#!/bin/sh
[ -z "$user" ] && write_log 14 "配置错误！保存阿里云API访问账号的'用户名'不能为空"
[ -z "$pass" ] && write_log 14 "配置错误！保存阿里云API访问密钥的'密码'不能为空"
[ $USE_CURL -eq 0 ] && USE_CURL=1
[ $use_https -eq 1 -a -z "$cacert" ] && cacert="IGNORE"
local CURL=$(command -v curl)
local CURL_SSL=$($CURL -V 2>/dev/null | grep -F "https")
local CURL_PROXY=$(find /lib /usr/lib -name libcurl.so* -exec strings {} 2>/dev/null \; | grep -im1 "all_proxy")
[ -z "$CURL" ] && write_log 13 "与阿里云服务器通信需要 cURL 支持, 请先安装"
command -v sed >/dev/null 2>&1 || write_log 13 "使用阿里云API需要 sed 支持, 请先安装"
command -v openssl >/dev/null 2>&1 || write_log 13 "使用阿里云API需要 openssl-util 支持, 请先安装"
. /usr/share/libubox/jshn.sh
local __HOST __DOMAIN __FQDN __TYPE __PROG __URLBASE __DATA __TTL __SEPARATOR __RECID
__URLBASE="http://alidns.aliyuncs.com"
[ $use_https -eq 1 ] && __URLBASE=$(echo $__URLBASE | sed -e 's#^http:#https:#')
__TTL=
__SEPARATOR="&"
[ "${domain:0:2}" == "@." ] && domain="${domain/./}"
[ "$domain" == "${domain/@/}" ] && domain="${domain/./@}"
__HOST="${domain%%@*}"
__DOMAIN="${domain#*@}"
if [ -z "$__HOST" -o "$__HOST" == "$__DOMAIN" ]; then
__HOST="@"
__FQDN=${__DOMAIN}
else
__FQDN=${__HOST}.${__DOMAIN}
fi
[ $use_ipv6 -eq 0 ] && __TYPE="A" || __TYPE="AAAA"
build_command() {
__PROG="$CURL -qLsS -o $DATFILE --stderr $ERRFILE"
[ -z "$CURL_SSL" -a $use_https -eq 1 ] && \
write_log 13 "cURL: libcurl 编译时缺少 https 支持"
if [ -n "$bind_network" ]; then
local __DEVICE
network_get_device __DEVICE $bind_network || \
write_log 13 "无法使用 'network_get_device $bind_network' 检测到本地设备 - 错误代码: '$?'"
write_log 7 "强制通过设备 '$__DEVICE' 进行通信"
__PROG="$__PROG --interface $__DEVICE"
fi
if [ $force_ipversion -eq 1 ]; then
[ $use_ipv6 -eq 0 ] && __PROG="$__PROG -4" || __PROG="$__PROG -6"
fi
if [ $use_https -eq 1 ]; then
if [ "$cacert" = "IGNORE" ]; then
__PROG="$__PROG --insecure"
elif [ -f "$cacert" ]; then
__PROG="$__PROG --cacert $cacert"
elif [ -d "$cacert" ]; then
__PROG="$__PROG --capath $cacert"
elif [ -n "$cacert" ]; then
write_log 14 "在 '$cacert' 中未发现用于 HTTPS 通信的有效证书"
fi
fi
if [ -z "$proxy" ]; then
__PROG="$__PROG --noproxy '*'"
elif [ -z "$CURL_PROXY" ]; then
write_log 13 "cURL: libcurl 编译时缺少代理支持"
fi
}
server_transfer() {
local __URL="$@"
local __ERR=0
local __CNT=0
local __RUNPROG
[ $# -eq 0 ] && write_log 12 "'server_transfer()' 出错 - 参数数量错误"
while : ; do
build_Request $__URL
__RUNPROG="$__PROG -X POST '$__URLBASE' -d '$__DATA'"
write_log 7 "#> $__RUNPROG"
eval $__RUNPROG
__ERR=$?
[ $__ERR -eq 0 ] && return 0
[ -n "$LUCI_HELPER" ] && return 1
write_log 3 "cURL Error: '$__ERR'"
write_log 7 "$(cat $ERRFILE)"
[ $VERBOSE -gt 1 ] && {
write_log 4 "Transfer failed - Verbose Mode: $VERBOSE - NO retry on error"
return 1
}
__CNT=$(( $__CNT + 1 ))
[ $retry_count -gt 0 -a $__CNT -gt $retry_count ] && \
write_log 14 "Transfer failed after $retry_count retries"
write_log 4 "Transfer failed - retry $__CNT/$retry_count in $RETRY_SECONDS seconds"
sleep $RETRY_SECONDS &
PID_SLEEP=$!
wait $PID_SLEEP
PID_SLEEP=0
done
write_log 12 "'server_transfer()' 出错 - 程序代码错误"
}
percentEncode() {
if [ -z "${1//[A-Za-z0-9_.~-]/}" ]; then
echo -n "$1"
else
local string=$1 i=0 chr
local ret=""
while [ $i -lt ${#string} ]; do
chr=${string:$i:1}
[ -z "${chr#[^A-Za-z0-9_.~-]}" ] && chr=$(printf '%%%02X' "'$chr")
ret="$ret$chr"
let i++
done
echo -n "$ret"
fi
}
build_Request() {
local args="$@" HTTP_METHOD="POST" string signature
__DATA=
for string in $args; do
case "${string%%=*}" in
Format|Version|AccessKeyId|SignatureMethod|Timestamp|SignatureVersion|SignatureNonce|Signature) ;;
*) __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}");;
esac
done
__DATA="${__DATA:1}"
string="Format=JSON"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="Version=2015-01-09"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="AccessKeyId=$user"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="SignatureMethod=HMAC-SHA1"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="Timestamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ'); __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="SignatureVersion=1.0"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string="SignatureNonce="$(cat '/proc/sys/kernel/random/uuid'); __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
string=$(echo -n "$__DATA" | sed 's/\'"${__SEPARATOR}"'/\n/g' | sort | sed ':label; N; s/\n/\'"${__SEPARATOR}"'/g; b label')
string="${HTTP_METHOD}${__SEPARATOR}"$(percentEncode "/")"${__SEPARATOR}"$(percentEncode "$string")
signature=$(echo -n "$string" | openssl dgst -sha1 -hmac "${pass}&" -binary)
signature=$(echo -n "$signature" | openssl base64)
string="Signature=$signature"; __DATA="$__DATA${__SEPARATOR}"$(percentEncode "${string%%=*}")"="$(percentEncode "${string#*=}")
}
describe_domain() {
local __URL count value ipaddr i=1 ret=0
__URL="Action=DescribeDomainRecords DomainName=${__DOMAIN} RRKeyWord=${__HOST} Type=${__TYPE}"
server_transfer "$__URL" || return 1
json_cleanup; json_load "$(cat "$DATFILE" 2>/dev/null)" >/dev/null 2>&1
json_get_var count "TotalCount"
if [ -z "$count" ]; then
json_get_var value "Message"
write_log 4 "Aliyun.com 响应失败, 错误原因: $value"
return 127
else
json_select "DomainRecords" >/dev/null 2>&1
json_select "Record" >/dev/null 2>&1
while [ $i -le $count ]; do
json_select $i >/dev/null 2>&1
json_get_var value "RR"
if [ "$value" == "$__HOST" ]; then
json_get_var __RECID "RecordId"
json_get_var value "Locked"
[ $value -ne 0 ] && write_log 13 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录已被锁定, 无法更新"
json_get_var value "Status"
[ "$value" != "ENABLE" ] && ret=$(( $ret | 4 )) && write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录已被禁用"
json_get_var value "Value"
if [ $use_ipv6 -eq 0 ]; then
ipaddr="$__IP"
else
expand_ipv6 $__IP ipaddr
expand_ipv6 $value value
fi
if [ "$value" == "$ipaddr" ]; then
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE} record nochg"
else
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE} record good"
ret=$(( $ret | 2 ))
fi
break
fi
json_select ..
let i++
done
if [ -z "$__RECID" ]; then
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录不存在"
ret=8
fi
fi
return $ret
}
add_domain() {
local __URL value
__URL="Action=AddDomainRecord DomainName=${__DOMAIN} RR=${__HOST} Type=${__TYPE} Value=${__IP}"
[ -n "${__TTL}" ] && __URL="${__URL} TTL=${__TTL}"
server_transfer "$__URL" || return 1
json_cleanup; json_load "$(cat "$DATFILE" 2>/dev/null)" >/dev/null 2>&1
json_get_var value "RecordId"
if [ -z "$value" ]; then
json_get_var value "Message"
write_log 4 "Aliyun.com 响应失败, 错误原因: $value"
return 127
else
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录已添加"
fi
return 0
}
update_domain() {
local __URL value
__URL="Action=UpdateDomainRecord RR=${__HOST} RecordId=${__RECID} Type=${__TYPE} Value=${__IP}"
[ -n "${__TTL}" ] && __URL="${__URL} TTL=${__TTL}"
server_transfer "$__URL" || return 1
json_cleanup; json_load "$(cat "$DATFILE" 2>/dev/null)" >/dev/null 2>&1
json_get_var value "RecordId"
if [ -z "$value" ]; then
json_get_var value "Message"
write_log 4 "Aliyun.com 响应失败, 错误原因: $value"
return 127
else
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录已更新为: ${__IP}"
fi
return 0
}
enable_domain() {
local __URL value
__URL="Action=SetDomainRecordStatus RecordId=${__RECID} Status=Enable"
server_transfer "$__URL" || return 1
json_cleanup; json_load "$(cat "$DATFILE" 2>/dev/null)" >/dev/null 2>&1
json_get_var value "RecordId"
if [ -z "$value" ]; then
json_get_var value "Message"
write_log 4 "Aliyun.com 响应失败, 错误原因: $value"
return 127
else
write_log 7 "Aliyun.com 上的 ${__FQDN} ${__TYPE}记录已启用"
fi
return 0
}
build_command
describe_domain
ret=$?
if [ $(( $ret & 1 )) -ne 0 ]; then
return $ret
elif [ $ret -eq 8 ]; then
sleep 3 && { add_domain; [ $? -ne 0 ] && return $?; }
else
[ $(( $ret & 4 )) -ne 0 ] && sleep 3 && { enable_domain; [ $? -ne 0 ] && return $?; }
[ $(( $ret & 2 )) -ne 0 ] && sleep 3 && { update_domain; [ $? -ne 0 ] && return $?; }
fi
return 0
