#! /usr/bin/lua

module("libmqlink", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libfil = require("utils.file")
local dkjson = require("dkjson");
local uci = require("luci.model.uci").cursor();
local sd_crypto = require("sd_crypto");
local mqlink_status_file = "/tmp/mqlink/mqlink_status.json"; -- ע����mqlink_status�ӿ�д���ļ���ͬһ��
local uybvsn_file = "/etc/mqlink/.uybvsn";
local szixpa_file = "/etc/mqlink/.szixpa"

-- ���ﲻ��Ҫ����ģ���ʼ����ֱ�Ӽ̳��ϲ���õ�
-- libdbg.debug_init("/tmp/libmqlink/", "mqlink_reg_status.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

err_msg_map = {
    ["-5"]   = "Get authentic signature fail",
    ["-4"]   = "Device internal error",
    ["-3"]   = "Parameter is invalid",
    ["-2"]   = "Parameter is null",
    ["-1"]   = "Function is not support",
    ["0"]    = "OK",
    ["1"]    = "Cannot connecte to Internet or dns failed",
    ["2"]    = "The server did not return a signature",
    ["1036"] = "Timestamp expires",
    ["1037"] = "Failed to verify signature",
    ["4003"] = "Device is not registered to server",
    ["9999"] = "Unknow error",
}

function get_random_from_uuid(random_str_len)
    -- �������
    assert(random_str_len ~= nil and type(random_str_len) == "number" and tonumber(random_str_len) <= 32, table.concat({"ERROR in ", debug.getinfo(2).short_src, " ", "[", debug.getinfo(2).currentline , "] ", "get_random_from_uuid() param:random_str_len is nil or invalid[1, 32]"}));

    local uuid = libfil.read_file("/proc/sys/kernel/random/uuid");
    local lib_string = require "utils.string";
    local uuid_str = lib_string.string_filter(uuid, "-");
    local random_str = string.sub(uuid_str, 1, tonumber(random_str_len));

    return random_str;
end

function get_authentic_info_tab(timestamp)
    local tab = {};

    tab["sn"] = uci:get_first("sysinfo", "sysinfo", "serial_num");
    if (tab["sn"] == nil or #tab["sn"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get sysinfo.@sysinfo[0].serial_num failed!");
        return {};
    end
    tab["url"] = uci:get_first("mqlink_reg", "mqlink_reg", "authurl");
    if (tab["url"] == nil or #tab["url"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get mqlink_reg.@mqlink_reg[0].authurl failed!");
        return {};
    end
    tab["appid"] = uci:get_first("mqlink_reg", "mqlink_reg", "appid");
    if (tab["appid"] == nil or #tab["appid"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get mqlink_reg.@mqlink_reg[0].appid failed!");
        return {};
    end
    -- BUGID:1153608
    if (libfil.file_is_exist(szixpa_file) ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "%s is not exist", szixpa_file);
        return {};
    end
    enc_szixpa = libfil.read_file(szixpa_file);
    recode, tab["secret"] = sd_crypto.lua_sd_crypto_buf_decrypt(enc_szixpa, #enc_szixpa, 'c');
    if (tab["secret"] == nil or #tab["secret"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get szixpa failed!");
        return {};
    end
    if (libfil.file_is_exist(uybvsn_file) ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "%s is not exist", unbind_key_file);
        return {};
    end
    enc_uybvsn = libfil.read_file(uybvsn_file);
    recode, tab["unbind_key"] = sd_crypto.lua_sd_crypto_buf_decrypt(enc_uybvsn, #enc_uybvsn, 'c');
    if (tab["unbind_key"] == nil or #tab["unbind_key"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get uybvsn failed!");
        return {};
    end
    tab["nonce"] = get_random_from_uuid(16);
    -- uci:set("mqlink_reg", "mqlink_reg", "nonce", tab["nonce"]);-- ����ʧ��
    uci:foreach("mqlink_reg", "mqlink_reg", function(s)
        uci:set("mqlink_reg", s[".name"], "nonce", tab["nonce"]);
    end)

    return tab;
end

function get_authentic_info_str(tab)
    local tab_sort_by_val = {};

    for _, v in pairs(tab) do
        if (v ~= nil) then
            table.insert(tab_sort_by_val, v);
        end
    end
    table.sort(tab_sort_by_val, function(a, b) return (a < b) end);-- ����
    authentic_info_str = "";
    for k, v in pairs(tab_sort_by_val) do
        authentic_info_str = table.concat({authentic_info_str, v})
        -- print(k, v);
    end

    return authentic_info_str;
end

function get_authentic_signature(method, tab)
    -- �������
    if (tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "get_authentic_signature parameter tab is nil");
        return false, nil;
    end
    if (method == nil or #method == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get_authentic_signature parameter method is nil");
        return false, nil;
    end
    
    local signature_info_tab = {
        ["appid"]     = tab["appid"],
        ["secret"]    = tab["secret"],
        ["nonce"]     = tab["nonce"],
        ["timestamp"] = tab["timestamp"],
    }
    
    local authentic_info_str = get_authentic_info_str(signature_info_tab)
    local signature = require("crypto").digest(method, authentic_info_str);
    if (signature == nil) then
        libdbg.lua_debug(libdbg.ERROR, "get_authentic_signature crypto by %s fail", method);
        return false, nil;
    end

    return true, signature;
end

function http_send(url, method, data, timeout)
    libdbg.lua_debug(libdbg.DEBUG, "Enter http_send()");

    -- ��μ��
    if (url == nil or #url == 0) then
        libdbg.lua_debug(libdbg.ERROR, "url is nil, requeire parameter url");
    end
    libdbg.lua_debug(libdbg.INFO, "url: %s", url);
    libdbg.lua_debug(libdbg.INFO, "postdata: %s", data or "");-- data����Ϊ��

    local result = {};
    local curl = require "luacurl";
    local c = curl.new();
    c:setopt(curl.OPT_USERAGENT, "curl/7.29.0");
    c:setopt(curl.OPT_URL, url);
    c:setopt(curl.OPT_HTTPHEADER, "content-type: application/json", "Expect:");
    c:setopt(curl.OPT_SSL_VERIFYHOST, 1);
    c:setopt(curl.OPT_SSL_VERIFYPEER, true);
    -- ָ��tls1.2�汾
    c:setopt(curl.OPT_SSLVERSION, curl.SSLVERSION_TLSv1_2 or 6)
    local cipher_list = table.concat({
        "ECDHE-ECDSA-AES256-GCM-SHA384",
        "ECDHE-ECDSA-AES128-GCM-SHA256",
        "ECDHE-RSA-AES128-GCM-SHA256",
        "DHE-RSA-AES256-GCM-SHA384",
        "DHE-RSA-AES128-GCM-SHA256",
        "AES256-GCM-SHA384",
        "AES128-GCM-SHA256"
    }, ":")

    -- ָ��ǿ�����׼�
    c:setopt(curl.OPT_SSL_CIPHER_LIST, cipher_list)
    -- ���method����POST����Ĭ��ΪGET
    if (method == "POST") then
        c:setopt(curl.OPT_POST, true);
        c:setopt(curl.OPT_POSTFIELDS, data);
    end
    c:setopt(curl.OPT_TIMEOUT, timeout);
    c:setopt(curl.OPT_WRITEFUNCTION, function (param, buf) -- �ص�call back������������
        table.insert(result, buf) -- result ������Ϊ���ؽ��
        return #buf
    end)
    local status = c:perform(); -- ����ֵ�ǲ���ֵ��boolean
    local http_code = c:getinfo(curl.INFO_RESPONSE_CODE);-- http������������
    -- c:close();-- ע�ⲻ�ܹرշ����coredump�������������ȫ�ֵģ����������رա�����Ҫע����ܴ��ڵ��ڴ�й©
    local http_rsp = table.concat(result);

    libdbg.lua_debug(libdbg.INFO, "http_rsp:%s, http_code:%d", http_rsp, http_code);

    return status, http_rsp, http_code;
end

--[[
    module_ret() -- �������
    @code�����صĴ�����
    @accountInfo���豸�����Ʒ��������ʺ���Ϣ�������ʱ�����Ϊ��
    @http_code��http�����룬�����ʱ�򣬿���Ϊ��
    @msg�������Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ�����{"code":x, "msg":"xxx", "accountInfo":"188****888"}
    @note��������˻᷵�ػ���д�뵽�ļ��С�
--]]
local function module_ret(code, accountInfo, http_code,  msg, ...)
    local result = {};

    -- ���ؽ�����ݷ�װ
    result["code"] = tonumber(code);

    if (accountInfo ~= nil) then
        result["accountInfo"] = accountInfo;
    end

    if (http_code ~= nil) then
        result["http_code"] = http_code;
    end

    if (msg ~= nil) then
        result["msg"] = string.format(msg, ...);
    else
        result["msg"] = err_msg_map[code];
    end

    -- ���д�ļ�
    local result_str = dkjson.encode(result);
    libfil.write_file(mqlink_status_file, result_str, "w")

    return result_str;
end

function mqlink_reg_status(timestamp)
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_reg_status()********************");

    -- 1���������
    if (timestamp == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param:timestamp is nil");
        return module_ret("-2");
    elseif (tonumber(timestamp) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param timestamp:%s is invalid", tab["timestamp"]);
        return module_ret("-3", nil, "param timestamp:%s is invalid", timestamp);
    end
    libdbg.lua_debug(libdbg.INFO, "timestamp:%s", timestamp);

    -- 2�����ݻ�ȡ
    local tab = get_authentic_info_tab();
    if (tab == {}) then
        libdbg.lua_debug(libdbg.ERROR, "Device get info error");
        return module_ret("-4");
    end
    tab["timestamp"] = timestamp;
    ret, tab["signature"] = get_authentic_signature("sha1", tab);-- ����ǩ��
    if (ret == false) then
        libdbg.lua_debug(libdbg.ERROR, "get_authentic_signature fail");
        module_ret("-5");
    end

    -- 3����������
    local data = string.format('{\
    "appid": "%s",\
    "nonce": "%s",\
    "signature": "%s",\
    "timestamp": "%s",\
    "sn": "%s"\n}\n',
    tab["appid"],
    tab["nonce"],
    tab["signature"],
    tab["timestamp"],
    tab["sn"]);
    local status, http_rsp, http_code = http_send(tab["url"], "POST", data, 3);

    -- 4����������
    -- ���ж�http������Ͳ���Ҫ��ȥ����http����ֵ
    if (status == false or (http_code ~= 200 and http_code ~= 204)) then
        libdbg.lua_debug(libdbg.ERROR, "http post failed, http_code: %s", http_code);
        return module_ret("1", "none", http_code);
    end
    local http_rsp_tab = require("dkjson").decode(http_rsp);
    -- �����ж�httpӦ��� code��ֻҪpcall����һ�μ��ɣ���֤��json
    local status, retval = pcall(function() http_rsp_code = http_rsp_tab["code"] end);
    if (status == false or http_rsp_code == nil) then
        -- ����json����ʧ��ֵΪ�յ��������ʱ�����httpӦ����json�ģ�http_rsp_tab���Ǳ���
        libdbg.lua_debug(libdbg.ERROR, "json decode http rsp code failed, error: %s", retval or "http rsp code is nil");
        return module_ret("9999");
    end
    libdbg.lua_debug(libdbg.DEBUG, "json decode http rsp code success");

    if (http_rsp_code == 4003) then
        http_rsp_tab["msg"] = "Device is not registered to CLOUD server";
    end

    return module_ret(tostring(http_rsp_code), http_rsp_tab["accountInfo"], http_rsp_tab["msg"]);
end

-- ���easycwmpd������mqlink��Ȼ��dns��ͨ�ĳ���
function mqlink_get_dnsurl()
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_get_dnsurl()********************");

    -- 1��CWMP��������
    local tab = {};
    tab["sn"] = uci:get_first("sysinfo", "sysinfo", "serial_num");
    if (tab["sn"] == nil or #tab["sn"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get sysinfo.@sysinfo[0].serial_num failed!");
        return false;
    end
    tab["mqtt_url"] = uci:get_first("mqlink", "mqlink", "addr");
    if (tab["mqtt_url"] == nil or #tab["mqtt_url"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get mqlink.@mqlink[0].addr failed!");
        return false;
    end
    local cwmp_url_total = uci:get_first("cwmp", "cwmp", "ACSURL");
    if (cwmp_url_total == nil or #cwmp_url_total == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get cwmp.@cwmp[0].ACSURL failed!");
        return false;
    end

    tab["cwmp_url"] = string.match(cwmp_url_total, '//([%w.]+)/');
    libdbg.lua_debug(libdbg.INFO, "cwmp_url domain is %s", tab["cwmp_url"]);

    -- 2����������
    local data = string.format('{\
    "sn": "%s",\
    "mqtt": "%s",\
    "cwmp": "%s"\n}\n',
    tab["sn"],
    tab["mqtt_url"],
    tab["cwmp_url"]);
    --local url = uci:get_first("mqlink_reg", "mqlink_reg", "dnsurl");
    if (libfil.file_is_exist(dlkodz_file) ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "%s is not exist", dnsurl_file);
        return {};
    end
    enc_dlkodz = libfil.read_file(dlkodz_file);
    recode, url = sd_crypto.lua_sd_crypto_buf_decrypt(enc_dlkodz, #enc_dlkodz, 'c');
    if (url == nil or #url == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get dlkodz failed!");
        return {};
    end
    -- GET����ʹ������ķ�ʽ
    -- tab["url"] = string.format(url, tab["cwmp_url"], tab["sn"], tab["mqtt_url"]);
    -- POST����ʹ��post data
    local status, http_rsp, http_code = http_send(url, "POST", data, 3);

    -- 3����������
    -- ���ж�http������Ͳ���Ҫ��ȥ����http����ֵ
    if (status == false or (http_code ~= 200 and http_code ~= 204)) then
        libdbg.lua_debug(libdbg.ERROR, "http post failed, http_code: %s", http_code);
        return module_ret("1", "none", http_code);
    end
    local http_rsp_tab = require("dkjson").decode(http_rsp);
    -- �����ж�httpӦ��� code��ֻҪpcall����һ�μ��ɣ���֤��json
    local status, retval = pcall(function() http_rsp_code = http_rsp_tab["code"] end);
    if (status == false or http_rsp_code == nil) then
        -- ����json����ʧ��ֵΪ�յ��������ʱ�����httpӦ����json�ģ�http_rsp_tab���Ǳ���
        libdbg.lua_debug(libdbg.ERROR, "json decode http rsp code failed, error: %s", retval or "http rsp code is nil");
        return module_ret("9999");
    end
    libdbg.lua_debug(libdbg.DEBUG, "json decode http rsp code success");

    hosts_file = "/etc/hosts";
    local hosts_ctx = libfil.read_file(hosts_file);
    for i, v in ipairs(http_rsp_tab["list"]) do
        if (string.match(hosts_ctx, v["domain"]) ~= nil) then
            libdbg.lua_debug(libdbg.INFO, "domain:%s already exists", v["domain"]);
        else
            libfil.write_file(hosts_file, "\n"..v["ip"].." "..v["domain"].."\n", "a");
        end
    end
    libdbg.lua_debug(libdbg.DEBUG, "cat %s\n%s", hosts_file, libfil.read_file(hosts_file));

    return 0;
end

-- ���Դ���
-- param = tostring(os.time() * 1000);;
-- mqlink_reg_status(param)
