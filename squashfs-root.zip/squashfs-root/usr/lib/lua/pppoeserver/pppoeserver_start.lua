#!/usr/bin/lua
require "public_module"

local lib_debug = require "utils.debug"
--local pppoe = require "luci.model.pppoe"
local uci = require "uci"
cjson = require "cjson"
local uci = require "uci"
local masklen = require "libc2lua"
local uci_r = uci.cursor()
local modul = "pppoe-server"
local sd_cfg = "/etc/sd_config/single/pppoeserver_global.json"
local chap_secrets = "/etc/ppp/chap-secrets"
local pap_secrets = "/etc/ppp/pap-secrets"
local iptables_path= "/tmp/iptables.rules/pppoe-server"
local exceptip_path = "/etc/config/pppoeserver_exceptip"
local ippool_path = "/etc/sd_config/single/ippool.json"
local def_ippool = "dev_config add --module 'ippool' '{\"first_addr\":\"10.44.66.100\",\"netmask\":\"255.255.255.0\",\"end_addr\":\"10.44.66.200\",\"ippool_name\":\"pppoe_pool\"}'"
local product = require("product")
local web_node = product.get_product("capacity.web")
local spt_pppoe_radius = string.format("cat /tmp/sd_device/sd_device.json|jq .%s.pppoeRadius | sed 's/\"//g'", web_node)
lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoe-server.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

local function is_spt_capacity(cmd)
    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close()
    res = string.gsub(res, "\n", "")
    if res == "1" then
        return true
    else
        return false
    end
end

function pppoeserver_user_load()
    --os.execute("mkdir -p /tmp/pppoe/server/config")
	local fp = io.open("/etc/config/pppoeserver_user", "r")
	if fp == nil then
        lib_debug.lua_debug(lib_debug.DEBUG, "open /etc/config/pppoeserver_user failed\n")
		return
	end
    fp:close()

    fp = io.open(chap_secrets, "w")
    fp:write("#USERNAME  PROVIDER  PASSWORD  IPADDRESS\n")
	uci_r:foreach("pppoeserver_user", "pppoeserver_user",
		function(section)
			if section["enable"] == "1" then
				local name = section["name"]
				local passwd = section["passwd"]
				local str = string.format([['%s' '%s' '%s' *]], name, modul, passwd)
                lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_user_load str:%s\n", str)
				fp:write(str, "\n")
			end
		end
	)
	
	fp:close()
    os.execute("cp "..chap_secrets.." "..pap_secrets)
end

function pppoeserver_maxnum_load()
	local fp = io.open("/tmp/sd_device/sd_device.json", "r")
	if fp == nil then
        lib_debug.lua_debug(lib_debug.DEBUG, "open /tmp/sd_device/sd_device.json failed\n")
		return
	end
    local data = fp:read("*a")
    fp:close()
    
    local tmp_json = cjson.decode(data)
    local tmp_maxnum = tmp_json.gateway.pppoe_server_max_session
    if (tmp_maxnum == nil) then
        tmp_maxnum = tmp_json.gateway.pppoe_server_maxnum
    end
    
    local uci_maxnum = uci_r:get("pppoeserver_global", "global", "max_sessions")
    -- if (data.state == uci_maxnum) then
    --     return
    -- end
    if (tmp_maxnum == uci_maxnum and tmp_maxnum ~= nil) then
        return
    end

    --һ�㲻��δnil��δnilǿ�Ƹ�һ��ֵ��ܣ�δnilʱ˵��tmp/sd_device/sd_device.jsonȱ��������
    if (tmp_maxnum == nil) then
        lib_debug.lua_debug(lib_debug.DEBUG, "tmp/sd_device/sd_device.json.pppoe_server_max_session and pppoe_server_maxnum is nil\n")
        tmp_maxnum = "35"
    end
    uci_r:set("pppoeserver_global", "global", "max_sessions", tmp_maxnum)
    uci_r:commit("pppoeserver_global")
	uci_r:revert("pppoeserver_global")
    
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    old_json.max_sessions = tmp_maxnum
    file_write(sd_cfg, cjson.encode(old_json))
end
-- ok
function pppoeserver_argvs_load()
	local max_sessions = uci_r:get("pppoeserver_global", "global", "max_sessions")
    local hardware_version
    uci_r:foreach("sysinfo", "sysinfo",
		function(section)
            --local_ip = section["wan_ip"]
			hardware_version = section["hardware_version"]
		end
	)
    --local local_ip = uci_r:get("network", "lan", "ipaddr")
    local local_ip = uci_r:get("pppoeserver_global", "global", "localip")
    local monitor_port = uci_r:get("pppoeserver_global", "global", "monitor_port")
    if monitor_port == nil or monitor_port == "233" then
        monitor_port = "br-lan"
    else
        monitor_port = "br-lan_"..monitor_port
    end
    
    local options = string.format([[OPTIONS="-C %s -I %s -L %s -N %s -x 1 -u -O /etc/ppp/pppoe-server-options -F -k"]], hardware_version, monitor_port, local_ip, max_sessions)
    
    lib_debug.lua_debug(lib_debug.DEBUG, "options:%s\n", options)
 
	local fp = io.open("/etc/ppp/pppoe-server-argvs", "w")
	if fp == nil then
    lib_debug.lua_debug(lib_debug.DEBUG, "open file failed\n")
	end
	fp:write(options)
	fp:close()
end

-- ok
function pppoeserver_options_load()
	local fp = io.open("/etc/ppp/pppoe-server-options", "w")
    --��ַ��
	fp:write("plugin ippool.so", "\n")
    --[[local ippool_name
    --��Ҫ����pptp��pppoe-server�ĵ�ַ������

    uci_r:foreach("pppoeserver_user", "pppoeserver_user",
			function(section)
				ippool_name = section["ippool_name"]
			end
		)
        
    fp:write("ippool_name ", ippool_name, "\n")
    ]]
	fp:write("ippool_name pppoe_pool", "\n")
	fp:write("name '", modul, "'\n")
    
    if is_spt_capacity(spt_pppoe_radius) == true then
        local radius_check = uci_r:get("pppoeserver_global", "global", "radius_check")
        local secret_check = uci_r:get("pppoeserver_global", "global", "secret_check")
        if radius_check == "1" then
            fp:write("plugin rp-radius.so", "\n")
        end
        if radius_check == "1" and secret_check == "1" then
            fp:write("spt_local_acct_check", "\n")
        end
    end
    --dns
	local dns_flag = false
	local fisrt_dns = uci_r:get("pppoeserver_global", "global", "first_dns_server")
	if fisrt_dns ~= nil and fisrt_dns ~= "0.0.0.0" and fisrt_dns ~= "" then
		fp:write("ms-dns ", fisrt_dns, "\n")
		dns_flag = true
	end
	local second_dns = uci_r:get("pppoeserver_global", "global", "second_dns_server")
	if second_dns ~= nil and second_dns ~= "0.0.0.0" and second_dns ~= "" then
		fp:write("ms-dns ", second_dns, "\n")
		dns_flag = true
	end
	if dns_flag == false then
		--local local_ip = uci_r:get("network", "lan", "ipaddr")
        local local_ip = uci_r:get("pppoeserver_global", "global", "localip")
		fp:write("ms-dns ", local_ip, "\n")
	end
    
    --���ͻ����Ƿ����
	fp:write("lcp-echo-interval 10", "\n")
	local max_noreply_lcp = uci_r:get("pppoeserver_global", "global", "max_noreply_lcp")
	fp:write("lcp-echo-failure ", max_noreply_lcp, "\n")
    
    --ָ��������ӿ���n�룬��pppdӦ�öϿ����ӡ�
	--local idle_time = uci_r:get("pppoeserver_global", "global", "idle_time")
	--idle_time = tostring(tonumber(idle_time) * 60)
	--fp:write("idle ", idle_time, "\n")
    
    --����
	local pap = uci_r:get("pppoeserver_global", "global", "pap")
	if pap == "1" then
		fp:write("require-pap", "\n")
	else
		fp:write("refuse-pap", "\n")
	end
	local chap = uci_r:get("pppoeserver_global", "global", "chap")
	if chap == "1" then
		fp:write("require-chap", "\n")
	else
		fp:write("refuse-chap", "\n")
	end
	local mschap = uci_r:get("pppoeserver_global", "global", "mschap")
	if mschap == "1" then
		fp:write("require-mschap", "\n")
	else
		fp:write("refuse-mschap", "\n")
	end
	local mschapv2 = uci_r:get("pppoeserver_global", "global", "mschapv2")
	if mschapv2 == "1" then
		fp:write("require-mschap-v2", "\n")
	else
		fp:write("refuse-mschap-v2", "\n")
	end

	fp:write("debug", "\n")
	fp:write("logfile /tmp/pppoe-server/debug/pppoe-server.log", "\n")
	
	fp:close()
end

-- ok
function ppppeserver_iptables_load()
    --print("ppppeserver_iptables_load\n")
	local state = uci_r:get("pppoeserver_global", "global", "state")
	local force_state = uci_r:get("pppoeserver_global", "global", "force_state")
	local user_isolation = uci_r:get("pppoeserver_global", "global", "user_isolation")
    local ippool_name
    uci_r:foreach("pppoeserver_user", "pppoeserver_user",
			function(section)
				ippool_name = section["ippool_name"]
			end
		)
    if (ippool_name == nil)
    then
        ippool_name = "pppoe_pool"
    end
        
    --[[local ipaddr
    uci_r:foreach("sysinfo", "sysinfo",
		function(section)
            ipaddr = section["wan_ip"]
		end
	)]]
    --local ipaddr = uci_r:get("network", "lan", "ipaddr")
    local ipaddr = uci_r:get("pppoeserver_global", "global", "localip")    
    lib_debug.lua_debug(lib_debug.DEBUG, "ipaddr:%s\n", ipaddr)
    local fp = io.open(ippool_path,"r")
	if(fp == nil )then
        lib_debug.lua_debug(lib_debug.DEBUG, def_ippool)
		os.execute(def_ippool)
    else
        fp:close()
	end
	
    local ippool_json = file_read(ippool_path)
    local ippool_data = cjson.decode(ippool_json)
    local length = table.maxn(ippool_data.list)
    local num = 1
    local rule
    local first_addr
    local end_addr
    local netmask
    local cmd_del
    
    local monitor_port = uci_r:get("pppoeserver_global", "global", "monitor_port")
    if monitor_port == nil or monitor_port == "233" then
        monitor_port = "br-lan"
    else
        monitor_port = "br-lan_"..monitor_port
    end

    while ( num < length + 1 )
    do  
        --print(ippool_name)
        --print(ippool_data.list[num].ippool_name)
		if (ippool_data.list[num].ippool_name == ippool_name)
        then
            rule = ippool_data.list[num].rule_name
            first_addr = ippool_data.list[num].first_addr
            end_addr = ippool_data.list[num].end_addr
            netmask = ippool_data.list[num].netmask
            --print(rule)
            --print(first_addr)
            --print(end_addr)
            --print(netmask)
            break
        end
        num = num + 1
    end
    if (rule == nil) then
        lib_debug.lua_debug(lib_debug.DEBUG, "ppppeserver_iptables_load:rule is nil \n")
        return
    end
    lib_debug.lua_debug(lib_debug.DEBUG, "state:%s, force_state:%s now:%d rule:%s", state, force_state, os.time(), rule)
	if state == "1" and force_state == "1" then
		-- force state iptables
		if cmd == nil then
            cmd = string.format([[iptables -w -I FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], monitor_port, rule)
            cmd_del = string.format([[iptables -w -D FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], monitor_port, rule)
		else
            cmd = string.format([[%s;iptables -w -I FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], cmd, monitor_port, rule)
            cmd_del = string.format([[%s;iptables -w -D FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], cmd_del, monitor_port, rule)
		end

		if cmd == nil then
            cmd = string.format([[iptables -w -I FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], monitor_port, rule)
            cmd_del = string.format([[iptables -w -D FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], monitor_port, rule)
		else
            cmd = string.format([[%s;iptables -w -I FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], cmd, monitor_port, rule)
            cmd_del = string.format([[%s;iptables -w -D FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], cmd_del, monitor_port, rule)
		end
        --print(cmd)
        
        local file = io.open(exceptip_path,"r")
        if file ~= nil then 
            if cmd ~= nil then
                cmd = string.format([[%s;ipset create pppoeserver_user_exceptip hash:net 2>/dev/null;iptables -w -I FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -I FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN 2>/dev/null]], cmd)
                cmd_del = string.format([[%s;iptables -w -D FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -D FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN 2>/dev/null;ipset destroy  pppoeserver_user_exceptip 2>/dev/null]], cmd_del)
            else
                cmd = string.format([[ipset create pppoeserver_user_exceptip hash:net 2>/dev/null;iptables -w -I FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -I FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN 2>/dev/null]])
                cmd_del = string.format([[iptables -w -D FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -D FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN; 2>/dev/null;ipset destroy  pppoeserver_user_exceptip 2>/dev/null]])
            end
        end
        
		uci_r:foreach("pppoeserver_exceptip", "pppoeserver_exceptip",
			function(section)
				if section["state"] ~= "0" then
					if cmd == nil then
						cmd = string.format([[ipset add pppoeserver_user_exceptip %s-%s -exist 2>/dev/null]], section["start_ip"], section["end_ip"])
					else
						cmd = string.format([[%s;ipset add pppoeserver_user_exceptip %s-%s -exist 2>/dev/null]], cmd, section["start_ip"], section["end_ip"])
					end
				end
			end
		)
	end
    
    local del_netmask_len = string.len(netmask)
    --print(del_netmask_len)
    --�����������ַ�������lua��չ�⣬��ͨ��netmasklen������ȡ��������λ��
    local netmasklen = masklen.netmasklen(netmask)
    
    --iptables -t nat -A POSTROUTING -s 192.168.111.0/24 -j SNAT --to-source 172.30.111.50  
    if cmd == nil then
        cmd = string.format([[iptables -w -t nat -A POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s 2>/dev/null]], ipaddr)
        cmd_del = string.format([[iptables -w -t nat -D POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s  2>/dev/null]], ipaddr)
    else
        cmd = string.format([[%s;iptables -w -t nat -A POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s 2>/dev/null]], cmd, ipaddr)
        cmd_del = string.format([[%s;iptables -w -t nat -D POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s  2>/dev/null]], cmd_del, ipaddr)
    end
    
    local fp_ippool= io.popen('ipset list |grep ippool_rule_pppoe_pool')
    local res = fp_ippool:read("*all")
    local res_len = string.len(res)
    if (res_len == 0) then
        lib_debug.lua_debug(lib_debug.DEBUG, "ippool_rule_pppoe_pool is err\n")
        os.execute("ubus -t 3 send \"pppoe_server_restart\" &")
    else 
        lib_debug.lua_debug(lib_debug.DEBUG, "ipset list |grep ippool_rule_pppoe_pool:%s\n", res)
    end

	if cmd ~= nil then
		--print(cmd)
        if (cmd_del ~= nil) then
            lib_debug.lua_debug(lib_debug.DEBUG, "cmd_del:%s", cmd_del)
            os.execute(cmd_del)
        end
        file_write(iptables_path, cmd)
		os.execute(cmd)
        lib_debug.lua_debug(lib_debug.DEBUG, "cmd:%s", cmd)
	end

    if state == "1" and force_state == "0" then
        cmd = "iptables -L FORWARD_sd_chain -v -n"
        local t1 = io.popen(cmd)
        local result = t1:read("*all")
        t1:close()
        local res = string.match(result, rule)
        if (res == nil) then
            lib_debug.lua_debug(lib_debug.DEBUG, "%s\n", result)
        else
            os.execute("ubus -t 3 send \"pppoe_server_restart\" &")
            lib_debug.lua_debug(lib_debug.DEBUG, "execute pppoe_server_restart\n")
        end
    end
end

function pppoeserver_start()
	-- check pppoeserver state
    lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_start\n")
	local state = uci_r:get("pppoeserver_global", "global", "state")
	if "0" == state then
        lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_global state is 0\n")
		return
	end
    pppoeserver_maxnum_load()
	-- load user
    --lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_user_load\n")
	--pppoeserver_user_load()
    
	-- load argvs
	lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_argvs_load\n")
    --pppoe.pppoeserver_argvs_load()
    pppoeserver_argvs_load()
	
    -- load options
	lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_options_load\n")
    --pppoe.pppoeserver_options_load()
    pppoeserver_options_load()
	
    -- set iptables	
	lib_debug.lua_debug(lib_debug.DEBUG, "ppppeserver_iptables_load\n")
    --pppoe.ppppeserver_iptables_load()
    ppppeserver_iptables_load()
    
	lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_start end\n")
end

pppoeserver_start()
