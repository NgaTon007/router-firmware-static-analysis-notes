#!/usr/bin/lua
require "public_module"
--local pppoe = require "luci.model.pppoe"
cjson = require "cjson"
local lfs = require "lfs"

local user_file = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local conf_file = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo_tmp.json"
local flowctrl = "flowctrl"
local sd_device = "/tmp/sd_device/sd_device.json"
local path = "/tmp/pppoe-server/pppoeserver_status/"
local path_mv = "/tmp/pppoe-server/pppoeserver_status_mv/"
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local uci = require "luci.model.uci".cursor()
local DEBUG_LOG_DIR = "/tmp/pppoe-server/debug/"
local order_relation = "/tmp/account_mgr/order_relation"
local inform_cloud_charge_active_cmd = "dev_config set -m chargeActive '{}'"
local ONE_MINUTE_BY_SEC = 60
local ONE_DAY_BY_SEC = 86400
local product = require("product")
local web_node = product.get_product("capacity.web")
local spt_expire_remind_cmd = string.format("cat /tmp/sd_device/sd_device.json|jq .%s.spt_expire_remind | sed 's/\"//g'", web_node)
local get_charge_usr_status = "account_mgr_cmd.elf -Q -u %s -t %s"
local elisten_json = {}
local cmd_iproute
local curl_flag = true
local spt_expire_remind

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

local function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "pppoeserver_port_status.log", 200, module_debug.DEBUG, "1");
end

local function traceback(msg)
    module_debug.lua_debug(module_debug.ERROR, debug.traceback());
    print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
end

local function is_spt_expire_remind(cmd)
    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close()
    res = string.gsub(res, "\n", "")
    if res == "1" then
        return true
    else
        return false
    end
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end
function file_write_a(conf_file, data)
    local file = io.open(conf_file,"a+")
    file:write(data)
    file:close()
end

local function flow_name_get(user_name)
    local flow_name = ""
    if (user_name == nil or user_name == "") then
        module_debug.lua_debug(module_debug.INFO, "get username is nil")
        return nil
    end
    local uci = require "luci.model.uci".cursor()
    uci:foreach("pppoeserver_user","pppoeserver_user",function(s)
        local name_section = s[".name"]
        local username = uci:get("pppoeserver_user", name_section, "name")
        if (user_name == username) then
            flow_name = uci:get("pppoeserver_user", name_section, "flow_name")
            if (flow_name ~= nil) then
                module_debug.lua_debug(module_debug.INFO, "INFO: user_name:%s, flow_name:%s", user_name, flow_name)
            end
            return false
        end
    end
    )
    return flow_name
end

function port_up(new_json, ret)	
	-- check pppoeserver state
    module_debug.lua_debug(module_debug.INFO, "***************port_up start\n")

    -- 支持认证计费的设备需要判断获取认证计费信息是否成功 
    if (ret == -1) then
        local cmd = string.format([[kill -9 %s]], new_json.pppd_pid)
        module_debug.lua_debug(module_debug.INFO, "get extra pram err, cmd:%s\n", cmd)
        os.execute(cmd)
        return -1
    end
    
    local data = '{"count":"0","list":[]}' 
    local file = io.open(conf_file, "r")
    if (file ~= nil) then
        data = file:read("*a")
        file:close()
    end
    local old_json = cjson.decode(data)
    local old_length = table.maxn(old_json.list)
    
    local num = 1 
    while ( num < old_length + 1 )
    do
		if ((old_json.list[num].peername == new_json.peername))
        then
            --保证每个账号只有一个用户使用
            if (old_json.list[num].pppd_pid == new_json.pppd_pid)
            then
                module_debug.lua_debug(module_debug.INFO, "repeat login; peername:%s, pppd_id:%s\n", new_json.peername, new_json.pppd_pid)
                return -1
            end
            local cmd = string.format([[kill -9 %s]], new_json.pppd_pid)
            module_debug.lua_debug(module_debug.INFO, "cmd:%s\n", cmd)
            os.execute(cmd)
            return -1
        end
        num = num + 1
    end

    old_length = table.maxn(old_json.list)
    num = 1 
    while ( num < old_length + 1 )
    do
		if ((old_json.list[num].macremote == new_json.macremote))
        then
            --保证每个mac只有一个在线用户
            table.remove(old_json.list,num)
        end
        num = num + 1
    end
    
    table.insert(old_json.list,new_json)
    file_write(conf_file, cjson.encode(old_json))
    if cmd_iproute == nil then
        cmd_iproute = string.format([[ip route add %s dev %s  proto kernel  scope link  src %s]], new_json.ipremote, new_json.ifname, new_json.localip)
    else
        cmd_iproute = string.format([[%s;ip route add %s dev %s  proto kernel  scope link  src %s]], cmd_iproute, new_json.ipremote, new_json.ifname, new_json.localip)
    end
    
    file_write_a(path..flowctrl, cjson.encode(elisten_json).."\n")
	module_debug.lua_debug(module_debug.INFO, "****************port_up end\n")
end


function port_down(new_json)	
	-- check pppoeserver state
    module_debug.lua_debug(module_debug.INFO, "***************port_down start\n")
    local old_data = file_read(conf_file)
    if (old_data == nil) then
        module_debug.lua_debug(module_debug.INFO, "old_data is nil")
        return
    end
    local old_json = cjson.decode(old_data)
	local old_length = table.maxn(old_json.list)
    local file
    local flag = 0 
    local mac_new_session = 0
    
    local num = 1 
    while ( num < old_length + 1 )
    do
		if ((old_json.list[num].macremote == new_json.macremote and old_json.list[num].pppd_pid == new_json.pppd_pid))
        then
            if elisten_json["name"] == nil or elisten_json["name"] == "" then
                elisten_json["name"] = old_json.list[num].peername
            end
            if elisten_json["ipaddr"] == nil or elisten_json["ipaddr"] == "" then
                elisten_json["ipaddr"] = old_json.list[num].ipremote
            end
            if elisten_json["auth_src"] == nil or elisten_json["auth_src"] == "" then
                elisten_json["auth_src"] = old_json.list[num].auth_src
            end
            table.remove(old_json.list,num)
            flag = 1 
            break
        elseif (old_json.list[num].macremote == new_json.macremote) then
            mac_new_session = 1
        end
        num = num + 1
    end
    
    local flow_name = flow_name_get(elisten_json["name"])
    if flow_name ~= nil and flow_name ~= "" then
        elisten_json["flow_name"] = flow_name
    end
    file_write_a(path..flowctrl, cjson.encode(elisten_json).."\n")
    if (flag == 0) then
        module_debug.lua_debug(module_debug.INFO, "not found , macremote:%s, pppd_pid:%s, mac_new_session:%d\n", new_json.macremote, new_json.pppd_pid, mac_new_session)
        if (mac_new_session == 1) then
            return -2
        end
        return -1
    end
    file_write(conf_file, cjson.encode(old_json))
    
    if new_json.localip == nil then
        new_json.localip = uci:get("pppoeserver_global", "global", "localip")
    end
    if new_json.localip == nil then
        return
    end
    if cmd_iproute == nil then
        cmd_iproute = string.format([[ip route del %s dev %s  proto kernel  scope link  src %s]], new_json.ipremote, new_json.ifname, new_json.localip)
    else
        cmd_iproute = string.format([[%s;ip route del %s dev %s  proto kernel  scope link  src %s]], cmd_iproute, new_json.ipremote, new_json.ifname, new_json.localip)
    end
    
	module_debug.lua_debug(module_debug.INFO, "****************port_down end\n")
    return
end

function check_port()
    local old_data = file_read(conf_file)
    if (old_data == nil) then
        return
    end
    local old_json = cjson.decode(old_data)
    local num = table.maxn(old_json.list) 
    while ( 0 < num )
    do
		file = io.open("/proc/"..old_json.list[num].pppd_pid, "r")
        if (file == nil) 
        then
            module_debug.lua_debug(module_debug.INFO, "pid:%s not exist\n", old_json.list[num].pppd_pid)
            table.remove(old_json.list,num)
        else
            file:close()
        end
        num = num - 1
    end
    old_json.count = string.format([[%s]], table.maxn(old_json.list))
    file_write(conf_file, cjson.encode(old_json))
    if cmd_iproute ~= nil then
        cmd_iproute = string.format([[%s;ubus send direct_route]], cmd_iproute)
        module_debug.lua_debug(module_debug.INFO, "cmd_iproute:%s\n", cmd_iproute)
        os.execute(cmd_iproute)
    end
end

function get_maxnum()
    local sd_data = file_read(sd_device)
    local sd_json = cjson.decode(sd_data)

    local maxnum = tonumber(sd_json.gateway.pppoe_server_maxnum)

    return maxnum
end

function get_usernum()
    local user_data = file_read(conf_file)
    if (user_data == nil) then
        return 0
    end
    local user_json = cjson.decode(user_data)
    
    local user_num = tonumber(user_json.count)

    return user_num
end

local function LoadCSV(filePath)
    local file = assert(io.open(filePath, 'r'))
    local content = string.gsub(file:read("*all"), "\r\n", "\n")
    file:close()
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [LoadCSV] config is nil")
        return
    end
    -- Read Word One By One   
    local c = content -- content
    local p = 0 -- content check pos
    local w = "" -- content check word
    local w_next = "" -- content check word(next one)
    local x = 1 -- content table x
    local y = 1 -- content table y
    
    local opt = {} -- output table
    opt[y] = {}
    opt[y][x] = ""
     
    local in_quote = false -- quote mode
     
    while true do
    p = p + 1
    w = string.sub(c,p ,p )
    w_next = string.sub(c,p+1,p+1)
        if w == ',' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                x = x + 1
                opt[y][x] = ""
            end
        elseif w == '"' then
            if in_quote then
                if w_next == '"' then
                    opt[y][x] = opt[y][x]..w
                    p = p + 1
                else
                    in_quote = false
                end
            else
                in_quote = true
            end
        elseif w == '\n' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                y = y + 1
                x = 1
                opt[y] = {}
                opt[y][x] = ""
            end
        elseif w == "" or w == nil then
            opt[y][x] = nil
            break
        else
            opt[y][x] = opt[y][x]..w
        end
    end

    return opt
end

local function order_relation_get()
    local user_info_list = {}
    local count = 0
    local csvData = LoadCSV(order_relation)
    if (csvData == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information format error")
        return nil
    end
    for k,v in pairs(csvData) do
        if (k > 1) then
            local account_name
            count = count + 1
            for k2, v2 in pairs(v) do
                if (k2 == 1) then
                    account_name = v2
                    if not user_info_list[account_name] then
                        user_info_list[account_name] = {}
                    end              
                elseif (k2 == 2) then
                    user_info_list[account_name]["type"] = v2  
                elseif (k2 == 3) then
                    user_info_list[account_name]["user_group"] = v2    
                elseif (k2 == 4) then
                    user_info_list[account_name]["group_uuid"] = v2  
                elseif (k2 == 5) then
                    user_info_list[account_name]["validity"] = v2
                elseif (k2 == 6) then
                    user_info_list[account_name]["dealline"] = v2
                end
            end
        end
    end
    -- module_debug.lua_debug(module_debug.INFO, "user_info_list:%s;", cjson.encode(user_info_list));
    return user_info_list
end

local function to_timestamp(date_str)
    local year, month, day = date_str:match("(%d+)-(%d+)-(%d+)")
    local time_table = {
        year = tonumber(year),
        month = tonumber(month),
        day = tonumber(day),
        hour = 0,
        min = 0,
        sec = 0
    }

    return os.time(time_table)
end

local function decode_URI(s)
    s = string.gsub(s, '%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end)
    return s
end

local function encode_URI(s)
    s = string.gsub(s, "([^%w%.%- ])", function(c) return string.format("%%%02X", string.byte(c)) end)
    return string.gsub(s, " ", "+")
end

local function get_confirm_time_by_uci(user_type, username)
    local result = {}
    result["confirm_time"] = "0"
    result["expire_time"] = "0"
    result["username"] = username
    result["user_type"] = user_type
    result["result"] = "false"
    uci:foreach("account_mgr", user_type, function(t)
        local name_section = t[".name"]
        local u_name = uci:get("account_mgr", name_section, "username")
        if (username == u_name) then
            result["confirm_time"] = uci:get("account_mgr", name_section, "confirm_time")
            result["expire_time"] = uci:get("account_mgr", name_section, "expire_time")
            if result["confirm_time"] == nil then
                result["confirm_time"] = "0"
            end
            if result["expire_time"] == nil then
                result["expire_time"] = "0"
            end
            result["result"] = "true"
            return false
        end
    end
    )
    return result
end

local function get_charge_user_status_with_retry(peername, user_type, max_retry)
    local retry_count = 0
    local res = nil
    local res_tab = nil
    
    if max_retry == nil then
        max_retry = 3
    end
    
    while retry_count < max_retry do
        local cmd = string.format(get_charge_usr_status, peername, user_type)
        module_debug.lua_debug(module_debug.DEBUG, "INFO:cmd : %s, retry_count: %d", cmd, retry_count)
        
        local t = io.popen(cmd)
        res = t:read("*all")
        t:close()
        
        if res ~= nil and res ~= "" then
            local success, result = pcall(cjson.decode, res)
            if success then
                res_tab = result
                module_debug.lua_debug(module_debug.DEBUG, "INFO:res_tab : %s", res)
                break
            else
                module_debug.lua_debug(module_debug.ERROR, "ERROR: Failed to decode JSON, retry_count: %d", retry_count)
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: res is nil or empty, retry_count: %d", retry_count)
        end
        
        retry_count = retry_count + 1
        if retry_count < max_retry then
            tool.sleep(1)
        end
    end
    
    res_tab = res_tab or get_confirm_time_by_uci(user_type, peername)
    return res_tab
end

local function get_user_status_info(param_tab, user_type, expire_time, expire_time_update, check_time)
    local has_active = "0"
    local res_tab = get_charge_user_status_with_retry(param_tab["peername"], user_type, 3)
    
    if res_tab ~= nil and res_tab["result"] == "true" and res_tab["username"] == param_tab["peername"] then
        has_active = "1"
        if (res_tab["confirm_time"] ~= nil and res_tab["confirm_time"] ~= "") then
            check_time = res_tab["confirm_time"]
        end
        if user_type == "charge" then
            if (res_tab["expire_time"] ~= nil and res_tab["expire_time"] ~= "" and expire_time_update == false) then
                expire_time = res_tab["expire_time"]
            end
        end
    end
    
    if tonumber(check_time) == 0 then
        check_time = os.time()
    end
    
    return has_active, check_time, expire_time
end
local function pppoe_insert_param(param_tab)
    local cmd = ""
    local user_info_list = nil
    local expire_time = ""
    local check_time = "0"
    local user_type = ""
    local has_active = "0"
    local group_name = ""
    local group_uuid = ""
    local flow_name = ""
    local flow_name_map
    local expire_time_update = false
    local auth_src = "local"

    if param_tab["auth_src"] ~= nil and param_tab["auth_src"] ~= "" then
        auth_src = param_tab["auth_src"]
    end
    user_info_list = order_relation_get()
    if (user_info_list == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: user_info_list is nil")
        return -1
    end

    for k,v in pairs(user_info_list) do
        if (k == param_tab["peername"]) then
            -- charge账号使用expire_time即dealline,validity是套餐有效期,pppoe账号使用dealline,expire_time可能为""，此时需要计算过期时间
            user_type = v["type"]
            if (user_type == "charge") then
                if (v["dealline"] ~= nil and v["dealline"] ~= "") then
                    expire_time = v["dealline"]
                    expire_time_update = true
                else
                    if (v["validity"] ~= nil and v["validity"] ~= "") then
                        if (v["validity"] == "0") then
                            expire_time = "0"
                        else
                            expire_time = os.time() + v["validity"] * ONE_MINUTE_BY_SEC
                        end
                    end
                end
                if (v["user_group"] == nil or v["user_group"] == "") then
                    group_name = "Default_PPPoE_Group"
                else
                    group_name = v["user_group"]
                    group_uuid = v["group_uuid"]
                end
            elseif (user_type == "pppoe") then
                if (v["dealline"] ~= nil and v["dealline"] ~= "") then
                    expire_time = to_timestamp(v["dealline"])
                else
                    expire_time = "0"
                end
                if (v["user_group"] == nil or v["user_group"] == "") then
                    group_name = "Default_PPPoE_Group"
                else
                    group_name = "pppoe_" .. v["user_group"]
                end
                flow_name = flow_name_get(param_tab["peername"])
            end
            break
        end
    end

    if auth_src == "local" then
        has_active, check_time, expire_time = get_user_status_info(param_tab, user_type, expire_time, expire_time_update, check_time)
    else
        module_debug.lua_debug(module_debug.DEBUG, "pppoe_radius type")
        user_type = "pppoe"
        check_time = "0"
        expire_time = "0"
        group_name = "Default_PPPoE_Group"
    end

    param_tab["check_time"]= tostring(check_time)
    param_tab["expire_time"] = tostring(expire_time)
    param_tab["user_type"] = user_type
    param_tab["group_name"] = group_name
    param_tab["group_uuid"] = group_uuid
    param_tab["has_active"] = has_active
    param_tab["auth_src"] = auth_src
    elisten_json["auth_src"] = auth_src
    if flow_name ~= nil and flow_name ~= "" then
        param_tab["flow_name"] = flow_name
        elisten_json["flow_name"] = param_tab["flow_name"]
    end
    return 0
end
-- 127.0.0.1:xx/pppoe_online?username=xx&ip=xxx&mac=xxx&check_time=xx&expire_time=xxx&type=xxx
local function ip_up_proc(param_tab)
    local cmd = ""

    if (param_tab["peername"] == nil or param_tab["peername"] == "") then
        module_debug.lua_debug(module_debug.ERROR, "get username is nil")
        return
    end
    cmd = string.format("curl --connect-timeout 2 'http://127.0.0.1:2060/pppoe_online?username=%s&ip=%s&mac=%s&check_time=%s&expire_time=%s&type=%s&group_name=%s&group_uuid=%s' -i", 
        encode_URI(param_tab["peername"]), param_tab["ipremote"], param_tab["macremote"], param_tab["check_time"], param_tab["expire_time"], param_tab["user_type"], encode_URI(param_tab["group_name"]), param_tab["group_uuid"])
    module_debug.lua_debug(module_debug.DEBUG, "INFO:cmd : %s", cmd)
    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close()
    local target = "HTTP/1.1 200 OK"
    if (string.find(res, target) == nil) then
        module_debug.lua_debug(module_debug.ERROR, "curl http://127.0.0.1:2060/pppoe_online err: %s", res)
        curl_flag = false
    end

    -- 通告云端获取pppoe拨号过期时间，只有首次激活时才上报, 延迟3s后再调用 
    if (param_tab.has_active == "0" and param_tab.user_type == "charge") then
        tool.sleep(3)
        os.execute(inform_cloud_charge_active_cmd)
        module_debug.lua_debug(module_debug.INFO, "INFO:cmd : %s", inform_cloud_charge_active_cmd)
    end
    module_debug.lua_debug(module_debug.DEBUG, "end ip_up_proc")
end

--  127.0.0.1:xx/pppoe_offline?ip=xxx&mac=xxx
local function auth_down_proc(param_tab)
    local cmd = ""

    if (param_tab.src == nil or param_tab.src == "conf" or param_tab.src == "ppp_radius") then
        cmd = string.format("curl --connect-timeout 2 'http://127.0.0.1:2060/pppoe_offline?ip=%s&mac=%s' -i", 
        param_tab["ipremote"], param_tab["macremote"])
        module_debug.lua_debug(module_debug.INFO, "INFO:cmd : %s", cmd)
        local t = io.popen(cmd)
        local res = t:read("*all")
        t:close()
        local target = "HTTP/1.1 200 OK"
        if (string.find(res, target) == nil) then
            module_debug.lua_debug(module_debug.ERROR, "curl http://127.0.0.1:2060/pppoe_offline err: %s", res)
            curl_flag = false
        end
    end
end

function client_status(status_json, maxnum)
    local user_num
    local cmd
    local ret = 0
    
    --写数据到临时文件，为后续流控设置做准备
    if status_json.peername ~= nil then
        elisten_json["name"] = status_json.peername
    end
    if status_json.ipremote ~= nil then
        elisten_json["ipaddr"] = status_json.ipremote
    end
    elisten_json["status"] = status_json.status
    module_debug.lua_debug(module_debug.DEBUG, "status:%s\n", elisten_json["status"])
    
    if (status_json.status == "up" ) then
        user_num = get_usernum() 
        module_debug.lua_debug(module_debug.DEBUG, "user_num:%d maxnum:%d\n", user_num, maxnum)
        --如果在线用户数达到最大限制数，则踢掉新拨号上来的设备
        if (user_num < maxnum) then
            if (spt_expire_remind == true) then
                ret = pppoe_insert_param(status_json)
            end
            ret = port_up(status_json, ret)
            if (spt_expire_remind == true and ret ~= -1) then
                ip_up_proc(status_json)
            end
        else
            cmd = string.format([[kill -9 %s]], status_json.pppd_pid)
            module_debug.lua_debug(module_debug.DEBUG, "cmd:%s\n", cmd)
            os.execute(cmd)
            -- 沒有上线成功不需要通报下线 
            -- if (spt_expire_remind== true) then
            --     cmd = string.format([[curl --connect-timeout 2 'http://127.0.0.1:2060/pppoe_offline?ip=%s&mac=%s' 2>/dev/null > /dev/null &]], status_json["ipremote"], status_json["macremote"])
            --     module_debug.lua_debug(module_debug.INFO, "cmd:%s\n", cmd)
            --     os.execute(cmd)
            -- end
        end
    else
        local down_ret = port_down(status_json)
        if (spt_expire_remind == true and down_ret ~= -2) then
            auth_down_proc(status_json)
        end
    end
end

-- 原子写入函数
local function atomic_copy(src, dst)
    local tmp = dst .. ".tmp." .. os.time() .. "." .. math.random(10000)
    
    -- 读取源文件
    local src_file = io.open(src, "r")
    if not src_file then
        return false
    end
    local content = src_file:read("*all")
    src_file:close()
    
    -- 写入临时文件
    local tmp_file = io.open(tmp, "w")
    if not tmp_file then
        return false
    end
    tmp_file:write(content)
    tmp_file:close()
    
    -- 原子重命名
    os.rename(tmp, dst)
    return true
end

local function func_for_debug(file)
    -- 复制文件到/tmp/guest_auth/ppp/目录
    local guest_auth_path = "/tmp/guest_auth/ppp/"
    local guest_auth_file = guest_auth_path..file
    os.execute("mkdir -p "..guest_auth_path)
    
    -- 如果目标文件已存在，追加内容；否则复制文件
    local src_file = io.open(path..file, "r")
    if src_file ~= nil then
        local content = src_file:read("*all")
        src_file:close()
        
        local dst_file = io.open(guest_auth_file, "a+")
        if dst_file ~= nil then
            dst_file:write(content)
            dst_file:close()
        end
    end
end
---------主函数--------

function status_file_load()
    local status_json
    local fp
    local mv_file
    
    --复制在线用户数据到临时文件
    os.execute("cp "..user_file.." "..conf_file);
    
    check_port()
    local maxnum = get_maxnum()
    
    for file in lfs.dir(path) do
        if (string.find(file, "ppp") ~= nil) then
            os.rename(path..file, path_mv..file);
            fp = io.open(path_mv..file)
            for line in fp:lines() do
                module_debug.lua_debug(module_debug.INFO, "line:%s", line)
                status_json = cjson.decode(line)
                client_status(status_json, maxnum)
                atomic_copy(conf_file, user_file)
            end
        end
        os.remove(path_mv..file);
    end
    
    check_port()
    
    --临时文件数据替换成在线用户数据
    os.rename(conf_file, user_file);
    
    --执行elisten命令
    os.execute("ubus -t 3 send \"pppoe_server_flowctrl\" &");
    if (curl_flag == false) then
        module_debug.lua_debug(module_debug.INFO, "pppoe_user_reload")
        os.execute("ubus -t 3 send \"pppoe_user_reload\"");
    end
end

function instance_check()
    local t = io.popen("ps -wf | grep -v grep|grep -v sh|grep -c pppoeserver_port_status.lua")
    local res = t:read("*all")
    t:close()
    local num = string.match(res, "%d")
    if (tonumber(num) > 1) then 
        os.execute("ubus -t 3 send \"pppoe_server_status\"");
        module_debug.lua_debug(module_debug.ERROR, "There is instance process running")
        os.exit()
    end
end


function main()
    module_debug.lua_debug(module_debug.DEBUG, "Start pppoeserver_port_status");
    debug_init()
    instance_check()
    spt_expire_remind = is_spt_expire_remind(spt_expire_remind_cmd)
    status_file_load()
    module_debug.lua_debug(module_debug.DEBUG, "End pppoeserver_port_status");
    print("{\"code\":\"0\", \"msg\":\"Success!\"}") 
end
xpcall(main, traceback)