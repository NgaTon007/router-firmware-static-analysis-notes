#!/usr/bin/lua

require "public_module"
local lib_debug = require "utils.debug"
--local pppoe = require "luci.model.pppoe"
cjson = require "cjson"
local uci = require "uci"
local masklen = require "libc2lua"
local uci_r = uci.cursor()


lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoe-server.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "pppoeserver_stop start\n")

local iptables_path= "/tmp/iptables.rules/pppoe-server"
local userinfo_path = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local exceptip_path = "/etc/config/pppoeserver_exceptip"
local ippool_path = "/etc/sd_config/single/ippool.json"

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end


function pppoeserver_iptables_rules_delete()
	local state = uci_r:get("pppoeserver_global", "global", "state")
	local state_force = uci_r:get("pppoeserver_global", "global", "force_state")
    local ippool_name
    uci_r:foreach("pppoeserver_user", "pppoeserver_user",
			function(section)
				ippool_name = section["ippool_name"]
			end
		)
    if (ippool_name == nil)
    then
        ippool_name = "pppoe_pool"
    end
    --local ipaddr = uci_r:get("network", "lan", "ipaddr")
    local ipaddr = uci_r:get("pppoeserver_global", "global", "localip")
    lib_debug.lua_debug(lib_debug.DEBUG, "ipaddr:%s state:%s force_dtate:%s\n", ipaddr, state, state_force)
    
    local ippool_json = file_read(ippool_path)
    local ippool_data = cjson.decode(ippool_json)
    local length = table.maxn(ippool_data.list)
    local num = 1
    local rule
    local first_addr
    local end_addr
    local netmask
    
    while ( num < length + 1 )
    do
		if ((ippool_data.list[num].ippool_name == ippool_name))
        then
            rule = ippool_data.list[num].rule_name
            first_addr = ippool_data.list[num].first_addr
            end_addr = ippool_data.list[num].end_addr
            netmask = ippool_data.list[num].netmask
            --print(rule)
            --print(first_addr)
            --print(end_addr)
            --print(netmask)
            break
            
        end
        num = num + 1
    end
    
    local monitor_port = uci_r:get("pppoeserver_global", "global", "monitor_port")
    if monitor_port == nil or monitor_port == "233" then
        monitor_port = "br-lan"
    else
        monitor_port = "br-lan_"..monitor_port
    end

    --print("pppoeserver_iptables_rules_delete\n")
	if state == "1" and state_force == "1" then
        if cmd == nil then
            cmd = string.format([[iptables -w -D FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], monitor_port, rule)
		else
            cmd = string.format([[%s;iptables -w -D FORWARD_sd_chain -i %s -m set ! --match-set %s src -j DROP 2>/dev/null]], cmd, monitor_port, rule)
		end

		if cmd == nil then
            cmd = string.format([[iptables -w -D FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], monitor_port, rule)
		else
            cmd = string.format([[%s;iptables -w -D FORWARD_sd_chain -o %s -m set ! --match-set %s dst -j DROP 2>/dev/null]], cmd, monitor_port, rule)
		end

        local file = io.open(exceptip_path,"r")
        if file ~= nil then 
            if cmd ~= nil then
                cmd = string.format([[%s;iptables -w -D FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -D FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN 2>/dev/null;ipset destroy  pppoeserver_user_exceptip 2>/dev/null]], cmd)
            else
                cmd = string.format([[iptables -w -D FORWARD_sd_chain -m set  --match-set pppoeserver_user_exceptip src -j RETURN 2>/dev/null;iptables -w -D FORWARD_sd_chain  -m set  --match-set pppoeserver_user_exceptip dst -j RETURN; 2>/dev/null;ipset destroy  pppoeserver_user_exceptip 2>/dev/null]])
            end
        end
	end
    
    local del_netmask_len = string.len(netmask)
    --将子网掩码字符串传给lua扩展库，并通过netmasklen函数获取子网掩码位长
    local netmasklen = masklen.netmasklen(netmask)
    
    --iptables -t nat -A POSTROUTING -s 192.168.111.0/24 -j SNAT --to-source 172.30.111.50  
    if cmd == nil then
        cmd = string.format([[iptables -w -t nat -D POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s  2>/dev/null]], ipaddr)
    else
        cmd = string.format([[%s;iptables -w -t nat -D POSTROUTING -m set --match-set ippool_rule_pppoe_pool src -j SNAT --to-source %s  2>/dev/null]], cmd, ipaddr)
    end
    
	if cmd ~= nil then
		--print(cmd)
        lib_debug.lua_debug(lib_debug.DEBUG, "cmd:%s\n", cmd)
        file_write(iptables_path, cmd)
		os.execute(cmd)
	end
 end

function pppoeserver_config_delete()
    local fp = io.open(userinfo_path, "r")
    if (fp ~= nil) then
        fp:close()
        os.execute("rm "..userinfo_path);
    end
end

function pppoeserver_stop()
	pppoeserver_iptables_rules_delete()
    pppoeserver_config_delete()
end

pppoeserver_stop()
