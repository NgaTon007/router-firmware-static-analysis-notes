#!/usr/bin/lua
require "public_module"
local lib_debug = require "utils.debug"
--local pppoe = require "luci.model.pppoe"
cjson = require "cjson"
local lfs = require "lfs"

local flow_file = "flowctrl"
local user_ip = "/tmp/pppoe-server/user_ip.txt"
local user_file = "/etc/sd_config/single/pppoeserver_user.json"
local path = "/tmp/pppoe-server/pppoeserver_status/"
local path_mv = "/tmp/pppoe-server/pppoeserver_status_mv/"
local cmd_iproute

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_flowctrl.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

function flowctrl_pppoe(flow_json, flow_name, status)
    --添加fc_cmd.elf pppoe用户
    --加个判断是否启用了流控模块
    local t=io.popen('ps | grep flow_ctrl.elf | grep -v grep' )
    local line = t:read("*all")
    local len=string.len(line)

    if (len == 0) then 
       t:close()
       lib_debug.lua_debug(lib_debug.DEBUG, "no flow_ctrl")  
       return
    end
    t:close()

    if (status == "up") then
        os.execute("/usr/sbin/fc_cmd.elf -A -g "..flow_name.." -i "..flow_json.ipaddr)
        lib_debug.lua_debug(lib_debug.DEBUG, "flow_ctrl -A %s  %s", flow_name, flow_json.ipaddr)  
    else
        os.execute("/usr/sbin/fc_cmd.elf -D -g "..flow_name.." -i "..flow_json.ipaddr)
        lib_debug.lua_debug(lib_debug.DEBUG, "flow_ctrl -D %s  %s", flow_name, flow_json.ipaddr)
    end
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

function file_write_a(conf_file, data)
    local file = io.open(conf_file,"a+")
    file:write(data)
    file:close()
end

function flow_up(flow_json, flow_name)
    local result = ""
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_up reuslt:%s\n", result)
    result = os.execute("ipset add "..flow_name.." "..flow_json.ipaddr)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_up ipset add :%s %s  result:%s ", flow_name, flow_json.ipaddr, result)

    file_write_a(user_ip, flow_json.ipaddr.."\n")
    --flowctrl策略中添加pppoe用户
    flowctrl_pppoe(flow_json, flow_name, "up")
end

function flow_down(flow_json, flow_name)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_down \n")

    local result = ""
    local str = ""
    local fp = io.open(user_ip)
    for line in fp:lines() do
        lib_debug.lua_debug(lib_debug.DEBUG, "line:%s flow_json.ipaddr:%s\n", line, flow_json.ipaddr)
        if (line ~= flow_json.ipaddr) then
            str = line.."\n"..str
        end
    end
    file_write(user_ip, str)

    lib_debug.lua_debug(lib_debug.DEBUG, "flow_name:%s flow_json.ipaddr:%s\n", flow_name, flow_json.ipaddr)
    result = os.execute("ipset del "..flow_name.." "..flow_json.ipaddr)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_down ipset del :%s %s  result:%s", flow_name, flow_json.ipaddr, result)

    --flowctrl策略中删除pppoe用户
    flowctrl_pppoe(flow_json, flow_name, "down")
end

function flow_ctrl(flow_json)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_ctrl\n")
    if (flow_json.auth_src ~= nil and flow_json.auth_src == "radius") then
        lib_debug.lua_debug(lib_debug.DEBUG, "flow_json.auth_src is radius\n")
        return
    end
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_json.name:%s\n", flow_json.name)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_json.ipaddr:%s\n", flow_json.ipaddr)
    lib_debug.lua_debug(lib_debug.DEBUG, "flow_json.status:%s\n", flow_json.status)

    --删除账号时 会携带flow_name参数
    if (flow_json.status == "down" and flow_json.flow_name ~= nil) then
        flow_down(flow_json, flow_json.flow_name)
        return
    end

    local user_data = file_read(user_file)
    local user_json = cjson.decode(user_data)
    
    for i, v in ipairs(user_json.list) do
        repeat
        lib_debug.lua_debug(lib_debug.DEBUG, "v.name:%s\n", v.name)
        if (v.name ~= flow_json.name) then
            break
        end
        lib_debug.lua_debug(lib_debug.DEBUG, "v.flow_enable:%s flow_json.status :%s\n", v.flow_enable, flow_json.status )
        
        if (v.flow_enable == "1") then
            if (flow_json.status == "up") then
                flow_up(flow_json, v.flow_name)
            else
                flow_down(flow_json, v.flow_name)
            end
        end
        return
        until true
    end
end

---------主函数--------

function status_file_load()
    local flow_json
    local fp
    local mv_file

    os.rename(path..flow_file, path_mv..flow_file);
    fp = io.open(path_mv..flow_file)
    if (fp == nil) then
        lib_debug.lua_debug(lib_debug.DEBUG, "return\n")
        return
    end
    for line in fp:lines() do
        flow_json = cjson.decode(line)
        lib_debug.lua_debug(lib_debug.DEBUG, "/tmp/pppoe-server/pppoeserver_status/flowctrl line:%s", line)
        flow_ctrl(flow_json)
    end
    os.remove(path_mv..flow_file);
    
    os.execute("/usr/sbin/flow_start restart &");

end

status_file_load()
