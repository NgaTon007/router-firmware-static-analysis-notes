#!/usr/bin/lua
require "public_module"
--local pppoe = require "luci.model.pppoe"
cjson = require "cjson"
local lfs = require "lfs"

local user_file = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR = "/tmp/pppoe-server/debug/"
local cmd = "curl 127.0.0.1:2060/pppoeusr_reload -i"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

local function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "pppoe_user_reload.log", 200, module_debug.DEBUG, "1");
end

function main()
    local t = io.popen("curl 127.0.0.1:2060/pppoeusr_reload -i")
    local res = t:read("*all")
    t:close()
    local target = "HTTP/1.1 200 OK"
    if (string.find(res, target) == nil) then
        module_debug.lua_debug(module_debug.ERROR, "pppoe_user_reload.lua failed, res : %s", res)
        os.execute("ubus -t 3 send \"pppoe_user_reload\"");
    end
    module_debug.lua_debug(module_debug.INFO, "pppoe_user_reload.lua success")
end

function instance_check()
    local t = io.popen("ps -wf | grep -v grep|grep -v sh|grep -c pppoe_user_reload.lua")
    local res = t:read("*all")
    t:close()
    local num = string.match(res, "%d")
    if (tonumber(num) > 1) then 
        os.execute("ubus -t 3 send \"pppoe_user_reload\"");
        module_debug.lua_debug(module_debug.ERROR, "There is instance process running")
        os.exit()
    end
end

debug_init()
instance_check()
main()