--lua共享库
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("flowctrl.flowctrl_app", package.seeall)

local x = require("luci.model.uci").cursor()
local cjson = require "cjson"
local lib_app_idy = require "app_identify.app_idy_pub"
local ac_config = require "ac_config"
local dev_sta = require "dev_sta"
local dev_config = require "dev_config"
require "public_module"
local module_debug = require "utils.debug"
local FC_DSCP_JSON_CFG = "/etc/flowctrl/flowctrlMarkDscpConfig.json"
local CAPACITY_CONFIG_FILE = "/tmp/sd_device/sd_device.json"

local id_is_exist=0
local name_is_exist=0
local cfg_index
local old_section
del_section={}
udp_cnt=5
pppoe_cnt=1
udp_tag="user_def_policy"
pppoe_tag="pppoe_policy"
vpn_tag="vpn_policy"
rate_tag="-"
ip_tag=" "
max_rate_tag="10000000"
min_rate_tag="1"
pppoe_pri=1
default_tc_pri=4
vpn_init_id=200
udp_init_id=1
vip_def_up_rate="10000"
vip_def_down_rate="20000"
tr_system_type="system"
tr_week_type="week"
tr_date_type="date"
max_dscp = 63 --dscp 取值0-63
max_ip_pri = 7
default_udp_normal_pri = 158
default_udp_block_pri = 157
default_udp_key_pri = 156
default_udp_auth_pri = 155
default_udp_auth_id = 0
udp_auth_type = "auth"

local app_comparison_table = {
	["社交软件"] = "communication",
	["视频|音乐|直播"] = "video",
	["购物|旅行|生活"] = "shopping",
	["网络游戏"] = "games",
	["网络硬盘|云存储"] = "databank",
	["P2P软件"] = "p2p_software",
	["应用商店"] = "app_store",
	["金融软件"] = "financial",
	["新闻阅读"] = "news",
	["学习"] = "study",
	["支付"] = "payment",
	["自定义"] = "custom",
	["Communication"] = "communication_En",
	["Video"] = "video_En",
	["Shopping"] = "shopping_En",
	["Play"] = "games_En",
	["Databank"] = "databank_En",
	["P2PSoftware"] = "p2p_software_En",
	["AppStore"] = "app_store_En",
	["Payment"] = "payment_En",
	["Custom"] = "custom_En"
}

--获取时间管理配置
function get_tr_config(tr_name)
	local json_tr = ac_config.fetch("get","tmngt")
	--有两层对象，先解析一层data对象
	local data = cjson.decode(json_tr["data"])
	return data
end

local function get_tr_effect(tr_name)
    local cmd = "{\"tmngtName\":\"" .. tr_name .. "\"}"
	local json_tr = dev_sta.fetch("get","tmngt_status", cmd, 1)
    if (json_tr == nil) then
        return 0
    end

	if (json_tr["data"] == nil) then
		return 0
	end
	--有两层对象，先解析一层data对象
	local data = cjson.decode(json_tr["data"])
	if (data["count"] == 0) then
		return 0
	end

	local status = data["list"][1]["status"]
	if (status ~= nil and status == "ACTIVE") then
	    return 1
	else
	    return 0
	end
end

--获取接口组能力值
function get_intf_grp_capability()
    local config_table=public_module.read_file(CAPACITY_CONFIG_FILE)
    if (config_table == nil) then
        module_debug.lua_debug(module_debug.ERROR, "get intf group capability failed, config_table nil");
        return 0
    end

    if (config_table.eweb == nil) then
        module_debug.lua_debug(module_debug.ERROR, "eweb nil");
        return 0
    end

    if (config_table.eweb.intf_group == nil) then
        module_debug.lua_debug(module_debug.INFO, "intf_group nil");
        return 0
    end

    if (tonumber(config_table.eweb.intf_group) == 1) then
        module_debug.lua_debug(module_debug.INFO, "intf_group 1");
        return 1
    else
        module_debug.lua_debug(module_debug.INFO, "intf_group 0");
        return 0
    end
end

--检查intf接口是否合法
function check_intf(intf, intf_type, intf_uuid, intf_list, fc_wan_grp, intf_grp_cap)
    if (intf == nil) then
        module_debug.lua_debug(module_debug.ERROR, "policy have no intf");
        return false
    end

    if (intf_grp_cap == 1) then
        if (intf_list ~= nil and #intf_list > 0) then
            for _,mem in pairs(intf_list) do
                if (fc_wan_grp[mem] ~= nil) then
                    return true
                end
            end

            return false
        elseif (intf_type ~= nil and intf_type == "user") then
            if (intf_uuid == nil or #intf_uuid == 0) then
                module_debug.lua_debug(module_debug.ERROR, "policy intfGrpUuid is nil");
                return false
            end

            return true
        else
            if (intf == "br-allwan") then
                return true
            end

            intf_name = string.match(intf, "[^-]+%-(.+)") or intf
            if (fc_wan_grp[intf_name] ~= nil) then
                return true
            else
                return false
            end
        end

        return false
    end

    if (intf == "br-allwan") then
        return true
    end

    intf_name = string.match(intf, "[^-]+%-(.+)") or intf
    if (fc_wan_grp[intf_name] ~= nil) then
        return true
    else
        return false
    end

    return false
end

--时间管理--
function check_policy_tr(tr_group_name)
	--tr_group_name为nil 默认策略全时段生效
	if (tr_group_name == nil) then
		return 1
	end

	local ret = get_tr_effect(tr_group_name)

    return ret
end

--增加引用计数
function ref_time_config(tr_name)
    local cmd = "{\"moduleName\":\"flowctrl\", \"opt\":\"ref\", \"tmngtName\":\"" .. tr_name .. "\"}"
	dev_sta.fetch("set","tmngt_notify", cmd, 1)
end

--减少引用计数
function deref_time_config(tr_name)
    local cmd = "{\"moduleName\":\"flowctrl\", \"opt\":\"deref\", \"tmngtName\":\"" .. tr_name .. "\"}"
	dev_sta.fetch("set","tmngt_notify", cmd, 1)
end

--更新配置项, 未防止tmngt升降级导致的tmngt配置残留，tmngt使用add接口不一定能添加成功，一律使用update接口
function update_time_config(tr_name, time, tmngt_type, tr_type)
	local cmd
	if (time == nil) then
		return
	end

	if (tr_type == tr_week_type) then
    	cmd = "{\"list\":[{\"tmngtName\":\"" .. tr_name .. "\", \"type\":\"" .. tmngt_type .. "\", \"time\":" .. time ..", \"timeType\":\"" .. tr_week_type .. "\"}]}"
	elseif (tr_type == tr_date_type) then
		cmd = "{\"list\":[{\"tmngtName\":\"" .. tr_name .. "\", \"type\":\"" .. tmngt_type .. "\", \"time\":{}, \"timeRange\":" .. time .. ", \"timeType\":\"" .. tr_date_type .. "\"}]}"
	else
		return
	end
	-- print(cmd)
	ac_config.fetch("update","tmngt", cmd, 1)
end
---------------------------
function app_parse(applist)
	local app_list = {}
	if (#applist ~= 0) then
		for i = 1, #applist do
			local app_name = app_comparison_table[applist[i]]
			if (app_name) then
				local app_tab = x:get("app_identify", app_name, "app")
				for j = 1, #app_tab do
					table.insert(app_list, app_tab[j])
				end
			else
				table.insert(app_list, applist[i])
			end
		end
		return app_list
	end
end

function bubble_sorting(a)
    local id_interval
    for i = 1,#a - 1 do
        for j = 1,#a - i do
            if a[j] > a[j + 1] then
                local temp = a[j]
                a[j] = a[j + 1]
                a[j + 1] = temp
            end
        end
    end
end

local function check_name_is_exist(name, old_app_version)
	--添加的时候，名字不能已存在
	if (old_app_version == "2" or old_app_version == "4") then
		section_name = "Custom_Group"
	elseif (old_app_version == "3") then
		section_name = "Custom_Group_En"
	end

	x:foreach("app_identify", section_name, function(s)
		local section = s[".name"]
		if (x:get("app_identify", section, "name") == name) then
			name_is_exist = 1
			cfg_index = s[".index"]
			old_section = section
			return
		end
    end)
	return
end

local last_index=0
local function find_last_rule_index(app_version)
	if (app_version == "2" or app_version == "4") then
		section_name = "Custom_Group"
	elseif (app_version == "3") then
		section_name = "Custom_Group_En"
	end

	x:foreach("app_identify", section_name, function(s)
        if (string.sub(s[".name"],1,11)=="fc_applist_") then
			last_index = s[".index"]
        end
    end)
end

local function del_uci_config_by_group(app_group, del_app_version)
	if (del_app_version == "2" or del_app_version == "4") then
		section_name = "Custom_Group"
	elseif (del_app_version == "3") then
		section_name = "Custom_Group_En"
	end

	x:foreach("app_identify", section_name, function(s)
		if (x:get("app_identify", s[".name"], "name") == app_group) then
			x:delete("app_identify", s[".name"])
			return
		end
    end)
end

local function fill_new_section_and_rule(policy_id, input_param, app_version)
	local new_section="fc_applist_"..policy_id
	if (app_version == "2" or app_version == "4") then
		x:set("app_identify", new_section, "Custom_Group")
	elseif (app_version == "3") then
		x:set("app_identify", new_section, "Custom_Group_En")
	end

	if (policy_id=="key") then
		x:set("app_identify", new_section, "name", "fc_".."关键通道") --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	elseif (policy_id=="block") then
		x:set("app_identify", new_section, "name", "fc_".."抑制通道") --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	else
		x:set("app_identify", new_section, "name", "fc_"..policy_id) --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	end

	local app_list={}
	app_list=app_parse(input_param["appList"])
	x:set("app_identify", new_section, "app", app_list)
end

local function fill_new_section_and_rule_2(policy_id, app_table, app_version)
	local new_section="fc_applist_"..policy_id
	if (app_version == "2" or app_version == "4") then
		x:set("app_identify", new_section, "Custom_Group")
	elseif (app_version == "3") then
		x:set("app_identify", new_section, "Custom_Group_En")
	end

	if (policy_id=="key") then
		x:set("app_identify", new_section, "name", "fc_".."关键通道") --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	elseif (policy_id=="block") then
		x:set("app_identify", new_section, "name", "fc_".."抑制通道") --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	else
		x:set("app_identify", new_section, "name", "fc_"..policy_id) --应用控制只识别appGrp 为了和应用控制区分，因此得加fc
	end

	local app_list={}
	app_list=app_parse(app_table)
	x:set("app_identify", new_section, "app", app_list)
end

function update_app_config(jsonStr, policy_id, app_group, old_app_version, new_app_version)
	--先把旧得section删掉再新增section 由于新增的app_group_id不一定相同因此不需要移到原有配置位置
	--由于appGrp是自己生成的，只有调用get接口时才能get到，因此更新时不一定能get到appGrp,appGrp要自己获取
	local group_name = "fc_"..policy_id
	if (app_group ~= nil) then
		check_name_is_exist(group_name, old_app_version)
		if (name_is_exist ~= 0) then
			x:delete("app_identify", old_section)
		else
			print("{\"code\":\"-1\", \"msg\":\"app group has no exist\"}")
			return -1
		end
	end

	--老流控web不下发appList字段为nil 为了兼容老流控web
	if (jsonStr["list"][1]["appList"] == nil or #jsonStr["list"][1]["appList"]==0) then --为all的时候直接删除当前应用组
		x:commit("app_identify")
		return
	end

	uci_section = "fc_applist_"..policy_id
	fill_new_section_and_rule(policy_id, jsonStr["list"][1], new_app_version)
	if (cfg_index ~= nil) then
		x:reorder("flowctrl", uci_section, cfg_index)
	else
		find_last_rule_index(new_app_version) --先确定位置，再新增节点。
		if (last_index ~= 0) then
			x:reorder("app_identify", uci_section, last_index + 1)
		else
			x:reorder("app_identify", uci_section, 150) --150个配置项足够，能够确保在最后。
		end
	end
	x:commit("app_identify")
end

function del_config_app_group(app_group, del_app_version) --"appGrp":{}
    for i, value in pairs(app_group) do --当"appGrp":{},app_group为空时根本value 不会显示为nil直接就没有值
		if (value ~= "key" and value ~= "block" and value ~= nil) then
			del_uci_config_by_group(value, del_app_version)
			-- delete_json_config_rule(value, config_table)
		end
	end

	x:commit("app_identify")
end

function app_idy_del_config_app_group(app_sec_table, app_sec) --"appGrp":{}	
	if ((app_sec_table == nil or #app_sec_table <= 0) and app_sec == nil) then
		return
	end

	if (app_sec_table ~= nil and #app_sec_table > 0 and app_sec ~= nil) then
		print("{\"code\":\"-1\", \"msg\":\"[del] app_sec_table and app_sec is not nil\"}")
		return
	end

	if (app_sec_table ~= nil and #app_sec_table > 0) then
		del_section["appSec"] = app_sec_table
	end

	if (app_sec ~= nil) then
		del_section["appSec"]={}
		del_section["appSec"][1]=app_sec
	end

	lib_app_idy.app_idy_del_cfg_section(del_section["appSec"])
end

function app_idy_add_app_config_policy(app_list, policy_id, app_version)
	if (policy_id == nil or app_list == nil or app_version == nil) then
		print("{\"code\":\"-1\", \"msg\":\"policy_id is nil or app_list is nil or app_version is nil\"}")
		return
	end

    uci_section = "fc_applist_"..policy_id
	local option_name
	if (policy_id=="key") then
		option_name = "fc_".."关键通道"
	elseif (policy_id=="block") then
		option_name = "fc_".."抑制通道"
	else
		option_name = "fc_"..policy_id
	end

	if (type(app_version) ~= "string") then
		tostring(app_version)
	end

	lib_app_idy.app_idy_add_cfg_section(app_version, uci_section, option_name, app_list)
end

function app_idy_update_app_config(app_list, policy_id, app_group, new_app_version)
	--先把旧得section删掉再新增section 由于新增的app_group_id不一定相同因此不需要移到原有配置位置
	--由于appGrp是自己生成的，只有调用get接口时才能get到，因此更新时不一定能get到appGrp,appGrp要自己获取
	if (policy_id == nil or new_app_version == nil) then
		print("{\"code\":\"-1\", \"msg\":\"[add] policy_id is nil or new_app_version is nil\"}")
	end

	if (app_group ~= nil and string.find(app_group, "fc_") == nil) then
		return
	end

	local option_name = "fc_"..policy_id
	if (app_group ~= nil) then
		local section_name = "fc_applist_"..policy_id
		app_idy_del_config_app_group(nil, section_name)
	end

	--老流控web不下发appList字段为nil 为了兼容老流控web
	if (app_list == nil or #app_list<=0) then --为all的时候直接删除当前应用组
		return
	end

	app_idy_add_app_config_policy(app_list, policy_id, new_app_version)
end

function add_app_config_policy(jsonStr, policy_id, app_version)
    uci_section = "fc_applist_"..policy_id
	find_last_rule_index(app_version) --先确定位置，再新增节点。
	fill_new_section_and_rule(policy_id, jsonStr["list"][1], app_version)
	-- 移到到自定义策略最后的位置，后配先生效。(内部实现iptables是-I操作)
	-- 没有自定义策略则放最后，有则放最后那条自定义策略的位置+1。需要先找位置，避免直接放最后，导致配置文件很乱。
    if (last_index ~= 0) then
        x:reorder("app_identify", uci_section, last_index + 1)
    else
        x:reorder("app_identify", uci_section, 150) --150个配置项足够，能够确保在最后。
    end
	x:commit("app_identify")
end

function add_app_config_policy_2(app_table, policy_id, app_version)
    uci_section = "fc_applist_"..policy_id
	find_last_rule_index(app_version) --先确定位置，再新增节点。
	fill_new_section_and_rule_2(policy_id, app_table, app_version)
	-- 移到到自定义策略最后的位置，后配先生效。(内部实现iptables是-I操作)
	-- 没有自定义策略则放最后，有则放最后那条自定义策略的位置+1。需要先找位置，避免直接放最后，导致配置文件很乱。
    if (last_index ~= 0) then
        x:reorder("app_identify", uci_section, last_index + 1)
    else
        x:reorder("app_identify", uci_section, 150) --150个配置项足够，能够确保在最后。
    end
	x:commit("app_identify")
end

--计算policy_id,先排序，policyid不连续则填补空缺，连续则取最大值加1，如果不是从1开始则取1
function clc_policy_id(type)
	local new_id
    local id_interval
	local tab={}

    tab["exist_id"]={}
	x:foreach("flowctrl", type, function(s)
		local id = x:get("flowctrl",s[".name"],"policy_id")
		id=tonumber(id)
		index = #tab["exist_id"]+1
		tab["exist_id"][index]=id
	end)

    bubble_sorting(tab["exist_id"])

	--udf的policy_id从1开始,vpn从200开始
    if (type == vpn_tag) then
		if (tab["exist_id"][1] ~= vpn_init_id) then
			new_id=vpn_init_id
			return new_id
		end
	else
		if (tab["exist_id"][1] ~= udp_init_id) then
			new_id=udp_init_id
			return new_id
		end
	end

    for i = 1, #tab["exist_id"]-1 do
        id_interval=tab["exist_id"][i+1] - tab["exist_id"][i]
        if (id_interval > 1) then
            new_id = tab["exist_id"][i] + 1
            return new_id
        end
    end

    new_id=tab["exist_id"][#tab["exist_id"]]+1
    return new_id
end

--仅可选择传入单一名称或者传入名称table
function execute_app_count_operation(operation,name,name_table)
	if (name~=nil and name_table~=nil) then
		print("{\"code\":\"-1\", \"msg\":\"Too many parameters\"}")
		return
	elseif (name==nil and name_table==nil) then
		print("{\"code\":\"-1\", \"msg\":\"Missing parameters of 'name'\"}")
		return
	end

	local table={}
	local attr={}
	local cmd
	table["csm_group"]={}
	if (operation == "add") then
		attr["operation"]="add_count"
	else
		attr["operation"]="del_count"
	end

	attr["grpNameArr"]={}
	if (name~=nil) then
		attr["grpNameArr"][1]=string.gsub(name, "csm_", "")
	else
		attr["grpNameArr"]=name_table
	end
	table["csm_group"]=attr
	cmd="/usr/bin/lua /usr/sbin/web/app_idy_set_custom_group.lua ".."'"..cjson.encode(table).."'"
	os.execute(cmd)
end

--func fc_app_grp_check(jsonStr) 在flowctrl_app.lua中，app_grp参数检查，外部已经debug_init，此处直接使用module_debug
function fc_tmngt_grp_check(jsonStr)
	local tr_type = jsonStr["tr_type"]
	local tr_slots = jsonStr["tr_slots"]
	local tr_range = jsonStr["tr_range"]
	local tr_group_name = jsonStr["tr_group"]
    if (tr_type ~= nil and type(tr_type) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_type type[%s] is invalid", jsonStr["comment"], type(tr_type));
        return -1;
    end

    if (tr_slots ~= nil and type(tr_slots) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_slots type[%s] is invalid", jsonStr["comment"], type(tr_slots));
        return -1;
    end

    if (tr_range ~= nil and type(tr_range) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_range type[%s] is invalid", jsonStr["comment"], type(tr_range));
        return -1;
    end

    if (tr_group_name ~= nil and type(tr_group_name) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_group type[%s] is invalid", jsonStr["comment"], type(tr_group_name));
        return -1;
    end

	if (tr_type ~= nil and #tr_type ~= 0) then
		if (tr_group_name ~= nil and #tr_group_name > 0) then
			module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_group_name[%s] is error", jsonStr["comment"], tr_group_name);
            return -1;
		elseif (tr_type == tr_week_type) then
			if (tr_slots == nil or type(tr_slots) ~= "table" or next(tr_slots) == nil) then
				module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_slots is nil", jsonStr["comment"]);
				return -1;
			end
		elseif (tr_type == tr_date_type) then
			if (tr_range == nil or type(tr_range) ~= "table" or next(tr_range) == nil) then
				module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_range is nil", jsonStr["comment"]);
				return -1;
			end
		else
			--新增类型后 存在app+旧设备，新类型直接拒绝，否则不知道新类型tr_slots/tr_range哪些要写入UCI，升级后也不保证能按用户意愿实现
			module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_range is nil", jsonStr["comment"]);
			return -1;
		end
	end

    return 0
end

--接口组参数检查，外部已经debug_init，此处直接使用module_debug
function fc_intf_grp_check(jsonStr)
    local intf_type = jsonStr["intfGrpType"]
    local intf_grp = jsonStr["intfGrpUuid"]
    local intf_list = jsonStr["intfGrpList"]
    local whole_flag = jsonStr["wholeWan"]

	if (intf_type ~= nil and type(intf_type) ~= "string") then
		module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpType type[%s] is invalid", jsonStr["comment"], type(intf_type));
		return -1;
	end

	if (intf_grp ~= nil and type(intf_grp) ~= "string") then
		module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpUuid type[%s] is invalid", jsonStr["comment"], type(intf_grp));
		return -1;
	end

	if (intf_list ~= nil and type(intf_list) ~= "table") then
		module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpList type[%s] is invalid", jsonStr["comment"], type(intf_list));
		return -1;
	end

    local intf = jsonStr["intf"]

    --旧字段intf不允许为空且需要有默认值
    if (intf == nil or #intf == 0) then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] have no intf", jsonStr["comment"]);
        return -1;
    end

    --此处不加接口组能力值判定，防止国内430版本，云端和eweb端下发异常配置，导致后期升级支持接口组版本异常
    if (intf_type ~= nil and #intf_type > 0) then
        --当前国内版本不支持接口多选，但是代码已经更新，后期若支持接口组的版本，再新版本配置后回退旧版本，旧版本改接口配置，将会导致报错
        --因此设备端不做限制
        -- if (intf ~= "br-allwan") then
        --     module_debug.lua_debug(module_debug.ERROR, "policy[%s] intf[%s] is error when intfGrpType exist", jsonStr["comment"], intf);
        --     return -1;
        -- end

        if (whole_flag ~= nil and #whole_flag > 0 and whole_flag ~= "0") then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] wholeWan[%s] and intf_type[%s] conexist", jsonStr["comment"], tostring(whole_flag), intf_type);
            return -1;
        end

        if (intf_type == "user") then
            if (intf_grp == nil or #intf_grp == 0) then
                module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpUuid is nil", jsonStr["comment"]);
                return -1;
            end

            if (intf_list ~= nil and #intf_list > 0) then
                module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpList[%s] exist, ", jsonStr["comment"], cjson.encode(intf_list));
                return -1;
            end
        end

        if (intf_type == "auto") then
            if (intf_grp ~= nil and #intf_grp > 0) then
                module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpUuid[%s] exist, ", jsonStr["comment"], intf_grp);
                return -1;
            end

            if (intf_list == nil or #intf_list == 0) then
                module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpList is nil", jsonStr["comment"]);
                return -1;
            end
        end
    end

    if (intf_type == nil or #intf_type == 0) then
        if (intf_grp ~= nil and #intf_grp > 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpUuid[%s] exist, ", jsonStr["comment"], intf_grp);
            return -1;
        end

        if (intf_list ~= nil and #intf_list > 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] intfGrpList[%s] exist, ", jsonStr["comment"], cjson.encode(intf_list));
            return -1;
        end
    end

    return 0;
end

--删除用户组
function fc_user_group_del(jsonStr)
    local cmd = cjson.encode(jsonStr)
    module_debug.lua_debug(module_debug.INFO, "cmd[%s] ", cmd);
    dev_config.fetch("del","user_group", cmd, 1)
end

--调用update新增接口组，若接口组存在则更新接口组
function fc_intf_grp_update(uuid, mem)
    local intf_json = { list = {} }
    local intf_list = {}

    intf_list["type"] = "auto"
    intf_list["uuid"] = uuid
    intf_list["name"] = uuid
    intf_list["mem"] = mem
    table.insert(intf_json.list, intf_list)
    local cmd = cjson.encode(intf_json)
    -- module_debug.lua_debug(module_debug.INFO, "cmd[%s] ", cmd);
    dev_config.fetch("update","intfGroupMgr", cmd, 1)
end

function fc_intf_grp_del(jsonStr)
    local cmd = cjson.encode(jsonStr)
    -- module_debug.lua_debug(module_debug.INFO, "cmd[%s] ", cmd);
    dev_config.fetch("del","intfGroupMgr", cmd, 1)
end

function fc_intf_grp_add_list(uuid, mem, list)
    local intf_list = {}

    intf_list["type"] = "auto"
    intf_list["uuid"] = uuid
    intf_list["name"] = uuid
    intf_list["mem"] = mem
    table.insert(list, intf_list)
end

--批量新增，调用update接口
function fc_intf_grp_batch(jsonStr)
    local cmd = cjson.encode(jsonStr)
    -- module_debug.lua_debug(module_debug.INFO, "cmd[%s] ", cmd);
    dev_config.fetch("update","intfGroupMgr", cmd, 1)
end


-- 函数名：check_del_uuids
-- 输入参数：{uuid1, uuid2, uuid3}
-- 返回值：{uuid1:0, uuid2:1, uuid3:0} 0表示无引用，1表示被引用
function fc_check_intf_grp_uuids(uuid_list)
    local ret_table = {}

    if uuid_list == nil then
        return ret_table
    end
    
    -- 初始化返回值，Key为UUID，Value默认为0（无引用）
    for _, uuid in ipairs(uuid_list) do
        ret_table[uuid] = "0"
    end

    x:foreach("flowctrl", "user_def_policy", function(s)
        local name = s[".name"]
        local intf_type = x:get("flowctrl", name, "intf_type")
        if (intf_type ~= nil) then
            local intf_grp = x:get("flowctrl", name, "intf_group")
            if (intf_grp ~= nil and intf_grp ~= "" and ret_table[intf_grp] ~= nil) then
                ret_table[intf_grp] = "1"
            end
        end
    end)

    return ret_table
end

-- 函数名：check_del_uuids
-- 输入参数：{uuid1, uuid2, uuid3}
-- 返回值：{uuid1:0, uuid2:1, uuid3:0} 0表示无引用，1表示被引用
function fc_dscp_check_intf_grp_uuids(uuid_list)
    local ret_table = {}

    if uuid_list == nil then
        return ret_table
    end
    
    -- 初始化返回值，Key为UUID，Value默认为0（无引用）
    for _, uuid in ipairs(uuid_list) do
        ret_table[uuid] = "0"
    end

    --public_module.read_file公共函数，/usr/lib/lua/public_module.lua，文件不存在时返回{"list":[]}
    local config_table=public_module.read_file(FC_DSCP_JSON_CFG)
    if (config_table == nil) then
        return ret_table
    end

    if (config_table.list == nil) then
        return ret_table
    end

    for _, policy in ipairs(config_table.list) do
        local group = policy.intf_group
        -- 如果 intfGrpUuid 存在且在我们的 uuid 列表中
        if group and ret_table[group] ~= nil then
            ret_table[group] = "1"
        end
    end

    return ret_table
end
