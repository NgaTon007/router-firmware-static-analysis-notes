package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("policy_route.policy_route_pub", package.seeall)

local x = require("luci.model.uci").cursor()

-- 函数名：pbr_check_intf_grp_uuids
-- 输入参数：["uuid1", "uuid2", "uuid3"]
-- 返回值：{"uuid1":"0", "uuid2":"1", "uuid3":"0"}
--     其中key:"uuid1", value:"0"均为字符串类型
--     "0"表示无引用，"1"表示被引用
function pbr_check_intf_grp_uuids(uuid_list)
    local ret_table = {}

    if uuid_list == nil or #uuid_list == 0 then
        return ret_table
    end

    -- 初始化返回值，Key为UUID，Value默认为1（有引用）
    for _, uuid in ipairs(uuid_list) do
        if uuid ~= nil and uuid ~= "" then
            ret_table[uuid] = "1"
        end
    end

    local found_table = {}
    -- 需搜索 rule 和 new_rule 两种类型：子接口和接口组规则存储为 new_rule，兼容旧配置中使用 rule 的情况
    for _, sec_type in ipairs({"rule", "new_rule"}) do
    x:foreach("policy_route", sec_type, function(s)
        local name = s[".name"]
        local grp_id = x:get("policy_route", name, "intfGrpUuid")
        if grp_id ~= nil and grp_id ~= "" then
            found_table[grp_id] = true
        end
    end)
    end

    -- 如果在配置中未找到，则修改返回值为0（无引用）
    for _, uuid in ipairs(uuid_list) do
        if uuid ~= nil and uuid ~= "" and not found_table[uuid] then
            ret_table[uuid] = "0"
        end
    end

    return ret_table
end
