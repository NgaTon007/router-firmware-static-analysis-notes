#!/usr/bin/env lua
module("dev_module_id", package.seeall);
MODULE_LIST = {
    ["networkConnect"] = "0101",
    ["pppoe_learn"] = "0102",
    ["ipsec_vpn"] = "0103",
    ["l2tp_vpn"] = "0104",
    ["pptp_vpn"] = "0105",
    ["pppoe_server"] = "0106",
    ["radio_scan"] = "0140",
    ["wifi"] = "0141",
    ["wifi_channelscan"] = "0142",
    ["wifi_channelscore"] = "0143",
    ["wifi_deassociation"] = "0144",
    ["ssidMacFilter"] = "0145",
    ["ap_portal"] = "0146",
    ["wqos"] = "0147",
    ["wlanLimit"] = "0148",
    ["wqsta"] = "0149",
    ["mclimit"] = "0150",
    ["wireless"] = "0151",
    ["igmpCtl"] = "0152",
    ["wifi_grp"] = "0153",
    ["wirelessMacFilter"] = "0154",
    ["country_channel"] = "0155",
    ["self_check"] = "0180",
    ["dev_diag"] = "0181",
    ["alarm_mngt"] = "0182",
    ["alarm_map"] = "0183",
    ["cwmp_inform"] = "0190",
    ["cwmp_mode"] = "0191",
    ["cwmp_reg"] = "0192",
    ["cwmp_wake"] = "0193",
    ["embed_url"] = "0194",
    ["mqlink"] = "0195",
    ["mqlink_reg"] = "0196",
    ["mqlink_status"] = "0197",
    ["mqlink_cfgntf"] = "0198",
    ["mqlink_stantf"] = "0199",
    ["cloudDomainCfg"] = "0200",
    ["cloudCAUpload"] = "0201",
    ["cloud_serverlist"] = "0202",
    ["dev_mode"] = "0230",
    ["web_menu"] = "0231",
    ["loopback_detection"] = "0232",
    ["speedtest"] = "0233",
    ["local_dns_server"] = "0234",
    ["arp_static"] = "0235",
    ["hostName"] = "0236",
    ["msw_intf_get"] = "0301",
    ["dhcpRelay"] = "0302",
    ["dhcp_static"] = "0303",
    ["ttl_setting"] = "0304",
    ["local_safe"] = "0305",
    ["snmp"] = "0403",
    ["domainProxy"] = "0404",
    ["max"] = "9999"
}

function get_module_id(name)
    local module_id = "9999"
    if (name == nil) then
        name = "na"
    end
    if (MODULE_LIST[name] ~= nil) then
        module_id = MODULE_LIST[name];
    end
    return module_id;
end
