#!/usr/bin/env lua
-- Lua CJSON Parse For Parent
-- Enhua Chen
local json = require "cjson"
require "public_module"

status_recorde_module = {}
--主要是为了开机时候用的。不考虑opkg安装的时候同步
function  status_recorde_module.status_sync(pfile_src, pfile_dest, path_dest, key)
    local config_status_table
    local config_table
    local buff_status = {}
    if (pfile_src == nil or pfile_dest == nil or path_dest == nil or key == nil)
    then
        return -1
    end
    public_module.check_env(path_dest)
    dest_table = public_module.read_file(pfile_dest)
    src_table = public_module.read_file(pfile_src)
    --如果为空的情况下，需要从access_ctrl.json同步默认值。
    if (#(dest_table["list"]) == 0)
    then
        for i,v in pairs(src_table["list"]) do
            buff_status["status"] = "EXPIRE"
            buff_status[key] = v[key]
            table.insert(dest_table["list"], buff_status)
            buff_status = {}
        end
    end
    public_module.write_file(dest_table, pfile_dest)
    return 0
end

--增加新规则，使用默认的EXPIRE
function  status_recorde_module.status_add_default(pfile, path, key, key_val)
    local ret = 0
    local buff_status = {}
    local status_table
    if (pfile == nil or key_val == nil or path == nil or key == nil)
    then
        return -1
    end
    public_module.check_env(path)
    status_table = public_module.read_file(pfile)
    for i,v in pairs(status_table["list"]) do
        if (v[key] == key_val)
        then
            return 0
        end
    end
    buff_status["status"] = "EXPIRE"
    buff_status[key] = key_val
    table.insert(status_table["list"], buff_status)
    buff_status = nil
    public_module.write_file(status_table, pfile)
    return 0
end

--更新规则，使用默认的EXPIRE
function  status_recorde_module.status_reset_default(pfile, path, key, key_val)
    local status_table
    
    if (pfile == nil or key_val == nil or path == nil or key == nil)
    then
        return -1
    end
    public_module.check_env(path)
    status_table = public_module.read_file(pfile)
    for i,v in pairs(status_table["list"]) do
        if (v[key] == key_val)
        then
            v["status"] = "EXPIRE"
            break
        end
    end
    public_module.write_file(status_table, pfile)
    return 0
end

--删除规则
function  status_recorde_module.status_remove(pfile, path, key, key_val)
    local status_table
    local ret = 0 
    
    if (pfile == nil or key_val == nil or path == nil or key == nil)
    then
        return -1
    end
    public_module.check_env(path)
    status_table = public_module.read_file(pfile)
    for i,v in pairs(status_table["list"]) do
        if (v[key] == key_val)
        then
            table.remove(status_table["list"], i)
            ret = 1
            break
        end
    end
    if (ret == 1)
    then
        public_module.write_file(status_table, pfile)
    end
    return 0
end

--把时间管理的状态一次性同步
function  status_recorde_module.status_update(status_table, key, key_val, status)
    local ret = 0
    local buff_status = {}
    if (status_table == nil or key_val == nil or status == nil or key == nil)
    then
        return -1
    end

    for i,v in pairs(status_table["list"]) do
        if (v[key] == key_val)
        then
            v["status"] = status
            ret = 1
            break
        end
    end
    if (ret == 0)
    then
        --没有就要增加
        buff_status["status"] = status
        buff_status[key] = key_val
        table.insert(status_table["list"], buff_status)
    end
    return 0
end
--接受来自时间管理的状态同步,一比对出不一致，就直接返回
function  status_recorde_module.status_update_check(pfile, path, key, key_val, status)
    local status_table
    local ret = 0
    local buff_status = {}
    if (pfile == nil or key_val == nil or path == nil or status == nil or key == nil)
    then
        return -1
    end
    public_module.check_env(path)
    status_table = public_module.read_file(pfile)
    for i,v in pairs(status_table["list"]) do
        if (v[key] == key_val and v["status"] ~= status)
        then
            ret = 1
            break
        end
    end
    if (v == nil)
    then
        ret = 1
    end
    return ret
end

return status_recorde_module