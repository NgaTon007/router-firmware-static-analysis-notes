#! /usr/bin/lua
module("search", package.seeall)

local libdbg = require("utils.debug");
local dkjson = require("dkjson");
--[[
输入：
    level:
        1-----全部搜索
        2-----带范围搜索
        3-----精确搜索
    condition：
        level1-------'{"index":a, "size":b, "listname":c}'
        level2-------'{"index":a, "size":b, "listname":c, "condition":{"key":c, "value":d}}'  部分匹配,condition.value可以部分值
        level3-------'{"index":a, "size":b, "listname":c, "condition":[{"key":c, "value":d}]}'  完全匹配
    data:
        {"listname":[]}
输出：
    {"list":[], "total":a, "count":b, "code":c}
]]--

function search_result_format(index, size, slist)
    local ret = {}
    local _start = (index - 1) * size + 1
    local _end = index * size
    local dlist = {}
    local count = 0
    local total = 0
    while (_start <= _end) do
        if (slist[_start] ~= nil) then
            table.insert(dlist, slist[_start])
            count = count + 1
        end
        _start = _start + 1
    end
    
    total = (#slist);

    ret["list"] = dlist;
    ret["count"] = tostring(count)
    ret["total"] = tostring(total)
    
    return dkjson.encode(ret);
end

function search_match_wildcard(slist, key, partition, dlist)
    local i = 1
    local spartition = string.lower(partition)
    while (slist[i] ~= nil) do
        local value = string.lower(slist[i][key])
        local ret = string.find(value, spartition)
        if (ret ~= nil) then
            table.insert(dlist, slist[i])
        end
        i = i + 1
    end
end

function search_match(slist, tcondition, dlist)
    local i = 1
    local ckey
    local cvalue
    local value
    local ret = {}
    local j = 0
    
    while (slist[i] ~= nil) do
        j = 0
        for k,v in ipairs(tcondition["condition"]) do
            cvalue = string.lower(v.value)
            value = string.lower(slist[i][v.key])
            if (cvalue == value) then
                j = j + 1
            end
        end
        
        if (j == (#tcondition["condition"])) then
            ret["list"] = {};
            ret["count"] = tostring(1);
            ret["total"] = tostring(1);
            return dkjson.encode(ret);
        end
        i = i + 1
    end
    
    if (j == (#tcondition["condition"])) then
        ret["list"] = {};
        ret["count"] = tostring(1);
        ret["total"] = tostring(1);
    else
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
    end

    return dkjson.encode(ret);
end

function search_all(condition, data)
    local tdata
    local tcontidion
    local listname
    local ret = {}
    
    if (data == nil or string.len(data) == 0) then
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        return dkjson.encode(ret);
    end
    
    tdata = dkjson.decode(data)
    tcontidion = dkjson.decode(condition)
    listname = tcontidion.listname

    ret = search_result_format(tcontidion.index, tcontidion.size, tdata[listname]);
    return ret;
end

function search_part(condition, data)
    local tdata
    local tcontidion
    local listname
    local ret
    local xdata = {}
    
    if (data == nil or string.len(data) == 0) then
        ret = {};
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        return dkjson.encode(ret);
    end
    
    tdata = dkjson.decode(data)
    tcontidion = dkjson.decode(condition)
    listname = tcontidion.listname
    
    xdata[listname]={}
    search_match_wildcard(tdata[listname], tcontidion["condition"].key, tcontidion["condition"].value, xdata[listname]);
    ret = search_result_format(tcontidion.index, tcontidion.size, xdata[listname]);
    return ret;
end

function search_exact(condition, data)
    local tdata
    local tcontidion
    local listname
    local ret = {}
    local xdata = {}
    
    if (data == nil or string.len(data) == 0) then
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        return dkjson.encode(ret);
    end
    
    tdata = dkjson.decode(data)
    tcontidion = dkjson.decode(condition)
    listname = tcontidion.listname
    
    xdata[listname]={}
    ret = search_match(tdata[listname], tcontidion, xdata[listname]);
    return ret;
end

