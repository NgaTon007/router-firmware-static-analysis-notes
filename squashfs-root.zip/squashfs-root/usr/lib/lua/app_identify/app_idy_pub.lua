-- app_identify lua公共库
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("app_identify.app_idy_pub", package.seeall)
require("uci")
local x = uci.cursor()
local cjson = require "cjson"
local libc2lua = require("libc2lua")

app_comparison_table = {
    ["社交软件"] = "communication",
    ["视频|音乐|直播"] = "video",
    ["购物|旅行|生活"] = "shopping",
    ["网络游戏"] = "games",
    ["网络硬盘|云存储"] = "databank",
    ["P2P软件"] = "p2p_software",
    ["应用商店"] = "app_store",
    ["金融软件"] = "financial",
    ["新闻阅读"] = "news",
    ["网络服务"] = "service",
    ["商务软件"] = "business",
    ["在线支付"] = "payment",
    ["网络协议"] = "protocol",
    ["在线学习"] = "study",
    ["社交"] = "child_social",
    ["游戏"] = "child_game",
    ["影音"] = "child_video",
    ["支付"] = "child_payment",
    ["学习"] = "child_study",
    ["安装应用"] = "child_appstore",
    ["自定义"] = "custom",
    ["Communication"] = "communication_En",
    ["Entertainment"] = "video_En",
    ["Shopping"] = "shopping_En",
    ["Game"] = "games_En",
    ["Reading"] = "reading_En",
    ["Databank"] = "databank_En",
    ["P2PSoftware"] = "p2p_software_En",
    ["AppStore"] = "app_store_En",
    ["Finance"] = "payment_En",
    ["NetworkService"] = "service_En",
    ["NetworkProtocol"] = "protocol_En",
    ["Custom"] = "custom_En"
}

-- 自定义应用组引用计数接口，接口扩展成可传单个id和多个id_table
function custom_group_count_handle(operation, id, id_table)
    local cmd
    local attr = {}
    local table = {}

    if (id ~= nil and id_table ~= nil) then
        print("{\"code\":\"-1\", \"msg\":\"Too many parameters\"}")
        return
    elseif (id == nil and id_table == nil) then
        print("{\"code\":\"-1\", \"msg\":\"illegal parameters!\"}")
        return
    end

    table["csm_group"] = {}
    if (operation == "add") then
        attr["operation"] = "add_count"
    elseif (operation == "del") then
        attr["operation"] = "del_count"
    else
        print("{\"code\":\"-1\", \"msg\":\"illegal operation!\"}")
    end

    attr["grpNameArr"] = {}
    if (id ~= nil) then
        attr["grpNameArr"][1] = id
    else
        attr["grpNameArr"] = id_table
    end

    table["csm_group"] = attr
    if (libc2lua.lua_param_safety_check(cjson.encode(table)) ~= true) then
        print("{\"code\":\"-1\", \"msg\":\"param is unsafe!\"}")
        return
    end
    cmd = "dev_config " .. operation .. " -m custom_group ".."'"..cjson.encode(table).."'"
    os.execute(cmd)
end

-- 自定义应用组中文名称兼容性处理bugid:954879
function get_custom_group_map_name(name)
    -- 查看国内特征库
    local final_name
    x:foreach("app_identify", "Custom_Group", function(s)
        -- 如果name == s[".name"]，说明已经修订好了
        if (s[".name"] ~= name) then
            local section_name = s[".name"]
            local pos = string.find(section_name, "csm_")
            if (pos ~= nil) then
                app_name = x:get("app_identify", section_name, "name")
                map_name = x:get("app_identify", section_name, "map_name")
                if (map_name ~= nil) then
                    map_name = "csm_" .. map_name
                end
                if (app_name == name or map_name == name) then
                    final_name = section_name
                end
            end
        end
    end
    )

    -- 查看国际特征库
    x:foreach("app_identify", "Custom_Group_En", function(s)
        if (s[".name"] ~= name) then
            local section_name = s[".name"]
            local pos = string.find(section_name, "csm_")
            if (pos ~= nil) then
                app_name = x:get("app_identify", section_name, "name")
                map_name = x:get("app_identify", section_name, "map_name")
                if (map_name ~= nil) then
                    map_name = "csm_" .. map_name
                end
                if (app_name == name or map_name == name) then
                    final_name = section_name
                end
            end
        end
    end
    )

    return final_name
end

-- 自定义系统组解析下一级分类
local function app_parse(applist)
    local app_list = {}
    if (#applist ~= 0) then
        for i = 1, #applist do
            local app_name = app_comparison_table[applist[i]]
            if (app_name) then
                local app_tab = x:get("app_identify", app_name, "app")
                if app_tab ~= nil then
                    for j = 1, #app_tab do
                        table.insert(app_list, app_tab[j])
                    end
                end
            else
                table.insert(app_list, applist[i])
            end
        end
        return app_list
    end
end

-- /etc/config/app_identify配置文件新增配置项接口
-- 输入参数：特征库版本，节名称，option_name，应用列表（不管单个应用还是多个应用都以列表形式下发）
function app_idy_add_cfg_section(version, section_name, option_name, app_list)
    local section_type
    local applist =  {}

    if (version == "2" or version == "4") then
        section_type = "Custom_Group"
    elseif (version == "3") then
        section_type = "Custom_Group_En"
    else
        print("{\"code\":\"-1\", \"msg\":\"version illegal\"}")
        return
    end

    x:set("app_identify", section_name, section_type)
    x:set("app_identify", section_name, "name", option_name)
    if (app_list ~= nil and #app_list > 0) then
        applist = app_parse(app_list)
        if #applist ~= 0 then
            x:set("app_identify", section_name, "app", applist)
        end
    end
    x:commit("app_identify")
end

-- /etc/config/app_identify配置文件新增配置项接口
-- 输入参数：组名列表（都以列表形式下发）
function app_idy_del_cfg_section(section_name)

    for key, value in ipairs(section_name) do
        x:delete("app_identify", value)
    end

    x:commit("app_identify")
end

-- R260项目青少年模式获取支付应用通告列表
function get_payment_app_list()
    local file
    local start_flag = 0
    local payment_list = {}
    local version = x:get("app_identify", "signature", "version")

    if (version == "2") then
        file = io.open("/usr/sbin/signature/V2.0/app_file_list.txt", "r")
    elseif (version == "3") then
        file = io.open("/usr/sbin/signature/V3.0/app_file_list.txt", "r")
    elseif (version == "4") then
        file = io.open("/usr/sbin/signature/V4.0/app_file_list.txt", "r")
    else
        print("{\"code\":\"-1\", \"msg\":\"version illegal\"}")
    end

    if file then
        for line in file:lines() do
            if (start_flag == 1) then
                if(#line == 0) then
                    return payment_list
                end
                table.insert(payment_list, line)
            end
            if (line == "[PAYMENT_LIST]") then
                start_flag = 1
            end
        end
    end

    return payment_list
end