#! /usr/bin/lua
local cjson = require "cjson";
local tool = require "dev.tools.common"
local uci = require "luci.model.uci".cursor()
local net_debug = require "utils.debug"
local PORTS_MAP_JSON = "/tmp/sd_device/ports_map.json"
local network_dir = "/tmp/network"
local iptv_vlan_file = "/tmp/network/iptv_vlan"
local network_json_file = "/etc/sd_config/single/network.json"
local network_json_bak_file = "/etc/sd_config/single/network_update_bak.json"
local capacity_file = "/tmp/sd_device/sd_device.json"

--��ʼ����־
if (tool.file_exist(network_dir) == false) then
    local mkdir = table.concat({"mkdir -p ", network_dir, " >/dev/null 2>&1"});
    os.execute(mkdir);
end
net_debug.debug_init("/tmp/network/", "network_update.log", 100, net_debug.INFO, "1");

--��ȡports_map
local ports_map = {};
if (tool.file_exist(PORTS_MAP_JSON) == false) then
    return
end
local ports_map_data = tool.file_read(PORTS_MAP_JSON);
if (tool.json_check(ports_map_data) == true) then
    ports_map = cjson.decode(ports_map_data);
end

--��ȡcapacity_json
local capacity_json = {};
if (tool.file_exist(capacity_file) == false) then
    return
end
local capacity_data = tool.file_read(capacity_file);
if (tool.json_check(capacity_data) == true) then
    capacity_json = cjson.decode(capacity_data);
end

-- �ȴ� /tmp/sd_device/product.json �л�ȡ .capacity.web ��ֵ��Ϊweb_key
local product_file = "/tmp/sd_device/product.json"
if (tool.file_exist(product_file) == false) then
    net_debug.lua_debug(net_debug.INFO, "product.json not exist");
    return
end

local product_data = tool.file_read(product_file);
if (tool.json_check(product_data) == false) then
    net_debug.lua_debug(net_debug.WARN, "product.json format error");
    return
end

local product_json = cjson.decode(product_data);
if (product_json.capacity == nil or product_json.capacity.web == nil) then
    net_debug.lua_debug(net_debug.INFO, "capacity.web not found in product.json");
    return
end

local web_key = product_json.capacity.web;
if (web_key == nil or web_key == "") then
    net_debug.lua_debug(net_debug.INFO, "web_key is empty");
    return
end
net_debug.lua_debug(net_debug.INFO, "get web_key from product.json: %s", web_key);

local web_capacity = capacity_json[web_key];
if (web_capacity == nil or web_capacity.lan2wan == nil or web_capacity.lan2wan ~= "1") then
    return
end

--network����portid
local network_json = {};
if (tool.file_exist(network_json_file) == false) then
    return
end
local network_json_data = tool.file_read(network_json_file);
if (tool.json_check(network_json_data) == true) then
    network_json = cjson.decode(network_json_data);
end
local change = false;
if (network_json["wan"] == nil) then
    return;
end
for key, val in pairs(network_json["wan"]) do
    local wan_num = tostring(key);
    if (val["portId"] == nil and ports_map ~= nil and ports_map["port"] ~= nil) then
        for skey, sval in pairs(ports_map["port"]) do
            if (wan_num == sval["wan_num"]) then
                network_json["wan"][key]["portId"] = sval["intf_port"];
                change = true;
            end
        end
    end
end
if (change == true) then
    if (network_json["configTime"] ~= nil) then
        network_json["configTime"] = tostring(tonumber(network_json["configTime"]) + 1);
    end
    if (network_json["currentTime"] ~= nil) then
        network_json["currentTime"] = tostring(tonumber(network_json["currentTime"]) + 1);
    end
    if (network_json["configId"] ~= nil) then
        network_json["configId"] = tostring(tonumber(network_json["configId"]) + 1);
    end
    tool.file_mv_write(network_json_file, network_json_bak_file, cjson.encode(network_json), "w+");
end

--����iptv
if (tool.file_exist(iptv_vlan_file) == false) then
    if (tool.file_exist(network_json_file) == false) then
        return;
    end
    if (network_json["lan"] == nil) then
        return;
    end
    for key, val in pairs(network_json["lan"]) do
        if (val["descRead"] == "iptv" or val["descRead"] == "ipPhone") then
            tool.file_write(iptv_vlan_file, table.concat({val["vlanid"], ","}), "a+");
        end
    end
end
