#!/usr/bin/env lua
-- Lua DKJSON Parse For Parent
-- Enhua Chen

local json = require "dkjson"
-- 文件名为 public_module.lua
-- 定义一个名为 public_module 的模块
public_module = {}

-- 定义一个常量
public_module.max_cache = 64*1024
public_module.log_file = "/tmp/public_module_log"
-- 定义一个函数
function public_module.read_file(pfile)
    local config_content
    local file
    local config_table
    
    file = io.open(pfile, "r")
    if (file ~= nil)
    then
        config_content = file:read("*a")
        if (config_content ~= nil)
        then
            if(string.len(config_content) ~= 0)
            then
                config_table = json.decode(config_content)
            else
                config_table = json.decode('{"list":[]}')
            end
           
        end
        io.close(file)
    else
        config_table = json.decode('{"list":[]}')
    end
    return config_table
end
 
function public_module.write_file(config_table, pfile)
    local config_content
    local file
    config_content = json.encode(config_table)
    if ( config_content == nil)
    then 
        public_module.debug_print(public_module.log_file, "save_config-config_content is nil")
        return -1
    end
    
    file = io.open(pfile, "w+")
    if ( file ~= nil)
    then
        file:write(config_content)
        io.close(file)
    end
    return 0
end
 
function public_module.check_env(path)
    local buff_exec
    local file = io.open(path, "rb")
    if (file ~=  nil) 
    then
        io.close(file) 
    else
        buff_exec = "mkdir -p "..path
        os.execute(buff_exec)
    end
end

function public_module.check_file(pfile)
    local config_content
    local file
    
    file = io.open(pfile, "r")
    if (file ~= nil)
    then
        config_content = file:read("*a")
        if (config_content ~= nil)
        then
            if(string.len(config_content) ~= 0)
            then
                io.close(file)
                return 1
            end
           
        end
        io.close(file)
    end
    return 0
end

function public_module.check_rule(rule)
    local port
    if (rule["srcPort"] ~= nil)
    then
        port = tonumber(rule["srcPort"])
        if ( port~= nil)
        then
            if (port >= 65535 or port <= 0)
            then
                public_module.debug_print(public_module.log_file,"port is invaild :%d", port)
                return 1
            end
        end
    end
    
    if (rule["destPort"] ~= nil)
    then
        port = tonumber(rule["destPort"])
        if (port ~= nil)
        then
            if (port >= 65535 or port <= 0)
            then
                public_module.debug_print(public_module.log_file, "port is invaild :%d", port)
                return 1
            end
        end
    end
    return 0
end

function public_module.stat_file(pfile)
    local exec_buff = "ls -l "..pfile.." 2>/dev/null|awk '{print $5}'"
    local file = io.popen(exec_buff)
    if (file == nil)
    then
        public_module.debug_print(public_module.log_file, "du result get fail")
        return -1
    end
    config_content = file:read("*a")
    if (config_content == nil)
    then
        io.close(file)
        return 0
    elseif (string.len(config_content) == 0)
    then
        io.close(file)
        return 0
    elseif (tonumber(config_content) <= public_module.max_cache)
    then
        io.close(file)
        return 0
    end
    os.rename(pfile,pfile.."_bak")
    io.close(file)
end

function public_module.debug_print(log_file, fmt, ...)
    local file 
    local date_buff
    if (log_file == nil)
    then
        return -1
    end
    public_module.stat_file(log_file)
    file = io.open(log_file, "a")
    if (file ~= nil)
    then
        date_buff = os.date("%Y-%m-%d %H:%M:%S")
        file:write("["..date_buff.."] "..string.format(fmt, ...).."\n")
        io.close(file)
    end
    return 0
end
 
return public_module