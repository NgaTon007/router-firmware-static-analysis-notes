#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("user_mgr.user_mgr_common", package.seeall)
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/user_group/vgrp/"
local DEL_GROUP_JSON_DIR = "/tmp/user_group/"
local USER_MRG_CMD_ELF = "/usr/sbin/user_mgr_cmd.elf"
local LOCK_FILE = "/tmp/user_group/user_mgr.lock"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path)
end

--debug初始化 
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "user_mgr_common.log", 500, module_debug.INFO, "1")
end

local function stringsplit(str, delimiter)
    if str==nil or str=='' or delimiter==nil then
        return nil
    end
    
    local result = {}
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end

local function checkparam_for_string(param)
    if (type(param) ~= "string") then
        return -1
    end

    if (string.match(param, "[^%w,_—]") ~= nil) then
        return -1
    end

    return 0
end

local function iprange_recover(iprange, ipset_name)
    ipstart, ipend = string.match(iprange, "^(%S+)-(%S+)$")
    if (ipstart == nil or ipend == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ipange style is error")
        return -1
    end
    
    ret, ipstart_int = ip_str_to_int(ipstart)
    if (ret ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr start [%s] pattern is error, cannot be converted to type int", ipstart)
        return -1
    end
    
    ret, ipend_int = ip_str_to_int(ipend)
    if (ret ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", ipend)
        return -1
    end
    
    ret, boundary = ip_str_to_int("129.0.0.0")
    if (ret ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", "129.0.0.0")
        return -1
    end
    
    if (ipstart_int < boundary and ipend_int > boundary) then
        cmd = string.format("ipset add %s %s-129.0.0.0 -exist >/dev/null 2>&1", ipset_name, ipstart)
        os.execute(cmd)
        
        cmd = string.format("ipset add %s 129.0.0.0-%s -exist >/dev/null 2>&1", ipset_name, ipend)
        os.execute(cmd)
    else
        cmd = string.format("ipset add %s %s-%s -exist >/dev/null 2>&1", ipset_name, ipstart, ipend)
        os.execute(cmd)
    end
end

local function has_prefix(str, prefix)
    return string.sub(str, 1, #prefix) == prefix
end

local function write_deleted_groups_json(deleted_ids)
    local timestamp = tostring(os.time())
    local file_path = DEL_GROUP_JSON_DIR .. "del_groups_" .. timestamp .. ".json"
    local json_data = {
        timestamp = timestamp,
        deleted_ids = deleted_ids
    }
    local json_str = cjson.encode(json_data)

    if (json_str == nil) then
        module_debug.lua_debug(module_debug.ERROR, "failed to encode deleted_ids json")
        return
    end

    tool.file_write(file_path, json_str, "w")
    module_debug.lua_debug(module_debug.INFO, "write deleted groups json to %s", file_path)
    return file_path
end

function single_uci_writer_check()
    if (tool.file_exist(LOCK_FILE) == true) then
        local attr = lfs.attributes(LOCK_FILE)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 5) then
            os.remove(LOCK_FILE);
        end
    end

    if (tool.file_exist(LOCK_FILE) == true) then
        module_debug.lua_debug(module_debug.INFO, "INFO: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(LOCK_FILE, "running", "w");
        return true;
    end
end

function remove_uci_lock_file()
    os.remove(LOCK_FILE)
end

function user_mgr_add_vgrp_core(name, param_tab, ipset_flag)
    local user_list = {}
    local id = nil
    debug_init()
    module_debug.lua_debug(module_debug.INFO, "################################ADD VGRP################################")
    if (name == nil or param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is null")
        return -1
    end
    module_debug.lua_debug(module_debug.INFO, "add vgrp name [%s]", name)
    uci:foreach("user_mgr", "virtual_grp", function(s)
        local namecode = s[".name"]
        local msg_name = uci:get("user_mgr", namecode, "name")	
        if (msg_name == name) then		    
            id = namecode
            module_debug.lua_debug(module_debug.INFO, "find the same name [%s], id is:%s",msg_name,id) 
        end		
    end
    )
    local count = 1
    while (single_uci_writer_check() == false) do
        if count > 5 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
        tool.sleep(1)
        count = count + 1
    end
    if (id ~= nil) then
        uci:delete("user_mgr", id)
        local del_id_cmd = USER_MRG_CMD_ELF .. " -D -d " .. id .. " >/dev/null 2>&1"
        module_debug.lua_debug(module_debug.INFO, "del_id_cmd = %s", del_id_cmd);
        os.execute(del_id_cmd)
    end
    
    local sectionname = tonumber(uci:get("user_mgr", "main", "static_cap"))
    uci:set("user_mgr", "main", "static_cap", sectionname+1)
    sectionname = tostring(sectionname)
    if (sectionname == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:sectionname is nil")
        remove_uci_lock_file()
        return -1
    end
    module_debug.lua_debug(module_debug.INFO, "add sectionname = %s", sectionname)
    for k,v in pairs(param_tab) do
        if (v == nil) then
            module_debug.lua_debug(module_debug.ERROR, "v is nil!")
            remove_uci_lock_file()
            return -1
        end
        if (k > 30) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR:user_group_list number is max!")
            remove_uci_lock_file()
            return -1
        end
        user_list[k] = v
    end
    
    uci:set("user_mgr", sectionname, "virtual_grp");
    uci:set("user_mgr", sectionname, "name", name)
    uci:set("user_mgr", sectionname, "type", "virtual")
    uci:set("user_mgr", sectionname, "user", user_list)
    if ipset_flag then
        uci:set("user_mgr", sectionname, "ipset_flag", "1")
    else
        uci:set("user_mgr", sectionname, "ipset_flag", "0")
    end

    uci:commit("user_mgr")
    remove_uci_lock_file()
    local add_id_cmd = USER_MRG_CMD_ELF .. " -R " .. sectionname .. " >/dev/null 2>&1"
    module_debug.lua_debug(module_debug.INFO, "add_id_cmd = %s", add_id_cmd);
    os.execute(add_id_cmd)

    module_debug.lua_debug(module_debug.INFO, "################################END################################")
    return 0
end

function user_mgr_add_vgrp(name, param_tab)
    user_mgr_add_vgrp_core(name, param_tab, false)
end

function user_mgr_del_vgrp(name)
    local id = nil
    debug_init()
    module_debug.lua_debug(module_debug.INFO, "################################DEL VGRP################################")
    if (name == nil ) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: name is null")
        return -1
    end
    module_debug.lua_debug(module_debug.INFO, "Input vgrp name:%s", name)
    uci:foreach("user_mgr", "virtual_grp", function(s)
        local namecode = s[".name"]
        local msg_name = uci:get("user_mgr", namecode, "name")	
        module_debug.lua_debug(module_debug.INFO, "=name=:%s", msg_name) 
        if (msg_name == name) then		    
            id = namecode
            module_debug.lua_debug(module_debug.INFO, "=id=:%s", id) 
        end		
    end
    )
    --flowctrl更新策略操作会先删除用户组再进行添加，因此name存在时不一定创建了user_group
    if (id ~= nil) then
        local count = 1
        while (single_uci_writer_check() == false) do
            if count > 5 then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
                return -1
            end
            module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
            tool.sleep(1)
            count = count + 1
        end
        uci:delete("user_mgr", id)
        uci:commit("user_mgr")
        remove_uci_lock_file()
        del_id_cmd = USER_MRG_CMD_ELF .. " -D -d " .. id .. " >/dev/null 2>&1"
        module_debug.lua_debug(module_debug.INFO, "del_id_cmd = %s", del_id_cmd);
        os.execute(del_id_cmd)
    else
        module_debug.lua_debug(module_debug.INFO, "have no virtual_group named:%s,not excute delete", name)
        return -1
    end
    
    return 0 
end

-- {"list": ["vgrp1", "vgrp2"]}
function user_mgr_del_vgrp_multi(param_name_list)
    debug_init()
    module_debug.lua_debug(module_debug.INFO, "############################DEL VGRP MULTI############################")
    if (param_name_list == nil or type(param_name_list) ~= "table" or param_name_list["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param_name_list is invalid")
        return -1
    end
    local target_name_map = {}
    for _, name in ipairs(param_name_list["list"]) do
        target_name_map[name] = true
    end

    local count = 1
    while (single_uci_writer_check() == false) do
        if count > 5 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
        tool.sleep(1)
        count = count + 1
    end

    local deleted_ids = {}
    uci:foreach("user_mgr", "virtual_grp", function(s)
        local id = s[".name"]
        local name = s["name"]
        if (name == nil) then
            name = uci:get("user_mgr", id, "name")
        end

        if (name ~= nil and target_name_map[name] == true) then
            uci:delete("user_mgr", id)
            table.insert(deleted_ids, id)
            target_name_map[name] = nil
        end
    end)

    for _, name in ipairs(param_name_list["list"]) do
        if (target_name_map[name] == true) then
            module_debug.lua_debug(module_debug.INFO, "have no virtual_group named:%s,not excute delete", name)
        end
    end

    if (#deleted_ids == 0) then
        remove_uci_lock_file()
        return -1
    end

    uci:commit("user_mgr")
    remove_uci_lock_file()

    local file_path = write_deleted_groups_json(deleted_ids)
    local del_id_cmd = USER_MRG_CMD_ELF .. " -B " .. file_path .. " >/dev/null 2>&1"
    module_debug.lua_debug(module_debug.INFO, "del_multi_cmd = %s", del_id_cmd)
    os.execute(del_id_cmd)


    return 0
end

function user_mgr_update_vgrp_ipset(vgrp_name, param_grp_list)
    local sectionname = nil
    local update_section = nil
    module_debug.lua_debug(module_debug.INFO, "user_mgr_update_vgrp_ipset %s, param_grp_list:%d", vgrp_name, #param_grp_list) 
    local count = 1
    while (single_uci_writer_check() == false) do
        if count > 5 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
        tool.sleep(1)
        count = count + 1
    end
    uci:foreach("user_mgr", "virtual_grp", function(s)
        sectionname = s[".name"]
        vgrp_name_conf = uci:get("user_mgr", sectionname, "name")	
        module_debug.lua_debug(module_debug.INFO, "=name=:%s", vgrp_name_conf) 
        if (vgrp_name_conf == vgrp_name) then
            update_section = sectionname
            uci:delete("user_mgr", update_section)
        end		
    end
    )
    uci:commit("user_mgr")
    remove_uci_lock_file()

    if (update_section ~= nil) then
        del_id_cmd = USER_MRG_CMD_ELF .. " -D -d " .. update_section .. " >/dev/null 2>&1"
        module_debug.lua_debug(module_debug.INFO, "del_id_cmd = %s", del_id_cmd);
        os.execute(del_id_cmd)
    end
    
    if (#param_grp_list ~= 0) then
        user_mgr_add_vgrp_core(vgrp_name, param_grp_list, true)
    else
        if (vgrp_name ~= nil and vgrp_name ~= "" and checkparam_for_string(vgrp_name) == -1) then
            return -1
        end
        cmd = string.format("ipset flush %s  >/dev/null 2>&1", vgrp_name)
        os.execute(cmd)
        cmd = string.format("ipset flush %s  >/dev/null 2>&1", vgrp_name.."_net")
        os.execute(cmd)
        cmd = string.format("ipset flush %s  >/dev/null 2>&1", vgrp_name.."_mac")
        os.execute(cmd)
    end
    
    module_debug.lua_debug(module_debug.INFO, "user_mgr_update_vgrp_ipset end") 
end

function user_mgr_reload_vgrp_ipset()
     local reload_cmd = USER_MRG_CMD_ELF .. " -L >/dev/null 2>&1"
     module_debug.lua_debug(module_debug.INFO, "reload_cmd = %s", reload_cmd);
     os.execute(reload_cmd)
end

-- { "groups": [ { "id": 213, "name": "l2tp-1.1.1.2", "auto": "true", "role": "user", "ip_range": "1.1.1.2" } ] }
function get_id_by_name(param)
    local id_str = nil
    if param == nil then
        return nil
    end

    local cmd = string.format("user_mgr_cmd.elf -Q -u %s", param)
    local t = io.popen(cmd)
    local str = t:read("*all")
    t:close()
    if (str ~= nil) then
        module_debug.lua_debug(module_debug.INFO, "user info %s ", str);
        user_tab = cjson.decode(str)
        if (#user_tab["groups"] == 0) then
            return nil
        else
            for _, group in ipairs(user_tab.groups) do
                if group.name == param then
                    id_str = tostring(group.id)
                end
            end
        end
    else
        return nil
    end
    
    return id_str
end