#!/usr/bin/lua
--dev_cap lua封装库
module('dev_cap',package.seeall)
local console = require "console"
local call_type={ac_config=0, dev_config=1, dev_sta=2, dev_cap=3}

local function debug(msg)
    console.debug("dev_cap", msg)
end

function get_ctype()
	return 3 --ac_config=0 dev_config=1 dev_sta=2 dev_cap=3
end

--主函数
function fetch(cmd, module, param, back, ip, password, force, not_change_configId)
    local uf_call = require "libuflua"
    local ctype

    ctype = get_ctype()
    param = param or ""
    ip = ip or ""
    password = password or ""
    if force and force == "1" then
    	force = true
    else
    	force = false
    end

    if back and back == "1" then
    	back = true
    else
    	back = false
    end    
    if not_change_configId then
    	not_change_configId = true
    else
    	not_change_configId = false
    end

    local stat = uf_call.client_call(ctype, cmd, module, param, back, ip, password, force, not_change_configId)
    return stat
end


function fetch_string(cmd, module, param, back, ip, password, force, not_change_configId)
    local ret = fetch(cmd, module, param, back, ip, password, force, not_change_configId)
    if ret.code == "1" or ret.code == 1 then
    	if ret.err then
        	debug("return ".. ret.err)
        end
        return ret.err
    else
        return ret.data
    end
end