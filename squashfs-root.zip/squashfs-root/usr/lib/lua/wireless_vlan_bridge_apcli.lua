-- config wifi-iface 'ra5_10'
        -- option ifname 'ra5.10'
        -- option disabled '1'
        -- option network 'lan'
module("wireless_vlan_bridge_apcli", package.seeall)

local uci = require "luci.model.uci".cursor()
local json = require "dkjson"
local console = require "console"
local lib_mesh = require "utils.mesh_com"
local radiolist_cache = lib_mesh.get_radio_info()
local dev_mode = uci:get_first("sysinfo", "sysinfo", "forwardMode")
local wan_vlanid = uci:get("network", "wan", "vlanid") or "1"
local lan_vlanid = "233"
local ext_ifname = nil
local apcli_name = nil
local ifname = nil
local log_msg = nil

local function debug(msg)
    console.debug("wireless_vlan_bridge_apcli", msg)
end

local function create_apcli_conf(apcli_if, apcli_name, vlanid)
	local iface_name = string.gsub(apcli_if, "%.", "_")
	if uci:get("repeater", iface_name) == "wifi-device" then
		log_msg = string.format("%s exists, do not need to create", iface_name)
		debug(log_msg)
		return
	end
	local cmd = string.format("vconfig add %s0 %s && ifconfig %s up", apcli_name, vlanid, apcli_if)
	os.execute(cmd)
	debug(cmd)
	uci:set("repeater", iface_name, "wifi-device")
	uci:set("repeater", iface_name, "ifname", apcli_if)
	uci:set("repeater", iface_name, "ApCliEnable", "1")
	uci:set("repeater", iface_name, "not_need_set", "true")
	local network = string.format("lan_%s", vlanid)
	uci:set("repeater", iface_name, "network", network)
	log_msg = string.format("Create apcli interface %s, apcli_ifname[%s], ApCliEnable 1, network[%s]", iface_name, apcli_if, network)
	debug(log_msg)
end

local function del_apcli_conf(apcli_if, vlanid)
	local iface_name = string.gsub(apcli_if, "%.", "_")
	if not uci:get("repeater", iface_name) then
		log_msg = string.format("%s does not exist, no need to delete uci section", iface_name)
		debug(log_msg)
		return
	end
	-- uci:load("network")
	-- local network = string.format("lan_%s", vlanid)
	-- if uci:get("network", network) then
	-- 	log_msg = string.format("%s bridge exists, no need to delete uci section", network)
	-- 	debug(log_msg)
	-- 	return
	-- end
	uci:delete("repeater", iface_name)
	log_msg = string.format("Delete iface[%s] uci section", iface_name)
	debug(log_msg)
	-- do not need to down interface
	local cmd = string.format("vconfig rem %s", apcli_if)
	os.execute(cmd)
	debug(cmd)
end

function vlan_tab_deduplicate(tab)
	local tmp_tab = {}
	local tab_after_dedup = {}
	for k, v in pairs(tab) do
		tmp_tab[v] = "1" -- any value is OK
	end
	for k, v in pairs(tmp_tab) do
		if k ~= wan_vlanid and k ~= lan_vlanid then
			table.insert(tab_after_dedup, k)
		else
			log_msg = string.format("This vlanid [%s] do not need to virtual", k)
			debug(log_msg)
		end
	end
	return tab_after_dedup
end

--Just create wlanid 6 virtual interface now. 
--Reserve "wlanid" parameter for subsequent expansion.
function ap_mesh_virtual_apcli_if_action(wlanid, vlan_tab, is_add)
	debug("Start-----------------------------------")
	if not vlan_tab or not wlanid then
		log_msg = string.format("Input wlanid or vlan_tab is nil")
		debug(log_msg)
		return
	end
	log_msg = string.format("Vlan table before deduplicating is %s", json.encode(vlan_tab))
	debug(log_msg)
	dedup_tab = vlan_tab_deduplicate(vlan_tab)
	log_msg = string.format("Vlan table after deduplicating is %s", json.encode(dedup_tab))
	debug(log_msg)
	for k, v in pairs(dedup_tab) do
		for i, device in ipairs(radiolist_cache) do
			apcli_name = device.apcli_ifname
			if apcli_name then
				apcli_if = string.format("%s0.%s", apcli_name, v)
				if is_add == true then
					create_apcli_conf(apcli_if, apcli_name, v)
				else
					del_apcli_conf(apcli_if, v)
				end
			end	
		end
	end
	uci:commit("repeater")
	debug("End-------------------------------------")
end

function virtual_apcli_if_action(radioid, wlanid, vlan_tab, is_add)
	debug("Start-----------------------------------")
	if not vlan_tab or not wlanid or not radioid then
		log_msg = string.format("Input wlanid or vlan_tab is nil")
		debug(log_msg)
		return
	end
	log_msg = string.format("Vlan table before deduplicating is %s", json.encode(vlan_tab))
	debug(log_msg)
	dedup_tab = vlan_tab_deduplicate(vlan_tab)
	log_msg = string.format("Vlan table after deduplicating is %s", json.encode(dedup_tab))
	debug(log_msg)
	for k, v in pairs(dedup_tab) do
		for i, device in ipairs(radiolist_cache) do
			cap_rid = string.match(device.index, "%d+")
			if radioid == cap_rid then
				apcli_name = device.apcli_ifname
				if apcli_name then
					apcli_if = string.format("%s0.%s", apcli_name, v)
					if is_add == true then
						create_apcli_conf(apcli_if, apcli_name, v)
					else
						del_apcli_conf(apcli_if, v)
					end
				end	
			end
		end
	end
	uci:commit("repeater")
	debug("End-------------------------------------")
end

