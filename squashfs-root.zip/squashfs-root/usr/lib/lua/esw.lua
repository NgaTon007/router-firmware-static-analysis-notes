#!/usr/bin/lua
module('esw',package.seeall)
local console = require "console"
local call_type={ac_config=0, dev_config=1, dev_sta=2, dev_cap=3}

local function debug(msg)
    console.debug("esw", msg)
end

function get_ctype()
    local ctype
    ctype = 5 --ac_config=0 dev_config=1 dev_sta=2 dev_cap=3 esw=5
	return ctype
end

function fetch(cmd, ip, sn, url, param, back, caller, password, esw_specific_channel, esw_basic)
    local uf_call = require "libuflua"
    local ctype
    local caller_ip

    module = "esw"
    ctype = get_ctype()
    if type(param) == "table" then
        param = luci.json.encode(param)
    end
    param = param or ""


    caller = caller or ""
    caller_ip = os.getenv('HTTP_X_FORWARDED_FOR') or os.getenv('REMOTE_ADDR') or ""

    if back and back == "1" then
    	back = true
    else
    	back = false
    end    

    if esw_specific_channel then
    	esw_specific_channel = true
    end

    if esw_basic then
    	esw_basic = true
    end

    local stat = uf_call.client_call(ctype, cmd, module, param, back, ip, password, force, not_change_configId, multi, caller, caller_ip, sn, url, esw_specific_channel, esw_basic)
    return stat
end


function fetch_string(cmd, ip, sn, url, param, caller, password, esw_specific_channel, esw_basic)
    local ret = fetch(cmd, ip, sn, url, param, caller, password, esw_specific_channel, esw_basic)
    if ret.code == "1" or ret.code == 1 then
    	if ret.err then
        	debug("return ".. ret.err)
        end
        return ret.err
    else
        return ret.data
    end
end

