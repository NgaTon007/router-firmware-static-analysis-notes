#! /usr/bin/lua
module("utils.ubus", package.seeall)

local libdbg = require("utils.debug");

--[[
    ubus_call() -- ubus call的lua接口
    @object：ubus对象
    @method：ubus对象方法。
    @param: ubus对象方法参数，是一个table对象。
    @timeout: ubus call超时时间，数据类型为数字，允许为空nil，这时候默认超时时间为30秒。
    @return：
            false：ubus连接错误
            {}空json table：ubus call空返回
            json table：ubus call返回
    @note：最好加上超时时间。
--]]
function ubus_call(object, method, param, timeout)
    -- 1、参数检查
    assert((object ~= nil and #object ~= 0), string.format("ERROR in %s [%d] ubus_call() param:object is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((method ~= nil and #method ~= 0), string.format("ERROR in %s [%d] ubus_call() param:method is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    -- param必须是table
    assert((param ~= nil and type(param) == "table"), string.format("ERROR in %s [%d] ubus_call() param:param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    -- timeout允许为空，但是如果不为空时，不允许非数字的
    if (timeout ~= nil) then
        assert(type(timeout) == "number", string.format("ERROR in %s [%d] ubus_call() param:timeout is not number.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    end

    local result = {};
    local ubus = require("ubus").connect(nil, timeout);-- timeout允许为空nil，这时候默认超时时间为30秒
    if (ubus == nil) then
        libdbg.lua_debug(libdbg.ERROR, "ubus connect failed");
        return false;
    end
    libdbg.lua_debug(libdbg.INFO, "ubus call object:%s, method:%s, param:%s, timeout:%s", object, method, require("dkjson").encode(param), timeout);
    result = ubus:call(object, method, param);
    if (result == nil or type(result) ~= "table") then
        result = {};
    end
    libdbg.lua_debug(libdbg.INFO, "ubus call result:%s", require("dkjson").encode(result));

    return result;
end

--[[
    ubus_send() -- ubus send的lua接口
    @object：ubus对象
    @param: ubus对象方法参数，是一个table对象。
    @timeout: ubus send超时时间，数据类型为数字，允许为空nil，这时候默认超时时间为30秒。
    @return：
            false：ubus连接错误
            {}空json table：ubus send空返回
            json table：ubus send返回
    @note：最好加上超时时间。
--]]
function ubus_send(object, param, timeout)
    -- 1、参数检查
    assert((object ~= nil and #object ~= 0), string.format("ERROR in %s [%d] ubus_send() param:object is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    -- param必须是table
    assert((param ~= nil and type(param) == "table"), string.format("ERROR in %s [%d] ubus_send() param:param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    -- timeout允许为空，但是如果不为空时，不允许非数字的
    if (timeout ~= nil) then
        assert(type(timeout) == "number", string.format("ERROR in %s [%d] ubus_send() param:timeout is not number.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    end

    local result = {};
    local ubus = require("ubus").connect(nil, timeout);-- timeout允许为空nil，这时候默认超时时间为30秒
    if (ubus == nil) then
        libdbg.lua_debug(libdbg.ERROR, "ubus connect failed");
        return false;
    end
    libdbg.lua_debug(libdbg.INFO, "ubus send object:%s, param:%s, timeout:%s", object, require("dkjson").encode(param), timeout);
    result = ubus:send(object, param);
    if (result == nil) then
        result = {};
    end
    libdbg.lua_debug(libdbg.INFO, "ubus send result:%s", require("dkjson").encode(result));

    return result;
end
