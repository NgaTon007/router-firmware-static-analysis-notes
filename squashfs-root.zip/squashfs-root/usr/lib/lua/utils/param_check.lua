#! /usr/bin/lua

module("utils.param_check", package.seeall)

--[[
检测参数是否含有&|;等字符，包含返回false，不包含返回true
    @param: 要检测的参数
调用用例:
    lib_param = require "utils.param_check"
    if (lib_param.param_safety_check(param) == true) then
        print("true")
    else
        print("false")
    end
]]
function param_safety_check(param)
    if (param == nil) then
        return true
    end

    if (string.match(param, "([\n\r'`&$;|])") == nil) then
        return true
    else
        return false
    end
end
