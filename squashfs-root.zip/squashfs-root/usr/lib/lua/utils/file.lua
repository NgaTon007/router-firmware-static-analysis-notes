#! /usr/bin/lua

module("utils.file", package.seeall)

local libdbg = require("utils.debug");

-- lua判断文件或则文件夹是否存在
function file_is_exist(path)
    local file = io.open(path, "rb");

    if (file) then
        file:close();
    end

    return file ~= nil;
end

--获取文件大小
function get_file_size(file)
    local f = assert(io.open(file, "rb"))
    local len = assert(f:seek("end"))
    f:close()

    return len
end

-- lua获取文件行数
function get_file_line_num(file)
    local BUFSIZE = 65536;
    local lc = 0;

    local f = io.input(file);
    while (true) do
        local lines, rest = f:read(BUFSIZE, "*line");
        if (not lines) then
            break;
        end
        _, t = string.gsub(lines, "\n", "\n");
        lc = lc + t;
    end

    return lc;
end

--lua读文件的第一行
function read_file_first_line(file)
    local f = assert(io.open(file,'r'));
    local content = f:read("*line");
    f:close();

    return content;
end

-- lua读文件
function read_file(file)
    local f = assert(io.open(file,'r'));
    local content = f:read("*all");
    f:close();

    return content;
end

-- lua写文件，mode参数为"w"或者"a"
function write_file(file, msg, mode)
    local f = assert(io.open(file, mode));
    f:write(msg or "");
    io.flush();
    f:close();
end
