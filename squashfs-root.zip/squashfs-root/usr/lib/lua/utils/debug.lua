#! /usr/bin/lua
module("utils.debug", package.seeall)
local pid_handle = require("libc2lua");

--使用说明：使用之前要调用初始化接口lua_lib_debug_init()（参数说明详见接口）进行初始化，否则使用默认配置

--调试开关
OPEN = "1";
CLOSE = "0";
DEBUG_STATUS = OPEN;

--调试等级
CRLF    = 0;--用于打印回车换行的级别
ERROR   = 1;
WARNING = 2;
NOTICE  = 3;
INFO    = 4;
DEBUG   = 5;
--调试等级与上述索引位置对应
dbg_level = {
    "ERROR",    --key=1
    "WARNING",  --key=2
    "NOTICE",   --key=3
    "INFO",     --key=4
    "DEBUG",    --key=5
}

--lua debug的默认配置，使用的时候要配置
if (DEBUG_STATUS == "1") then
    DEBUG_LOG_DIR = "/tmp/lua_debug/";
    DEBUG_LOG_FILE_PATH = table.concat({DEBUG_LOG_DIR, "lua_debug.log"});
    DEBUG_LOG_FILE_SIZE = 500;--line number
    DEBUG_LEVEL = 3;
end

--[[lua调试debug初始化：注意要在使用之前进行初始化，否则都默认打印到/tmp/lua_debug/lua_debug.log
    如果进行初始化，则所有的参数必须都有参数
    @log_dir: 日志目录，默认/tmp/lua_debug/
    @log_file: 日志文件名，默认lua_debug.log
    @log_file_size: 日志文件大小，控制的是行数，默认100
    @debug_level: 调试日志等级，"1":ERROR，"2":WARNING，"3":DEBUG，默认是3
    @debug_status: 调试日志状态，"1":打开，"0":打开，默认是1
]]
function debug_init(log_dir, log_file, log_file_size, debug_level, debug_status)
    --入参检查
    if (not log_dir) then
        print("log_dir is invalid!");
        return false;
    end
    if (not log_file) then
        print("log_file is invalid!");
        return false;
    end
    if (not log_file_size) then
        print("log_file_size is invalid!");
        return false;
    end
    if (not debug_level) then
        print("debug_level is invalid!");
        return false;
    end
    if (not debug_status) then
        print("debug_status is invalid!");
        return false;
    end
    DEBUG_LOG_DIR = log_dir;
    DEBUG_LOG_FILE_PATH = table.concat({log_dir, log_file});
    DEBUG_LOG_FILE_SIZE = tonumber(log_file_size);--line number
    DEBUG_LEVEL = debug_level;
    DEBUG_STATUS = debug_status;
end

--lua判断文件或则文件夹是否存在
function lua_is_file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

--lua获取文件行数
function lua_get_file_line_number(file)
    local BUFSIZE = 65536;
    local lc = 0;
    local f = io.input(file);
    while (true) do
        local lines, rest = f:read(BUFSIZE, "*line");
        if (not lines) then
            break;
        end
        _, t = string.gsub(lines, "\n", "\n");
        lc = lc + t;
    end
    return lc;
end

--lua调试debug
function lua_debug(level, fmt, ...)
    if (DEBUG_STATUS == "1") then
        assert((type(level) == "number"), string.format("ERROR in %s %s[%d] debug level has no input or is not a number(eg, lua_debug(ERROR, \"xxx\"), define ERROR=1, WARNING=2...", debug.getinfo(2).short_src, (debug.getinfo(2).name ~= nil) and table.concat({debug.getinfo(2).name, "() "}) or "", debug.getinfo(2).currentline));

        if (level > DEBUG_LEVEL) then
            return;
        end
        if (lua_is_file_exist(DEBUG_LOG_FILE_PATH) == true) then
            local log_line = lua_get_file_line_number(DEBUG_LOG_FILE_PATH);
            if (log_line >= DEBUG_LOG_FILE_SIZE) then
                -- 解决875861，句柄泄漏问题
                local lckfil = table.concat({DEBUG_LOG_FILE_PATH, ".lck"});
                require("utils.lock").lock(lckfil);
                local DEBUG_LOG_FILE_PATH_BAK = table.concat({DEBUG_LOG_FILE_PATH, ".old"});
                os.rename(DEBUG_LOG_FILE_PATH, DEBUG_LOG_FILE_PATH_BAK);
                require("utils.lock").unlock(lckfil);
            end
        else
            if (lua_is_file_exist(DEBUG_LOG_DIR) == false) then
                local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
                os.execute(mkdir);
            end
        end
        local pid = nil;
        --如果没有getpid()接口可以考虑用执行shell获取pid：cat /proc/$$/stat | awk '{printf $4}'
        if (type(pid_handle) == "table") then
            pid = table.concat({"[", pid_handle.getpid() ,"]"});
        else
            cmd_ret = io.popen("cat /proc/$$/stat | awk '{printf $4}'"):read("*all");
            pid = (cmd_ret ~= nil and cmd_ret ~= "") and table.concat({"[", cmd_ret, "]"}) or "[NA]";
        end
        local cur_time = os.date("[%Y-%m-%d %H:%M:%S] ");
        local f = assert(io.open(DEBUG_LOG_FILE_PATH, "a"));
        --如果输入空字符串，直接打空行分隔开。例如：lib_debug.lua_debug(ERROR, "")，需要传入最低等级：ERROR，也就是数字1
        if (string.format(fmt, ...) == "") then
            f:write("\r\n");
            f:close();
            return;
        end
        f:write(pid, cur_time, string.match(debug.getinfo(2).short_src, "([^/]*%w+%.%w+)$"), " ", (debug.getinfo(2).name ~= nil) and table.concat({debug.getinfo(2).name, "() "}) or "", "[", debug.getinfo(2).currentline, "] ", "[", dbg_level[level], "] ", string.format(fmt, ...), "\n");
        f:close();
    end
end
