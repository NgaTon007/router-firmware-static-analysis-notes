#! /usr/bin/lua
module("utils.double_tag", package.seeall)

local json = require "cjson"

function check_double_tag()
    local file = io.open("/tmp/sd_device/sd_device.json", "r")
    if file then
        local content = file:read("*a")
        file:close()
        local data = json.decode(content)
        if data.double_tag and data.double_tag.double_tag_enable and data.double_tag.double_tag_enable == "1" then
            return 1
        else
            return 0
        end
    else
        return 0
    end
end