#! /usr/bin/lua
module("utils.lock", package.seeall)

local libdbg = require("utils.debug");

-- 加锁
function lock(path)
    local file = io.open(path, "r")
    if file then 
        local line = file:read() 
        file:close()
        if (string.len(line) > 0) then
            -- 超过3分钟就认为是无效锁
            if (tonumber(os.time()) - 180 > tonumber(line)) then
                do return true end
            else
                do return false end
            end
        end
    end
    local file = io.open(path, "w")
    if file then 
        file:write(os.time())
        io.flush ()
        file:close()
    end
    return true
end

-- 解锁
function unlock(path)
    os.remove(path);
end
