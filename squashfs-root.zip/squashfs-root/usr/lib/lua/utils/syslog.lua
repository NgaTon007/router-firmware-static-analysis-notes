#! /usr/bin/lua
module("utils.syslog", package.seeall)
local libc2lua = require("libc2lua");
local libdbg   = require("utils.debug");

-- 不要用简写，因为里面有部分是关键字，例如local，
-- 参考：build_dir/toolchain-mips_r2_gcc-4.6-linaro_uClibc-0.9.33.2/uClibc-0.9.33.2/include/sys/syslog.h
facility = { -- 循环左移n位等于2^n
    auth     = 4  * (2 ^ 3),
    authpriv = 10 * (2 ^ 3),
    cron     = 9  * (2 ^ 3),
    daemon   = 3  * (2 ^ 3),
    ftp      = 11 * (2 ^ 3),
    kern     = 0  * (2 ^ 3),
    lpr      = 6  * (2 ^ 3),
    mail     = 2  * (2 ^ 3),
    mark     = 0  * (2 ^ 3),-- 这个待定
    news     = 7  * (2 ^ 3),
    security = 4  * (2 ^ 3),
    syslog   = 5  * (2 ^ 3),
    user     = 1  * (2 ^ 3),
    uucp     = 8  * (2 ^ 3),
    local0   = 16 * (2 ^ 3),
    local1   = 17 * (2 ^ 3),
    local2   = 18 * (2 ^ 3),
    local3   = 19 * (2 ^ 3),
    local4   = 20 * (2 ^ 3),
    local5   = 21 * (2 ^ 3),
    local6   = 22 * (2 ^ 3),
    local7   = 23 * (2 ^ 3),
    -- ["local"]= 24 * (2 ^ 3),
    ["local"]= 23 * (2 ^ 3),
};

priority = {
    alert   = 1,
    crit    = 2,
    debug   = 7,
    emerg   = 0,
    err     = 3,
    error   = 3,
    info    = 6,
    none    = 0x10,
    notice  = 5,
    panic   = 0,
    warn    = 4,
    warning = 4,
};

--[[
    syslog() -- syslog的lua接口
    @module：模块名
    @types：打印类型<auth|authpriv|cron|daemon|ftp|kern|lpr|mail|mark|news|security|syslog|user|uucp|local0|local1|local2|local3|local4|local5|local6|local7|local>
    @level: 日志等级<alert|crit|debug|emerg|err|error|info|none|notice|panic|warn|warning>
    @msg: 打印的日志
    @return：
            false：ubus连接错误
            {}空json table：ubus call空返回
            json table：ubus call返回
    @note：最好加上超时时间。
--]]
function syslog(module, types, level, msg)
    -- 1、参数检查
    assert((module ~= nil and #module ~= 0), string.format("ERROR in %s [%d] syslog() param:module is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((module ~= nil and type(module) == "string"), string.format("ERROR in %s [%d] syslog() param:module is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    assert((types ~= nil), string.format("ERROR in %s [%d] syslog() param:types is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((types ~= nil and type(types) == "number"), string.format("ERROR in %s [%d] syslog() param:types is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    assert((level ~= nil), string.format("ERROR in %s [%d] syslog() param:level is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((level ~= nil and type(level) == "number"), string.format("ERROR in %s [%d] syslog() param:level is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    assert((msg ~= nil and #msg ~= 0), string.format("ERROR in %s [%d] syslog() param:msg is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((msg ~= nil and type(msg) == "string"), string.format("ERROR in %s [%d] syslog() param:msg is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    -- 2、记录日志
    libdbg.lua_debug(libdbg.INFO, "ubus call module:%s, type:%d, level:%s, msg:%s", module, types, level, msg);

    -- 3、写syslog
    libc2lua.syslog(module, types, level, msg);
end