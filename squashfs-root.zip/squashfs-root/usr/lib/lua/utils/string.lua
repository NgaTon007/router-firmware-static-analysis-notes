#! /usr/bin/lua
module("utils.string", package.seeall)

local libdbg = require("utils.debug");

-- lua去除字符串行尾空格，行尾空格包括，空格，tab，回车换行\n
function string_trim_tail_space(str)
    assert((str ~= nil and string.len(str) ~= 0), string.format("ERROR in %s [%d] string_trim_tail_space() param:str is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    return (string.gsub(str, "^%s*(.-)%s*$", "%1"));
end

--[[
    string_filter() - lua过滤字符串中的不要的字符并返回字符串
    @str：待处理的字符串
    @chr：要过滤的字符（串），包括可过滤控制字符，\t，\n，""
    @return：返回字符串
--]]
function string_filter(str, chr)
    assert((str ~= nil and string.len(str) ~= 0), string.format("ERROR in %s [%d] string_filter() param:str is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    return string.gsub(str, chr, "");
end

-- lua过滤字符串中的空白符，空白符同时包含：空格，tab，回车换行\n
function string_split_space_to_table(str)
    assert((str ~= nil and string.len(str) ~= 0), string.format("ERROR in %s [%d] string_split_space_to_table() param:str is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end
   
    return sub_str_tab
end

--[[
    string_split_to_table() - lua根据字符分割字符串并返回table
    @str：待处理的字符串
    @reps：要过滤的字符（串），包括可过滤控制字符，\t，\n，""
    @return：返回字符串table
    @note：本函数是精准匹配。如果传入空字符串""，效果并不等同于上述函数：string_split_space_to_table()
--]]
function string_split_to_table(str, reps)
    assert((str ~= nil and string.len(str) ~= 0), string.format("ERROR in %s [%d] string_split_to_table() param:str is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    local resultStrTable = {};
    string.gsub(str, table.concat({'[^', reps, ']+'}), function(w)
        table.insert(resultStrTable, w);
    end)

    return resultStrTable;
end

-- lua判断是否是base64编码
function is_base64(str)
    return string.match(str, "^[A-Za-z0-9%+/%=]+$") and #str % 4 == 0
end

-- lua计算文件的md5值
-- 无需单独提供md5sum的函数，因为可以直接require("crypto").digest("md5", str)
function md5sum_file(file_path)
    assert((file_path ~= nil and string.len(file_path) ~= 0), string.format("ERROR in %s [%d] md5sum_file() param:file_path is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    local file = io.open(file_path, "r")
    if not file then
        return nil
    end

    local file_content = file:read("*all")
    file:close()

    if not file_content then
        return nil
    end

    local crypto = require("crypto")
    local md5_hash = crypto.digest("md5", file_content)
    return md5_hash
end

-- 用于判断传入的字符串是否满足X.509证书格式
function is_x509_certificate(str)
    assert((str ~= nil and string.len(str) ~= 0), string.format("ERROR in %s [%d] is_x509_certificate() param:str is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    -- 定义X.509证书的正则表达式模式
    local x509_pattern = [[-----BEGIN CERTIFICATE-----%s(.-)%s-----END CERTIFICATE-----]]
    -- 使用正则表达式匹配X.509证书的开头和结尾
    local certificate_body = string.match(str, x509_pattern)
    if not certificate_body then
        -- 未匹配到X.509证书的开头和结尾
        return false
    end
    -- 去除换行符
    certificate_body = certificate_body:gsub("[\r\n]", "")
    -- 检查是否为Base64编码
    return is_base64(certificate_body)
end