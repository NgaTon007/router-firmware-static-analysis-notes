#! /usr/bin/lua
module("utils.device_capability", package.seeall)

local json = require "cjson"

--判断设备是否支持多WAN同vlan
--返回值：1 表示支持，0 表示不支持
function check_dev_double_tag_ability()
    local file = io.open("/tmp/sd_device/sd_device.json", "r")
    if file then
        local content = file:read("*a")
        file:close()
        local data = json.decode(content)
        if data and data.double_tag and data.double_tag.double_tag_enable and data.double_tag.double_tag_enable == "1" then
            return 1
        else
            return 0
        end
    else
        return 0
    end
end

--判断设备是否支持bridge-vlan配置
--返回值：1 表示支持，0 表示不支持
function check_dev_bridge_vlan_ability()
    local file = io.open("/tmp/sd_device/sd_device.json", "r")
    if file then
        local content = file:read("*a")
        file:close()
        local data = json.decode(content)
        if data and data.bridge_vlan and data.bridge_vlan.bridge_vlan_enable and data.bridge_vlan.bridge_vlan_enable == "1" then
            return 1
        else
            return 0
        end
    else
        return 0
    end
end

-- 判断设备是否支持指定能力值
-- @param ... 依次传入能力值的多级key，例如("double_tag", "double_tag_enable")
--返回值：1 表示支持，0 表示不支持
function check_device_ability(...)
    local file = io.open("/tmp/sd_device/sd_device.json", "r");
    if not file then
        return 0;
    end
    local content = file:read("*a");
    file:close();
    local data = json.decode(content);
    if not data then
        return 0;
    end

    local keys = {...};
    local value = data;
    for _, key in ipairs(keys) do
        value = value and value[key];
        if value == nil then
            return 0;
        end
    end

    -- 如果最终值为字符串"1"，则认为支持
    if value == "1" then
        return 1
    else
        return 0
    end
end
