#! /usr/bin/lua
module("utils.table", package.seeall)

local libdbg = require("utils.debug");

-- 查看某值是否为表tbl中的key值，注意可以测试复合表，但只能测试最外层的key
function key_in_table(tbl, key)
    assert((key ~= nil and string.len(key) ~= 0), string.format("ERROR in %s [%d] key_in_table() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    for k, v in pairs(tbl) do
        if (k == key) then
            return true
        end
    end

    return false
end

-- 查看某值是否为表tbl中的value值
function val_in_table(tbl, value)
    assert((value ~= nil and string.len(value) ~= 0), string.format("ERROR in %s [%d] val_in_table() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    for k, v in pairs(tbl) do
        if (v == value) then
            return true
        end
    end

    return false
end

-- 根据key（字符串）删除table中的元素
function remove_by_key(tbl, key)
    assert((key ~= nil and string.len(key) ~= 0), string.format("ERROR in %s [%d] remove_by_key() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    --新建一个临时的table
    local tmp ={};

    --把每个key做一个下标，保存到临时的table中，转换成{1=a,2=c,3=b}
    --组成一个有顺序的table，才能在while循环准备时使用#table
    for i in pairs(tbl) do
        table.insert(tmp,i);
    end

    local ret_tab = {};
    --使用while循环剔除不需要的元素
    local i = 1;
    while i <= #tmp do
        local val = tmp[i];
        if (val == key) then
            --如果是需要剔除则remove
            table.remove(tmp, i);
        else
            --如果不是剔除，放入新的tabl中
            ret_tab[val] = tbl[val];
            i = i + 1;
        end
    end

    return ret_tab;
end

-- 表格合并
function merge(...)
    local tabs = {...}
    if not tabs then
        return {}
    end
    local origin = tabs[1]
    for i = 2, #tabs do
        if origin then
            if tabs[i] then
                for k, v in pairs(tabs[i]) do
                    table.insert(origin, v)
                end
            end
        else
            origin = tabs[i]
        end
    end

    return origin
end

-- table去重（注意：在OpenWRT中是可以的，在Windows上失败）
function unique(tbl)
    local tmp = {};
    for key, val in pairs(tbl) do
        tmp[val] = true;
    end
    local ret = {};
    for key, val in pairs(tmp) do
        table.insert(ret, key);--将key插入到新的table，构成最终的结果
    end
    return ret;
end

-- 表格深拷贝Lua table deep copy
function clone(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end
        local new_table = {}
        lookup_table[object] = new_table
        for key, value in pairs(object) do
            new_table[_copy(key)] = _copy(value)
        end
        return setmetatable(new_table, getmetatable(object))
    end
    return _copy(object)
end

-- 反转table
function reverse_table(tbl)
    local tmp_table = {};
    local key = 0;

    for i = 1, #tbl do
        key = #tbl + 1 - i;
        tmp_table[i] = tbl[key];
    end

    return tmp_table;
end
