#! /usr/bin/lua
module("utils.json", package.seeall)

local libdbg = require("utils.debug");

function param_safety_check(param)
    if (param == nil) then
        return false
    end

    if (string.match(param, "([&|;])") == nil) then
        return true
    else
        return false
    end
end

-- lua判断字符串是否是json
-- 只能用cjson，不能用dkjson
function str_is_json(param)
    if
        pcall(
            function(param)
                require("cjson").decode(param)
            end,
            param
        )
    then
        return true;
    else
        return false;
    end
end

-- lua判断文件是否是json格式文件
function file_is_cjson(jpath)
    assert((jpath ~= nil and string.len(jpath) ~= 0), string.format("ERROR in %s [%d] file_is_cjson() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    local f = assert(io.open(jpath, 'r'));
    local content = f:read("*all");
    f:close();
    -- assert(string.len(content) ~= 0, "File is empty");
    assert((string.len(content) ~= 0), table.concat({"ERROR in ", debug.getinfo(2).short_src, " [", debug.getinfo(2).currentline , "] ", "file:", jpath, " is empty."}));

    return str_is_json(content);
end

-- lua打印json字符串，json_Str是字符串
function print_json(json_Str)
    assert((json_Str ~= nil and string.len(json_Str) ~= 0), string.format("ERROR in %s [%d] print_json() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    -- 参数安全检查
    assert((param_safety_check(json_Str) == true), string.format("ERROR in %s [%d] print_json() param is unsafe.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    --可以json序列化jq .
    cmd = table.concat({"echo '", json_Str, "' | jq ."});

    --也可以不json序列化jq .
    --cmd = table.concat({"echo '", json_Str, "'"});

    os.execute(cmd);
end

-- lua从json文件获取json table
function get_json_table_from_file(jpath)
    assert((jpath ~= nil and string.len(jpath) ~= 0), string.format("ERROR in %s [%d] get_json_table_from_file() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    local f = assert(io.open(jpath, 'r'));
    local content = f:read("*all");
    f:close();
    -- assert(string.len(content) ~= 0, "File is empty");
    assert((string.len(content) ~= 0), table.concat({"ERROR in ", debug.getinfo(2).short_src, " [", debug.getinfo(2).currentline , "] ", "file:", jpath, " is empty."}));

    return require("dkjson").decode(content);
end

-- lua写json table到json文件
function set_json_table_to_file(jpath, json_tab)
    assert((jpath ~= nil and string.len(jpath) ~= 0), string.format("ERROR in %s [%d] set_json_table_to_file() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    assert((type(json_tab) == "table"), string.format("ERROR in %s [%d] set_json_table_to_file() param:json_tab is not table.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    local f = assert(io.open(jpath, 'w'));
    f:write(require("dkjson").encode(json_tab));
    f:close();

    return true;
end
