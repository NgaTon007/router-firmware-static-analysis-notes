#! /usr/bin/lua
module("utils.singleton", package.seeall)

local libdbg = require("utils.debug");

--[[
    ins_is_running - lua判断实例进程是否在运行
    @lockfile：锁文件绝对路径（全路径），注意同目录下的锁文件不要重名
    @return：true，当前有实例进程在运行；false，当前没有实例进程在运行
    @note：1、如果在进程中被多次调用，要注意区分，传入不同的lockfile
           2、如果锁文件不存在，锁文件的目录也不存在，会强制创建锁文件目录
--]]
function ins_is_running(lockfile)
    assert((lockfile ~= nil and string.len(lockfile) ~= 0), string.format("ERROR in %s [%d] ins_is_running() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    -- 上层调用脚本文件名
    local scriptname = string.match(debug.getinfo(2).short_src, "([^/]*%w+%.%w+)$");

    -- 上层调用脚本pid
    local status, currpid = pcall(require("libc2lua").getpid);-- 常规调用方法：require("libc2lua").getpid()
    if (status == false or currpid == nil) then
        currpid = io.popen("cat /proc/$$/stat | awk '{printf $4}'"):read("*all");
    end

    local lib_file = require("utils.file");
    if (lib_file.file_is_exist(lockfile) == false) then
        -- print(string.format("process is first running, lock file:%s is not exist!", lockfile));
        -- 如果文件目录不存在需要创建
        local lockdir = string.match(lockfile, "(.*/)");
        if (lib_file.file_is_exist(lockdir) == false) then
            -- print(string.format("lockfile direcory:%s is not exist, force create it!", lockdir))
            os.execute(string.format("mkdir -p %s", lockdir));
        end
        lib_file.write_file(lockfile, currpid, "w");
        return false;
    else
        local lastpid = lib_file.read_file(lockfile);
        -- 处理锁文件存在但pid为空的情况
        if (lastpid == "") then
            -- print(string.format("process is first running, lock file:%s is exist but empty!", lockfile));
            lib_file.write_file(lockfile, currpid, "w");
            return false;
        end
        -- 当前pid不等于上一次pid（锁文件pid），检查锁文件pid对应的进程是否在运行
        if (currpid ~= lastpid) then
            -- 缺陷1，lua调用shell执行效率慢；缺陷2，进程名不能太长或者因为调用关系导致ps里面的进程名显示不全
            local sh_cmd = string.format("ps | grep -w %s | grep -v 'grep' | grep %s | wc -l", lastpid, scriptname);
            -- print("sh_cmd:"..sh_cmd)
            local sh_ret = io.popen(sh_cmd):read("*all");
            if (sh_ret == nil or tonumber(sh_ret) == 0) then
                -- 除了当前实例进程，没有其他实例进程在运行
                -- print("No instance process is running");
                lib_file.write_file(lockfile, currpid, "w");
                return false;
            else
                -- 除了当前实例进程，还有其他实例进程在运行
                -- print("There are already instance processes running.");
                return true;
            end
        end
    end
end