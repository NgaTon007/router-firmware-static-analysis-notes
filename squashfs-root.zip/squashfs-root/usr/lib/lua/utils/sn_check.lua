#! /usr/bin/lua

module("utils.sn_check", package.seeall)

-- 检测SN序列号是否合法
-- 不合法序列号：前三位为123、包含小写字母、纯数字
function input_sn_check(sn)
    if (sn == nil) then
        return -1;
    end

    local sn_pre = string.sub(sn, 1, 3);
    if (sn_pre == "123" or string.find(sn, '%l') or string.find(sn, '^[0-9]*$')) then
        return -1;
    end

    return 0;
end
