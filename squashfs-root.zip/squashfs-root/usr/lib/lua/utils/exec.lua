#! /usr/bin/lua

module("utils.exec", package.seeall)

local libdbg = require("utils.debug");

-- 串行执行shell命令并获取返回值，有的命令要注意屏蔽执行的返回2>/dev/null 1>&2，后台运行不要调用本接口，直接调用io.popen或os.execute
function exec_cmd_ret(sh_cmd)
    assert((sh_cmd ~= nil and string.len(sh_cmd) ~= 0), string.format("ERROR in %s [%d] exec_cmd_ret() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    -- libdbg.lua_debug(libdbg.INFO, "----Enter exec_cmd_ret()----");

    local sh_ret_handle = io.popen(sh_cmd);
    local sh_ret = sh_ret_handle:read("*all") or "";
    -- os.execute(table.concat({"[execute cmd] ", sh_cmd}));
    -- os.execute(table.concat({"[cmd  result] ", sh_ret}));
    libdbg.lua_debug(libdbg.INFO, "[sh_cmd] %s", sh_cmd or "");
    libdbg.lua_debug(libdbg.INFO, "[sh_ret] %s", sh_ret or "");
    sh_ret_handle:close()

    return sh_ret;
end

-- 同步执行命令，逐行读取，获取输出并存储在表中
function exec_cmd_ret_tbl(sh_cmd)
    assert((sh_cmd ~= nil and string.len(sh_cmd) ~= 0), string.format("ERROR in %s [%d] exec_cmd_ret_tbl() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));
    local output = {};
    local sh_ret_handle = io.popen(sh_cmd);

    for line in sh_ret_handle:lines() do
        table.insert(output, line);
    end

    libdbg.lua_debug(libdbg.INFO, "[sh_cmd] %s", sh_cmd or "");
    for key, value in pairs(output) do
        libdbg.lua_debug(libdbg.INFO, "[sh_ret] %s", value or "");
    end
    sh_ret_handle:close()

    return output
end

-- 异步执行shell命令
function fork_exec_cmd(sh_cmd)
    assert((sh_cmd ~= nil and string.len(sh_cmd) ~= 0), string.format("ERROR in %s [%d] fork_exec_cmd() param is nil or length is 0.", debug.getinfo(2).short_src, debug.getinfo(2).currentline));

    libdbg.lua_debug(libdbg.INFO, "[sh_cmd] %s", sh_cmd);

    local nixio = require "nixio";
    local pid = nixio.fork();
    if (pid > 0) then
        return;
    elseif (pid == 0) then
        nixio.chdir("/");
        local null = nixio.open("/dev/null", "w+");
        if (null) then
            nixio.dup(null, nixio.stderr);
            nixio.dup(null, nixio.stdout);
            nixio.dup(null, nixio.stdin);
            if (null:fileno() > 2) then
                null:close();
            end
        end
        nixio.exec("/bin/sh", "-c", sh_cmd);
    end
end

-- 注意io.popen也是异步执行命令的，但是os.execute是同步执行的