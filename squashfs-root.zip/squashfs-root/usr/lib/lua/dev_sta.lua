#!/usr/bin/lua
--dev_sta lua封装库
module('dev_sta',package.seeall)
local console = require "console"
local call_type={ac_config=0, dev_config=1, dev_sta=2, dev_cap=3}

local function debug(msg)
    console.debug("dev_sta", msg)
end

function get_ctype()
	return 2 --ac_config=0 dev_config=1 dev_sta=2 dev_cap=3
end

--主函数
function fetch(cmd, module, param, back, ip, password, force, not_change_configId, multi, caller, not_commit)
    local uf_call = require "libuflua"
    local ctype
    local caller_ip

    ctype = get_ctype()
    param = param or ""
    ip = ip or ""
    password = password or ""
    caller = caller or ""
    caller_ip = os.getenv('HTTP_X_FORWARDED_FOR') or os.getenv('REMOTE_ADDR') or ""

    if force and force == "1" then
    	force = true
    else
    	force = false
    end

    if back and back == "1" then
    	back = true
    else
    	back = false
    end   

    if not_change_configId then
    	not_change_configId = true
    else
    	not_change_configId = false
    end

    if not_commit then
    	not_commit = true
    else
    	not_commit = false
    end

    if multi then
    	multi = true
    else
    	multi = false
    end

    local stat = uf_call.client_call(ctype, cmd, module, param, back, ip, password, force, not_change_configId, multi, caller, caller_ip, not_commit)
    return stat
end


function fetch_string(cmd, module, param, back, ip, password, force, not_change_configId, multi, caller, not_commit)
    local ret = fetch(cmd, module, param, back, ip, password, force, not_change_configId, multi, caller, not_commit)
    if ret.code == "1" or ret.code == 1 then
    	if ret.err then
        	debug("return ".. ret.err)
        end
        return ret.err
    else
        return ret.data
    end
end