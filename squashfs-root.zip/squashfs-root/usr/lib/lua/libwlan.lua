#!/usr/bin/lua
--无线公共lua库
module("libwlan", package.seeall)
local uci = require "luci.model.uci".cursor()
local dev_sta = require "dev_sta"
local json = require "cjson"

function channel_to_freq_mhz_2g(channel)
    local ch = tonumber(channel)
    if ch <= 0 then
        return 0
    end
    if (ch >= 1 and ch <= 13) then
        return 2407 + ch * 5
    end
    return 0
end

function channel_to_freq_mhz(channel)
    local ch = tonumber(channel)
    if ch <= 0 then
        return 0
    end
    if ch >= 182 and ch <= 200 then
        return 4000 + ch * 5
    else
        return 5000 + ch * 5
    end
    return 0
end

function freq_to_channel(freq)
    if freq % 5 ~= 0 then
        return false
    end
    -- freq range 4910 ~ 5000
    if freq >= 4910 and freq <= 5000 then
        return (freq - 4000) / 5
    -- freq range 5000 ~ 5900
    elseif freq < 5910 then
        return (freq - 5000) / 5
    end
    return false
end

function get_center_channel(channel_str,bw)
    local center_channel = 0
    local channel = tonumber(channel_str)
    if bw == 20 then
        center_channel = channel
    elseif bw == 40 then
        if channel == 36 or channel == 44 or channel == 52 or channel == 60 or channel == 100 or channel == 108 or channel == 116 or channel == 124 or channel == 132 or channel == 149 or channel == 157 then
            center_channel = channel + 2
        elseif channel == 40 or channel == 48 or channel == 56 or channel == 64 or channel == 104 or channel == 112 or channel == 120 or channel == 128 or channel == 136 or channel == 153 or channel == 161 then
            center_channel = channel - 2
        end
    elseif bw == 80 then
        if (channel >=36 and channel <=48) then
            center_channel = 42
        elseif (channel >=52 and channel <=64) then
            center_channel = 58
        elseif (channel >=100 and channel <=112) then
            center_channel = 106
        elseif (channel >=116 and channel <=128) then
            center_channel = 122
        elseif (channel >=132 and channel <=144) then
            center_channel = 138
        elseif (channel >=149 and channel <=161) then
            center_channel = 155
        end
    end
    return center_channel
end

function get_cur_bandwidth(radio)
    local cur_bw = uci:get("wireless", radio, "bw") or ""
    local data
    if cur_bw == "auto" then
        data = json.decode(dev_sta.fetch("get", "country_channel",'{"qry_type":"bandwidth_list", "range":"5G", "func":"single"}').data)
        -- 检查是否存在 "bandwidth_5G" 键,或对应的值是一个非空数组
        if not data["bandwidth_5G"] or #data["bandwidth_5G"] == 0 then
            return nil
        end
        local max_bw = 0
        for _, bw_str in ipairs(data["bandwidth_5G"]) do
            local bw = tonumber(bw_str)
            if bw and bw > max_bw then
                max_bw = bw
            end
        end
        return max_bw
    elseif cur_bw == "20" then
        return 20
    elseif cur_bw == "40" then
        return 40
    elseif cur_bw == "80" then
        return 80
    end

    return nil
end

function is_std_channel(bw,freq)
    local channel = freq_to_channel(freq)
    if(bw == 20) then
        if channel == 36 or channel == 44 or channel == 52 or channel == 60 or channel == 100 or channel == 108 or channel == 116 or channel == 124 or channel == 132 or channel == 149 or channel == 157 or channel == 140 or channel == 144 then
            return true
        elseif channel == 40 or channel == 48 or channel == 56 or channel == 64 or channel == 104 or channel == 112 or channel == 120 or channel == 128 or channel == 136 or channel == 153 or channel == 161 or channel == 165 then
            return true
        end
    elseif(bw == 40) then
        if channel == 38 or channel == 46 or channel == 54 or channel == 62 or channel == 102 or channel == 110 or channel == 118 or channel == 126 or channel == 134 or channel == 142 or channel == 151 or channel == 159 then
            return true
        end
    elseif(bw == 80) then
        if channel == 42 or channel == 58 or channel == 106 or channel == 122 or channel == 138 or channel ==  155 then
            return true
        end
    end
    return false
end