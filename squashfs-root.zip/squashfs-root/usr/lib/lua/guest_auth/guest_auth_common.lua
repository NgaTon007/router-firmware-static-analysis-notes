#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("guest_auth.guest_auth_common", package.seeall)

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/guest_auth/max_users/"
local ACCOUNT_JSON_FILE = "/etc/guest_auth/account.json"
local VOUCHER_PUB_DIR = "/etc/guest_auth/voucher/"

local max_user_sta_by_group = {}
local voucher_group_list = {}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path)
end

--debug初始化 
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_common.log", 500, module_debug.INFO, "1")
end

local function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

local function get_max_user_sta_num()
    uci:foreach("user_mgr", "user_grp", function(s)
        local name = s[".name"]
        local max_users = uci:get("user_mgr", name, "maxUsers")
        if (max_users ~= nil) then
            local groupuuid = uci:get("user_mgr", name, "uuid")
            if (groupuuid ~= nil) then
                max_user_sta_by_group[groupuuid] = tonumber(max_users)
                module_debug.lua_debug(module_debug.DEBUG, "groupuuid: %d \n", groupuuid);
                module_debug.lua_debug(module_debug.DEBUG, "max_user_sta_by_group[groupuuid]: %d \n", max_user_sta_by_group[groupuuid]);
            else
                module_debug.lua_debug(module_debug.ERROR, "uuid of cloud user_group is nil\n");
                return
            end
        end
    end
    )
end

local function voucher_file_get()
    for file in lfs.dir(VOUCHER_PUB_DIR) do
        if (file ~= "." and file ~= "..") then
            local file_name = VOUCHER_PUB_DIR.."/"..file
            local attr = lfs.attributes(file_name)
            assert(type(attr)=="table")
            if (attr.mode == "file") then
                table.insert(voucher_group_list, file)
            end
        end
    end
end

local function update_account_max_users(param)
    -- 没有数据时直接返回 
    if (tool.file_exist(ACCOUNT_JSON_FILE) == false) then
        module_debug.lua_debug(module_debug.INFO, "INFO:account.json not exist\n")
        return -1
    end
    -- {"accountInfo":[{"password":"pwd@voucher","name":"fDB8v3","groupUuid":"0oPKY","maxUsers":5}]}
    local account = tool.file_read(ACCOUNT_JSON_FILE)
    if (account == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:account.json read err\n")
        return -1
    end
    local account_tab = cjson.decode(account)
    if (account_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: account_tab is nil")
        return -1
    end


    for k, v in pairs(account_tab["accountInfo"]) do
        if (v["groupUuid"] == param) then
            v["maxUsers"] = max_user_sta_by_group[param]
            module_debug.lua_debug(module_debug.INFO, "INFO: groupUuid is %s, maxUsers is %d \n", v["groupUuid"], v["maxUsers"])
        end
    end

    local result = cjson.encode(account_tab)
    tool.file_write(ACCOUNT_JSON_FILE, result, "w")
    module_debug.lua_debug(module_debug.DEBUG, "update_account_max_user end\n");
end

local function update_voucher_max_users(param)
    -- sed -i '1c 8' /etc/guest_auth/voucher/123
    for k,v in pairs(max_user_sta_by_group) do
        if (k == param) then
            local cmd = string.format("sed -i '1c %d' %s", v, VOUCHER_PUB_DIR..param)
            module_debug.lua_debug(module_debug.INFO, "INFO: cmd is %s \n", cmd)
            os.execute(cmd);
        end
    end
end

function update_max_users(param)
    debug_init()
    local cmd = ""
    get_max_user_sta_num()
    voucher_file_get()
    -- account
    update_account_max_users(param)
    cmd = string.format("curl --connect-timeout 2 127.0.0.1:2060/ga_reloadcloud_user?user_type=%s 2>/dev/null > /dev/null",
            "cloud_account_user")
    os.execute(cmd);
    -- voucher
    update_voucher_max_users(param)
    cmd = string.format("curl --connect-timeout 2 127.0.0.1:2060/ga_reloadcloud_user?user_type=%s 2>/dev/null > /dev/null",
            "cloud_voucher_user")
    os.execute(cmd);
end

function support_local_radius_flag()
    local web_node = require("product").get_product("capacity.web")
    local cmd = string.format("cat /tmp/sd_device/sd_device.json | jq .%s.localAuthSupportRadius | sed 's/\"//g'", web_node)
    local t = io.popen(cmd)
    local str = t:read("*all")
    t:close()
    if (str == "1\n") then
        module_debug.lua_debug(module_debug.INFO, "localAuthSupportRadius is %s \n", str);
        return true
    else
        return false
    end
end
debug_init()
