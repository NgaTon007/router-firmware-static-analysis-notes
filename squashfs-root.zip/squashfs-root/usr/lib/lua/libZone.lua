#! /usr/bin/env lua

libZone = {}

function libZone.update_nat_ena(intf, enable)
    local cjson_safe = require "cjson.safe"
    local module_debug = require "utils.debug"
    local dev_config = require "dev_config"
    local node = {}
    
    --module_debug.debug_init("/tmp/fwmng/", "libNatEna.log", 500, module_debug.DEBUG, "1")
    
    if (intf == nil or type(intf) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the update enable's intf is null")
        
        return false
    end
    
    if (string.find(intf, "wan") == nil) then
        module_debug.lua_debug(module_debug.ERROR, "the update enable's intf [%s] is error", intf)
        
        return false
    end
    
    if (string.match(intf, "[^%w_-]") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "the intf %s isn't illegal", intf)
        return false
    end    
    module_debug.lua_debug(module_debug.INFO, "the update enable's intf is %s", intf)
    
    if (enable == nil or type(enable) ~= "string") then
        enable = "1"
    end
    
    if (enable ~= "0" and enable ~= "1") then
        enable = "1"
    end
    
    if (enable == "1") then
        node["op"] = "del"
    end
    
    if (enable == "0") then
        node["op"] = "add"
    end
    
    node["uuid"] = "ZoneRoute"
    node["mem_intf"] = intf

    cmdstr = cjson_safe.encode(node)
    if (cmdstr ~= nil) then
        dev_config.fetch("update","safeZone", cmdstr)
        module_debug.lua_debug(module_debug.INFO, "the update enable's intf is %s success", intf)
        
        return true
    else
        module_debug.lua_debug(module_debug.INFO, "the update enable's intf is %s failed", intf)
        
        return false
    end
end

function libZone.update_intflist_nat_ena(intf_list_json)
    local cjson_safe = require "cjson.safe"
    local module_debug = require "utils.debug"
    local dev_config = require "dev_config"
    
    -- 参数验证
    if (intf_list_json == nil or type(intf_list_json) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the intf_list_json parameter is null or not a string")
        return false
    end
    
    -- 解析输入的 JSON 参数
    local intf_list = cjson_safe.decode(intf_list_json)
    if (intf_list == nil or type(intf_list) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "the intf_list_json is not valid JSON")
        return false
    end
    
    -- 验证接口名称和 enable 值的合法性
    for intf, enable in pairs(intf_list) do
        if (type(intf) ~= "string" or string.find(intf, "wan") == nil) then
            module_debug.lua_debug(module_debug.ERROR, "the intf [%s] is not a valid wan interface", tostring(intf))
            return false
        end
        
        if (string.match(intf, "[^%w_-]") ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "the intf %s isn't illegal", intf)
            return false
        end
        
        if (enable ~= "0" and enable ~= "1") then
            module_debug.lua_debug(module_debug.ERROR, "the enable value for %s is invalid: %s", intf, tostring(enable))
            return false
        end
    end
    
    module_debug.lua_debug(module_debug.INFO, "start update intflist nat ena with param: %s", intf_list_json)
    
    -- 构建新的 mem 列表
    local new_mem = {}
    
    -- 遍历所有接口，enable 为 "0" 的加入列表（禁用 nat）
    for intf, enable in pairs(intf_list) do
        if (enable == "0") then
            table.insert(new_mem, intf)
        end
    end
    
    -- 构建命令字符串，使用 mem_intflist 格式
    local cmdstr = cjson_safe.encode({
        op = "update",
        uuid = "ZoneRoute",
        mem_intflist = new_mem
    })

    if (cmdstr ~= nil) then
        dev_config.fetch("update", "safeZone", cmdstr)
        module_debug.lua_debug(module_debug.INFO, "update intflist nat ena success: %s", cmdstr)
        return true
    else
        module_debug.lua_debug(module_debug.ERROR, "failed to encode command string")
        return false
    end
end

return libZone
