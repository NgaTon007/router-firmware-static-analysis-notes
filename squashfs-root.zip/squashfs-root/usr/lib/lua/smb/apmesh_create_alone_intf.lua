#! /usr/bin/lua

module("apmesh_create_alone_intf", package.seeall);

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"
local sys = require "luci.sys"

--debug
local function debug(msg)
    console.debug("apmesh_create_alone_intf", msg)
end

local function get_wan_portid()
    local port_status 
    local wan_portid

    local fd = io.popen("dev_sta get -m port_status |jq .", "r")
    port_status = fd:read("*a")
    port_status = dkjson.decode(port_status)
    if port_status and port_status.List then
        for k, v in pairs(port_status.List) do
            if v.name and v.name == 'WAN' then
                wan_portid = v.portId
                break
            end
        end
    end
    fd:close()

    return wan_portid
end

local function get_alone_intf(wan_portid)
    local alone_intf_info 
    local alone_intf
    local port_cmd = string.format("dev_sta get -m port '{\"caller\":\"apmesh\",\"port\":[{\"portId\":\"%s\",\"key\":[\"interface\"]}]}'",  wan_portid)
    debug("port_cmd: " .. port_cmd)

    local fd = io.popen(port_cmd, "r")
    alone_intf_info = fd:read("*a")
    alone_intf_info = dkjson.decode(alone_intf_info)
    if alone_intf_info then
        for k, v in pairs(alone_intf_info) do
            if k and k == wan_portid then
                alone_intf = v.interface
                break 
            end
        end
    end
    fd:close()

    return alone_intf
end

function main()
    debug(">>enter apmesh_create_alone_intf script")
    if arg[1] == nil or arg[1] == "" then 
        debug("arg[1]: invalid param!")
        return
    end

    debug("param: " .. arg[1])
    local param = arg[1]
    local wan_portid = get_wan_portid()
    local alone_intf = ""
    debug("wan_portid: " .. wan_portid)

    if param and param == 'enable' then
         if wan_portid and wan_portid ~= "" then
             local cmd1 = string.format("dev_sta set -m port '{\"caller\":\"apmesh\",\"save\":\"1\",\"port\":[{\"portId\":\"%s\",\"mode\":\"alone\",\"action\":\"add\",\"type\":\"access\",\"pvid\":\"4094\"}]}' > /dev/null", wan_portid)
             debug("cmd1: " .. cmd1)
             os.execute(cmd1)
             local cmd2 = string.format("dev_config add -m interface '{\"caller\":\"apmesh\",\"type\":\"alone_intf\",\"name\":\"alone1\",\"data\":{\"vid\":\"4094\",\"portId\":\"%s\"}}' > /dev/null", wan_portid)
             debug("cmd2: " .. cmd2)
             os.execute(cmd2)

            alone_intf = get_alone_intf(wan_portid)

            local cmd3 = string.format("uci set apmgr.global.alone_intf_name='%s'", alone_intf)
             debug("cmd3: " .. cmd3)
             os.execute(cmd3)

             local cmd4 = string.format("uci set apmgr.global.alone_intf_enable='1'")
             debug("cmd4: " .. cmd4)
             os.execute(cmd4)

             local cmd5 = string.format("uci commit apmgr")
             debug("cmd5: " .. cmd5)
             os.execute(cmd5)
        end
    elseif  param and param == 'disable' then
        if wan_portid and wan_portid ~= "" then
            alone_intf = get_alone_intf(wan_portid)

             local cmd1 = string.format("dev_config del -m interface '{\"caller\":\"apmesh\",\"type\":\"alone_intf\",\"name\":\"alone1\",\"data\":{\"vid\":\"4094\",\"portId\":\"%s\"}}' > /dev/null", wan_portid)
             debug("cmd1: " .. cmd1)
             os.execute(cmd1)
             local cmd2 = string.format("dev_sta set -m port '{\"caller\":\"apmesh\",\"save\":\"1\",\"port\":[{\"portId\":\"%s\",\"mode\":\"alone\",\"action\":\"del\",\"type\":\"access\",\"pvid\":\"4094\"}]}' > /dev/null", wan_portid)
             debug("cmd2: " .. cmd2)
             os.execute(cmd2)

             local cmd3 = string.format("uci set apmgr.global.alone_intf_name='%s'", alone_intf)
             debug("cmd3: " .. cmd3)
             os.execute(cmd3)

             local cmd4 = string.format("uci set apmgr.global.alone_intf_enable='0'")
             debug("cmd4: " .. cmd4)
             os.execute(cmd4)

             local cmd5 = string.format("uci commit apmgr")
             debug("cmd5: " .. cmd5)
             os.execute(cmd5)
        end
    end

    debug(">>leave apmesh_create_alone_intf script")
end

main()

















