#!/usr/bin/lua

--*************************以下为加载库**************************
local console = require 'console'
local dkjson = require "dkjson" 
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"
local sys = require "luci.sys"
local dev_sta = require "dev_sta"
--*************************以下为全局变量************************


local function debug(msg)
    console.debug("apmeshMergeNetwork", msg)
end

local function get_uplink_mac()
    local uplink_mac = ""
    local apcli_info
    local fd = io.popen("dev_sta get -m apcliInfo |jq .", "r")
    apcli_info = fd:read("*a")
    apcli_info = dkjson.decode(apcli_info)
    fd:close()
    if apcli_info and apcli_info.uplink_mac ~= nil then
        uplink_mac = apcli_info.uplink_mac
    else
        debug("apcli_info is nil !!!")
    end
    return uplink_mac
end

local function get_target_networkid(uplink_mac)
    local toNetworkId = ""
    local get_nei
    local fd = io.popen("dev_sta get -m neighbor | jq .", "r")
    get_nei = fd:read("*a")
    get_nei = dkjson.decode(get_nei)
    if get_nei and get_nei.neighbor then
        for k, v in pairs(get_nei.neighbor) do
            if v.devMac == string.upper(uplink_mac) then
                debug("According to uplink mac: "..v.devMac..", select target AC Device: " .. v.deviceType)
                debug("role=" .. v.role .. "; v.networkId=" .. v.networkId)
                toNetworkId = v.networkId
                break
            end
        end
    end
    fd:close()
    return toNetworkId
end

local function get_current_networkid()
    local fromNetworkId = ""
    local get_master
    local fd = io.popen("dev_sta get -m master | jq .", "r")
    get_master = fd:read("*a")
    get_master = dkjson.decode(get_master)
    
    if get_master and get_master.networkId then
        fromNetworkId   = get_master.networkId
    end
    fd:close()
    return fromNetworkId
end

local function get_nei_count()
    local nei_count = luci.sys.exec("dev_sta get -m neighbor |jq .count -r"):gsub('%\n', '')
    return nei_count
end

local function get_password()
    local fd = io.popen("cat /etc/sd_config/admin", "r")
    if not fd then
        debug("Failed to open the configuration file.")
        return "admin"
    end

    local passwd = fd:read("*a")
    fd:close()

    if not passwd or passwd == "" then
        debug("Failed to read the encrypted password.")
        return "admin"
    end

    return passwd
end

function main()
	local data = {
        toNetworkId     = "0",
        fromNetworkId   = "0",
        status          = "failed"
    }
    local toNetworkId
    local fromNetworkId
	local nei_count
    local uplink_mac
    local merge_network
    local retry = 0

    debug("################## START ##################")
    debug(">>> step1: dev_sta get -m apcliInfo |jq .")
    while (retry < 10)
    do
        uplink_mac  = get_uplink_mac()
        if uplink_mac and uplink_mac ~= "" then
            debug("uplink_mac: " .. uplink_mac .. "; just jump to next step.")
            break
        end
        debug("uplink_mac is nil, try to get again! sleep 6s")
        os.execute("sleep 6")
        retry = retry + 1
    end
    if uplink_mac and uplink_mac ~= "" and uplink_mac ~= "00:00:00:00:00:00" then
        debug("uplink is valid, Let's go on!")
    else
        debug("uplink sysmac is invalid, just do nothing !!!!!!")
        return
    end

    debug(">>> step2: get nei")
    retry = 0
    while (retry < 30)
    do
		nei_count = get_nei_count()
		
		if nei_count == '0' then
			debug("nei is empty, no need to get_target_networkid!")
		else 
			debug("nei is ok, no need to get_target_networkid!")
			toNetworkId = get_target_networkid(uplink_mac)
			if toNetworkId and toNetworkId ~= "" then
				debug("toNetworkId: " .. toNetworkId .. "; just jump to next step.")
				break
			end
		end
       
        debug("toNetworkId is nil, try to get again! sleep 6s")
        os.execute("sleep 6")
        retry = retry + 1
    end
	
	if toNetworkId == nil then
		debug("get_target_networkid is failed! just do nothing !!!!!!")
		return
	end

    debug(">>> step3: get master")
    retry = 0
    while (retry < 5)
    do
        fromNetworkId = get_current_networkid()
        if fromNetworkId and fromNetworkId ~= "" then
            debug("fromNetworkId: " .. fromNetworkId .. "; just jump to next step.")
            break
        end
        debug("fromNetworkId is nil, try to get again! sleep 6s")
        os.execute("sleep 6")
        retry = retry + 1
    end

    if toNetworkId ~= nil and fromNetworkId ~= nil then
        local param = {}
        debug(">>> step4: dev_sta set -m networkId_merge xxx")

        os.execute("rm -rf /tmp/apmesh_is_running")
        debug("rm -rf /tmp/apmesh_is_running")
        param.password = get_password()
        param.type = 'enc'
        param.fromNetworkId = fromNetworkId
        param.toNetworkId = toNetworkId
        debug("merge_network fromNetworkId: " .. fromNetworkId .. ", toNetworkId: " .. toNetworkId)
        dev_sta.fetch("set", "networkId_merge", dkjson.encode(param))

        set_declare_count= string.format("dev_sta set -m declare_count '{\"declare_count\":50}'")
        debug("set_declare_count cmd: " .. set_declare_count)
        os.execute(set_declare_count)

        data.toNetworkId    = toNetworkId
        data.fromNetworkId  = fromNetworkId
        data.status         = "success"
    end

    data = dkjson.encode(data)
    debug("################## END ####################")
    return data
end	

main()
