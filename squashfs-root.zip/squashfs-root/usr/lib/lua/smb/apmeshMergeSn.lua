#!/usr/bin/env lua

local console = require "console"
local json = require "dkjson"
local uci = require "luci.model.uci".cursor()
local dev_sta = require "dev_sta"
local mac_status = {}
local nei_info
local networkId
MERGE_LOG="/tmp/sd_config/apmeshMergeSn.log"
SLEEP_PERIOD=3
OVER_TIME=180
WAIT_TIME=3

local function debug(msg)
    console.debug("apmeshMergeSn", msg)
end

function ubus_call_merge_network(param)
	dev_sta.fetch("set", "networkId_merge", param, "1")
	debug("dev_sta set -m merge_network ".. param)
	--{"password":"xxxxx","type":"enc/noenc", "fromNetworkId":"xxxx", "toNetworkId":"xxxx","fromSn":["sn1","sn2"],"esw_fromSn":["sn3","sn4"]}
    --local ubus = require("ubus").connect(nil, 3)
    --if ubus == nil then
        --return
    --end
    --ubus:call("mqtt", "merge_network", param)
end


local function state_device(mac, state)
	local find = false
	local neighbor_arr = nei_info.neighbor
	if state == 0 then
		for i=1,#neighbor_arr do
			if mac == neighbor_arr[i].devMac then
				find = true
				if networkId == neighbor_arr[i].networkId then
					return 4
				else
					local tmp_param = string.format("{\"password\":\"admin\",\"type\":\"noenc\", \"fromNetworkId\":\"%s\", \"toNetworkId\":\"%s\", \"fromSn\":[\"%s\"]}", neighbor_arr[i].networkId, networkId, neighbor_arr[i].devSN)
					ubus_call_merge_network(tmp_param)
					return (state+1)
				end
			end
		end
		return 0
	elseif state <= 3 then
		for i=1,#neighbor_arr do
			if mac == neighbor_arr[i].devMac then
				find = true
				if networkId == neighbor_arr[i].networkId then
					return 4
				else
					if state == 3 then
						local tmp_param = string.format("{\"password\":\"admin\",\"type\":\"noenc\", \"fromNetworkId\":\"%s\", \"toNetworkId\":\"%s\", \"fromSn\":\"%s\"}", neighbor_arr[i].networkId, networkId, neighbor_arr[i].devSN)
						ubus_call_merge_network(tmp_param)
						return 1
					else
						return (state+1)
					end
				end
			end
		end
		if find == false then
			if state == 3 then
				return 0
			else
				return (state+1)
			end
		end
	elseif state == 4 then
		return 4
	else
		return 0
	end
end

--获取文件路径
local function main()
	local time
	local finish_num
	local mac_num
	local nixio = require "nixio"
	
	local fd = nixio.open("/tmp/sd_config/apmeshMergeSn.log", "a+")
	nixio.dup(fd, nixio.stderr)
	if not arg[1] then
        debug("not param!")
        os.exit()
    end
	local param_table = json.decode(arg[1]);
	local mac_table = string.split(param_table.mac_str, "#")
	for i=1,#mac_table do
		mac_table[i]=string.upper(mac_table[i])
		mac_status[i]=0
		debug("mac ".. i.." "..mac_table[i])
		mac_num = i
	end
	networkId = json.decode(dev_sta.fetch("get", "networkId").data).networkId
	debug("self networkId "..networkId)
	os.execute("sleep "..WAIT_TIME)
	time = 0
	while(true)
	do
		finish_num = 0
		nei_info = json.decode(dev_sta.fetch("get", "neighbor").data)
		if nei_info ~= nil and #nei_info.neighbor ~= 0 then
			for i=1,#mac_table do
				mac_status[i] = state_device(mac_table[i], mac_status[i])
				debug("mac:"..mac_table[i].." state:"..mac_status[i])
				if mac_status[i] == 4 then
					finish_num = finish_num + 1
				end
			end
		end
		if finish_num == mac_num then
			debug("All mac finish!")
			os.exit()
		end
		
		time = time + SLEEP_PERIOD
		if time == OVER_TIME then
			debug("Over time!")
			os.exit()
		end
		os.execute("sleep "..SLEEP_PERIOD)
	end
end

main()
