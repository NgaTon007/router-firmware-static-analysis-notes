#! /usr/bin/lua

function channelSet(radio_index, channel)
    local lib_mesh = require "utils.mesh_com"
    local radiolist_cache = lib_mesh.get_radio_info()
    lib_mesh.apmesh_update_radio_channel_info(radio_index, channel)
end

local radio_index = arg[1] or '2'
local channel = arg[2] or ''

channelSet(radio_index, channel)