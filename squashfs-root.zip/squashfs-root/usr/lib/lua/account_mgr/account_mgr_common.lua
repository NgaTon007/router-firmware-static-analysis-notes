#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("account_mgr.account_mgr_common", package.seeall)

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libfil = require("utils.file");
local sd_crypto = require "sd_crypto"
local DEBUG_LOG_DIR = "/tmp/account_mgr/"
local conf_file = "/etc/account_mgr/account"
local order_relation = "/tmp/account_mgr/order_relation"
local chap_secrets_tmp = "/tmp/pppoe-server/chap-secrets"
local pap_secrets_tmp = "/tmp/pppoe-server/pap-secrets"
local relation_default_header = "username,type,user_group,group_uuid,validity,dealline\n"
local pppoe_charge_auth_enable = "dev_config get -m pppoeChargeAuth"
local modul = "pppoe-server"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path)
end

if (tool.file_exist("/tmp/pppoe-server/") == false) then
    local path = "mkdir -p /tmp/pppoe-server/ >/dev/null 2>&1"
    os.execute(path)
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_common.log", 500, module_debug.INFO, "1")
end

local function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

local function pppoeserver_user_group_get()
    local flow_name_map = {}
    uci:foreach("flowctrl", "pppoe_policy", function(s)
        local flow_name = uci:get("flowctrl", s[".name"], "pppoe_group")
        local comment = uci:get("flowctrl", s[".name"], "comment")

        if not flow_name_map[flow_name] then
            flow_name_map[flow_name] = {
                comment = comment
            }
        end
    end)
    
    return flow_name_map
end

local function maccChargePkg_validity_get()
    local pkg_uuid_map = {}
    local file = "/etc/sd_config/single/maccChargePkg.json"
    if (libfil.file_is_exist(file) == false) then
        return nil;
    end
    
    local content = libfil.read_file(file);
    if (content == nil) then
        return nil;
    end
    
    local tconfig = cjson.decode(content);
    if (tconfig == nil) then
        return nil;
    end
    
    for i, v in ipairs(tconfig["list"]) do
        local uuid = v["uuid"]
        local validity = v["validity"]
        if (validity == nil) then
            validity = ""
        end
        pkg_uuid_map[uuid] = validity
    end
    return pkg_uuid_map
end

function pppoe_order_relation_get()
    local flow_name_map
    local pppoeserver_user_list = {}
    
    flow_name_map = pppoeserver_user_group_get()
    module_debug.lua_debug(module_debug.INFO, "flow_name_map: %s", cjson.encode(flow_name_map));
    pppoeserver_user_list["list"] = {}
    uci:foreach("pppoeserver_user", "pppoeserver_user", function(s)
        local user = {}
        local section_name = s[".name"]
        user["name"] = uci:get("pppoeserver_user", section_name, "name")
        local passwd = uci:get("pppoeserver_user", section_name, "passwd")
        local flow_name = uci:get("pppoeserver_user", section_name, "flow_name")
        local dealline = uci:get("pppoeserver_user", section_name, "dealline")
        local enc_type = uci:get("pppoeserver_user", section_name, "enc_type")
        user["enable"] = uci:get("pppoeserver_user", section_name, "enable")
        if enc_type == "1" then
            user["passwd"] = aes256_decode(passwd)
        else
            user["passwd"] = passwd
        end
        -- �˺�δ���������ײ�ʱ����Ĭ��pppoe�ײ�
        if flow_name == nil then
            user["group_name"] ="Default_PPPoE_Group"
        else
            if flow_name_map[flow_name] == nil then
                user["group_name"] = "Default_PPPoE_Group"
            else
                user["group_name"] = flow_name_map[flow_name]["comment"]
            end
            module_debug.lua_debug(module_debug.DEBUG, "flow_name: %s; flow_name_map[flow_name]:%s", flow_name, user["group_name"]);
        end
        if dealline == nil then
            user["dealline"] = ""
        else
            user["dealline"] = dealline
        end
        user["type"] = "pppoe"
        user["group_uuid"] = ""
        user["validity"] = ""
    
        table.insert(pppoeserver_user_list["list"], user)
    end
    )
    if (#pppoeserver_user_list["list"] == 0) then
        module_debug.lua_debug(module_debug.INFO, "pppoeserver_user_list is nil");
        return nil
    end
    module_debug.lua_debug(module_debug.INFO, "pppoeserver_user_list: %s", cjson.encode(pppoeserver_user_list));
    return pppoeserver_user_list
end

function charge_order_relation_get(conf_file)
    local charge_user_list = {}
    local count = 0
    local csvData = LoadCSV(conf_file)
    if (csvData == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information format error")
        return nil
    end
    for k,v in pairs(csvData) do
        if (k > 1) then
            local account_name
            count = count + 1
            for k2, v2 in pairs(v) do
                if (k2 == 1) then
                    account_name = v2
                    if not charge_user_list[account_name] then
                        charge_user_list[account_name] = {}
                    end              
                elseif (k2 == 2) then
                    charge_user_list[account_name]["passwd"] = v2  
                elseif (k2 == 3) then
                    charge_user_list[account_name]["dealline"] = v2    
                elseif (k2 == 4) then
                    charge_user_list[account_name]["note"] = v2  
                elseif (k2 == 5) then
                    charge_user_list[account_name]["enable"] = v2
                elseif (k2 == 6) then
                    charge_user_list[account_name]["pkg_uuid"] = v2
                elseif (k2 == 7) then
                    charge_user_list[account_name]["pkg_name"] = v2
                elseif (k2 == 8) then
                    charge_user_list[account_name]["pkg_active_time"] = v2
                elseif (k2 == 9) then
                    charge_user_list[account_name]["pkg_expire_time"] = v2
                elseif (k2 == 10) then
                    charge_user_list[account_name]["spt_service"] = v2
                elseif (k2 == 11) then
                    charge_user_list[account_name]["status"] = v2
                elseif (k2 == 12) then
                    if v2 == '1' then
                        charge_user_list[account_name]["passwd"] = aes256_decode(charge_user_list[account_name]["passwd"])
                    end
                end
            end
        end
    end
    module_debug.lua_debug(module_debug.INFO, "charge_user_list:%s;", cjson.encode(charge_user_list));
    return charge_user_list
end

function aes256_encode(src)
    if (src == nil) then
        return nil
    end

    recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(src,#src,'C')
    if (recode ~= 0) then
        return nil
    else
        ciphertext = string.gsub(ciphertext, "\n", "")
        return ciphertext
    end
end

function aes256_decode(src)
    if (src == nil) then
        return nil
    end

    recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(src, #src, 'C')
    if (recode ~= 0) then
        return nil
    else
        plaintext_restore = string.gsub(plaintext_restore, "\n", "")
        return plaintext_restore
    end
end

function account_mgr_read_para(param)
    local t = io.popen(param)
    local str = t:read("*all"):gsub("\n", "")
    t:close()
    module_debug.lua_debug(module_debug.INFO, "str:%s\n", str)
    if (str == "") then
        str = "0"
    end
    return str
end

function LoadCSV(filePath)
    local file = assert(io.open(filePath, 'r'))
    local content = string.gsub(file:read("*all"), "\r\n", "\n")
    file:close()
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [LoadCSV] config is nil")
        return
    end
    -- Read Word One By One   
    local c = content -- content
    local p = 0 -- content check pos
    local w = "" -- content check word
    local w_next = "" -- content check word(next one)
    local x = 1 -- content table x
    local y = 1 -- content table y
    
    local opt = {} -- output table
    opt[y] = {}
    opt[y][x] = ""
     
    local in_quote = false -- quote mode
     
    while true do
    p = p + 1
    w = string.sub(c,p ,p )
    w_next = string.sub(c,p+1,p+1)
        if w == ',' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                x = x + 1
                opt[y][x] = ""
            end
        elseif w == '"' then
            if in_quote then
                if w_next == '"' then
                    opt[y][x] = opt[y][x]..w
                    p = p + 1
                else
                    in_quote = false
                end
            else
                in_quote = true
            end
        elseif w == '\n' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                y = y + 1
                x = 1
                opt[y] = {}
                opt[y][x] = ""
            end
        elseif w == "" or w == nil then
            opt[y][x] = nil
            break
        else
            opt[y][x] = opt[y][x]..w
        end
    end

    return opt
end

function escape_comma(inputString)
    if (inputString == nil) then
        return inputString
    end
    if string.find(inputString, ",") then
        return '"' .. inputString .. '"'
    else
        return inputString
    end
end

function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end
    if (tool.file_exist(lockfile) == true) then
 --����ʵ������
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
 --��ʵ������
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- дchap-secrets �� order_relation�ļ�
local function pppoe_update_file(param, back_secrets_file, back_order_relation_file, src)
    -- if src == "update" and tool.file_exist(chap_secrets_tmp) == true and tool.file_exist(order_relation) == true then
    --     return;
    -- end
    local name_escape
    local group_name_escape
    local chap_fp = io.open(back_secrets_file, "w")
    chap_fp:write("#USERNAME  PROVIDER  PASSWORD  IPADDRESS\n")
    local relation_fp = io.open(back_order_relation_file, "w")
    relation_fp:write(relation_default_header)
    for k,v in pairs(param["list"]) do
        if (v["enable"] == "1") then
            local chap_str = string.format([['%s' '%s' '%s' *]], v["name"], modul, v["passwd"])
            module_debug.lua_debug(module_debug.INFO, "chap str:%s\n", chap_str)
            chap_fp:write(chap_str, "\n")

            name_escape = escape_comma(v["name"])
            group_name_escape = escape_comma(v["group_name"])
            local relation_str = string.format([[%s,%s,%s,%s,%s,%s]], name_escape, v["type"], group_name_escape, v["group_uuid"], v["validity"], v["dealline"])
            module_debug.lua_debug(module_debug.INFO, "relation_str str:%s\n", relation_str)
            relation_fp:write(relation_str, "\n")
        end
    end
        
	chap_fp:close()
    relation_fp:close()

    os.execute("mv "..back_secrets_file.." "..chap_secrets_tmp)
    os.execute("cp "..chap_secrets_tmp.." "..pap_secrets_tmp)
    os.execute("mv "..back_order_relation_file.." "..order_relation)
end

local function charge_update_file(param, back_secrets_file, back_order_relation_file, src)
    -- if src == "update" and tool.file_exist(chap_secrets_tmp) == true and tool.file_exist(order_relation) == true then
    --     return;
    -- end
    local name_escape
    local group_name_escape
    local pkg_uuid_map = maccChargePkg_validity_get()
    local chap_fp = io.open(back_secrets_file, "w")
    chap_fp:write("#USERNAME  PROVIDER  PASSWORD  IPADDRESS\n")
    local relation_fp = io.open(back_order_relation_file, "w")
    relation_fp:write(relation_default_header)
    for k,v in pairs(param) do
        if (v["enable"] == "1") then
            local chap_str = string.format([['%s' '%s' '%s' *]], k, modul, v["passwd"])
            module_debug.lua_debug(module_debug.INFO, "chap str:%s\n", chap_str)
            chap_fp:write(chap_str, "\n")
            name_escape = escape_comma(k)
            group_name_escape = escape_comma(v["pkg_name"])
            if (v["pkg_uuid"] ~= nil and v["pkg_uuid"] ~= "" and pkg_uuid_map ~= nil) then
                if (pkg_uuid_map[v["pkg_uuid"]] ~= nil and pkg_uuid_map[v["pkg_uuid"]] ~= "") then
                    validity = pkg_uuid_map[v["pkg_uuid"]]
                    module_debug.lua_debug(module_debug.INFO, "pkg_uuid:%s, validity:%s", v["pkg_uuid"], validity);
                    v["validity"] = validity
                else
                    v["validity"] = "0"
                end
            else
                v["validity"] = "0"
            end
            local relation_str = string.format([[%s,%s,%s,%s,%s,%s]], name_escape, "charge", group_name_escape, v["pkg_uuid"], v["validity"], v["pkg_expire_time"])
            module_debug.lua_debug(module_debug.INFO, "relation_str str:%s\n", relation_str)
            relation_fp:write(relation_str, "\n")
        end
    end
    
    chap_fp:close()
    relation_fp:close()

    os.execute("mv "..back_secrets_file.." "..chap_secrets_tmp)
    os.execute("cp "..chap_secrets_tmp.." "..pap_secrets_tmp)
    os.execute("mv "..back_order_relation_file.." "..order_relation)
end

function merge_charge_pppoe_user(back_secrets_file, back_order_relation_file, src)
    local pppoeserver_user_list = nil
    local charge_user_list = nil
    local need_merge = true
    local pkg_uuid_map = maccChargePkg_validity_get()

    local t = io.popen(pppoe_charge_auth_enable)
    local res = t:read("*all")
    t:close()
    local pppoe_charge_auth = cjson.decode(res)
    if (pppoe_charge_auth["auth_enable"] == "1") then
        charge_user_list = charge_order_relation_get(conf_file)
    end

    pppoeserver_user_list = pppoe_order_relation_get()

    if (pppoeserver_user_list == nil or charge_user_list == nil) then
        need_merge = false
    end

    -- дchap-secrets �� order_relation�ļ�
    -- 1���ظ���2��Charge�У�pppoeû��
    if (need_merge == true) then
        module_debug.lua_debug(module_debug.INFO, "need merge");
        for k,v in pairs(pppoeserver_user_list["list"]) do
            if charge_user_list[v["name"]] ~= nil and charge_user_list[v["name"]]["spt_service"] ~= "web" then
                -- charge�˺����ȣ����£����Charge�˺��Ѽ���pppoe
                pppoeserver_user_list["list"][k]["type"] = "charge"
                pppoeserver_user_list["list"][k]["group_name"] = charge_user_list[v["name"]]["pkg_name"]
                pppoeserver_user_list["list"][k]["group_uuid"] = charge_user_list[v["name"]]["pkg_uuid"]
                pppoeserver_user_list["list"][k]["passwd"] = charge_user_list[v["name"]]["passwd"]
                pppoeserver_user_list["list"][k]["enable"] = charge_user_list[v["name"]]["enable"]
                -- validity����uuid�������ļ��л�ȡ
                if (charge_user_list[v["name"]]["pkg_uuid"] ~= nil and charge_user_list[v["name"]]["pkg_uuid"] ~= "" and pkg_uuid_map ~= nil) then
                    if (pkg_uuid_map[charge_user_list[v["name"]]["pkg_uuid"]] ~= nil and pkg_uuid_map[charge_user_list[v["name"]]["pkg_uuid"]] ~= "") then
                        validity = pkg_uuid_map[charge_user_list[v["name"]]["pkg_uuid"]]
                    else
                        validity = "0"
                    end
                    module_debug.lua_debug(module_debug.INFO, "pkg_uuid:%s, validity:%s", pppoeserver_user_list["list"][k]["group_uuid"], validity);
                    pppoeserver_user_list["list"][k]["validity"] = validity
                else
                    pppoeserver_user_list["list"][k]["validity"] = "0"
                end
                pppoeserver_user_list["list"][k]["dealline"] = charge_user_list[v["name"]]["pkg_expire_time"]
                charge_user_list[v["name"]]["merge_flag"] = "1"
                module_debug.lua_debug(module_debug.INFO, "merge user %s", v["name"]);
            end
        end
        -- Charge�У�pppoeû��
        for m,n in pairs(charge_user_list) do
            if n["merge_flag"] ~= "1" and n["spt_service"] ~= "web" then
                local account_info = {}
                account_info["name"] = m
                account_info["enable"] = n["enable"]
                account_info["type"] = "charge"
                account_info["group_name"] = n["pkg_name"]
                account_info["group_uuid"] = n["pkg_uuid"]
                account_info["passwd"] = n["passwd"]
                if (account_info["group_uuid"] ~= nil and account_info["group_uuid"] ~= "") then
                    if (pkg_uuid_map[account_info["group_uuid"]] ~= nil and pkg_uuid_map[account_info["group_uuid"]] ~= "") then
                        validity = pkg_uuid_map[account_info["group_uuid"]]
                    else
                        validity = "0"
                    end
                    module_debug.lua_debug(module_debug.INFO, "pkg_uuid:%s, validity:%s", account_info["group_uuid"], validity);
                    account_info["validity"] = validity
                else
                    account_info["validity"] = "0"
                end
                account_info["dealline"] = n["pkg_expire_time"]
                table.insert(pppoeserver_user_list["list"], account_info)
                module_debug.lua_debug(module_debug.INFO, "value:%s", cjson.encode(account_info));
            end
        end
    else
        -- ����pppoe��charge����secrets��order_relation�ļ�
        if pppoeserver_user_list ~= nil then
            module_debug.lua_debug(module_debug.INFO, "only pppoe user");
            pppoe_update_file(pppoeserver_user_list, back_secrets_file, back_order_relation_file, src)
        end
        if charge_user_list ~= nil then
            module_debug.lua_debug(module_debug.INFO, "only charge user");
            charge_update_file(charge_user_list, back_secrets_file, back_order_relation_file, src)
        end
        if charge_user_list == nil and pppoeserver_user_list == nil then
            module_debug.lua_debug(module_debug.INFO, "no user");
            os.execute("echo '#USERNAME  PROVIDER  PASSWORD  IPADDRESS' > /tmp/pppoe-server/chap-secrets")
            os.execute("echo 'username,type,user_group,group_uuid,validity,dealline' > /tmp/account_mgr/order_relation")
            os.execute("cp "..chap_secrets_tmp.." "..pap_secrets_tmp)
        end
        return
    end
    module_debug.lua_debug(module_debug.INFO, "both charge user and pppoe user");
    module_debug.lua_debug(module_debug.INFO, "pppoeserver_user_list: %s", cjson.encode(pppoeserver_user_list));
    pppoe_update_file(pppoeserver_user_list, back_secrets_file, back_order_relation_file, src)
    return
end