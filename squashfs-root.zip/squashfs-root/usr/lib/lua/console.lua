#!/usr/bin/lua
module("console", package.seeall)
FRAME_TMP_DIR = "/tmp/sd_config/"
local DEV_STA_LUA_DIR="/usr/local/lua/dev_sta/"
local AC_CONFIG_LUA_DIR="/usr/local/lua/ac_config/"
local DEV_CONFIG_LUA_DIR="/usr/local/lua/dev_config/"
local GLOBAL_LUA_DIR="/usr/local/lua/global/"
DEBUG_STATUS = "1"
--lua调试debug
function debug(method, msg)
    if (DEBUG_STATUS == "1") then
        if not method then
            return "method is nil"
        end
        local lengthMap =
            setmetatable(
            {
                ac_config = 51200,
                dev_config = 51200,
                dev_sta = 20000,
                iwpriv_set = 51200
            },
            {
                __index = function(table, key)
                    return 10000
                end
            }
        )
        local log_path = FRAME_TMP_DIR .. method .. ".log"
        if (is_file_exist(log_path)) then
            log_max_length = lengthMap[method]
            local log_length = get_file_length(log_path)
            if (log_length > log_max_length) then
                os.rename(log_path, log_path .. ".old")
            end
        else
            if (not console.is_file_exist(FRAME_TMP_DIR)) then
                local lfs = require "lfs"
                lfs.mkdir(FRAME_TMP_DIR)
            end
        end
        require "nixio"
        local pid = nixio.getpid()
        local cur_time = os.date("%Y-%m-%d %H:%M:%S")
        local f = assert(io.open(log_path, "a"))
        if not msg then
            msg = ""
        end
        f:write("[" .. pid .. "][" .. cur_time .. "]" .. msg .. "\n")
        f:close()
    end
end

-- 异步执行shell命令
function forkExec(command)
    local nixio = require "nixio"
    local pid = nixio.fork()
    if pid > 0 then
        return
    elseif pid == 0 then
        nixio.chdir("/")
        local null = nixio.open("/dev/null", "w+")
        if null then
            nixio.dup(null, nixio.stderr)
            nixio.dup(null, nixio.stdout)
            nixio.dup(null, nixio.stdin)
            if null:fileno() > 2 then
                null:close()
            end
        end
        nixio.exec("/bin/sh", "-c", command)
    end
end

function module_call_forkExec(cmd, module, param, not_change_configId)
    local nixio = require "nixio"
    if cmd == nil or cmd == "" then
        debug("console", "!!!!cmd=nil!!!")
        return
    end
    local pid = nixio.fork()
    if pid > 0 then
        return
    elseif pid == 0 then
        nixio.chdir("/")
        local null = nixio.open("/dev/null", "w+")
        if null then
            nixio.dup(null, nixio.stderr)
            nixio.dup(null, nixio.stdout)
            nixio.dup(null, nixio.stdin)
            if null:fileno() > 2 then
                null:close()
            end
        end
        if not_change_configId then
            nixio.execp("/usr/sbin/module_call", cmd, module, param, "-n")
        else
            nixio.execp("/usr/sbin/module_call", cmd, module, param)
        end
    end
end


--lua读文件
function read_file(file)
    local f = assert(io.open(file, "r"))
    local content = f:read("*al")
    f:close()
    return trim(content)
end

--lua读文件 仅提供给框架ac_config dev_config 使用 bug722272
function uf_read_file(file)
    local f = io.open(file, "r")
    local content
    if (f) then
       content = f:read("*a")
       f:close()
    end

    return trim(content)
end

--lua写文件
function write_file(file, msg, mode)
    local f = assert(io.open(file, mode))
    f:write(msg or "")
    f:close()
end

--是否是json
function is_cjson(param)
    local json = require "cjson"
    if
        pcall(
            function(param)
                json.decode(param)
            end,
            param
        )
     then
        return true
    else
        return false
    end
end

--lua判断文件或则文件夹是否存在
function is_file_exist(path)
    local file = io.open(path, "rb")
    if (file) then
        file:close()
    end
    return file ~= nil
end

--lua执行shell命令行
function exec_cmd(sh_cmd)
    if (sh_cmd == nil) then
        return nil
    end
    local sh_ret_handle = io.popen(sh_cmd)
    local sh_ret
    if (sh_ret_handle) then
    	sh_ret = sh_ret_handle:read("*al")
    	sh_ret_handle:close()
    end

    if sh_ret == "" then
        sh_ret = nil
    end
    return trim(sh_ret)
end

--获取文件大小
function get_file_length(filename)
    local f = assert(io.open(filename, "rb"))
    local len = assert(f:seek("end"))

    f:close()
    return len
end

--获取设备sn
function get_dev_sn()
    local sn
    local file_path = FRAME_TMP_DIR .. "dev_sn_file"
    if is_file_exist(file_path) then
        sn = read_file(file_path)
    else
        local cmd = "uci -q get sysinfo.@sysinfo[0].serial_num"
        sn = exec_cmd(cmd)
        if sn and sn ~= "" then
            write_file(file_path, sn, "w")
        end
    end
    return trim(sn)
end

--获取设备类型
function get_dev_type()
    local dev_type
    local dev_type_path = FRAME_TMP_DIR .. "dev_type_file"
    if is_file_exist(dev_type_path) then
        dev_type = read_file(dev_type_path)
    else
        local cmd = "dev_cap get --module dev_type"
        dev_type = exec_cmd(cmd)
        if dev_type and dev_type ~= "" then
            write_file(dev_type_path, dev_type, "w")
        end
    end
    return trim(dev_type)
end

--获取模块id
function get_moduleId(module)
    if not module then
        return "module is nil"
    end
    local moduleId
    local moduleId_file_path = FRAME_TMP_DIR .. module .. "_moduleId_file"

    if is_file_exist(moduleId_file_path) then
        moduleId = console.read_file(moduleId_file_path)
    else
        local module_file = "/tmp/sd_device/dev_modules_info"
        if not is_file_exist(module_file) then
            return nil
        end
        local json = require "dkjson"
        local content = read_file(module_file)
        local Table = json.decode(content)
        for k, v in pairs(Table.modules) do
            if v.moduleName == module then
                moduleId = v.moduleId
                write_file(moduleId_file_path, moduleId, "w")
                break
            end
        end
    end
    return trim(moduleId)
end

function get_call_module_sh_cmd(method, module, param)
    local sh_path = "/usr/sbin/module_call"
    if param then
        local json = require "dkjson"
        param = json.encode(param)
    end
    local sh_cmd = string.format("%s %s %s %s", sh_path, method, module, param or "")
    return sh_cmd
end

function get_all_list_pair()
    local file_data = ""
    local wds_info_file = "/tmp/wds_info_lite.json"

    if is_file_exist(wds_info_file) then
        file_data = console.read_file(wds_info_file)
        local json = require "dkjson"
        local dataTable = json.decode(file_data)
        return dataTable.list_all
    end
    
    return nil
end
--Obtains the password setting status of the bridge group
function get_list_pair_wdspw_status(list_pair)
    for i,v in ipairs(list_pair) do
        if not v.wds_pw then
            debug("dev_sta","dev ["..v.sn.."] no wdspw")
            return false
        end
    end
    return true
end



function get_tipc_sync(remote_sn, method, cmd, module, param)
    if not remote_sn then
        return "remote_sn is nil"
    end
    if not module then
        return "module is nil"
    end
    if not method then
        return "method is nil"
    end
    if not cmd then
        return "cmd is nil"
    end
    if not param then
        return "param is nil"
    end
    local param1 = param
    local json = require "dkjson"
    local paramTable = json.decode(param1)
    
    -- tipc远程调用时，不要将参数中的sn信息写到命令中，并且参数不能只有"{}"
    paramTable.sn = nil
    local content = nil
    if next(paramTable) == nil then 
        content = string.format("%s %s -m %s", method, cmd, module)
    else
        param1 = json.encode(paramTable)
        param1 = json.encode(param1)
        content = string.format("%s %s -m %s %s", method, cmd, module, param1)
    end
    debug("console","[content]"..content.."[remote_sn]"..remote_sn.."")
    -- todo 没有使用到可以删除
    local head_cmd = "est_wds_sync " ..remote_sn.. " << EOF"
    local end_cmd = "EOF"
    local cmd = head_cmd.."\n"..content.."\n"..end_cmd
    debug("console", cmd)
    return (exec_cmd(cmd))
end

--tipc同步通告
function tipc_sync(remote_sn, method, cmd, module, param)
    if not remote_sn then
        return "remote_sn is nil"
    end
    if not module then
        return "module is nil"
    end
    if not method then
        return "method is nil"
    end
    if not cmd then
        return "cmd is nil"
    end
    if not param then
        return "param is nil"
    end
    local param1 = param
    local json = require "dkjson"
    local paramTable = json.decode(param1)
    
    -- tipc远程调用时，不要将参数中的sn信息写到命令中
    paramTable.sn = nil
    param1 = json.encode(paramTable)
    param1 = json.encode(param1)
    local content = string.format("%s %s -m %s %s", method, cmd, module, param1)
    debug("console","[content]"..content.."[remote_sn]"..remote_sn.."")
    local head_cmd = "est_wds_sync " ..remote_sn.. " << EOF"
    local end_cmd = "EOF"
    local cmd = head_cmd.."\n"..content.."\n"..end_cmd
    debug("console", cmd)
    return (forkExec(cmd))
end

function is_include_dev_sn(paramTable)
    local sn = paramTable.sn
    local inc_current = nil
    local remote_sn = nil
    if not sn or sn == "" then
        inc_current = 1
    else
        if not sn[1] or sn[1] == "" then
            inc_current = 1
        else
            local dev_sn = get_dev_sn()
            if sn[1] == dev_sn then   --这里注定如果传入多sn时包括本地，必须把本机放到第一位，否则不返回本机,所以目前这里应该是最多一次只能get一个
                inc_current = 1
            else
                remote_sn = sn[1]
            end
        end
    end
    return inc_current, remote_sn
end

function is_module_support_lua(module, type)
    local module_call = nil
    if not module then
        return false
    end

    if type == "dev_sta" then
        if is_file_exist(DEV_STA_LUA_DIR..module..".lua") then
            package.path = "/usr/local/lua/dev_sta/?.lua;" .. package.path
            module_call = require (module)
        end
    elseif type == "dev_config" then
        if is_file_exist(DEV_CONFIG_LUA_DIR..module..".lua") then
            package.path = "/usr/local/lua/dev_config/?.lua;" .. package.path
            module_call = require (module)
        end
    elseif type == "ac_config" then
        if is_file_exist(AC_CONFIG_LUA_DIR..module..".lua") then
            package.path = "/usr/local/lua/ac_config/?.lua;" .. package.path
            module_call = require (module)
        end
    end
    
    if not module_call then
        if is_file_exist(GLOBAL_LUA_DIR..module..".lua") then
            package.path = "/usr/local/lua/global/?.lua;" .. package.path
            module_call = require (module)
        end
    end

    return module_call
end

--深拷贝
function deepcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

local function ToStringEx(value)
    if type(value)=='table' then
        return TableToStr(value)
    elseif type(value)=='string' then
        return "\'"..value.."\'"
    else
        return tostring(value)
    end
end

function TableToStr(t)
    if t == nil then return "" end
    local retstr= "{"

    local i = 1
    for key,value in pairs(t) do
        local signal = ","
        if i==1 then
          signal = ""
        end

        if key == i then
            retstr = retstr..signal..ToStringEx(value)
        else
            if type(key)=='number' or type(key) == 'string' then
                retstr = retstr..signal..'['..ToStringEx(key).."]="..ToStringEx(value)
            else
                if type(key)=='userdata' then
                    retstr = retstr..signal.."*s"..TableToStr(getmetatable(key)).."*e".."="..ToStringEx(value)
                else
                    retstr = retstr..signal..key.."="..ToStringEx(value)
                end
            end
        end

        i = i+1
    end

     retstr = retstr.."}"
     return retstr
end

--去除空格
function trim(s)
    if not s then
        return nil
    end
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

function result(code, err, data)
    return {code = code, err = err, data = data}
end

function err(err)
    return result(1, err)
end

function ok(data)
    return result(0, nil, data)
end

function fail(msg)
    local json = require "dkjson"
    local ret = {code = "1", err = msg}
    return json.encode(ret)
end

function failed(msg)
    local json = require "dkjson"
    local ret = {code = "2", data = msg}
    return json.encode(ret)
end

function success(msg)
    local json = require "dkjson"
    local ret = {code = "0", err = msg}
    return json.encode(ret)
end

function get_table_value(t, tab)          
    if (type(t) ~= 'table') then               
        debug("check failed the t is not table")   
        return t                                     
    end                                         
    local ret_string = "{"                      
    local i = 1                        
    for key,value in pairs(t) do       
        local signal = ","             
        if i==1 then                                
            if tab == "1" then                      
                ret_string =ret_string.."\"err\":\"{"
            end                                                          
            signal = ""                             
        end
        if tab == "1" then                                           
            ret_string =ret_string..signal.."\\\""..key.."\\\""..":".."\\\""..value.."\\\""
        else 
            ret_string =ret_string..signal.."\""..key.."\""..":".."\""..value.."\""
        end
        i = i+1                                                                
    end                                         
    if tab == "1" then                                                         
        ret_string = ret_string.."}\",\"code\":\"1\""                                     
    end                                                       
    ret_string = ret_string.."}"                              
    return ret_string                                         
end                                                        
                                                                         
function uf_lua_fail(t)                                                  
    if t == nil then                                                     
        debug("param is nil")                                            
        return ""                                                              
    end                                                                        
        if (type(t) ~= 'table') then                                           
            debug("check failed the t is not table")                           
            return t                                                           
        end                                                                    
        return get_table_value(t,"1")                                          
end                                                                            
                                                                               
function uf_lua_success(t)                                                     
    if (t == nil) then                    
        local json = require "dkjson"     
        local r_string = {rcode = "00000000", msg = "success"}
        return json.encode(r_string)                          
    else                                             
        return get_table_value(t,"0")           
    end                                                       
end
