#! /usr/bin/lua

module("alarm.lib_alarm", package.seeall);

SD_DEVICE_JSON = "/tmp/sd_device/sd_device.json"

-- 全局变量（当作C语言的宏使用）
-- device
ALARM_TYPE_POE_STATUS                = 10   -- POE状态变化
ALARM_TYPE_POE_FAULT                 = 11   -- POE故障
ALARM_TYPE_POE_POWER                 = 12   -- POE功率变化
-- network
ALARM_TYPE_PORT_LINK_SPEED_DUPLEX    = 20   -- 端口状态变化（端口link状态，协商速率，双工）
ALARM_TYPE_PORT_WAN_LINK_STATUS      = 21   -- WAN口link状态（WAN口是否插网线）
ALARM_TYPE_PORT_LINK_SPEED           = 22   -- 端口协商速率
ALARM_TYPE_LOOP_STATUS               = 30   -- 环路（EG系列和EAP系列只关心WAN口）
ALARM_TYPE_DHCP_SERVER_STATUS_CHANGE = 40   -- 多DHCP Server 状态变化上报
ALARM_TYPE_LAN_MULT_DHCP_SERVER      = 41   -- EG的ROUTER模式和EGW的ROUTER模式，LAN口存在多DHCP Server
ALARM_TYPE_WAN_MULT_DHCP_SERVER      = 42   -- EGW的中继模式（AP模式）和EAP，WAN口存在多DHCP Server
ALARM_TYPE_IP_ADDR_CONFLICT          = 60   -- IP地址冲突
ALARM_TYPE_LAN_IP_ADDR_CONFLICT      = 61   -- LAN口IP地址冲突
ALARM_TYPE_MAC_ADDR_CONFLICT         = 70   -- MAC地址冲突
ALARM_TYPE_DNS_NO_DNS                = 80   -- 检查网络中是否有配置dns，包括设备本身配置的
ALARM_TYPE_DNS_PING_DNS_FAILED       = 81   -- 检查ping dns ip
ALARM_TYPE_DNS_PARSE_DNS_ERROR       = 82   -- 检查dns解析外网地址
ALARM_TYPE_ROUTE_STATUS              = 100  -- 检查路由状态
ALARM_TYPE_NEXTHOP_STATUS            = 101  -- 检查下一跳
ALARM_TYPE_MQTT_PROC_NO_RUNNING      = 120  -- MQTT进程没有运行
ALARM_TYPE_MQTT_SELF_ORGAN_NETWORK   = 121  -- 检查自组网状态
ALARM_TYPE_MQTT_MULT_AC              = 122  -- 检查自组网多AC
-- device
ALARM_TYPE_CWMP_PROC_NO_RUNNING      = 150  -- CWMP进程未运行（设备云服务进程未启动）
ALARM_TYPE_CWMP_IS_DISABLE           = 151  -- 设备未开启云服务
ALARM_TYPE_CWMP_CLOUD_NO_ADD_DEVICE   = 152  -- 云端未添加设备
ALARM_TYPE_CWMP_NO_CONNECT_CLOUD      = 153  -- 设备未连接上云服务
ALARM_TYPE_FLASH_STATUS              = 180  -- 检查flash状态
ALARM_TYPE_VIRTUAL_MEMORY_STATUS     = 181  -- 检查虚拟内存状态（检测百分比）
ALARM_TYPE_PHYSICAL_MEMORY_STATUS    = 181  -- 检查物理内存状态（检测百分比）
ALARM_TYPE_CPU_STATUS                = 183  -- 检查CPU状态
-- max
ALARM_TYPE_MAX                       = 9999 -- 最大值


-- 连续检测n+1次告警就添加告警，从0开始计数
ALARM_COUNT_MAX                      = 2

-- debug初始化
local lib_debug = require "utils.debug";
lib_debug.debug_init("/tmp/alarm/", "alarm_source.log", 500, lib_debug.DEBUG, "1");

-- 函数封装，TODO：debug也封装
function string_split_to_table(str, reps)
    return require("utils.string").string_split_to_table(str, reps);
end

-- lua执行shell命令行，有的命令要注意屏蔽执行的返回：2>/dev/null 1>&2，后台运行不要调用本接口，直接调用io.popen
function lua_exec_cmd(sh_cmd)
    if (sh_cmd == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "lua_exec_cmd(), cmd is nil!");
        return nil;
    end
    local sh_ret = require("utils.exec").exec_cmd_ret(sh_cmd);
    -- 解决%s打印问题
    -- lib_debug.lua_debug(lib_debug.DEBUG, table.concat({"[execute cmd] ", sh_cmd}));
    -- lib_debug.lua_debug(lib_debug.DEBUG, table.concat({"[cmd  result] ", sh_ret}));
    lib_debug.lua_debug(lib_debug.DEBUG, "%s", table.concat({"[execute cmd] ", sh_cmd}));
    lib_debug.lua_debug(lib_debug.DEBUG, "%s", table.concat({"[cmd  result] ", sh_ret}));

    return sh_ret;
end

-- lua执行shell命令行（无调试），有的命令要注意屏蔽执行的返回：2>/dev/null 1>&2，后台运行不要调用本接口，直接调用io.popen
function lua_exec_cmd_nodebug(sh_cmd)
    if (sh_cmd == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "lua_exec_cmd(), cmd is nil!");
        return nil;
    end
    local sh_ret = require("utils.exec").exec_cmd_ret(sh_cmd);
    lib_debug.lua_debug(lib_debug.DEBUG, table.concat({"[execute cmd] ", sh_cmd}));

    return sh_ret;
end

-- 获取port_status，json table格式
function alarm_get_port_status()
    local port_status = {};--这样告警源只需验证是否为空表即可
    -- lua调用lua可用dofile或require，但考虑获取返回值，还是调用系统shell
    local json_str = lua_exec_cmd("dev_sta get -m port_status");
    if (json_str == nil or string.len(json_str) == 0) then
        lib_debug.lua_debug(lib_debug.DEBUG, "port_status get error");
    else
        port_status = require("dkjson").decode(json_str);
        port_status_count = tonumber(port_status["count"]);
        if (port_status_count == nil or port_status_count == 0) then
            lib_debug.lua_debug(lib_debug.DEBUG, "port_status:%s get error", json_str);
            port_status = {};-- 告警源只需验证是否为空表即可
        else
            lib_debug.lua_debug(lib_debug.DEBUG, "port_status:%s", json_str);
        end
    end
    return port_status;
end

--[[
    alarm_get_alarm_by_id() - 通过告警id查找告警信息
    @id：要操作的id，必须是数字。不允许为空nil
    @return：告警信息字符串，如果为空表（即"{}"），表示不存在该id对应的告警信息
--]]
function alarm_get_alarm_by_id(id)
    --入参检查
    if (id == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_get_alarm_by_id() args:id is nil");
        return false;
    end
    if (type(id) ~= "number") then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_get_alarm_by_id() args:id is not a number");
        return false;
    end

    local json_str = lua_exec_cmd("dev_sta get -m alarm_mngt");

    if (string.len(json_str) == 0) then
        local alarm_process_is_running = lua_exec_cmd("ps | grep alarm.elf | grep -v grep | wc -l");
        if (alarm_process_is_running == nil or tonumber(alarm_process_is_running) == 0) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm.elf process is not running");
            return nil;
        else
            lib_debug.lua_debug(lib_debug.ERROR, "alarm.elf process is running, but get alarm json table failed");
            return nil;
        end
    end

    local dkjson = require "dkjson";
    local alarm_list = dkjson.decode(json_str);
    local alarm_table = {};

    local local_sn = lua_exec_cmd("uci get sysinfo.@sysinfo[0].serial_num 2>/dev/null");
    if (type(local_sn) == "string") then
        local_sn = string.gsub(local_sn, "^%s*(.-)%s*$", "%1");
    end

    if (alarm_list ~= nil and alarm_list["list"] ~= nil) then
        for _, v in pairs(alarm_list["list"]) do
            if (v["id"] == id and type(v["detail"]) == "table") then
                for _, detail_item in pairs(v["detail"]) do
                    if (type(detail_item) == "table" and type(detail_item["sn"]) == "string") then
                        local detail_sn = string.gsub(detail_item["sn"], "^%s*(.-)%s*$", "%1");
                        if (type(local_sn) == "string" and #local_sn > 0 and detail_sn == local_sn) then
                            alarm_table = {
                                {
                                    ["id"] = id,
                                    ["serial_num"] = local_sn,
                                }
                            };
                            break;
                        end
                    end
                end
            end
            if (next(alarm_table) ~= nil) then
                break;
            end
        end
    end

    local alarm_table_json_str = dkjson.encode(alarm_table);

    return alarm_table_json_str;
end

-- 读取文件中的数字，数字范围[0, cnt_max]，文件不存在、文件内容空、文件内容非数字都返回0，超过cnt_max的返回cnt_max
function alarm_get_count(file, cnt_max)
    local count = "0";
    local lib_file = require "utils.file";
    -- local lib_debug = require "utils.debug";
    -- lib_debug.debug_init("/tmp/alarm/", "count.log", 500, lib_debug.DEBUG, "1");
    -- 文件不存在时
    if (lib_file.file_is_exist(file) == false) then
        count = "0";
        lib_debug.lua_debug(lib_debug.WARNING, "counter file:%s is not exist, count:%s", file, count);
        return count;
    end
    count = lib_file.read_file_first_line(file);
    -- 读取内容为空时
    if (count == nil) then
        count = "0";
        lib_debug.lua_debug(lib_debug.WARNING, "counter file:%s is empty, count:%s", file, count);
        return count;
    end
    num = tonumber(count);
    -- 读取内容不是数字字符串或者小于1
    if (num == nil) then
       count = "0";
       lib_debug.lua_debug(lib_debug.WARNING, "counter file:%s, data:%s is not a num, count:%s", file, dat, count);
       return count;
    end
    -- 读取内容大于 cnt_max
    if (num > cnt_max) then
        dat = count;
        count = string.format("%d", cnt_max)
        lib_debug.lua_debug(lib_debug.WARNING, "counter file:%s, data:%s is large than %d, count:%s", file, dat, cnt_max, count);
        return count;
    end

    lib_debug.lua_debug(lib_debug.INFO, "counter file:%s, count:%s", file, count);
    return count;
end

--[[
    alarm_check_interval() - 间隔5次才检测告警源1次
    @cnt_file：计数文件，用于保存和读取的同个告警检测的间隔次数
    @interval：间隔次数（注意不是时间）,是数字不是字符串数字
    @return：true，可以开始告警源检测；false，不进行告警源检测
--]]
function alarm_check_interval(cnt_file, interval)
    --入参检查
    if (cnt_file == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args cnt_file is nil");
        return false;
    end
    -- 计数处理
    dat = alarm_get_count(cnt_file, interval);
    count = tonumber(dat);
    if (count == nil) then
        count = 0;
    end
    -- 从0开始，如果连续COUNT次都检测到告警就添加告警
    if (count < interval) then
        count = count + 1;
        lib_debug.lua_debug(lib_debug.INFO, "re-write counter file:%s, count:%s", cnt_file, count);
        local lib_file = require "utils.file";
        lib_file.write_file(cnt_file, count, "w");
        return false;
    end

    return true;
end

--[[
    alarm_check_interval() - 间隔5次才检测告警源1次
    @cnt_file：计数文件，用于保存和读取的同个告警检测的间隔次数
    @interval：间隔次数（注意不是时间）
    @return：true，可以开始告警源检测；false，不进行告警源检测
--]]
function alarm_reset_interval(cnt_file)
    -- 入参检查
    if (cnt_file == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args cnt_file is nil");
        return false;
    end
    -- 计数处理
    count = 0;
    lib_debug.lua_debug(lib_debug.INFO, "re-write counter file:%s, count:%s", cnt_file, count);
    local lib_file = require "utils.file";
    lib_file.write_file(cnt_file, count, "w");

    return true;
end

--[[
    alarm_notify() - 告警通告
    @op：告警操作，add：添加告警，del：删除告警。不允许为空nil
    @id：要操作的id。不允许为空nil
    @msg：告警消息，只有当告警操作是add时有用，当操作是del时可以为空nil
    @rmsg：新告警消息，只有当告警操作是add时有用，当操作是del时可以为空nil
    @alarm_type：告警类型，只有当告警操作是add时有用，当操作是del时可以为空nil
    @ttl：告警存活时间（单位：秒），只有当告警操作是add时有用，当操作是del时可以为空nil
    @data：表格，传入的变量
    格式：dev_sta set -m alarm_mngt '{"opt":"add","id":idnum,"msg":"xxx","type":"device|network","age":ttl}'
    例子：dev_sta set -m alarm_mngt '{"opt":"add","id":3,"msg":"多dhcp","type":"device","age":30}'
    注意：age的单位是秒
    --ubus call
--]]
function alarm_notify(op, id, msg, rmsg, alarm_type, ttl, data)
    -- 入参检查
    if (data ~= nil) then
    	lib_debug.lua_debug(lib_debug.DEBUG, "alarm_notify() args data:%s", require("dkjson").encode(data));
    end

    if (op == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args op is nil");
        return false;
    elseif (op ~= "add" and op ~= "del") then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args op:%s is invalid", op);
        return false;
    end
    if (id == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args id is nil");
        return false;
    elseif (id <= 0 or id >= 9999) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args id:%d is invalid", id);
        return false;
    end
    if (op == "add") then
        if (msg == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args msg is nil");
            return false;
        end
        if (rmsg == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args rmsg is nil");
            return false;
        end
        if (alarm_type == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args alarm_type is nil");
            return false;
        elseif (alarm_type ~= "network" and alarm_type ~= "device") then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args alarm_type:%s is invalid", alarm_type);
            return false;
        end
        if (ttl == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args ttl is nil");
            return false;
        elseif (ttl < 10) then -- 告警老化时间（单位：秒）暂不限定上限时间
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args ttl:%d is invalid", ttl);
            return false;
        end
        if (data == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args data is nil");
            return false;
        elseif (type(data) ~= "table") then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args data is not a table");
            return false;
        end
    end

    alarm_json = {
        ["opt" ] = op,
        ["id"  ] = id,
    }
    if (data ~= nil) then
        alarm_json["list"] = data;
    end

    -- 如果是add接口，还需要三个参数
    if (op == "add") then
        alarm_json["msg" ] = msg;
        alarm_json["rmsg"] = rmsg;
        alarm_json["type"] = alarm_type;
        alarm_json["age" ] = ttl;
        alarm_json["data"] = data;
    end

    local json_str = require("dkjson").encode(alarm_json);
    local alarm_cmd = table.concat({"dev_sta set -m alarm_mngt '", json_str, "'"});
    -- 解决%s打印问题
    -- lib_debug.lua_debug(lib_debug.DEBUG, alarm_cmd);
    lib_debug.lua_debug(lib_debug.DEBUG, "%s", alarm_cmd);
    lua_exec_cmd(alarm_cmd);

    return true;
end

--[[
    alarm_notify_count_3() - 如果连续3次检测到告警就告警通告
    @cnt_file：计数文件，用于保存和读取的同个告警检测到告警的次数
    @op：告警操作，add：添加告警，del：删除告警。不允许为空nil
    @id：要操作的id。不允许为空nil
    @msg：告警消息，只有当告警操作是add时有用，当操作是del时可以为空nil
    @rmsg： 新版本告警消息，只有当告警操作是add时有用，当操作是del时可以为空nil
    @alarm_type：告警类型，只有当告警操作是add时有用，当操作是del时可以为空nil
    @ttl：告警存活时间（单位：秒），只有当告警操作是add时有用，当操作是del时可以为空nil
    @data：表格，传入的变量
    格式：dev_sta set -m alarm_mngt '{"opt":"add","id":idnum,"msg":"xxx","type":"device|network","age":ttl}'
    例子：dev_sta set -m alarm_mngt '{"opt":"add","id":3,"msg":"多dhcp","type":"device","age":30}'
    注意：age的单位是秒
    注意：可以考虑ubus call接口
--]]
function alarm_notify_count_3(cnt_file, op, id, msg, rmsg, alarm_type, ttl, data)
    -- 入参检查
    if (cnt_file == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args cnt_file is nil");
        return false;
    end
    if (op == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args op is nil");
        return false;
    elseif (op ~= "add" and op ~= "del") then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args op:%s is invalid", op);
        return false;
    end
    if (id == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args id is nil");
        return false;
    elseif (id <= 0 or id >= 9999) then
        lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args id:%d is invalid", id);
        return false;
    end

    if (op == "add") then
        if (msg == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args msg is nil");
            return false;
        end
        if (rmsg == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args rmsg is nil");
            return false;
        end
        if (alarm_type == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args alarm_type is nil");
            return false;
        elseif (alarm_type ~= "network" and alarm_type ~= "device") then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args alarm_type:%s is invalid", alarm_type);
            return false;
        end
        if (ttl == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args ttl is nil");
            return false;
        elseif (ttl < 10) then -- 告警老化时间（单位：秒）暂不限定上限时间
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args ttl:%d is invalid", ttl);
            return false;
        end
        if (data == nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args data is nil");
            return false;
        elseif (type(data) ~= "table") then
            lib_debug.lua_debug(lib_debug.ERROR, "alarm_notify() args data is not a table");
            return false;
        end
    end

    -- 计数处理
    local dat = alarm_get_count(cnt_file, ALARM_COUNT_MAX);
    local count = tonumber(dat);
    if (op == "add") then
        if (count == nil) then
            count = 0;
        end
        -- 从0开始，如果连续ALARM_COUNT_MAX次都检测到告警就添加告警
        if (count < ALARM_COUNT_MAX) then
            count = count + 1;
            lib_debug.lua_debug(lib_debug.INFO, "re-write counter file:%s, count:%s", cnt_file, count);
            local lib_file = require "utils.file";
            lib_file.write_file(cnt_file, count, "w");
            return true;
        end
    elseif (op == "del") then
        -- 如果count不为0，则暂时不消除告警，count会递减到0才会消除告警。BUGID:567457
        if (count > 0) then
            count = count - 1;
            lib_debug.lua_debug(lib_debug.INFO, "re-write counter file:%s, count:%s", cnt_file, count);
            local lib_file = require "utils.file";
            lib_file.write_file(cnt_file, count, "w");
            return true;
        end
    end

    alarm_notify(op, id, msg, rmsg, alarm_type, ttl, data);

    return true;
end
