#! /usr/bin/lua
module("dev.tools.status", package.seeall)

--lua获取端口转态
function ports_status(devs)
    local switches = { };
    local ports = { };
    for dev in devs:gmatch("[^%s,]+") do
        local port_num = 1;
        repeat
            local char=table.concat({"swconfig dev ",dev," port ",port_num," get link 2>/dev/null"});
            local swc = io.popen(char);
            local var
            if swc then
                var=swc:read("*l")
                if var then
                    local port, up = var:match("port:(%d+) link:(%w+)")
                    if port then
                        local speed  = var:match(" speed:(%d+)")
                        ports[#ports+1] = {
                            port   = port or tostring(0),
                            speed  = speed or tostring(0),
                            link   = (up == "up"),
                        }
                    end
                end
            end
            port_num = port_num + 1;
            swc:close()
        until not var
        switches[devs] = ports
    end
    return switches;
end

--lua获取端口转态
function ports_num_status(dev,port_num)
    local ports = { };
    local char=table.concat({"swconfig dev ",dev," port ", port_num ," get link 2>/dev/null"});
    local swc = io.popen(char);
    local var
    if swc then
        var=swc:read("*l")
        if var then
            local port, up = var:match("port:(%d+) link:(%w+)")
            if port then
                local speed, baseT, duplex = var:match(" speed:(%d+)(%w+) (%w+)-duplex")
                ports[#ports+1] = {
                    port   = port or tostring(0),
                    speed  = speed or tostring(0),
                    link   = (up == "up"),
                    duplex = duplex or "NULL",
                 }
            end
        end
    end

    swc:close()
    return ports;
end

function sta_info()
    local rv = { }
    local file = "/tmp/sta_sta.info"
    local mac_tmp = nil

    local fd = io.open(file, "r")
    if fd then
        while true do
            local ln = fd:read("*l")
            if not ln then
                break
            end

            ln = ln:gsub("%s+", " ")
            local name, mac, ip, creat_time, online_time, rateup, ratedown = ln:match("^(%S+) (%S+) (%S+) (%S+) (%S+) (%S+) (%S+)")
            if mac then
                mac_tmp = mac:upper()
            end
            if name and mac and ip and creat_time and online_time and rateup and ratedown then
                rv[#rv+1] = {
                    sta_name = name,
                    sta_mac = mac_tmp,
                    sta_ip = ip,
                    online_time = tonumber(online_time),
                    flow_rateup = tonumber(rateup),
                    flow_ratedown = tonumber(ratedown)
                }
            end
        end

        fd:close()
    end

    return rv
end
