#! /usr/bin/lua
module("dev.tools.common", package.seeall)
DEBUG_LOG_DIR = "/tmp/debug";

--lua判断文件或则文件夹是否存在
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

--lua获取文件行数
function file_line_num_get(file)
    local BUFSIZE = 65536;
    local lc = 0;
    local f = io.input(file);
    while (true) do
        local lines,rest = f:read(BUFSIZE,"*line");
        if not lines then
            break;
        end
        _,t = string.gsub(lines,"\n","\n");
        lc = lc + t;
    end
    return lc;
end

function trim(s)
    return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end

--json格式简单判断
function json_check(jsonS)
    if (jsonS == nil) then
        return false
    end
    jsonString =trim(jsonS);
    local String1=string.sub(jsonString, 1, 1)
    local String2 = string.sub(jsonString,#jsonString)
    if (String1=="{" and String2 =="}") then
        return true
    end
    return false
end

--写入文件
function file_write(path, content, mode)
    mode = mode or "w+b"
    local file = io.open(path, mode)
    if file then
        if file:write(content) == nil then
            return false
        end
        io.close(file)
        return true
    else
        return false
    end
end

--写文件到tmp mv办法覆盖文件(防止掉电丢失)
function file_mv_write(path, path_tmp, content, mode)
    mode = mode or "w+b"
    local file = io.open(path_tmp, mode)
    if (file == nil) then
        return false
    end

    local ret = file:write(content)
    if (ret == nil) then
        return false
    end
    -- flush 程序内部缓存的文件数据刷新到OS缓冲区
    file:flush()
    file:close()

    -- rename 双文件写入策略
    ret = os.rename(path_tmp, path)
    if (ret == nil) then
        return false
    end

    -- sync 文件系统缓冲区数据刷新到磁盘
    os.execute("sync")
    return true
end

--lua读文件
function file_read(file)
    local f = assert(io.open(file,'r'));
    local content = f:read("*all");
    f:close();
    return content;
end

--lua根据字符分割字符串
function split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

--lua调试debug
function lua_debug(msg, name, size)
    local dir = table.concat({DEBUG_LOG_DIR,"/",name})
    local file = table.concat({dir,"/", name,".log"})
    if (file_exist(file) == true) then
        local log_line = file_line_num_get(file);
        if (log_line > size) then
            os.rename(file,table.concat({file,".old"}));
        end
    else
        if (file_exist(dir) == false) then
            local char = table.concat({"mkdir -p ",dir," >/dev/null 2>&1"});
            os.execute(char);
        end
    end
    local cur_time = os.date("%Y-%m-%d %H:%M:%S");
    local f = assert(io.open(file,"a"));
    f:write("[",cur_time,"] ", name ,"[",string.format("%3s",debug.getinfo(3).currentline),"] ",msg,"\n");
    f:close();
end

--lua执行shell命令行
function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    local sh_ret_handle = io.popen(sh_cmd);
    local sh_ret = sh_ret_handle:read("*all");
    sh_ret_handle:close();
    return sh_ret;
end

--lua日志写到logger
function syslog(msg)
    local cmd = table.concat({"logger -t '[network_wan_monitor.sh]' ", msg});
    exec(cmd);
end

--lua的sleep命令
function sleep(n)
   os.execute("sleep " .. n)
end

--按位或
function bit_or(a,b)
    local p,c=1,0
    while a+b>0 do
        local ra,rb=a%2,b%2
        if ra+rb>0 then c=c+p end
        a,b,p=(a-ra)/2,(b-rb)/2,p*2
    end
    return c
end

--按位非
function bit_not(n)
    local p,c=1,0
    while n>0 do
        local r=n%2
        if r<1 then c=c+p end
        n,p=(n-r)/2,p*2
    end
    return c
end

--按位与
function bit_and(a,b)
    local p,c=1,0
    while a>0 and b>0 do
        local ra,rb=a%2,b%2
        if ra+rb>1 then c=c+p end
        a,b,p=(a-ra)/2,(b-rb)/2,p*2
    end
    return c
end

--ip转int型
function ip_to_int(str)
    local num = 0
    if str and type(str)=="string" then
        local o1,o2,o3,o4 = str:match("(%d+)%.(%d+)%.(%d+)%.(%d+)" )
        num = 2^24*o1 + 2^16*o2 + 2^8*o3 + o4
    end
    return num
end

--int转ip
function int_to_ip(n)
    if n then
        n = tonumber(n)
        local n1 = math.floor(n / (2^24))
        local n2 = math.floor((n - n1*(2^24)) / (2^16))
        local n3 = math.floor((n - n1*(2^24) - n2*(2^16)) / (2^8))
        local n4 = math.floor((n - n1*(2^24) - n2*(2^16) - n3*(2^8)))
        return n1.."."..n2.."."..n3.."."..n4
    end
    return "0.0.0.0"
end

--检查字符串是否为mac
function mac_check(str)
    local ret = string.find(str, '[A-Fa-f0-9][A-Fa-f0-9]:[A-Fa-f0-9][A-Fa-f0-9]:[A-Fa-f0-9][A-Fa-f0-9]:[A-Fa-f0-9][A-Fa-f0-9]:[A-Fa-f0-9][A-Fa-f0-9]:[A-Fa-f0-9][A-Fa-f0-9]')
    if (ret ~= nil) then
        return true
    end
    return false
end

function strdel(str, n)
    local result = split(str, " ");
    local target = ""
    for j = 1, 100, 1 do
        if (result[j] == nil) then
            break;
        end
        if (result[j] ~= n) then
            if (target ~= "" ) then
                local tmp = table.concat({target, " ", result[j]});
                target = tmp;
            else
                target = result[j];
            end
        end
    end

    return trim(target);
end

function strncat(str, n)
    local result = split(str, " ");
    local target = ""
    local check = 0;
    if (str == nil) then
        return trim(n);
    end
    for j = 1, 100, 1 do
        if (result[j] == nil) then
            break;
        end
        if (result[j] == n) then
            check = 1;
        end
    end
    if (check == 1) then
        target = str;
    else
        local tmp = table.concat({str, " ", n});
        target = tmp;
    end

    return trim(target);
end

