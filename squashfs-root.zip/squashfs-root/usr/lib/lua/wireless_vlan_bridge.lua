-- config wifi-iface 'ra5_10'
        -- option ifname 'ra5.10'
        -- option disabled '1'
        -- option network 'lan'
module("wireless_vlan_bridge", package.seeall)

local uci = require "luci.model.uci".cursor()
local json = require "dkjson"
local console = require "console"
local libc2lua = require("libc2lua")
local cap_2g = uci:get("wifiinfo", "global", "support2g")
local cap_5g = uci:get("wifiinfo", "global", "support5g")
local dev_mode = uci:get_first("sysinfo", "sysinfo", "forwardMode")
local wan_vlanid = uci:get("network", "wan", "vlanid") or "1"
local lan_vlanid = "233"
local uci_confdir = uci:get("wifiinfo", "global", "wireless_path") or "/etc/config"
local default_uci_path = "/etc/config"
local SD_DEVICE_DIR = "/tmp/sd_device/sd_device.json"
local WIRELESS_UCI_LOCK_FILE = "/tmp/.wireless_uci.lockfile"
local ext_ifname = nil
local ifname = nil
local log_msg = nil
local cap_tab
local cap_config_buf = console.read_file(SD_DEVICE_DIR)
if (cap_config_buf == nil or cap_config_buf == '') then
	return
else
	cap_tab = json.decode(cap_config_buf)
end
local wireless_cap_tab = cap_tab.wireless
if not wireless_cap_tab then
	return
end

local function debug(msg)
    console.debug("wireless_vlan_bridge", msg)
end

local function create_bridge_conf(ext_ifname, wlanid, ifname, vlanid, is_force)
	uci:set_confdir(uci_confdir)
	local iface_name = string.gsub(ifname, "%.", "_")
	if uci:get("wireless", iface_name) == "wifi-iface" and not is_force then
		log_msg = string.format("%s exists, do not need to create , just up", iface_name)
		local cmd = string.format("ifconfig %s up", ifname)
		os.execute(cmd)
		debug(cmd)
		debug(log_msg)
		return
	end
	local cmd = string.format("vconfig add %s%d %s && ifconfig %s up", ext_ifname, tonumber(wlanid)-1, vlanid, ifname)
	os.execute(cmd)
	debug(cmd)
	if not is_force then
		uci:set("wireless", iface_name, "wifi-iface")
		uci:set("wireless", iface_name, "ifname", ifname)
		uci:set("wireless", iface_name, "disabled", "0")
		uci:set("wireless", iface_name, "not_need_set", "true")
		local network = string.format("lan_%s", vlanid)
		-- network should be "wan" while vlanid of interface is wan vlanid in ROUTER mode
		if dev_mode == "ROUTER" and vlanid == uci:get("network", "wan", "vlanid") then
			network = "wan"
		end
		uci:set("wireless", iface_name, "network", network)
		uci:commit("wireless")
		uci:set_confdir(default_uci_path)
		log_msg = string.format("Create iface %s, ifname[%s], disabled 0, network[%s]", iface_name, ifname, network)
		debug(log_msg)
	end
end

local function del_bridge_conf(ifname, vlanid, delete_vif_anyway)
	local iface_name = string.gsub(ifname, "%.", "_")
	-- local network = string.format("lan_%s", vlanid)
	-- uci:load("network")
	-- if uci:get("network", network) and not delete_vif_anyway then
	-- 	log_msg = string.format("%s bridge exists, no need to delete uci section", network)
	-- 	debug(log_msg)
	-- 	return
	-- end
	uci:set_confdir(uci_confdir)
	if not uci:get("wireless", iface_name) then
		log_msg = string.format("%s does not exist, no need to delete uci section", iface_name)
		debug(log_msg)
		return
	end
	uci:delete("wireless", iface_name)
	uci:commit("wireless")
	uci:set_confdir(default_uci_path)
	log_msg = string.format("Delete iface[%s] uci section", iface_name)
	debug(log_msg)
	-- do not need to down interface
	local cmd = string.format("vconfig rem %s", ifname)
	os.execute(cmd)
	debug(cmd)
end

function vlan_tab_deduplicate(tab)
	local tmp_tab = {}
	local tab_after_dedup = {}
	for k, v in pairs(tab) do
		tmp_tab[v] = "1" -- any value is OK
	end
	for k, v in pairs(tmp_tab) do
		if k ~= wan_vlanid and k ~= lan_vlanid then
			table.insert(tab_after_dedup, k)
		else
			log_msg = string.format("This vlanid [%s] do not need to virtual", k)
			debug(log_msg)
		end
	end
	return tab_after_dedup
end

--Just create wlanid 6 virtual interface now. 
--Reserve "wlanid" parameter for subsequent expansion.
function ap_mesh_virtual_if_action(wlanid, vlan_tab, is_add, is_force)
    local fd

	debug("Start-----------------------------------")
	if not vlan_tab or not wlanid then
		log_msg = string.format("Input wlanid or vlan_tab is nil")
		debug(log_msg)
		return
	end
    fd = libc2lua.lock(WIRELESS_UCI_LOCK_FILE, 30)
	log_msg = string.format("Vlan table before deduplicating is %s", json.encode(vlan_tab))
	debug(log_msg)
	dedup_tab = vlan_tab_deduplicate(vlan_tab)
	log_msg = string.format("Vlan table after deduplicating is %s", json.encode(dedup_tab))
	debug(log_msg)
	for k, v in pairs(dedup_tab) do
		if cap_2g then
			ext_ifname = uci:get("wifiinfo", "band_2g", "ext_ifname")
			if ext_ifname then
				ifname = string.format("%s%d.%s", ext_ifname, tonumber(wlanid)-1, v)
				if is_add == true then
					create_bridge_conf(ext_ifname, wlanid, ifname, v, is_force)
				else
					del_bridge_conf(ifname, v)
				end
			end
		end
		if cap_5g then
			ext_ifname = uci:get("wifiinfo", "band_5g", "ext_ifname")
			if ext_ifname then
				ifname = string.format("%s%d.%s", ext_ifname, tonumber(wlanid)-1, v)
				if is_add == true then
					create_bridge_conf(ext_ifname, wlanid, ifname, v, is_force)
				else
					del_bridge_conf(ifname, v)
				end
			end
		end
	end
    libc2lua.unlock(fd)
	debug("End-------------------------------------")
end

function virtual_if_action(radioid, wlanid, vlan_tab, is_add)
	local cap_rid
    local fd
	debug("Start-----------------------------------")

	if not vlan_tab or not wlanid or not radioid then
		log_msg = string.format("Input wlanid or vlan_tab is nil")
		debug(log_msg)
		return
	end
    fd = libc2lua.lock(WIRELESS_UCI_LOCK_FILE, 30)
	log_msg = string.format("Vlan table before deduplicating is %s", json.encode(vlan_tab))
	debug(log_msg)
	dedup_tab = vlan_tab_deduplicate(vlan_tab)
	log_msg = string.format("Vlan table after deduplicating is %s", json.encode(dedup_tab))
	debug(log_msg)
	for k, v in pairs(dedup_tab) do
		for m, n in ipairs(wireless_cap_tab.radiolist) do
			cap_rid = string.match(n.index, "%d+")
			if radioid == cap_rid then
				ifname = string.format("%s%d.%s", n.ext_ifname, tonumber(wlanid)-1, v)
				if is_add == true then
					create_bridge_conf(n.ext_ifname, wlanid, ifname, v)
				else
					del_bridge_conf(ifname, v, true)
				end
			end
		end
	end
    libc2lua.unlock(fd)
	debug("End-------------------------------------")
end
