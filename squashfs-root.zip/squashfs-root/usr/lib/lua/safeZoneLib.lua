#! /usr/bin/env lua

safeZoneLib = {}

local cfg = "/etc/safeConf/safeZoneCap.json"
local cjson_safe = require "cjson.safe"
local module_debug = require "utils.debug"
local dev_config = require "dev_config"
local dev_sta = require "dev_sta"
local cfg_idx_tb = {}
local cfg_access_tb = {}

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

local function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        return nil
    end

    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        return nil
    end

    return config_json
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    os.execute(sh_cmd)
end

local function exec_popen(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    local sh_ret_handle = io.popen(sh_cmd);
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret;
end

local function exec_ipset_batch(cmds)
    if (#cmds == 0) then 
        return 
    end

    local pipe = io.popen("ipset -exist restore 2>/dev/null", "w")
    if (pipe) then
        for _, c in ipairs(cmds) do
            pipe:write(c .. "\n")
        end
        pipe:close()
    end
end

function safeZoneLib.create_deny_zone(setname)
    exec(string.format("ipset create RelZone_%s list:set size 64 -exist 2>/dev/null", setname))

    exec_ipset_batch({
        string.format("create DenyLocal_%s_v4 hash:ip family inet -exist", setname),
        string.format("create DenyLocal_%s_v6 hash:ip family inet6 -exist", setname),
    })
end

function safeZoneLib.destroy_deny_zone(setname)
    -- Destroy shadow sets (flush then destroy) via the shared helper.
    safeZoneLib.destroy_shadow_zones({setname})

    exec_ipset_batch({
        string.format("destroy DenyLocal_%s_v4", setname),
        string.format("destroy DenyLocal_%s_v6", setname),
        string.format("destroy RelZone_%s", setname),
    })

    mem_file_v4 = string.format("/tmp/fwmng/%s_ipv4", setname)
    mem_file_v6 = string.format("/tmp/fwmng/%s_ipv6", setname)
    
    local ret = file_exist(mem_file_v4)
    if (ret ~= nil) then
        os.remove(mem_file_v4)
    end
  
    local ret = file_exist(mem_file_v6)
    if (ret ~= nil) then
        os.remove(mem_file_v6)
    end
end

function safeZoneLib.flush_deny_zone(setname)
    exec_ipset_batch({
        string.format("flush RelZone_%s", setname),
        string.format("flush DenyLocal_%s_v4", setname),
        string.format("flush DenyLocal_%s_v6", setname),
    })
end

local function get_iface_ip(mem_table, mem_file_v4, mem_file_v6)
    cmd = string.format("echo '' > %s 2>&1", mem_file_v4)
    exec(cmd)

    cmd = string.format("echo '' > %s 2>&1", mem_file_v6)
    exec(cmd)

    for k,v in pairs(mem_table) do
        if (string.find(v, "wan") ~= nil) then
            cmd = string.format("ip addr show  pppoe-%s  2>&1 | grep 'inet ' |awk '{print $2}' >> %s 2>&1", v, mem_file_v4)
            exec(cmd)

            cmd = string.format("ip addr show  pppoe-%s  2>&1 | grep 'inet6 ' |awk '{print $2}' >> %s  2>&1", v, mem_file_v6)
            exec(cmd)
        end

        cmd = string.format("ip addr show  br-%s  2>&1 | grep 'inet ' |awk '{print $2}' >> %s 2>&1", v, mem_file_v4)
        exec(cmd)

        cmd = string.format("ip addr show  br-%s  2>&1 | grep 'inet6 ' |awk '{print $2}' >> %s 2>&1", v, mem_file_v6)
        exec(cmd)
    end
end

local function update_local_mem(mem_file, mem_set)
    local ret = file_exist(mem_file)
    if (ret == nil) then
        return
    end
    
    local content = file_read(mem_file)
    if (content == nil) then
        return
    end
    
    local cmds = {}
    for line in string.gmatch(content, "%C+") do
        if (string.find(line, '/') ~= nil) then
            ip, netmask = string.match(line, "(%S+)/(%d)")
            if (ip ~= nil) then
                table.insert(cmds, string.format("add %s %s -exist", mem_set, ip))
            end
        end
    end
    exec_ipset_batch(cmds)
end

local function update_relation_local_mem(setname, mem_table, suffix)
    suffix = suffix or ""
    mem_file_v4 = string.format("/tmp/fwmng/%s%s_ipv4", setname, suffix)
    mem_file_v6 = string.format("/tmp/fwmng/%s%s_ipv6", setname, suffix)

    mem_set_v4 = string.format("DenyLocal_%s_v4%s", setname, suffix)
    mem_set_v6 = string.format("DenyLocal_%s_v6%s", setname, suffix)

    get_iface_ip(mem_table, mem_file_v4, mem_file_v6)
    
    update_local_mem(mem_file_v4, mem_set_v4)
    update_local_mem(mem_file_v6, mem_set_v6)
end

function safeZoneLib.update_relation_zone(setname, RelZone, mem_table, suffix)
    suffix = suffix or ""
    if (table.maxn(RelZone) ~= 0) then
        local cmds = {}
        for k,v in pairs(RelZone) do
            table.insert(cmds, string.format("add RelZone_%s%s %s -exist", setname, suffix, v))
        end
        exec_ipset_batch(cmds)
    end

    if (table.maxn(mem_table) ~= 0) then
        update_relation_local_mem(setname, mem_table, suffix)
    end
end

function safeZoneLib.add_relation_rule(setname, zone_type)
    if (zone_type == "lan") then
        cmd = string.format("iptables -w -t filter -A safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -t filter -A safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("iptables -w -t filter -A safeZoneRelLocal -m set --match-set %s src,src -m set --match-set DenyLocal_%s_v4 dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)

        cmd = string.format("ip6tables -w -t filter -A safeZoneRelLocal -m set --match-set %s src,src -m set --match-set DenyLocal_%s_v6 dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
    end

    if (zone_type == "wan") then
        cmd = string.format("iptables -w -t filter -A safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j ACCEPT >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -t filter -A safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j ACCEPT >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
    end
end

function safeZoneLib.remove_relation_rule(setname, zone_type)
    if (zone_type == "lan") then
        cmd = string.format("iptables -w -t filter -D safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -t filter -D safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("iptables -w -t filter -D safeZoneRelLocal -m set --match-set %s src,src -m set --match-set DenyLocal_%s_v4 dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        cmd = string.format("ip6tables -w -t filter -D safeZoneRelLocal -m set --match-set %s src,src -m set --match-set DenyLocal_%s_v6 dst -j DROP >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
    end
    
    if (zone_type == "wan") then
        cmd = string.format("iptables -w -t filter -D safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j ACCEPT >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -t filter -D safeZoneRel -m set --match-set %s src,src -m set --match-set RelZone_%s dst,dst -j ACCEPT >/dev/null 2>&1 ", setname, setname)
        exec(cmd)
    end
end

function safeZoneLib.build_index(list)
    cfg_idx_tb = {}
    cfg_access_tb = {}
    for k, v in pairs(list) do
        cfg_idx_tb[v["uuid"]] = k
        cfg_access_tb[v["uuid"]] = {}
        for ref_k, ref_v in pairs(v["zoneAccess"]) do
            cfg_access_tb[v["uuid"]][ref_v] = ref_k
        end
    end
end

function safeZoneLib.query_ipset_names()
    local ipset_names = {}
    local output = exec_popen("ipset -n -L 2>/dev/null")
    if (output ~= nil) then
        for name in string.gmatch(output, "%S+") do
            ipset_names[name] = true
        end
    end
    return ipset_names
end

function safeZoneLib.flush_all_deny_zones(setname_list)
    local cmds = {}
    for _, setname in ipairs(setname_list) do
        table.insert(cmds, string.format("flush RelZone_%s", setname))
        table.insert(cmds, string.format("flush DenyLocal_%s_v4", setname))
        table.insert(cmds, string.format("flush DenyLocal_%s_v6", setname))
    end
    exec_ipset_batch(cmds)
end

function safeZoneLib.create_shadow_zones(setname_list)
    -- Only creates sets; does not flush.  RelZone_sw (list:set) is created
    -- via exec() so a failure is silent and does not abort the batch below.
    -- All DenyLocal creates carry -exist, so the batch never aborts.
    local cmds = {}
    for _, setname in ipairs(setname_list) do
        exec(string.format("ipset create RelZone_%s_sw list:set size 64 -exist 2>/dev/null", setname))
        table.insert(cmds, string.format("create DenyLocal_%s_v4_sw hash:ip family inet -exist", setname))
        table.insert(cmds, string.format("create DenyLocal_%s_v6_sw hash:ip family inet6 -exist", setname))
    end
    exec_ipset_batch(cmds)
end

function safeZoneLib.flush_shadow_zones(setname_list)
    -- Flushes all shadow sets.  Must be called after create_shadow_zones so
    -- every set is guaranteed to exist; the batch will not abort mid-way.
    local cmds = {}
    for _, setname in ipairs(setname_list) do
        table.insert(cmds, string.format("flush RelZone_%s_sw", setname))
        table.insert(cmds, string.format("flush DenyLocal_%s_v4_sw", setname))
        table.insert(cmds, string.format("flush DenyLocal_%s_v6_sw", setname))
    end
    exec_ipset_batch(cmds)
end

function safeZoneLib.swap_shadow_zones(setname_list)
    local cmds = {}
    for _, setname in ipairs(setname_list) do
        table.insert(cmds, string.format("swap RelZone_%s RelZone_%s_sw", setname, setname))
        table.insert(cmds, string.format("swap DenyLocal_%s_v4 DenyLocal_%s_v4_sw", setname, setname))
        table.insert(cmds, string.format("swap DenyLocal_%s_v6 DenyLocal_%s_v6_sw", setname, setname))
    end
    exec_ipset_batch(cmds)
end

function safeZoneLib.destroy_shadow_zones(setname_list)
    safeZoneLib.flush_shadow_zones(setname_list)

    local cmds_destroy = {}
    for _, setname in ipairs(setname_list) do
        table.insert(cmds_destroy, string.format("destroy RelZone_%s_sw", setname))
        table.insert(cmds_destroy, string.format("destroy DenyLocal_%s_v4_sw", setname))
        table.insert(cmds_destroy, string.format("destroy DenyLocal_%s_v6_sw", setname))
    end
    exec_ipset_batch(cmds_destroy)
end

local function get_intf4_count(sname)
    if (ipset_cache ~= nil) then
        local n = 0
        for ipname, _ in pairs(ipset_cache) do
            if (string.find(ipname, sname, 1, true) ~= nil and
                string.find(ipname, "intf4", 1, true) ~= nil) then
                n = n + 1
            end
        end
        return n
    end
    cmd = string.format("ipset -n -L 2>/dev/null|grep %s |grep 'intf4'|wc -l 2>/dev/null", sname)
    return exec_popen(cmd)
end

function safeZoneLib.update_relation_rule(node, setname, list, zone_type, ipset_cache, suffix)
    local RelZone = {}
    local RelZone_intf = {}

    if (ipset_cache == nil) then
        safeZoneLib.build_index(list)
    end

    if (zone_type == "lan") then
        --[[ 找到不允许访问的域添加到集合中 ]]--
        for k,v in pairs(cfg_idx_tb) do
            if (k ~= node["uuid"] and cfg_access_tb[node["uuid"]][k] == nil) then
                for conf_k, conf_v in pairs(list[v]["mem"]) do
                    if (conf_v == "lan") then
                        table.insert(RelZone_intf, "pppoe_pool_alloc_addr")
                    end
                end

                intf = string.format("%s_intf4", list[v]["setname"])
                table.insert(RelZone_intf, intf)

                intf = string.format("%s_intf6", list[v]["setname"])
                table.insert(RelZone_intf, intf)

                -- 如果存在其他的集合,同步添加到对应的关系中
                count = get_intf4_count(list[v]["setname"])

                for i=1, count - 1, 1 do
                    addname = list[v]["setname"].."_"..i
                    intf = string.format("%s_intf4", addname)
                    table.insert(RelZone_intf, intf)

                    intf = string.format("%s_intf6", addname)
                    table.insert(RelZone_intf, intf)
                end

                RelZone[list[v]["setname"]] = 1
            end
        end

    end
    
    if (zone_type == "wan") then
        for k,v in pairs(node["zoneAccess"]) do
            local idx = cfg_idx_tb[v]
            local name = list[idx]["setname"]

            intf = string.format("%s_intf4", name)
            table.insert(RelZone_intf, intf)

            intf = string.format("%s_intf6", name)
            table.insert(RelZone_intf, intf)

            -- 如果存在其他的集合,同步添加到对应的关系中
            count = get_intf4_count(name)

            for i=1, count - 1, 1 do
                addname = name.."_"..i
                intf = string.format("%s_intf4", addname)
                table.insert(RelZone_intf, intf)

                intf = string.format("%s_intf6", addname)
                table.insert(RelZone_intf, intf)
            end
        end
       
        for k,v in pairs(cfg_idx_tb) do
            if (k ~= node["uuid"] and cfg_access_tb[node["uuid"]][k] == nil) then
                RelZone[list[v]["setname"]] = 1
            end
        end
    end
    
    local mem_table = {}
    for k,v in pairs(list) do
        local name = v["setname"]
        local mem = v["mem"]
        if (name ~= nil and RelZone[name] ~= nil and mem ~= nil) then
            for mem_k, mem_v in pairs(mem) do
                table.insert(mem_table, mem_v)
            end
        end
    end

    safeZoneLib.update_relation_zone(setname, RelZone_intf, mem_table, suffix)
end

function safeZoneLib.add_relation(node, setname, list)
    zone_type = node["type"] 

    safeZoneLib.remove_relation_rule(setname, zone_type)

    safeZoneLib.flush_deny_zone(setname)

    safeZoneLib.destroy_deny_zone(setname)

    safeZoneLib.create_deny_zone(setname)
    
    safeZoneLib.flush_deny_zone(setname)

    safeZoneLib.add_relation_rule(setname, zone_type)

    safeZoneLib.update_relation_rule(node, setname, list, zone_type)
end

function safeZoneLib.update_serv_rule(setname, servArray)
    for k,v in pairs(servArray) do
        cmd = string.format("iptables -w -N denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
        
        cmd = string.format("iptables -w -A denyServ%s -j denyServ%s_%s >/dev/null 2>&1  ", setname, setname, v)
        exec(cmd)

        cmd = string.format("ip6tables -w -N denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -A denyServ%s -j denyServ%s_%s >/dev/null 2>&1  ", setname, setname, v)
        exec(cmd)

        if (v == "web") then
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p tcp -m multiport --dport 80,443 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_web >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p tcp -m multiport --dport 80,443 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p tcp -m multiport --dport 80,443 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_web >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p tcp -m multiport --dport 80,443 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
        elseif (v == "ping") then
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p icmp --icmp-type echo-request -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_ping >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p icmp --icmp-type echo-request -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p ipv6-icmp --icmpv6-type echo-request -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_ping >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p ipv6-icmp --icmpv6-type echo-request -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
        elseif (v == "dns") then
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p tcp --dport 53 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dns >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p tcp --dport 53 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp --dport 53 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dns >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp --dport 53 -j DROP", setname, v)
            exec(cmd)

            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p tcp --dport 53 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dns >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p tcp --dport 53 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp --dport 53 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dns >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp --dport 53 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
        elseif (v == "dhcp") then
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 67,68 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dhcp >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 67,68 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 546,547 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_dhcp >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 546,547 -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
        elseif (v == "snmp") then
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 161,162 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix %s_snmp >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("iptables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 161,162  -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 161,162 -m limit --limit 50/sec --limit-burst 100  -j NFLOG --nflog-group 1 --nflog-prefix %s_snmp >/dev/null 2>&1 ", setname, v, setname)
            exec(cmd)
            
            cmd = string.format("ip6tables -w -t filter -A denyServ%s_%s -p udp -m multiport --dport 161,162  -j DROP >/dev/null 2>&1 ", setname, v)
            exec(cmd)
        else
            print("no type support")
        end
    end
end

function safeZoneLib.add_serv_rule(setname)
    cmd = string.format("iptables -w -N denyServ%s  ", setname)
    exec(cmd)

    cmd = string.format("iptables -w -t filter -A safeZoneServ -m set --match-set %s src,src -j denyServ%s >/dev/null 2>&1 ", setname, setname)
    exec(cmd)

    cmd = string.format("ip6tables -w -N denyServ%s  ", setname)
    exec(cmd)

    cmd = string.format("ip6tables -w -t filter -A safeZoneServ -m set --match-set %s src,src -j denyServ%s >/dev/null 2>&1 ", setname, setname)
    exec(cmd)
end

function safeZoneLib.del_serv_rule(setname)
    cmd = string.format("iptables -w -t filter -D safeZoneServ -m set --match-set %s src,src -j denyServ%s >/dev/null 2>&1 ", setname, setname)
    exec(cmd)

    cmd = string.format("iptables -w -F denyServ%s >/dev/null 2>&1  ", setname)
    exec(cmd)
    
    cmd = string.format("iptables -w -X denyServ%s >/dev/null 2>&1  ", setname)
    exec(cmd)
    
    cmd = string.format("ip6tables -w -t filter -D safeZoneServ -m set --match-set %s src,src -j denyServ%s >/dev/null 2>&1 ", setname, setname)
    exec(cmd)

    cmd = string.format("ip6tables -w -F denyServ%s >/dev/null 2>&1  ", setname)
    exec(cmd)
    
    cmd = string.format("ip6tables -w -X denyServ%s >/dev/null 2>&1  ", setname)
    exec(cmd)
end

function safeZoneLib.clear_serv_rule(setname, servArray)
    local servList
    local content = dev_sta.fetch("get","safeZoneCap", "", 1)
    if (content ~= nil and content["data"] ~= nil) then
        content_list = cjson_safe.decode(content["data"])
        if (content_list ~= nil and content_list["servList"] ~= nil) then
            servList = content_list["servList"]
        end
    end
    
    if (servList == nil) then
        servList = servArray
    end

    for k,v in pairs(servList) do
        cmd = string.format("iptables -w -D denyServ%s -j denyServ%s_%s >/dev/null 2>&1  ", setname, setname, v)
        exec(cmd)

        cmd = string.format("iptables -w -F denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
        
        cmd = string.format("iptables -w -X denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -D denyServ%s -j denyServ%s_%s >/dev/null 2>&1  ", setname, setname, v)
        exec(cmd)

        cmd = string.format("ip6tables -w -F denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
        
        cmd = string.format("ip6tables -w -X denyServ%s_%s >/dev/null 2>&1  ", setname, v)
        exec(cmd)
    end
end

function safeZoneLib.safeZone_check_uuids(setnamelist)
    local config_file_path = "/etc/sd_config/single/safeZone.json"

    if (type(setnamelist) ~= "table") then
        return {}
    end

    local config_json = file_to_json(config_file_path)
    if (config_json == nil or config_json["list"] == nil) then
        local result = {}
        if (type(setnamelist) == "table") then
            for _, uuid in pairs(setnamelist) do
                result[uuid] = 0
            end
        end
        return result
    end

    -- 收集所有setname到一个集合中
    local setname_set = {}
    for _, item in pairs(config_json["list"]) do
        if (item["setname"]) then
            setname_set[item["setname"]] = true
        end
    end

    -- 检查每个UUID是否存在
    local result = {}
    for _, uuid in pairs(setnamelist) do
        if (setname_set[uuid]) then
            result[uuid] = 1
        else
            result[uuid] = 0
        end
    end

    return result
end

function safeZoneLib.rebuild_all_zones(list)
    local setname_list = {}
    for _, v in pairs(list) do
        table.insert(setname_list, v["setname"])
    end
    safeZoneLib.build_index(list)
    
    local ipset_cache = safeZoneLib.query_ipset_names()
    safeZoneLib.create_shadow_zones(setname_list)
    safeZoneLib.flush_shadow_zones(setname_list)
    for _, v in pairs(list) do
        safeZoneLib.update_relation_rule(v, v["setname"], list, v["type"], ipset_cache, "_sw")
    end
    safeZoneLib.swap_shadow_zones(setname_list)
    -- Shadow sets are intentionally kept alive after swap so that the next
    -- rebuild can reuse them (create_shadow_zones will flush them).  They are
    -- only destroyed when the zone itself is deleted (destroy_deny_zone).
end

return safeZoneLib
