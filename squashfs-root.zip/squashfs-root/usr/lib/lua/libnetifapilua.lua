module("libnetifapilua", package.seeall);
package.cpath = package.cpath .. ";/usr/lib/libnetifapi.so"
local libnetifapi = require "libnetifapi"
local dev_config = require "dev_config"
local net_debug = require "utils.debug"
local cjson = require "cjson";
local tool = require "dev.tools.common"
local ac_config = require "ac_config"
local wireless_vlan_count_file = "/etc/netifcfg/wireless_vlan_count.json"
local libjsn = require("utils.json");
local netifcfg_path = "/etc/netifcfg"
local uci = require "luci.model.uci".cursor()

--�ж�����ӿ��Ƿ���ųɹ�
--interface��������� ����ӿ�
--vlan_id��������� vlan id
--return:����ֵ���ųɹ�����true��ʧ�ܷ���-1
function check_interface_binding(interface, vlan_id)
    local br_interface = "br-" .. interface
    local br_link = io.popen("ip link show " .. br_interface.." 2>/dev/null"):read("*all")
    if (br_link == nil) then
        return false
    end
    local br_name = string.match(br_link, "@(%S+):%s+<")
    if br_name == nil then
        return false
    end
    local ubus_output = io.popen("ubus -t 3 call network.device status '{\"name\": \"" .. br_name .. "\"}' 2>/dev/null"):read("*all")
    if (ubus_output == nil) then
        return false
    end
    local bridge_vlans = string.match(ubus_output, "\"bridge%-vlans\":%s*(%b[])")
    if (bridge_vlans == nil) then
        return false
    end
    local bridge_vlans_table = cjson.decode(bridge_vlans)
    for i, vlan in ipairs(bridge_vlans_table) do
        if (vlan["id"] == vlan_id and vlan["ports"] ~= nil) then
            if (#vlan["ports"] > 0) then
                return true
            else
                return false
            end
        end
    end
    return false
end

--����ɾ��Ĭ��lan��
--return:void
function wireless_del_lan()
    local vlan_table = {"233"};

    --debug��ʼ��
    net_debug.debug_init("/tmp/libnetifapi/", "wireless_cfg.log", 100, net_debug.INFO, "1");
    local handle = io.popen("echo $$");
    local pid = tonumber(handle:read("*all"));
    handle:close();
    net_debug.lua_debug(net_debug.INFO, "pid:%d", pid);
    local str = table.concat(vlan_table, ",")
    local ret = libnetifapi.vlan_cfg(3, pid, str, "wireless");
    if (ret == 0) then
        net_debug.lua_debug(net_debug.ERROR, "vlan lan_del fail");
        return;
    end
    net_debug.lua_debug(net_debug.INFO, "vlan lan_del success");

    return;
end

--ɾ����Ҫ�ж�
local function get_wireless_config(vlan_table)
    local single = false;
    local wireless_json = {};

    --���ÿ�������ȡ�������ݣ�ac_config)
    local ac_result = ac_config.fetch("get", "wireless", nil, 0, nil, nil, nil, nil, nil);
    if (ac_result == nil or type(ac_result) ~= "table") then
        net_debug.lua_debug(net_debug.ERROR, "ac_result is nil");
        return;
    end
    if (tool.json_check(ac_result["data"]) == false) then
        net_debug.lua_debug(net_debug.ERROR, "File of %s is not in JSON format.", "ac_config_config get -m wireless fsil");
        return;
    end
    wireless_json = cjson.decode(ac_result["data"]);
    if (wireless_json == nil) then
        net_debug.lua_debug(net_debug.INFO, "data fail");
        return;
    end
    --���ÿ�������ȡ�������ݣ�dev_config)
    if (wireless_json["existIndepend"] == "true") then
        local dev_result  = dev_config.fetch("get", "wireless", nil, 0, nil, nil, nil, nil, nil);
        if (dev_result == nil or type(dev_result) ~= "table") then
            net_debug.lua_debug(net_debug.ERROR, "dev_result is nil");
            return;
        end
        single = true;
        if (tool.json_check(dev_result["data"]) == false) then
            net_debug.lua_debug(net_debug.ERROR, "File of %s is not in JSON format.", "dev_config get -m wireless fsil");
            return;
        end
        wireless_json = cjson.decode(dev_result["data"]);
        if (wireless_json == nil) then
            net_debug.lua_debug(net_debug.INFO, "data fail");
            return;
        end
    end
    --��ӡ����
    if (single == true) then
        net_debug.lua_debug(net_debug.INFO, "dev_config get -m wireless %s", cjson.encode(wireless_json));
    else
        net_debug.lua_debug(net_debug.INFO, "ac_config get -m wireless %s", cjson.encode(wireless_json));
    end
    --�ж�ssidList�Ƿ����
    if (wireless_json["ssidList"] == nil or wireless_json["ssidList"] == "") then
        net_debug.lua_debug(net_debug.ERROR, "ssidList is not exist");
        return;
    end
    for i, var in ipairs(wireless_json["ssidList"]) do
        local vlan_id = var["vlanId"];
        for i, id in ipairs(vlan_table) do
            if (id == vlan_id) then
                table.remove(vlan_table, i);
                net_debug.lua_debug(net_debug.INFO, "vlan %s not del", tostring(vlan_id));
                break
            end
        end
    end
    net_debug.lua_debug(net_debug.INFO, "output vlan '%s'", cjson.encode(vlan_table));

    return;
end

--����ɾ��lan_x��
--return:void
function wireless_vlan_del(vlan_list, user)
    local vlan_table = {};
    local seen = {};
    -- local count = 0;
    -- local sign = false;
    -- local wireless_json = {};

    --debug��ʼ��
    net_debug.debug_init("/tmp/libnetifapi/", "wireless_cfg.log", 100, net_debug.INFO, "1");
    if (vlan_list == nil or #vlan_list == 0) then
        lua_debug.lua_debug(lua_debug.INFO, "vlan_list is empty.");
        return;
    end
    -- --�ж�/etc/netifcfg/wireless_vlan_count.json�Ƿ�����
    -- if (tool.file_exist(wireless_vlan_count_file) == true) then
    --     wireless_json = libjsn.get_json_table_from_file(wireless_vlan_count_file);
    --     if (wireless_json == nil) then
    --         net_debug.lua_debug(net_debug.ERROR, "load %s fail", wireless_vlan_count_file);
    --     end
    -- end
    --����vlan_list��vlan�ж��Ƿ���Ҫɾ��
    for i, vlanid in ipairs(vlan_list) do
        if (vlanid ~= nil and tonumber(vlanid) ~= nil and tonumber(vlanid) > 1 and vlanid ~= "233") then
            -- if (wireless_json ~= nil and wireless_json[vlanid] ~= nil and wireless_json[vlanid]["count"] ~= nil) then
            --     sign = true;
            --     count = wireless_json[vlanid]["count"];
            --     print(tostring(count));
            --     count = count - 1;
            --     wireless_json[vlanid]["count"] = count;
            --     print(tostring(count));
            --     if (count <= 0) then
            --         --ɾ�����ֶ�
            --         wireless_json[vlanid] = nil;
            --         if (not seen[vlanid]) then
            --             table.insert(vlan_table, vlanid);
            --             seen[vlanid] = true;
            --         end
            --     end
            -- else
            if (not seen[vlanid]) then
                table.insert(vlan_table, vlanid);
                seen[vlanid] = true;
            end
            -- end
        end
    end
    -- �жϲ���ɾ����vlan
    --get_wireless_config(vlan_table);
    -- --�ж��Ƿ���Ҫ�����ļ�
    -- if (sign == true) then
    --     tool.file_write(wireless_vlan_count_file, cjson.encode(wireless_json), "w");
    --     net_debug.lua_debug(net_debug.INFO, "wireless vlan count save:%s", cjson.encode(wireless_json));
    -- end
    --�·�����
    if (vlan_table ~= nil and #vlan_table ~= 0) then
        --��ȡ�ű��Ľ���ID ����luaʵ��
        local handle = io.popen("echo $$");
        local pid = tonumber(handle:read("*all"));
        handle:close();
        net_debug.lua_debug(net_debug.INFO, "pid:%d", pid);
        local str = table.concat(vlan_table, ",");
        --Ĭ��Ϊwireless
        if (user == nil or user == "") then
            ret = libnetifapi.vlan_cfg(2, pid, str, "wireless");
        else
            ret = libnetifapi.vlan_cfg(2, pid, str, user);
        end
        if (ret == 0) then
            net_debug.lua_debug(net_debug.ERROR, "vlan lan_del fail");
            return;
        end
        net_debug.lua_debug(net_debug.INFO, "del vlan %s", cjson.encode(vlan_table));
    else
        net_debug.lua_debug(net_debug.ERROR, "not vlan del");
        return;
    end

    return;
end

--��������lan_x��
--return:void
function wireless_vlan_add(vlan_list, user)
    -- local wireless_json = {};
    local vlan_table = {};
    local seen = {};
    local sign = false;

    --debug��ʼ��
    net_debug.debug_init("/tmp/libnetifapi/", "wireless_cfg.log", 100, net_debug.INFO, "1");
    if (vlan_list == nil or #vlan_list == 0) then
        lua_debug.lua_debug(lua_debug.INFO, "vlan_list is empty.");
        return;
    end
    -- --�ж�/etc/netifcfg/wireless_vlan_count.json�Ƿ�����
    -- if (tool.file_exist(wireless_vlan_count_file) == true) then
    --     wireless_json = libjsn.get_json_table_from_file(wireless_vlan_count_file);
    --     if (wireless_json == nil) then
    --         net_debug.lua_debug(net_debug.ERROR, "load %s fail", wireless_vlan_count_file);
    --         wireless_json = {};
    --     end
    -- else
    --     --�����ļ���
    --     if (tool.file_exist(netifcfg_path) ~= true) then
    --         os.execute("mkdir -p /etc/netifcfg 2>/dev/null 1>&2");
    --     end
    -- end
    --����vlan_list��vlan�ж��Ƿ���Ҫɾ��
    for i, vlanid in ipairs(vlan_list) do
        if (vlanid ~= nil and tonumber(vlanid) ~= nil and tonumber(vlanid) > 1 and vlanid ~= "233") then
            -- --���Ӽ���
            -- if (wireless_json[vlanid] == nil) then
            --     wireless_json[vlanid] = {};
            --     wireless_json[vlanid]["count"] = 0;
            -- end
            -- sign = true;
            -- wireless_json[vlanid]["count"] = wireless_json[vlanid]["count"] + 1;
            -- wireless_json[vlanid]["vlanid"] = vlanid;
            --���Ӽ���
            if (not seen[vlanid]) then
                table.insert(vlan_table, vlanid);
                seen[vlanid] = true;
            end
        end
    end
    -- --�ж��Ƿ���Ҫ�����ļ�
    -- if (sign == true) then
    --     tool.file_write(wireless_vlan_count_file, cjson.encode(wireless_json), "w");
    --     net_debug.lua_debug(net_debug.INFO, "wireless vlan count save:%s", cjson.encode(wireless_json));
    -- end
    --�·�����
    if (vlan_table ~= nil and #vlan_table ~= 0) then
        --��ȡ�ű��Ľ���ID ����luaʵ��
        local handle = io.popen("echo $$");
        local pid = tonumber(handle:read("*all"));
        handle:close();
        net_debug.lua_debug(net_debug.INFO, "pid:%d", pid);
        local str = table.concat(vlan_table, ",");
        --Ĭ��Ϊwireless
        if (user == nil or user == "") then
            ret = libnetifapi.vlan_cfg(1, pid, str, "wireless");
        else
            ret = libnetifapi.vlan_cfg(1, pid, str, user);
        end
        if (ret == 0) then
            net_debug.lua_debug(net_debug.ERROR, "vlan lan_del fail");
            return;
        end
        net_debug.lua_debug(net_debug.INFO, "add vlan %s", cjson.encode(vlan_table));
    else
        net_debug.lua_debug(net_debug.ERROR, "not vlan add");
        return;
    end
end

--�����ж�vlan�Ƿ�Ϸ�
--return:�Ϸ�����"yes"�����Ϸ�����"no"
function is_vid_legal(vid_list)
    local is_legal= "yes"

    --debug��ʼ��
    net_debug.debug_init("/tmp/libnetifapi/", "wireless_cfg.log", 100, net_debug.INFO, "1");
    if (vid_list == nil or #vid_list == 0) then
        lua_debug.lua_debug(lua_debug.INFO, "vid_list is empty.");
        is_legal = "err";
    end
    is_legal = libnetifapi.vid_legal(vid_list);
    if (is_legal == "no") then
        is_legal = "no";
    else
        is_legal = "yes";
    end
    net_debug.lua_debug(net_debug.INFO, "is_vid_legal:%s - %s",cjson.encode(vid_list), is_legal);

    return is_legal;
end

--��ȡ�ӿڶ�Ӧport
function get_ifname_port(ifname)
    if ifname == nil or ifname == "" then
        return nil;
    end
    local vlan_section = "vlan_" .. ifname;
    -- ��ȡ����port�ڻ�ȡÿ��port�ڵ�ifname��
    local ports = uci:get_list("network", vlan_section, "ports");
    if not ports or #ports == 0 then
        return nil;
    end
    local result = {}
    for _, port in ipairs(ports) do
        local name = port:match("^([^:]+)");
        if name and name ~= "" then
            table.insert(result, name);
        end
    end
    if #result == 0 then
        return nil;
    end
    local out = table.concat(result, " ");

    return out;
end