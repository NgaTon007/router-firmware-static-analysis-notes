#! /usr/bin/env lua

intfGroupIpset = {}

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    os.execute(sh_cmd)
end

local function exec_popen(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    local sh_ret_handle = io.popen(sh_cmd);
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret;
end

local function ipset_restore(cmds)
    if #cmds == 0 then
        return
    end

    local f = io.popen("ipset -exist restore 2>/dev/null", "w")
    if f then
        for _, c in ipairs(cmds) do
            f:write(c .. "\n")
        end
        f:close()
    end
end

-- Collect all expanded set base names (setname_N) that currently exist.
local function ipset_collect_expand_names(setname)
    local cmd = string.format("ipset -n -L 2>/dev/null | grep -o '^%s_[0-9][0-9]*_intf4$'", setname)
    local output = exec_popen(cmd) or ""
    local names = {}
    for matched in output:gmatch("[^\n]+") do
        local name = matched:match("^(.+)_intf4$")
        if name then
            table.insert(names, name)
        end
    end
    return names
end

-- Remove each set in intf_sets from every RelZone_* list:set in one batch.
-- Required before destroying hash:net,iface sets that are referenced as
-- members of a RelZone; otherwise the kernel rejects the destroy silently.
local function ipset_deref_from_relzones(intf_sets)
    if #intf_sets == 0 then
        return
    end
    local rz_output = exec_popen("ipset -n -L 2>/dev/null | grep '^RelZone_'") or ""
    local cmds = {}
    for rz in rz_output:gmatch("[^\n]+") do
        if rz ~= "" then
            for _, s in ipairs(intf_sets) do
                table.insert(cmds, string.format("del %s %s", rz, s))
            end
        end
    end
    ipset_restore(cmds)
end

function intfGroupIpset.ipset_create_set(setname)
    exec(string.format("ipset create %s list:set size 64 -exist 2>/dev/null", setname))

    local cmds = {
        string.format("create %s_intf4 hash:net,iface family inet maxelem 64 -exist", setname),
        string.format("create %s_intf6 hash:net,iface family inet6 maxelem 64 -exist", setname),
        string.format("add %s %s_intf4 -exist", setname, setname),
        string.format("add %s %s_intf6 -exist", setname, setname),
    }
    ipset_restore(cmds)
end

-- Destroy only the expanded sets (setname_N_intf4/intf6) for setname.
-- The caller must have already flushed the base list:set so these sets are
-- no longer referenced by it before calling this function.
local function ipset_destroy_expand_set(setname)
    local names = ipset_collect_expand_names(setname)
    if #names == 0 then
        return
    end

    local intf_sets = {}
    for _, name in ipairs(names) do
        table.insert(intf_sets, string.format("%s_intf4", name))
        table.insert(intf_sets, string.format("%s_intf6", name))
    end

    -- Step 1: deref from RelZone_* sets so destroy is not blocked.
    ipset_deref_from_relzones(intf_sets)

    -- Step 2: flush entries to release kernel netdev notifier references.
    local flush_cmds = {}
    for _, s in ipairs(intf_sets) do
        table.insert(flush_cmds, string.format("flush %s", s))
    end
    ipset_restore(flush_cmds)

    -- Step 3: destroy in batch.
    local destroy_cmds = {}
    for _, s in ipairs(intf_sets) do
        table.insert(destroy_cmds, string.format("destroy %s", s))
    end
    ipset_restore(destroy_cmds)
end

function intfGroupIpset.ipset_destroy_set(setname)
    local expand_names = ipset_collect_expand_names(setname)

    -- Build the complete list of intf4/intf6 sets (base + all expanded).
    local intf_sets = {
        string.format("%s_intf4", setname),
        string.format("%s_intf6", setname),
    }
    for _, name in ipairs(expand_names) do
        table.insert(intf_sets, string.format("%s_intf4", name))
        table.insert(intf_sets, string.format("%s_intf6", name))
    end

    -- Step 1: remove all intf sets from any RelZone_* list:sets so the
    -- destroy below is not silently blocked by a reference-count error.
    ipset_deref_from_relzones(intf_sets)

    -- Step 2: single flush batch — detach all entries from list:set and
    -- release kernel netdev notifier references.
    local flush_cmds = { string.format("flush %s", setname) }
    for _, s in ipairs(intf_sets) do
        table.insert(flush_cmds, string.format("flush %s", s))
    end
    ipset_restore(flush_cmds)

    -- Step 3: single destroy batch — expanded sets first (no longer referenced
    -- after the flush above), then base intf sets, then the list:set itself.
    local destroy_cmds = {}
    for _, name in ipairs(expand_names) do
        table.insert(destroy_cmds, string.format("destroy %s_intf4", name))
        table.insert(destroy_cmds, string.format("destroy %s_intf6", name))
    end
    table.insert(destroy_cmds, string.format("destroy %s_intf4", setname))
    table.insert(destroy_cmds, string.format("destroy %s_intf6", setname))
    table.insert(destroy_cmds, string.format("destroy %s", setname))
    ipset_restore(destroy_cmds)
end

function intfGroupIpset.ipset_create_expand_set(setname)
    local cmds = {
        string.format("create %s_intf4 hash:net,iface family inet maxelem 64 -exist", setname),
        string.format("flush %s_intf4", setname),
        string.format("create %s_intf6 hash:net,iface family inet6 maxelem 64 -exist", setname),
        string.format("flush %s_intf6", setname),
    }
    ipset_restore(cmds)
end

-- Returns the number of intf4 and intf6 entries a single interface consumes.
-- wan: 2 entries each (br- + pppoe-),  lan: 1 entry each (br- only)
local function ipset_intf_entry_count(intf)
    if string.find(intf, "wan") ~= nil then
        return 2, 2
    elseif string.find(intf, "lan") ~= nil then
        return 1, 1
    end
    return 0, 0
end

-- First pass: assign each interface to a slot index based on actual entry counts.
-- Returns intf_to_slot table and the highest slot index used (cur_slot).
local function ipset_assign_slots(intflist, max_elem)
    local intf_to_slot = {}
    local cur_slot = 0
    local slot_count4 = 0
    local slot_count6 = 0

    for i, v in ipairs(intflist) do
        local need4, need6 = ipset_intf_entry_count(v)

        -- overflow into next slot if either counter would exceed max_elem
        if (slot_count4 + need4 > max_elem) or (slot_count6 + need6 > max_elem) then
            cur_slot = cur_slot + 1
            slot_count4 = 0
            slot_count6 = 0
        end

        intf_to_slot[i] = cur_slot
        slot_count4 = slot_count4 + need4
        slot_count6 = slot_count6 + need6
    end

    return intf_to_slot, cur_slot
end

-- Build commands to create expanded sets for slots 1..cur_slot
-- and link them into the base list:set.
local function ipset_build_expand_cmds(setname, cur_slot, max_elem, cmds)
    for i = 1, cur_slot do
        local name = setname .. "_" .. i
        table.insert(cmds, string.format("create %s_intf4 hash:net,iface family inet maxelem %d -exist", name, max_elem))
        table.insert(cmds, string.format("flush %s_intf4", name))
        table.insert(cmds, string.format("create %s_intf6 hash:net,iface family inet6 maxelem %d -exist", name, max_elem))
        table.insert(cmds, string.format("flush %s_intf6", name))
        table.insert(cmds, string.format("add %s %s_intf4 -exist", setname, name))
        table.insert(cmds, string.format("add %s %s_intf6 -exist", setname, name))
    end
end

-- Build commands to add all interface entries into their assigned slots.
local function ipset_build_entry_cmds(setname, intflist, intf_to_slot, cmds)
    for i, v in ipairs(intflist) do
        local slot = intf_to_slot[i]
        local name
        if slot == 0 then
            name = setname
        else
            name = setname .. "_" .. slot
        end

        --[[ wan/pppoe-wan ]]--
        if string.find(v, "wan") ~= nil then
            table.insert(cmds, string.format("add %s_intf4 0.0.0.0/0,br-%s", name, v))
            table.insert(cmds, string.format("add %s_intf4 0.0.0.0/0,pppoe-%s", name, v))
            table.insert(cmds, string.format("add %s_intf6 ::/0,br-%s", name, v))
            table.insert(cmds, string.format("add %s_intf6 ::/0,pppoe-%s", name, v))
        end

        --[[ lan ]]--
        if string.find(v, "lan") ~= nil then
            table.insert(cmds, string.format("add %s_intf4 0.0.0.0/0,br-%s", name, v))
            table.insert(cmds, string.format("add %s_intf6 ::/0,br-%s", name, v))
        end

        --[[ pppoe server ]]--
        if v == "lan" then
            table.insert(cmds, string.format("add %s pppoe_pool_alloc_addr", setname))
        end

        --[[ vpn interface ]]--
        --[[if (v == "vpn") then
            cmd = string.format("ipset add %s l2tp_pool_alloc_addr 2>/dev/null", setname)
            exec(cmd)

            cmd = string.format("ipset add %s pptp_pool_alloc_addr 2>/dev/null", setname)
            exec(cmd)

            cmd = string.format("ipset add %s_intf 0.0.0.0/0,tun0 2>/dev/null", setname, v)
            exec(cmd)
        end]]--
    end
end

function intfGroupIpset.ipset_update_set(setname, intflist)
    local MAX_ELEM = 64

    -- Phase 1: flush base sets and detach all list:set members.
    -- This must complete before ipset_destroy_expand_set is called so that
    -- expanded sets (setname_N_intf4/6) are no longer referenced by setname
    -- and can be safely destroyed.
    ipset_restore({
        string.format("flush %s_intf4", setname),
        string.format("flush %s_intf6", setname),
        string.format("flush %s", setname),
    })

    -- Phase 2: destroy any previously created expanded sets.
    -- Safe now because setname no longer holds references to them.
    ipset_destroy_expand_set(setname)

    -- Phase 3: rebuild — re-link base sets into the list:set, create expanded
    -- sets if needed, and add all interface entries.
    local cmds = {
        string.format("add %s %s_intf4", setname, setname),
        string.format("add %s %s_intf6", setname, setname),
    }
    local intf_to_slot, cur_slot = ipset_assign_slots(intflist, MAX_ELEM)
    ipset_build_expand_cmds(setname, cur_slot, MAX_ELEM, cmds)
    ipset_build_entry_cmds(setname, intflist, intf_to_slot, cmds)
    ipset_restore(cmds)
end

return intfGroupIpset
