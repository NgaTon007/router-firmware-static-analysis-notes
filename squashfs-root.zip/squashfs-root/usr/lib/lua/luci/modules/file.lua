module("luci.modules.file", package.seeall)
-- 智能设备终端名称批量修改
function fileTml()
    local path = "/tmp/nt_info/nt_tml_file.txt"
    local tool = require "luci.utils.tool"
    tool.weblog(path, "_path")
    tool.uploadFile(path, 1)
    local _size = nixio.fs.stat(path).size
    if _size < 20480 then
        tool.weblog(path, "UPGRADE FILE SUCC!")
        return {
            rcode = 0,
            size = _size
        }
    else
        nixio.fs.unlink(path)
        return {rcode = 2, msg = "The file is too large"}
    end
end
--背景图片上传
function portal(params)
    local query_table = {}
    local path = "/tmp/guest_auth/"
    local tool = require "luci.utils.tool"
    if not nixio.fs.access(path) then
        nixio.fs.mkdir(path)
    end
    for query in string.gmatch(params, "%w+=%w+") do
        for name, value in string.gmatch(query, "([^&=]+)=([^&=]+)") do
            query_table[name] = value
        end
    end
    path = path .. query_table["target"] .. "." .. query_table["type"]
    tool.uploadFile(path, 1)
    return {rcode = "0"}
end
-- 特征库本地升级
function upgradeSignature()
    local type = luci.http.formvalue("type", true)
    local filepath = "/tmp/signature/"
    local SIGN_PATH = "/tmp/signature/app_signature.tar"
    if type == "rule" then
        SIGN_PATH = "/tmp/nt_info/nt_rule.tar.gz"
        filepath = "/tmp/nt_info/"
    else
        if type == "oui" then
            SIGN_PATH = "/tmp/nt_info/nt_oui.tar.gz"
            filepath = "/tmp/nt_info/"
        else
            SIGN_PATH = "/tmp/signature/app_signature.tar"
        end
    end
    if not nixio.fs.access(filepath) then
        nixio.fs.mkdir(filepath)
    end
    local tool = require "luci.utils.tool"
    tool.uploadFile(SIGN_PATH, 1)
    local _size = nixio.fs.stat(SIGN_PATH).size
    if _size < 1048576 then
        tool.weblog(SIGN_PATH, "UPGRADE FILE SUCC!")
        return {
            rcode = 0,
            size = _size
        }
    else
        nixio.fs.unlink(SIGN_PATH)
        return {rcode = 2, msg = "The file is too large"}
    end
end

local DELETE_PID = "/tmp/firmware_delete_pid"
function killDeleteFireware()
    if not nixio.fs.access(DELETE_PID) then
        return
    end
    local pid = nixio.fs.readfile(DELETE_PID)
    nixio.fs.unlink(DELETE_PID)
    if pid then
        -- 忽略不存在的进程，使用 pcall 捕获错误
        pcall(
            function()
                nixio.fs.kill(pid, 9)
            end
        )
    end
end

-- 升级设备(上传)
function upgradeLocal()
    local imageTmp = "/tmp/firmware.img"
    -- 判断安装包合法性  0：合法   1：不合法 151: 设备硬件不支持当前升级包; 201-208：槽位板卡硬件不支持当前升级包
    local function imageSupported()
        -- return os.execute(". /lib/functions.sh; include /lib/upgrade; platform_check_image %q >/dev/null" % imageTmp)
        local checkRes = false
        local uci = require "luci.model.uci".cursor()
        local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type") or "msw"
        if dev_type == "msw" then
            -- 交换机热备设备校验使用新接口
            local cmd = require("luci.modules.cmd")
            checkRes = cmd.devSta.get({device = "pc", module = "sysImageCheck", data = {image = imageTmp}}) or false
        end
        if checkRes == "" or not checkRes then
            local p =
                io.popen(
                ". /lib/functions.sh; include /lib/upgrade; platform_check_image %q >/dev/null \necho _$?" % imageTmp
            )
            checkRes = {
                code = (p:read "*a":match ".*%D(%d+)" + 0)
            }
        end
        return checkRes
    end

    -- 可用存储空间
    local function storageSize()
        local size = 0
        if nixio.fs.access("/proc/mtd") then
            for l in io.lines("/proc/mtd") do
                local d, s, e, n = l:match('^([^%s]+)%s+([^%s]+)%s+([^%s]+)%s+"([^%s]+)"')
                if n == "linux" or n == "firmware" or n == "ubi" then
                    size = tonumber(s, 16)
                    break
                end
            end
        elseif nixio.fs.access("/proc/partitions") then
            for l in io.lines("/proc/partitions") do
                local x, y, b, n = l:match("^%s*(%d+)%s+(%d+)%s+([^%s]+)%s+([^%s]+)")
                if b and n and not n:match("[0-9]") then
                    size = tonumber(b) * 1024
                    break
                end
            end
        end
        return size
    end
    local tool = require "luci.utils.tool"
    -- 上传升级包前清理缓存，增加升级成功率
    local shell = "sync;echo 3 > /proc/sys/vm/drop_caches;"
    tool.forkExec(shell)
    tool.weblog(shell, "UPGRADE CLEAN CACHE")

    -- 执行上传文件前删除定时任务
    killDeleteFireware()
    tool.uploadFile(imageTmp, 1)
    local _isPersist = not (not luci.http.formvalue("isPersist"))
    local isEstAll = luci.http.formvalue("isEstAll") or false

    if nixio.fs.access(imageTmp) then
        tool.weblog("exist", "UPGRADE BEFORE CHECK")
    end
    local checkRes = imageSupported()
    if nixio.fs.access(imageTmp) then
        tool.weblog("exist too", "UPGRADE AFTER CHECK")
    end
    local errCode = tonumber(checkRes.code) >= 107 and tonumber(checkRes.code) <= 119
    if isEstAll or checkRes.code == 0 or errCode then
        -- fork进程：（不执行升级时）一小时后自动删除升级包，防止web非正常关闭导致的升级包残留
        local pid = tool.forkExec("sleep 3600; rm -f %q; rm %q;" % {imageTmp, DELETE_PID})
        luci.sys.exec("echo %q > %q" % {pid, DELETE_PID})
        tool.debug("firmware_delete_pid: ", pid)

        local _realSize = nixio.fs.readfile("/tmp/tar_gz_size")
        local _size = _realSize and tonumber(_realSize) or nixio.fs.stat(imageTmp).size
        tool.weblog(_size, "UPGRADE SIZE")
        local _result = {
            code = checkRes.code,
            -- storage = storageSize(),
            size = _size,
            keep = _isPersist,
            path = imageTmp,
            valid = _realSize and true or (storageSize() > _size)
        }

        if isEstAll then
            local cmd = require("luci.modules.cmd")
            local pkgInfo = cmd.devSta.get({device = "pc", module = "tipc_verchk"})
            _result.pkgInfo = pkgInfo or {code = 0}
            if pkgInfo.code == "3" then
                nixio.fs.unlink(imageTmp)
            end
        end
        return _result
    else
        nixio.fs.unlink(imageTmp)
        -- luci.http.status(500, "Error")
        -- luci.http.write_json({code = 2})
        local system = require "luci.modules.system"
        if system.hasKillRemaining() then
            return {invalid = true, supportCode = 999}
        else
            return {invalid = true, supportCode = checkRes.code, checkRes = checkRes}
        end
    end
end

-- 导入配置
function restoreConfig(hasFile)
    local RESTORE_PATH = hasFile and "/overlay/backup-config.tar.gz" or "/tmp/restoreCmd"
    local tool = require "luci.utils.tool"
    local system = require("luci.modules.system")
    if not hasFile then
        tool.uploadFile(RESTORE_PATH, 1)
    end
    --luci.http.formvalue必须放在tool.uploadFile后面执行
    local localMac = luci.http.formvalue("localMac") or false
    local sysupgradeShell = "sysupgrade -r " .. RESTORE_PATH
    if localMac and localMac == "1" then
        sysupgradeShell = "sysupgrade --local-mac -r " .. RESTORE_PATH
    end
    local _result = luci.sys.exec(sysupgradeShell)
    if string.find(_result, "not supports") then
        return {code = 1, msg = _result}
    else
        local _shell = ""
        if nixio.fs.access("/backup/none_config_flag") then
            _shell = "rm -rf /backup/none_config_flag;"
        end

        _shell = _shell .. "sync; sleep 1"
        if path then
            _shell = _shell .. "; rm " .. path
        end
        -- _shell = _shell .. "; reboot >/dev/null 2>&1;"
        _shell = _shell .. system.getRebootShell("Import configuration") .. " >/dev/null 2>&1;"

        tool.forkExec(_shell)
        return {code = 0, addr = luci.http.getenv("SERVER_NAME") or "", _shell = _shell}
    end
end

-- 备份配置文件
function backupConfig()
    local tool = require "luci.utils.tool"
    local uci = require "luci.model.uci".cursor()

    local _backupCmd = "sysupgrade -b -"
    local devType = uci:get_first("sysinfo", "sysinfo", "product_class") or ""
    local _fileName =
        "backup-%s-%s-%s.tar.gz" %
        {
            luci.sys.hostname(),
            devType,
            os.date("%Y-%m-%d")
        }
    tool.downloadFile(_backupCmd, _fileName)
    return {fileName = _fileName}
end

-- 故障收集
function techSupport()
    local tool = require "luci.utils.tool"
    local uci = require "luci.model.uci".cursor()
    local _backupCmd = "/sbin/tech-support.sh sync"
    local _fileName =
        "tech-support-%s-%s.tar.gz" %
        {
            os.date("%Y-%m-%d-%H-%M-%S"),
            uci:get_first("sysinfo", "sysinfo", "serial_num")
        }
    tool.downloadFile(_backupCmd, _fileName)
    return {fileName = _fileName}
end

-- 下载抓包信息
function downloadPackDiagnose()
    -- 抓包文件临时路径
    local _packTmp = "/tmp/tcpdump.pcap"
    local tool = require "luci.utils.tool"
    local _fileName = "tcpdump-%s.pcap" % os.date("%Y-%m-%d")
    tool.downloadFile("cat " .. _packTmp, _fileName)
    return {fileName = _fileName}
end
-- 下载无线抓包信息
function downloadApPackDiagnose()
    -- 抓包文件临时路径
    local _packTmp = "/tmp/pcapService/tcpdump.pcap"
    local tool = require "luci.utils.tool"
    local _fileName = "tcpdump-%s.pcap" % os.date("%Y-%m-%d")
    tool.downloadFile("cat " .. _packTmp, _fileName)
    return {fileName = _fileName}
end
-- 下载OpenVpn客户端配置
function downloadPackOpenVpn()
    local tool = require "luci.utils.tool"
    local openvpn = require "luci.modules.openvpn"

    local type = luci.http.formvalue("type")
    local res = openvpn.isExistPackOpenVpn(type, true)
    local _fileName = ("%s_" .. res.fileName) % os.date("%Y%m%d")

    if res.isExist then
        tool.downloadFile("cat " .. res.path, _fileName)
    end
    return {fileName = _fileName, isExist = res.isExist}
end

-- 下载Vpn日志配置文件
function downloadPackVpnFile()
    local tool = require "luci.utils.tool"
    local type = luci.http.formvalue("type")
    local fileMap = {
        l2tp = "/tmp/l2tp_log.tar.gz",
        pptp = "/tmp/pptp_log.tar.gz",
        ipsec = "/tmp/strongswan.log",
        openvpn = "/tmp/openvpn.log"
    }
    local res = {}
    local path = fileMap[type] or nil
    if path and not (not nixio.fs.access(path)) then
        local pathArr = luci.util.split(path, "/")
        res = {
            path = path,
            fileName = pathArr[#pathArr]
        }
        local _fileName = ("%s_" .. res.fileName) % os.date("%Y%m%d")
        tool.downloadFile("cat " .. res.path, _fileName)
        return true
    end
    return "file is not exist"
end

-- 上传文件不写内容
function uploadNullFile()
    local tool = require "luci.utils.tool"
    tool.uploadFile(">/dev/null", 2)
    return {msg = "upload compete"}
end
-- wifi测速上传
local filepath = "/tmp/www-wifi-test/"
local filename = "wifiTest.file"
local path = filepath .. filename
function wifiTestUpload()
    local fs = require "nixio.fs"
    if not fs.access(filepath) then
        fs.mkdir(filepath)
    end
    local tool = require "luci.utils.tool"
    -- path = path .. os.time()
    if not fs.access(path) then
        tool.uploadFile(path, 1)
    else
        tool.uploadFile(">/dev/null", 2)
    end
    return {msg = "upload ok", path = path}
end
-- wifi测速下载
function wifiTestDownload()
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(path) then
        return {msg = "download fail, file is not exist", path = path}
    end
    tool.downloadFile("cat " .. path, filename)
    return {msg = "download ok", path = path}
end
-- wifi测速删除
function wifiTestDelete()
    local fs = require "nixio.fs"
    if fs.access(path) then
        fs.unlink(path)
    end
    return {msg = "delete ok", path = path}
end
-- pppoe配置下载
function pppoeDownload()
    local filepath = "/tmp/accounts_batch/"
    local filename = "pppoeserver_user_cfg_get.csv"
    local path = filepath .. filename
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(path) then
        return {msg = "download fail, file is not exist", path = path}
    end
    tool.downloadFile("cat " .. path, filename)
    return {msg = "download ok", path = path}
end
-- pppoe配置上传
function pppoeUpload()
    local filepath = "/tmp/"
    local filename = "pppoeserver_user_cfg_set.csv"
    local path = filepath .. filename
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(filepath) then
        fs.mkdir(filepath)
    end
    tool.uploadFile(path, 1)
    local _size = fs.stat(path).size
    if _size < 51200 then
        tool.weblog(path, "UPGRADE FILE SUCC!")
        return {
            rcode = 0,
            size = _size
        }
    else
        nixio.fs.unlink(path)
        return {rcode = 2, msg = "The file is too large"}
    end
end
-- pppoe模板下载
function pppoeMoelDownload()
    local filepath = "/usr/sbin/"
    local type = luci.http.formvalue("type")
    local filename = "pppoeserver_user_cfg_template_" .. type .. ".csv"
    local path = filepath .. filename
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(path) then
        return {msg = "download fail, file is not exist", path = path}
    end
    tool.downloadFile("cat " .. path, filename)
    return {msg = "download ok", path = path}
end
-- 磁盘日志下载
function diskLogDownload()
    local filepath = "/mnt/mmcblk0p1/storage_mgr/xlog_export/"
    local filename = "data.csv"
    local path = filepath .. filename
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(path) then
        return {msg = "download fail, file is not exist", path = path}
    end
    tool.downloadFile("cat " .. path, filename)
    return {msg = "download ok", path = path}
end
--sd-wan文件导出
function sdWanDownload()
    local time = os.time()
    local pathFile = "/tmp/sdwan_" .. time .. ".gz"
    local tool = require "luci.utils.tool"
    -- luci.sys.exec("tar -czvf /tmp/sdwan.gz tmp/sdwan/")
    tool.doShell("tar -czvf " .. pathFile .. " -C /tmp sdwan/")

    local fs = require "nixio.fs"
    if not fs.access(pathFile) then
        return {msg = "download fail, file is not exist"}
    end

    local _fileName = "sdwan-%s.gz" % os.date("%Y-%m-%d")
    tool.downloadFile("cat " .. pathFile, _fileName)

    -- 删除临时文件
    fs.unlink(pathFile)
    return {msg = "download ok"}
end
-- 验证认证日志
function AuthenCheck()
    local fs = require "nixio.fs"
    if not fs.access("/tmp/log/auth/") then
        return {
            isExist = false
        }
    end
    return {
        isExist = true
    }
end
-- 认证日志导出
function AuthenDownload()
    local time = os.time()
    local pathFile = "/tmp/log/auth/authen_" .. time .. ".gz"
    local tool = require "luci.utils.tool"
    tool.doShell("tar -czvf " .. pathFile .. " -C /tmp/log/auth/ .")

    local fs = require "nixio.fs"
    if not fs.access(pathFile) then
        return {msg = "download fail, file is not exist"}
    end

    local _fileName = "authen-%s.gz" % os.date("%Y-%m-%d")
    tool.downloadFile("cat " .. pathFile, _fileName)

    -- 删除临时文件
    fs.unlink(pathFile)
    return {msg = "download ok"}
end
-- 验证syslog导出文件是否存在
function syslogDownCheck()
    local fs = require "nixio.fs"
    if not fs.access("/tmp/std_syslog/gzip/") then
        return {
            isExist = false
        }
    end
end
--syslog文件导出
function syslogDownload()
    local time = os.time()
    local pathFile = "/tmp/syslog_" .. time .. ".gz"
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access("/tmp/std_syslog/gzip/") then
        fs.mkdir("/tmp/tmp_std_syslog/")
        tool.doShell("tar -czvf " .. pathFile .. " -C /tmp/tmp_std_syslog/ .")
        -- 删除临时文件
        fs.unlink("/tmp/tmp_std_syslog/")
    else
        tool.doShell("tar -czvf " .. pathFile .. " -C /tmp/std_syslog/gzip/ .")
    end
    if not fs.access(pathFile) then
        return {msg = "download fail, file is not exist"}
    end
    local _fileName = "std_syslog-%s.gz" % os.date("%Y-%m-%d")
    tool.downloadFile("cat " .. pathFile, _fileName)

    -- 删除临时文件
    fs.unlink(pathFile)
    return {msg = "download ok"}
end
--URL文件上传
function urlGroupUpload()
    local filepath = "/tmp/content_audit/"
    local filename = "url_group_cfg.csv"
    local path = filepath .. filename
    local tool = require "luci.utils.tool"
    local fs = require "nixio.fs"
    if not fs.access(filepath) then
        fs.mkdir(filepath)
    end
    tool.uploadFile(path, 1)
    local _size = fs.stat(path).size
    if _size < 3170304 then
        return {
            rcode = 0,
            size = _size
        }
    else
        nixio.fs.unlink(path)
        return {rcode = 2, msg = "The file is too large"}
    end
end
