module("luci.modules.network", package.seeall)

-- 设置network信息
function setNetwork(params, remoteIp)
    local cmd = require("luci.modules.cmd")
    local _sysinfo = cmd.devSta.get({device = "pc", module = "sysinfo"})
    local _network = params.network
    local _devType = string.upper(_sysinfo.productType)
    local _isEgRouter = (_devType == "EGW" or _devType == "EWR") and (_sysinfo.forwardMode == "ROUTER")

    --重新计算所有WAN口数量，兼容支持WAN子接口的设备
    local totalWanNum = 0
    if _network and type(_network.wan) == "table" then
        for _, wanNode in ipairs(_network.wan) do
            totalWanNum = totalWanNum + 1
            if type(wanNode.subwan) == "table" then
                totalWanNum = totalWanNum + #wanNode.subwan
            end
        end
    else
        totalWanNum = tonumber(_network and _network.wanNum) or 1
    end

    if _isEgRouter and (totalWanNum == 1) then
        -- 单WAN口关闭ISP选路/负载均衡
        setMultWan(false)
    end
    --[[
    -- 现在转发模式都由设备模式控制，所以切PPPoE时不要改动转发模式
    if _devType == "EAP" then
        local _wan1 = _network.wan[1]
        if type(_wan1) == "table" and _wan1.proto == "pppoe" then
            local wireless = require("luci.modules.wireless")
            -- wifi检查函数
            local _checkFn = function(wifis)
                local _flag = false
                for _, v in ipairs(wifis) do
                    if v.fowardType ~= "nat" then
                        v.fowardType = "nat"
                        v.vlanId = "233"
                        _flag = true
                    end
                end
                return _flag, wifis
            end
            wireless.checkWirelessModeAndDispatcher({fn = _checkFn})
            -- wirelan检测函数
            local _checkWirelanFn = function(list)
                local flag = false
                local _list = list[1] or {}
                if _list.transmode ~= "nat" then
                    _list.transmode = "nat"
                    _flag = true
                end
                return _flag, list
            end
            wireless.checkWirelanAndDispatcher({fn = _checkWirelanFn})
        end
    end ]]
    return cmd.devConfig.set(
        {
            device = params.device or "pc",
            module = "network",
            data = _network,
            remoteIp = remoteIp or false
        }
    )
end

-- 获取arp列表
function getArpTable()
    local _arpMap = {}
    luci.sys.net.arptable(
        function(arp)
            if arp["Flags"] ~= "0x0" then -- 过滤掉0X0
                table.insert(
                    _arpMap,
                    {
                        ip = arp["IP address"],
                        mac = string.upper(arp["HW address"]),
                        type = arp["HW type"],
                        flags = arp["Flags"],
                        mask = arp["Mask"],
                        intf = arp["Device"],
                        device = string.upper(string.gsub(arp["Device"], "br%-", "")) --去掉br-并转成大写
                    }
                )
            end
        end
    )
    return _arpMap
end


function setIsp(params)
    local cmd = require("luci.modules.cmd")
    params.func = "set"
    cmd.devConfig.set({device = "pc", module = "route_db", data = params})
end
function setWeight(params)
    local cmd = require("luci.modules.cmd")
    cmd.devConfig.set({device = "pc", module = "mllb", data = params})
end
function setFlowCtrl(params)
    local cmd = require("luci.modules.cmd")
    cmd.devConfig.set({device = "pc", module = "flowctrl", data = params})
end
-- 设置ISP和多链路负载均衡信息
function setMultWan(params)
    local cmd = require("luci.modules.cmd")

    if params and params.isp then
        setIsp(params.isp)
    else -- 关闭ISP选路
        local _isp = cmd.devConfig.get({device = "pc", module = "route_db", data = {func = "state"}})
        if _isp and _isp.enable ~= "0" then
            _isp.enable = "0"
            setIsp(_isp)
        end
    end
    if params and params.weight then
        setWeight(params.weight)
    else -- 关闭负载均衡
        local _weight = cmd.devConfig.get({device = "pc", module = "mllb"})
        if _weight and _weight.enable ~= "0" then
            _weight.enable = "0"
            setWeight(_weight)
        end
    end

    -- local _fc = cmd.devConfig.get({device = "pc", module = "flowctrl"}) or {}
    -- local wanNum
    -- if params and params.isp then -- 多WAN插入流控
    --     wanNum = tonumber(params.isp.intf_cnt)
    -- else
    --     wanNum = 1 -- 关闭多WAN口流控
    -- end

    -- if #_fc.list ~= wanNum then
    --     for i = 1, wanNum do
    --         if not _fc.list[i] or _fc.list[i].ifname ~= "br-wan" .. (i == 1 and "" or i - 1) then
    --             _fc.list[i] = {
    --                 ifname = "br-wan" .. (i == 1 and "" or i - 1),
    --                 downloadBand = "1000",
    --                 uploadBand = "1000"
    --             }
    --         end
    --     end
    --     -- 删除多余的流控配置
    --     for i = wanNum + 1, #_fc.list do
    --         if _fc.list[i] then
    --             _fc.list[i] = nil
    --         end
    --     end
    --     _fc.wanNum = tostring(#_fc.list)
    --     setFlowCtrl(_fc)
    -- end
    return params
end

function setIptv(params)
    local cmd = require("luci.modules.cmd")
    local res = cmd.devConfig.set({device = "pc", module = "network", data = params.network})

    if res and res.rcode ~= "00000000" then
        return res
    end
    cmd.devConfig.set({device = "pc", module = "vlan_port", data = params.vlanPort})
    return { code = 0, res = 'ok'}
end
