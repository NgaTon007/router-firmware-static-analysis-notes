module("luci.modules.noauth", package.seeall)
local fs = require("nixio.fs")
local tool = require("luci.utils.tool")
local LOCKTIME, COUNT = 60, 5

local cmd = require("luci.modules.cmd")
local capGateway = cmd.devCap.get({device = "pc", module = "gateway"}) or {}
local hasNtIdy = capGateway.nt_idy_upload == "1"
-- 密码输入错误时，记录loginLog
local function doLoginLog(user)
    local loginLog = {}
    if fs.access("/tmp/loginLog") then
        loginLog = luci.json.decode(fs.readfile("/tmp/loginLog")) or {}
    end
    tool.syslog({
        '6',
        "LOGIN",
        "remoteIp %s login failed due to incorrect password",
        { id = 1004 }
    })
    -- tool.debug("loginLog", loginLog)
    local log = loginLog and loginLog[user] or false
    -- 没有记录时，写一条记录
    if not log then
        loginLog[user] = {
            time = os.time(),
            count = 1
        }
        fs.writefile("/tmp/loginLog", luci.json.encode(loginLog))
        return true
    end

    local _lastErrTime = os.time() - log.time
    if _lastErrTime <= LOCKTIME then
        if log.count < COUNT then
            loginLog[user].time = os.time()
            loginLog[user].count = loginLog[user].count + 1
        else
            loginLog[user].time = os.time()
        end
    else
        -- 间隔大于60S后初始化统计次数
        loginLog[user].time = os.time()
        loginLog[user].count = 1
    end
    fs.writefile("/tmp/loginLog", luci.json.encode(loginLog))
    return loginLog
end
local function clearLoginLog(user)
    if fs.access("/tmp/loginLog") then
        local loginLog = luci.json.decode(fs.readfile("/tmp/loginLog")) or {}
        if loginLog[user] then
            loginLog[user] = nil
            fs.writefile("/tmp/loginLog", luci.json.encode(loginLog))
        end
    end
end
-- 判断用户是否还能进行密码校验
function getLockTime(user)
    local loginLog = {}
    if fs.access("/tmp/loginLog") then
        loginLog = luci.json.decode(fs.readfile("/tmp/loginLog")) or {}
    end

    local uci = require("luci.model.uci").cursor()
    local log = loginLog[user or os.getenv("REMOTE_ADDR")] or false
    if log then
        local pastTime = os.time() - log.time -- 距离上次错误时间
        if pastTime <= LOCKTIME and log.count >= COUNT then
            return {
                sid = "", -- 不能删掉，兼容APP旧版本
                count = COUNT,
                lockTime = LOCKTIME - pastTime
            }
        end
    end
    return false
end

 -- 协议签署
local function checkReadAgreement(params,user)
    local cmd = require "luci.modules.cmd"
    local tool = require("luci.utils.tool")
    local _userAgreement = cmd.devSta.get({device = "pc", module = "user_agreement_sign_status",data = {time_out = "3"}}) or {}
    local _master = cmd.devSta.get({device = "pc", module = "master"}) or {}
    local agree_version = _userAgreement.agree_version or ''
    local p_time = (params.time and params.time ~= '') and params.time or tostring(os.time())
    local agreement = {
            sign_user = 'admin_' .. user,
            sign_status = 'true',
            agree_time = p_time,
            agree_version = agree_version ~= '' and agree_version or p_time,
            agree_version_type = agree_version ~= '' and 'new' or 'agree_time'
           };
    tool.debug('agreement',agreement)

    local _ip = _master.ip
    -- 当_master.ip存在且不为127.0.0.1时，当前设备是从设备，额外给本机下发一次配置
    if _ip and _ip ~= "127.0.0.1" then
        cmd.acConfig.add({
            device = "pc",
            module = "user_agreement_sign",
            data = agreement,
            async = true,
            remoteIp = _master.mastertip
        })
    end

    -- 下发给主设备（若本机是主设备则直接下发给自己）
    return cmd.acConfig.add({
            device = "pc",
            module = "user_agreement_sign",
            data = agreement,
            async = true
    })
end

-- 登录
function login(params)
    local disp = require("luci.dispatcher")
    local common = require("luci.modules.common")
    local tool = require("luci.utils.tool")
    if params.password and tool.includeXxs(params.password) then
        tool.weblog("INVALID DATA", "LOGIN FAILED")
        return
    end

    local user = os.getenv("REMOTE_ADDR")
    local authOk
    local ua = os.getenv("HTTP_USER_AGENT") or "unknown brower (ua is nil)"
    tool.weblog(ua, "LOGIN UA")
    local _lockInfo = getLockTime(user)
    if _lockInfo and _lockInfo.lockTime > 0 then
        return _lockInfo
    end

    local password = params.password or ""
    if params.pwd then
        local logFile = require("luci.utils.logFile")
        local k = logFile.getUserKey()
        if not k then
            tool.debug("Auth key is nil.")
            return {reload = true, msg = "Auth key is nil."}
        end
        local _pwd = tool.decry(params.pwd, k)
        if not _pwd then
            tool.debug("Auth key is invalid.")
            return {reload = true, msg = "Auth key is invalid."}
        end
        password = tool.aesEncode(_pwd)
    end
    -- tool.debug('noauth password', password)
    local checkStat = {
        password = password,
        username = "admin", -- params.username,
        encry = params.encry,
        limit = params.limit
    }
    local authres, reason = tool.checkPasswd(checkStat)
    local log_opt = {
        username = params.username,
        level = "auth.notice"
    }
    if authres then
        authOk = disp.writeSid("admin")
        -- 手动登录时设置时间
        if params.time and tonumber(params.time) then
            common.setSysTime({
                time = params.time
            })
        end
        log_opt.action = "login-success"
        if params.more then
            local tool = require("luci.utils.tool")
            authOk.httpsEnable = tool.capacityWeb().https_enable == "1"
        end
        if hasNtIdy then
            cmd.devSta.update({device = "pc", module = "net_tml_list_v2", data = { from = "web" }})
        end
        clearLoginLog(user)
        tool.syslog({
            '6',
            "LOGIN",
            "remoteIp %s login successful",
            { id = 1001 }
        })
        if params.isCheckReadAgreement ~= 'true' then
            checkReadAgreement(params,user)
        end

    else
        log_opt.action = "login-fail"
        doLoginLog(user)
        authOk = getLockTime(user)
        if authOk and authOk.lockTime > 0 and authOk.count then
            tool.syslog({
                '5',
                "LOGIN_LOCKED",
                "remoteIp %s experienced " .. authOk.count .. " failed password attempts, and will be locked for 1 minute",
                { id = 1003, cnt = authOk.count, time = 1 }
            })
        end
    end
    tool.write_log(log_opt)
    return authOk
end

-- 单点登录
local function singleLogin()
    local sauth = luci.sauth
    local fs = require "nixio.fs"
    local config = require("luci.config")
    config.sauth = config.sauth or {}
    local sessionpath = config.sauth.sessionpath
    if sauth.sane() then
        local id
        for id in fs.dir(sessionpath) do
            sauth.kill(id)
        end
    end
end

-- 网络合并
function merge(params)
    local cmd = require "luci.modules.cmd"
    local tool = require("luci.utils.tool")
    local _strParams = luci.json.encode(params)

    if tool.includeXxs(_strParams) or tool.includeQuote(_strParams) then
        tool.weblog(_strParams, "MERGE FAILED INVALID DATA")
        return 'INVALID DATA'
    end

    return cmd.devSta.set({
        device = "pc",
        module = "networkId_merge",
        data = params,
        async = true
    })
end

-- ping checknet
function checkNet(params)
    if params.host then
        local tool = require("luci.utils.tool")
        if string.len(params.host) > 50 or not tool.checkIp(params.host) then
            return {
                connect = false,
                msg = "host illegal"
            }
        end
        local json = require "luci.json"
        local _curl =
            'curl -s -k -X POST \'http://%s/cgi-bin/luci/api/auth\' -H content-type:application/json -d \'{"method":"checkNet"}\'' %
                params.host
        local _data = json.decode(luci.sys.exec(_curl))
        if type(_data) == "table" then
            if type(_data.data) == "table" then
                return _data.data
            end
            return {
                connect = false
            }
        else
            return {
                connect = false
            }
        end
    else
        return {
            connect = true
        }
    end
end

