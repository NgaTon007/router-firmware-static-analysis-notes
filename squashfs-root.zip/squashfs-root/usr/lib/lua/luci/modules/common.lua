module("luci.modules.common", package.seeall)

-- 注销
function logout(params)
    local tool = require("luci.utils.tool")
    tool.logout(params)
end

-- 设置设备时间
function setSysTime(params)
    local tool = require "luci.utils.tool"
    local _force = "false"
    if tostring(params.force or "") == "true" then
        _force = "true"
    end
    if not tool.checkTime(params.time) then
        return {setTime = "illegal time"}
    end

    -- local shell = 'dev_sta set -m systime \'{"utc":"' .. params.time .. '","force":' .. _force .. ',"sn":[]}\''
    local shell =
        'dev_sta set -m systime \'{"utc":"%s","force":%q,"sn":[]}\'' %
        {
            params.time,
            _force
        }

    tool.forkExec(shell)
    tool.weblog(shell, "LOGIN SET TIME")
    return {time = params.time}
end

-- 设置语言
function localLang(lang)
    luci.http.setcookie("LOCAL_LANG", lang)
end

--设置登录超时
function setSessionTime(params)
    local tool = require "luci.utils.tool"
    local time = params.sessiontime
    if tool.checkTime(time) and tonumber(time) >= 600 and tonumber(time) <= 7200 then
        local _shell = "uci -q set luci.sauth.sessiontime=%d;uci commit luci;" % time
        tool.forkExec(_shell)
        tool.syslog({
            '6',
            "SESSION_TIME",
            "remoteIp %s changed session time to " .. time .. " seconds",
            { id = 1005, time = time }
        })
        return true
    end
    return false
end

-- 修改密码
function pwdmodify(params)
    local tool = require "luci.utils.tool"
    local cmd = require("luci.modules.cmd")
    local _networkId = params.networkId or false
    if not _networkId or (_networkId and _networkId == "0") then
        -- 修改密码时候如果没有或networkId为0，就创建网络
        if params.setQuick then
            local _res = setQuickStatus() -- 家用修改密码开局
            _networkId = _res.network.networkId
        else
            local networkInfo = cmd.devSta.get({device = "pc", module = "networkId"})
            _networkId = networkInfo.networkId
        end
    end
    if not params.passwordOld then
        tool.debug("empty passwordOld")
        return {code = "-1", msg = "empty passwordOld"}
    end

    local _checkOk = tool.checkPasswd({password = params.passwordOld, encry = true})
    if not _checkOk then
        return {code = "-1", msg = "error passwordOld"}
    end

    local uci = require("luci.model.uci").cursor()
    uci:delete("luci", "sauth", "pwdTip")
    uci:commit("luci")

    return tool.modifyPasswd(params.password, params.type, _networkId, params.sn)
end

-- 检查密码
function checkPassword(params)
    local tool = require "luci.utils.tool"
    return {isOk = tool.checkPasswd({password = params.password, encry = params.type, username})}
end

-- 检查是否默认密码
function isDefPass()
    local tool = require "luci.utils.tool"
    return tool.checkPasswd({password = "admin", encry = false})
end

-- 获取能力表
function capacity()
    local cmd = require("luci.modules.cmd")
    return cmd.devCap.get({device = "pc", module = "all"})
end
--[[ function formatMac(mac)
    local m1, m2, m3, m4, m5, m6 = mac:match('^([^%s]+):([^%s]+):([^%s]+):([^%s]+):([^%s]+):([^%s]+)')
    return m1..m2.."."..m3..m4.."."..m5..m6
end ]]
function generateLnid(mac)
    return "dev_" .. mac .. "_" .. string.format("%010d", os.time())
end

-- 设置快速配置状态
function setQuickStatus(params)
    params = params or {}
    local cmd = require("luci.modules.cmd")
    local _networkGroup = nil
    local _networkId = cmd.devSta.get({device = "pc", module = "networkId"})
    -- 出厂状态并且可创建时才创建网络
    if _networkId.networkId == "0" then
        local _sysinfo = cmd.devSta.get({device = "pc", module = "sysinfo"})
        local _groupInfo = params.groupInfo
        if not _groupInfo then
            local _networkGroupInfo = cmd.acConfig.get({device = "pc", module = "network_group"})
            _groupInfo = _networkGroupInfo and _networkGroupInfo.groupInfo or {}
            -- 分组异常，补充默认分组
            if #_groupInfo == 0 then
                _groupInfo[1] = {
                    groupId = "0",
                    groupName = "default",
                    isDefault = "true",
                    deviceList = {}
                }
            end
        end

        _networkId = {
            networkName = params.networkName or "WEB_" .. string.gsub(_sysinfo.sys_mac, ":", ""), -- MAC地址去掉冒号
            networkId = params.lnid or generateLnid(_sysinfo.sys_mac),
            groupId = "0",
            groupName = "default",
            parentGroupId = params.parentGroupId or ""
        }
        -- 查找默认网络分组，并把名称修改成《WEB》，当默认分组不包含当前设备，则加入设备
        for k, v in pairs(_groupInfo) do
            if v.isDefault == "true" then
                _networkId.groupName = v.groupName
                if not v.deviceList then
                    v.deviceList = {}
                end
                local _hasOwn = false
                for _k, _v in pairs(v.deviceList) do
                    if _v.devSN == _sysinfo.serial_num then
                        _hasOwn = true
                        break
                    end
                end
                if not _hasOwn then
                    v.deviceList[#v.deviceList + 1] = {
                        devSN = _sysinfo.serial_num,
                        devName = _sysinfo.product_class
                    }
                end
            -- break
            end
        end
        _networkGroup = {
            version = "1.0.0",
            networkId = _networkId.networkId,
            networkName = _networkId.networkName,
            parentGroupId = _networkId.parentGroupId,
            groupInfo = _groupInfo
        }
        -- 创建网络
        cmd.acConfig.set(
            {
                device = "pc",
                module = "network_group",
                data = _networkGroup,
                async = true,
                remotePwd = params.remotePwd
            }
        )
        cmd.devSta.set(
            {
                device = "pc",
                module = "networkId",
                data = _networkId,
                remotePwd = params.remotePwd
            }
        )
    else
        -- 修改项目名称
        if (params.networkName) then
            _networkGroup =
                cmd.acConfig.get(
                {
                    device = "pc",
                    module = "network_group"
                }
            )
            _networkGroup.networkName = params.networkName
            cmd.acConfig.set(
                {
                    device = "pc",
                    module = "network_group",
                    data = _networkGroup,
                    async = true
                }
            )
            _networkId.networkName = params.networkName
        end
    end

    return {network = _networkId, networkGroup = _networkGroup}
end

-- 设置快速配置信息
function setQuickInfo(params)
    local tool = require "luci.utils.tool"
    local _res = {}
    local _networkId = "0"
    local cmd = require("luci.modules.cmd")
    local pwd = params.webPassword or ""
    if pwd == "" then
        local product = require("product")
        local webpw = product.get_product("capacity.webpw.module")
        local _webPassword =
            cmd.acConfig.get(
            {
                module = webpw,
                device = "pc"
            }
        ) or {}
        pwd = _webPassword.password or ""
    end
    local _netInfo = setQuickStatus({networkName = params.networkName})
    _res.networkId = _netInfo.network
    _networkId = _netInfo.network.networkId
    _res.networkName = _networkId == "0" and "unset" or "ok"

    if _networkId ~= "0" then
        if params.wireless then
            local wireless = require("luci.modules.wireless")
            wireless.setWifiConfig(params.wireless, _networkId)
            _res.wireless = "ok"
        end
        if params.network then
            local network = require("luci.modules.network")
            network.setNetwork(params, params.remoteIp)
            _res.network = "ok"
        end

        if pwd ~= "" then
            if tool.includeQuote(pwd) or tool.includeXxs(pwd) then
                _res.webPassword = "illegal password"
            else
                tool.modifyPasswd(pwd, true, _networkId)
                _res.webPassword = "ok"
            end
        end
    end
    return _res
end
-- 获取权限相关信息
function getAuthority()
    local env = require("luci.modules.env")
    local cmd = require("luci.modules.cmd")
    local uci = require "luci.model.uci".cursor()
    local tool = require "luci.utils.tool"
    local _devMode = cmd.devConfig.get({device = "pc", module = "dev_mode"}) or {}
    local _master = cmd.devSta.get({device = "pc", module = "master"}) or {}
    local _apRole = cmd.devSta.get({device = "pc", module = "role"})
    local _sysinfo = cmd.devSta.get({device = "pc", module = "sysinfo"})
    local _networkId = cmd.devSta.get({device = "pc", module = "networkId"})
    local _developMode = cmd.devSta.get({device = "pc", module = "develop_mode"})
    local _product = cmd.devSta.get({device = "pc", module = "product"})

    if not _devMode.forwardMode then
        _devMode = {
            forwardMode = uci:get_first("sysinfo", "sysinfo", "forwardMode") or "ROUTER",
            autoJoin = uci:get_first("sysinfo", "sysinfo", "autoJoin") or "true",
            acEnable = uci:get_first("sysinfo", "sysinfo", "acEnable") or "true",
            relayMode = uci:get_first("sysinfo", "sysinfo", "relayMode") or "none"
        }
    end

    if _sysinfo == "" then
        _sysinfo = {
            productType = uci:get_first("sysinfo", "sysinfo", "dev_type") or "egw",
            forwardMode = uci:get_first("sysinfo", "sysinfo", "forwardMode") or "ROUTER",
            serial_num = uci:get_first("sysinfo", "sysinfo", "serial_num") or "UNKNOWN",
            software_version = uci:get_first("sysinfo", "sysinfo", "software_version") or "UNKNOWN",
            autoJoin = uci:get_first("sysinfo", "sysinfo", "autoJoin") or "UNKNOWN",
            model = uci:get_first("sysinfo", "sysinfo", "model") or "UNKNOWN"
        }
    end

    -- local _isEhr = _sysinfo.productType == "ehr"
    local _capacity = capacity()
    local _roles = {}

    if _master.ip and _master.sn ~= _sysinfo.serial_num then
        if _master.tipcInst then -- 无IP时默认ping成功
            _master.pingOk = true
        else
            _master.pingOk = luci.sys.net.pingtest(_master.ip) == 0
        end
    end

    -- tq用的IP地址
    if _sysinfo.forwardMode == "ROUTER" then
        _sysinfo.auth_ip = uci:get("network", "lan", "ipaddr") or ""
    else
        _sysinfo.auth_ip = uci:get_first("sysinfo", "sysinfo", "wan_ip") or ""
    end

    -- if _isEhr and _isMaster then
    --     -- 判断是否有下联中继设备
    --     local ap_list_ehr = cmd.devSta.get({device = "pc", module = "ap_list"})
    --     if ap_list_ehr and ap_list_ehr.total and tonumber(ap_list_ehr.total) > 0 and ap_list_ehr.list then
    --         local _hasEhrAp, _hasWirelessEhrAp = false, false
    --         for k, v in pairs(ap_list_ehr.list) do
    --             if (v.forwardMode == "AP" and v.serialNumber ~= _sysinfo.serial_num) then
    --                 _hasEhrAp = true
    --                 if (v.relayMode == "wirelessBridge") then
    --                     _hasWirelessEhrAp = true
    --                 end
    --             end
    --         end
    --         if _hasEhrAp then
    --             _roles[#_roles + 1] = "hasEhrAp"
    --             if _capacity.web.wio == "1" then
    --                 local _wioIsNeed = cmd.devSta.get({device = "pc", module = "wio", data = {mode = "is_need_wio"}})
    --                 if _wioIsNeed.rcode ~= "02521002" then
    --                     _roles[#_roles + 1] = "wioIsNeed"
    --                 end
    --             end
    --         end
    --         if _hasWirelessEhrAp then
    --             _roles[#_roles + 1] = "hasWirelessEhrAp"
    --         end
    --     end
    -- end

    local _hostName = uci:get_first("system", "system", "hostname") or ""
    local system = require "luci.modules.system"
    return {
        product = _product,
        hasKill = system.hasKillRemaining(), -- 是否有清理脚本
        capacity = _capacity,
        roles = _roles, -- 未使用，家用待整合
        devMode = _devMode,
        isDevelopMode = _developMode and _developMode.developMode == "1", -- 开发者模式
        deviceRole = _apRole.role,
        currentIp = tool.getSafeRemoteIp(), --os.getenv('HTTP_X_FORWARDED_FOR') or os.getenv("REMOTE_ADDR"),
        master = _master,
        sysinfo = _sysinfo,
        hostname = _hostName, -- uci:get_first("system", "system", "hostname") or "",
        networkId = _networkId,
        langs = env.getSupportLangs(),
        isDefPass = isDefPass(),
        showStep = uci:get("luci", "main", "steped") ~= "1" -- 是否显示全网配置向导界面
    }
end
