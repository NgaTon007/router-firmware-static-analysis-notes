module("luci.modules.diagnose", package.seeall)
local tool = require("luci.utils.tool")

-- 抓包文件临时路径
local pack_tmp = "/tmp/tcpdump.pcap"
local function switchFastDhcp(enable)
    -- tool.doShell("echo " .. enable .. " > /proc/net/fast_dhcp")
    tool.doShell("echo %d /proc/net/fast_dhcp" % enable)
end
-- 开始抓包
function runPackDiagnose(data)
    for k, v in pairs(data) do
        if type(v) == "string" and string.match(v, "[^%w_%.%-]") then
            return {res = false, msg = "params illegal"}
        end
    end
    stopPackDiagnose()
    switchFastDhcp(0)
    tool.doShell("rm -rf %s" % pack_tmp)

    local _host = ""
    if data.ip and data.ip ~= "" then
        if data.protocal ~= "" then
            _host = "and host %s" % data.ip
        else
            _host = "host %s" % data.ip
        end
    end

    local _linux_sll = (data.iface == "any") and "-y LINUX_SLL" or ""
    local _shell =
        "tcpdump -i %s %s %s %s -w %s -C %d -W 1 " %
        {
            data.iface,
            _linux_sll,
            data.protocal,
            _host,
            pack_tmp,
            data.size
        }
    if data.package and data.package ~= "" then
        _shell = _shell .. " -c " .. data.package
    end

    if string.match(_shell, "[>]") ~= nil then
        return {res = false, msg = "shell illegal"}
    end
    
    tool.weblog(_shell, "runPackDiagnose")
    return tool.doShell(_shell, true)
end
-- 获取抓包状态
function getPackDiagnoseStatus()
    local _isRunning, _hasPackage, _packageInfo = false, false, {}
    if nixio.fs.access(pack_tmp) then
        _hasPackage = true
        _packageInfo = nixio.fs.stat(pack_tmp)
    end
    local _res = luci.sys.exec("ps | grep 'tcpdump -i' | grep -v grep")
    if string.find(_res, "tcpdump %-i ", 0) then
        _isRunning = true
    else
        switchFastDhcp(1)
    end
    return {
        isRunning = _isRunning,
        hasPackage = _hasPackage,
        packageInfo = _packageInfo
    }
end
-- 停止抓包
function stopPackDiagnose()
    switchFastDhcp(1)
    local _shell = "killall tcpdump"
    tool.weblog(_shell, "stopPackDiagnose")
    return tool.doShell(_shell)
end
-- 删除包
function deletePackDiagnose()
    switchFastDhcp(1)
    if nixio.fs.access(pack_tmp) then
        nixio.fs.unlink(pack_tmp)
    end
    return "delet ok"
end
-- 获取可用内存
function getMemfree()
    local overview = require "luci.modules.overview"
    local _deviceInfo = overview.getDeviceInfo()
    return (_deviceInfo.mem_free_total) / 1024
end
-- 获取接口信息
function getIfaces()
    local uci = require "luci.model.uci".cursor()
    local ifaces = {}

    return uci:foreach(
        "network",
        "interface",
        function(s)
            local name = string.lower(s[".name"])
            if (string.find(name, "wan") == 1 or string.find(name, "lan") == 1) and string.find(name, "_v6") == nil then
                table.insert(
                    ifaces,
                    {
                        l = string.gsub(string.gsub(string.gsub(name, "lan_", "VLAN"), "wan", "WAN"), "lan", "LAN"),
                        v = (s.proto == "pppoe" and "pppoe-" or "br-") .. name -- s.ifname
                    }
                )
            end
        end
    ) and ifaces
end
function getMemAndIfaces()
    return {
        freeMem = getMemfree(),
        ifaces = getIfaces()
    }
end
-- 清理网络工具的进程和结果文件内容
local tmpPath = "/tmp/diagnose_res"
function clearDiagnoseTool()
    -- luci.sys.exec("killall traceroute")
    -- luci.sys.exec("killall ping")
    -- luci.sys.exec("echo '' > %s" % tmpPath)
    local _shell = "killall traceroute;killall ping;echo '' > %s" % tmpPath
    luci.sys.exec(_shell)
end

-- 执行ping操作
function ping(_d)
    clearDiagnoseTool()
    if string.len(_d.target) > 200 then
        return {res = false, msg = "target illegal"}
    end
    local _shell =
        "ping %s -c %d -s %d -W 1 %q > %s" %
        {
            _d.ipType == 'v6' and '-6' or '-4',
            _d.count,
            _d.size,
            _d.target,
            tmpPath
        }
    -- return luci.sys.call(_shell)
    return tool.doShell(_shell, false, true)
end

-- 执行traceroute操作
function traceroute(_d)
    clearDiagnoseTool()
    if string.len(_d.target) > 200 then
        return {res = false, msg = "target illegal"}
    end
    local _shell =
        "traceroute %s -m %d %q > %s" %
        {
            _d.ipType == 'v6' and '-6' or '-4',
            _d.ttl,
            _d.target,
            tmpPath
        }
    -- return luci.sys.call(_shell)
    return tool.doShell(_shell, false, true)
end

-- 执行nslookup操作
function nslookup(_d)
    clearDiagnoseTool()
    if string.len(_d.target) > 200 and string.len(_d.dns) > 20 then
        return {res = false, msg = "target illegal"}
    end

    local _shell = ""
    if _d.dns and _d.dns ~= "" then
        _shell = "nslookup %q %q" % {
            _d.target,
            _d.dns
        }
    else 
        _shell = "nslookup %q" % _d.target
    end
    return {res = tool.doShell(_shell)}
end

-- 获取检测结果
function getDiagnoseRes()
    local _res = ""
    if nixio.fs.access(tmpPath) then
        _res = tool.doShell("cat %s" % tmpPath)
    end
    return {res = string.trim(_res)}
end
-- 获取MTU检测结果
function getMtuRes()
    local _res = ""
    local path = "/tmp/mtu_disc/web_tty.txt"
    if nixio.fs.access(path) then
        _res = tool.doShell("cat %s" % path)
    end
    return {res = string.trim(_res)}
end
-- 测试临时使用 获取极速上云地址
function getcloudDomain()
    local uci = require "luci.model.uci".cursor()
    return {cloudDomain = uci:get("luci", "main", "testUrl") or ""}
end
