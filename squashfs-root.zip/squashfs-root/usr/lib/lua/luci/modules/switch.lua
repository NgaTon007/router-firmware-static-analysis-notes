module("luci.modules.switch", package.seeall)

-- 获取ip是否可达
function ipIsReach(params)
    -- local shell = "ping " .. params.ip .. " -q -c 1 -s 1 -w 1"
    -- local result = luci.sys.exec(shell)
    -- local _isReach = string.find(result, "1 packets received")
    -- if _isReach then
    --     return {isReach = true}
    -- else
    --     return {isReach = false}
    -- end
    return {isReach = luci.sys.net.pingtest(params.ip) == 0}
end

-- esw远程调用接口
function doSwitchApi(params)
    local json = require "luci.json"
    local tool = require "luci.utils.tool"
    local esw = require "esw"
    local cmd = params.method == "post" and "set" or "get"
    local dev_type = "esw"

    tool.debug("ESW API params", params)
    if params.async then
        esw.fetch(cmd, params.ip, params.sn, params.url, params.data, "1", "pc")
        return {code = 0, msg = "shell success", dev_type = dev_type}
    else
        local result = esw.fetch(cmd, params.ip, params.sn, params.url, params.data, nil, "pc")
        -- tool.debug("result", result)
        if result.code == 0 then
            return json.decode(result.data or result.result) or {}
        else
            return {code = 1009, result = "connect timeout", dev_type = dev_type}
        end
    end
end

function cmdArrEsw(params)
    local res = {}
    for _, param in pairs(params) do
        res[#res + 1] = doSwitchApi(param)
    end
    return res
end
