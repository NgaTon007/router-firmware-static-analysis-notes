module("luci.modules.system", package.seeall)

-- 获取当前版本
local function getCurVersion()
    local patch_fs = require "nixio.fs"
    local _vesioninfo = patch_fs.readfile("/etc/openwrt_version")
    return _vesioninfo
end

-- 配置语言
function setLang(params)
    local env = require "luci.modules.env"
    local lang = params.lang or "en"
    if not env.langMap[lang] then
        return {result = false}
    end
    local uci = require "luci.model.uci".cursor()
    uci:set("luci", "main", "lang", lang)
    uci:commit("luci")
    return {result = true}
end

-- 获取最新版本
local function getNewVersion(deviceType)
    local tool = require("luci.utils.tool")
    if deviceType == "bottom" or deviceType == "self" then
        _shell = "cloud_upgrade.sh --version-check " .. deviceType
        tool.weblog(_shell, "GET NEW VERSION")
        return tool.decode(luci.sys.exec(_shell))
    end
    return {}
end

-- 获取设备版本
function getVersion(params)
    local _curVersion = getCurVersion()
    local _newVersion = getNewVersion(params.deviceType)
    return {cur = _curVersion, new = _newVersion or {}}
end

-- 同步时间
function asyncTime(params)
    -- local set = tonumber(params.time)
    -- if set ~= nil and set > 0 then
    --     local date = os.date("*t", set)
    --     if date then
    --         luci.sys.call(
    --             "date -s '%04d-%02d-%02d %02d:%02d:%02d'" %
    --                 {
    --                     date.year,
    --                     date.month,
    --                     date.day,
    --                     date.hour,
    --                     date.min,
    --                     date.sec
    --                 }
    --         )
    --     end
    -- end
    return string.trim(luci.sys.exec('date "+%Y/%m/%d %H:%M:%S"'))
end

function getRebootShell(reason)
    local tool = require("luci.utils.tool")
    local _shell = "; sync; reboot"
    -- 检查文件是否存在
    if nixio.fs.access("/etc/init.d/parse_reboot_reason") and not tool.includeXxs(reason) then
        local userIp = tool.getSafeRemoteIp()
        -- local userIp = os.getenv("HTTP_X_FORWARDED_FOR") or os.getenv("REMOTE_ADDR") or "UNKNOWN IP"
        _shell = _shell .. " -m 'web(%s)' -r '%s'" % {userIp, reason}
    end
    return _shell
end

-- 恢复出厂配置
function restoreConfiguration()
    local tool = require("luci.utils.tool")
    local _shell = "sleep 1; firstboot; sleep 2"
    _shell = _shell .. getRebootShell("restore")

    local uci = require "luci.model.uci".cursor()
    local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type") or "msw"
    if dev_type == "msw" then
        -- 交换机热备设备采用统一框架接口执行本机恢复出厂操作
        local cmd = require("luci.modules.cmd")
        local _res = cmd.devSta.get({device = "pc", module = "devResetLocal"}) or {}
        if _res and _res.exist == "1" then
            -- cmd.devSta.set({device = "pc", module = "devResetLocal", data = {}})
            _shell = "dev_sta set -m devResetLocal '{}'"
        end
    end
    tool.forkExec(_shell)
    return {code = 0, shell = _shell}
end

-- 重启
function reboot()
    local tool = require("luci.utils.tool")
    local uci = require "luci.model.uci".cursor()
    local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type") or "egw"
    -- local _shell = "sleep 1; sync;reboot >/dev/null 2>&1;"
    local _shell = "sleep 1"
    _shell = _shell .. getRebootShell("user reboot") .. " >/dev/null 2>&1;"

    tool.forkExec(_shell)
    return {code = 0, shell = _shell}
end

local kill_remaining_path = "/etc/sysupgrade.d/kill_remaining.sh"
function hasKillRemaining()
    local fs  = require "nixio.fs"
    if fs.access(kill_remaining_path) then
        return true
    end
    return false
end

function doKillRemaining()

    if hasKillRemaining() then
        luci.sys.exec(string.format("%s >/dev/null 2>&1", kill_remaining_path))
    end
end

-- 升级设备(提交)
function upgradeConfirm(params)
    local file = require("luci.modules.file")
    -- 执行升级前删除定时任务
    file.killDeleteFireware()

    if params.check and not nixio.fs.access("/tmp/firmware.img") then
        return {code = 1, msg = "firmware not found, please try again."}
    end

    local tool = require("luci.utils.tool")
    local _isPersist = not (not params.isPersist)
    local _isEstAll = not (not params.isEstAll)
    local _keepExec = _isPersist and "" or "-n"
    if tool.includeXxs(params.path) then
        return {code = -1, msg = "params illegal"}
    end
    local _shell =
        _isEstAll and "sd_tipc_client_upgrade upgrade_req" or
        "killall dropbear; sleep 2; /sbin/sysupgrade %s %q" % {_keepExec, params.path}
    tool.weblog(_shell, "DO UPGRADE")
    tool.forkExec(_shell)
    return {code = 0}
end

-- 升级设备(取消，删除升级的文件/tmp/firmware.img)
function upgradeCancel()
    local file = require("luci.modules.file")
    -- 执行升级前删除定时任务
    file.killDeleteFireware()

    local imageTmp = "/tmp/firmware.img"
    local fs = require "nixio.fs"
    fs.unlink(imageTmp)
    return {code = 0, msg = "delete fireware.img ok"}
end

-- 获取web登录超时时间
function getSessiontime()
    local uci = require "luci.model.uci".cursor()
    local res = uci:get("luci", "sauth", "sessiontime")
    return res or 3600
end

-- 是否存在备份文件
function hasBackupFile()
    local fs = require "nixio.fs"
    local RESTORE_PATH = "/overlay/backup-config.tar.gz"

    local _hasfile = fs.access(RESTORE_PATH) and true or false
    return {
        hasfile = _hasfile,
        path = RESTORE_PATH
    }
end

-- 恢复配置
function restoreConfig()
    -- local path = "/overlay/backup-config.tar.gz"
    local file = require "luci.modules.file"
    -- local tool = require "luci.utils.tool"
    return file.restoreConfig(true)
end

-- 删除恢复配置
function delRestoreConfig()
    local path = "/overlay/backup-config.tar.gz"
    luci.sys.call("rm " .. path)
    return "ok"
end

-- 配置新用户引导标识
function setStep(params)
    if not params or not params.steped then
        return {result = false, params = params}
    end

    if params.steped ~= "0" and params.steped ~= "1" then
        return {result = false}
    end

    local tool = require "luci.utils.tool"

    local uci = require "luci.model.uci".cursor()
    uci:set("luci", "main", "steped", params.steped)
    uci:commit("luci")
    return {result = true}
end

--获取当前设备overlay剩余空间
function getOverlayFreeSpace()
    local overlay = luci.sys.exec("df | grep overlayfs | awk -F' ' '{ print $4 }'")
    return overlay
end