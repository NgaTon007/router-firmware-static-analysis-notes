module("luci.modules.cmd", package.seeall)

local function fetch(fn, shell, params, ...)
    require "luci.json"
    local tool = require "luci.utils.tool"
    local _start = os.time()
    local _res = fn(...)
    tool.weblog(shell, params.device, os.time() - _start)
    if params.method ~= "get" then
        tool.write_log({action = shell})
    end
    if _res.code == 0 then
        _res = _res.data or ""
        if params.noParse then
            return _res
        end
        return _res and luci.json.decode(_res) or (_res or "")
    end
    return _res
end

local function doParams(params)
    require "luci.json"
    -- web接口调用全部去掉时间，强制force设置下去
    if type(params.data) == "table" then
        params.data.currentTime = nil
        params.data.configTime = nil
        params.data.configId = nil
    end
    local tool = require "luci.utils.tool"
    if tool.includeXxs(params.module) or tool.includeXxs(params.method) then
        params.module = "illegalMoule"
        params.method = "illegalMethod"
    end
    if (not params.module or not params.method) then
        return "please input module"
    else
        local data, back, ip, password = nil, nil, nil, nil

        local _shell = params.cfg_cmd .. " " .. params.method .. " --module '" .. params.module .. "'"
        -- 远程代理调用
        if params.remoteIp then
            _shell = _shell .. " -i '" .. params.remoteIp .. "'"
            ip = params.remoteIp
        end
        if params.remotePwd and not (params.cur) then
            _shell = _shell .. " -p '" .. params.remotePwd .. "'"
            password = params.remotePwd
        end
        if params.data then
            data = luci.json.encode(params.data)
            _shell = _shell .. " '" .. data .. "'"
        end
        if params.async == true or params.async == "true" then
            back = 0
            _shell = _shell .. " -b 0 "
        elseif params.async == false or params.async == "false" then
            back = 1
            _shell = _shell .. " -b 1 "
        end
        if params.module == 'adminCheck' and params.data and params.data.type == 'noenc' then
            _shell = 'dev_sta get --module "adminCheck" \'{"password":"xxx","type":"noenc","name":"admin"}\''
        end
        return data, back, ip, password, _shell
    end
end

local opt = {"add", "del", "update", "get", "set", "clear", "doc"}
acConfig, devConfig, devSta, devCap = {}, {}, {}, {}

for i = 1, #opt do
    acConfig[opt[i]] = function(params)
        local model = require "ac_config"
        params.method = opt[i]
        params.cfg_cmd = "ac_config"
        local data, back, ip, password, shell = doParams(params)
        return fetch(model.fetch, shell, params, opt[i], params.module, data, back, ip, password, nil, nil, nil, "PC")
    end

    devConfig[opt[i]] = function(params)
        local model = require "dev_config"
        params.method = opt[i]
        params.cfg_cmd = "dev_config"
        local data, back, ip, password, shell = doParams(params)
        return fetch(model.fetch, shell, params, opt[i], params.module, data, back, ip, password, nil, nil, nil, "PC")
    end

    devSta[opt[i]] = function(params)
        local model = require "dev_sta"
        params.method = opt[i]
        params.cfg_cmd = "dev_sta"
        local data, back, ip, password, shell = doParams(params)
        return fetch(model.fetch, shell, params, opt[i], params.module, data, back, ip, password, nil, nil, nil, "PC")
    end
    if opt[i] == "get" then
        devCap[opt[i]] = function(params)
            local model = require "dev_cap"
            params.method = opt[i]
            params.cfg_cmd = "dev_cap"
            local data, back, ip, password, shell = doParams(params)
            return fetch(model.fetch, shell, params, opt[i], params.module, ip, password, nil, nil, nil, "PC")
        end
    end
    if opt[i] == "doc" then
        syshell = function(params)
            local tool = require "luci.utils.tool"
            return tool.doc(params)
        end
    end
end

cmdArr = function(params)
    local res = {}
    local cmd = require("luci.modules.cmd")
    local rpc = require("luci.utils.jsonrpc")

    for _, _param in ipairs(params.params) do
        local method = rpc.resolve(cmd, _param.method)
        _param.params.device = params.device
        if _param.params.noParse == nil then
            _param.params.noParse = params.noParse
        end
        if _param.params.remoteIp == nil then
            _param.params.remoteIp = params.remoteIp
        end
        local _res = method(_param.params)
        res[#res + 1] = _res == nil and {code = "-1", msg = "nil value"} or _res
    end

    return res
end
