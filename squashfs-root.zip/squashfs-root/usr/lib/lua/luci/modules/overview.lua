module("luci.modules.overview", package.seeall)

local util = require("luci.util")
local tool = require("luci.utils.tool")

-- 获取系统信息（sysinfo配置文件）
function getSysinfo()
    local uci = require "luci.model.uci".cursor()
    local _sectionName = uci:get_first("sysinfo", "sysinfo")
    return uci:get_all("sysinfo", _sectionName)
end

-- 获取设备硬件信息
function getDeviceInfo()
    local system = require("luci.modules.system")
    local _result = {}
    local _harmInfo = {luci.sys.sysinfo()}
    -- 设备时间
    _result.local_time = system.asyncTime() -- string.trim(luci.sys.exec('date "+%Y-%m-%d %H:%M:%S"'))
    -- 开机时间
    _result.uptime = luci.sys.uptime()
    -- 总内存
    _result.mem_total = _harmInfo[3] + _harmInfo[8]/2   -- mem_total + swaptotal/2 
    -- 可用存储
    _result.mem_free = _harmInfo[6]
    -- 可用存储总
    _result.mem_free_total = _result.mem_free + _harmInfo[10]/2 + _harmInfo[11] + _harmInfo[12] + _harmInfo[13] ---- MemFree + (swapfree/2 + (Active(file) + Inactive(file) + SReclaimable
    -- 已用存储
    _result.mem_used = _harmInfo[3] - _result.mem_free_total

    -- 设备sysinfo信息
    -- local _softInfo = getSysinfo()
    -- util.update(_result, _softInfo)
    return _result
end

-- 开机时间
function getUptime()
    return luci.sys.uptime()
end

-- 获取设备hostname
function getHostName()
    local uci = require "luci.model.uci".cursor()
    return {hostname = uci:get_first("system", "system", "hostname") or ""}
end
