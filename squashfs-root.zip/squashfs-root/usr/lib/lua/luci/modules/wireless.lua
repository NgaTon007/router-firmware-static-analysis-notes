module("luci.modules.wireless", package.seeall)

-- 升级ap列表
function updateVersion(param)
    local tool = require "luci.utils.tool"
    if tool.includeQuote(param.jsonparam) then
        -- 参数较长，将参数放在单引号内，因此只判断是否有单引号即可。(jsonparams包含封号;)
        return {res = false, msg = "params illegal"}
    end
    -- local _shell = "cloud_upgrade.sh --version-upgrade '" .. param.jsonparam .. "'"
    local _shell = "cloud_upgrade.sh --version-upgrade '%s'" % param.jsonparam
    tool.weblog(_shell, "UPGRADE LIST")
    return luci.sys.exec(_shell)
end
-- 设置wifi
function setWifiConfig(params, networkId)
    local cmd = require("luci.modules.cmd")
    if not networkId then
        local networkInfo = cmd.devSta.get({device = "pc", module = "networkId"})
        if networkInfo and networkInfo.networkId then
            networkId = networkInfo.networkId
        end
    end
    params.networkId = networkId
    local wifiRes = cmd.acConfig.set({device = "pc", module = "wireless", data = params})
    return {myNetworkId = networkId, wifiRes = wifiRes}
end

-- 加载信道
function getChannel(params)
    local cmd = require("luci.modules.cmd")
    local channel =
        cmd.devSta.get(
        {device = "pc", module = "country_channel", data = {qry_type = "channellist"}, remoteIp = params.remoteIp}
    )
    if channel == "" then
        channel = {
            channel_2G = {
                {
                    channel = "1",
                    frequency = "2.412"
                },
                {
                    channel = "2",
                    frequency = "2.417"
                },
                {
                    channel = "3",
                    frequency = "2.422"
                },
                {
                    channel = "4",
                    frequency = "2.427"
                },
                {
                    channel = "5",
                    frequency = "2.432"
                },
                {
                    channel = "6",
                    frequency = "2.437"
                },
                {
                    channel = "7",
                    frequency = "2.442"
                },
                {
                    channel = "8",
                    frequency = "2.447"
                },
                {
                    channel = "9",
                    frequency = "2.452"
                },
                {
                    channel = "10",
                    frequency = "2.457"
                },
                {
                    channel = "11",
                    frequency = "2.462"
                },
                {
                    channel = "12",
                    frequency = "2.467"
                },
                {
                    channel = "13",
                    frequency = "2.472"
                }
            },
            channel_5G = {
                {
                    channel = "36",
                    frequency = "5.18"
                },
                {
                    channel = "40",
                    frequency = "5.2"
                },
                {
                    channel = "44",
                    frequency = "5.22"
                },
                {
                    channel = "48",
                    frequency = "5.24"
                },
                {
                    channel = "52",
                    frequency = "5.26"
                },
                {
                    channel = "56",
                    frequency = "5.28"
                },
                {
                    channel = "60",
                    frequency = "5.3"
                },
                {
                    channel = "64",
                    frequency = "5.32"
                },
                {
                    channel = "149",
                    frequency = "5.745"
                },
                {
                    channel = "153",
                    frequency = "5.765"
                },
                {
                    channel = "157",
                    frequency = "5.785"
                },
                {
                    channel = "161",
                    frequency = "5.805"
                },
                {
                    channel = "165",
                    frequency = "5.825"
                }
            }
        }
    end
    return channel
    -- local _channel2G = luci.sys.exec("iwlist ath0 channel | grep GHz")
    -- if _channel2G == "" then
    --     _channel2G =
    --         "Channel 01 : 2.412 GHz↵Channel 02 : 2.417 GHz↵Channel 03 : 2.422 GHz↵Channel 04 : 2.427 GHz↵Channel 05 : 2.432 GHz↵Channel 06 : 2.437 GHz↵Channel 07 : 2.442 GHz↵Channel 08 : 2.447 GHz↵Channel 09 : 2.452 GHz↵Channel 10 : 2.457 GHz↵Channel 11 : 2.462 GHz↵Channel 12 : 2.467 GHz↵Channel 13 : 2.472 GHz↵Current Frequency=2.412 GHz (Channel 1)↵"
    -- end
    -- local _channel5G = luci.sys.exec("iwlist ath1 channel | grep GHz")
    -- if _channel5G == "" then
    --     _channel5G =
    --         "Channel 36 : 5.18 GHz↵Channel 40 : 5.2 GHz↵Channel 44 : 5.22 GHz↵Channel 48 : 5.24 GHz↵Channel 52 : 5.26 GHz↵Channel 56 : 5.28 GHz↵Channel 60 : 5.3 GHz↵Channel 64 : 5.32 GHz↵Channel 149 : 5.745 GHz↵Channel 153 : 5.765 GHz↵Channel 157 : 5.785 GHz↵Channel 161 : 5.805 GHz↵Channel 165 : 5.825 GHz↵Current Frequency=5.825 GHz (Channel 165)↵"
    -- end
    -- return {channel2G = _channel2G, channel5G = _channel5G}
end

-- EHR设置无线桥接/有线中继
function setRepeater(params)
    local common = require "luci.modules.common"
    local cmd = require("luci.modules.cmd")
    local res
    local lnid = params.lnid or false -- APP会传参数进来

    -- 无线桥接设置中继在前，开局在后（需要根据中继结果判断是否开局）
    if params.type ~= "wired" then
        local _curLnid = cmd.devSta.get({device = "pc", module = "networkId"}).networkId or false

        if _curLnid == "0" then
            if not lnid then
                local _sysinfo = cmd.devSta.get({device = "pc", module = "sysinfo"})
                lnid = common.generateLnid(_sysinfo.sys_mac) -- 开局没传lnid时提前生成lnid
            end
            params.host.lnid = lnid -- 无线桥接数据增加 lnid 信息，给无线桥接模块创建无线配置用
        else
            lnid = _curLnid
        end

        res = cmd.devSta.set({device = "pc", module = "repeater_hostrouter", data = params.host})
    end
    if params.type == "wired" or res.connStatus == "1" then
        local tool = require "luci.utils.tool"
        -- 修改密码, 创建网络(networkId为0时)
        local _res =
            common.setQuickStatus(
            {
                lnid = lnid or false, -- 和无线桥接使用同一个 lnid
                networkName = params.networkName or false,
                parentGroupId = params.parentGroupId or false
            }
        ) -- 家用修改密码开局
        local _networkId = _res.network.networkId
        if params.pwd and params.pwd ~= "" then
            tool.modifyPasswd(params.pwd, false, _networkId)
        end
        --无线中继开局后重新下发一次中继命令,修复bugid 1140854
        if params.type ~= "wired" then
            cmd.devSta.set({device = "pc", module = "repeater_hostrouter", data = params.host})
        end
    end
    -- 有线中继设置中继在后，开局在前（否则开局关联无线设置会覆盖有线中继里的无线设置）
    if params.type == "wired" then
        res = cmd.devSta.set({device = "pc", module = "wired_repeater_finish", data = params.host})
    end
    return res
end

-- EHR设置WISP模式
function setWisp(params)
    local common = require "luci.modules.common"
    local cmd = require("luci.modules.cmd")
    local res
    local lnid = params.lnid or false -- APP会传参数进来

    -- 无线桥接设置中继在前，开局在后（需要根据中继结果判断是否开局）
    local _curLnid = cmd.devSta.get({device = "pc", module = "networkId"}).networkId or false

    if _curLnid == "0" then
        if not lnid then
            local _sysinfo = cmd.devSta.get({device = "pc", module = "sysinfo"})
            lnid = common.generateLnid(_sysinfo.sys_mac) -- 开局没传lnid时提前生成lnid
        end
        params.host.lnid = lnid -- 无线桥接数据增加 lnid 信息，给无线桥接模块创建无线配置用
    else
        lnid = _curLnid
    end

    res = cmd.devSta.set({device = "pc", module = "repeater_hostrouter", data = params.host})

    if res.connStatus == "1" then
        -- 设置network
        if params.network then
            -- local _network = cmd.devConfig.get({device = "pc", module = "network", data = params.network})
            -- params.network.wan[1].macaddr = _network.wan[1].macaddr
            cmd.devConfig.set({device = "pc", module = "network", data = params.network})
        end
        -- 设置开局
        local tool = require "luci.utils.tool"
        -- 修改密码, 创建网络(networkId为0时)
        local _res =
            common.setQuickStatus(
            {
                lnid = lnid or false, -- 和无线桥接使用同一个 lnid
                networkName = params.networkName or false,
                parentGroupId = params.parentGroupId or false
            }
        ) -- 家用修改密码开局
        local _networkId = _res.network.networkId
        if params.pwd and params.pwd ~= "" then
            tool.modifyPasswd(params.pwd, false, _networkId)
        end
    end
    return res
end
