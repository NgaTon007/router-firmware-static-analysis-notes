module("luci.modules.env", package.seeall)
local uci = require("luci.model.uci").cursor()
-- local tool = require("luci.utils.tool")

langMap = uci:get_all("luci", "languages")
if (not langMap or not langMap["en"]) then
    -- luci.languages没有默认的en语言包时，使用默认的语言包列表
    local devType = uci:get_first("sysinfo", "sysinfo", "dev_type")
    langMap =
        devType == "eap" and
        {
            en = "English",
            zh_cn = "简体中文"
        } or
        {
            en = "English",
            zh_cn = "简体中文",
            zh_ft = "繁體中文",
            th = "ไทย", -- 泰语
            vi = "Tiếng Việt", -- 越南语
            es = "Español", -- 西班牙语(西班牙)
            ru = "Русский", -- 俄语
            tr = "Türkçe", -- 土耳其语
            id = "Bahasa Indonesia", -- 印度尼西亚
            ar = "اللغة العربية", -- 阿拉伯
            de = "Deutsch", -- 德语
            fr = "Français", -- 法语
            jp = "日本語", -- 日语
            -- R300 新增四国小语种
            es_MX = "Español (Latinoamérica)", -- 西班牙语（墨西哥）
            pt_BR = "Português (Brasil)",  -- 葡萄牙语（巴西）
            pl = "Polski", -- 波兰语
            it = "Italiano",  -- 意大利语
            yk = "Українська мова" -- 乌克兰语
        }
    -- tool.debug("use defautl langMap", langMap)
end
function getLang()
    local http = require "luci.http"
    -- local conf = require "luci.config"
    local lang = http.getcookie("__APP_LANG__")

    if lang then
        if langMap[lang] then
            return lang
        end
        return lang == "zh_ft" and "zh_cn" or "en"
    else
        -- 没有cookie时都根据浏览器语言自动选择
        -- if conf.main.lang and conf.main.lang ~= "auto" then
        --     lang = conf.main.lang
        --     return langMap[lang] and lang or (lang == "zh_ft" and "zh_cn" or "en")
        -- else
            local aclang = http.getenv("HTTP_ACCEPT_LANGUAGE") or ""
            for lpat in aclang:gmatch("[%a-]+") do
                lang = lpat and string.lower(lpat:gsub("-", "_"))
                if lang == "zh_hk" or lang == "zh_tw" or lang == "zh_mo" or lang == "zh_hant" or lang == "zh_cht" then
                    lang = "zh_ft"
                elseif string.find(lang, "zh") == 1 then -- 其他zh_开头的都中文简体
                    lang = "zh_cn"
                elseif string.find(lang, "en") == 1 then -- 其他en_开头的都英文
                    lang = "en"
                end
                if langMap[lang] then
                    return lang
                end
            end
        -- end
    end
    return "en"
end

function getSupportLangs()
    local supportLangs = {
        {
            name = "简体中文",
            v = "zh_cn"
        },
        {
            name = "English",
            v = "en"
        }
    }
    if langMap["zh_ft"] and nixio.fs.access('/www/luci-static/i18n/zh_ft.json') then
        supportLangs[#supportLangs + 1] = {
            name = "繁體中文",
            v = "zh_ft"
        }
    end
    for k, name in pairs(langMap) do
        if k ~= ".type" and k ~= ".name" and k ~= ".anonymous" and k ~= "zh_cn" and k ~= "en" and k ~= "zh_ft" then
            if k and nixio.fs.access('/www/luci-static/i18n/'..k..'.json') then
                supportLangs[#supportLangs + 1] = {
                    name = name,
                    v = k
                }
            end
        end
    end
    -- tool.debug('supportLangs', supportLangs)
    return supportLangs
end

local function _hasHttps()
    local tool = require("luci.utils.tool")
    local hasHttps = tool.capacityWeb().https_enable == "1"
    return hasHttps
end

local function _getDevId()
    local uci = require "luci.model.uci".cursor()
    local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type") or "unknown"
    local product = string.upper(dev_type)
    local forwardMode = uci:get_first("sysinfo", "sysinfo", "forwardMode")
    local _product = require("product")
    local _nbr_type = _product.get_product("capacity.nbr_type") or ''
    if product == 'MSW' or product == 'SW' then
        devId = "switch" -- 交换机MSW 或 非网管ESW
    elseif product == 'EAP' or forwardMode == 'AP' then
        devId = "ap" -- EAP 或 EWR 的AP模式
    elseif product == 'EHR' or product == 'EWR' then
        devId = "ehr" -- 无线路由器
    elseif product == "EAC" or forwardMode == 'AC' then
        devId = "ac" -- EAC 或 EGW的AC模式
    elseif product == 'EGW' or product == _nbr_type then
        devId = "egw" -- 网关
    elseif product == 'FW_NTOS' then
        devId = "fw" -- 防火墙
    else
        devId = false -- 未知设备
    end
    return devId
end

local LANGMAP = {
    zh_cn = "zh-cn",
    en = "en-global",
    zh_ft = "en-global",
    th = "th-th", -- 泰语
    vi = "vi-vn", -- 越南语
    es = "es-es", -- 西班牙语(西班牙)
    ru = "ru-kz", -- 俄语
    tr = "tr-tr", -- 土耳其语
    id = "id-id", -- 印度尼西亚
    ar = "ar-sa", -- 阿拉伯
    de = "de-de", -- 德语
    fr = "fr-fr", -- 法语
    -- R300 新增四国小语种
    es_MX = "es-latam", -- 西班牙语（墨西哥）
    pt_BR = "pt-pt", -- 葡萄牙语（巴西）
    pl = "pl-pl", -- 波兰语
    it = "it-it", -- 意大利语
    yk = "uk-ua" -- 乌克兰语
}

local product = require("product")
local web = product.get_product("capacity.web")
local r = product.get_product("manufacturer.company")
local re = string.lower(product.get_product("manufacturer.brand"))

local enRPolicyIdMap = {'user-agreement-for-%s-%s'%{r, web}, '%s-%s-data-processing-agreement'%{r, web}, 'all'}

local zhPolicyTypeMap = {'device_user_agreement',  'device_data_deal'}
-- 获取协议地址
local url = luci.json.decode(product.get_product("capacity.policyUrl")) or {}
local custom = product.get_product("manufacturer.custom")
local u1 =  url[1] or ''
local u2 = url[2] or u1


local function getPolicyContentUrl(lang, infoKeyIdx)
    if lang == 'en_r' then
        return '%s/%s'% {u2, enRPolicyIdMap[infoKeyIdx]}
    end
    return '%s/agrement/device?type=DEVICE&code=%s&language=%s' % {u1, zhPolicyTypeMap[infoKeyIdx],  LANGMAP[lang]}
end

local function _getMasterIp(toHttps)
    local cmd = require "luci.modules.cmd"
    local http = require "luci.http"
    local _masterIp = nil
    local _httpHost = http.getenv('HTTP_HOST')
    local product = require("product")
    local _master_ip = product.get_product("capacity.master_ip") or ''
    local _localhost_ip = product.get_product("capacity.localhost_ip") or ''
    if _httpHost and _httpHost == _master_ip then
        local _master = cmd.devSta.get({device = "pc", module = "master"}) or {}
        if _master.mastertip and _master.mastertip ~= '127.0.0.1' and _master.status == "Connected" then
            _masterIp = _master.mastertip
        else
            _masterIp = _localhost_ip
        end
        _masterIp = (toHttps and 'https://' or 'http://') .. _masterIp
    end
    return _masterIp
end

local function isSupportLang(langs, lang)
    for _, o in pairs(langs) do
        if lang == o.v then
            return true
        end
    end
    return false
end

function getIndex()
    local cmd = require "luci.modules.cmd"
    local uci = require "luci.model.uci".cursor()
    local model = uci:get_first("sysinfo", "sysinfo", "model") or ""
    local version = uci:get_first("sysinfo", "sysinfo", "software_version") or os.time()
    local devType = uci:get_first("sysinfo", "sysinfo", "dev_type")
    local company, isL = r, false
    local isIndustry = uci:get_first("sysinfo", "sysinfo", "logo") == string.lower(company)
    local toHttps = _hasHttps()
    local langs, lang = getSupportLangs(), getLang()
    if not isSupportLang(langs, lang) then
        lang = "en"
    end

    local langPolicy = (lang == 'zh_cn' or lang == 'zh_ft' or lang == 'jp') and 'zh_cn' or (LANGMAP[lang] and lang or 'en')
    local product = require("product")
    if isIndustry then
        langPolicy = 'en_r'
    else
        company = product.get_product("manufacturer.company")
        isL = custom == "L"
    end
    -- local agreementTime, policyTime = 0, 0 -- getPolicyTime(langPolicy)

      -- 协议签署
    local _userAgreement = cmd.devSta.get({device = "pc", module = "user_agreement_sign_status",data = {time_out = "3"}}) or {}
    local isCheckReadAgreement = _userAgreement.sign_status == 'true'

    return {
        title = "%s - %s" % {company, string.gsub(web, "w", "W")},
        -- 新设备
        isNew = uci:get_first("mqtt", "mqtt", "networkId") == "0",
        -- 公司名称
        company = company or '',
        -- 公司简写
        companyLite = custom or '',
        -- 电话
        tel = product.get_product("manufacturer.aftersaleshotline"),
        -- 忘记密码提示地址
        lip = devType == "msw" and product.get_product("capacity.swmng_ip") or product.get_product("capacity.localhost_ip"),
        -- 主题题色 （背景色，按钮色，点缀色，文本色）
        themeColor = isL and {"#F5F7FA", "#41BC4C", "#255CDC", "#797E8A"} or {"#255CDC", "#255CDC", "#255CDC", "#FFF"},
        -- 产品型号
        model = model,
        -- 产品系列
        devType = devType,
        -- 是否行业版
        isIndustry = isIndustry,
        -- 当前语言
        lang = lang,
        -- 支持的语言列表
        langs = langs,
        -- 跳转到https
        toHttps = toHttps,
        -- 登录的设备ID(图示用)
        devId = _getDevId(),
        -- 版本号
        version = version,
        -- 用户协议
        agreement = getPolicyContentUrl(langPolicy, 1),
        -- 用户协议更新时间
        -- agreementTime = agreementTime,
        -- 用户数据处理协议
        policy = getPolicyContentUrl(langPolicy, 2),
        -- 用户数据处理协议更新时间
        -- policyTime = policyTime
        -- 主设备的IP地址
        masterIp = _getMasterIp(toHttps),
        -- 是否签署了隐私协议
        isCheckReadAgreement = isCheckReadAgreement,
        --R牌设备
        isR = product.get_product("manufacturer.custom") == "R"
    }
end

function getEntry(isEhr)
    local uci = require "luci.model.uci".cursor()
    local product = require("product")
    local lang = getLang()
    local version = uci:get_first("sysinfo", "sysinfo", "software_version") or os.time()
    local isNew = uci:get_first("mqtt", "mqtt", "networkId") == "0"
    local sessiontime = uci:get("luci", "sauth", "sessiontime") or 3600
    local env = {}
    local devId = _getDevId()

    local toHttps = _hasHttps()
    local ctx = require "luci.dispatcher".context
    local sid = ctx.authsession
    local sn = ctx.sn
    local stok = ctx.urltoken.stok
    local country = luci.sys.exec("ac_config get -m wireless | jq .radioList[0].country") or '"CN"'
    local isL = product.get_product("manufacturer.custom") == "L"
    local bodyClass = product.get_product("capacity.webBodyClass")
    return sid, sn, stok, lang, version, env, isNew, sessiontime, toHttps, devId, string.trim(country), product.get_product("capacity.sct.m"), bodyClass, isL
end
