module("luci.modules.openvpn", package.seeall)

fileMap = {
    ca = "/etc/openvpn/client/ca.crt",
    book = "/etc/openvpn/client/client.crt",
    key = "/etc/openvpn/client/client.key",
    tls = "/etc/openvpn/client/ta.key",
    client = "/etc/openvpn/client/client.ovpn",
    share = "/etc/openvpn/client/static.key",
    tar = "/etc/openvpn/openvpn-client-cfg.tar",
    serverLog = "/tmp/log/openvpn/openvpn.log",
    clientLog = "/tmp/log/openvpn/openvpn.log"
}
--如果没有目录，先生成指定目录
local filepath = "/etc/openvpn/client/"
if not nixio.fs.access(filepath) then
    nixio.fs.mkdir(filepath)
end

local function getPath(_type)
    return type(_type) == "string" and string.len(_type) < 20 and fileMap[_type] or false
end

-- OpenVpn文件(上传)
-- 返回rcode： 1：参数异常；2：设备存储空间不够； 0：成功
function vpnUpload()
    local path = getPath(luci.http.formvalue("type", true))
    if not path then
        return {rcode = 1}
    end
    local tool = require "luci.utils.tool"
    -- tool.debug("_storage", _size)
    tool.uploadFile(path, 1)
    local _size = nixio.fs.stat(path).size
    if _size < 102400 then
        tool.weblog(path, "UPGRADE OPENVPN FILE:")
        return {
            rcode = 0,
            size = _size
        }
    else
        nixio.fs.unlink(path)
        return {rcode = 2, msg = "The file is too large"}
    end
end

-- 判断oepnVpn客户端配置文件是否存在
function isExistPackOpenVpn(_type, showPath)
    local path = getPath(_type)
    local tool = require "luci.utils.tool"
    if not path then
        return {
            isExist = false
        }
    end
    local pathArr = luci.util.split(path, "/")
    return {
        isExist = not (not nixio.fs.access(path)) or false,
        path = showPath and path or nil,
        fileName = pathArr[#pathArr]
    }
end

-- 判断oepnVpn客户端配置文件是否存在
function isFileExist()
    local res = {}
    for key, path in pairs(fileMap) do
        res[key] = not (not nixio.fs.access(path))
    end
    return res
end
