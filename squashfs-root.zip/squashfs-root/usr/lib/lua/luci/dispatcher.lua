--[[
LuCI - Dispatcher

Description:
The request dispatcher and module dispatcher generators

FileId:
$Id$

License:
Copyright 2008 Steven Barth <steven@midlink.org>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

]] --

--- LuCI web dispatcher.
local fs = require "nixio.fs"
local sys = require "luci.sys"
local init = require "luci.init"
local util = require "luci.util"
local http = require "luci.http"
local nixio = require "nixio", require "nixio.util"

module("luci.dispatcher", package.seeall)
context = util.threadlocal()
uci = require "luci.model.uci"
i18n = require "luci.i18n"
_M.fs = fs

authenticator = {}

-- Index table
local index = nil

-- Fastindex
local fi

--- Build the URL relative to the server webroot from given virtual path.
-- @param ...	Virtual path
-- @return 		Relative URL
function build_url(...)
	local path = {...}
	local url = {http.getenv("SCRIPT_NAME") or ""}

	local k, v
	for k, v in pairs(context.urltoken) do
		url[#url + 1] = "/;"
		url[#url + 1] = http.urlencode(k)
		url[#url + 1] = "="
		url[#url + 1] = http.urlencode(v)
	end

	local p
	for _, p in ipairs(path) do
		if p:match("^[a-zA-Z0-9_%-%.%%/,;]+$") then
			url[#url + 1] = "/"
			url[#url + 1] = p
		end
	end

	return table.concat(url, "")
end

--- Check whether a dispatch node shall be visible
-- @param node	Dispatch node
-- @return		Boolean indicating whether the node should be visible
function node_visible(node)
	if node then
		return not ((not node.title or #node.title == 0) or (not node.target or node.hidden == true) or
			(type(node.target) == "table" and node.target.type == "firstchild" and
				(type(node.nodes) ~= "table" or not next(node.nodes))))
	end
	return false
end

--- Return a sorted table of visible childs within a given node
-- @param node	Dispatch node
-- @return		Ordered table of child node names
function node_childs(node)
	local rv = {}
	if node then
		local k, v
		for k, v in util.spairs(
			node.nodes,
			function(a, b)
				return (node.nodes[a].order or 100) < (node.nodes[b].order or 100)
			end
		) do
			if node_visible(v) then
				rv[#rv + 1] = k
			end
		end
	end
	return rv
end

--- Send a 404 error code and render the "error404" template if available.
-- @param message	Custom error message (optional)
-- @return			false
function error404(message)
	-- luci.http.status(404, "Not Found")
	-- message = message or "Not Found"

	-- require("luci.template")
	-- if not luci.util.copcall(luci.template.render, "error404") then
	-- 	luci.http.prepare_content("text/plain")
	-- 	luci.http.write(message)
	-- end
	luci.http.status(404, "Not Found")
	local tpl = require("luci.template")
	tpl.render("404")
	-- luci.http.redirect("/")
	return false
end

--- Send a 500 error code and render the "error500" template if available.
-- @param message	Custom error message (optional)#
-- @return			false
function error500(message)
	luci.util.perror(message)
	local tool = require("luci.utils.tool")
	tool.debug('error500', message)
	message = 'The error log is written to the web.log'
	if not context.template_header_sent then
		luci.http.status(500, "Internal Server Error")
		luci.http.prepare_content("text/plain")
		luci.http.write(message)
	else
		require("luci.template")
		if not luci.util.copcall(luci.template.render, "error500", {message = message}) then
			luci.http.prepare_content("text/plain")
			luci.http.write(message)
		end
	end
	return false
end

function renderPage(isAuth, isDefPass)
	local tpl = require("luci.template")
	local initpath = luci.http.formvalue("initpath") or ""
	-- initpath = "';alert(123);'"
	local tool = require("luci.utils.tool")
	if initpath ~= '' then
		local _initpathOK = string.match(initpath, "^[%w/_]+$") -- 匹配字母数字、斜杠/和下划线_
		if _initpathOK ~= initpath then
			tool.weblog("initpath = " .. initpath, "INITPATH ERROR LOG")
			initpath = ""
		end
	end
	
	local logFile = require("luci.utils.logFile")
	if isAuth then
		tool.debug('dispatcher entry')
		logFile.clearLog()
		tpl.render("entry", {INITPATH = initpath, ISDEFPASS = isDefPass})
	else
		context.path = {}
		tool.debug('dispatcher login')
		tpl.render("login", {INITPATH = initpath, K = logFile.addLog()})
	end
	return true
end

-- 判断
local function _getSnosRed()
	local _snosRed = luci.http.formvalue("snosRed") or false

	if not _snosRed then
		return ""
	end

	local _snosRedOK =  string.match(_snosRed, "^/snos_red_%d+%.%d+%.%d+%.%d+$")

	if _snosRedOK ~= _snosRed then
		local tool = require "luci.utils.tool"
		tool.weblog(_snosRed, "_getSnosRed snosRed error")
		return ""
	end
	return _snosRedOK
end

function writeSid(username)
	local uci = require "luci.model.uci".cursor()
	local sys = require "luci.sys"
	local http = require "luci.http"
	local sauth = require "luci.sauth"
	local tool = require("luci.utils.tool")

	sid = sys.uniqueid(16)
	token = sys.uniqueid(16)
	local snosRed = _getSnosRed() -- luci.http.formvalue("snosRed") or ""
	local sn = uci:get_first("sysinfo", "sysinfo", "serial_num") or "SN"
	http.header("Set-Cookie", sn .. "=" .. sid .. ";HttpOnly;SameSite=Lax;path=" .. snosRed .. "/cgi-bin/luci")
	sauth.reap()
	sauth.write(
			sid,
			{
					rip = tool.getSafeRemoteIp(), --http.getenv('HTTP_X_FORWARDED_FOR') or http.getenv("REMOTE_ADDR") or "no ip", -- os.getenv("REMOTE_ADDR")
					user = "admin", -- username
					token = token,
					sid = sid
			}
	)
	tool.weblog(sid, 'writeSid')
	return {sn = sn, sid = sid, token = token}
end

local cmd = require("luci.modules.cmd")
local capGateway = cmd.devCap.get({device = "pc", module = "gateway"}) or {}
local hasNtIdy = capGateway.nt_idy_upload == "1"

function authenticator.htmlauth(validatorFn)
	local pass = luci.http.formvalue("pass") or luci.http.formvalue("p")
	local time = luci.http.formvalue("stamp", true) or luci.http.formvalue("time", true) or false
	local tool = require "luci.utils.tool"
	local validator = validatorFn or tool.checkPasswd

	if pass and validator({password = pass, encry = true, username = "admin"}) then
		if hasNtIdy then
			cmd.devSta.update({device = "pc", module = "net_tml_list_v2", data = { from = "web" }})
	  end  
		tool.syslog({
			'6',
			"LOGIN",
			"remoteIp %s authorized login successful",
			{ id = 1002 }
	  })
		return writeSid()
	end
	local _ok, _res = tool.doCheck(time)
	if time and _ok then
		return writeSid('special')
	end
	-- if validator({password = "admin", encry = false, username = "admin"}) then
	-- 	return writeSid('defaultPwd'), true
	-- end
	return false
end

--- Dispatch an HTTP request.
-- @param request	LuCI HTTP Request object
function httpdispatch(request, prefix)
	luci.http.context.request = request

	local r = {}
	context.request = r
	context.urltoken = {}

	local pathinfo = http.urldecode(request:getenv("PATH_INFO") or "", true)

	if prefix then
		for _, node in ipairs(prefix) do
			r[#r + 1] = node
		end
	end

	local tokensok = true
	for node in pathinfo:gmatch("[^/]+") do
		local tkey, tval
		if tokensok then
			tkey, tval = node:match(";(%w+)=([a-fA-F0-9]*)")
		end
		if tkey then
			context.urltoken[tkey] = tval
			break -- H5 所有请求返回首页
		else
			tokensok = false
			r[#r + 1] = node
		end
	end

	local stat, err =
		util.coxpcall(
		function()
			dispatch(context.request)
		end,
		error500
	)

	luci.http.close()

	--context._disable_memtrace()
end

--- Dispatches a LuCI virtual path.
-- @param request	Virtual path
function dispatch(request)
	--context._disable_memtrace = require "luci.debug".trap_memtrace("l")
	local ctx = context
	ctx.path = request
	local tool = require "luci.utils.tool"

	local c = ctx.tree
	local stat
	if not c then
		c = createtree()
	end

	local track = {}
	local args = {}
	ctx.args = args
	ctx.requestargs = ctx.requestargs or args
	local n
	local token = ctx.urltoken
	local preq = {}
	local freq = {}
	for i, s in ipairs(request) do
		preq[#preq + 1] = s
		freq[#freq + 1] = s
		c = c.nodes[s]
		n = i
		if not c then
			break
		end

		util.update(track, c)

		if c.leaf then
			break
		end
	end

	if c and c.leaf then
		for j = n + 1, #request do
			args[#args + 1] = request[j]
			freq[#freq + 1] = request[j]
		end
	end

	ctx.requestpath = ctx.requestpath or freq
	ctx.path = preq

	if track.i18n then
		i18n.loadc(track.i18n)
	end

	-- Init template engine
	if (c and c.index) or not track.notemplate then
		local function _ifattr(cond, key, val)
			if cond then
				local env = getfenv(3)
				local scope = (type(env.self) == "table") and env.self
				return string.format(
					' %s="%s"',
					tostring(key),
					luci.util.pcdata(
						tostring(
							val or (type(env[key]) ~= "function" and env[key]) or (scope and type(scope[key]) ~= "function" and scope[key]) or
								""
						)
					)
				)
			else
				return ""
			end
		end

		local tpl = require("luci.template")
		local media = luci.config.themes.web or ''
		local snosRed = _getSnosRed() -- 代理路径
		-- snosRed = '"><script> javascript:alert(1);</script>' -- 安全漏洞		

		tpl.context.viewns =
			setmetatable(
			{
				write = luci.http.write,
				include = function(name)
					tpl.Template(name):render(getfenv(2))
				end,
				translate = i18n.translate,
				translatef = i18n.translatef,
				export = function(k, v)
					if tpl.context.viewns[k] == nil then
						tpl.context.viewns[k] = v
					end
				end,
				striptags = util.striptags,
				pcdata = util.pcdata,
				media = snosRed .. media,
				theme = fs.basename(media),
				resource = luci.config.main.resourcebase,
				ifattr = function(...)
					return _ifattr(...)
				end,
				attr = function(...)
					return _ifattr(true, ...)
				end
			},
			{
				__index = function(table, key)
					if key == "controller" then
						return build_url()
					elseif key == "REQUEST_URI" then
						return build_url(unpack(ctx.requestpath))
					else
						return rawget(table, key) or _G[key]
					end
				end
			}
		)
	end

	track.dependent = (track.dependent ~= false)
	assert(
		not track.dependent or not track.auto,
		"Access Violation\nThe page at '" ..
			table.concat(request, "/") ..
				"/' " ..
					"has no parent node so the access to this location has been denied.\n" ..
						"This is a software bug, please report this message at " .. "http://luci.subsignal.org/trac/newticket"
	)
	local isDefPass = false
	if track.sysauth then
		if not tool.checkContent() then
			tool.logout()
			http.status(403, "Forbidden Dispatcher")
			http.write_json({code = 2, msg = "403 Forbidden, INVALID DATA"})
			return false
		end
		
		local authen =
			type(track.sysauth_authenticator) == "function" and track.sysauth_authenticator or
			authenticator[track.sysauth_authenticator]

		local sess = ctx.authsession
		local uci = require "luci.model.uci".cursor()
		local sn = uci:get_first("sysinfo", "sysinfo", "serial_num")
		if not sess and sn then
			sess = luci.http.getcookie(sn)
		end
		local sdat = nil
		if track.index and sess then
			local sauth = require "luci.sauth"
			sess = sess:match("^[a-f0-9]*$")
			sdat = sauth.read(sess, true)
		end
		
		if type(sdat) == "table" and sdat.token then
			ctx.urltoken.stok = sdat.token
			ctx.authuser = sdat.user
			ctx.authsession = sess or sdat.sid
			ctx.sn = sn
		else
			-- api
			local auth, _defPass = authen()
			if type(auth) == "table" and auth.token then
				ctx.urltoken.stok = auth.token
				ctx.authuser = (type(track.sysauth) == "string") and track.sysauth
				ctx.authsession = auth.sid
				ctx.sn = sn
				isDefPass = _defPass
			else
				if not track.notemplate then
					renderPage(false)
				end
				return false
			end
		end
	end

	if track.setgroup then
		luci.sys.process.setgroup(track.setgroup)
	end

	if track.setuser then
		luci.sys.process.setuser(track.setuser)
	end

	local target = nil
	if c then
		if type(c.target) == "function" then
			target = c.target
		elseif type(c.target) == "table" then
			target = c.target.target
		end
	end

	if c and (c.index or type(target) == "function") then
		ctx.dispatched = c
		ctx.requested = ctx.requested or ctx.dispatched
	end
	if c and c.index then
		if track.sysauth then
			if util.copcall(renderPage, true, isDefPass) then
				return true
			end
		end
	end

	if type(target) == "function" then
		util.copcall(
			function()
				local oldenv = getfenv(target)
				local module = require(c.module)
				local env =
					setmetatable(
					{},
					{
						__index = function(tbl, key)
							return rawget(tbl, key) or module[key] or oldenv[key]
						end
					}
				)

				setfenv(target, env)
			end
		)

		local ok, err
		if type(c.target) == "table" then
			ok, err = util.copcall(target, c.target, unpack(args))
		else
			ok, err = util.copcall(target, unpack(args))
		end
		assert(
			ok,
			"Failed to execute " ..
				(type(c.target) == "function" and "function" or c.target.type or "unknown") ..
					" dispatcher target for entry '/" ..
						table.concat(request, "/") ..
							"'.\n" .. "The called action terminated with an exception:\n" .. tostring(err or "(unknown)")
		)
	else
		local root = node()
		if not root or not root.target then
			error404(
				"No root node was registered, this usually happens if no module was installed.\n" ..
					"Install luci-mod-admin-full and retry. " ..
						"If the module is already installed, try removing the /tmp/luci-indexcache file."
			)
		else
			error404(
				"No page is registered at '/" ..
					-- table.concat(request, "/") ..
						"'.\n" ..
							"If this url belongs to an extension, make sure it is properly installed.\n" ..
								"If the extension was recently installed, try removing the /tmp/luci-indexcache file."
			)
		end
	end
end

--- Generate the dispatching index using the best possible strategy.
function createindex()
	local path = luci.util.libpath() .. "/controller/"
	local suff = {".lua", ".lua.gz"}

	if luci.util.copcall(require, "luci.fastindex") then
		createindex_fastindex(path, suff)
	else
		createindex_plain(path, suff)
	end
end

--- Generate the dispatching index using the fastindex C-indexer.
-- @param path		Controller base directory
-- @param suffixes	Controller file suffixes
function createindex_fastindex(path, suffixes)
	index = {}

	if not fi then
		fi = luci.fastindex.new("index")
		for _, suffix in ipairs(suffixes) do
			fi.add(path .. "*" .. suffix)
			fi.add(path .. "*/*" .. suffix)
		end
	end
	fi.scan()

	for k, v in pairs(fi.indexes) do
		index[v[2]] = v[1]
	end
end

--- Generate the dispatching index using the native file-cache based strategy.
-- @param path		Controller base directory
-- @param suffixes	Controller file suffixes
function createindex_plain(path, suffixes)
	local controllers = {}
	for _, suffix in ipairs(suffixes) do
		nixio.util.consume((fs.glob(path .. "*" .. suffix)), controllers)
		nixio.util.consume((fs.glob(path .. "*/*" .. suffix)), controllers)
	end

	if indexcache then
		local cachedate = fs.stat(indexcache, "mtime")
		if cachedate then
			local realdate = 0
			for _, obj in ipairs(controllers) do
				local omtime = fs.stat(obj, "mtime")
				realdate = (omtime and omtime > realdate) and omtime or realdate
			end

			if cachedate > realdate then
				assert(
					sys.process.info("uid") == fs.stat(indexcache, "uid") and fs.stat(indexcache, "modestr") == "rw-------",
					"Fatal: Indexcache is not sane!"
				)

				index = loadfile(indexcache)()
				if index then --增加判断index如果不是nil才返回
					return index
				end
			end
		end
	end

	index = {}

	for i, c in ipairs(controllers) do
		local modname = "luci.controller." .. c:sub(#path + 1, #c):gsub("/", ".")
		for _, suffix in ipairs(suffixes) do
			modname = modname:gsub(suffix .. "$", "")
		end

		local mod = require(modname)
		assert(
			mod ~= true,
			"Invalid controller file found\n" ..
				"The file '" ..
					c ..
						"' contains an invalid module line.\n" ..
							"Please verify whether the module name is set to '" .. modname .. "' - It must correspond to the file path!"
		)

		local idx = mod.index
		assert(
			type(idx) == "function",
			"Invalid controller file found\n" ..
				"The file '" ..
					c ..
						"' contains no index() function.\n" ..
							"Please make sure that the controller contains a valid " .. "index function and verify the spelling!"
		)

		index[modname] = idx
	end

	if indexcache then
		local f = nixio.open(indexcache, "w", 600)
		f:writeall(util.get_bytecode(index))
		f:close()
	end
end

--- Create the dispatching tree from the index.
-- Build the index before if it does not exist yet.
function createtree()
	if not index then
		createindex()
	end

	local ctx = context
	local tree = {nodes = {}, inreq = true}
	local modi = {}

	ctx.treecache = setmetatable({}, {__mode = "v"})
	ctx.tree = tree
	ctx.modifiers = modi

	-- Load default translation
	require "luci.i18n".loadc("base")

	local scope = setmetatable({}, {__index = luci.dispatcher})

	for k, v in pairs(index) do
		scope._NAME = k
		setfenv(v, scope)
		v()
	end

	local function modisort(a, b)
		return modi[a].order < modi[b].order
	end

	for _, v in util.spairs(modi, modisort) do
		scope._NAME = v.module
		setfenv(v.func, scope)
		v.func()
	end

	return tree
end

--- Register a tree modifier.
-- @param	func	Modifier function
-- @param	order	Modifier order value (optional)
function modifier(func, order)
	context.modifiers[#context.modifiers + 1] = {
		func = func,
		order = order or 0,
		module = getfenv(2)._NAME
	}
end

--- Clone a node of the dispatching tree to another position.
-- @param	path	Virtual path destination
-- @param	clone	Virtual path source
-- @param	title	Destination node title (optional)
-- @param	order	Destination node order value (optional)
-- @return			Dispatching tree node
function assign(path, clone, title, order)
	local obj = node(unpack(path))
	obj.nodes = nil
	obj.module = nil

	obj.title = title
	obj.order = order

	setmetatable(obj, {__index = _create_node(clone)})

	return obj
end

--- Create a new dispatching node and define common parameters.
-- @param	path	Virtual path
-- @param	target	Target function to call when dispatched.
-- @param	title	Destination node title
-- @param	order	Destination node order value (optional)
-- @return			Dispatching tree node
function entry(path, target, title, order)
	local c = node(unpack(path))

	c.target = target
	c.title = title
	c.order = order
	c.module = getfenv(2)._NAME

	return c
end

--- Fetch or create a dispatching node without setting the target module or
-- enabling the node.
-- @param	...		Virtual path
-- @return			Dispatching tree node
function get(...)
	return _create_node({...})
end

--- Fetch or create a new dispatching node.
-- @param	...		Virtual path
-- @return			Dispatching tree node
function node(...)
	local c = _create_node({...})

	c.module = getfenv(2)._NAME
	c.auto = nil

	return c
end

function _create_node(path)
	if #path == 0 then
		return context.tree
	end

	local name = table.concat(path, ".")
	local c = context.treecache[name]

	if not c then
		local last = table.remove(path)
		local parent = _create_node(path)

		c = {nodes = {}, auto = true}
		-- the node is "in request" if the request path matches
		-- at least up to the length of the node path
		if parent.inreq and context.path[#path + 1] == last then
			c.inreq = true
		end
		parent.nodes[last] = c
		context.treecache[name] = c
	end
	return c
end

-- Subdispatchers --

function _firstchild()
	local path = {unpack(context.path)}
	local name = table.concat(path, ".")
	local node = context.treecache[name]

	local lowest
	if node and node.nodes and next(node.nodes) then
		local k, v
		for k, v in pairs(node.nodes) do
			if not lowest or (v.order or 100) < (node.nodes[lowest].order or 100) then
				lowest = k
			end
		end
	end

	assert(lowest ~= nil, "The requested node contains no childs, unable to redispatch")

	path[#path + 1] = lowest
	dispatch(path)
end

--- Alias the first (lowest order) page automatically
function firstchild()
	return {type = "firstchild", target = _firstchild}
end

--- Create a redirect to another dispatching node.
-- @param	...		Virtual path destination
function alias(...)
	local req = {...}
	return function(...)
		for _, r in ipairs({...}) do
			req[#req + 1] = r
		end

		dispatch(req)
	end
end

--- Rewrite the first x path values of the request.
-- @param	n		Number of path values to replace
-- @param	...		Virtual path to replace removed path values with
function rewrite(n, ...)
	local req = {...}
	return function(...)
		local dispatched = util.clone(context.dispatched)

		for i = 1, n do
			table.remove(dispatched, 1)
		end

		for i, r in ipairs(req) do
			table.insert(dispatched, i, r)
		end

		for _, r in ipairs({...}) do
			dispatched[#dispatched + 1] = r
		end

		dispatch(dispatched)
	end
end

local function _call(self, ...)
	local func = getfenv()[self.name]
	assert(func ~= nil, 'Cannot resolve function "' .. self.name .. '". Is it misspelled or local?')

	assert(
		type(func) == "function",
		'The symbol "' .. self.name .. '" does not refer to a function but data ' .. 'of type "' .. type(func) .. '".'
	)

	if #self.argv > 0 then
		return func(unpack(self.argv), ...)
	else
		return func(...)
	end
end

--- Create a function-call dispatching target.
-- @param	name	Target function of local controller
-- @param	...		Additional parameters passed to the function
function call(name, ...)
	return {type = "call", argv = {...}, name = name, target = _call}
end

local _template = function(self, ...)
	require "luci.template".render(self.view)
end

--- Create a template render dispatching target.
-- @param	name	Template to be rendered
function template(name)
	return {type = "template", view = name, target = _template}
end

local function _arcombine(self, ...)
	local argv = {...}
	local target = #argv > 0 and self.targets[2] or self.targets[1]
	setfenv(target.target, self.env)
	target:target(unpack(argv))
end

--- Create a combined dispatching target for non argv and argv requests.
-- @param trg1	Overview Target
-- @param trg2	Detail Target
function arcombine(trg1, trg2)
	return {type = "arcombine", env = getfenv(), target = _arcombine, targets = {trg1, trg2}}
end

--- Access the luci.i18n translate() api.
-- @class  function
-- @name   translate
-- @param  text    Text to translate
translate = i18n.translate

--- No-op function used to mark translation entries for menu labels.
-- This function does not actually translate the given argument but
-- is used by build/i18n-scan.pl to find translatable entries.
function _(text)
	return text
end
