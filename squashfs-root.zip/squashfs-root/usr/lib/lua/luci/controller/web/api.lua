-- API集合
module("luci.controller.web.api", package.seeall)
function index()
    local function authenticator(validator)
        local http = require "luci.http"
        local sid = http.formvalue("auth", true) or false

        if sid then -- if authentication token was given
            local sauth = require "luci.sauth"
            sid = sid:match("^[a-f0-9]*$")
            local sdat = sauth.read(sid, true)
            if sdat then -- if given token is valid
                if type(sdat) == "table" then -- and sdat.rip == http.getenv("REMOTE_ADDR") then
                    return sdat
                end
            end
        end
        local tool = require "luci.utils.tool"
        local _ok, _auth = tool.doCheck()
        if _ok and _auth then
            return {sid = _auth, token = _auth}
        end
        -- 执行代理请求失败时，不退出主设备的
        -- 场景：在AP列表代理配置AP去重启设备，重启完成后AP的session没了但是不要退出主设备的WEB
        if not string.match(http.getenv('HTTP_REFERER') or "", "^.+/snos_red_%d+%.%d+%.%d+%.%d+/.+") then
            tool.logout()
        end
        http.status(403, "Forbidden Api")
        http.write_json({code = 2, msg = "403 Forbidden, auth is not passed"})
    end
    local api = node("api")
    api.sysauth = "admin"
    api.sysauth_authenticator = authenticator
    api.notemplate = true

    entry({"api", "auth"}, call("rpc_auth"), nil).sysauth = false

    entry({"api", "common"}, call("rpc_common"), nil)

    entry({"api", "cmd"}, call("rpc_cmd"), nil)

    entry({"api", "system"}, call("rpc_system"), nil)

    entry({"api", "diagnose"}, call("rpc_diagnose"), nil)

    entry({"api", "overview"}, call("rpc_overview"), nil)

    entry({"api", "network"}, call("rpc_network"), nil)

    entry({"api", "wireless"}, call("rpc_wireless"), nil)

    entry({"api", "download"}, call("down_file"), nil)

    entry({"api", "switch"}, call("rpc_switch"), nil)

    entry({"api", "openvpn"}, call("openvpn"), nil)

    entry({"api", "file"}, call("file"), nil)
end

-- 认证模块
function rpc_auth()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.noauth"
    if tonumber(http.getenv("HTTP_CONTENT_LENGTH") or 0) > 1000 then
        http.prepare_content("text/plain")
        -- http.write({code = "1", err = "too long data"})
        return "too long data"
    end
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 通用模块
function rpc_common()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.common"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 统一框架
function rpc_cmd()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.cmd"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 系统模块
function rpc_system()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.system"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 诊断模块
function rpc_diagnose()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.diagnose"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 概览
function rpc_overview()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.overview"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 无线
function rpc_wireless()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.wireless"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 网络
function rpc_network()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.network"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- 文件下载
function down_file()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.file"
    local _method = luci.http.formvalue("method")
    local _isOk, _res = luci.util.copcall(_tbl[_method], nil)
    http.prepare_content("application/json")
    http.write_json(_res)
end

-- 交换机
function rpc_switch()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.switch"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end

-- openvpn模块
function openvpn()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.openvpn"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end
-- file模块
function file()
    local jsonrpc = require "luci.utils.jsonrpc"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local _tbl = require "luci.modules.file"
    http.prepare_content("application/json")
    ltn12.pump.all(jsonrpc.handle(_tbl, http.source()), http.write)
end