module("luci.controller.web.wifitest", package.seeall)
local http = require "luci.http"

function index()
    entry({"api", "wifitest"}, nil, nil)

    -- local common = require("luci.modules.common")
    -- local _capacity = common.capacity() -- 接口执行影响会其他接口访问时间！
    -- if _capacity.dev_type == 'eap' then -- eap有wifi测速接口
        entry({"api", "wifitest", "upload"}, call("wifiTestUpload"), nil).leaf = true
        entry({"api", "wifitest", "download"}, call("wifiTestDownload"), nil).leaf = true
        entry({"api", "wifitest", "delete"}, call("wifiTestDelete"), nil).leaf = true
        entry({"api", "wifitest", "uploadNullFile"}, call("uploadNullFile"), nil).leaf = true
    -- end
end
-- wifi测速上传接口
function wifiTestUpload()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.wifiTestUpload())
end
-- wifi测速下载接口
function wifiTestDownload()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.wifiTestDownload())
end
-- wifi测速删除文件
function wifiTestDelete()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.wifiTestDelete())
end
-- 上传但不写文件
function uploadNullFile()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.uploadNullFile())
end
