-- 入口页面

module("luci.controller.web.index", package.seeall)
function index()
    local root = node()
    if not root.target then
        root.target = alias("web")
        root.index = true
    end

    local page = node("web")
    page.target = template("entry")
    page.title = _("Administration")
    page.order = 10
    page.sysauth = "admin" -- {"admin", "root"}
    page.sysauth_authenticator = "htmlauth"
    page.ucidata = true
    page.index = true
end