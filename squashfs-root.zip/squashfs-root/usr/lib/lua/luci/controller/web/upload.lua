module("luci.controller.web.upload", package.seeall)
local http = require "luci.http"

function index()
    entry({"api", "upload"}, nil, nil)
    entry({"api", "upload", "upgradeLocal"}, call("upgradeLocal"), nil).leaf = true
    entry({"api", "upload", "restoreConfig"}, call("restoreConfig"), nil).leaf = true
    entry({"api", "upload", "vpnUpload"}, call("vpnUpload"), nil).leaf = true
    entry({"api", "upload", "fileTml"}, call("fileTml"), nil).leaf = true
    entry({"api", "upload", "upgradeSignature"}, call("upgradeSignature"), nil).leaf = true
    entry({"api", "upload", "portal"}, call("portal"), nil).leaf = true
    entry({"api", "upload", "pppoeUpload"}, call("pppoeUpload"), nil).leaf = true
    entry({"api", "upload", "urlGroupUpload"}, call("urlGroupUpload"), nil).leaf = true
end

-- 本地升级上传
function upgradeLocal()
    local file = require "luci.modules.file"
    local tool = require "luci.utils.tool"
    tool.debug("upgradeLocal")
    http.prepare_content("application/json")
    http.write_json(file.upgradeLocal())
end

-- 恢复配置上传
function restoreConfig()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.restoreConfig())
end

-- OpenVpn证书文件上传
function vpnUpload()
    local openvpn = require "luci.modules.openvpn"
    http.prepare_content("application/json")
    http.write_json(openvpn.vpnUpload())
end

-- 智能设备终端名称批量修改
function fileTml()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.fileTml())
end
-- 特征库本地升级
function upgradeSignature()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.upgradeSignature())
end
-- 本地认证定制
function portal()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.portal(http.getenv("QUERY_STRING")))
end
function pppoeUpload()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.pppoeUpload())
end
function urlGroupUpload()
    local file = require "luci.modules.file"
    http.prepare_content("application/json")
    http.write_json(file.urlGroupUpload())
end
