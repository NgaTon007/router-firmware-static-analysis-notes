module("luci.utils.logFile", package.seeall)

local json = require "luci.json"
local FILE = "/tmp/webLog"
local MAX_SIZE = 50 * 1024 -- 超过50KB会被清空
local TIMEOUT = 5 * 60  -- 未使用的密钥保活时间
-- local LOCKTIME, COUNT = 100, 2

local function getUser()
    return os.getenv("REMOTE_ADDR") or os.getenv("HTTP_USER_AGENT") or "unknown"
end

-- 生成记录
local function creatLog(log)
    -- 五分钟内生成一次key
    local _now = os.time()
    if log and _now - log.time < TIMEOUT then
        return log
    end

    local sys = require "luci.sys"
    local k = sys.uniqueid(16)
    return {
        k = k,
        -- used = false,
        time = _now
    }
end

-- 添加记录
function addLog()
    local fs = require("nixio.fs")
    local _user = getUser()
    local _logJson = {}

    -- 文件小于50KB时，读取（保留）旧数据
    if fs.access(FILE) and fs.stat(FILE).size < MAX_SIZE then
        _logJson = json.decode(fs.readfile(FILE)) or {}
    end
    -- local tool = require("luci.utils.tool")
    -- tool.debug("logFile _logJson", _logJson)
    -- 更新k
    _logJson[_user] = creatLog(_logJson[_user] or false)
    fs.writefile(FILE, json.encode(_logJson))
    return _logJson[_user].k or false
end

-- 获取记录
function getUserKey()
    local fs = require("nixio.fs")
    if not fs.access(FILE) then
        return false
    end

    local _logJson = luci.json.decode(fs.readfile(FILE))
    local _user = _logJson and _logJson[getUser()] or false

    if not _user then
        return false
    end

    -- local _lastTime = os.time() - _user.time
    -- if _lastTime <= LOCKTIME then
    --     return 'timeout'
    -- end
    if not _user.k then
        local tool = require("luci.utils.tool")
        tool.debug("logFile fail", "user key is nil")
        return false
    end
    return _user.k
end

function clearLog()
    local fs = require("nixio.fs")
    local user = getUser()
    if fs.access(FILE) then
        local loginLog = luci.json.decode(fs.readfile(FILE))
        if loginLog[user] then
            loginLog[user] = nil
            fs.writefile(FILE, luci.json.encode(loginLog))
        end
    end
end
