local debug = require "debug"
local io = require "io"
local collectgarbage, floor = collectgarbage, math.floor
local tostring, type, string, pairs, ipairs, table = tostring, type, string, pairs, ipairs, table
local MAX_SIZE = 50 * 1024
module("luci.utils.debug", package.seeall)
__file__ = debug.getinfo(1, "S").source:sub(2)
function index()
end
-- Enables the memory tracer with given flags and returns a function to disable the tracer again
function trap_memtrace(flags, dest)
    flags = flags or "clr"
    local tracefile = io.open(dest or "/tmp/memtrace", "w")
    local peak = 0

    local function trap(what, line)
        local info = debug.getinfo(2, "Sn")
        local size = floor(collectgarbage("count"))
        if size > peak then
            peak = size
        end
        if tracefile then
            tracefile:write(
                "[",
                what,
                "] ",
                info.source,
                ":",
                (line or "?"),
                "\t",
                (info.namewhat or ""),
                "\t",
                (info.name or ""),
                "\t",
                size,
                " (",
                peak,
                ")\n"
            )
        end
    end

    debug.sethook(trap, flags)

    return function()
        debug.sethook()
        tracefile:close()
    end
end
--

--[[
o:打印的数据
f:一般是io.write
b:是否打印[]
]] function luaprint(o, f, b)
    if type(f) ~= "function" and f ~= nil then
        error("expected second argument %s is a function", tostring(f))
    end
    if type(b) ~= "boolean" and b ~= nil then
        error("expected third argument %s is a boolean", tostring(b))
    end
    p = f or io.write
    b = b or false
    if type(o) == "number" or type(o) == "function" or type(o) == "boolean" or type(o) == "nil" then
        p(tostring(o))
    elseif type(o) == "string" then
        p(string.format("%q", o))
    elseif type(o) == "table" then
        p("{/n")
        for k, v in pairs(o) do
            if b then
                p("[")
            end

            luaprint(k, p, b)

            if b then
                p("]")
            end

            p(" = ")
            luaprint(v, p, b)
            p(",/n")
        end
        p("}")
    end
end

function debug_tofile(...)
    local printResult = ""

    for i, v in ipairs(arg) do
        if type(v) == "table" then
            table.foreach(
                v,
                function(k, l)
                    if type(l) == "table" then
                        printResult = printResult .. "\n" .. tostring(k) .. ":\n"
                        table.foreach(
                            l,
                            function(m, n)
                                printResult = printResult .. tostring(m) .. "=" .. tostring(n) .. "\n"
                            end
                        )
                        printResult = printResult .. "\n"
                    else
                        printResult = printResult .. tostring(k) .. "=" .. tostring(l) .. "\n"
                    end
                end
            )
        else
            printResult = printResult .. tostring(v) .. "\t"
        end
    end
    printResult = printResult .. "\n"

    local tracefile = io.open("/tmp/web.log", "a+")
    if tracefile then
        local file_size = tracefile:seek("end")
        if file_size > MAX_SIZE then
            luci.sys.call("mv /tmp/web.log /tmp/web.log.old")
        end
        tracefile:write(printResult)
        tracefile:close()
    end
end
