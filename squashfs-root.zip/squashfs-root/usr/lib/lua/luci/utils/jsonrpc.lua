--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>
Copyright 2008 Jo-Philipp Wich <xm@leipzig.freifunk.net>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]] --

module("luci.utils.jsonrpc", package.seeall)
require "luci.json"
function resolve(mod, method)
    local path = luci.util.split(method, ".")

    for j = 1, #path - 1 do
        if not type(mod) == "table" then
            break
        end
        mod = rawget(mod, path[j])
        if not mod then
            break
        end
    end
    mod = type(mod) == "table" and rawget(mod, path[#path]) or nil
    if type(mod) == "function" then
        return mod
    end
end

function handle(tbl, rawsource, ...)
    local decoder = luci.json.Decoder()
    local stat, err = luci.ltn12.pump.all(rawsource, decoder:sink())
    local json = decoder:get()
    local response
    local success = false

    if stat then
        if type(json.method) == "string" then
            local method = resolve(tbl, json.method)
            if method then
                response = reply(json.jsonrpc, json.id, proxy(method, json.params or {}))
            else
                response = reply(json.jsonrpc, json.id, nil, {code = -32601, message = "Method not found."})
            end
        else
            response = reply(json.jsonrpc, json.id, nil, {code = -32600, message = "Invalid request."})
        end
    else
        local tool = require "luci.utils.tool"
        tool.debug("[" .. os.date() .. " -s]" .. "=====      RPC HANDLE LOG", {err = err})
        response = reply("2.0", nil, nil, {code = -32700, message = "Parse error."})
    end

    return luci.json.Encoder(response, ...):source()
end

function reply(jsonrpc, id, res, err)
    require "luci.json"
    id = id or luci.json.null

    -- 1.0 compatibility
    if jsonrpc ~= "2.0" then
        jsonrpc = nil
        res = res or luci.json.null
        err = err or luci.json.null
    end
    -- if type(res) == "string" then
    --     res = luci.json.decode(res) or res
    -- end
    return {id = id, data = res, error = err, jsonrpc = jsonrpc, code = 0}
end

function proxy(method, ...)
    local tool = require "luci.utils.tool"
    local res = {luci.util.copcall(method, ...)}
    local stat = table.remove(res, 1)
    if not stat then
        tool.debug("[" .. os.date() .. " -s]" .. "=====      RPC ERROR LOG", {params = ...})
        -- return nil, {code = -32602, data = "jsonrpc:81", params = ..., res = res}
        return nil, {code = -32602, data = "jsonrpc:81", res = res}
    else
        if #res <= 1 then
            return res[1] or luci.json.null
        else
            tool.debug("[" .. os.date() .. " -s]" .. "=====      RPC ERROR LOG", {params = ...})
            -- return {code = -32603, data = "jsonrpc:89", params = ..., res = res}
            return {code = -32603, data = "jsonrpc:89", res = res}
        end
    end
end
