module("luci.utils.tool", package.seeall)

function debug(k, v)
    local debug = require "luci.utils.debug"
    debug.debug_tofile((k or 'nil') .. "=====", v)
end
-- web统一log格式
function weblog(shell, device, time)
    if device and device ~= 'pc' and includeXxs(device) then
        device = ''
    end
    local user = (device or "UNKNOWN") .. " (" .. (getSafeRemoteIp()) .. ")"
    debug("[" .. os.date() .. " " .. (time or '-') .. "s]", user .. ' --> ' .. shell)
end

-- params
function params()
    local json = require "luci.json"
    local http = require "luci.http"
    local ltn12 = require "luci.ltn12"
    local decoder = json.Decoder()
    local stat = ltn12.pump.all(http.source(), decoder:sink())
    return decoder:get()
end

-- decode
function decode(data)
    local json = require "luci.json"
    if type(data) == "string" then
        data = json.decode(data) or data
    end
    return data
end

-- 执行shell命令
function forkExec(command)
    local pid = nixio.fork()
    if pid > 0 then
        return pid
    elseif pid == 0 then
        nixio.chdir("/")
        local null = nixio.open("/dev/null", "w+")
        if null then
            nixio.dup(null, nixio.stderr)
            nixio.dup(null, nixio.stdout)
            nixio.dup(null, nixio.stdin)
            if null:fileno() > 2 then
                null:close()
            end
        end
        nixio.exec("/bin/sh", "-c", command)
    end
end

-- 上传文件
function uploadFile(command, type, mode)
    local fp = nil
    mode = mode or "w"
    type = type or 1
    luci.http.setfilehandler(
        function(meta, chunk, eof)
            if not fp then
                if type == 1 then
                    fp = io.open(command, mode)
                elseif type == 2 then
                    fp = io.popen(command, mode)
                end
            end
            if chunk then
                fp:write(chunk)
            end
            if eof then
                fp:close()
                fp = nil
            end
        end
    )
    local _file = luci.http.formvalue("file")
end

-- 创建reader
function ltn12Popen(command)
    local fdi, fdo = nixio.pipe()
    local pid = nixio.fork()

    if pid > 0 then
        fdo:close()
        local close
        return function()
            local buffer = fdi:read(2048)
            local wpid, stat = nixio.waitpid(pid, "nohang")
            if not close and wpid and stat == "exited" then
                close = true
            end

            if buffer and #buffer > 0 then
                return buffer
            elseif close then
                fdi:close()
                return nil
            end
        end
    elseif pid == 0 then
        nixio.dup(fdo, nixio.stdout)
        fdi:close()
        fdo:close()
        nixio.exec("/bin/sh", "-c", command)
    end
end

-- 下载文件
function downloadFile(command, fileName, mine)
    local http = require "luci.http"
    local reader = ltn12Popen(command)
    if mine == nil then
        mine = "application/x-targz"
    end
    http.header("Content-Disposition", 'attachment; filename="%s"' % fileName)
    http.prepare_content(mine)
    luci.ltn12.pump.all(reader, http.write)
    return true
end

-- 加密(aes-256-cbc)
function encry(value, key)
    local _shell = "echo '" .. value .. "' | openssl enc -aes-256-cbc -a -k '" .. key .. "'"
    return luci.sys.exec(_shell)
end

local function _checkid(id)
    return not (not (id and #id == 32 and id:match("^[a-fA-F0-9]+$")))
end

-- 解密函数
local function decrypt_aes256cbc_base64(encrypted_base64, password)
    local crypto = require("crypto")
    require('base64')
    -- Base64解码
    local encrypted_data = base64.dec_base64(encrypted_base64)
    -- debug("\nencrypted_data", encrypted_data)
    -- 提取Salt值
    -- local salt_prefix = "Salted__"
    local salt = string.sub(encrypted_data, 9, 16)
    -- debug("\nsalt", salt)
    local encrypted_content = string.sub(encrypted_data, 17)
    -- debug("\nencrypted_content", encrypted_content)

    -- 使用EVP_BytesToKey算法从密码和盐生成密钥和IV
    local function evp_bytes_to_key(password, salt, key_len, iv_len)
        local data = password .. salt
        local key_iv = ""
        while #key_iv < (key_len + iv_len) do
            data = crypto.digest("md5", data, true)
            key_iv = key_iv .. data
            data = data .. password .. salt
        end
        return string.sub(key_iv, 1, key_len), string.sub(key_iv, key_len + 1, key_len + iv_len)
    end

    -- 生成密钥和IV
    local key, iv = evp_bytes_to_key(password, salt, 32, 16)
    -- debug("\nkey", key)
    -- debug("\niv", iv)

    -- 解密
    local decrypted_data = crypto.decrypt("aes-256-cbc", encrypted_content, key, iv)
    -- debug("\ndecrypted_data", decrypted_data)
    return decrypted_data
end

-- 解密(aes-256-cbc)
function decry(value, key)
    if includeXxs(value) then
        return false
    end
    if not _checkid(key) then
        return false
    end

    debug(value, key)
    -- local decrypted_data = luci.sys.exec("echo '" .. value .. "' | openssl enc -d -aes-256-cbc -a -k '" .. key .. "'")

    local decrypted_data = decrypt_aes256cbc_base64(value, key)
    -- debug("\ntool decrypted", decrypted_data)
    return decrypted_data
end

-- 检测密码是否正确
function checkPasswd(checkStat)
    local cmd = require("luci.modules.cmd")
    local _data = {
        type = checkStat.encry and "enc" or "noenc",
        password = checkStat.password,
        name = checkStat.username or 'admin'
    }
    local _check = cmd.devSta.get({module = "adminCheck", device = "pc", data = _data})
    if type(_check) == "table" and _check.result == "success" then
        return true
    end
    return false, _check.reason
end

-- 修改密码
function modifyPasswd(password, enc, networkId, sn)
    local cmd = require("luci.modules.cmd")
    if password == '' then
        return { code = '-1', msg = 'empty password' }
    end
    if not enc then -- 修改的密码全部要求是密文密码
        password = aesEncode(password)
    end
    if not password then
        return { code = '-1', msg = 'error password' }
    end
    if includeQuote(password) then
        debug('includeQuote ==> password', password)
        return { code = '-1', msg = 'error quote password' }
    end
    local _data = {
        type = "enc",
        password = password,
        networkId = networkId or "0",
        groupId = "0",
        sn = sn or nil
    }
    local product = require("product")
    local webpw = product.get_product("capacity.webpw.module")
    return cmd.acConfig.set(
        {
            module = webpw,
            device = "pc",
            data = _data
        }
    )
end

-- 发送http请求
function http_post_client(url, body, timeout)
    local zhttp = require("luci.utils.http")
    local httpc = zhttp.new()

    timeout = timeout or 30000
    httpc:set_timeout(timeout)

    local res, err_ =
        httpc:request_uri(
        url,
        {
            method = "POST",
            body = body,
            headers = {
                ["Content-Type"] = "application/json"
            }
        }
    )
    if not res then
        return nil, err_
    else
        if res.status == 200 then
            return res.body, err_
        else
            return nil, err_
        end
    end
end
function checkTime(time)
    if type(time) == 'number' then
        return true
    end
    if type(time) == 'string' then
        return string.match(time, "^%d+$") -- 纯数字字符串
    end
    return false
end
-- 获取TQ
function getMd5(sn, ip, time)
    if checkTime(time) and checkIp(ip) and checkSn(sn) then
        local shell = "echo -n '%s%s%s' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1" % {time,sn,ip}
        return luci.sys.exec(shell)
    end
    return ""
end

function md5(str)
    if includeQuote(str) then
        debug('includeQuote ==> md5', str)
        return false
    end
    return string.trim(luci.sys.exec("echo -n '"..str.."' |md5sum|cut -d ' ' -f1"))
end

-- function aesEncode(str)
--     if includeQuote(str) then
--         debug('includeQuote ==> aesEncode', str)
--         return false
--     end

--     return string.trim(luci.sys.exec("echo -n '".. str .. "' | /usr/sbin/sd_crypto enc -t C"))
-- end

function aesEncode(str)
    local sd_crypto = require("sd_crypto")
    local plaintext = str

    local recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(plaintext, #plaintext, "c")
    if (recode ~= 0) then
        return false
    end
    return ciphertext
end

function doCheck(stamp)
	-- local _time = time - os.time()
	-- local isIn5mins = _time > -300 or _time < 300  --  isIn5mins then
    local auth = luci.http.formvalue("auth", true) or false
    local time = stamp or luci.http.formvalue("time", true)
    if checkTime(time) and auth and auth ~= "" then
        local cmd = require("luci.modules.cmd")
        local webAuth = cmd.devSta.get({device = "pc", module = "webAuth", data = {type = "check", auth = auth, time = time, new = 1}}) or {}
        if (webAuth.code == '1') then
            weblog('webAuth Failed', 'doCheck')
            return false, nil
        end
        if (webAuth.rcode == '00000000') then
            weblog('webAuth OK', 'doCheck')
            return true, auth
        end
        local uci = require "luci.model.uci".cursor()
        local _master = cmd.devSta.get({device = "pc", module = "master", data = {native = "false"}}) or {}
        local sn = uci:get_first("sysinfo", "sysinfo", "serial_num")
        -- 整网已启用加密直接返回
        if _master.useSSL == true then
            local product = require("product")
            local _nbr_type = product.get_product("capacity.nbr_type") or ''
            local _host = os.getenv("REMOTE_ADDR") or "" -- os.getenv('HTTP_X_FORWARDED_FOR')
            weblog(_host, 'doCheck host ip')
            if (_master.role == 'ACP' or _master.role == 'AC' or _master.role == 'ACG') and checkIp(_host) then
                -- 兼容NBR/NTOS/FW调用主设备接口
                local _neighbor = cmd.devSta.get({device = "pc", module = "neighbor", data = {product = "%s|FW_NTOS|NBR_NTOS" % _nbr_type}}).neighbor or {}
                local _isInNeigbor = false
                for _, dev in ipairs(_neighbor) do
                    if dev.ip == _host then
                        _isInNeigbor = true
                        weblog(_host, 'host ip is in neighbor')
                        break
                    end
                end
                if not _isInNeigbor then
                    weblog(_host, 'host ip is not in neighbor, not allowed')
                    return false, nil
                end
            else
                weblog(sn, 'useSSL is true, tq not allowed')
                return false, nil
            end
        end
        local ip = _master.auth

        if not ip then
            local forwardMode = uci:get_first("sysinfo", "sysinfo", "forwardMode")
            local dev = uci:get_first("sysinfo", "sysinfo", "dev_type")
            ip = uci:get_first("sysinfo", "sysinfo", "wan_ip")

            if forwardMode == "ROUTER" then
                ip = uci:get("network", "lan", "ipaddr")
            elseif dev == "msw" then
                local proto = uci:get("network", "wan", "proto")
                if proto == 'static' then
                    ip = uci:get("network", "wan", "ipaddr")
                end
            end
        end

        local md5 = getMd5(sn, ip, time)
        md5 = string.gsub(md5, "^%s*(.-)%s*$", "%1")
        auth = string.gsub(auth, "^%s*(.-)%s*$", "%1")
        if md5 == auth and md5 ~= '' then
            return true, auth
        else
            weblog(md5 .. ' != ' .. auth, 'doCheck auth')
            debug('auth data ', {sn=sn, ip=ip, time=time})
        end
    end
    return false, nil
end

-- 数组转map
function arrToObj(pages)
    local _map = {}
    for _, page in pairs(pages) do
        _map[page] = page
    end
    return _map
end

-- 对象是否包含
function tb_include(tb, value)
    for k, v in pairs(tb) do
        if v == value then
            return true
        end
    end
    return false
end

-- table拷贝
function tb_copy(tb)
    local _type = type(tb)
    local _copy
    if _type == "table" then
        _copy = {}
        for k, v in pairs(tb) do
            _copy[k] = tb_copy(v)
        end
    else
        _copy = tb
    end
    return _copy
end

-- logger
function write_log(cfg)
    -- local http = require "luci.http"
    -- local ip = http.getenv("REMOTE_ADDR") or ""
    -- local sid = luci.http.formvalue("auth")
    -- local username = cfg.username or "unknown"
    -- local level = cfg.level or "user.notice"
    -- local cfgAct = cfg.action or "unknown action"
    -- if sid then
    --     local sauth = require "luci.sauth"
    --     sid = sid:match("^[a-f0-9]*$")
    --     local userToken = sauth.read(sid)
    --     username = type(userToken) == "table" and userToken.user or "unknown"
    -- end
    -- if type(username) ~= "string" then
    --     username = "unknown"
    -- end
    -- local shell = "logger -t WEB -p " .. level .. " user:" .. username .. " '" .. cfgAct .. "' from " .. ip
    -- shell = filterExecShell(shell)
    -- 可能存在注入风险/非显示需求，不写入logread
    -- return luci.sys.exec(shell)
end

-- XSS漏洞（可执行命令） shell执行命令注入校验/过滤
function filterExecShell(str)
    return string.gsub(str, "([\n\r`&$;|])", "\\%1")
end
function includeXxs(str)
    local ngstr = "[\n\r`&$;|]"
    return string.match(str, ngstr) ~= nil
end

function includeQuote(str)
    return string.match(str, "(['])") ~= nil
end

function checkIp(str)
    -- 放宽IP校验(tipcIp需要)
    return str and string.len(str) < 50 and string.match(str, "^[%.%d:%a]+$") ~= nil
end

function checkSn(str)
    return string.match(str, "^%w+$") ~= nil
end

function doShell(shell, async, call)
    if string.match(shell, "[\n\r'`&$;|]")  then
        weblog(shell, 'DO SHELL illegal')
        return {res = false, msg = "shell illegal"}
    end
    weblog(shell, 'DO SHELL')
    -- 异步已下发，不关注执行结果
    if async then
        forkExec(shell)
        return true
    end
    -- 返回下发成功与否，不需要执行结果
    if call then
        return luci.sys.call(shell)
    end
    -- 返回执行结果
    return luci.sys.exec(shell)
end

local product = require("product")
local curlMd5Pre = product.get_product("capacity.easydisc.curl_md5_pre") or "Sd"

function checkContent()
    local http = require "luci.http"
    local contentAccept = http.getenv("HTTP_CONTENT_ACCEPT") or false
    if contentAccept  then
        local contentLen = http.getenv("HTTP_CONTENT_LENGTH")
        local _contAccept = contentLen and md5("Web@" .. curlMd5Pre .. "$2020!"..contentLen) or ''
        if _contAccept ~= contentAccept then
            weblog(contentAccept, "INVALID DATA")
            debug(_contAccept, http.content()) -- http.content()只能读取一次
            return false
        end
    end
    return true
end

function logout(params)
    local dsp = require "luci.dispatcher"
    local sauth = require "luci.sauth"
    local uci = require "luci.model.uci".cursor()
    write_log({action = "logout"})
    weblog("LOGOUT", "pc")
    if dsp.context.authsession then
        sauth.kill(dsp.context.authsession)
        dsp.context.urltoken.stok = nil
    end
    local sn = params and params.sn or uci:get_first("sysinfo", "sysinfo", "serial_num") or "SN"
    local sid = luci.http.getcookie(sn)
    if sid then
        sauth.reap()
        weblog("Clear sid ==> " .. sid, "pc")
        luci.http.header("Set-Cookie", sn .. "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/cgi-bin/luci")
    end
    if params and params.log then
        syslog({
           '6',
           "LOGOUT",
           "remoteIp %s logout",
           { id = 1006 }
        })
    end
end

function doc( p )
    local _c = p.cmd
    local _res = {code = -1, msg = "cmd is null"}

    local _allowCmd = {
        "echo $(uci get sysinfo.@sysinfo[0].relayMode)===$(ifconfig |grep HWaddr |grep encap:Ethernet)",
        "echo $(uci get sysinfo.@sysinfo[0].relayMode)===$(uci get system.@system[0].hostname)===$(ethstt)===$(cat /proc/switch/switch0/arl_table)===$(ifconfig |grep apcli)===$(dev_sta get -m apcliInfo)===$(cut -f2 -d\" \" /tmp/sta_sta.info)===$(lua /usr/sbin/data_collect.lua sta_dev;cat /tmp/user_list/sta_dev.json)"
    }
    if not luci.util.contains(_allowCmd, _c) then
        weblog(_c, 'CMD IS NOT ALLOWED')
        return {code = -1, msg = "403 Forbidden, cmd is not allowed"}
    end

    if _c then
        if p.async then
            forkExec(_c) -- 异步
            _res = {code = 0, cmd = _c}
        else
            _res = luci.sys.exec(_c)
        end
    end
    return _res
end

-- 安全获取远程IP地址，防止HTTP头注入
function getSafeRemoteIp()
    local ip = os.getenv('HTTP_X_FORWARDED_FOR') or os.getenv('REMOTE_ADDR') or 'UNKNOWN'
    -- 验证IP格式，防止命令注入
    if ip ~= 'UNKNOWN' and not checkIp(ip) then
        debug('Invalid IP detected', ip)
        return 'UNKNOWN'
    end
    return ip
end

-- 获取能力表
function capacityWeb()
    local cmd = require("luci.modules.cmd")
    local product = require("product")
    return cmd.devCap.get({device = "pc", module = product.get_product("capacity.web")}) or {}
end

local cmd = require("luci.modules.cmd")
local capWeb = capacityWeb()
local hasSysLog = capWeb.std_syslog == "1"
local hasAlarm = capWeb.noAlarmLog ~= '1'
function syslog (params)
   local http = require "luci.http"
   local remoteIp = getSafeRemoteIp()
   params[3] = params[3] % remoteIp
   if hasSysLog then
      doShell("std_syslog_shell 1 %s 0 0 WEB %s \"%s\" " % params)
   end
   if hasAlarm then
    local res
    local extra = type(params[4]) == 'table' and params[4] or {}
    local paramsData = {
        ip = remoteIp
    }
    for k, v in pairs(extra) do
        if k ~= "id" then
            paramsData[k] = v
        end
    end
    local alarmParam = {
        opt = "add",
        id = 13019,
        msg = params[3],
        type = "event",
        age = 1800,
        data = {
            module_name = "WEB",
            id = extra.id,
            params = paramsData
        }
    }
    res = cmd.devSta.set({device = "pc", module = "alarm_mngt", data = alarmParam})
   end
end