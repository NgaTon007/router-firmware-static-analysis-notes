-- Licensed to the public under the Apache License 2.0.

module "luci.sys.zoneinfo.tzdata"

TZ = {
	{ 'Asia/Shanghai', 'CST-8' },
}
