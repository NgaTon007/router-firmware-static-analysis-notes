-- Licensed to the public under the Apache License 2.0.

module "luci.sys.zoneinfo.tzoffset"

OFFSET = {
}
