#! /usr/bin/lua
DEBUG_STATUS = "0";
DEBUG_LOG_DIR = "/tmp/vpn_mng/"
PROGRAM_NAME = "ippool_route";

--lua����debug����
if (DEBUG_STATUS == "1") then
    DEBUG_LOG_FILE = DEBUG_LOG_DIR .. "ippool_route.log";
    DEBUG_LOG_FILE_SIZE = 500;
end

--lua�ж��ļ������ļ����Ƿ����
function lua_is_file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

--lua��ȡ�ļ�����
function lua_get_file_line_number(file)
    local BUFSIZE = 65536;
    local lc = 0;
    local f = io.input(file);
    while (true) do
        local lines,rest = f:read(BUFSIZE,"*line");
        if not lines then
            break;
        end
        _,t = string.gsub(lines,"\n","\n");
        lc = lc + t;
    end
    return lc;
end

--lua����debug
function lua_debug(msg)
    if (DEBUG_STATUS == "1") then
        if (lua_is_file_exist(DEBUG_LOG_FILE) == true) then
            local log_line = lua_get_file_line_number(DEBUG_LOG_FILE);
            if (log_line > DEBUG_LOG_FILE_SIZE) then
                os.rename(DEBUG_LOG_FILE, DEBUG_LOG_FILE .. ".old");
            end
        else
            if (lua_is_file_exist(DEBUG_LOG_DIR) == false) then
                local char = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1";
                os.execute(char);
            end
        end

        local cur_time = os.date("%Y-%m-%d %H:%M:%S");

        local f = assert(io.open(DEBUG_LOG_FILE,"a"));
        f:write("[",cur_time,"] ",PROGRAM_NAME,"[",string.format("%3s",debug.getinfo(2).currentline),"] ",msg,"\n");
        f:close();
    end
end

--lua�����ַ��ָ��ַ���
function lua_split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

--luaִ��shell������
local function lua_exec_cmd(sh_cmd)
    if (sh_cmd == nil) then
        lua_debug("Error: enter lua_exec_cmd(), cmd is nil!");
        return nil;
    end
    local sh_ret_handle = io.popen(sh_cmd);
    local sh_ret = sh_ret_handle:read("*all");
    lua_debug("Debug: [execute cmd] " .. sh_cmd);
    lua_debug("Debug: [cmd  result] " .. sh_ret);
    return sh_ret;
end

--д���ļ�
function writefile(path, content, mode)
    mode = mode or "w+b"
    local file = io.open(path, mode)
    if file then
        if file:write(content) == nil then
            return false
        end
        io.close(file)
        return true
    else
        return false
    end
end

--lua���ļ�
function file_read(file)
    local f = assert(io.open(file,'r'));
    local content = f:read("*all");
    f:close();
    return content;
end

function Sleep(n)
   os.execute("sleep " .. n)
end

--ִ��ϵͳ�����ȡjson�ļ�,����table
function get_cmd_json_info(cmd)
    local data = {};
    local cjson = require "cjson";
    local var = io.popen(cmd);
    if ( var==nil ) then
        lua_debug(debug.getinfo(1).name,"a");
        lua_debug("Execute command failure","a");
    else
        t = var:read("*all");
        var:close();
        if (string.len(t) ~= 0) then
            data = cjson.decode(t);
        else
            lua_debug(debug.getinfo(1).name,"a");
            lua_debug("File is empty","a");
        end
    end
    return data;
end

function l2tp_manage(cmd_type, pool_name, remote_ip)
    local input_data=lua_exec_cmd("cat /etc/sd_config/single/l2tp_server.json 2>/dev/null")
    if (input_data == nil) then
        lua_debug("l2tp_server.json is empty.")
        return
    end

    local cjson = require "cjson";
    data = cjson.decode(input_data);
    lua_debug(input_data);

    if ( data["enable"] == nil or data["enable"] == "0" ) then
        lua_debug("l2tp is not enable.")
        return
    end

    if ( data["ippool_name"] ~=  pool_name ) then
        lua_debug(data["ippool_name"] .. "is not equal " .. pool_name)
        return
    end

    if ( data["netmode"] ==  "client2lan" ) then
        lua_debug("netmode is client2lan.")
        return
    end

    if (cmd_type ==  "add" ) then
        local result = lua_split(data["remotesubnet"],"/");
        for i=3,1,-1 do
            local check = lua_exec_cmd("route |grep \"".. remote_ip.."\" |grep "..result[1].." |wc -l")
            lua_debug("route |grep \"".. remote_ip.."\" |grep "..result[1].." |wc -l")
            if ( tonumber(check) < 1 ) then
                lua_exec_cmd("route add -net " .. data["remotesubnet"] .. " gw " .. remote_ip .. " 2>/dev/null")
            else
                lua_debug("route add success.")
                return
            end
            Sleep(1)
        end
    elseif(cmd_type ==  "del" ) then
        lua_exec_cmd("route del -net " .. data["remotesubnet"] .. " gw " .. remote_ip .. " 2>/dev/null")
    end
end

------------------��������--------------------------
local cmd_type = arg[1]
local pool_name = arg[2]
local remote_ip = arg[3]

--�������
if (remote_ip == nil or pool_name == nil) then
    lua_debug("Error: Param is error")
    return 1
end

l2tp_manage(cmd_type, pool_name, remote_ip)
