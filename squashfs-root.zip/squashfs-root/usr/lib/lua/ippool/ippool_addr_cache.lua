#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("ippool_addr_cache", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libexc = require("utils.exec");
local libtbl = require("utils.table");
local tool = require "dev.tools.common"
local ippool = require "utils.debug"
local dkjson = require "dkjson";
local DEBUG_LOG_DIR = "/tmp/debug/ippool/"
local IPPOOL_JSON_FILE = "/etc/sd_config/single/ippool.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug��ʼ��
function debug_init()
    ippool.debug_init(DEBUG_LOG_DIR, "ippool_addr_cache.log", 500, ippool.INFO, "1");
end

function ipset_scan(pool)
    ippool.lua_debug(ippool.INFO, "********************Enter ipset pool_scan(\"%s\")********************", pool);

    local obj = nil;
    local str = libexc.exec_cmd_ret(string.format("ipset save %s_alloc_addr 2>/dev/null |awk 'NR > 1' | awk '{print $3}'", pool));
    if(string.len(str) == 0)
    then
        return list;
    end
    
    local tab = require("utils.string").string_split_to_table(str, "\n");
    obj = {};
    obj.pool_name = pool;
    obj.pool = {};
    for _,v in ipairs(tab) do
        local ip,ifname = v:match("^ *(%S+),+(%S+)")
        ippool.lua_debug(ippool.INFO, "ip:"..ip);
        ippool.lua_debug(ippool.INFO, "ifname:"..ifname);
        if (ip ~= nil and ifname ~= nil) then
            local item = {}
            item.addr = ip;
            item.ifname = ifname;
            table.insert(obj.pool, item);
        end
        
    end

    return obj;
end

function ippool_addr_cache_load()
    debug_init();
    ippool.lua_debug(ippool.INFO, "#####################ippool_addr_cache_load####################");
    
    local conf_data = nil;
    local conf_json = {};
    local ret = {}
    local result_data;
    local conf_file = DEBUG_LOG_DIR.."ippool_ipset.json"
    
    if (tool.file_exist(IPPOOL_JSON_FILE) == true) then
        conf_data = tool.file_read(IPPOOL_JSON_FILE);
        if (tool.json_check(conf_data) == true) then
            conf_json = dkjson.decode(conf_data);
        end
    end
    
    if (conf_json["list"] == nil) then
        return 0;
    end
    
    ret["list"] = {};
    for i, var in ipairs(conf_json["list"]) do
        obj = ipset_scan(var["ippool_name"]);
        if (obj ~= nil)
        then
            table.insert(ret.list, obj);
        end
        ippool.lua_debug(ippool.INFO, "add "..var["ippool_name"]);
    end
    

    tool.file_write(conf_file, dkjson.encode(ret), "w+");
    
end

ippool_addr_cache_load()