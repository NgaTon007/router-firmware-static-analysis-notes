#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("ippool_reference", package.seeall);

local cjson = require "cjson";
local tool = require "dev.tools.common"
local PROGRAM_NAME = "ippool_reference"
local SD_CONFIG_JSON_FILE = "/etc/sd_config/single/ippool_reference.json"
local DEBUG_LOG_DIR = "/tmp/debug/ippool/"
local DEBUG_LOG_FILE = table.concat({DEBUG_LOG_DIR, PROGRAM_NAME, ".log"});
local DEBUG_LOG_FILE_SIZE = 500;

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--lua��ȡ�ļ�����
function get_file_line_number(file)
    local BUFSIZE = 65536;
    local lc = 0;
    local f = io.input(file);
    while (true) do
        local lines,rest = f:read(BUFSIZE,"*line");
        if not lines then
            break;
        end
        _,t = string.gsub(lines,"\n","\n");
        lc = lc + t;
    end
    return lc;
end

--lua����debug
function lua_debug(msg)
    if (tool.file_exist(DEBUG_LOG_FILE) == true) then
        local log_line = get_file_line_number(DEBUG_LOG_FILE);
        if (log_line > DEBUG_LOG_FILE_SIZE) then
            os.rename(DEBUG_LOG_FILE, table.concat({DEBUG_LOG_FILE, ".old"}));
        end
    end

    local cur_time = os.date("%Y-%m-%d %H:%M:%S");
    local f = assert(io.open(DEBUG_LOG_FILE,"a"));
    f:write("[",cur_time,"] ",PROGRAM_NAME,"[",string.format("%3s",debug.getinfo(2).currentline),"] ",msg,"\n");
    f:close();
end

function ippool_reference_get(param)
    lua_debug("#####################GET#####################");

    local result = 0;
    --��μ��
    if (param == nil or tool.json_check(param) == false) then
        ippool.lua_debug(ippool.ERROR, "Param is error.");
        return result;
    end
    input_json = cjson.decode(param);

    --��ȡ֮ǰ���������
    local save_json = {};
    if (tool.file_exist(SD_CONFIG_JSON_FILE) == true) then
        local save_data = tool.file_read(SD_CONFIG_JSON_FILE)
        if (save_data ~= nil and tool.json_check(save_data)) then
            save_json = cjson.decode(save_data);
        end
    end

    lua_debug(table.concat({"Input_json: ", cjson.encode(input_json)}));
    lua_debug(table.concat({"Save_json: ", cjson.encode(save_json)}));
    local ippool_name = input_json["ippool_name"];
    local ippool_module = input_json["module"];
    if (ippool_name == nil) then
        lua_debug(table.concat({"reference: ", result}));
        return result;
    end
    if (save_json[ippool_name] == nil or next(save_json[ippool_name]) == nil) then
        lua_debug(table.concat({"reference: ", result}));
        return result;
    end
    if (ippool_module == nil) then
        for key, val in pairs(save_json[ippool_name]) do
            if (val ~= nil and tonumber(val) ~= nil) then
                result = tonumber(val) + result;
            end
        end
    else
        for key, val in pairs(save_json[ippool_name]) do
            if (key == ippool_module and val ~= nil and tonumber(val) ~= nil) then
                result = tonumber(val);
            end
        end
    end

    lua_debug(table.concat({"reference: ", result}));
    lua_debug("#####################END####################");
    return result;
end

function ippool_reference_add(param)
    lua_debug("#####################ADD#####################");

    --��μ��
    if (param == nil or tool.json_check(param) == false) then
        ippool.lua_debug(ippool.ERROR, "Param is error.");
        return false;
    end
    input_json = cjson.decode(param);

    --��ȡ֮ǰ���������
    local save_json = {};
    if (tool.file_exist(SD_CONFIG_JSON_FILE) == true) then
        local save_data = tool.file_read(SD_CONFIG_JSON_FILE)
        if (save_data ~= nil and tool.json_check(save_data)) then
            save_json = cjson.decode(save_data);
        end
    end
    lua_debug(table.concat({"Input_json: ", cjson.encode(input_json)}));
    lua_debug(table.concat({"Save_json: ", cjson.encode(save_json)}));

    local ippool_name = input_json["ippool_name"];
    local ippool_module = input_json["module"];
    if (ippool_name == nil or ippool_module == nil) then
        lua_debug("ippool_name or module is nil.");
        return false;
    end

    if (save_json[ippool_name] == nil or next(save_json[ippool_name]) == nil) then
        save_json[ippool_name] = {};
        save_json[ippool_name][ippool_module] = "1";
    else
        if (save_json[ippool_name][ippool_module] == nil) then
            save_json[ippool_name][ippool_module] = "1";
        else
            local num = tonumber(save_json[ippool_name][ippool_module]) + 1;
            save_json[ippool_name][ippool_module] = tostring(num);
        end
    end

    --�����ļ�
    tool.file_write(SD_CONFIG_JSON_FILE, cjson.encode(save_json), "w+");
    lua_debug("#####################END####################");
    return true;
end

function ippool_reference_del(param)
    lua_debug("#####################DEL#####################");

    --��μ��
    if (param == nil or tool.json_check(param) == false) then
        ippool.lua_debug(ippool.ERROR, "Param is error.");
        return false;
    end
    lua_debug(table.concat({"Input: ", param}));
    input_json = cjson.decode(param);

    --��ȡ֮ǰ���������
    local save_json = {};
    if (tool.file_exist(SD_CONFIG_JSON_FILE) == true) then
        local save_data = tool.file_read(SD_CONFIG_JSON_FILE)
        if (save_data ~= nil and tool.json_check(save_data)) then
            save_json = cjson.decode(save_data);
        end
    end

    local ippool_name = input_json["ippool_name"];
    local ippool_module = input_json["module"];
    if (ippool_name == nil or ippool_module == nil) then
        lua_debug("ippool_name or module is nil.");
        return false;
    end

    if (save_json[ippool_name] == nil or next(save_json[ippool_name]) == nil) then
        return true;
    end

    if (save_json[ippool_name][ippool_module] == nil) then
        return true;
    end

    local num = tonumber(save_json[ippool_name][ippool_module]) - 1;
    if (num <= 0) then
        save_json[ippool_name][ippool_module] = nil;
    else
        save_json[ippool_name][ippool_module] = tostring(num);
    end
    
    if (next(save_json[ippool_name]) == nil) then
        save_json[ippool_name] = nil
    end

    --�����ļ�
    tool.file_write(SD_CONFIG_JSON_FILE, cjson.encode(save_json), "w+");
    lua_debug("#####################END####################");
    return true;
end
