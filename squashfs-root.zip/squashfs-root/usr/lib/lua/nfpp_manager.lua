package.path = "/usr/lib/lua/?.lua;" .. package.path;

require("uci")
--与其他内容审计脚本共同操作一个配置文件，x需要是全局的
x =uci.cursor()
local cjson = require "cjson" 
local DEBUG_LOG_DIR = "/tmp/"
local module_debug = require "utils.debug"
local cjson_safe = require "cjson.safe"
--debug初始化
module_debug.debug_init(DEBUG_LOG_DIR, "nfpp_manager.log", 200, module_debug.INFO, "1")

local _M = {}
--  set_nfpp_conntrack - 设置每用户和整机的新建流限速
--  @zone:				安全域(暂未使用，后期用)
--  @recordRate:		每ip的新建流限速
--  @globalRate:		整机的新建流限速
--  注意：入参不为字符串类型，要为number
--  返回值：0 - 配置成功; 1 - 配置失败
function _M.set_nfpp_conntrack(zone, recordRate, globalRate)
	local para = recordRate .. globalRate

	local cfg_json = {}
	if (recordRate == 0 and globalRate == 0) then
		cfg_json["conntrack_enable"] = "0"
	else
		cfg_json["conntrack_enable"] = "1"
	end

	cfg_json["record_burst"] = recordRate
	cfg_json["record_rate"] = recordRate
	cfg_json["global_burst"] = globalRate
	cfg_json["global_rate"] = globalRate
	local cfg_json_str = cjson.encode(cfg_json);
	local cmd = ". /usr/bin/nfpp_set_cfg.sh nfpp_set \'" .. cfg_json_str .. "\' \"nfpp_conntrack\""
	-- print(cmd)
	os.execute(cmd)
	module_debug.lua_debug(module_debug.INFO, "cmd = %s..", cmd)

	return 0
end

--  set_nfpp_bridge - 设置arp的限速和最大突发值
--  @zone:					安全域(暂未使用，后期用)
--  @arpRate:				arp限速速率
--  @arpBurst:				arp突发速率
--  注意：入参不为字符串类型，要为number
--  返回值：0 - 配置成功; 1 - 配置失败
function _M.set_nfpp_bridge(zone, arpRate, arpBurst)
	local para = arpRate .. arpBurst

	local cfg_json = {}
	if (arpRate == 0 and arpBurst == 0) then
		local broadcast_burst = x:get("nfpp", "nfpp_bridge", "broadcast_burst")
		local multicast_burst = x:get("nfpp", "nfpp_bridge", "multicast_burst")
		if (broadcast_burst == "0" and multicast_burst == "0") then
			cfg_json["bridge_enable"] = "0"
		else
			cfg_json["bridge_enable"] = "1"
		end
	else
		cfg_json["bridge_enable"] = "1"
	end
	cfg_json["arp_burst"] = arpBurst
	cfg_json["arp_rate"] = arpRate
	local cfg_json_str = cjson.encode(cfg_json);
	local cmd = ". /usr/bin/nfpp_set_cfg.sh nfpp_set \'" .. cfg_json_str .. "\' \"nfpp_bridge\""
	-- print(cmd)
	os.execute(cmd)
	module_debug.lua_debug(module_debug.INFO, "cmd = %s..", cmd)

	return 0
end

--  get_nfpp_conntrack - 获取新建流相关信息（新建平均限速、突发速率等）
--  返回值：数组，包含每ip和整机的限速和突发，以及每ip的老化时间和ip节点最大数
function _M.get_nfpp_conntrack()
    local tab = {}
    local cmd = ". /usr/bin/nfpp_get_cfg.sh nfpp_get_conntrack"
	local t = io.popen(cmd)
	local data = t:read("*all")
	local json_tr = cjson.decode(data);
	tab["record_burst"] = json_tr["record_burst"]
	tab["record_rate"] = json_tr["record_rate"]
	tab["global_burst"] = json_tr["global_burst"]
	tab["global_rate"] = json_tr["global_rate"]
	tab["ip_ageing_time"] = json_tr["ip_ageing_time"]
	tab["record_max_count"] = json_tr["record_max_count"]
	module_debug.lua_debug(module_debug.INFO, "record_rate = %d;global_rate = %d..", tab["record_rate"], tab["global_rate"])
	return tab
end

--  get_nfpp_bridge - 设置arp的限速和最大突发值
--  返回值：数组
function _M.get_nfpp_bridge()
    local tab = {}
    local cmd = ". /usr/bin/nfpp_get_cfg.sh nfpp_get_bridge"
	local t = io.popen(cmd)
	local data = t:read("*all")
	local json_tr = cjson.decode(data);
	tab["arp_burst"] = json_tr["arp_burst"]
	tab["arp_rate"] = json_tr["arp_rate"]
	module_debug.lua_debug(module_debug.INFO, "arp_burst = %d;arp_rate = %d..", tab["arp_burst"], tab["arp_rate"])
	return tab
end

local function syn_flood(node, defValue)
    local value = 500

    if (defValue ~= nil) then
        if (defValue * 5 > 500) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

local function udp_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 5 > 2000) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

local function arp_flood(node, defValue)
    local value = 300

    if (defValue ~= nil) then
        if (defValue * 2 > 300) then
            value = defValue * 2
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

local function icmp_flood(node, defValue)
    local value = 300

    if (defValue ~= nil) then
        if (defValue * 2 > 300) then
            value = defValue * 2
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

local function tcp_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 10 > 2000) then
            value = defValue * 10
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

local function other_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 5 > 2000) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        node["limit_rate"] = tostring(value)
    end
end

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

function _M.get_nfpp_defcfg_json()
    local content
    local defValueCfg = "/usr/lib/app_auth/app_auth.cfg"

    local def_cfg_str = '{"list":[{"zone_name":"lan","defend_ddos":{"syn_flood":{"enable":"1","limit_rate":"500"},"icmp_flood":{"enable":"0","limit_rate":"300"},"udp_flood":{"enable":"0","limit_rate":"2000"},"arp_flood":{"enable":"0","limit_rate":"300"},"tcp_other_flood":{"enable":"0","limit_rate":"2000"},"other_flood":{"enable":"0","limit_rate":"2000"}},"malformed_pkt":{"large_ping":{"enable":"0","limit_length":"4000"},"fraggle_atk":{"enable":"0"},"icmp_check":{"enable":"0"},"ip_check":{"enable":"0"}},"local_pkt_send":{"icmp_forbit":{"enable":"0","msg_type":[{"type":"11","code":"","enable":"0"}]},"icmpv6_forbit":{"enable":"0","msg_type":[{"type":"1","code":"","enable":"0"},{"type":"2","code":"","enable":"0"},{"type":"3","code":"","enable":"0"},{"type":"4","code":"","enable":"0"}]}},"session_safe":{"rate_limit":{"enable":"0","global_rate":"10000","record_rate":"200"}}}],"total":"1","flag":"1"}'

    local defValue = nil
    local ret = file_exist(defValueCfg)
    if (ret ~= nil) then
        content = file_read(defValueCfg)
        if (content ~= nil) then
            defValue = tonumber(content)
        end
    end
    
    local idx = 1
    if (defValue ~= nil) then
        local nfpp_content = cjson_safe.decode(def_cfg_str)
        if (nfpp_content ~= nil) then
            if (nfpp_content["list"][idx]["defend_ddos"]["syn_flood"] ~= nil) then
                syn_flood(nfpp_content["list"][idx]["defend_ddos"]["syn_flood"], defValue)
            end
        
            if (nfpp_content["list"][idx]["defend_ddos"]["udp_flood"] ~= nil) then
                udp_flood(nfpp_content["list"][idx]["defend_ddos"]["udp_flood"], defValue)
            end
        
            if (nfpp_content["list"][idx]["defend_ddos"]["arp_flood"] ~= nil) then
                arp_flood(nfpp_content["list"][idx]["defend_ddos"]["arp_flood"], defValue)
            end
     
            if (nfpp_content["list"][idx]["defend_ddos"]["icmp_flood"] ~= nil) then
                icmp_flood(nfpp_content["list"][idx]["defend_ddos"]["icmp_flood"], defValue)
            end

            if (nfpp_content["list"][idx]["defend_ddos"]["tcp_flood"] ~= nil) then
                tcp_flood(nfpp_content["list"][idx]["defend_ddos"]["tcp_flood"], defValue)
            end
     
            if (nfpp_content["list"][idx]["defend_ddos"]["other_flood"] ~= nil) then
                other_flood(nfpp_content["list"][idx]["defend_ddos"]["other_flood"], defValue)
            end
        
            def_cfg_str = cjson_safe.encode(nfpp_content)
        end
    end

    return def_cfg_str
end


return _M

-- test.lua:
-- package.path = "/usr/lib/lua/?.lua;" .. package.path;
-- local cjson = require "cjson"
-- local ctmngt = require("nfpp_manager")
-- ctmngt.set_nfpp_conntrack(300, 2000)
-- ctmngt.set_nfpp_bridge(100, 200)
-- local tab = ctmngt.get_nfpp_conntrack()
-- local jsonStr = cjson.encode(tab);
-- print(jsonStr)
-- local tab = ctmngt.get_nfpp_bridge()
-- local jsonStr = cjson.encode(tab);
-- print(jsonStr)