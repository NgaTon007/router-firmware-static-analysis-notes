-- app_route lua公共库
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("app_route.app_route_pub", package.seeall)

local cjson = require "luci.json"
local URL_ROUTE_JSON_CFG = "/etc/sd_config/single/urlRoute.json"

-- 函数名：check_del_uuids
-- 输入参数：[uuid1, uuid2, uuid3]
-- 返回值：{uuid1:0, uuid2:1, uuid3:0} 0表示无引用，1表示被引用
function check_del_uuids(uuid_list)
    local ret_table = {}

    if uuid_list == nil then
        return ret_table
    end

    -- 初始化返回值，Key为UUID，Value默认为0（无引用）
    for _, uuid in ipairs(uuid_list) do
        ret_table[uuid] = "0"
    end

    local file = io.open(URL_ROUTE_JSON_CFG, "r")
    if not file then
        return ret_table
    end

    local content = file:read("*all")
    file:close()

    if not content or content == "" then
        return ret_table
    end

    local json_info = cjson.decode(content)
    if json_info and json_info.policy then
        for _, policy in ipairs(json_info.policy) do
            local group = policy.itf_group
            -- 如果 itf_group 存在且在我们的 uuid 列表中
            if group and ret_table[group] ~= nil then
                ret_table[group] = "1"
            end
        end
    end

    return ret_table
end