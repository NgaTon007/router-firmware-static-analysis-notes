#!/usr/bin/lua
module("arp", package.seeall)

local curl = require "luacurl"
local json = require "luci.json"
local console = require "console"
local uci = require "luci.model.uci".cursor()
local _M = {}

local function http_request(url, data)
    local result = { }
    c = curl.new()
    c:setopt(curl.OPT_URL, url)
    c:setopt(curl.OPT_WRITEDATA, result)
    c:setopt(curl.OPT_POST, true);
    c:setopt(curl.OPT_POSTFIELDS, data);
    c:setopt(curl.OPT_SSL_VERIFYHOST, 0);
    c:setopt(curl.OPT_SSL_VERIFYPEER, false);
    c:setopt(curl.OPT_TIMEOUT, 3);
    c:setopt(curl.OPT_WRITEFUNCTION, function(tab, buffer)     --call back函数，必须有
        table.insert(result, buffer)                      --tab参数即为result，参考http://luacurl.luaforge.net/
        return #buffer
    end)
    local ok = c:perform()
    local http_code = c:getinfo(curl.INFO_RESPONSE_CODE);
    return ok, table.concat(result), http_code
end

local function get_auth_key(ip, pwd)
    local url = string.format("http://%s:20099/devConfig.php?a=login", ip)
    local data = {admin = "admin", password = pwd, encry = true}
    local auth = nil
    data = json.encode(data)
    local ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 and result_table.data then
                code = "200"
                auth = result_table.data.auth
            else
                --鉴权失败
                code = "401"
                --debug("get_auth_key:code 401")
            end
        else
            code = "401"
            --debug("get_auth_key:code 401")
        end
    else
        code = "401"
        --debug("get_auth_key:code 000")
    end
    return code, auth
end

function _M.do_Nbr_Api(params)
    local nbr_pwd = console.exec_cmd("cat /etc/sd_config/admin")
    local code, auth_key = get_auth_key(params.ip, nbr_pwd)
    if code ~= "200" then
        return {code = "-1", data = "认证失败"}
    end
    
    local url = string.format("http://%s:20099/getStatus.php?a=cliShow", params.ip)
    local data = {auth = auth_key, cmd = params.cmds}
    data = json.encode(data)
    local ok, result
    ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 then
                return result_table
            end
        end
    end
    return {code = "-1", data = "认证失败"}
end

return _M
