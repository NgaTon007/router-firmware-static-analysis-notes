#!/usr/bin/lua
module("luci.modules.switch", package.seeall)
require "luci.sys"
local json = require "luci.json"
local _M = {}

function checkTime(time)
    if type(time) == 'number' then
        return true
    end
    if type(time) == 'string' then
        return string.match(time, "^%d+$") -- 纯数字字符串
    end
    return false
end

function get_Md5(sn, ip, time)
    if checkTime(time) then
        -- local shell = "echo -n '" .. "x$x" .. time .. sn .. ip .. "' |md5sum|cut -d ' ' -f1"
        local shell = "echo -n '" .. time .. sn .. ip .. "' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1"
        return luci.sys.exec(shell)
    end
    return ""
end

-- 获取ip是否可达
function ipIsReach(params)
    -- local shell = "ping " .. params.ip .. " -q -c 1 -s 1 -w 1"
    -- local result = luci.sys.exec(shell)
    -- local _isReach = string.find(result, "1 packets received")
    -- if _isReach then
    --     return {isReach = true}
    -- else
    --     return {isReach = false}
    -- end
    return {isReach = luci.sys.net.pingtest(params.ip) == 0}
end

-- 参数拼接 (获取mactb 时暂时未使用到，后续获取sta等信息可能会需要使用)
function getParamsData(params)
    local _params = ""
    if type(params) == "table" then
        for k, v in pairs(params) do
            local _v = ""
            if type(v) == "table" then
                local _vv = ""
                for kk, vv in ipairs(v) do
                    if _vv ~= "" then
                        _vv = _vv .. "&" .. k .. "=" .. vv
                    else
                        _vv = k .. "=" .. vv
                    end
                end
                _v = _vv
            else
                _v = k .. "=" .. v
            end
            if _params ~= "" then
                _params = _params .. "&" .. _v
            else
                _params = _v
            end
        end
    else
        _params = params or ""
    end
    return _params
end

-- esw远程调用接口
function _M.do_Esw_Api(params)
    local time = os.time()
    local isPost = params.method == "post"
    local md5 = get_Md5(params.sn, params.ip, time)
    local connect_timeout = params.connect_timeout or 3
    local ttl_timeout = params.ttl_timeout or 10
    local hasParams = string.find(params.url, "?")
    if hasParams then
        params.url = params.url .. "&t=" .. time
    else
        params.url = params.url .. "?t=" .. time
    end
    --local isReach = ipIsReach(params)
    --if not isReach.isReach then
        --return {code = "-1", result = "地址不可达"}
    --end
    local shell = "curl -s 'http://" .. params.ip .. "/" .. params.url .. "' -H 'Authorization: " .. md5 .. "' -H 'Req-From: mobile'"
    if isPost then
        local _params = getParamsData(params.data)
        shell = shell .. ' -X POST -d  "' .. _params .. '"'
    else
        shell = shell .. " -X GET"
    end
    shell = shell .. " --connect-timeout " .. connect_timeout
    shell = shell .. " -m " .. ttl_timeout
    if params.async then
        local tool = require "luci.utils.tool"
        tool.forkExec(shell)
        return {code = "0", result = "操作成功"}
    else
        local result = luci.sys.exec(shell)
        if #result > 0 then
            if string.find(result, "<!DOCTYPE html>") then
                return {code = "-1", result = "认证失败"}
            else
                result_table = json.decode(result)
                return result_table
            end
        else 
            return {code = "0", result = "未收到返回结果"}
        end
    end
end

return _M
