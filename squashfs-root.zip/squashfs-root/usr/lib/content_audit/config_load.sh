#!/bin/sh
. /lib/functions.sh

config_content_usr() {
#  echo "call config_content_usr ......"
  local entry_name="$1"
  if [ -z "$entry_name" ]
  then
      return 0
  fi

  config_get mac_list $entry_name mac
  if [ "$mac_list" != "" ]; then
    echo "$mac_list" | xargs -n1 | while read value
    do
      cmd=`/usr/sbin/content_audit_cmd.elf -C --usr $entry_name --mac $value`
    done
  fi

  config_get ip_range $entry_name ip_range
  if [ -z "$ip_range" ]
  then
      return 0
  fi
  echo "$ip_range" | xargs -n1 | while read value
  do
  cmd=`/usr/sbin/content_audit_cmd.elf -C --usr $entry_name --ip-range $value`
  done
  
  
  #echo "usr_name:$entry_name, ip_range:$ip_range"
}

config_time_range() {
  #echo "call config_time_range ......"
  local entry_name="$1"
  if [ -z "$entry_name" ]
  then
      return 0
  fi
  
  config_get time $entry_name time
  #echo "time:$time"
  if [ -z "$time" ]
  then
      return 0
  fi
  
  echo "$time" | xargs -n1 | while read value
  do
  time_stop=${value##*-}
  value=${value%-*}
  time_start=${value##*-}
  weekdays=${value%-*}
  cmd=`/usr/sbin/content_audit_cmd.elf -C --time-range $entry_name -w $weekdays -b $time_start -e $time_stop`
  done
}

config_url_class() {
  #echo "call config_url_class ....."
  local entry_name="$1"
  if [ -z "$entry_name" ]
  then
      return 1
  fi
  cmd=`/usr/sbin/content_audit_cmd.elf -C --url-class $entry_name`
  
  config_get url  $entry_name url
  if [ -z "$url" ]
  then
      return 0
  fi
  echo "$url" | xargs -n1 | while read value
  do
  #value=${value##http://}
  #value=${value##www.}
  value=${value##\*.}
  cmd=`/usr/sbin/content_audit_cmd.elf -C --url-class $entry_name -u $value`
  done
   
  #echo "entry_name:$entry_name, url:$url"
}

config_url_object() {
  #echo "call config_url_object ....."
  local entry_name="$1"  
  if [ -z "$entry_name" ]
  then
      return 1
  fi
  cmd=`/usr/sbin/content_audit_cmd.elf -C --url-object $entry_name`
   
   
  config_get url_class  $entry_name url_class
  if [ -z "$url_class" ]
  then
       return 0
  fi
  echo "$url_class" | xargs -n1 | while read value
  do
  cmd=`/usr/sbin/content_audit_cmd.elf -C --url-object $entry_name -c $value`
  done
   
  #echo "entry_name:$entry_name, url_class:$url_class"
}

config_con_object() {  
  #echo "call config_con_object ....."
  local entry_name="$1"
  cmd=`/usr/sbin/content_audit_cmd.elf -C --content-object $entry_name`
  
  config_get key  $entry_name key
  if [ -z "$key" ]
  then
      return 0
  fi
  echo "$key" | xargs -n1 | while read value
  do
  cmd=`/usr/sbin/content_audit_cmd.elf -C --content-object $entry_name -k $value`
  done
   
  #echo "name:$entry_name, key:$key"
}

config_policy() {  
    # echo "call config_policy ....."
    local entry_name="$1"
    if [ -z "$entry_name" ]
    then
        return 1
    fi
    cmd=`/usr/sbin/content_audit_cmd.elf -C --content-policy $entry_name`
    
    config_get usr_name $entry_name usr_name
    if [ -z "$usr_name" ] 
    then
        usr_name="none"
    fi
    config_get usr_group $entry_name usr_group
    if [ -z "$usr_group" ] 
    then
        usr_group="none"
    fi
    
    if [ "$usr_group" == "none" ] && [ "$usr_name" == "none" ] 
    then
        return 1
    fi
    
    cmd=`/usr/sbin/content_audit_cmd.elf -C --content-policy-relate --relate -s $usr_name -u $usr_group -p $entry_name`
    # echo "policy_name: $entry_name, usr_name:$usr_name, usr_group:$usr_group"
    
    config_get default_audit $entry_name default_audit
    if [ -n "$default_audit" ] && [ "$default_audit" == "1" ]
    then
        cmd=`/usr/sbin/content_audit_cmd.elf -C -p $entry_name -i -e`
    fi
}

config_block_policy() {  
    # echo "call config_block_policy ....."
    local entry_name="$1"
    if [ -z "$entry_name" ]
    then
        return 1
    fi
    cmd=`/usr/sbin/content_audit_cmd.elf -C --content-policy $entry_name`
    
    config_get usr_name $entry_name usr_name
    if [ -z "$usr_name" ] 
    then
        usr_name="none"
    fi
    config_get usr_group $entry_name usr_group
    if [ -z "$usr_group" ] 
    then
        usr_group="none"
    fi
    
    if [ "$usr_group" == "none" ] && [ "$usr_name" == "none" ] 
    then
        return 1
    fi
    
    cmd=`/usr/sbin/content_audit_cmd.elf -C --content-policy-relate --relate -s $usr_name -u $usr_group -p $entry_name`
    # echo "policy_name: $entry_name, usr_name:$usr_name, usr_group:$usr_group"

    config_get default_audit $entry_name default_audit
    if [ -n "$default_audit" ] && [ "$default_audit" == "1" ]
    then
        cmd=`/usr/sbin/content_audit_cmd.elf -C -p $entry_name -i -e`
    fi
}

config_app_rule() {
  local cfg="$1"
  
  #echo "call config_app_rule ....."
  
  cmd="/usr/sbin/content_audit_cmd.elf -C"
  
  #enable
  config_get enable $cfg enable
  if [ -z "$enable" ] || [ "$enable" == "0" ]
  then
	  return 1
  fi
  
  #policy_name
  config_get policy_name $cfg policy_name
  if [ -z "$policy_name" ] 
  then
	  return 1
  fi
  cmd=${cmd}" --content-policy "$policy_name
  
  #rule_id
  config_get rule_id  $cfg rule_id
  if [ -z "$rule_id" ]
  then
      return 1
  fi
  cmd=${cmd}" -a="$rule_id
  
  #time_range
  config_get time_range  $cfg time_range
  if [ -z "$time_range" ]
  then
      return 1
  fi
  cmd=${cmd}" -t '$time_range'"
  
  #app_group
  config_get app_group  $cfg app_group
  if [ -z "$app_group" ]
  then 
	  return 1
  fi
  cmd=${cmd}" -g "$app_group
  
  #action
  config_get action  $cfg action
  if [ -z "$action" ] 
  then
      return 1
  fi
  cmd=${cmd}" -a "--$action
  
  #audit
  config_get audit  $cfg audit
  if [ -n "$audit" ]
  then
      cmd=${cmd}" --audit"
  fi
  
  #vpn
  config_get vpn  $cfg vpn
  if [ -n "$vpn" ]
  then
      cmd=${cmd}" --vpn"
  fi
  
  #vip
  config_get vip  $cfg vip
  if [ -n "$vip" ]
  then
      cmd=${cmd}" --vip"
  fi
  
  #comment
  config_get comment  $cfg comment
  if [ -n "$comment" ]
  then
      cmd=${cmd}" -c "$comment
  fi
  
  #echo "$cmd"
  ret=$(eval $cmd)
  
  return 0
}

config_block_app_rule() {
  local cfg="$1"
  
#   echo "call config_block_app_rule ....."
  
  cmd="/usr/sbin/content_audit_cmd.elf -C"
  
  #enable
  config_get enable $cfg enable
  if [ -z "$enable" ] || [ "$enable" == "0" ]
  then
	  return 1
  fi
  
  #policy_name
  config_get policy_name $cfg policy_name
  if [ -z "$policy_name" ] 
  then
	  return 1
  fi
  cmd=${cmd}" --content-policy "$policy_name
  
  #rule_id
  config_get rule_id  $cfg rule_id
  if [ -z "$rule_id" ]
  then
      return 1
  fi
  cmd=${cmd}" -a="$rule_id
  
  #time_range
  config_get time_range  $cfg time_range
  if [ -z "$time_range" ]
  then
      return 1
  fi
  cmd=${cmd}" -t '$time_range'"
  
  #app_group
  config_get app_group  $cfg app_group
  if [ -z "$app_group" ]
  then 
	  return 1
  fi
  cmd=${cmd}" -g "$app_group
  
  #action
  config_get action  $cfg action
  if [ -z "$action" ] 
  then
      return 1
  fi
  cmd=${cmd}" -a "--$action
  
  #audit
#   config_get audit  $cfg audit
#   if [ -n "$audit" ]
#   then
#       cmd=${cmd}" --audit"
#   fi
  
  #vpn
#   config_get vpn  $cfg vpn
#   if [ -n "$vpn" ]
#   then
#       cmd=${cmd}" --vpn"
#   fi
  
  #vip
#   config_get vip  $cfg vip
#   if [ -n "$vip" ]
#   then
#       cmd=${cmd}" --vip"
#   fi
  
  #comment
#   config_get comment  $cfg comment
#   if [ -n "$comment" ]
#   then
#       cmd=${cmd}" -c "$comment
#   fi
  
#   echo "$cmd"
  ret=$(eval $cmd)
  
  return 0
}

config_url_rule() {
  local cfg="$1"
  
  #echo "call config_url_rule ....."
  
  cmd="/usr/sbin/content_audit_cmd.elf -C"
  
  #enable
  config_get enable $cfg enable
  if [ -z "$enable" ] || [ "$enable" == "0" ]
  then
	  return 1
  fi
  
  #policy_name
  config_get policy_name $cfg policy_name
  if [ -z "$policy_name" ]
  then
	  return 1
  fi
  cmd=${cmd}" --content-policy "$policy_name
  
  #default_audit
  config_get default_audit  $cfg default_audit
  if [ -n "$default_audit" ] && [ $default_audit == "true" ]
  then
	cmd=${cmd}" --url-rule --audit-default-enable"
    #echo "$cmd"
	ret=$(eval $cmd)
	return 0
  fi
  
  #rule_id
  config_get rule_id  $cfg rule_id
  if [ -z "$rule_id" ]
  then
      return 1
  fi
  cmd=${cmd}" -u="$rule_id
  
  #tiem_range
  config_get time_range  $cfg time_range
  if [ -z "$time_range" ]
  then
      return 1
  fi
  cmd=${cmd}" -t '$time_range'"
  
  #url_object
  config_get url_object  $cfg url_object
  if [ -z "$url_object" ]
  then
      return 1
  fi
  cmd=${cmd}" -o "$url_object
  
  #action
  config_get action  $cfg action
  if [ -z "$action" ]
  then
     return 1
  fi
  cmd=${cmd}" -a "--$action
  
  #audit
  config_get audit  $cfg audit
  if [ -n "$audit" ]
  then
      cmd=${cmd}" --audit"
  fi
  
  #comment
  config_get comment  $cfg comment
  if [ -n "$comment" ]
  then
     cmd=${cmd}" -c "$comment
  fi
  
  #echo "$cmd"
  ret=$(eval $cmd)
  
  return 0
}

config_im_rule() {
  local cfg="$1"
  
  #echo "call config_im_rule ....."
  
  cmd="/usr/sbin/content_audit_cmd.elf -C"
  
  #enable
  config_get enable $cfg enable
  if [ -z "$enable" ] || [ "$enable" == "0" ]
  then
	  return 1
  fi
  
  #policy_name
  config_get policy_name $cfg policy_name
  if [ -z "$policy_name" ]
  then
      return 1
  fi
  cmd=${cmd}" --content-policy "$policy_name
  
  #rule_id
  config_get rule_id  $cfg rule_id
  if [ -z "$rule_id" ]
  then
      return 1
  fi
  cmd=${cmd}" -i="$rule_id
  
  #time_range
  config_get time_range  $cfg time_range
  if [ -z "$time_range" ]
  then
      return 1
  fi
  cmd=${cmd}" -t '$time_range'"
  
  #im_type
  config_get im_type  $cfg im_type
  if [ -z "$im_type" ]
  then
     return 1
  fi
  cmd=${cmd}" -e "$im_type
  
  #relation
  config_get relation  $cfg relation
  if [ -n "$relation" ]
  then
     cmd=${cmd}" -l "--$relation
	 
	 #account
	 config_get account  $cfg account
	 if [ -n "$account" ]
	 then
	    cmd=${cmd}" -o "$account
	 fi
	 
	 #message
	 config_get message  $cfg message
	 if [ -n "$message" ]
	 then
	    cmd=${cmd}" -m "$message
	 fi
  fi
	 
  #action
  config_get action  $cfg action
  if [ -z "$action" ]
  then
      return 1
  fi
  cmd=${cmd}" -i "--$action
  
  #audit
  config_get audit  $cfg audit
  if [ -n "$audit" ]
  then
     cmd=${cmd}" --audit"
  fi
  
  #comment
  config_get comment  $cfg comment
  if [ -n "$comment" ]
  then
      cmd=${cmd}" -c "$comment
  fi
  
  #echo "$cmd"
  ret=$(eval $cmd)
  
  return 0
}

/usr/bin/lua /usr/sbin/ca_url_list_sync.lua 'load'
config_load content_audit
config_foreach config_content_usr content_usr
#config_foreach config_time_range time_range
config_foreach config_url_object url_object
config_foreach config_con_object content_object
config_foreach config_block_policy block_policy
config_foreach config_policy policy
config_foreach config_block_app_rule block_app_rule
config_foreach config_app_rule app_rule
config_foreach config_url_rule url_rule
config_foreach config_im_rule im_rule

config_get enable content_audit enable
if [ -z "$enable" ]
then
	return 0
fi
if [ "$enable" == "1" ]
then
	`/usr/sbin/content_audit_cmd.elf -E -y`
else
	`/usr/sbin/content_audit_cmd.elf -E -n`
fi

