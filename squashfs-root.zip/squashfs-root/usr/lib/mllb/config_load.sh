#!/bin/sh
. /lib/functions.sh

[ -x /tmp/mwan_quota4 ] || mkdir /tmp/mwan_quota4 &> /dev/null
[ -x /tmp/mwan_quota4/mwan_quota4 ] || touch /tmp/mwan_quota4/mwan_quota4
[ -x /tmp/mwan_quota6 ] || mkdir /tmp/mwan_quota6 &> /dev/null
[ -x /tmp/mwan_quota6/mwan_quota6 ] || touch /tmp/mwan_quota6/mwan_quota6

UCIv4="uci -c /tmp/mwan_quota4/"
UCIv6="uci -c /tmp/mwan_quota6/"
log_file="/tmp/mwanQuota.log"
log_file_size=12        # 日志文件大小, 单位KB;

config_load_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    local file_size

    if [ -e "$log_file" ]; then
        file_size=$(du -shk "$log_file" | awk '{print $1}' | tr -d ' \n\t')
    else
        file_size=0
    fi

    [ "$file_size" -gt "$log_file_size" ] && {
        mv -f "$log_file" "${log_file}.old"
    }

    echo -e "${cur_time} ${1}" >> "$log_file"
}

SESSION_COUNT_DISABLED=0
SESSION_COUNT_MIN=100
SESSION_COUNT_MAX=1000000
MWAN_LOAD_SESSION_ENABLE=0

# is_sub_intf - 判断接口名是否为子接口（wan[0-9]*_[0-9]+）
is_sub_intf() {
    echo "$1" | grep -qE '^wan[0-9]*_[0-9]+$'
}

# intf_grp_uuid_valid - 校验接口组UUID字符串合法性（防命令注入）
# 双重校验: 字符白名单 [a-z0-9_] + 结构(已知固定前缀 + 至少一位纯数字 + 结尾)
# 返回: 0=合法, 1=非法
intf_grp_uuid_valid() {
    local uuid="$1"
    [ -z "$uuid" ] && return 1
    # 字符白名单: 仅允许 [a-z0-9_]，拒绝所有 shell 元字符
    case "$uuid" in
        *[!a-z0-9_]*) return 1 ;;
    esac
    # 结构校验: 已知固定前缀 + 至少一位纯数字 + 字符串结尾
    echo "$uuid" | grep -qE '^(cloud_|web_|app_|ar_intf_|pbr_intf_group_|pbr6_intf_group_)[0-9]+$' || return 1
    return 0
}

pbr_rule_add() {
    local cfg="$1"
    local cfg_version="$2"
    # cfg_name 为 UCI 配置文件名(policy_route/policy_routev6)，由调用方传入。
    # 因为 _sec 来自 uci show，格式为 @rule[0]，含特殊字符，config_get 内部
    # 会将其拼为 CONFIG_@rule[0]_xxx 这样的非法 shell 变量名导致报错退出。
    # 改用 uci get 直接读取，完全规避该问题。
    local cfg_name="$3"
    local _u="${cfg_name}.${cfg}"

    cmd="/usr/sbin/mllb_cmd.elf -C $cfg_version"

    #enable
    enable="$(uci get "${_u}.enable" 2>/dev/null)"
    if [ -z "$enable" ] || [ "$enable" == "off" ]
    then
        return 1
    fi

    # name 使用自动编号(从1起), 避免直接嵌入用户输入的规则名称导致命令注入
    cmd=${cmd}" --name "$((pbr_rule_num + 1))

    #proto
    proto="$(uci get "${_u}.proto" 2>/dev/null)"
    if [ -z "$proto" ]
    then
        return 1
    fi
    if [ "$proto" == "udef_proto" ]
    then
        #udef_proto 协议号1-255
        udef_proto="$(uci get "${_u}.udef_proto" 2>/dev/null)"
        if [ -z "$udef_proto" ]
        then
            return 1
        fi
        cmd=${cmd}" --proto "$udef_proto"u"
    elif [ "$proto" == "ip" ]; then
        # ip则包含所有的协议号，统一用256标识（无256协议号）
        cmd=${cmd}" --proto 256"
    elif [ "$proto" == "tcp" ]; then
        cmd=${cmd}" --proto 6"
    elif [ "$proto" == "udp" ]; then
        cmd=${cmd}" --proto 17"
    elif [ "$proto" == "icmp" ]; then
        cmd=${cmd}" --proto 1"
    elif [ "$proto" == "icmpv6" ]; then
        cmd=${cmd}" --proto 1"
    else
        return 1
    fi

    if [ "$proto" == "tcp" ] || [ "$proto" == "udp" ]
    then
        #sport dport 端口号1-65535
        sport="$(uci get "${_u}.sport" 2>/dev/null)"
        dport="$(uci get "${_u}.dport" 2>/dev/null)"
        if [ -z "$sport" ] || [ -z "$dport" ]
        then
            return 1
        fi
        cmd=${cmd}" --sport "$sport
        cmd=${cmd}" --dport "$dport
    fi

    #sip
    sip="$(uci get "${_u}.sip" 2>/dev/null)"
    if [ -z "$sip" ]
    then
        return 1
    fi

    if [ "$sip" == "udef_src" ]
    then
        #sipRange
        sipRange="$(uci get "${_u}.sipRange" 2>/dev/null)"
        if [ -z "$sipRange" ]
        then
            return 1
        fi
        cmd=${cmd}" --sip "$sipRange
    elif [ "$sip" == "all" ]; then
        cmd=${cmd}" --sip "$sip
    else
        return 1
    fi

    #dip
    dip="$(uci get "${_u}.dip" 2>/dev/null)"
    if [ -z "$dip" ]
    then
        return 1
    fi
    if [ "$dip" == "udef_dst" ]
    then
        #dipRange
        dipRange="$(uci get "${_u}.dipRange" 2>/dev/null)"
        if [ -z "$dipRange" ]
        then
            return 1
        fi
        cmd=${cmd}" --dip "$dipRange
    elif [ "$dip" == "country_dst" ]; then
        #dipCountry
        dipCountry="$(uci get "${_u}.dipCountry" 2>/dev/null)"
        if [ -z "$dipCountry" ]
        then
            return 1
        fi
        cmd=${cmd}" --dip "$dipCountry
    elif [ "$dip" == "all" ]; then
        cmd=${cmd}" --dip "$dip
    else
        return 1
    fi

    #intf_switch 接口断网保障开关
    intf_switch="$(uci get "${_u}.intf_switch" 2>/dev/null)"
    if [ -z "$intf_switch" ]
    then
        intf_switch="true"
    fi
    cmd=${cmd}" --intf-switch "$intf_switch

    #intf
    intf="$(uci get "${_u}.intf" 2>/dev/null)"
    if [ -z "$intf" ]; then
        intf="$(uci get "${_u}.sub_intf" 2>/dev/null)"
    fi

    # 接口组支持: auto/user类型使用intfGrpUuid作为--intf参数, single类型使用intf字段
    local intfGrpType intfGrpUuid
    intfGrpType="$(uci get "${_u}.intfGrpType" 2>/dev/null)"
    if [ "$intfGrpType" = "auto" ] || [ "$intfGrpType" = "user" ]; then
        intfGrpUuid="$(uci get "${_u}.intfGrpUuid" 2>/dev/null)"
        # intfGrpUuid 会嵌入 cmd 字符串后经 backtick 执行，必须严格校验防命令注入
        if ! intf_grp_uuid_valid "$intfGrpUuid"; then
            return 1
        fi
        cmd=${cmd}" --intf "${intfGrpUuid:-$intf}
        cmd=${cmd}" --intf-grp-type "$intfGrpType
        # auto成员已通过pbr_auto_grp_preload预加载, user由C层查询intfGroup框架
    # elif [ -n "$intfGrpType" ]; then
    #     cmd=${cmd}" --intf "$intf
    #     cmd=${cmd}" --intf-grp-type "$intfGrpType
    else
        if [ -z "$intf" ]
        then
            return 1
        fi
        cmd=${cmd}" --intf "$intf
    fi

    cmd=${cmd}" --pref "$pbr_rule_num
    # echo "$cmd"
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 11 --proto 55 --sip 1.1.1.1-3.3.3.3 --dip 3.3.3.3-5.5.5.5 --intf-switch false --intf wan1 --pref 0
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 10 --proto 256 --sip all --dip all --intf-switch false --intf wan1 --pref 1
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 8 --proto 256 --sip all --dip 2.3.3.3-6.6.6.6 --intf-switch true --intf wan --pref 2
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 7 --proto 256 --sip all --dip 1.1.1.1 --intf-switch true --intf wan --pref 3
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 6 --proto 256 --sip 2.2.2.2-3.3.3.3 --dip all --intf-switch true --intf wan --pref 4
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 5 --proto 256 --sip 1.1.1.1 --dip all --intf-switch true --intf wan --pref 5
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 4 --proto 17 --sport 1:222 --dport 2:111 --sip all --dip all --intf-switch true --intf wan --pref 6
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 3 --proto 6 --sport 1:111 --dport 2:222 --sip all --dip all --intf-switch true --intf wan --pref 7
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 2 --proto 1 --sip all --dip all --intf-switch true --intf wan --pref 8 
    # /usr/sbin/mllb_cmd.elf -C --policy-route --name 1 --proto 256 --sip all --dip all --intf-switch true --intf wan --pref 9
    ret=`$cmd`
    pbr_rule_num=$((pbr_rule_num+1))
    
    return 0
}

pbr_preloaded_uuids=""

pbr_auto_grp_preload()
{
    local cfg="$1"
    local cfg_version="$2"

    local intfGrpType
    config_get intfGrpType $cfg intfGrpType
    [ "$intfGrpType" != "auto" ] && return 0

    local intfGrpUuid
    config_get intfGrpUuid $cfg intfGrpUuid
    [ -z "$intfGrpUuid" ] && return 0
    # 直接传入可执行文件，虽已双引号保护，仍提前校验避免无效操作
    intf_grp_uuid_valid "$intfGrpUuid" || return 0

    local intfGrpList
    config_get intfGrpList $cfg intfGrpList
    [ -z "$intfGrpList" ] && return 0

    # 去重: 同一UUID只预加载一次
    echo "$pbr_preloaded_uuids" | grep -qw "$intfGrpUuid" && return 0
    pbr_preloaded_uuids="$pbr_preloaded_uuids $intfGrpUuid"

    # 分批预加载, 每批不超过240字节
    local BATCH_MAX=240
    local batch="" batch_len=0
    for mem in $intfGrpList; do
        local mem_len=${#mem}
        if [ $batch_len -gt 0 ] && [ $((batch_len + mem_len + 1)) -gt $BATCH_MAX ]; then
            /usr/sbin/mllb_cmd.elf -C $cfg_version --intf-grp-preload "$intfGrpUuid" --intf-grp-list "$batch"
            batch=""
            batch_len=0
        fi
        if [ $batch_len -gt 0 ]; then
            batch="$batch $mem"
            batch_len=$((batch_len + mem_len + 1))
        else
            batch="$mem"
            batch_len=$mem_len
        fi
    done
    # 最后一批带 --intf-grp-list-done 标志
    if [ $batch_len -gt 0 ]; then
        /usr/sbin/mllb_cmd.elf -C $cfg_version --intf-grp-preload "$intfGrpUuid" --intf-grp-list "$batch" --intf-grp-list-done
    fi
}

pbr_config_add()
{
    #echo "call pbr_config_add ....."
    local cfg_version country_num
    local ip_version="$1"
    if [ "$ip_version" == "4" ]; then
        cfg_version="--policy-route"
    else
        cfg_version="--policy-routev6"
    fi

    # 预加载 new_rule 中的 auto 接口组成员(去重, 分批)
    # rule 类型包含单个主接口和虚拟口，无接口组规则，无需预加载
    pbr_preloaded_uuids=""
    config_foreach pbr_auto_grp_preload new_rule $cfg_version

    pbr_rule_num=0
    # 按 UCI 文件实际顺序加载 rule/new_rule，保证 --pref 与存储位置（优先级）严格一致
    # 分类型 config_foreach 会导致所有 rule 先于 new_rule 加载，破坏跨类型的全局优先级顺序
    local _pbr_cfg_name
    if [ "$ip_version" == "4" ]; then
        _pbr_cfg_name="policy_route"
    else
        _pbr_cfg_name="policy_routev6"
    fi
    for _sec in $(uci show "$_pbr_cfg_name" 2>/dev/null | \
        grep -E "^${_pbr_cfg_name}\.[^.=]+=(rule|new_rule)$" | \
        sed "s/^${_pbr_cfg_name}\\.\\([^.=]*\\)=.*/\\1/"); do
        pbr_rule_add "$_sec" "$cfg_version" "$_pbr_cfg_name"
    done

    if [ "$ip_version" == "4" ]; then
        # 是否需要加载库
        country_num="$(cat /etc/config/policy_route |grep "country_dst"|wc -l)"
        if [ -z "$country_num" ] || [ "$country_num" == "0" ]
        then
            cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --country_flag 0"
        else
            cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --country_flag 1"
        fi
        ret=`$cmd_main`
    fi

    cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --number $pbr_rule_num"
    # echo "$cmd_main"
    # /usr/sbin/mllb_cmd.elf -C --policy-route --number 5
    ret=`$cmd_main`
    
    return 0
}

url_config_add()
{
    #echo "call url_config_add ....."
    local cfg_version
    local ip_version="$1"
    if [ "$ip_version" == "4" ]; then
        cfg_version="--url-route"
    else
        cfg_version="--url-routev6"
    fi

    [ -f /etc/sd_config/single/urlRoute.json ] || return 0
    url_rule_num="$(cat /etc/sd_config/single/urlRoute.json |jq .policy[].enable|grep 1|wc -l)"

    cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --number $url_rule_num"
    # echo "$cmd_main"
    # /usr/sbin/mllb_cmd.elf -C --url-route --number 5
    ret=`$cmd_main`

    # 提取接口组UUID列表并分批传给mllb进程 (msg->param最大256字节，安全限制240)
    local itf_group_uuids
    itf_group_uuids=$(cat /etc/sd_config/single/urlRoute.json 2>/dev/null | \
        jq -r '.policy[].itf_group // empty | select(length > 0)' 2>/dev/null | \
        sort -u | tr '\n' ' ' | sed 's/ $//')
    if [ -n "$itf_group_uuids" ]; then
        local BATCH_MAX=240
        local batch="" batch_len=0
        local uuid uuid_len
        for uuid in $itf_group_uuids; do
            # 校验每个UUID格式合法性，过滤非法值防命令注入
            intf_grp_uuid_valid "$uuid" || continue
            uuid_len=${#uuid}
            # 当前批次加上新uuid超限，先发送当前批次
            if [ $batch_len -gt 0 ] && [ $((batch_len + uuid_len + 1)) -gt $BATCH_MAX ]; then
                /usr/sbin/mllb_cmd.elf -C $cfg_version --url-intf-grp "$batch"
                batch=""
                batch_len=0
            fi
            if [ $batch_len -gt 0 ]; then
                batch="$batch $uuid"
                batch_len=$((batch_len + uuid_len + 1))
            else
                batch="$uuid"
                batch_len=$uuid_len
            fi
        done
        # 最后一批带done标记，触发一次性内核同步
        if [ $batch_len -gt 0 ]; then
            /usr/sbin/mllb_cmd.elf -C $cfg_version --url-intf-grp "$batch" --url-intf-grp-done
        else
            /usr/sbin/mllb_cmd.elf -C $cfg_version --url-intf-grp-done
        fi
    else
        # 没有任何策略引用接口组（全部策略已删除或不含接口组），
        # 仍需发送 DONE 触发 cleanup_unseen，清理上轮残留的 auto/user 接口组
        /usr/sbin/mllb_cmd.elf -C $cfg_version --url-intf-grp-done
    fi

    return 0
}

db_interface_add()
{
    local cfg="$1"
    #echo "call db_interface_add ....."
    
    cmd="/usr/sbin/mllb_cmd.elf -C --route-db"
    
    cmd=${cmd}" --interface "$cfg
    #isp
    config_get isp $cfg isp
    if [ -z "$isp" ] 
    then
        return 1
    fi
    cmd=${cmd}" --isp "$isp

    # #old_isp
    # config_get old_isp $cfg old_isp
    # if [ -z "$old_isp" ] 
    # then
    #     return 1
    # fi
    # cmd=${cmd}" --old_isp "$old_isp

    # echo "$cmd"
    # /usr/sbin/mllb_cmd.elf -C --route-db --interface wan1 --isp cnc --old_isp cnc
    ret=`$cmd`
    return 0
}

db_config_add()
{
    #echo "call db_config_add ....."

    config_get enable "set" enable
    int_num="$(cat /etc/config/route_db |grep -E "config (interface|sub_intf)"|wc -l)"
    if [ -z "$int_num" ] || [ "$int_num" == "0" ]
    then
        return 1
    fi
    cmd_main="/usr/sbin/mllb_cmd.elf -C --route-db --enable $enable --intf-num $int_num"
    # echo "$cmd_main"
    # /usr/sbin/mllb_cmd.elf -C --route-db --enable 0 --intf-num 2
    ret=`$cmd_main`

    if [ "$enable" == "1" ]
    then
        config_foreach db_interface_add interface
        config_foreach db_interface_add sub_intf
    fi

    return 0
}

special_line_intf_add()
{
    local interface="$1"

    if [ -z "$interface" ] 
    then
        return 1
    fi
    cmd="/usr/sbin/mllb_cmd.elf -C --network --intf $interface"
    if [ $(uci get network.$interface.special_line) == "1" ]; then
        cmd=${cmd}" --special-line"
    fi
    # echo "$cmd"
    sl_intf_num=$((sl_intf_num+1))
    ret=`$cmd`

    return 0
}

special_line_config_add()
{
    local sl_intf_num=0
    config_foreach special_line_intf_add interface
    # config_foreach special_line_intf_add sub_intf 目前无专项配置项，暂不处理

    cmd="/usr/sbin/mllb_cmd.elf -C --network --intf-num $sl_intf_num"
    # echo "$cmd"
    ret=`$cmd`
    return 0
}

mwan_member_add()
{
    local cfg="$1"
    local cfg_version="$2"

    #echo "call mwan_member_add ....."

    cmd="/usr/sbin/mllb_cmd.elf -C $cfg_version"

    #interface
    config_get interface $cfg interface
    if [ -z "$interface" ] 
    then
        return 1
    fi
    cmd=${cmd}" --interface "$interface

    #metric
    config_get metric $cfg metric
    if [ -z "$metric" ] 
    then
        return 1
    fi
    cmd=${cmd}" --metric "$metric

    config_load_log "mode:$mode"
    config_load_log "cfg_version:$cfg_version"
    if [ "$cfg_version" == "--mwan" ]
    then
        if is_sub_intf "$interface"; then
            $UCIv4 -q set mwan_quota4.$interface=sub_intf
        else
            $UCIv4 -q set mwan_quota4.$interface=interface
        fi
        $UCIv4 commit mwan_quota4
        
    else
        if is_sub_intf "$interface"; then
            $UCIv6 -q set mwan_quota6.$interface=sub_intf
        else
            $UCIv6 -q set mwan_quota6.$interface=interface
        fi
        $UCIv6 commit mwan_quota6
    fi

    if [ "$mode" != "load" ]
    then
        #weight
        config_get weight $cfg weight
        if [ -z "$weight" ] 
        then
            return 1
        fi
        config_load_log "weight:$weight"

        #adjustBalance
        config_get adjustBalance punish_$interface adjustBalance
        if [ -n "$adjustBalance" ] 
        then
            config_load_log "adjustBalance:$adjustBalance"
            new_weight=$((weight * adjustBalance))
            if [ $new_weight -gt 1000000 ]
            then 
                new_weight=1000000
                cmd=${cmd}" --weight "$new_weight
            else
                cmd=${cmd}" --weight "$new_weight
            fi
            if [ "$cfg_version" == "--mwan" ]
            then
                $UCIv4 -q set mwan_quota4.$interface.session_weight=$new_weight
                $UCIv4 commit mwan_quota4
            else
                $UCIv6 -q set mwan_quota6.$interface.session_weight=$new_weight
                $UCIv6 commit mwan_quota6
            fi
        else
            config_get session_weight punish_$interface session_weight
            config_load_log "session_weight:$session_weight"
            if [ -n "$session_weight" ] 
            then
                new_weight=$((weight * session_weight))
                if [ $new_weight -gt 1000000 ]
                then 
                    new_weight=1000000
                    cmd=${cmd}" --weight "$new_weight
                else
                    cmd=${cmd}" --weight "$new_weight
                fi
                if [ "$cfg_version" == "--mwan" ]
                then
                    $UCIv4 -q set mwan_quota4.$interface.session_weight=$new_weight
                    $UCIv4 commit mwan_quota4
                else
                    $UCIv6 -q set mwan_quota6.$interface.session_weight=$new_weight
                    $UCIv6 commit mwan_quota6
                fi
            else
                cmd=${cmd}" --weight "$weight
                if [ "$cfg_version" == "--mwan" ]
                then
                    $UCIv4 -q set mwan_quota4.$interface.session_weight=$((weight * 100))
                    $UCIv4 commit mwan_quota4
                else
                    $UCIv6 -q set mwan_quota6.$interface.session_weight=$((weight * 100))
                    $UCIv6 commit mwan_quota6
                fi
            fi
       fi
       config_load_log "cmd:$cmd"
    else
        #band_up
        config_get band_up $interface band_up
        if [ -z "$band_up" ] 
        then
            return 1
        fi

        #adjustBalance
        config_get adjustBalance punish_$interface adjustBalance
        if [ -n "$adjustBalance" ] 
        then
            result=$((adjustBalance * band_up / 100))
            remainder=$(( (adjustBalance * band_up) % 100 ))
            if [ "$remainder" -ne 0 ]; then
                #有小数,向上取整并加1
                new_band_up=$((result + 1))
            else
                #没有小数,直接使用计算结果
                new_band_up=$result
            fi
            cmd=${cmd}" --band-up "$new_band_up
            config_load_log "new_band_up:$new_band_up"
            if [ "$cfg_version" == "--mwan" ]
            then
                $UCIv4 -q set mwan_quota4.$interface.new_band_up=$new_band_up
                $UCIv4 commit mwan_quota4
            else
                $UCIv6 -q set mwan_quota6.$interface.new_band_up=$new_band_up
                $UCIv6 commit mwan_quota6
            fi
        else
            cmd=${cmd}" --band-up "$band_up
            if [ "$cfg_version" == "--mwan" ]
            then
                $UCIv4 -q set mwan_quota4.$interface.new_band_up=$band_up
                $UCIv4 commit mwan_quota4
            else
                $UCIv6 -q set mwan_quota6.$interface.new_band_up=$band_up
                $UCIv6 commit mwan_quota6
            fi
        fi

        #band_down
        config_get band_down $interface band_down
        if [ -z "$band_down" ] 
        then
            return 1
        fi

        if [ -n "$adjustBalance" ] 
        then
            result=$((adjustBalance * band_down / 100))
            remainder=$(( (adjustBalance * band_down) % 100 ))
            if [ "$remainder" -ne 0 ]; then
                #有小数,向上取整并加1
                new_band_down=$((result + 1))
            else
                #没有小数,直接使用计算结果
                new_band_down=$result
            fi
            cmd=${cmd}" --band-down "$new_band_down
            config_load_log "new_band_down:$new_band_down"
            if [ "$cfg_version" == "--mwan" ]
            then
                $UCIv4 -q set mwan_quota4.$interface.new_band_down=$new_band_down
                $UCIv4 commit mwan_quota4
            else
                $UCIv6 -q set mwan_quota6.$interface.new_band_down=$new_band_down
                $UCIv6 commit mwan_quota6
            fi
        else
            cmd=${cmd}" --band-down "$band_down
            if [ "$cfg_version" == "--mwan" ]
            then
                $UCIv4 -q set mwan_quota4.$interface.new_band_down=$band_down
                $UCIv4 commit mwan_quota4
            else
                $UCIv6 -q set mwan_quota6.$interface.new_band_down=$band_down
                $UCIv6 commit mwan_quota6
            fi
        fi
        config_load_log "cmd:$cmd"

        #这边是load模式下了
        if [ "$cfg_version" == "--mwan" ]
        then
            session_value=$SESSION_COUNT_DISABLED
            if [ "$MWAN_LOAD_SESSION_ENABLE" -eq 1 ]
            then
                config_get session $interface session
                if [ -n "$session" ]
                then
                    case "$session" in
                        (*[!0-9]*)
                            config_load_log "session_invalid:$interface:$session"
                            session_value=$SESSION_COUNT_DISABLED
                        ;;
                        (*)
                            session_value=$session
                            if [ "$session_value" -gt "$SESSION_COUNT_MAX" ]
                            then
                                config_load_log "session_out_of_range:$interface:$session_value"
                                session_value=$SESSION_COUNT_DISABLED
                            elif [ "$session_value" -gt "$SESSION_COUNT_DISABLED" ] && [ "$session_value" -lt "$SESSION_COUNT_MIN" ]
                            then
                                config_load_log "session_out_of_range:$interface:$session_value"
                                session_value=$SESSION_COUNT_DISABLED
                            fi
                        ;;
                    esac
                fi
            fi
            cmd=${cmd}" --session "$session_value
        fi
    fi

    # echo "mwan member:$cmd"
    # /usr/sbin/mllb_cmd.elf -C --mwan --interface wan --metric 1 --band-up 1000 --band-down 1000 --session 1000
    # /usr/sbin/mllb_cmd.elf -C --mwan --interface wan --metric 1 --weight 1
    ret=`$cmd`

    return 0
}

mwan_config_notice_blockIntf()
{
    local interface="$1"
    local cmd="/usr/sbin/mllb_cmd.elf -C --block "

    cmd=${cmd}" --interface "$interface

    # 获取配置中的 blockIntf
    config_get blockIntf "punish_$interface" "blockIntf"

    # 全量对齐模型：以接口为驱动反向收敛内核 xt_mwan_quota[]。
    #   blockIntf=1                    -> 下发 --blockIntf 1
    #   blockIntf 为 0/空/punish 段缺失 -> 下发 --blockIntf 0
    # 这样即使 UCI 中的 punish_<intf> 段已被 mwanQuota_set 删除，
    # 本次 reload 仍会主动清除内核中残留的阻断标记，避免出现
    # "UCI 已无 punish 但内核仍残留 block_discon=1" 的状态错位。
    # mllb 用户态 mwan_quota_set_by_intf_id() 对"未找到 intf_id"是幂等的，
    # 重复下发 --blockIntf 0 无副作用。
    if [ "$blockIntf" = "1" ]; then
        cmd=${cmd}" --blockIntf 1"
    else
        cmd=${cmd}" --blockIntf 0"
    fi
    #执行命令
    #/usr/sbin/mllb_cmd.elf -C --block  --interface wan1 --blockIntf 1
    ret=`$cmd`
    config_load_log "block cmd:$cmd"
}

# mllb_capacity_set - 读取设备能力值并写入守护进程运行时上限
# 在 "all" 初始化路径首先执行(进程启动后只需一次)
# JSON key 说明:
#   wan_number      - WAN口最大数量
#   subwan_max - 子接口最大数量
#   pbr_number      - PBR v4 接口组容量
#   pbr_number     - PBR v6 接口组容量
#   url_grp_number  - URL路由接口组容量
#   user_grp_number - 用户自定义接口组容量
mllb_capacity_set()
{
    local web_node=$(product capacity.web)
    local DEVINFO_JSON=/tmp/sd_device/sd_device.json

    if [ ! -f "$DEVINFO_JSON" ]; then
        return
    fi

    local wan_max=$(jq -r .eth_port.wan_number $DEVINFO_JSON 2>/dev/null)
    local sub_max=$(jq -r .${web_node}.subwan_max $DEVINFO_JSON 2>/dev/null)
    local pbr_grp=$(jq -r .gateway.pbr_number $DEVINFO_JSON 2>/dev/null)
    local pbr6_grp=$pbr_grp
    local url_grp=30  # URL路由接口组容量固定30，来源于产品设计预留值
    local user_grp=$(jq -r .gateway.intf_group_num $DEVINFO_JSON 2>/dev/null)

    # 能力值读取失败则跳过
    if [ -z "$wan_max" ] || [ -z "$sub_max" ] || [ -z "$pbr_grp" ] || [ -z "$user_grp" ]; then
        return
    fi

    # 接口组总上限 = PBR_v4 + PBR_v6 + URL + user
    local intf_grp_max=$(( ${pbr_grp:-0} + ${pbr6_grp:-0} + ${url_grp:-0} + ${user_grp:-0} ))
    [ "$intf_grp_max" -le 0 ] && return

    /usr/sbin/mllb_cmd.elf -C --capacity \
        --wan-max "$wan_max" \
        --sub-max "$sub_max" \
        --intf-grp-max "$intf_grp_max"
}

mwan_config_blockIntf()
{
    config_foreach mwan_config_notice_blockIntf interface
    config_foreach mwan_config_notice_blockIntf sub_intf
}

mwan_config_add()
{
    #echo "call mwan_config_add ....."
    local cfg_version
    local web_node=$(product capacity.web)
    local backup_discon=$(jq -r .${web_node}.mllb_backup_discon /tmp/sd_device/sd_device.json)
    local ip_version="$1"
    if [ "$ip_version" == "4" ]; then
        cfg_version="--mwan"
    else
        cfg_version="--mwanv6"
    fi
    config_get enabled "wan" enabled
    config_get mode "balanced" mode
    config_get backup_discon_value "balanced" backup_discon 0
    if [ "$ip_version" == "4" ]; then
        int_num="$(cat /etc/config/mwan3|grep -E "config (interface|sub_intf)"|wc -l)"
    else
        int_num="$(cat /etc/config/mwan3v6|grep -E "config (interface|sub_intf)"|wc -l)"
    fi
    if [ -z "$int_num" ] || [ "$int_num" == "0" ]
    then
        return 1
    fi
    if [ "$ip_version" == "4" ]; then
        config_get load_session_enable_cfg "balanced" loadSessionEnable 0
        if [ "$mode" == "load" ] && [ "$load_session_enable_cfg" == "1" ]; then
            MWAN_LOAD_SESSION_ENABLE=1
        else
            MWAN_LOAD_SESSION_ENABLE=0
        fi
        if [ "$backup_discon" == "1" ]; then
            cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --enable $enabled --mode $mode --intf-num $int_num --load-session-enable $MWAN_LOAD_SESSION_ENABLE --backup-discon $backup_discon_value"
        else
            cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --enable $enabled --mode $mode --intf-num $int_num --load-session-enable $MWAN_LOAD_SESSION_ENABLE"
        fi
    else
        MWAN_LOAD_SESSION_ENABLE=0
        # v6无相关配置，不加载
        cmd_main="/usr/sbin/mllb_cmd.elf -C $cfg_version --enable $enabled --mode $mode --intf-num $int_num"
    fi
    # echo "$cmd_main"
    # /usr/sbin/mllb_cmd.elf -C --mwan --enable 1 --mode load --intf-num 2
    ret=`$cmd_main`

    # if [ "$enabled" == "1" ]
    # then
        config_foreach mwan_member_add member $cfg_version  # 关闭也要加载接口，用于在线状态变更使用
        config_foreach mwan_member_add sub_member $cfg_version
    # fi

    return 0
}

db_cnii_add()
{
    input_file="/tmp/cnii.txt"

    if [ -f "$input_file" ]; then
        while IFS= read -r line
        do
            value="$(echo "$line" | sed 's/^add cnii //')"
            cmd=`/usr/sbin/mllb_cmd.elf -C --route-db --cnii $value`
        done < $input_file
    fi
}

db_cnc_add()
{
    input_file="/tmp/cnc.txt"

    if [ -f "$input_file" ]; then
        while IFS= read -r line
        do
            value="$(echo "$line" | sed 's/^add cnc //')"
            cmd=`/usr/sbin/mllb_cmd.elf -C --route-db --cnc $value`
        done < $input_file
    fi
}

db_mobile_add()
{
    input_file="/tmp/mobile.txt"

    if [ -f "$input_file" ]; then
        while IFS= read -r line
        do
            value="$(echo "$line" | sed 's/^add mobile //')"
            cmd=`/usr/sbin/mllb_cmd.elf -C --route-db --mobile $value`
        done < $input_file
    fi
}

db_cernet_add()
{
    input_file="/tmp/cernet.txt"

    if [ -f "$input_file" ]; then
        while IFS= read -r line
        do
            value="$(echo "$line" | sed 's/^add cernet //')"
            cmd=`/usr/sbin/mllb_cmd.elf -C --route-db --cernet $value`
        done < $input_file
    fi
}

config_ipv4_manage_class() {
  #echo "call config_ipv4_manage_class ....."
  local entry_name="$1"
  if [ -z "$entry_name" ]
  then
      return 1
  fi
  config_get type  $entry_name addr_type
  cmd=`/usr/sbin/mllb_cmd.elf -C --ipv4_manage --ipv4_manage-class $entry_name --type $type`
  
  config_get addr  $entry_name addr
  if [ -z "$addr" ]
  then
      return 0
  fi
  echo "$addr" | xargs -n1 | while read value
  do
  #value=${value##http://}
  #value=${value##www.}
  value=${value##\*.}
  cmd=`/usr/sbin/mllb_cmd.elf -C --ipv4_manage --ipv4_manage-class $entry_name --addr $value`
  done
   
  #echo "entry_name:$entry_name, url:$url"
}

ipv4_manage_set() {
    config_foreach config_ipv4_manage_class ipv4_manage_class
    cmd=`/usr/sbin/mllb_cmd.elf -C --ipv4_manage --over_cfg 1`
}

if [ -z "$1" ]; then
    echo "para is error.."
    return 1
fi

if [ "$1" == "capacity" ]; then
    # 单独分支：写入能力上限，由C层进程启动阶段调用一次
    mllb_capacity_set
elif [ "$1" == "mwan3" ]; then
    config_load_log "config_load mwan3"
    config_load mwan3
    mwan_config_add "4"
    mwan_config_blockIntf
elif [ "$1" == "ipv4_manage" ]; then
    config_load ipv4_manage
    ipv4_manage_set
elif [ "$1" == "policy_route" ]; then
    config_load policy_route
    pbr_config_add "4"
elif [ "$1" == "mwan3v6" ]; then
    config_load mwan3v6
    mwan_config_add "6"
    mwan_config_blockIntf
elif [ "$1" == "policy_routev6" ]; then
    config_load policy_routev6
    pbr_config_add "6"
elif [ "$1" == "url_route" ]; then
    url_config_add "4"
elif [ "$1" == "route_db" ]; then
    config_load route_db
    db_config_add
elif [ "$1" == "network" ]; then
    config_load mwan3
    special_line_config_add
elif [ "$1" == "cnii" ]; then
    db_cnii_add
elif [ "$1" == "cnc" ]; then
    db_cnc_add
elif [ "$1" == "mobile" ]; then
    db_mobile_add
elif [ "$1" == "cernet" ]; then
    db_cernet_add
elif [ "$1" == "all" ]; then
    config_load mwan3
    mwan_config_add "4"
    config_load ipv4_manage
    config_foreach config_ipv4_manage_class ipv4_manage_class
    config_load policy_route
    pbr_config_add "4"
    config_load mwan3v6
    mwan_config_add "6"
    mwan_config_blockIntf
    config_load policy_routev6
    pbr_config_add "6"

    url_config_add "4"

    config_load route_db
    db_config_add
fi
