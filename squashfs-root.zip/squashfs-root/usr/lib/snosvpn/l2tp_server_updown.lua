#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local lfs = require "lfs"
local ubus = require "ubus"
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local snosvpn = require "common"
local cjson = require "cjson";
local l2tp_uci = require "luci.model.uci".cursor();
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local CHANNELINFO_DIR = "/tmp/channelInfo/"
local SERVER_DIR = "/tmp/l2tp/server/"
local VPN_USER_DIR = "/tmp/vpn_user/"
local VPN_USER_L2TP_DIR = "/tmp/vpn_user/l2tpserver_"
local VPN_USER_JSON = "/etc/sd_config/single/vpn_user.json";
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown/"});
local L2TP_SERVER_JSON = "/etc/sd_config/single/l2tp_server.json";
local LINK_RECORD_FILE = "/tmp/l2tp/server/link_record"
local LINK_RECORD_LOCK = "/tmp/l2tp/server/link_record_lock"
local SNOSVPN_ROUTE = "/tmp/snosvpn/route"
local L2TP_SERVER_SAVE_FILE = nil;
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IP_ROUTE_350_FILE = nil;
local tunnelname = nil;
local l2tp_tunnelname = nil;
local record_file_json = {};
local sd_device = "/tmp/sd_device/sd_device.json"
local sd_device_json = nil
local support_vpn_account_fc = nil
if (tool.file_exist(sd_device) == true) then
    local file_data = tool.file_read(sd_device);
    sd_device_json = cjson.decode(file_data);
    support_vpn_account_fc = sd_device_json["gateway"]["vpn_account_fc"]
end

if (tool.file_exist(VPN_USER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", VPN_USER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(SERVER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(CHANNELINFO_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", CHANNELINFO_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if support_vpn_account_fc ~= nil then
    lib_user = require "user_mgr.user_mgr_common"
else
    lib_user = nil
end

--debug初始化
local function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "server_updown_lua.log", 2000, l2tp.INFO, "1");
end

function ubus_call(modul, method, data)
    local conn = ubus.connect()
    if not conn then
        return
    end
    status = conn:call(modul, method, data)
    return status
end

local function tunnelname_get(ifname)
    l2tp_tunnelname = ifname;
    if (l2tp_tunnelname ~= nil) then
        tunnelname = l2tp_tunnelname;
        l2tp_tunnelname = table.concat({"l2tp-", tunnelname});
    end
    if (tunnelname == nil) then
        l2tp.lua_debug(l2tp.INFO, "Tunnelname is not exist.");
        return false;
    end

    IP_ROUTE_350_FILE = table.concat({IPTABLES_RULES_DIR, "ip_route_350_server_", tunnelname});
    L2TP_SERVER_SAVE_FILE = table.concat({CHANNELINFO_DIR, "l2tp_server_", tunnelname});
    return true;
end

local function read_json_from_file(fn_file)
    local data = {}
    local file_json = {}

    if (tool.file_exist(fn_file) == false) then
        return file_json;
    end

    local file_data = tool.file_read(fn_file)
    if (file_data ~= nil and tool.json_check(file_data) == true) then
        file_json = cjson.decode(file_data)
    end

    return file_json;
end

local function get_pid_from_save_file(fn_file)
    local pid = nil;

    if (tool.file_exist(fn_file) == false) then
        return pid;
    end

    pid = tool.file_read(fn_file)
    if (pid ~= nil) then
        pid = tonumber(tool.trim(pid))
    end

    return pid;
end

local function get_gateway_ipaddr(ipaddr)
    local gateway = '-';

    if (ipaddr == nil) then
        return gateway;
    end
    if (tool.file_exist(SNOSVPN_ROUTE) == false) then
        return gateway;
    end

    local file = io.open(SNOSVPN_ROUTE)
    for line in file:lines() do
        if (line ~= nil and tool.json_check(line) == true) then
            json = cjson.decode(line);
            if (json["ipaddr"] == ipaddr) then
                gateway = json["gateway"];
            end
        end
    end
    io.close(file);

    return gateway;
end

function get_remote_ip(pid)
    local remote_ip = '-'
    local local_ip = '-'
    local cmdline_dir = table.concat({"/proc/", pid})
    local cmdline_file = table.concat({"/proc/", pid, "/cmdline"})
    if (tool.file_exist(cmdline_dir) == false or tool.file_exist(cmdline_file) == false) then
        return '-'
    end

    local cmdline_data = tool.exec(table.concat({"echo $(cat ", cmdline_file, ")"}));
    l2tp.lua_debug(l2tp.INFO, "cmdline: %s", cmdline_data);
    local result = snosvpn.get_string_before_or_after_specified_string(cmdline_data, "pppol2tp_tunnel_id", "after");
    if (result ~= nil) then
        local tunnel_id = tool.split(result, "pppol2tp")[1];
        if (tunnel_id ~= nil) then
        l2tp.lua_debug(l2tp.INFO, "tunnel_id: %s", tunnel_id);
        tunnel_id = tostring(tunnel_id);
        local cmd = table.concat({"ip l2tp show tunnel 2>/dev/null |grep -A 3 -i ", tunnel_id, " | grep From"});
            local tmp_res = tool.exec(cmd);
            if (tmp_res ~= nil) then
                result = tool.trim(tmp_res);
            end
        end
    end

    if (result ~= nil) then
        local sub_result = tool.split(result, " ");
        if (sub_result[2] ~= nil) then
            local_ip = get_gateway_ipaddr(sub_result[2]);
        end
        if (sub_result[4] ~= nil) then
            remote_ip = sub_result[4];
        end
    end

    return remote_ip, local_ip;
end

--l2tp客户端上线，同步用户管理
function l2tp_up_sync_usermgr(param)
    local grp_parent_id = nil
    local name = "l2tp-"..param["remoteIp"]
    l2tp.lua_debug(l2tp.INFO, "l2tp client up[username:%s,ip:%s]",param["username"], param["remoteIp"]);
    l2tp_uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local vpn_grp_name = l2tp_uci:get("user_mgr", namecode, "name")
        local grp_type = l2tp_uci:get("user_mgr", namecode, "type")
        if (grp_type == "vpn" and vpn_grp_name == param["username"]) then		    
            grp_parent_id = namecode
        end		
    end
    )
    if (grp_parent_id ~= nil) then
        local cmd = string.format("user_mgr_cmd.elf -A -t vpn -u %s -p %s -i %s", name, grp_parent_id, param["remoteIp"])
        l2tp.lua_debug(l2tp.INFO, "l2tp client up[cmd:%s]", cmd);
        tool.exec("exec 1>/tmp/null 2>&1")
        tool.exec(cmd)
    end
end

--l2tp客户端下线，同步用户管理
function l2tp_down_sync_usermgr(param)
    local user_id = nil
    l2tp.lua_debug(l2tp.INFO, "l2tp client down[username:%s,ip:%s]",param["peername"], param["ipremote"])
    local vpn_user_name = "l2tp-"..param["ipremote"]
    user_id = lib_user.get_id_by_name(vpn_user_name)
    if  (user_id == nil) then
        l2tp.lua_debug(l2tp.INFO, "try  to get user_id again")
        user_id = lib_user.get_id_by_name(vpn_user_name)
    end
    if (user_id ~= nil) then
        local del_cmd = " user_mgr_cmd.elf -D -d " .. user_id .. " >/dev/null 2>&1"
        l2tp.lua_debug(l2tp.INFO, "del_cmd[%s]", del_cmd)
        tool.exec(del_cmd)
    else
        l2tp.lua_debug(l2tp.INFO, "user_id is nil")
    end
end

--删除连接记录
function client_record_del()
    l2tp.lua_debug(l2tp.DEBUG, "client_record_del");
    local save_file = table.concat({SERVER_DIR, tunnelname, "_client_save"});
    os.remove(L2TP_SERVER_SAVE_FILE);
    os.remove(save_file);
end

--连接记录
function client_record_add(fn_json, file_json)
    local data = file_json;
    local cjson = require "cjson";
    l2tp.lua_debug(l2tp.DEBUG, "client_record_add");

    data["tunnelname"] = tunnelname;
    data["remoteIp"] = fn_json["ipremote"];
    data["username"] = fn_json["peername"];
    data["lns"] = fn_json["lns"];
    data["lnc"] = fn_json["lnc"];

    if (tool.file_exist(L2TP_SERVER_JSON) == true) then
        local file = tool.file_read(L2TP_SERVER_JSON);
        local file_data = cjson.decode(file);
        data["localIp"] = file_data["localip"];
        data["DNS"] = file_data["DNS"];
    end

    local jsonStr = cjson.encode(data);
    l2tp.lua_debug(l2tp.INFO, "jsonStr: %s", jsonStr);
    tool.file_write(L2TP_SERVER_SAVE_FILE, table.concat({jsonStr, "\n"}), "w+");
    local pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
    tool.file_write(pid_file, fn_json["pppd_pid"], "w+");
    local save_file = table.concat({SERVER_DIR, tunnelname, "_client_save"});
    tool.file_write(save_file, cjson.encode(fn_json), "w+");
    --新增l2tp服务器网卡，注册VPN流控脚本
    local fc_add_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh add "..data["tunnelname"].." L2TP >/dev/null 2>&1"
    l2tp.lua_debug(l2tp.INFO, "fc_add_cmd: %s", fc_add_cmd)
    os.execute(fc_add_cmd)
    --end
    --l2tp客户端上线，同步用户管理
    if (support_vpn_account_fc ~= nil) then
        l2tp_up_sync_usermgr(data)
    end
    --end
end

function route_add(file_json, fn_json)
    local gateway_ipaddr = fn_json["ipremote"];
    local file = assert(io.open(IP_ROUTE_350_FILE, "w+"));

    if (file_json["netmode"] == "lan2lan") then
        --Bugid=926695 | access client multi-segment
        if (file_json["remotesubnetArr"] ~= nil) then
            for k,var in pairs(file_json["remotesubnetArr"]) do 
                local remotesubnet = nil
                if (var ~= nil) then
                    remotesubnet = snosvpn.remotesubnet_transform(var)
                end
                if (remotesubnet ~= nil and gateway_ipaddr ~= nil) then
                    local metric = snosvpn.metric_get(remotesubnet, l2tp_tunnelname);
                    file:write("ip route add ", remotesubnet, " via ", gateway_ipaddr, " metric ", metric, " dev ", tunnelname, " table 350 2>/dev/null\n");
                end
            end
        else
            local remotesubnet = nil
            if (file_json["remotesubnet"] ~= nil) then
                remotesubnet = snosvpn.remotesubnet_transform(file_json["remotesubnet"]);
            end
            if (remotesubnet ~= nil and gateway_ipaddr ~= nil) then
                local metric = snosvpn.metric_get(remotesubnet, l2tp_tunnelname);
                file:write("ip route add ", remotesubnet, " via ", gateway_ipaddr, " metric ", metric, " dev ", tunnelname, " table 350 2>/dev/null\n");
            end
        end
    end

    if (fn_json["ipremote"] ~= nil and fn_json["localip"] ~= nil) then
        file:write("ip route add ", fn_json["ipremote"], " via ", fn_json["localip"], " dev ", tunnelname, " table 350 2>/dev/null\n");
    end

    if (fn_json["lns"] ~= "-" and fn_json["lnc"] ~= "-") then
        file:write("ip route add ", fn_json["lns"], " via ", fn_json["lnc"], " table 350 2>/dev/null\n");
    end
    file:close(file);

    os.execute(table.concat({"chmod +x ", IP_ROUTE_350_FILE}));
    os.execute(table.concat({"sh ", IP_ROUTE_350_FILE}));
end

function route_del(fn_json)
    local gateway_ipaddr = fn_json["remoteIp"];
    local file = assert(io.open(IP_ROUTE_350_FILE, "w+"));

    if (fn_json["netmode"] == "lan2lan") then
        --Bugid=926695 | access client multi-segment
        if (fn_json["remotesubnetArr"] ~= nil) then
            for k,var in pairs(fn_json["remotesubnetArr"]) do 
                local remotesubnet = nil
                if (var ~= nil) then
                    remotesubnet = snosvpn.remotesubnet_transform(var)
                end
                if (remotesubnet ~= nil and gateway_ipaddr ~= nil) then
                    file:write("ip route del ", remotesubnet, " via ", gateway_ipaddr, " dev ", tunnelname, " table 350 2>/dev/null\n")
                    snosvpn.metric_del(remotesubnet, l2tp_tunnelname)
                end
            end
        else
            local remotesubnet = nil;
            if (fn_json["remotesubnet"] ~= nil) then
                remotesubnet = snosvpn.remotesubnet_transform(fn_json["remotesubnet"]);
            end
            if (remotesubnet ~= nil and gateway_ipaddr ~= nil) then
                file:write("ip route del ", remotesubnet, " via ", gateway_ipaddr, " dev ", tunnelname, " table 350 2>/dev/null\n")
                snosvpn.metric_del(remotesubnet, l2tp_tunnelname)
            end
        end
    end

    if (fn_json["remoteIp"] ~= nil and fn_json["localIp"] ~= nil) then
        file:write("ip route del ", fn_json["remoteIp"], " via ", fn_json["localIp"], " dev ", tunnelname, " table 350 2>/dev/null\n");
    end

    if (fn_json["lns"] ~= "-" and fn_json["lnc"] ~= "-") then
        file:write("ip route del ", fn_json["lns"], " via ", fn_json["lnc"], " table 350 2>/dev/null\n");
    end
    file:close(file);

    os.execute(table.concat({"chmod +x ", IP_ROUTE_350_FILE}));
    os.execute(table.concat({"sh ", IP_ROUTE_350_FILE}));
    os.remove(IP_ROUTE_350_FILE);
end

function server_shutdown(fn_json)
    local pid = fn_json["pppd_pid"]
    local l2tp_service_enable = l2tp_uci:get("xl2tpd", "service", "enable")

    if (l2tp_service_enable == "0") then
        l2tp.lua_debug(l2tp.INFO, "L2tp server shutdown.");
        local cmd = table.concat({"kill -TERM ", pid, " 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", cmd);
        os.execute(cmd);
        return true;
    end

    return false;
end

function links_number_limit_check(dir, netmode, fn_json)
    local links_num = 0;
    local lan2lan_links_num = 0;
    local pid = fn_json["pppd_pid"]
    local name = fn_json["peername"];
	local sd_device = "/tmp/sd_device/sd_device.json"
	local sd_device_json = nil
	local links_limit_num = 8
    if (record_file_json[name] == nil) then
        local cmd = table.concat({"kill -TERM ", pid, " 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", cmd);
        os.execute(cmd);
        return true;
    end

    l2tp.lua_debug(l2tp.INFO, "user_name: %s", name);
    if (tool.file_exist(dir) == true and netmode == "lan2lan") then
        lan2lan_links_num = tonumber(record_file_json[name]["links_num"]) + 1;
    end

    for key,val in pairs(record_file_json) do
        links_num = links_num + val["links_num"];
    end

    local data = {};
    data["localip"] = fn_json["localip"];
    data["ipremote"] = fn_json["ipremote"];
    data["pppd_pid"] = fn_json["pppd_pid"];
    links_num = links_num + 1; 

	if (tool.file_exist(sd_device) == true) then
		local file_data = tool.file_read(sd_device);
		sd_device_json = cjson.decode(file_data);
		if (sd_device_json["gateway"]["l2tp_links_limit"] ~= nil) then
			links_limit_num = tonumber(sd_device_json["gateway"]["l2tp_links_limit"])
		end
	end
	l2tp.lua_debug(l2tp.INFO, "links num: %d,links_limit_num:%d,lan2lan_links_num:%d", links_num, links_limit_num, lan2lan_links_num);
    if (links_num > links_limit_num or lan2lan_links_num > 1) then
        local cmd = table.concat({"kill -TERM ", pid, " 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", cmd);
        os.execute(cmd);
        return true;
    else
        local file = table.concat({dir, tunnelname, "_limit"});
        local num = tonumber(record_file_json[name]["links_num"]);
        l2tp.lua_debug(l2tp.INFO, "%s links num: %s", name, num);
        record_file_json[name]["links_num"] = tostring(num + 1);
        record_file_json[name]["links"][tunnelname] = data;
        tool.file_write(file, pid, "w+");
        return false;
    end
end

function links_number_limit_delete(dir, fn_json)
    local name = fn_json["peername"];
    local file = table.concat({dir, tunnelname, "_limit"});
    os.remove(file);

    l2tp.lua_debug(l2tp.INFO, "user_name: %s", name);
    if (record_file_json[name] == nil) then
        return;
    end

    if (record_file_json[name]["links"][tunnelname] ~= nil) then
        local num = tonumber(record_file_json[name]["links_num"]);
        l2tp.lua_debug(l2tp.INFO, "%s links num: %s", name, num);
        record_file_json[name]["links_num"] = tostring(num - 1);
        record_file_json[name]["links"][tunnelname] = nil;
    end

    return;
end

function input_param_check(fn_json)
    if (fn_json["pppd_pid"] == nil) then
        l2tp.lua_debug(l2tp.ERROR, "Pppd pid is empty.");
        return false;
    end
    local list = {"peername", "ifname", "ipremote", "peername"}
    for i, var in ipairs(list) do
        if (fn_json[var] == nil) then
            l2tp.lua_debug(l2tp.ERROR, "%s is empty.", var);
            os.execute(table.concat({"kill -TERM ", fn_json["pppd_pid"], " 2>/dev/null"}));
            return false;
        end
    end
    return true;
end

function sd_config_file_get(peername)
    local file_json = {};
    local sd_config_json = {};
    local user_file = table.concat({VPN_USER_L2TP_DIR, peername, "/input_save"});

    if (tool.file_exist(user_file) == true) then
        local sd_config_file = tool.file_read(user_file);
        if (sd_config_file ~= nil and tool.json_check(sd_config_file) == true) then
            file_json = cjson.decode(sd_config_file);
        end
    end
    if (next(file_json) == nil) then
        user_file = VPN_USER_JSON;
        if (tool.file_exist(user_file) == true) then
            local sd_config_file = tool.file_read(user_file);
            if (sd_config_file ~= nil and tool.json_check(sd_config_file) == true) then
                sd_config_json = cjson.decode(sd_config_file);
            end
        end
    end
    if (next(sd_config_json) ~= nil and next(sd_config_json.list) ~= nil) then
        for key, val in pairs(sd_config_json.list) do
            if (val["provider"] == "all") then
                val["provider"] = "l2tpserver";
            end

            if (val["username"] == peername and val["provider"] == "l2tpserver") then
                file_json = val;
            end
        end
    end

    return file_json;
end

function server_save_file_get()
    local file_json = {};
    if (tool.file_exist(L2TP_SERVER_SAVE_FILE) == true) then
        local server_save = tool.file_read(L2TP_SERVER_SAVE_FILE);
        if (server_save ~= nil and tool.json_check(server_save) == true) then
            file_json = cjson.decode(server_save);
        end
    end

    return file_json;
end

function l2tp_server_up(fn_json)
    if (input_param_check(fn_json) == false) then
        return;
    end

    local file_json = sd_config_file_get(fn_json["peername"])
    if (next(file_json) == nil) then
        l2tp.lua_debug(l2tp.INFO, "Username and password is empty.");
        local pid = fn_json["pppd_pid"]
        local cmd = table.concat({"kill -TERM ", pid, " 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", cmd);
        os.execute(cmd);
        return;
    end

    --打印日志
    fn_json["lns"],fn_json["lnc"] = get_remote_ip(fn_json["pppd_pid"]);
    l2tp.lua_debug(l2tp.INFO, "Call from: %s", fn_json["lns"]);

    --服务端是否关闭
    local ret = server_shutdown(fn_json);
    if (ret == true) then
        return;
    end

    --链接数限制
    local limit_dir = table.concat({VPN_USER_L2TP_DIR, fn_json["peername"], "/"});
    local ret = links_number_limit_check(limit_dir, file_json["netmode"], fn_json);
    if (ret == true) then
        return;
    end

    route_add(file_json, fn_json);
    client_record_add(fn_json, file_json);
end

function l2tp_server_down(fn_json)
    --新增l2tp服务器网卡注销，注册VPN流控脚本
    local fc_del_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh remove "..tunnelname.." L2TP >/dev/null 2>&1"
    l2tp.lua_debug(l2tp.INFO, "fc_del_cmd: %s", fc_del_cmd)
    os.execute(fc_del_cmd)
    --l2tp客户端下线，同步用户管理
    if (support_vpn_account_fc ~= nil) then
        l2tp_down_sync_usermgr(fn_json)
    end
    --end
    if (fn_json["peername"]  == nil) then
        l2tp.lua_debug(l2tp.INFO, "Username is empty.");
        return;
    end

    local pppd_pid = tonumber(fn_json["pppd_pid"]);
    local pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
    local pid = get_pid_from_save_file(pid_file);
    if (pppd_pid ~= pid) then
        l2tp.lua_debug(l2tp.INFO, "Pppd pid is empty.");
        return;
    end
    os.remove(pid_file);

    local limit_dir = table.concat({VPN_USER_L2TP_DIR, fn_json["peername"], "/"});
    links_number_limit_delete(limit_dir, fn_json);

    fn_json["lns"], fn_json["lnc"] = get_remote_ip(fn_json["pppd_pid"]);
    file_json = server_save_file_get();
    if (next(file_json) == nil) then
        return;
    end

    l2tp.lua_debug(l2tp.INFO, "File data: %s", cjson.encode(file_json));
    -- Bugid = 926695 | access client multi-segment
    --[[
    local remotesubnet = nil;
    if (file_json["remotesubnet"] ~= nil) then
        remotesubnet = snosvpn.remotesubnet_transform(file_json["remotesubnet"]);
    end
    --]]
    route_del(file_json);
    --snosvpn.metric_del(remotesubnet, l2tp_tunnelname);
    client_record_del();
end

function update_links_status(input_json, name)
    local opt_type = input_json["status"];
    if (string.find(name, "client_save") ~= nil) then
        opt_type = "down"
    end

    --隧道名称校验
    if (tunnelname_get(input_json["ifname"]) == false) then
        return;
    end

    local switch = {
        ["up"] = l2tp_server_up,
        ["down"] = l2tp_server_down,
    }

    local opt_func = switch[opt_type]
    if opt_func ~= nil then
        opt_func(input_json)
    else
        l2tp.lua_debug(l2tp.ERROR, "Unknown updown status: %s", opt_type)
    end
end

function read_each_file(fn_dir)
    local i = 0;
    local fn_table = {};
    local fn_array = {};

    for file in lfs.dir(fn_dir) do
        if (string.find(file, "l2tpsrv") ~= nil) then
            local ppp_file = table.concat({fn_dir, file});
            local attr = lfs.attributes(ppp_file)
            if type(attr) == "table" then
                local file_data = tool.file_read(ppp_file);
                if (file_data ~= nil and tool.json_check(file_data) == true) then
                    i = i + 1;
                    local num = tonumber(attr.change) *10000 + i
                    fn_array[i]= {};
                    fn_array[i]["num"] = num;
                    fn_array[i]["file"] = file;
                    fn_table[tostring(num)] = cjson.decode(file_data);
                end
            end
            os.remove(ppp_file);
        end
    end

    --根据时间戳排序
    for i = 1, #fn_array do
        for j = i + 1, #fn_array do
            if fn_array[i]["num"] > fn_array[j]["num"] then
                fn_array[i], fn_array[j] = fn_array[j], fn_array[i]
            end
        end
    end

    return fn_table, fn_array;
end

------------------主函数区--------------------------
--是否存在updown目录
if (tool.file_exist(VPN_USER_JSON) == false or tool.file_exist(UPDOWN_DIR) == false) then
    return;
end

debug_init();
l2tp.lua_debug(l2tp.INFO, "###################main###################")
local array = {};
local file_table = {};

tool.file_write(LINK_RECORD_LOCK, "LOCK", "w");
snosvpn.delete_user_from_secrets_of_provider("l2tpserver");
file_table, array = read_each_file(UPDOWN_DIR);
record_file_json = read_json_from_file(LINK_RECORD_FILE)

for key ,var in pairs(array) do
    local num = var["num"];
    local file = var["file"];
    local data = file_table[tostring(num)];
    local ifname = file_table[tostring(num)]["ifname"];
    local status = file_table[tostring(num)]["status"];
    l2tp.lua_debug(l2tp.INFO, "---------------------------------------")
    l2tp.lua_debug(l2tp.INFO, "Time: %s", num)
    l2tp.lua_debug(l2tp.INFO, "Data: %s", cjson.encode(data))
    update_links_status(data, file);
end

local total_links_num = 0
local vpn_user_json = read_json_from_file(VPN_USER_JSON);

if (vpn_user_json.list == nil or vpn_user_json.list == "") then
    l2tp.lua_debug(l2tp.ERROR, "vpn_user_json.list is nil");
    return;
end

if (next(vpn_user_json.list) == nil) then
    l2tp.lua_debug(l2tp.ERROR, "vpn_user_json.list is nil");
    return;
end

for key, val in pairs(vpn_user_json["list"]) do
    local username = val["username"];

    if (val["provider"] == "all") then
        val["provider"] = "l2tpserver";
    end

    if (record_file_json[username] ~= nil and val["provider"] == "l2tpserver") then
        local links_num = tonumber(record_file_json[username]["links_num"]);
        total_links_num = total_links_num + links_num;
    end
end

l2tp.lua_debug(l2tp.INFO, "total_links_num: %s", total_links_num)
for key, val in pairs(vpn_user_json["list"]) do
    local username = val["username"];

    if (val["provider"] == "all") then
        val["provider"] = "l2tpserver";
    end

    if (record_file_json[username] ~= nil and val["provider"] == "l2tpserver") then
        local links_num = tonumber(record_file_json[username]["links_num"]);
        local limit = tonumber(record_file_json[username]["limit"]);
        if (val["enable"] == "on") then
            snosvpn.write_to_chap_secrets(val)
        end
    end
end

os.remove(LINK_RECORD_LOCK);
os.execute("ipset flush INPUT_zone_vpn_1701_reject 2>/dev/null");
tool.file_write(LINK_RECORD_FILE, cjson.encode(record_file_json), "w+");
os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
l2tp.lua_debug(l2tp.INFO, "####################end###################")
