module("common", package.seeall)
local tool = require "dev.tools.common"
local sd_crypto = require "sd_crypto"
local cjson = require "cjson";
local CHANNELINFO_DIR = "/tmp/channelInfo/"
local VPN_CLIENT_MAX = 100;
local dmask = {
    [0] = "0",
    [1] = "128",
    [2] = "192",
    [3] = "224",
    [4] = "240",
    [5] = "248",
    [6] = "252",
    [7] = "254"
}

function get_string_before_or_after_specified_string(strurl, strchar, status)
    local result = nil;
    local ts = string.reverse(strurl)
    local str = string.reverse(strchar)
    local param1, param2 = string.find(ts, str);
    if (param2 == nil) then
        return result
    end
    local m = string.len(strurl) - param2 + string.len(strchar)

    if (status == "before") then
        result = string.sub(strurl, 1, m-string.len(strchar))
    else
        result = string.sub(strurl, m+1, string.len(strurl))
    end

    return result
end

function filter_spec_chars(s)
    local ss = {}
    local k = 1
    while true do
        if k > #s then break end
        local c = string.byte(s,k)
        print(c);
        if not c then break end
        if c<192 then
            if (c>=48 and c<=57) or (c>= 65 and c<=90) or (c>=97 and c<=122) or c==46 then
                table.insert(ss, string.char(c))
            end
            k = k + 1
        elseif c<224 then
            k = k + 2
        elseif c<240 then
            if c>=228 and c<=233 then
                local c1 = string.byte(s,k+1)
                local c2 = string.byte(s,k+2)
                if c1 and c2 then
                    local a1,a2,a3,a4 = 128,191,128,191
                    if c == 228 then a1 = 184
                    elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
                    end
                    if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then
                        table.insert(ss, string.char(c,c1,c2))
                    end
                end
            end
            k = k + 3
        elseif c<248 then
            k = k + 4
        elseif c<252 then
            k = k + 5
        elseif c<254 then
            k = k + 6
        end
    end
    return table.concat(ss)
end

function remotesubnet_transform(remotesubnet)
    if (remotesubnet == nil) then
        return nil;
    end
    local result = tool.split(remotesubnet, "/");
    if (result[1] == nil or result[2] == nil) then
        return nil;
    end

    local ipaddr = result[1];
    local mask = tonumber(result[2]);
    local index = mask;
    local maskaddr;
    local maskfloor = math.floor(mask/8)
    for i = 1, maskfloor, 1 do
        if (maskaddr == nil) then
            maskaddr = "255"
        else
            maskaddr = table.concat({maskaddr, ".255"});
        end
    end

    if (maskfloor < 4) then
        if (maskaddr == nil) then
            maskaddr = dmask[mask%8];
        else
             maskaddr = table.concat({maskaddr, "." , dmask[mask%8]});
        end

        for i = 1, 3 - maskfloor, 1 do
            maskaddr = table.concat({maskaddr, ".", "0"});
        end
    end

    ipaddr = tool.ip_to_int(ipaddr);
    maskaddr = tool.ip_to_int(maskaddr);
    ip = tool.bit_and(ipaddr,maskaddr);

    output_ip = table.concat({tool.int_to_ip(ip), "/", index});
    return output_ip;
end

function metric_get(remotesubnet, tunnelname)
    if (remotesubnet == nil) then
        return nil;
    end
    local remotesubip = tool.split(remotesubnet, "/")[1];
    if (remotesubip == nil) then
        return nil;
    end

    local file_json = {}
    local file_data = nil;
    local metric_file = table.concat({CHANNELINFO_DIR, remotesubip});
    if (tool.file_exist(metric_file) == true) then
        local file = io.open(metric_file)
        file_data = file:read("*all");
        file:close();
        if (tool.json_check(file_data) == true) then
            file_json = cjson.decode(file_data);
        end
    end

    if (file_json["list"] ~= nil and file_json["data"] ~= nil) then
        if (file_json["data"][tunnelname] == nil) then
            for i = 1, VPN_CLIENT_MAX, 1 do
                if (file_json["list"][i] == nil or file_json["list"][i] == "empty") then
                    file_json["list"][i] = tunnelname;
                    file_json["data"][tunnelname] = i;
                    metric = i;
                    break;
                end
            end
        else
            metric = file_json["data"][tunnelname];
        end
    else
        file_json["list"] = {};
        file_json["data"] = {};
        file_json["list"][1] = tunnelname
        file_json["data"][tunnelname] = 1;
        metric = 1;
    end

    tool.file_write(metric_file, cjson.encode(file_json), "w+");
    return metric;
end

function metric_del(remotesubnet, tunnelname)
    if (remotesubnet == nil) then
        return false;
    end
    local remotesubip = tool.split(remotesubnet, "/")[1];
    if (remotesubip == nil) then
        return false;
    end

    local metric_file = table.concat({CHANNELINFO_DIR, remotesubip});
    if (tool.file_exist(metric_file) == false) then
        return true;
    end

    local file_json = {}
    local file_data = nil;
    local file = io.open(metric_file)
    file_data = file:read("*all");
    file:close();
    if (file_data == nil or tool.json_check(file_data) == false) then
        os.remove(metric_file);
        return true;
    end

    file_json = cjson.decode(file_data);
    local metric = file_json["data"][tunnelname];
    file_json["data"][tunnelname] = nil;
    if (metric ~= nil) then
        file_json["list"][metric] = "empty";
    end

    if (next(file_json["list"])== nil or next(file_json["data"]) == nil) then
        os.remove(metric_file);
        return true;
    end

    tool.file_write(metric_file, cjson.encode(file_json), "w+");
    return true;
end

function iptables_del_from_file(fn_file, ...)
    local arg = {...};
    local new_file = table.concat({fn_file, "_new"});
    local new_f = assert(io.open(new_file, "w+"));
    if (tool.file_exist(fn_file) == true) then
        local file = assert(io.open(fn_file, 'r'));
        for line in file:lines() do
            local is_same_rule = "yes"
            for i, var in ipairs(arg) do
                if (string.match(line, var) == nil) then
                    is_same_rule = "no"
                end
            end
            if (is_same_rule == "no") then
                new_f:write(table.concat({line, "\n"}));
            end
        end
        io.close(file);
    end

    io.close(new_f);
    os.rename(new_file, fn_file);
    local cmd = table.concat({"chmod +x ", fn_file});
    os.execute(cmd);
end

function iptables_save_to_file(fn_file, fn_input, ...)
    local arg = {...};
    local new_file = table.concat({fn_file, "_new"});
    local new_f = assert(io.open(new_file, "w+"));
    if (tool.file_exist(fn_file) == true) then
        local file = assert(io.open(fn_file, 'r'));
        for line in file:lines() do
            local is_same_rule = "yes"
            for i, var in ipairs(arg) do
                if (string.match(line, var) == nil) then
                    is_same_rule = "no"
                end
            end
            if (is_same_rule == "no") then
                new_f:write(table.concat({line, "\n"}));
            end
        end
        io.close(file);
    end
    new_f:write(table.concat({fn_input, "\n"}));
    io.close(new_f);
    os.rename(new_file, fn_file);
    local cmd = table.concat({"chmod +x ", fn_file});
    os.execute(cmd);
end

function write_to_chap_secrets(fn_json)
    if (fn_json.username == nil or fn_json.password == nil or fn_json.provider == nil) then
        return false;
    end
    local password_decrypt = nil
    if fn_json["encType"] ~= nil and fn_json["encType"] == 1 then
        if fn_json["password"] ~= nil and fn_json["password"] ~= "" then
            recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(fn_json["password"], #fn_json["password"], 'C');
            if (recode == 0) then
               password_decrypt = tostring(plaintext_restore)
            end
        end
    end
    local name = fn_json.provider:match("(%w+)server")
    local chap_file = table.concat({"/tmp/", name, "/chap-secrets"});
    local pap_file = table.concat({"/tmp/", name, "/pap-secrets"});
    local new_file = table.concat({chap_file, "_new"});
    local p_file = assert(io.open(pap_file, 'w+'));
    local n_file = assert(io.open(new_file, 'w+'));
    local user_name_input = table.concat({ "'", fn_json.username, "'"});
    local provider_input = table.concat({ "'", fn_json.provider, "'"});
    local password_input = table.concat({ "'", password_decrypt, "'"});
    local msg = ""
    if (tool.file_exist(chap_file) == true) then
        local c_file = assert(io.open(chap_file, 'r'));
        for line in c_file:lines() do
            local result=tool.split(line, "\t");
            local user_name_in_file = result[1];
            local provider_in_file = result[2];
            if (provider_in_file == "'l2tpserver'" or provider_in_file == "'pptpserver'") then
                if (not(user_name_in_file == user_name_input and provider_in_file == provider_input)) then
                    msg = msg..line.."\n"
                end
            end
        end
        io.close(c_file);
    end
    n_file:write(msg);
    p_file:write(msg);
    n_file:write(user_name_input, "\t", provider_input, "\t", password_input, "\t", "*", "\n");
    p_file:write(user_name_input, "\t", provider_input, "\t", password_input, "\t", "*", "\n");
    io.close(n_file);
    io.close(p_file);
    os.rename(new_file, chap_file);
    local cmd = table.concat({"chmod 600 ", pap_file});
    os.execute(cmd);
    local cmd = table.concat({"chmod 600 ", chap_file});
    os.execute(cmd);
end

function delete_from_chap_secrets(fn_json)
    if (fn_json.username == nil or fn_json.password == nil or fn_json.provider == nil) then
        return false;
    end
    local name = fn_json.provider:match("(%w+)server")
    local chap_file = table.concat({"/tmp/", name, "/chap-secrets"});
    local pap_file = table.concat({"/tmp/", name, "/pap-secrets"});
    local new_file = table.concat({chap_file, "_new"});
    local p_file = assert(io.open(pap_file, 'w+'));
    local n_file = assert(io.open(new_file, 'w+'));
    local user_name_input = table.concat({ "'", fn_json.username, "'"});
    local provider_input = table.concat({ "'", fn_json.provider, "'"});
    local password_input = table.concat({ "'", fn_json.password, "'"});
    if (tool.file_exist(chap_file) == true) then
        local c_file = assert(io.open(chap_file, 'r'));
        for line in c_file:lines() do
            local result=tool.split(line, "\t");
            local user_name_in_file=result[1];
            local provider_in_file=result[2];
            if (not(user_name_in_file == user_name_input and provider_in_file == provider_input)) then
                n_file:write(line, "\n");
                p_file:write(line, "\n");
            end
        end
        io.close(c_file);
    end
    io.close(n_file);
    io.close(p_file);
    os.rename(new_file, chap_file);
end

function delete_user_from_secrets_of_provider(provider)
    local name = provider:match("(%w+)server")
    local provider_input = table.concat({ "'", provider, "'"});
    local chap_file = table.concat({"/tmp/", name, "/chap-secrets"});
    local pap_file = table.concat({"/tmp/", name, "/pap-secrets"});
    local new_file = table.concat({chap_file, "_new"});
    local p_file = assert(io.open(pap_file, 'w+'));
    local n_file = assert(io.open(new_file, 'w+'));
    if (tool.file_exist(chap_file) == true) then
        local c_file = assert(io.open(chap_file, 'r'));
        for line in c_file:lines() do
            local result=tool.split(line, "\t");
            if (provider_input ~= result[2]) then
                n_file:write(line, "\n");
                p_file:write(line, "\n");
            end
        end
        io.close(c_file);
    end
    io.close(n_file);
    io.close(p_file);
    os.rename(new_file, chap_file);
end

function limit_flie_num_get(path)
    local num = 0;
    for file in lfs.dir(path) do
        if (string.match(file, "limit") ~= nil) then
            local pid_file = table.concat({path, file});
            local pid = tool.file_read(pid_file);
            if (tool.file_exist(table.concat({"/proc/", pid})) == true) then
                num = num + 1;
            else
                os.remove(pid_file);
            end
        end
    end
    return num;
end
