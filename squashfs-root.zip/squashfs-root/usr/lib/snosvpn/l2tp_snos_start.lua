#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local cjson = require "cjson";
local l2tp_client = require "l2tp_client";
local l2tp_server = require "l2tp_server";
local sd_crypto = require "sd_crypto";
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown"});
local SERVER_DIR = table.concat({DEBUG_LOG_DIR, "server"});
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "l2tp_server_rules"})
local L2TP_CLIENT_FILE ="/etc/sd_config/single/l2tp_client.json"
local L2TP_SERVER_FILE ="/etc/sd_config/single/l2tp_server.json"

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "l2tp_start_lua.log", 500, l2tp.INFO, "1");
end

function l2tp_client_enable(input_data)
    if (input_data ~= nil) then
        local config_json = cjson.decode(input_data)
        if config_json["encType"] ~= nil and config_json["encType"] == 1 then
            if config_json["password"] ~= nil and config_json["password"] ~= "" then
                recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(config_json["password"], #config_json["password"], 'C');
                if (recode == 0) then
                   config_json["password"] = tostring(plaintext_restore)
                end
            end
            if config_json["tunnelkey"] ~= "nil" and config_json["tunnelkey"] ~= "" then
                recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(config_json["tunnelkey"], #config_json["tunnelkey"], 'C');
                if (recode == 0) then
                   config_json["tunnelkey"] = tostring(plaintext_restore)
                end
            end
            if config_json["presharekey"] ~= "nil" and config_json["presharekey"] ~= "" then
                recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(config_json["presharekey"], #config_json["presharekey"], 'C');
                if (recode == 0) then
                   config_json["presharekey"] = tostring(plaintext_restore)
                end
            end
            config_json["encType"] = 0;
        end
        input_data = cjson.encode(config_json)
        l2tp.lua_debug(l2tp.INFO, "Output: %s", input_data);
        l2tp_client.module_update(input_data, L2TP_CLIENT_FILE);
    end
end

function l2tp_mkdir_file()
    if (tool.file_exist(UPDOWN_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    if (tool.file_exist(SERVER_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end
end

--------------------------main--------------------------------
debug_init();
l2tp_mkdir_file();

--恢复客户端拨号
if (tool.file_exist(L2TP_CLIENT_FILE) == true) then
    local file_data = tool.file_read(L2TP_CLIENT_FILE)
    local json = cjson.decode(file_data)
    if (json["list"] ~= nil) then
        local num = #json["list"];
        for j = 1, num, 1 do
            if (json["list"][j]["enable"] == "1") then
                l2tp_client_enable(cjson.encode(json["list"][j]))
            end
        end
    end
end
