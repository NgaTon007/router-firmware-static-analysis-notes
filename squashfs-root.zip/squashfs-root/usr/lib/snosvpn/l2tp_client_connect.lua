#! /usr/bin/lua
local lfs = require "lfs"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/l2tp/start/"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    return;
end

for file in lfs.dir(DEBUG_LOG_DIR) do
    if (string.find(file, "start") ~= nil) then
        local cmd = table.concat({"sh ", DEBUG_LOG_DIR, file});
        os.execute(cmd);
    end
end
