#!/usr/bin/env lua
local tool = require "dev.tools.common"
local cmd_handle = io.popen("ps |grep /usr/sbin/pppd");

for line in cmd_handle:lines() do
    if (string.find(line, "/usr/sbin/pppd plugin pppol2tp.so pppol2tp") ~= nil) then
        local pid = tool.split(line, " ")[1]
        local cmd = table.concat({"kill -9 ", pid, " 2>/dev/null"});
        os.execute(cmd);
    end
end

os.execute("ubus -t 3 send l2tp_client_connect");
