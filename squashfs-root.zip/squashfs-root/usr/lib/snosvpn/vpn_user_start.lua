#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")
local vpn = require "utils.debug"
local vpn_user = require "vpn_user"
local tool = require "dev.tools.common"
local cjson = require "cjson";
local DEBUG_LOG_DIR = "/tmp/vpn_user/"
local L2TP_DIR = "/tmp/l2tp/"
local PPTP_DIR = "/tmp/pptp/"
local VPN_USER_JSON_FILE = "/etc/sd_config/single/vpn_user.json";

--debug初始化
local function debug_init()
    vpn.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "vpn_user_start.log", 500, vpn.INFO, "1");
end

------------------------------main------------------------------
debug_init();

local function creat_secrets_file(dir)
    local secrets_file = table.concat({dir, "chap-secrets"})
    if (tool.file_exist(secrets_file) == false) then
        local file = assert(io.open(secrets_file, "w+"));
        file:write("#USERNAME  PROVIDER  PASSWORD  IPADDRESS\n");
        file:close(file);
    end
end

local list = {L2TP_DIR, PPTP_DIR}
for i, var in ipairs(list) do
    if (tool.file_exist(var) == false) then
        local mkdir = table.concat({"mkdir -p ", var, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    local server_dir = table.concat({var, "server/"});
    if (tool.file_exist(server_dir) == false) then
        local mkdir = table.concat({"mkdir -p ", server_dir, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end
    creat_secrets_file(var);
end

if (tool.file_exist(VPN_USER_JSON_FILE) == false) then
    return;
end

vpn.lua_debug(vpn.INFO, "################################START################################");
local file_data = tool.file_read(VPN_USER_JSON_FILE)
if (file_data ~= nil and tool.json_check(file_data) == true) then
    vpn.lua_debug(vpn.INFO, "File data: %s", file_data);
    json = cjson.decode(file_data)
    if (json["list"] == nil or next(json["list"]) == nil) then
        return;
    end
    for key, val in pairs(json["list"]) do
        if (val ~= nil and next(val) ~= nil) then
            data = cjson.encode(val)
            vpn_user.module_add(data, VPN_USER_JSON_FILE)
        end
    end
end
