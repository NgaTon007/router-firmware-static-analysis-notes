#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local lfs = require "lfs"
local cjson = require "cjson";
local snosvpn = require "common"
local tool = require "dev.tools.common"
local LINK_RECORD_FILE = "/tmp/l2tp/server/link_record"
local LINK_RECORD_LOCK = "/tmp/l2tp/server/link_record_lock"
local VPN_USER_JSON = "/etc/sd_config/single/vpn_user.json";
local DEAL_DIR = "/tmp/l2tp/deal/";
local SERVER_DIR = "/tmp/l2tp/server/";
local CHANNELINFO_DIR = "/tmp/channelInfo/";
local LINKS_LIMIT_NUM = {
    ["client2lan"] = "8",
    ["lan2lan"] = "1"
}

if (tool.file_exist(SERVER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(CHANNELINFO_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", CHANNELINFO_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(DEAL_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEAL_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

local function read_json_from_file(fn_file)
    local data = {}
    local file_json = {}

    if (tool.file_exist(fn_file) == false) then
        return file_json;
    end

    local file_data = tool.file_read(fn_file)
    if (file_data ~= nil and tool.json_check(file_data) == true) then
        file_json = cjson.decode(file_data)
    end

    return file_json;
end

local function vpn_user_monitor()
    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        local attr = lfs.attributes(LINK_RECORD_LOCK)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < 120) then
            return
        end
        os.remove(LINK_RECORD_LOCK);
    end

    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        return;
    end

    tool.file_write(LINK_RECORD_LOCK, "lock", "w+");
    local sd_config_json = read_json_from_file(VPN_USER_JSON);
    local record_file_json = read_json_from_file(LINK_RECORD_FILE)
    for key, val in pairs(sd_config_json["list"]) do
        if val["provider"] == "l2tpserver" or val["provider"] == "all" then
            local username = val["username"];
            local netmode = val["netmode"]
            if (val["provider"] == "all") then
                val["provider"] = "l2tpserver";
            end
            if (record_file_json[username] == nil) then
                record_file_json[username] = {};
                record_file_json[username]["netmode"] = netmode;
                record_file_json[username]["links_num"] = "0";
                record_file_json[username]["limit"] = LINKS_LIMIT_NUM[netmode];
                record_file_json[username]["links"] = {};
            end
        end
    end

    local total_links_num = 0
    for key, val in pairs(record_file_json) do
        local links_num = 0;
        for skey, sval in pairs(val["links"]) do
            local pid = sval["pppd_pid"];
            local pid_cmdline =  table.concat({"/proc/", pid, "/cmdline"});
            local recordfile = table.concat({CHANNELINFO_DIR, "l2tp_server_", skey});
            if (tool.file_exist(pid_cmdline) == false or tool.file_exist(recordfile) == false) then
                record_file_json[key]["links"][skey] = nil;
            else
                links_num = links_num + 1;
            end
        end
        record_file_json[key]["links_num"] = tostring(links_num);
    end
    local record_file_data = cjson.encode(record_file_json);
    tool.file_write(LINK_RECORD_FILE, record_file_data, "w+");

    for key, val in pairs(sd_config_json["list"]) do
        local username = val["username"];
        if (val["provider"] == "all") then
            val["provider"] = "l2tpserver";
        end

        if (record_file_json[username] ~= nil and val["provider"] == "l2tpserver") then
            local links_num = tonumber(record_file_json[username]["links_num"]);
            total_links_num = total_links_num + links_num;
        end
    end

    for key, val in pairs(sd_config_json["list"]) do
        local username = val["username"];
        if (val["provider"] == "all") then
            val["provider"] = "l2tpserver";
        end

        if (record_file_json[username] ~= nil and val["provider"] == "l2tpserver") then
            local links_num = tonumber(record_file_json[username]["links_num"]);
            local limit = tonumber(record_file_json[username]["limit"]);
            if (val["enable"] == "on") then
                snosvpn.write_to_chap_secrets(val)
            end
        end
    end

    for file in lfs.dir(DEAL_DIR) do
        if (string.find(file, "%.") == nil) then
            local pid = file;
            local key_word = table.concat({'pppd_pid":"', pid});
            local pid_file = table.concat({DEAL_DIR, pid});
            local count = tool.file_read(pid_file);
            if (string.find(record_file_data, key_word) == nil and count == "1") then
                local cmd = table.concat({"kill -TERM ", pid, " 2>/dev/null"});
                os.execute(cmd);
                os.remove(pid_file);
            end
            if (count == "0") then
                tool.file_write(pid_file, "1", "w+");
            end
        end
    end

    local cmd_handle = io.popen("ps |grep pppd");
    for line in cmd_handle:lines() do
        if (string.find(line, "/usr/sbin/pppd plugin pppol2tp.so pppol2tp") ~= nil) then
            local pid = tool.split(line, " ")[1]
            local key_word = table.concat({'pppd_pid":"', pid});
            local pid_file = table.concat({DEAL_DIR, pid});
            if (string.find(record_file_data, key_word) == nil and tool.file_exist(pid_file) == false) then
                tool.file_write(pid_file, "0", "w+");
            end
        end
    end
    cmd_handle:close();

    for file in lfs.dir(CHANNELINFO_DIR) do
        if (string.find(file, "l2tp_server_") ~= nil) then
            local l2tp_server_file = table.concat({CHANNELINFO_DIR, file});
            local l2tp_server_json = read_json_from_file(l2tp_server_file)
            local username = l2tp_server_json["username"];
            local tunnelname = l2tp_server_json["tunnelname"];
            if (record_file_json[username] == nil or record_file_json[username]["links"] == nil or record_file_json[username]["links"][tunnelname] == nil) then
                os.remove(l2tp_server_file);
            end
        end
    end

    for file in lfs.dir(SERVER_DIR) do
        if (string.find(file, "_client_save") ~= nil) then
            local l2tp_server_file = table.concat({SERVER_DIR, file});
            local l2tp_server_json = read_json_from_file(l2tp_server_file)
            local username = l2tp_server_json["peername"];
            local tunnelname = l2tp_server_json["ifname"];
            local l2tp_pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
            if (record_file_json[username] == nil or record_file_json[username]["links"] == nil or record_file_json[username]["links"][tunnelname] == nil) then
                os.remove(l2tp_server_file);
                os.remove(l2tp_pid_file);
            end
        end
    end
    os.remove(LINK_RECORD_LOCK);
end

vpn_user_monitor()
