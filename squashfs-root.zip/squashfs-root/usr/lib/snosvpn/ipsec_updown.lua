#! /usr/bin/lua
local lfs = require "lfs"
local tool = require "dev.tools.common"
local cjson = require "cjson";
local l2tp = require "utils.debug"
local SERVER_DIR = "/tmp/l2tp/server/"
local UPDOWN_DIR = "/tmp/l2tp/updown/"
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local CHANNELINFO_DIR = "/tmp/channelInfo/"
local L2TP_CLIENT = "/tmp/l2tp/l2tp/input_save"
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/l2tp_server_updown.lua"
local snos_uci = require "luci.model.uci".cursor()
local l2tp_client_enable = snos_uci:get("xl2tpd", "client", "enable")

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "ipsec_down.log", 500, l2tp.INFO, "1");
end

local function lns_format(lns)
    if (lns == nil) then
        return nil;
    end

    local ipaddr = lns
    if (string.find(lns, "/") ~= nil) then
        local result=tool.split(lns, "/");
        ipaddr = result[1];
    end
    return ipaddr
end

local function stop_client_connect(tunnelname)
    local kill_cmd = "kill -TERM"
    local rm_file_cmd = "rm -rf"

    local pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
    if (tool.file_exist(pid_file) == false) then
        return;
    end
    local pid = tool.file_read(pid_file);
    --判断ipsec down之后，L2TP是否还在线，如果在线删除，sleep 2s防止重复删除客户端
    tool.sleep(2);
    if (tool.file_exist(pid_file) == false) then
        return;
    end
    local  tmp_pid = tool.file_read(pid_file);
    if (tmp_pid ~= pid) then
        return;
    end

    kill_cmd = table.concat({kill_cmd, " ", pid});
    rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
    local file = table.concat({tunnelname, "_client_save"});
    local save_file = table.concat({SERVER_DIR, file});
    local down_file = table.concat({UPDOWN_DIR, file});
    l2tp.lua_debug(l2tp.INFO, "save_file: %s", save_file);
    l2tp.lua_debug(l2tp.INFO, "down_file: %s", down_file);
    if (tool.file_exist(save_file) == true) then
        os.rename(save_file, down_file);
        l2tp.lua_debug(l2tp.INFO, "%s", SERVER_UPDOWN_CMD);
        os.execute(SERVER_UPDOWN_CMD);
    end

    l2tp.lua_debug(l2tp.INFO, "%s", kill_cmd);
    l2tp.lua_debug(l2tp.INFO, "%s", rm_file_cmd);
    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
       os.execute(rm_file_cmd);
    end
end

local function module_del(input_data)
    debug_init();
    l2tp.lua_debug(l2tp.INFO, "################################DEL################################");
    --参数获取
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.ERROR, "Input data is not json mode.");
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "Input: %s", input_data);
    input_json = cjson.decode(input_data);
    if (next(input_json.list) == nil) then
        l2tp.lua_debug(l2tp.ERROR, "Tunnelname is empty.");
        return;
    end

    --遍历要删除的用户
    for key,val in pairs(input_json.list) do
        local tunnelname = val.tunnelname;
        stop_client_connect(tunnelname);
    end
end

local function iptables_add(lns)
    local add_cmd = table.concat({"ipset add zone_vpn_1701_reject ", lns, " 2>/dev/null"})
    l2tp.lua_debug(l2tp.INFO, "%s", add_cmd);
    os.execute(add_cmd);
end

local function ipsec_up(fn_json)
    if (l2tp_client_enable == "1") then
        os.execute("ubus -t 3 send xl2tpd_restart");
    end
    os.execute("ubus -t 3 send l2tp_client_connect");
end

local function ipsec_down(fn_json)
    local lns = lns_format(fn_json["pluto_peer_client"]);
    if (lns == nil) then
        l2tp.lua_debug(l2tp.INFO, "lns is empty.");
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "lns: %s", lns);
    for file in lfs.dir(CHANNELINFO_DIR) do
        if (string.find(file, "l2tp_server_") ~= nil) then
            local l2tp_file = table.concat({CHANNELINFO_DIR, file});
            local file_data = tool.file_read(l2tp_file);
            if (file_data ~= nil and tool.json_check(file_data) == true) then
                local file_json = cjson.decode(file_data);
                if (file_json.lns == lns) then
                    iptables_add(lns);
                    stop_client_connect(file_json.tunnelname);
                end
            end
        end
    end
end

---------------------------------------main------------------------------------------
debug_init();
l2tp.lua_debug(l2tp.INFO, "-----------------------MAIN------------------------");
local input_data = arg[1];

if (input_data == nil) then
    l2tp.lua_debug(l2tp.ERROR, "Input is empty.");
    return
end

l2tp.lua_debug(l2tp.INFO, "Input: %s", input_data);
if (tool.json_check(input_data) == false) then
    l2tp.lua_debug(l2tp.ERROR, "Input is not json format.");
    return
end

input_json = cjson.decode(input_data);
status = lns_format(input_json["pluto_verb"]);
if (status == nil) then
    l2tp.lua_debug(l2tp.INFO, "status is empty.");
    return;
end

l2tp.lua_debug(l2tp.INFO, "status: %s", status);
local switch = {
    ["up-host"] = ipsec_up,
    ["down-host"] = ipsec_down,
}

local opt_func = switch[status]

if (opt_func ~= nil) then
    opt_func(input_json)
else
    l2tp.lua_debug(l2tp.ERROR, "Unknown operation type %s", opt_type)
end
l2tp.lua_debug(l2tp.INFO, "-----------------------END------------------------");
