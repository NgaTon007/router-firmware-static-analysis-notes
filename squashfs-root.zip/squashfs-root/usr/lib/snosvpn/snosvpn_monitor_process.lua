#! /usr/bin/lua
local lfs = require "lfs"
local snos_uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local l2tp_client_enable = snos_uci:get("xl2tpd", "client", "enable")
local l2tp_service_enable = snos_uci:get("xl2tpd", "service", "enable")
local l2tp_ipsec_enable = snos_uci:get_first("ipsec", "connection", "status")
local ipsec_create_by = snos_uci:get_first("ipsec", "connection", "create_by")
local L2TP_CLIENT_LOCK = "/tmp/l2tp/l2tp/l2tp_lock"
local L2TP_ENABLE = "1"
local pptp_service_enable = snos_uci:get("pptpd", "service", "enable")
local pptp_client_enable = snos_uci:get("pptpd", "client", "enable")
local PPTP_CLIENT_FAIL = "/tmp/pptp/pptp/record"
local PPTP_CLIENT_LOCK = "/tmp/pptp/pptp_client_lock"
local L2TP_CLIENT_UP_FILE = "/tmp/l2tp/l2tp/l2tp_up"
local PPTP_CLIENT_UP_FILE = "/tmp/pptp/pptp/pptp_up"

if (l2tp_client_enable == "0" and l2tp_service_enable == "0") then
    L2TP_ENABLE = "0"
end

local function is_lock_effect(lock_file, maxtime)
    if (tool.file_exist(lock_file) == true) then
        local attr = lfs.attributes(lock_file)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < maxtime) then
            return true;
        end
        os.remove(lock_file);
    end
    return false;
end

local function xl2tpd_status_monitor()
    local ps_info = io.popen("pidof xl2tpd")
    local spid = nil;

    if (ps_info == nil) then
        return;
    end

    for line in ps_info:lines() do
        if (line ~= nil) then
            spid = line:match("(%d+.+%d+)")
        end
    end
    ps_info:close();

    --重复xl2tp进程检查
    if (spid ~= nil and string.find(spid, ".%s.") ~= nil) then
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
        if (L2TP_ENABLE == "0") then
            return;
        end

        os.execute("ubus -t 3 send xl2tpd_restart");
        return;
    end

    if (L2TP_ENABLE == "0" and spid ~= nil) then
        os.execute("/etc/init.d/xl2tpd stop");
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
        return;
    end

    if (L2TP_ENABLE == "1" and spid == nil) then
        os.execute("ubus -t 3 send xl2tpd_restart");
    end
    return;
end

local function l2tp_control_status_monitor()
    local ps_info = io.popen("pidof xl2tpd-control")
    local spid = nil;

    if (ps_info == nil) then
        return;
    end

    for line in ps_info:lines() do
        if (line ~= nil) then
            spid = line:match("(%d+.+%d+)")
        end
    end
    ps_info:close();

    if (spid == nil) then
        return;
    end

    --重复xl2tpd-control进程检查
    if (spid ~= nil and string.find(spid, ".%s.") ~= nil) then
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
        if (L2TP_ENABLE == "0") then
            return;
        end

        os.execute("ubus -t 3 send xl2tpd_restart");
        return;
    end

    if (spid ~= nil and L2TP_ENABLE == "0") then
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
    end
    return;
end

local function l2tp_client_monitor()
    if (tool.file_exist(L2TP_CLIENT_LOCK) == true) then
        local attr = lfs.attributes(L2TP_CLIENT_LOCK)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < 120) then
            return
        end
        os.remove(L2TP_CLIENT_LOCK);
    end

    if (l2tp_client_enable == "1" and tool.file_exist(L2TP_CLIENT_LOCK) == false) then
        if (tool.file_exist(L2TP_CLIENT_UP_FILE) == false) then
            os.execute("ubus -t 3 send xl2tpd_restart");
            -- l2tp over ipsec restart
            if (ipsec_create_by == "l2tp" and l2tp_ipsec_enable == "enable") then
                os.execute("/etc/init.d/ipsec restart &");
            end
        end
    end
end

local function vpn_user_monitor()
    if (l2tp_service_enable == "1") then
        os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
    end
    if (pptp_service_enable == "1") then
        os.execute("ubus -t 3 send pptp_vpn_user_monitor");
    end
end

local function pptp_status_monitor()
    local ps_info = io.popen("pidof pptpd")
    local spid = nil;

    if (ps_info == nil) then
        return;
    end

    for line in ps_info:lines() do
        if (line ~= nil) then
            spid = line:match("(%d+.+%d+)")
        end
    end
    ps_info:close();

    --重复xl2tp进程检查
    if (spid ~= nil and string.find(spid, ".%s.") ~= nil) then
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
        if (pptp_service_enable == "0") then
            return;
        end

        os.execute("/etc/init.d/pptpd restart");
        return;
    end

    if (pptp_service_enable == "0" and spid ~= nil) then
        os.execute("/etc/init.d/pptpd stop");
        os.execute(table.concat({"kill -9 ", spid, " 2>/dev/nul"}));
        return;
    end

    if (pptp_service_enable == "1" and spid == nil) then
        os.execute("/etc/init.d/pptpd restart");
    end
    return;
end

local function pptp_client_monitor()
    if (is_lock_effect(PPTP_CLIENT_LOCK, 120) == true) then
        return;
    end

    if (pptp_client_enable == "1") then
        local failtime = 0
        if (tool.file_exist(PPTP_CLIENT_FAIL) == true) then
            local data = tool.file_read(PPTP_CLIENT_FAIL);
            if (data ~= nil and tonumber(data) ~= nil) then
                failtime = tonumber(data);
            end
        end

        if (tool.file_exist(PPTP_CLIENT_UP_FILE) == false) then
            if (failtime >= 2) then
                os.execute("ubus -t 3 send pptp_client_connect");
                failtime = 0;
            else
                failtime = failtime + 1;
            end
        else
            failtime = 0;
        end
        print(failtime);
        tool.file_write(PPTP_CLIENT_FAIL, tostring(failtime), "w+");
    end
end

local function check_and_add_rule(priority)
    local handle = io.popen("ip rule list | grep " .. priority)
    local result = handle:read("*a")
    handle:close()
    
    if result == "" then
        os.execute("ip rule add from all lookup " .. priority .. " prio " .. priority .. " 2>/dev/null")
    end
end

local function l2tp_pptp_route_rule_monitor()
    if (l2tp_client_enable == "1" or l2tp_service_enable == "1" or pptp_client_enable == "1" or pptp_service_enable == "1") then
        check_and_add_rule(350)
        check_and_add_rule(550)
    end
end

------------------------------------------main----------------------------------------------
xl2tpd_status_monitor();
l2tp_control_status_monitor();
l2tp_client_monitor();
vpn_user_monitor();
pptp_status_monitor();
pptp_client_monitor()
l2tp_pptp_route_rule_monitor();
