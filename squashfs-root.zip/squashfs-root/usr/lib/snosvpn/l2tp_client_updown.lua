#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local l2tp = require "utils.debug"
local ubus = require "ubus"
local tool = require "dev.tools.common"
local snosvpn = require "common"
local cjson = require "cjson";
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local CHANNELINFO_DIR = "/tmp/channelInfo/"
local L2TP_CLIENT_JSON = "/etc/sd_config/single/l2tp_client.json";
local SNOSVPN_ROUTE = "/tmp/snosvpn/route"
local VPN_CLIENT_MAX = 100;
local IPTABLES_COMMENT = "L2TP_CLIENT_UPDOWN"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = nil;
local L2TP_CLIENT_SAVE_FILE = nil;
local l2tp_tunnelname = nil;
local tunnelname = nil;
local CLIENT_DIR = nil;
local dmask = {
    [0] = "0",
    [1] = "128",
    [2] = "192",
    [3] = "224",
    [4] = "240",
    [5] = "248",
    [6] = "252",
    [7] = "254"
}

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(CHANNELINFO_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", CHANNELINFO_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "client_updown_lua.log", 500, l2tp.INFO, "1");
end

local function tunnelname_get(tunnel, status)
    l2tp_tunnelname = tunnel;
    if (l2tp_tunnelname ~= nil) then
        if (string.find(l2tp_tunnelname, "l2tp-") ~= nil) then
            tunnelname = tool.split(l2tp_tunnelname, "-")[2];
        else
            tunnelname = l2tp_tunnelname;
            l2tp_tunnelname = table.concat({"l2tp-", tunnelname});
        end
    end
    if (tunnelname == nil) then
        l2tp.lua_debug(l2tp.INFO, "Tunnelname is not exist.");
        return false;
    end
    CLIENT_DIR = table.concat({DEBUG_LOG_DIR, tunnelname, "/"});
    if (tool.file_exist(CLIENT_DIR) == false and status == "up") then
        local mkdir = table.concat({"mkdir -p ", CLIENT_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "updown_client_", tunnelname});
    L2TP_CLIENT_SAVE_FILE = table.concat({CHANNELINFO_DIR, "l2tp_client_", tunnelname});
    return true;
end

local function remotesubnet_transform(ip)
    local result = tool.split(ip, "/");
    local ipaddr = result[1];
    local mask = tonumber(result[2]);
    local index = mask;
    local maskaddr;
    local maskfloor = math.floor(mask/8)

    for i = 1, maskfloor, 1 do
        if (maskaddr == nil) then
            maskaddr = "255"
        else
            maskaddr = table.concat({maskaddr, ".255"});
        end
    end

    if (maskfloor < 4) then
        if (maskaddr == nil) then
            maskaddr = dmask[mask%8];
        else
             maskaddr = table.concat({maskaddr, "." , dmask[mask%8]});
        end

        for i = 1, 3 - maskfloor, 1 do
            maskaddr = table.concat({maskaddr, ".", "0"});
        end
    end

    ipaddr = tool.ip_to_int(ipaddr);
    maskaddr = tool.ip_to_int(maskaddr);
    ip = tool.bit_and(ipaddr,maskaddr);

    return table.concat({tool.int_to_ip(ip), "/", index});
end

function get_lns_lnc_ipaddr(fn_json)
    local file_data;

    fn_json["lnc"] = "-"
    local L2TP_DIR = table.concat({DEBUG_LOG_DIR, tunnelname});
    if (tool.file_exist(L2TP_DIR) == false) then
        return;
    end
    local info_file = table.concat({L2TP_DIR, "/info"});
    if (tool.file_exist(info_file) == true) then
        file_data = tool.file_read(info_file)
    end

    if (file_data == nil or tool.json_check(file_data) == false) then
        return;
    end
    local file_json = cjson.decode(file_data);
    fn_json["lnc"] = file_json["lnc"];
    fn_json["lns"] = file_json["lns"];
end

function client_down_inform_cloud(fn_json)
    local alarm_data = {};
    local alarm_call = {};
    alarm_call["id"] = 181;
    alarm_call["age"] = 0;
    alarm_call["opt"] = "add";
    alarm_call["msg"] = "l2tp client event trigger";
    alarm_call["type"] = "event";
    if (fn_json["enable"] == "1") then
        l2tp.lua_debug(l2tp.DEBUG, "client_down_inform_cloud");
        alarm_data["username"] = fn_json["username"]
        alarm_data["vpn_status"] = "down"
        alarm_data["clientip"] = fn_json["lnc"]
        alarm_data["serverip"] = fn_json["lns"]
        alarm_data["remoteip"] = fn_json["remoteIp"]
        alarm_data["localip"] = fn_json["localIp"]
        alarm_call["data"] = alarm_data;
        alarm_call_data = cjson.encode(alarm_call)
        local cmd = table.concat({"dev_sta set -m alarm_mngt '", alarm_call_data, "'"});
        os.execute(cmd)
        l2tp.lua_debug(l2tp.INFO, "cmd: %s", cmd);
    end
end

function client_up_inform_cloud(fun_json)
    local alarm_data = {};
    local alarm_call = {};
    alarm_call["id"] = 181;
    alarm_call["age"] = 0;
    alarm_call["opt"] = "add";
    alarm_call["msg"] = "l2tp client event trigger";
    alarm_call["type"] = "event";

    if (fun_json["enable"] == "1") then
        l2tp.lua_debug(l2tp.DEBUG, "client_up_inform_cloud");
        alarm_data["username"] = fun_json["username"]
        alarm_data["vpn_status"] = "up"
        alarm_data["clientip"] = fun_json["lnc"]
        alarm_data["serverip"] = fun_json["lns"]
        alarm_data["remoteip"] = fun_json["remoteIp"]
        alarm_data["localip"] = fun_json["localIp"]
        alarm_call["data"] = alarm_data;
        alarm_call_data = cjson.encode(alarm_call)
        local cmd = table.concat({"dev_sta set -m alarm_mngt '", alarm_call_data, "'"});
        os.execute(cmd)
        l2tp.lua_debug(l2tp.INFO, "cmd: %s", cmd);
    end
end

function client_info_save(fun_json)
    local lock_file = table.concat({CLIENT_DIR, tunnelname, ".lock"});
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    tool.file_write(L2TP_CLIENT_SAVE_FILE, cjson.encode(fun_json), "w+");
    l2tp.lua_debug(l2tp.INFO, "record %s", up_file);
    tool.file_write(up_file, "record", "w+");
    os.remove(lock_file);
end

function client_info_del(fun_json)
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    l2tp.lua_debug(l2tp.INFO, "remove %s", up_file);
    os.remove(L2TP_CLIENT_SAVE_FILE);
    os.remove(up_file);
end

--删除iptable规则
function iptable_del(fn_json)
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("ipset del zone_vpn_nat_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_route_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    file:close(file);
    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    os.remove(IPTABLES_RULES_FILE)
end

--设置iptable规则
function iptable_add(fn_json)
    local workmode = fn_json["workmode"];
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("ipset del zone_vpn_nat_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_route_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    if (workmode == "nat") then
        file:write("ipset add zone_vpn_nat_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    else
        file:write("ipset add zone_vpn_route_iface 0.0.0.0/0,", l2tp_tunnelname, " 2>/dev/null\n");
    end
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
end

function route_add(fn_json)
    local file_json = {};
    local gateway_ipaddr = fn_json["remoteIp"];

    for k,var in pairs(fn_json["remotesubnetArr"]) do 
        if (var ~= nil and gateway_ipaddr ~= nil) then
            local metric = snosvpn.metric_get(var, l2tp_tunnelname);
            local command = table.concat({"ip route add ", var, " via ", gateway_ipaddr, " metric ", metric, " dev ", l2tp_tunnelname, " table 550 2>/dev/null"});
            l2tp.lua_debug(l2tp.INFO, "%s", command);
            os.execute(command);
        end
    end

    if (fn_json["remoteIp"] ~= nil and fn_json["localIp"] ~= nil) then
        local command = table.concat({"ip route add ", fn_json["remoteIp"], " via ", fn_json["localIp"], " dev ", l2tp_tunnelname, " table 350 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", command);
        os.execute(command);
    end
    -- R216 | add vpn default gateway 
    if (fn_json["redirect_gateway"] ~= nil and fn_json["redirect_gateway"] == "1") then
        local command_1 = table.concat({"ip route add default via ", fn_json["remoteIp"], " dev ", l2tp_tunnelname, " table 550 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", command_1);
        os.execute(command_1);
    end
end

function route_del(fn_json)
    if (fn_json == nil) then
        l2tp.lua_debug(l2tp.INFO, "Input is empty.");
        return;
    end

    local gateway_ipaddr = fn_json["remoteIp"];
    
    for k,var in pairs(fn_json["remotesubnetArr"]) do
        if (var ~= nil and gateway_ipaddr ~= nil) then
            local command = table.concat({"ip route del ", var, " via ", fn_json["remoteIp"], " dev ", l2tp_tunnelname , " table 550 2>/dev/null"});
            l2tp.lua_debug(l2tp.INFO, "%s", command);
            os.execute(command);
        end
    end
    
    if (fn_json["remoteIp"] ~= nil and fn_json["localIp"] ~= nil) then
        local command = table.concat({"ip route del ", fn_json["remoteIp"], " via ", fn_json["localIp"], " dev ", l2tp_tunnelname, " table 350 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", command);
        os.execute(command);
    end
    
    -- R216 | add vpn default gateway 
    if (fn_json["redirect_gateway"] ~= nil) then
        local command_1 = table.concat({"ip route del default via ", fn_json["remoteIp"], " dev ", l2tp_tunnelname, " table 550 2>/dev/null"});
        l2tp.lua_debug(l2tp.INFO, "%s", command_1);
        os.execute(command_1);
    end
end

function create_tunnel_rule(fn_json)
    l2tp.lua_debug(l2tp.DEBUG, "tunnel_add");
    if (fn_json["enable"] == "1") then
        iptable_add(fn_json);
        route_add(fn_json);
    end
end

function update_tunnel_rule(old_json, new_json)
    l2tp.lua_debug(l2tp.INFO, "update_tunnel_rule");

    if (next(old_json) ~= nil and old_json["enable"] == "1") then
        iptable_del(old_json);
        route_del(old_json);
    end

    if (new_json["enable"] == "1") then
        iptable_add(new_json);
        route_add(new_json);
    end
end

function new_configuration_get(fn_json)
    local out_json = {}
    local msg = {}
    msg["remotesubnetArr"] = {}
    local INPUT_SAVE = table.concat({CLIENT_DIR, "input_save"});
    if (tool.file_exist(INPUT_SAVE) == false) then
        l2tp.lua_debug(l2tp.INFO, "%s is not exist.", INPUT_SAVE);
        return out_json;
    end
    local file_data = tool.file_read(INPUT_SAVE)
    if (file_data == nil or tool.json_check(file_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Old config is not json mode.");
        return out_json;
    end

    local file_json = cjson.decode(file_data);
    out_json = file_json;
    for k,var in pairs(file_json["remotesubnetArr"]) do
        table.insert(msg["remotesubnetArr"], remotesubnet_transform(var))
    end
    l2tp.lua_debug(l2tp.INFO, "msg:%s",cjson.encode(msg));
    out_json["remotesubnetArr"] = msg["remotesubnetArr"];
    out_json["localIp"] = fn_json["localIp"];
    out_json["remoteIp"] = fn_json["remoteIp"];
    out_json["DNS"] = fn_json["DNS"];
    out_json["local_ip"] = nil;
    get_lns_lnc_ipaddr(out_json);

    return out_json;
end

function old_configuration_get()
    local out_json = {}
    if (tool.file_exist(L2TP_CLIENT_SAVE_FILE) == true) then
        file_data = tool.file_read(L2TP_CLIENT_SAVE_FILE);
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            out_json = cjson.decode(file_data);
        end
    end
    return out_json;
end

--设置route规则
function l2tp_client_up(input_json)
    local new_json = new_configuration_get(input_json);
    if (next(new_json) == nil) then
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "New config: %s", cjson.encode(new_json));

    local old_json = old_configuration_get();
    if (next(old_json) == nil) then
        create_tunnel_rule(new_json);
        --客户端上线事件通告云端
        client_up_inform_cloud(new_json)
    else
        l2tp.lua_debug(l2tp.INFO, "Old config: %s", cjson.encode(old_json));
        update_tunnel_rule(old_json, new_json);
    end
    
    --新增l2tp客户端网卡，注册VPN流控脚本
    local fc_add_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh add l2tp-l2tp L2TP >/dev/null 2>&1"
    l2tp.lua_debug(l2tp.INFO, "fc_add_cmd: %s", fc_add_cmd)
    os.execute(fc_add_cmd)
    os.execute("sh /usr/sbin/web/url_route_line_detect_exec.sh l2tp-l2tp up >/dev/null 2>&1")
    --end
    client_info_save(new_json);
end

function l2tp_client_down(input_json)
    --配置获取
    local client_json = old_configuration_get();
    if (next(client_json) == nil) then
        l2tp.lua_debug(l2tp.INFO, "%s is not exist.", L2TP_CLIENT_SAVE_FILE);
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "Delete json: %s", cjson.encode(client_json));
    --注销l2tp客户端网卡，注册VPN流控脚本
    local fc_del_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh remove l2tp-l2tp L2TP >/dev/null 2>&1"
    l2tp.lua_debug(l2tp.INFO, "fc_del_cmd: %s", fc_del_cmd)
    os.execute(fc_del_cmd)
    os.execute("sh /usr/sbin/web/url_route_line_detect_exec.sh l2tp-l2tp down >/dev/null 2>&1")
    --end
    
    --客户端下线事件通告云端
    client_down_inform_cloud(client_json)
    
    --删除路由列表文件
    for k,var in pairs(client_json["remotesubnetArr"]) do 
        snosvpn.metric_del(var, l2tp_tunnelname);
    end
    iptable_del(client_json)
    route_del(client_json);
    client_info_del();
end

------------------主函数区--------------------------
local opt_type = arg[1]
local input_data = arg[2]

l2tp.lua_debug(l2tp.INFO, "running")
--参数检查
if (opt_type == nil) then
    l2tp.lua_debug(l2tp.ERROR, "Param is error")
    return;
end

if (input_data == nil or tool.json_check(input_data) == false) then
    l2tp.lua_debug(l2tp.INFO, "Input data is not json mode.");
    return;
end

debug_init();
--参数获取
l2tp.lua_debug(l2tp.INFO, "###################main###################")
l2tp.lua_debug(l2tp.INFO, "optiong type: %s", opt_type)
l2tp.lua_debug(l2tp.INFO, "optiong input: %s", input_data)

--隧道名称校验
local input_json = cjson.decode(input_data);
if (tunnelname_get(input_json["tunnelname"], opt_type) == false) then
    return;
end

local switch = {
    ["up"] = l2tp_client_up,
    ["down"] = l2tp_client_down,
}

local opt_func = switch[opt_type]

if (opt_func ~= nil) then
    opt_func(input_json)
else
    l2tp.lua_debug(l2tp.ERROR, "Unknown operation type %s", opt_type)
end

l2tp.lua_debug(l2tp.INFO, "####################end###################")
