#! /usr/bin/lua
local lfs = require "lfs"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/pptp/start/"
local PPTP_CLIENT_LOCK = "/tmp/pptp/pptp_client_lock"
local PPTP_DIR = "/tmp/pptp/pptp/"

local function is_lock_effect(lock_file, maxtime)
    if (tool.file_exist(lock_file) == true) then
        local attr = lfs.attributes(lock_file)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < maxtime) then
            return true;
        end
        os.remove(lock_file);
    end
    return false;
end

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    return;
end

if (is_lock_effect(PPTP_CLIENT_LOCK, 120) == true) then
    return;
end

if (tool.file_exist(PPTP_DIR) == true) then
    for file in lfs.dir(PPTP_DIR) do
        if (string.find(file, "pid_") ~= nil) then
            local pid = file:match("pid_(%w+)");
            local pid_file = table.concat({"/proc/", pid});
            local run_file = table.concat({PPTP_DIR, file, "/run"});
            if (tool.file_exist(pid_file) == true and tool.file_exist(run_file) == true) then
                return;
            end
        end
    end
end

tool.file_write(PPTP_CLIENT_LOCK, "lock", "w+");
for file in lfs.dir(DEBUG_LOG_DIR) do
    if (string.find(file, "start") ~= nil) then
        local cmd = table.concat({"sh ", DEBUG_LOG_DIR, file});
        os.execute(cmd);
    end
end
os.remove(PPTP_CLIENT_LOCK);
