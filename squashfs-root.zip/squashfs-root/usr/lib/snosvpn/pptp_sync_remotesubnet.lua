#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/pptp/log/"
local PPTP_JSON_FILE = "/etc/sd_config/single/pptp_client.json"
local PPTP_CLIENT_SAVE_FILE = "/tmp/channelInfo/pptp_client_pptp"
local PPTP_SAVE_FILE = "/tmp/pptp/pptp/input_save"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "pptp_sync_remotesubnet.log", 100, module_debug.INFO, "1");
end

function main()
    module_debug.lua_debug(module_debug.INFO, "################################MAIN START################################")
    enable = uci:get("pptpd", "main", "subnet_sync")
    if (enable == "1") then
        module_debug.lua_debug(module_debug.INFO, "already sync")
        return 
    end
    uci:set("pptpd", "main", "subnet_sync", 1)
    uci:commit("pptpd")

    if (tool.file_exist(PPTP_JSON_FILE) == true) then
        local config_json = tool.file_read(PPTP_JSON_FILE)
        if (config_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", PPTP_JSON_FILE)
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "config_json: %s", config_json)

        local config_tab = cjson.decode(config_json)
        for k,var in pairs(config_tab["list"]) do
            if var["remotesubnet"] ~= nil then
                module_debug.lua_debug(module_debug.INFO, "remotesubnet:%s", var["remotesubnet"])
                if  var["remotesubnetArr"] == nil then
                    var["remotesubnetArr"] = {}
                    table.insert(var["remotesubnetArr"], var["remotesubnet"])
                end
            end
        end
        config_json = cjson.encode(config_tab)
        tool.file_write(PPTP_JSON_FILE, config_json)
    end
    
    if (tool.file_exist(PPTP_CLIENT_SAVE_FILE) == true) then
        local param_json = tool.file_read(PPTP_CLIENT_SAVE_FILE)
        if (param_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", PPTP_CLIENT_SAVE_FILE)
            return -1
        end

        local param_tab = cjson.decode(param_json)
        if  param_tab["remotesubnetArr"] == nil and param_tab["remotesubnet"] ~= nil then
            param_tab["remotesubnetArr"] = {}
            table.insert(param_tab["remotesubnetArr"], param_tab["remotesubnet"])
        end
        param_json = cjson.encode(param_tab)
        tool.file_write(PPTP_CLIENT_SAVE_FILE, param_json)
    end
    
    if (tool.file_exist(PPTP_SAVE_FILE) == true) then
        param_json = tool.file_read(PPTP_SAVE_FILE)
        if (param_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", PPTP_SAVE_FILE)
            return -1
        end

        param_tab = cjson.decode(param_json)
        if  param_tab["remotesubnetArr"] == nil and param_tab["remotesubnet"] ~= nil then
            param_tab["remotesubnetArr"] = {}
            table.insert(param_tab["remotesubnetArr"], param_tab["remotesubnet"])
        end
        param_json = cjson.encode(param_tab)
        tool.file_write(PPTP_SAVE_FILE, param_json)
    end
    
    module_debug.lua_debug(module_debug.INFO, "################################END################################")
    return 0
end
---------------------------------------------main--------------------------------------------------
debug_init()
main()