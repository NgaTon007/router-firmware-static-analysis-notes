#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/l2tp/log/"
local L2TP_JSON_FILE = "/etc/sd_config/single/l2tp_client.json"
local L2TP_CLIENT_SAVE_FILE = "/tmp/channelInfo/l2tp_client_l2tp"
local L2TP_SAVE_FILE = "/tmp/l2tp/l2tp/input_save"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "l2tp_sync_remotesubnet.log", 100, module_debug.INFO, "1");
end

function main()
    module_debug.lua_debug(module_debug.INFO, "################################MAIN START################################")
    enable = uci:get("xl2tpd", "main", "subnet_sync")
    if (enable == "1") then
        module_debug.lua_debug(module_debug.INFO, "already sync")
        return 
    end
    uci:set("xl2tpd", "main", "subnet_sync", 1)
    uci:commit("xl2tpd")

    if (tool.file_exist(L2TP_JSON_FILE) == true) then
        local config_json = tool.file_read(L2TP_JSON_FILE)
        if (config_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", L2TP_JSON_FILE)
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "config_json: %s", config_json)

        local config_tab = cjson.decode(config_json)
        for k,var in pairs(config_tab["list"]) do
            if var["remotesubnet"] ~= nil then
                module_debug.lua_debug(module_debug.INFO, "remotesubnet:%s", var["remotesubnet"])
                if  var["remotesubnetArr"] == nil then
                    var["remotesubnetArr"] = {}
                    table.insert(var["remotesubnetArr"], var["remotesubnet"])
                end
            end
        end
        config_json = cjson.encode(config_tab)
        tool.file_write(L2TP_JSON_FILE, config_json)
    end
    
    if (tool.file_exist(L2TP_CLIENT_SAVE_FILE) == true) then
        local param_json = tool.file_read(L2TP_CLIENT_SAVE_FILE)
        if (param_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", L2TP_CLIENT_SAVE_FILE)
            return -1
        end

        local param_tab = cjson.decode(param_json)
        if  param_tab["remotesubnetArr"] == nil and param_tab["remotesubnet"] ~= nil then
            param_tab["remotesubnetArr"] = {}
            table.insert(param_tab["remotesubnetArr"], param_tab["remotesubnet"])
        end
        param_json = cjson.encode(param_tab)
        tool.file_write(L2TP_CLIENT_SAVE_FILE, param_json)
    end
    
    if (tool.file_exist(L2TP_SAVE_FILE) == true) then
        param_json = tool.file_read(L2TP_SAVE_FILE)
        if (param_json == nil) then
            module_debug.lua_debug(module_debug.ERROR, "%s config is nil", L2TP_CLIENT_SAVE_FILE)
            return -1
        end

        param_tab = cjson.decode(param_json)
        if  param_tab["remotesubnetArr"] == nil and param_tab["remotesubnet"] ~= nil then
            param_tab["remotesubnetArr"] = {}
            table.insert(param_tab["remotesubnetArr"], param_tab["remotesubnet"])
        end
        param_json = cjson.encode(param_tab)
        tool.file_write(L2TP_SAVE_FILE, param_json)
    end
    
    module_debug.lua_debug(module_debug.INFO, "################################END################################")
    return 0
end
---------------------------------------------main--------------------------------------------------
debug_init()
main()