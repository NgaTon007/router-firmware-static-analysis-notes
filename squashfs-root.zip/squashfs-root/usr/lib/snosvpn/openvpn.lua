module("openvpn", package.seeall)
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
local tool = require "dev.tools.common"
local cjson = require "cjson";
local OPENVPN_CONFIG_FILE = "/etc/config/openvpn"
local openvpn_exist = tool.file_exist(OPENVPN_CONFIG_FILE)
local pwsfile="/etc/openvpn/psw-file"

function openvpn_user_update(username,password,status)
    local new_file = table.concat({pwsfile, "_new"});
    local p_file = assert(io.open(pwsfile, 'r'));
    local n_file = assert(io.open(new_file, 'w+'));
    local user_name_input = username.." "..password
    for line in p_file:lines() do
        repeat
            local result=tool.split(line, " ");
            local user_name_in_file=result[1];
            local password_in_file=result[2];
            if (user_name_in_file == username and password_in_file ~= password) then
                break
            elseif (user_name_in_file == username and password_in_file == password and status == "off") then
                break
            else
                n_file:write(line, "\n");
            end
        until true
    end
    if status == "on" then
        n_file:write(user_name_input, "\n");
    end
    io.close(n_file);
    io.close(p_file);
    os.rename(new_file, pwsfile);
    os.execute("echo -e 'kill "..username.." \r\n' |nc 127.0.0.1 5572 &");
    os.execute("killall -9 nc 2>/dev/null");
    return true
end

function openvpn_user_add(username,password,status)
    if (tool.file_exist(pwsfile) == false) then
        tool.exec("touch /etc/openvpn/psw-file");
    end

    local new_file = table.concat({pwsfile, "_new"});
    local p_file = assert(io.open(pwsfile, 'r'));
    local n_file = assert(io.open(new_file, 'w+'));
    local user_name_input = username.." "..password
    local password_restore;
    if password ~= nil and password ~= "" then
        recode, password_restore = sd_crypto.lua_sd_crypto_buf_decrypt(password, #password, 'C');
        if (recode ~= 0) then
           return false;
        end
    end
    for line in p_file:lines() do
        repeat
            local result=tool.split(line, " ");
            local user_name_in_file=result[1];
            local password_in_file=result[2];
            local password_in_file_restore;
            if password_in_file ~= nil and password_in_file ~= "" then
                recode, password_in_file_restore = sd_crypto.lua_sd_crypto_buf_decrypt(password_in_file, #password_in_file, 'C');
                if (recode ~= 0) then
                   return false;
                end
            end
            if (user_name_in_file == username and password_in_file_restore == password_restore) then
                break
            else
                n_file:write(line, "\n");
            end
        until true
    end
    if status == "on" then
        n_file:write(user_name_input, "\n");
    end
    io.close(n_file);
    io.close(p_file);
    os.rename(new_file, pwsfile);
    return true
end

local function lua_string_split(str, split_char)
    local sub_str_tab = {}
    while (true) do
        local pos = string.find(str, split_char)
        if (not pos) then
            sub_str_tab[#sub_str_tab+1] = str
            break
        end
        local sub_str = string.sub(str, 1, pos - 1)
        sub_str_tab[#sub_str_tab + 1] = sub_str
        str = string.sub(str, pos + 1, #str)
    end
    return sub_str_tab
end

function openvpn_user_del(fn_json)
    local cfg = {}
    local match_cfg = nil
    local new_file = table.concat({pwsfile, "_new"});
    local n_file = assert(io.open(new_file, 'w+'));
    local msg = ""
    for key, val in pairs(fn_json.list) do
        --Statistics of deleted account and password
        if (val.provider == "all" or val.provider == "openvpnserver") then
            if (openvpn_exist == true) then
                local user_name_input = val.username
                local password_input = val.password
                match_cfg = user_name_input.." "..password_input
                os.execute("echo -e 'kill "..user_name_input.." \r\n' |nc 127.0.0.1 5572 &");
                os.execute("killall -9 nc 2>/dev/null");
                table.insert(cfg, match_cfg)
            end
        end 
    end
    
    if (match_cfg == nil or next(cfg) == nil) then
        return
    end
    
    if (tool.file_exist(pwsfile) == true) then
        local p_file = io.open(pwsfile, "r+")
        if io.type(p_file) ~= nil then
            local a = p_file:read("*all")
            info = lua_string_split(a, "\n") 
            p_file:close()
        end
        --The deleted content is compared with the original content and removed
        for i=#info,1,-1 do
            if (info[i] ~= nil) then
                for j=#cfg,1,-1 do
                    if (cfg[j] ~= nil) then
                        if (info[i] == cfg[j]) then
                            table.remove(info, i)
                            table.remove(cfg, j)
                            break
                        end
                    end
                end
            end
        end
        for i,v in ipairs(info) do
            if (v ~= "") then
                msg = msg..v.."\n"
            end
        end
        n_file:write(msg)
        io.close(n_file);
        os.rename(new_file, pwsfile)
    end
end