#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local cjson = require "cjson";
local l2tp_client = require "l2tp_client";
local l2tp_server = require "l2tp_server";
local sd_crypto = require "sd_crypto"
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown"});
local SERVER_DIR = table.concat({DEBUG_LOG_DIR, "server"});
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "l2tp_server_rules"})
local L2TP_CLIENT_FILE ="/etc/sd_config/single/l2tp_client.json"
local L2TP_SERVER_FILE ="/etc/sd_config/single/l2tp_server.json"
local L2TP_ETC_SECRETS_FILE ="/etc/xl2tpd/xl2tp-server-secrets"
local L2TP_TMP_SECRETS_FILE ="/tmp/xl2tpd/xl2tp-server-secrets"

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "l2tp_start_lua.log", 500, l2tp.INFO, "1");
end

local function iptables_rule_create()
    local conf_json = {}
    local enable = "0"
    if (tool.file_exist(L2TP_SERVER_FILE) == true) then
        conf_data = tool.file_read(L2TP_SERVER_FILE);
        if (tool.json_check(conf_data) == true) then
            conf_json = cjson.decode(conf_data)
            enable = conf_json["enable"]
        end
    end

    os.execute("ipset flush INPUT_zone_vpn_1701_reject 2>/dev/null");
    os.execute(table.concat({"iptables -w -D INPUT -p udp -m udp --dport 1701 -j reject -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null"}));
    if (enable == "1") then
        local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
        file:write("iptables -w -D INPUT -p udp -m udp --dport 1701 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        if (conf_json["ipsecenc"] ~= "yes") then
            file:write("ipset flush zone_vpn_1701_reject 2>/dev/null\n");
            file:write("iptables -w -I INPUT -p udp -m udp --dport 1701 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        end
        file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:write("iptables -w -I INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:close(file);

        os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
        os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    end
end

function l2tp_mkdir_file()
    if (tool.file_exist(UPDOWN_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    if (tool.file_exist(SERVER_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    if (tool.file_exist(L2TP_ETC_SECRETS_FILE) == true and tool.file_exist(L2TP_TMP_SECRETS_FILE) == false) then
        local file = io.open("/etc/xl2tpd/xl2tp-server-secrets", "r")
        local lines = file:lines()
        for line in lines do
            local fields = line:split("\t") 
            if fields[1] == "*" and fields[2] == "*" then
                local secret = fields[3]
                l2tp.lua_debug(l2tp.INFO, "secret: %s", secret); 
                recode, secret_restore = sd_crypto.lua_sd_crypto_buf_decrypt(secret, #secret, 'C');
                if (recode == 0) then
                    local tmpfile = io.open("/tmp/xl2tpd/xl2tp-server-secrets", "w+");
                    if (tmpfile ~= nil) then
                        tmpfile:write("# Secrets for authenticating l2tp tunnels\n");
                        tmpfile:write("# us\tthem\tsecret\n");
                        tmpfile:write("*\t*\t", secret_restore, "\n");
                        tmpfile:close(tmpfile);
                    end
                end
            end
        end
        file:close(file)
    end
end

function l2tp_client_enable()
    local snos_uci = require "luci.model.uci".cursor()
    local client_enable = snos_uci:get("xl2tpd", "client", "enable")
    if (client_enable == "1") then
        os.execute("ubus -t 3 send l2tp_client_connect");
    end
end

--------------------------main--------------------------------
debug_init();
l2tp_mkdir_file();
iptables_rule_create();
l2tp_client_enable();