#!/usr/bin/env lua

local tool = require "dev.tools.common"
local pptp_tunnelname= arg[1];

if (pptp_tunnelname == nil) then
    return;
end

local kill = "kill -TERM"
local cmd = table.concat({"ps |grep \"/usr/sbin/pppd ifname\"| grep ", pptp_tunnelname, "|grep -v grep"});
local file = io.popen(cmd)
for line in file:lines() do
    local pid = tool.split(tool.trim(line)," ")[1];
    if (pid ~= nil) then
        kill = table.concat({kill, " ", pid});
    end
end
io.close(file)

cmd = table.concat({"rm -rf ", pptp_tunnelname, ".pid >/dev/null 2>&1"});
kill = table.concat({kill, " >/dev/null 2>&1"});
os.execute(kill);
os.execute(cmd);
