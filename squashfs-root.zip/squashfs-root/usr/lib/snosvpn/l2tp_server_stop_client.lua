#! /usr/bin/lua

local lfs = require "lfs"
local cjson = require "cjson";
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/l2tp/log/"
local SERVER_DIR = "/tmp/l2tp/server/"
local UPDOWN_DIR = "/tmp/l2tp/updown/"

if (tool.file_exist(SERVER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(UPDOWN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(DEBUG_LOG_DIR, "l2tp_server_stop_client.log", 500, l2tp.INFO, "1");
end

local function stop_client_connect(fn_file)
    local kill_cmd = "kill -TERM"
    local rm_file_cmd = "rm -rf"
    if (fn_file == nil) then
        return;
    end

    local pid_file = table.concat({SERVER_DIR, fn_file});
    if (tool.file_exist(pid_file) == true) then
        local pid = tool.file_read(pid_file);
        kill_cmd = table.concat({kill_cmd, " ", pid});
        rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
    end

    l2tp.lua_debug(l2tp.INFO, "%s", kill_cmd);
    l2tp.lua_debug(l2tp.INFO, "%s", rm_file_cmd);
    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
end

------------------------------------main---------------------------------
local snos_uci = require "luci.model.uci".cursor()
local l2tp_service_enable = snos_uci:get("xl2tpd", "service", "enable")
if (l2tp_service_enable ~= "1") then
    return;
end

debug_init();
l2tp.lua_debug(l2tp.INFO, "################################START################################");
--网络重启过程中不允许拨入l2tp，一直到l2tp重启完成（解除reject在l2tp_start.lua脚本中）
local del_reject_1701 = "iptables -w -D INPUT -p udp -m udp --dport 1701 -j reject -m comment --comment vpn 2>/dev/null"
local add_reject_1701 = "iptables -w -I INPUT -p udp -m udp --dport 1701 -j reject -m comment --comment vpn 2>/dev/null"
os.execute(del_reject_1701);
os.execute(add_reject_1701);

local is_send_termination_signal = false
for file in lfs.dir(SERVER_DIR) do
    l2tp.lua_debug(l2tp.INFO, "File: %s", file);
    if (string.find(file, "_pid") ~= nil) then
        stop_client_connect(file)
        is_send_termination_signal = true
    end
end

if (is_send_termination_signal == true) then
    os.execute("sleep 2")
end
os.execute(del_reject_1701);

l2tp.lua_debug(l2tp.INFO, "################################END################################");
