#! /usr/bin/lua
local lfs = require "lfs"
local cjson = require "cjson";
local tool = require "dev.tools.common"
local snos_uci = require "luci.model.uci".cursor()
local l2tp_client_enable = snos_uci:get("xl2tpd", "client", "enable")
local pptp_client_enable = snos_uci:get("pptpd", "client", "enable")
local SNOSVPN_ROUTE_JSON="/tmp/snosvpn/route"
local L2TP_CLIENT_JSON="/etc/sd_config/single/l2tp_client.json"
local PPTP_CLIENT_JSON="/etc/sd_config/single/pptp_client.json"

local function is_lock_effect(lock_file, maxtime)
    if (tool.file_exist(lock_file) == true) then
        local attr = lfs.attributes(lock_file)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < maxtime) then
            return true;
        end
        os.remove(lock_file);
    end
    return false;
end

local function snosvpn_client_route_create(fn_json)
    local intf_binding = fn_json["intf_binding"];
    local lns = fn_json["lns"];
    local gateway = nil;
    local device = nil;

    if (tool.file_exist(SNOSVPN_ROUTE_JSON) == false) then
        return;
    end

    local file = io.open(SNOSVPN_ROUTE_JSON)
    for line in file:lines() do
        if (line ~= nil and tool.json_check(line) == true) then
            json = cjson.decode(line);
            if (string.lower(json["interface"]) == string.lower(intf_binding)) then
                gateway = json["gateway"];
                device = json["device"];
            end
        end
    end
    io.close(file);
    if (gateway ~= nil and lns ~= nil and lns ~= "" and device ~= nil) then
        cmd = table.concat({"ip route del ", lns, " table 350 2>/dev/null"});
        os.execute(cmd);
        cmd = table.concat({"ip route add ", lns, " via ", gateway, " dev ", device, " table 350 2>/dev/null"});
        os.execute(cmd);
        print(cmd);
    end
end

local function l2tp_client_route_create(interface)
    if (tool.file_exist(L2TP_CLIENT_JSON) == false) then
        return;
    end
    file_data = tool.file_read(L2TP_CLIENT_JSON);
    if (file_data == nil or tool.json_check(file_data) == false) then
        return;
    end
    file_json = cjson.decode(file_data);
    if (file_json["list"] == nil or next(file_json["list"]) == nil) then
        return;
    end
    if (l2tp_client_enable == "0") then
        return;
    end

    for key, data in pairs(file_json["list"]) do
        if (string.lower(data["intf_binding"]) == string.lower(interface)) then
            snosvpn_client_route_create(data)
            os.execute("ubus -t 3 send l2tp_client_connect");
        end
    end
end

local function pptp_client_route_create(interface)
    if (tool.file_exist(PPTP_CLIENT_JSON) == false) then
        return;
    end
    file_data = tool.file_read(PPTP_CLIENT_JSON);
    if (file_data == nil or tool.json_check(file_data) == false) then
        return;
    end
    file_json = cjson.decode(file_data);
    if (file_json["list"] == nil or next(file_json["list"]) == nil) then
        return;
    end
    if (pptp_client_enable == "0") then
        return;
    end

    for key, data in pairs(file_json["list"]) do
        if (string.lower(data["intf_binding"]) == string.lower(interface)) then
            snosvpn_client_route_create(data)
            os.execute("ubus -t 3 send pptp_client_connect");
        end
    end
end

------------------------------------------main-------------------------------------------------
local interface= arg[1];
if (interface == nil) then
    return;
end

pptp_client_route_create(interface);
l2tp_client_route_create(interface);
