#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")
local tool = require "dev.tools.common"
local cjson = require "cjson";
local DEBUG_LOG_DIR = "/tmp/pptp/"
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "pptp_server_rules"})
local PPTP_SERVER_FILE ="/etc/sd_config/single/pptp_server.json"

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

local function iptables_rule_create()
    local enable = "1"
    if (tool.file_exist(PPTP_SERVER_FILE) == true) then
        conf_data = tool.file_read(PPTP_SERVER_FILE);
        if (tool.json_check(conf_data) == true) then
            conf_json = cjson.decode(conf_data)
            enable = conf_json["enable"]
        end
    end

    os.execute("ipset flush INPUT_zone_vpn_1723_reject 2>/dev/null");
    os.execute(table.concat({"iptables -w -D INPUT -p tcp -m tcp --dport 1723 -j reject -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null"}));
    if (enable == "1") then
        local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
        file:write("iptables -w -D INPUT_sd_chain -p tcp -m tcp --dport 1723 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:write("iptables -w -I INPUT_sd_chain -p tcp -m tcp --dport 1723 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:write("iptables -w -I INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
        file:close(file);
        os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
        os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    end
end


--------------------------main--------------------------------
iptables_rule_create();
