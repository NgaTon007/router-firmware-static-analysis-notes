#!/bin/sh

is_350_exist=$(ip rule show 2>/dev/null|grep 'lookup 350')
l2tp_dir="/tmp/l2tp/iptables"
pptp_dir="/tmp/pptp/iptables"

if [ -z "$is_350_exist" -o "$is_350_exist" = "" ]; then
    ip rule del from all lookup 350 prio 350 2> /dev/null
    ip rule add from all lookup 350 prio 350 2> /dev/null
fi

create_iptables_rules() {
    dir=$1;
    name=$2
    for files in $dir/*; do
        local file=${files##*/}
        case $file in
        *"$name"*)
            eval "sh $dir/$file"
            ;;
        *)
        ;;
        esac
    done
}

#####################main######################
if [ -d "$l2tp_dir" ]; then
    create_iptables_rules "$l2tp_dir" "ip_route_350_"
fi

if [ -d "$pptp_dir" ]; then
    create_iptables_rules "$pptp_dir" "ip_route_350_"
fi
