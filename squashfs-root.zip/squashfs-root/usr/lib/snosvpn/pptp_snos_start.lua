#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")
local pptp = require "utils.debug"
local tool = require "dev.tools.common"
local cjson = require "cjson";
local sd_crypto = require "sd_crypto";
local pptp_client = require "pptp_client";
local DEBUG_LOG_DIR = "/tmp/pptp/"
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown"});
local SERVER_DIR = table.concat({DEBUG_LOG_DIR, "server"});
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local PPTP_CLIENT_FILE ="/etc/sd_config/single/pptp_client.json"

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    pptp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "pptp_start_lua.log", 500, pptp.INFO, "1");
end

function pptp_client_enable(input_data)
    if (input_data ~= nil) then
        local config_json = cjson.decode(input_data)
        if config_json["encType"] ~= nil and config_json["encType"] == 1 then
            if config_json["password"] ~= nil and config_json["password"] ~= "" then
                recode, plaintext_restore = sd_crypto.lua_sd_crypto_buf_decrypt(config_json["password"], #config_json["password"], 'C');
                if (recode == 0) then
                   config_json["password"] = tostring(plaintext_restore)
                end
            end
            config_json["encType"] = 0;
        end
        input_data = cjson.encode(config_json)
        pptp.lua_debug(pptp.INFO, "Output: %s", input_data);
        pptp_client.module_update(input_data, PPTP_CLIENT_FILE);
    end
end

function pptp_mkdir_file()
    if (tool.file_exist(UPDOWN_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    if (tool.file_exist(SERVER_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end
end

--------------------------main--------------------------------
debug_init();
pptp_mkdir_file();

--恢复客户端拨号
if (tool.file_exist(PPTP_CLIENT_FILE) == true) then
    local file_data = tool.file_read(PPTP_CLIENT_FILE)
    local json = cjson.decode(file_data)
    if (json["list"] ~= null) then
        local num = #json["list"];
        for j = 1, num, 1 do
            if (json["list"][j]["enable"] == "1") then
                pptp_client_enable(cjson.encode(json["list"][j]))
            end
        end
    end
end
