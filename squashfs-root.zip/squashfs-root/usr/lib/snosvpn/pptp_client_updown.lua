#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local lfs = require "lfs"
local pptp = require "utils.debug"
local ubus = require "ubus"
local tool = require "dev.tools.common"
local snosvpn = require "common"
local cjson = require "cjson";
local DEBUG_LOG_DIR = "/tmp/pptp/"
local CHANNELINFO_DIR = "/tmp/channelInfo/"
local PPTP_CLIENT_JSON = "/etc/sd_config/single/pptp_client.json";
local SNOSVPN_ROUTE = "/tmp/snosvpn/route"
local VPN_CLIENT_MAX = 100;
local IPTABLES_COMMENT = "PPTP_CLIENT_UPDOWN"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = nil;
local PPTP_CLIENT_SAVE_FILE = nil;
local pptp_tunnelname = nil;
local tunnelname = nil;
local CLIENT_DIR = nil;
local dmask = {
    [0] = "0",
    [1] = "128",
    [2] = "192",
    [3] = "224",
    [4] = "240",
    [5] = "248",
    [6] = "252",
    [7] = "254"
}

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(CHANNELINFO_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", CHANNELINFO_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    pptp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "client_updown.log", 500, pptp.INFO, "1");
end

function ubus_call(modul, method, data)
    local conn = ubus.connect()
    if not conn then
        return nil
    end
    status = conn:call(modul, method, data)
    return status
end

local function tunnelname_get(tunnel, status)
    pptp_tunnelname = tunnel;
    if (pptp_tunnelname ~= nil) then
        if (string.find(pptp_tunnelname, "pptp-") ~= nil) then
            tunnelname = tool.split(pptp_tunnelname, "-")[2];
        else
            tunnelname = pptp_tunnelname;
            pptp_tunnelname = table.concat({"pptp-", tunnelname});
        end
    end
    if (tunnelname == nil) then
        pptp.lua_debug(pptp.INFO, "Tunnelname is not exist.");
        return false;
    end
    CLIENT_DIR = table.concat({DEBUG_LOG_DIR, tunnelname, "/"});
    if (tool.file_exist(CLIENT_DIR) == false and status == "up") then
        local mkdir = table.concat({"mkdir -p ", CLIENT_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "updown_client_", tunnelname});
    PPTP_CLIENT_SAVE_FILE = table.concat({CHANNELINFO_DIR, "pptp_client_", tunnelname});
    return true;
end

local function remotesubnet_transform(ip)
    local result = tool.split(ip, "/");
    local ipaddr = result[1];
    local mask = tonumber(result[2]);
    local index = mask;
    local maskaddr;
    local maskfloor = math.floor(mask/8)

    for i = 1, maskfloor, 1 do
        if (maskaddr == nil) then
            maskaddr = "255"
        else
            maskaddr = table.concat({maskaddr, ".255"});
        end
    end

    if (maskfloor < 4) then
        if (maskaddr == nil) then
            maskaddr = dmask[mask%8];
        else
             maskaddr = table.concat({maskaddr, "." , dmask[mask%8]});
        end

        for i = 1, 3 - maskfloor, 1 do
            maskaddr = table.concat({maskaddr, ".", "0"});
        end
    end

    ipaddr = tool.ip_to_int(ipaddr);
    maskaddr = tool.ip_to_int(maskaddr);
    ip = tool.bit_and(ipaddr,maskaddr);

    return table.concat({tool.int_to_ip(ip), "/", index});
end

function get_lns_lnc_ipaddr(fn_json)
    local file_data;

    fn_json["lnc"] = "-"
    local PPTP_DIR = table.concat({DEBUG_LOG_DIR, tunnelname});
    if (tool.file_exist(PPTP_DIR) == false) then
        return;
    end

    for file in lfs.dir(PPTP_DIR) do
        if (string.find(file, "pid_") ~= nil) then
            local info_file = table.concat({PPTP_DIR, "/", file, "/info"});
            if (tool.file_exist(info_file) == true) then
                file_data = tool.file_read(info_file)
            end
        end
    end
    if (file_data == nil or tool.json_check(file_data) == false) then
        return;
    end
    local file_json = cjson.decode(file_data);
    fn_json["lnc"] = file_json["lnc"];
    fn_json["lns"] = file_json["lns"];
end

function client_down_inform_cloud(fn_json)
    local alarm_data = {};
    local alarm_call = {};
    alarm_call["id"] = 182;
    alarm_call["age"] = 0;
    alarm_call["opt"] = "add";
    alarm_call["msg"] = "pptp client event trigger";
    alarm_call["type"] = "event";
    if (fn_json["enable"] == "1") then
        pptp.lua_debug(pptp.DEBUG, "client_down_inform_cloud");
        alarm_data["username"] = fn_json["username"]
        alarm_data["vpn_status"] = "down"
        alarm_data["clientip"] = fn_json["lnc"]
        alarm_data["serverip"] = fn_json["lns"]
        alarm_data["remoteip"] = fn_json["remoteIp"]
        alarm_data["localip"] = fn_json["localIp"]
        alarm_call["data"] = alarm_data;
        alarm_call_data = cjson.encode(alarm_call)
        local cmd = table.concat({"dev_sta set -m alarm_mngt '", alarm_call_data, "'"});
        os.execute(cmd)
        pptp.lua_debug(pptp.INFO, "cmd: %s", cmd);
    end
end

function client_up_inform_cloud(fun_json)
    local alarm_data = {};
    local alarm_call = {};
    alarm_call["id"] = 182;
    alarm_call["age"] = 0;
    alarm_call["opt"] = "add";
    alarm_call["msg"] = "pptp client event trigger";
    alarm_call["type"] = "event";

    if (fun_json["enable"] == "1") then
        pptp.lua_debug(pptp.INFO, "client_up_inform_cloud");
        alarm_data["username"] = fun_json["username"]
        alarm_data["vpn_status"] = "up"
        alarm_data["clientip"] = fun_json["lnc"]
        alarm_data["serverip"] = fun_json["lns"]
        alarm_data["remoteip"] = fun_json["remoteIp"]
        alarm_data["localip"] = fun_json["localIp"]
        alarm_call["data"] = alarm_data;
        alarm_call_data = cjson.encode(alarm_call)
        local cmd = table.concat({"dev_sta set -m alarm_mngt '", alarm_call_data, "'"});
        os.execute(cmd)
        pptp.lua_debug(pptp.INFO, "cmd: %s", cmd);
    end
end

function client_info_save(fun_json)
    local lock_file = table.concat({CLIENT_DIR, tunnelname, ".lock"});
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    tool.file_write(PPTP_CLIENT_SAVE_FILE, cjson.encode(fun_json), "w+");
    tool.file_write(up_file, "record", "w+");
    os.remove(lock_file);
end

function client_info_del(fun_json)
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    os.remove(PPTP_CLIENT_SAVE_FILE);
    os.remove(up_file);
end

--删除iptable规则
function iptable_del(fn_json)
    local lns = fn_json["lns"];
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("ipset del zone_vpn_nat_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_route_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_1723_accept ", lns, " 2>/dev/null\n");
    file:close(file);
    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    os.remove(IPTABLES_RULES_FILE)
end

--设置iptable规则
function iptable_add(fn_json)
    local workmode = fn_json["workmode"];
    local lns = fn_json["lns"];
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("ipset del zone_vpn_nat_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_route_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    file:write("ipset del zone_vpn_1723_accept ", lns, " 2>/dev/null\n");
    if (workmode == "nat") then
        file:write("ipset add zone_vpn_nat_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    else
        file:write("ipset add zone_vpn_route_iface 0.0.0.0/0,", pptp_tunnelname, " 2>/dev/null\n");
    end

    if (lns ~= nil) then
        file:write("ipset add zone_vpn_1723_accept ", lns, " 2>/dev/null\n");
    end
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
end

function route_add(fn_json)
    pptp.lua_debug(pptp.INFO, "Route add");

    local file_json = {};
    if (fn_json == nil) then
        pptp.lua_debug(pptp.INFO, "Input is empty.");
        return;
    end

    local gateway_ipaddr = fn_json["remoteIp"];
    
    for k,var in pairs(fn_json["remotesubnetArr"]) do 
        if (var ~= nil and gateway_ipaddr ~= nil) then
            local metric = snosvpn.metric_get(var, pptp_tunnelname);
            local command = table.concat({"ip route add ", var, " via ", gateway_ipaddr, " metric ", metric, " dev ", pptp_tunnelname, " table 550 2>/dev/null"});
            pptp.lua_debug(pptp.INFO, "%s", command);
            os.execute(command);
        end
    end

    local command = table.concat({"ip route add ", fn_json["remoteIp"], " via ", fn_json["localIp"], " dev ", pptp_tunnelname, " table 350 2>/dev/null"});
    pptp.lua_debug(pptp.INFO, "%s", command);
    os.execute(command);
    
    -- R216 | add vpn default gateway 
    if (fn_json["redirect_gateway"] ~= nil and fn_json["redirect_gateway"] == "1") then
        local command_1 = table.concat({"ip route add default via ", fn_json["remoteIp"], " dev ", pptp_tunnelname, " table 550 2>/dev/null"});
        pptp.lua_debug(pptp.INFO, "%s", command_1);
        os.execute(command_1);
    end
end

function route_del(fn_json)
    pptp.lua_debug(pptp.INFO, "Route del");

    if (fn_json == nil) then
        pptp.lua_debug(pptp.INFO, "Input is empty.");
        return;
    end

    local gateway_ipaddr = fn_json["remoteIp"];
    
    for k,var in pairs(fn_json["remotesubnetArr"]) do
        if (var ~= nil and gateway_ipaddr ~= nil) then
            local command = table.concat({"ip route del ", var, " via ", gateway_ipaddr, " dev ", pptp_tunnelname , " table 550 2>/dev/null"});
            pptp.lua_debug(pptp.INFO, "%s", command);
            os.execute(command);
        end
    end

    local command = table.concat({"ip route del ", fn_json["remoteIp"], " via ", fn_json["localIp"], " dev ", pptp_tunnelname, " table 350 2>/dev/null"});
    pptp.lua_debug(pptp.INFO, "%s", command);
    os.execute(command);
    
    -- R216 | add vpn default gateway 
    if (fn_json["redirect_gateway"] ~= nil) then
        local command_1 = table.concat({"ip route del default via ", fn_json["remoteIp"], " dev ", pptp_tunnelname, " table 550 2>/dev/null"});
        pptp.lua_debug(pptp.INFO, "%s", command_1);
        os.execute(command_1);
    end
end

function create_tunnel_rule(fn_json)
    pptp.lua_debug(pptp.INFO, "create_tunnel_rule");
    if (fn_json["enable"] == "1") then
        iptable_add(fn_json);
        route_add(fn_json);
    end
    return;
end

function update_tunnel_rule(old_json, new_json)
    pptp.lua_debug(pptp.INFO, "update_tunnel_rule");
    if (next(old_json) ~= nil and old_json["enable"] == "1") then
        iptable_del(old_json);
        route_del(old_json);
    end

    if (new_json["enable"] == "1") then
        iptable_add(new_json);
        route_add(new_json);
    end
end

function new_configuration_get(fn_json)
    local out_json = {}
    local msg = {}
    msg["remotesubnetArr"] = {}
    local INPUT_SAVE = table.concat({CLIENT_DIR, "input_save"});
    if (tool.file_exist(INPUT_SAVE) == false) then
        pptp.lua_debug(pptp.INFO, "%s is not exist.", INPUT_SAVE);
        return out_json;
    end
    local file_data = tool.file_read(INPUT_SAVE)
    if (file_data == nil or tool.json_check(file_data) == false) then
        pptp.lua_debug(pptp.INFO, "Old config is not json mode.");
        return out_json;
    end

    local file_json = cjson.decode(file_data);
    out_json = file_json;

    for k,var in pairs(file_json["remotesubnetArr"]) do
        table.insert(msg["remotesubnetArr"], remotesubnet_transform(var))
    end
    pptp.lua_debug(pptp.INFO, "msg:%s",cjson.encode(msg));
    out_json["remotesubnetArr"] = msg["remotesubnetArr"];
    out_json["localIp"] = fn_json["localIp"];
    out_json["remoteIp"] = fn_json["remoteIp"];
    out_json["DNS"] = fn_json["DNS"];
    out_json["local_ip"] = nil;
    get_lns_lnc_ipaddr(out_json);

    return out_json;
end

function old_configuration_get()
    local out_json = {}
    if (tool.file_exist(PPTP_CLIENT_SAVE_FILE) == true) then
        file_data = tool.file_read(PPTP_CLIENT_SAVE_FILE);
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            out_json = cjson.decode(file_data);
        end
    end
    return out_json;
end

--设置route规则
function pptp_client_up(input_json)
    local new_json = new_configuration_get(input_json);
    if (next(new_json) == nil) then
        return;
    end
    pptp.lua_debug(pptp.INFO, "New config: %s", cjson.encode(new_json));
    --新增pptp客户端网卡，注册VPN流控脚本
    local fc_add_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh add pptp-pptp PPTP >/dev/null 2>&1"
    pptp.lua_debug(pptp.INFO, "fc_add_cmd: %s", fc_add_cmd)
    os.execute(fc_add_cmd)
    os.execute("sh /usr/sbin/web/url_route_line_detect_exec.sh pptp-pptp up >/dev/null 2>&1")
    --end
    local old_json = old_configuration_get();
    if (next(old_json) == nil) then
        create_tunnel_rule(new_json);
        --客户端上线事件通告云端
        client_up_inform_cloud(new_json)
    else
        pptp.lua_debug(pptp.INFO, "Old config: %s", cjson.encode(old_json));
        update_tunnel_rule(old_json, new_json);
    end

    client_info_save(new_json);
end

function pptp_client_down(input_json)
    --配置获取
    local client_json = old_configuration_get();
    if (next(client_json) == nil) then
        pptp.lua_debug(pptp.INFO, "%s is not exist.", PPTP_CLIENT_SAVE_FILE);
        return;
    end
    pptp.lua_debug(pptp.INFO, "Delete json: %s", cjson.encode(client_json));
    --注销pptp客户端网卡，注册VPN流控脚本
    local fc_del_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh remove pptp-pptp PPTP >/dev/null 2>&1"
    pptp.lua_debug(pptp.INFO, "fc_del_cmd: %s", fc_del_cmd)
    os.execute(fc_del_cmd)
    os.execute("sh /usr/sbin/web/url_route_line_detect_exec.sh pptp-pptp down >/dev/null 2>&1")
    --end

    --客户端下线事件通告云端
    client_down_inform_cloud(client_json)
    
    --删除路由列表文件
    for k,var in pairs(client_json["remotesubnetArr"]) do 
        snosvpn.metric_del(var, pptp_tunnelname);
    end
    iptable_del(client_json)
    route_del(client_json);
    client_info_del();
    
end

------------------主函数区--------------------------
local opt_type = arg[1]
local input_data = arg[2]
debug_init();

--参数检查
if (opt_type == nil) then
    pptp.lua_debug(pptp.ERROR, "Param is error")
    return;
end

if (input_data == nil or tool.json_check(input_data) == false) then
    pptp.lua_debug(pptp.INFO, "Input data is not json mode.");
    return;
end

pptp.lua_debug(pptp.INFO, "###################main###################")
pptp.lua_debug(pptp.INFO, "optiong type: %s", opt_type)
pptp.lua_debug(pptp.INFO, "optiong input: %s", input_data)

--隧道名称校验
local input_json = cjson.decode(input_data);
if (tunnelname_get(input_json["tunnelname"], opt_type) == false) then
    return;
end

local switch = {
    ["up"] = pptp_client_up,
    ["down"] = pptp_client_down,
}

local opt_func = switch[opt_type]

if (opt_func ~= nil) then
    opt_func(input_json)
else
    pptp.lua_debug(pptp.ERROR, "Unknown operation type %s", opt_type)
end

pptp.lua_debug(pptp.INFO, "####################end###################")
