#!/usr/bin/env lua
local CLIENT_JSON_FILE = "/tmp/l2tp/l2tp/input_save"
local CLIENT_LOCK = "/tmp/l2tp/l2tp/l2tp_lock"
local tool = require "dev.tools.common"
local snos_uci = require "luci.model.uci".cursor()
local client_enable = snos_uci:get("xl2tpd", "client", "enable")
local cjson = require "cjson";
local ipaddr = nil;

if (tool.file_exist(CLIENT_LOCK) == true) then
    return;
end

if (tool.file_exist(CLIENT_JSON_FILE) == false) then
    return;
end

file_data = tool.file_read(CLIENT_JSON_FILE);
if (file_data == nil or tool.json_check(file_data) == false) then
    return;
end
file_json = cjson.decode(file_data);

for i = 1, 3, 1 do
    os.execute("xl2tpd-control status tunnel l2tp-l2tp")
    local file = io.popen("logread |tail -50")
    local list = nil
    for line in file:lines() do
        list = {next = list,value = line}
    end
    file:close();

    local line = list
    while line do
        ipaddr = line.value;
        line = line.next
        if (line ~= nil) then
            if (string.find(line.value, '==Config File==') ~= nil or string.find(line.value, 'l2tp, LNS is/are') ~= nil) then
                break;
            else
                ipaddr = nil;
            end
        end
    end

    if (ipaddr ~= nil) then
        break;
    end
    os.execute("sleep 1")
end

if (ipaddr ~= nil and client_enable == "1") then
    if (string.find(ipaddr, '==Config File==') ~= nil) then
        os.execute("ubus -t 3 send l2tp_client_connect");
    else
        local result = tool.split(ipaddr, " ");
        for i = 1, 20, 1 do
            if (string.find(result[i], 'xl2tpd') ~= nil) then
                ipaddr = result[i + 1];
                break
            end
        end
        if (ipaddr ~= file_json["lns"]) then
            os.execute("ubus -t 3 send xl2tpd_restart");
        end
    end
end
