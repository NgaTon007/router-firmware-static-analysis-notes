#!/bin/bash

JSON_FILE="/tmp/sd_device/sd_device.json"

#判断设备是否支持多WAN同vlan
# 返回值：1 表示支持，0 表示不支持
check_dev_double_tag_ability() {
    if [ -f /tmp/sd_device/sd_device.json ]; then
        local double_tage=$(cat /tmp/sd_device/sd_device.json | jq -r '.double_tag.double_tag_enable // "01"')
        if [ "$double_tage" = "1" ]; then
            echo 1
        else
            echo 0
        fi
    else
        echo 0
    fi
}

#判断设备是否支持bridge-vlan配置
# 返回值：1 表示支持，0 表示不支持
check_bridge_vlan_ability() {
    if [ -f /tmp/sd_device/sd_device.json ]; then
        local bridge_vlan=$(cat /tmp/sd_device/sd_device.json | jq -r '.bridge_vlan.bridge_vlan_enable // "01"')
        if [ "$bridge_vlan" = "1" ]; then
            echo 1
        else
            echo 0
        fi
    else
        echo 0
    fi
}

# usage: check_device_ability key1 [key2 ...]
# 返回值：1 表示支持，0 表示不支持
check_device_ability() {
    if [ ! -f "$JSON_FILE" ]; then
        echo 0
        return
    fi

    # 构造 jq 查询路径
    local jq_query=""
    for key in "$@"; do
        jq_query="${jq_query}.${key}"
    done

    # 读取并判断
    local value
    value=$(jq -r "$jq_query // empty" "$JSON_FILE" 2>/dev/null)

    if [ "$value" = "1" ]; then
        echo 1
    else
        echo 0
    fi
}
