string_is_mac(){
    mac=$1

    len=$(echo $mac | wc -L)
    if [ ! $len -eq 17 ]; then
        echo "MAC address length is invalid"
        return 1
    fi

    i=0
    mac_range="0123456789abcdefABCDEF"
    while [ $i -le 16 ]; do
        char=${mac:$i:1}
        flag=$(echo $mac_range | grep "$char")
        let i++
        local pos=$(($i%3))
        if [ $pos -ne 0 -a -n "$flag" ]; then
            continue
        elif [ $pos -eq 0 -a $char == ":" ]; then
            continue
        else
            echo "MAC address is invalid"
            return 1
        fi
    done

    echo 0
    return 0
}
