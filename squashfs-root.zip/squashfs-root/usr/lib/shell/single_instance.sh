# echo 0: current thread is not running
# echo 1: current thread is running
# echo -1: incorrect useage, a parameter of <lockfile> needs to be passed in

check_single_instance()
{
    local lockfile=$1
    local scriptname=`basename $0`

    if [ -z "$1" ]; then
        echo -1
    else
        dir=$(dirname $lockfile)
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
        fi

        if [ -f "$lockfile" ]; then
            prepid=`cat $lockfile`
            if [ "$$" != "${prepid}" ]; then
                result=$(ps -w | grep -w ${prepid} | grep $scriptname | grep -v 'grep')
                if [ -z "$result" ]; then
                    echo "$$" > "$lockfile"
                    echo 0
                else
                    echo 1
                fi
            else
                echo 0
            fi
        else
            echo "$$" > "$lockfile"
            echo 0
        fi
    fi
}
