LOG_NAME="logfile.log"
LOG_FILE="$LOG_DIR/$LOG_NAME"
LOG_LINE_NUM_MAX=50

log_init()
{
    if [ -z $1 ]; then
        echo "Error: parameter LOG_DIR is null"
        exit 1
    fi
    if [ -z $2 ]; then
        echo "Error: parameter LOG_NAME is null"
        exit 1
    fi
    if [ -z $3 ]; then
        echo "Error: parameter LOG_LINE_NUM_MAX is null"
        exit 1
    fi
    expr $3 "+" 10 &> /dev/null
    if [ $? -ne 0 ] ; then
        echo "Error: parameter LOG_LINE_NUM_MAX is not number"
        exit 1
    fi

    LOG_DIR=$1
    LOG_NAME=$2
    LOG_FILE="$LOG_DIR/$LOG_NAME"
    LOG_LINE_NUM_MAX=$3
}

log()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -ge $LOG_LINE_NUM_MAX ] && { mv -f $LOG_FILE ${LOG_FILE}.old; }
    else
        if [ ! -d ${LOG_DIR} ]; then
            mkdir "$LOG_DIR"
        fi
    fi
    if [ -n "$1" ]; then
        local cur_pid="[$$]"
        local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
        echo -e "${cur_pid}${cur_time} ${1}" >> $LOG_FILE
    else
        echo -e "" >> $LOG_FILE
    fi
}
