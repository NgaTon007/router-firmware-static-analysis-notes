dec2bin(){
    if [ -z $1 ]; then
        echo "Error: input parameter is null"
        exit 1
    fi
    expr $1 "+" 10 &> /dev/null
    if [ $? -ne 0 ] ; then
        echo "Error: input parameter is not number"
        exit 1
    fi
    dec=$1
    while [ $dec -gt 0 ]; do
        bin=$(($dec&1))$bin
        dec=$(($dec>>1))
    done

    echo $bin
}
