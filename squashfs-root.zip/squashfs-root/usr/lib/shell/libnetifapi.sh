#!/bin/bash

#��ȡwan����������
get_wan_rx_bytes() {
  proto=$(uci get network.wan.proto 2>/dev/null)
  if [ "$proto" = "pppoe" ]; then
    dev="pppoe-wan"
  else
    dev="br-wan"
  fi
  output=$(cat /proc/net/dev | grep -w "$dev" | sed 's/:/ /g' | awk '{print $2}' 2>/dev/null)
  if [ -n "$output" ]; then
    echo "$output"
  else
    echo "0"
  fi
}

#��ȡwan���������
get_wan_tx_bytes() {
  proto=$(uci get network.wan.proto 2>/dev/null)
  if [ "$proto" = "pppoe" ]; then
    dev="pppoe-wan"
  else
    dev="br-wan"
  fi
  output=$(cat /proc/net/dev | grep -w "$dev" | sed 's/:/ /g' | awk '{print $10}' 2>/dev/null)
  if [ -n "$output" ]; then
    echo "$output"
  else
    echo "0"
  fi
}

get_ifname_port() {
    local ifname="$1"
    if [ -z "$ifname" ]; then
        echo ""
        return
    fi
    local vlan_section="vlan_$ifname"
    # ��ȡ���� ports �ֶΣ������ж��У�
    local ports
    ports=$(uci get network.$vlan_section.ports 2>/dev/null)
    if [ -z "$ports" ]; then
        echo ""
        return
    fi
    local result=""
    for port in $ports; do
        # ȡð��ǰ����
        name="${port%%:*}"
        if [ -n "$name" ]; then
            result="$result $name"
        fi
    done
    # ȥ����β�ո�
    result=$(echo "$result" | sed 's/^ *//;s/ *$//')
    echo "$result"
}