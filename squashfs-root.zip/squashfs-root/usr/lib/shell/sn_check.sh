input_sn_check() {
    sn=$1
    if [ -z $sn ]; then
        echo 1
        return 1
    fi

    sn_pre=${sn:0:3}
    if [ $sn_pre == "123" ] ; then
        echo 1
        exit 1
    elif echo "$sn" | grep -q "^[0-9]*$" ; then
        echo 1
        exit 1
    elif echo "$sn" | grep -q "[a-z]" ; then
        echo 1
        exit 1
    fi

    echo 0
}

system_sn_check() {
    sn=$(uci -q get sysinfo.@sysinfo[0].serial_num)

    if [ -z $sn ]; then
        echo 1
        exit 1 
    fi

    input_sn_check $sn
}