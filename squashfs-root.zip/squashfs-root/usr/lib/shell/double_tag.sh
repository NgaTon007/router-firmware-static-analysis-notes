#!/bin/bash

check_double_tag() {
    if [ -f /tmp/sd_device/sd_device.json ]; then
        local double_tage=$(cat /tmp/sd_device/sd_device.json | jq -r '.double_tag.double_tag_enable // "01"')
        if [ "$double_tage" = "1" ]; then
            echo 1
        else
            echo 0
        fi
    else
        echo 0
    fi
}