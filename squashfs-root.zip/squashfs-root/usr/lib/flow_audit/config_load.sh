#!/bin/sh
. /lib/functions.sh

LOG="/usr/bin/logger -t flow_audit -p"
config_flow_audit_usr() {
    #echo "call config_flow_audit_usr ......"
    local entry_name="$1" enable=""
    if [ -z "$entry_name" ]
    then
        return 0
    fi
    
    config_get mac_addr $entry_name mac_addr
    config_get enable $entry_name enable
    /usr/sbin/flow_audit_cmd.elf -C -m -e $enable
    #�����ԭ�ȵ�����mac
    /usr/sbin/flow_audit_cmd.elf -C -m -d "all"

    if [ -z "$mac_addr" ]
    then
        return 0
    fi

    if [ "$enable"=="true" ]
    then
        echo "$mac_addr" | xargs -n1 | while read value
        do
        echo "value = $value"
        /usr/sbin/flow_audit_cmd.elf -C -m -a $value
        done
    fi
  
  
  #echo "usr_name:$entry_name, mac_addr:$mac_addr"
}

init_config() {
    local config="$1"
    config_get enable $config enable
    config_get refresh $config refresh
    config_get age $config age 50         #�ϻ����з�ֵ,�˴�����Ĭ��ֵ���Լ���֮ǰδ��ʼ���Ĳ�Ʒ
    # config_get newday $config newday

    if [ $enable = "false" ]
    then
		/usr/sbin/flow_audit_cmd.elf -C -f
        #if [ -f "/usr/sbin/web/app_idy_set_module.sh" ]; then
        #    /usr/sbin/web/app_idy_set_module.sh fa off
        #else
        #    $LOG warn "app indentify module is not installed."
        #fi
    else
        /usr/sbin/flow_audit_cmd.elf -C -o
        #if [ -f "/usr/sbin/web/app_idy_set_module.sh" ]; then
        #    /usr/sbin/web/app_idy_set_module.sh fa on
        #else
        #    $LOG warn "app indentify module is not installed."
        #fi
    fi
    /usr/sbin/flow_audit_cmd.elf -C -r $refresh
    /usr/sbin/flow_audit_cmd.elf -C -a $age

    # if [ $newday = "1" ]
    # then
    #     uci set flow_audit.global.newday=0
    #     uci commit flow_audit
    #     /usr/sbin/flow_audit_cmd.elf -C --newday
    # fi
   
    echo "enable:$enable, refresh:$refresh, age:$age"
}

config_load flow_audit
config_foreach init_config flow_audit
config_foreach config_flow_audit_usr flow_audit_usr
