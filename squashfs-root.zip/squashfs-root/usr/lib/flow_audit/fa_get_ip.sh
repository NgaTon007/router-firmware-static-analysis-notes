#!/bin/sh
/usr/sbin/flow_audit_cmd.elf -S -r -s -g | {
	read cnt_name  cnt
	if [ x"$cnt" = x ]
	then
		cnt=0
	fi
	read nothing
	read nothing
	read nothing
	while
	   read  name  ip  session
	   read  passUp  passDown  passUpPkt  passDownPkt
	   read  dropUp  dropDown  dropUpPkt  dropDownPkt
	do
	   echo $ip
	done
}