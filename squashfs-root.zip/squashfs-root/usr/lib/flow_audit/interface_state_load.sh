#!/bin/sh
. /lib/functions.sh

init_config() {
  local config="$1"
  config_get ifname $config ifname
  config_get state $config state
  
  /usr/sbin/flow_audit_cmd.elf -I -n $ifname -s $state
  
}
config_load /usr/lib/flow_audit/interface_state
config_foreach init_config interface



