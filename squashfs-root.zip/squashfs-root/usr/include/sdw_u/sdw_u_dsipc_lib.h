#ifndef _SDW_U_DSIPC_LIB_H_
#define _SDW_U_DSIPC_LIB_H_

#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <pthread.h>
#include <sd_thread/sd_thread.h>
#include <dsipc/ds_server.h>

#define IFNAMSIZ                                 16
#define SDW_DS_SOCKET_PATH                        "/tmp/sdwan/.DS_SDW"
#define SDW_EVENT_SHOW_PEER_STATUS                1
#define SDW_CLTI_NUM                              16
#define SDW_SELECT_SLEEP_TIME                     5
#define SDW_PTHREAD_STACK_SIZE                    (1024 * 26)

typedef enum sdw_ds_call_cmd_e {
    SDW_DS_SHOW_PEER_STATUS  = 0,
    SDW_DS_SHELL_ATTR_ROUTE_SET,
    SDW_DS_CMD_ALL
} sdw_ds_call_cmd_t;

typedef enum sdw_clt_event_e {
    SDW_CLT_DOWN  = 1 << 0,
    SDW_CLT_UP  = 1 << 1,
    SDW_CLT_ALL
} sdw_clt_event_t;

typedef struct sdw_clt_info {
    char intf[IFNAMSIZ];
    int state;
} sdw_clt_info_t;

typedef struct {
    char cltnum;
    sdw_clt_info_t clt_info[SDW_CLTI_NUM];
} sdw_ds_msg_t;

void sdw_ds_client_dereg_event(void);
int sdw_ds_client_reg_event(long events, void (*event_handle_func)(__u8, __u16, char *));
int sdw_ds_client_func_call(__u8 code, __u16 data_len, void *data);

#endif /* _SDW_U_DSIPC_LIB_H_ */
