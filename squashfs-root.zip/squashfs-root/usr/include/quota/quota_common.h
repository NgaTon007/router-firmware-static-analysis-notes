#ifndef __QUOTA_COMMON_H__
#define __QUOTA_COMMON_H__

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/types.h>

#define QUOTA_UNUSED(V) ((void) V)
#define ANET_CONNECT_NONE     0
#define ANET_CONNECT_NONBLOCK 1

#define ANET_OK               (0)
#define ANET_ERR              (-1)
#define QUOTA_OK              (0)
#define QUOTA_ERR             (-1)
#define QUOTA_MAC_LEN         (6)
#define QUOTA_INTF_NAME_LEN   (16)
#define QUOTA_MODULE_NAME_LEN (64)
#define QUOTA_USER_NAME_LEN   (64)
#define QUOTA_STRING_LEN      (64)

#define QUOTA_FILE_NAME_LEN   (128)
#define QUOTA_CMD_LEN         (256)
#define MAX_LOG_SIZE          (200 * 1024)
#define MAX_BUFFER_LEN        (2 * 1024)
#define QUOTA_TMP_PATH        "/tmp/run/quota/"
#define QUOTA_TMP_BAK_PATH    "/tmp/run/quota/bak/"
#define SERVER_LOG_FILE       "quota_server"
#define CLIENT_LOG_FILE       "quota_client_%s"
#define SERVER_DS_FILE        QUOTA_TMP_PATH"quota_server.ds"

#define QUOTA_SUB_TYPE_ALL    (0XFFFF)

#define BIT_IS_UNSET(var, pos) (((var) & (1 << (pos))) == 0)
#define BIT_IS_SET(var, pos) (((var) & (1 << (pos))) != 0)
#define SET_BIT(x, i)       ((x) |= ((1 << (i))))
#define CLEAR_BIT(x, i)     ((x) &= ~((1 << (i))))

typedef enum quota_set_mask_e {
    QUOTA_SET_MASK_TIME_QUOTA = 1 << 0,
    QUOTA_SET_MASK_FLOW_QUOTA = 1 << 1,
    QUOTA_SET_MASK_PKG_FLOW_QUOTA = 1 << 2,
    QUOTA_SET_MASK_ACCT_INTERVAL = 1 << 3,
    QUOTA_SET_MASK_ALL = 0XFFFFFFFF
} quota_set_mask_t;

/**
 * DEBUG������־��
 */
#define QUOTA_LOG_DEBUG(message, ...) \
    do {\
        log_to_file(DEBUG, "[%s:%d]"message, __FUNCTION__, __LINE__, ##__VA_ARGS__);\
        printf("[%s:%d]"message"\n", __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } while(0);

/**
 * INFO������־��
 */
#define QUOTA_LOG_INFO(message, ...) \
    do {\
        log_to_file(INFO, "[%s:%d]"message, __FUNCTION__, __LINE__, ##__VA_ARGS__);\
        printf("[%s:%d]"message"\n", __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } while(0);
/**
 * ERR������־��
 */
#define QUOTA_LOG_ERR(message, ...) \
    do {\
        log_to_file(ERR, "[%s:%d]"message, __FUNCTION__, __LINE__, ##__VA_ARGS__);\
        printf("[%s:%d]"message"\n", __FUNCTION__, __LINE__, ##__VA_ARGS__);\
    } while(0);

// �û����
typedef enum quota_user_type_e {
    QUOTA_USER_TYPE_WEBAUTH,
    QUOTA_USER_TYPE_CMD,
    QUOTA_USER_TYPE_IPSET,
    QUOTA_USER_TYPE_MWAN3,
    QUOTA_USER_TYPE_PPP,
    QUOTA_USER_TYPE_MAX
} quota_user_type_t;

// �û����
typedef enum quota_user_state_e {
    QUOTA_USER_STATE_RUNNING,
    QUOTA_USER_STATE_RUNOUT,
    QUOTA_USER_STATE_ONCERUNOUT
} quota_user_state_t;

// ������־����
typedef enum LogLevel {
    ERR   = 1, // ���󼶱�
    INFO  = 2, // ��Ϣ����
    DEBUG = 3  // ���Լ���
} LogLevel;

// ������Ϣ���,��Ϣ�Ǵ�client->server
typedef enum quota_msg_type_e {
    QUOTA_MSG_TYPE_REGISTER,         /* �ͻ���ע����Ϣ         */
    QUOTA_MSG_TYPE_ADD,              /* �����Ʒ� */
    QUOTA_MSG_TYPE_UPD,              /* ���¼Ʒ� */
    QUOTA_MSG_TYPE_SET,              /* ��λ������� */
    QUOTA_MSG_TYPE_QUERY,            /* ��ѯ�Ʒ� */
    QUOTA_MSG_TYPE_OFFLINE,          /* ���ߣ�ֹͣ�Ʒ� */

    QUOTA_MSG_TYPE_UG_QUERYALL,      /* �û���ȫ������ */
    QUOTA_MSG_TYPE_UG_DEL_GROUP,     /* �û���ɾ����̬�û��� */
    QUOTA_MSG_TYPE_SHOWALL,          /* ��ѯ���мƷ�״̬ */
    QUOTA_MSG_TYPE_SHOWFULL,         /* ��ѯ���мƷ�״̬����ӡ��ȫ */
    QUOTA_MSG_TYPE_SHOWUSERALL,          /* ��ѯ�����û��Ʒ�״̬ */
    QUOTA_MSG_TYPE_SHOWUSERFULL,         /* ��ѯ�����û��Ʒ�״̬����ӡ��ȫ */
    QUOTA_MSG_TYPE_SHOWINTFALL,      /* ��ѯ���нӿڼƷ�״̬ */
    QUOTA_MSG_TYPE_SHOWINTFFULL,     /* ��ѯ���нӿڼƷ�״̬����ӡ��ȫ */
    QUOTA_MSG_TYPE_SETUDBG,            /* ����user debug��״̬ */
    QUOTA_MSG_TYPE_SETKDBG,            /* ����kernel debug��״̬ */
    QUOTA_MSG_TYPE_SETKENABLE,          /* ����kernel enable��״̬ */
    QUOTA_MSG_TYPE_DELPOLICY,          /* ɾ��ĳ��policy */
    QUOTA_MSG_TYPE_CLEAN_AUTH,         /* ������֤�����Ϣ */
    QUOTA_MSG_TYPE_INTF_DOWN          /* �ӿ�down�¼� */
} quota_msg_type_t;

// ����ͻ��˶��Ĺ�ע����Ϣ,��Ϣ�Ǵ�server->client
typedef enum quota_sub_type_e {
    QUOTA_SUB_TYPE_UPDATE = 1 << 0,           /* ���¼Ʒ�     */
    QUOTA_SUB_TYPE_RUNOUT = 1 << 1,           /* ����þ� */
    QUOTA_SUB_TYPE_FINISH = 1 << 2,           /* �������� */
    QUOTA_SUB_TYPE_ALARM  = 1 << 3            /* ���澯 */
} quota_sub_type_t;

// ����domain socket�䴫�ݵ���Ϣͷ
typedef struct quota_msg_head_s {
    int type;
    uint32_t len;
    char data[];
} quota_msg_head_t;

/* client->server */
typedef struct quota_msg_register_s {
    char name[QUOTA_MODULE_NAME_LEN];
    quota_user_type_t type;
    int flag;
} quota_msg_register_t;

typedef struct quota_msg_add_s {
    char name[QUOTA_USER_NAME_LEN];
    quota_user_type_t type;
    unsigned int ip;
    char mac[QUOTA_MAC_LEN];
    uint64_t time_quota;
    uint64_t update_period;
    uint64_t once_t_allow;
    uint64_t once_t_pause;
    uint64_t flow_quota;
    uint64_t pkg_flow_quota;
} quota_msg_add_t;

typedef struct quota_msg_set_s {
    char name[QUOTA_USER_NAME_LEN];
    quota_user_type_t type;
    unsigned int ip;
    char mac[QUOTA_MAC_LEN];
    uint32_t set_mask;
    uint64_t time_quota;
    uint64_t update_period;
    uint64_t flow_quota;
    uint64_t pkg_flow_quota;
} quota_msg_set_t;

typedef struct quota_msg_del_s {
    char name[QUOTA_USER_NAME_LEN];
    char path[QUOTA_USER_NAME_LEN];
    unsigned int ip;
    char mac[QUOTA_MAC_LEN];
} quota_msg_del_t;

typedef enum quota_msg_query_type_e {
    QUOTA_QUERY_TYPE_NAME,
    QUOTA_QUERY_TYPE_IP
} quota_msg_query_type_t;

typedef struct quota_msg_query_s {
    quota_msg_query_type_t type;
    char name[QUOTA_USER_NAME_LEN];
    unsigned int ip;
} quota_msg_query_t;

typedef struct quota_msg_intf_s {
    char name[QUOTA_USER_NAME_LEN];
} quota_msg_intf_t;

/* server->client */

typedef struct quota_flow_info_s {
    uint64_t total_up;                         /* ������ͨ������ */
    uint64_t total_up_pkt;                     /* ������ͨ������ */
    uint64_t total_down;                       /* ������ͨ������ */
    uint64_t total_down_pkt;                   /* ������ͨ������ */
    uint64_t login_time;                       /* �ڵ����ʱ�� */
} quota_flow_info_t;

typedef struct quota_ip_info_s {
    unsigned int ip;
    char mac[QUOTA_MAC_LEN];
    quota_flow_info_t flow;
} quota_ip_info_t;

typedef struct quota_msg_upd_ro_s {
    char name[QUOTA_USER_NAME_LEN];
    uint64_t time_quota;
    uint64_t time_used;
    uint64_t traffic_quota;
    quota_flow_info_t flow;
    int ip_count;
    quota_ip_info_t ip[];
} quota_msg_upd_ro_t;

typedef struct quota_query_rep_s {
    char name[QUOTA_USER_NAME_LEN];
    uint64_t time_quota;
    uint64_t time_used;
    uint64_t traffic_quota;
    uint64_t pkg_traffic_quota;
    quota_flow_info_t flow;
    int ip_count;
    quota_ip_info_t ip[];
} quota_query_rep_t;

typedef int (*quota_msg_cb_t) (void *data);

/**
 * ��ʼ����־�ļ�
 */
extern FILE *quota_log_server_init(void);
extern FILE *quota_log_client_init(void);
extern void quota_log_finish(void);

/**
 * ������־����
 * @param level ��־���� ERR|INFO|DEBUG
 */
extern void set_log_level(LogLevel level);

/**
 * �����־
 * @param level ��־���� ERR|INFO|DEBUG
 * @param message fmt
 */
extern int log_to_file(LogLevel level, const char *message, ...);

/* libquota.so ��غ������� */
extern int quota_query_request(quota_msg_query_t *info, quota_query_rep_t **data);
extern int quota_start_billing(quota_msg_add_t *info);
extern int quota_update_billing(quota_msg_add_t *info);
extern int quota_set_billing(quota_msg_set_t *info);
extern int quota_stop_billing(quota_msg_del_t      *info);
extern int quota_register_cb(int type, quota_msg_cb_t cb);
extern int quota_unix_client_init(char *name, quota_user_type_t type, int flag);

#endif /* __QUOTA_COMMON_H__ */
