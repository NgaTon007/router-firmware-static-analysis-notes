/*
 * $Id:$
 * Copyright (C)2013-   All rights reserved.
 */
/*
 * gw_pub.h
 * Original Author:  huangxiaobao, 2018-10-11
 * gw����ͷ�ļ�
 *
 *  History   v1.0
 *    v1.0    huangxiaobao       2018-10-11
 */
 
#ifndef _GW_PUB_H_
#define _GW_PUB_H_

#ifdef __KERNEL__

/*ֻ�����ڵ�ǰeg205g�Ĳ�Ʒ*/
#if NR_CPUS > 2 
#define KTHREAD_BIND(p) {kthread_bind(p, 2);}
#elif NR_CPUS > 1
#define KTHREAD_BIND(p) {kthread_bind(p, 1);}
#else
#define KTHREAD_BIND(p) 
#endif
#endif

static inline int is_lan_intf(char *name)
{
    if(strncmp(name, "br-lan", 6) == 0)
        return 1;

    if(strncmp(name, "ppp", 3) == 0 && strncmp(name, "pppo", 4) != 0)
        return 1;
    return 0;
}

#endif    

