/*
 * Copyright (C)2011 sd.  All rights reserved. 
 */
/*
 * proxy_pub.h             
 * Original Author:  jiangzehao, 2024-9-11  
 *   
 *  proxy代理模块对外服务接口
 *
 *  History  
 *  V1.0  jiangzehao, 2024-9-11
 *        create 
 */

#ifndef __PROXY_PUB_H_
#define __PROXY_PUB_H_

#include <net/netfilter/nf_conntrack.h>
#include <net/netfilter/nf_conntrack_service.h>
#include <net/netfilter/nf_conntrack_module_space.h>

typedef enum {
    PROXY_NT_MARK_PROXY,            /* 标记此此流需要代理/缓存 */
    PROXY_NT_RELEASE_CACHAE_SKB,    /* 释放缓存报文 */
    PROXY_NT_GET_CACHE_SKB_COUNT,   /* 获取缓存报文数量 */
    PROXY_NT_GET_PROXY_RESULT,      /* 获取代理流结果 */
    PROXY_NT_GET_PROXY_SEQ_DIFF,    /* 获取原始流与代理流的差值 */
    PROXY_NT_MODIFY_HOOK_STATUS,    /* 卸载钩子 */
    PROXY_NT_MODIFY_MTU_INFO,       /* 更改全局mss信息 */
    PROXY_NT_MAX
} proxy_nt_server_type;

typedef enum {
    PROXY_TYPE_INIT,
    PROXY_TYPE_PROXY,               /* 流代理标志 */
    PROXY_TYPE_CACHE,               /* 首载荷分包缓存标志 */
    PROXY_TYPE_IGNORE,              /* 代理组件忽视标志 */
    PROXY_TYPE_MAX
} proxy_mark_type_e;

typedef enum {
    PROXY_HOOK_REG,                 /* 钩子注册 */
    PROXY_HOOK_DEREG                /* 钩子卸载 */
} proxy_hook_status_e;

typedef int (*proxy_nt_server_t)(struct sk_buff *skb, u32 interface,
        u8 intf_switch, u8 nat_flag, proxy_mark_type_e type);
typedef int (*proxy_nt_proxy_t)(struct sk_buff *skb, u32 *interface, u8 *intf_switch);
typedef int (*proxy_nt_proxy_seq_t)(struct sk_buff *skb, __be32 *seq_diff);
typedef int (*proxy_nt_cache_skb_t)(struct sk_buff *skb);
typedef int (*proxy_nt_cache_release_skb_t)(struct sk_buff *skb, u32 *interface, bool flag);
typedef int (*proxy_nt_hook_t)(proxy_hook_status_e type);
typedef int (*proxy_nt_mtu_t)(u8 enable, unsigned int mtu);

static inline int proxy_nt_get_cache_skb_count(struct sk_buff *skb)
{
    proxy_nt_cache_skb_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_GET_CACHE_SKB_COUNT);
    if (!func) {
        return -1;
    }

    return func(skb);
}

static inline int proxy_nt_release_skb_cache(struct sk_buff *skb, u32 interface, bool flag)
{
    proxy_nt_cache_release_skb_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_RELEASE_CACHAE_SKB);
    if (!func) {
        return -1;
    }

    return func(skb, interface, flag);
}

static inline int proxy_nt_server_mark_proxy(struct sk_buff *skb, u32 interface,
        u8 intf_switch, u8 intf_route, proxy_mark_type_e type)
{
    proxy_nt_server_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_MARK_PROXY);
    if (!func) {
        return -1;
    }

    return func(skb, interface, intf_switch, intf_route, type);
}

/**
 * proxy_nt_server_get_proxy_result--判断是否是代理流并获取代理流选路结果
 * @skb:报文
 * @interface:选路结果
 * 0成功，-1失败
*/
static inline int proxy_nt_server_get_proxy_result(struct sk_buff *skb, u32 *interface, u8 *intf_switch)
{
    proxy_nt_proxy_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_GET_PROXY_RESULT);
    if (!func) {
        return -1;
    }

    return func(skb, interface, intf_switch);
}

/*
 * proxy_nt_server_get_proxy_seq--获取代理流与原始流的seq差值
 * 返回0正常，-1错误
*/
static inline int proxy_nt_server_get_proxy_seq(struct sk_buff *skb, __be32 *seq_diff)
{
    proxy_nt_proxy_seq_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_GET_PROXY_SEQ_DIFF);
    if (!func) {
        return -1;
    }

    return func(skb, seq_diff);
}

/* 返回0正常，-1错误 */
static inline int proxy_nt_modify_proxy_hook_status(proxy_hook_status_e type)
{
    proxy_nt_hook_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_MODIFY_HOOK_STATUS);
    if (!func) {
        return -1;
    }

    return func(type);
}

static inline int proxy_nt_modify_proxy_mtu_info(u8 enable, unsigned int mtu)
{
    proxy_nt_mtu_t func;

    func = nf_ct_get_service(NF_CT_MOD_PROXY, PROXY_NT_MODIFY_MTU_INFO);
    if (!func) {
        return -1;
    }

    return func(enable, mtu);
}

#endif /* __PROXY_PUB_H_ */
