/*
 * Copyright (C)2011.  All rights reserved. 
 */
/*
 * url_route_pub.h             
 * Original Author:  zhuweilin, 2023-07-19  
 *   
 *  url选路内核模块对外提供头文件,提供给其他模块使用的接口
 *
 *  History  
 *  V1.0  zhuweilin, 2023-07-19
 *        create 
 */

#ifndef _URL_ROUTE_PUB_H_
#define _URL_ROUTE_PUB_H_

#include <net/netfilter/nf_conntrack.h>
#include <net/netfilter/nf_conntrack_service.h>
#include <net/netfilter/nf_conntrack_module_space.h>

typedef unsigned char       uint8;
typedef unsigned int        uint32;

#define INTERFACE_MAX_LEN   16      /* 接口名称最大长度 */
#define INTERFACE_MAX_COUNT 16      /* 接口最大数量 */

typedef enum {
    URL_ROUTE_GET_FLOW_ITF,         /* 获取流私有空间的接口信息 */
    URL_ROUTE_TYPE_MAX
} url_route_type;


/**
 * url_route_get_flow_interface - 获取流的选路结果
 * @skb         :报文skb
 * @itf         :一维数组用于获取接口组信息
 * @itf_switch  :是否开启接口断网保障, 开启：1，未开启：0
 * return       ：成功：接口数量，失败：返回0；
 */
typedef uint8 (*url_route_get_flow_interface_t)(struct sk_buff *skb, uint32 *itf, uint8 *itf_switch);

static inline uint8 url_route_get_flow_interface(struct sk_buff *skb, uint32 *itf, uint8 *itf_switch)
{
    url_route_get_flow_interface_t func;

    func = nf_ct_get_service(NF_CT_MOD_URL_ROUTE, URL_ROUTE_GET_FLOW_ITF);
    if (!func) {
        return 0;
    }

    return func(skb, itf, itf_switch);
}

#endif /* _URL_ROUTE_PUB_H_ */