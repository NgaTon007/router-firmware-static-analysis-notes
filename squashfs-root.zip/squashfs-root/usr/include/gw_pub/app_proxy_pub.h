#ifndef _APP_PROXY_PUB_H_
#define _APP_PROXY_PUB_H_

#include <gw_pub/app_identify_pub.h>

/* 兼容为拆分的版本，在app_identify中会调到 */
enum {
    SHOW_ROUTE_ENHANCE_DETAIL_DEFAULT,
    SHOW_ROUTE_ENHANCE_DETAIL_UNKNOWN,
    SHOW_ROUTE_ENHANCE_DETAIL_TCP,
    SHOW_ROUTE_ENHANCE_DETAIL_HTTP,
    SHOW_ROUTE_ENHANCE_DETAIL_MAX
};
#define PROXY_ENABLE_DEFAULT            1
#define PROXY_HTTP_ENABLE_DEFAULT       1
#define PROXY_UDP_ENABLE_DEFAULT        1
#define PROXY_UDP_ENHANCE_ENABLE_DEFAULT 1
#define PROXY_ORI_T_ENABLE_DEFAULT      1
#ifdef CONFIG_EG_URL_ROUTE
#define PROXY_DNS_ENABLE_DEFAULT        1
#else
#define PROXY_DNS_ENABLE_DEFAULT        0
#endif

#define PROXY_SHOW_PER_PRCB             20
#define PROXY_SHOW_PER_MAX              120
#define PROXY_SHOW_BUF_SIZE             (PROXY_SHOW_PER_PRCB * PROXY_SHOW_PER_MAX)

typedef struct proxy_show_detail_s {
    int pos;
    int type;
} proxy_show_detail_t;










#endif