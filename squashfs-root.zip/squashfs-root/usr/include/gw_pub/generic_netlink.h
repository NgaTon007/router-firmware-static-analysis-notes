/*
 * Copyright(C) 2012 Network. All rights reserved.
 */
/*
 * generic_netlink.h
 * Original Author:  yhb, 2012-1-19
 *
 * ����ͨ��netlink�׽��ֵĺ���
 *
 * History
 *
 */
 #ifndef _SD_NET_GENERIC_NETLINK_H_
#define _SD_NET_GENERIC_NETLINK_H_

#include <linux/genetlink.h>
#include <sys/socket.h>
#include <errno.h>

/*
 * Generic macros for dealing with netlink sockets. Might be duplicated
 * elsewhere. It is recommended that commercial grade applications use
 * libnl or libnetlink and use the interfaces provided by the library
 */
#define GENLMSG_DATA(glh)	((void *)(NLMSG_DATA(glh) + GENL_HDRLEN))
#define GENLMSG_PAYLOAD(glh)	(NLMSG_PAYLOAD(glh, 0) - GENL_HDRLEN)
#define NLA_DATA(na)		((void *)((char*)(na) + NLA_HDRLEN))
#define NLA_PAYLOAD(len)	(len - NLA_HDRLEN)

/* Maximum size of response requested or message sent */
#undef NL_MAX_MSG_SIZE 
#define NL_MAX_MSG_SIZE 2048

typedef struct msgtemplate {
    struct nlmsghdr n;
    struct genlmsghdr g;
    char buf[NL_MAX_MSG_SIZE];
} msgtemplate;

#if 0
/* ��Linux�ں˷�����Ϣ */
int genl_send_msg(int sd, __u16 nlmsg_type, __u32 nlmsg_pid,
	     __u8 genl_cmd, __u8 genl_version, __u16 nla_type,
	     void *nla_data, int nla_len);
/* �첽��Linux�ں˷�����Ϣ */
int genl_async_send_msg(int sd, __u16 nlmsg_type, __u32 nlmsg_pid,
	     __u8 genl_cmd, __u8 genl_version, __u16 nla_type,
	     void *nla_data, int nla_len);
#endif

static inline int genl_send_cmd_priv(int sd, __u16 nlmsg_type, __u32 nlmsg_pid, __u8 genl_cmd, __u16 nla_type,
            void *nla_data, int nla_len, int dump)
{
    char *buf;
    int r, buflen;
    struct nlattr *na;
    struct sockaddr_nl nladdr;
    struct msgtemplate msg;

    msg.n.nlmsg_len = NLMSG_LENGTH(GENL_HDRLEN);
    msg.n.nlmsg_type = nlmsg_type;
    if (dump) {
        msg.n.nlmsg_flags = NLM_F_REQUEST | NLM_F_DUMP;
    } else {
        msg.n.nlmsg_flags = NLM_F_REQUEST;
    }
    msg.n.nlmsg_seq = 0;
    msg.n.nlmsg_pid = nlmsg_pid;
    msg.g.cmd = genl_cmd;
    msg.g.version = 0x1;
    na = (struct nlattr *) GENLMSG_DATA(&msg);
    na->nla_type = nla_type;
    na->nla_len = nla_len + 1 + NLA_HDRLEN;
    memcpy(NLA_DATA(na), nla_data, nla_len);
    msg.n.nlmsg_len += NLMSG_ALIGN(na->nla_len);

    buf = (char *)&msg;
    buflen = msg.n.nlmsg_len;
    memset(&nladdr, 0, sizeof(nladdr));
    nladdr.nl_family = AF_NETLINK;
    while ((r = sendto(sd, buf, buflen, 0, (struct sockaddr *)&nladdr, sizeof(nladdr))) < buflen) {
        if (r > 0) {
            buf += r;
            buflen -= r;
        } else if (errno != EAGAIN) {
            return -1;
        }
    }

    return 0;
}

/* ���ݼ������ƻ�ȡ�����*/
static inline int genl_get_family_id(int sd, char *family_name)
{
    struct msgtemplate ans;
    int id = 0, rc;
    struct nlattr *na, *ghr;
    int rep_len;

    rc = genl_send_cmd_priv(sd, GENL_ID_CTRL, 0, CTRL_CMD_GETFAMILY, CTRL_ATTR_FAMILY_NAME,
            (void *)family_name, strlen(family_name) + 1, 0);
    if (rc < 0) {
        return 0;
    }

    rep_len = recv(sd, &ans, sizeof(ans), 0);
    if (ans.n.nlmsg_type == NLMSG_ERROR || (rep_len < 0) || !NLMSG_OK((&ans.n), rep_len)) {
        return 0;
    }

    ghr = (struct nlattr *)GENLMSG_DATA(&ans);

    na = (struct nlattr *)((char *) ghr + NLA_ALIGN(ghr->nla_len));
    if (na->nla_type == CTRL_ATTR_FAMILY_ID) {
        if (strcmp(NLA_DATA(ghr), family_name) != 0) {
            return 0;
        }
        id = *(__u16 *)NLA_DATA(na);
    }

    return id;
}

#endif/* _SD_NET_GENERIC_NETLINK_H_ */

