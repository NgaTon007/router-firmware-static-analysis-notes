/*
 * log.h
 * Original Author: yewenjun, 2023-08-10
 *
 * History:
 */
#ifndef __NETIFINFO_LOG_H__
#define __NETIFINFO_LOG_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <inttypes.h>

#define LOG_LEV_LEN             16
#define NETIFINFO_FILE_LEN      128
#define NETIFINFO_FILE_SIZE     20
#define NUMBER_20               20
#define NUMBER_200              200
#define NUMBER_1000             1000
#define NUMBER_1024             1024
#define NUMBER_1900             1900
#define NETIFINFO_LOG_DIR       "/tmp/netifinfo"
#define LOG_FILE_NAME           "/tmp/netifinfo/netifinfo.log"
#define ERR_LOG                 "/tmp/netifinfo/error.log"
#define LISTEN_LOG              "/tmp/netifinfo/listener.log"
#define PARSER_LOG              "/tmp/netifinfo/parser.log"
#define NOTIFY_LOG              "/tmp/netifinfo/notifier.log"
#define SOCK_LOG                "/tmp/netifinfo/register_user.log"
#define REG_LOG                 "/tmp/netifinfo/register_server.log"
#define USER_LOG                "/tmp/netifinfo/user.log"
#define QUERY_LOG               "/tmp/netifinfo/netifinfo_query.log"

/* ��־�ȼ����� */
typedef enum log_level_e {
    LDEBUG = 0,
    LINFO,
    LWARN,
    LERROR,
    LEV_TYPE_MAX
} log_level_t;

#ifndef __LEVEL_STR__
#define __LEVEL_STR__
/* ������־�ȼ��ַ���ѯ���� */
static const char LEVEL_STR[][LOG_LEV_LEN] = {
    "DEBUG",
    "INFO",
    "WARNING",
    "ERROR",
    "null"
};
#endif /* __LEVEL_STR__ */

/* ������־�ȼ��ַ�ӳ��� */
#define LEV_STR(LEVEL)  ({LEVEL_STR[(LEVEL)];})

/* ������־Ŀ¼ */
int netifinfo_debug_init(void);

/* ��¼ָ���ȼ�����־���ݵ�ָ�����ļ��� */
void netifinfo_debug(int level, char *file, const char *fmt, ...);

/* netifinfo ���������־ */
#define LRUN(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, LOG_FILE_NAME, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, \
        ##arg); \
} while (0)

/* netifinfo ������д�����־ */
#define LERR(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, ERR_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__,##arg); \
} while (0)

/* ����״̬�仯������־ */
#define LLISTEN(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, LISTEN_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, \
        ##arg); \
} while (0)

/* ����״̬�仯������־ */
#define LPARSE(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, PARSER_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, \
        ##arg); \
} while (0)

/* ����״̬�仯ͨ����־ */
#define LNOTIFY(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, NOTIFY_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, \
        ##arg);\
} while (0)

/* ҵ��ע����־ */
#define LREG(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, REG_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, ##arg); \
} while (0)

/* socket�ӿ�ר����־ */
#define LSOCK(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, SOCK_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, ##arg);\
} while (0)

/* ҵ��������־ - �����ڵ��� */
#define LUSER(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, USER_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, ##arg);\
} while (0)

/* ��Ϣ��ѯ��־ */
#define LQUERY(LEVEL, fmt, arg...) do { \
    netifinfo_debug(LEVEL, QUERY_LOG, "[%s] %s [%d]: "fmt"\n", LEV_STR(LEVEL), __FILE__, __LINE__, \
        ##arg);\
} while (0)

/* �ж��ļ��Ƿ���� */
bool netifinfo_is_file_exists(const char *filename);

/* ������־�ȼ� */
int netifinfo_loglev_set(log_level_t level);

#endif /* __NETIFINFO_LOG_H__ */
