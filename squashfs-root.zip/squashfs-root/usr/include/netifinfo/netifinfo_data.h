/*
 * netifinfo_data.h
 * Original Author: yewenjun, 2024-01-05
 *
 * History:
 */
#ifndef __NETIFINFO_DATA_H__
#define __NETIFINFO_DATA_H__

#include "netifinfo.h"

#define NETIFINFO_NOTIFY_MSG_NODE_GET(notify_msg, notify_msg_len, NODE_TYPE) do { \
    notify_msg = (NODE_TYPE *)malloc(sizeof(NODE_TYPE)); \
    if (notify_msg == NULL) { \
        LNOTIFY(LERROR, #NODE_TYPE " allocation failed"); \
        break; \
    } \
    memset(notify_msg, 0, sizeof(NODE_TYPE)); \
    notify_msg_len = sizeof(NODE_TYPE); \
} while (0)

/* sending event message to reg_info */
int netifinfo_event_data_send(event_msg_t *pnode, reg_info_t *reg_info);

#endif /* __NETIFINFO_DATA_H__ */
