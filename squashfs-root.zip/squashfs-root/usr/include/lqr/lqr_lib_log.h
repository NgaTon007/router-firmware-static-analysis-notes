/*
 * lqr_lib_log.h
 *
 *  Created on: 2025-08-19
 *      Author: zhangjianwei1
 */

#ifndef _LQR_LIB_LOG_H_
#define _LQR_LIB_LOG_H_

#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/timeb.h>

typedef enum log_level_e {
    LQR_LOG_ERROR   = 0,
    LQR_LOG_WARNING = 1,
    LQR_LOG_INFO    = 2,
    LQR_LOG_DEBUG   = 3,
    LQR_LOG_ALL
} log_level_t;

#define LOG_ERROR(fmt, arg...) do { \
    lqr_lib_log(LQR_LOG_ERROR, " %s %s() [%d] [ERROR] "fmt, __FILE__, __func__, __LINE__, ##arg); \
} while (0)

#define LOG_WARNING(fmt, arg...) do { \
    lqr_lib_log(LQR_LOG_WARNING, " %s %s() [%d] [WARNING] "fmt, __FILE__, __func__, __LINE__, ##arg); \
} while (0)

#define LOG_INFO(fmt, arg...) do { \
    lqr_lib_log(LQR_LOG_INFO, " %s %s() [%d] [INFO] "fmt, __FILE__, __func__, __LINE__, ##arg); \
} while (0)

#define LOG_DEBUG(fmt, arg...) do { \
    lqr_lib_log(LQR_LOG_DEBUG, " %s %s() [%d] [DEBUG] "fmt, __FILE__, __func__, __LINE__, ##arg); \
} while (0)

int lqr_lib_log(log_level_t level, char *fmt, ...);

#endif /* _LQR_LIB_LOG_H_ */
