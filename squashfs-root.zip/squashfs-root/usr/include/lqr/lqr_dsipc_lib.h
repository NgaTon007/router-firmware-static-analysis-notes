#ifndef _LQR_DSIPC_LIB_H_
#define _LQR_DSIPC_LIB_H_

#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <pthread.h>
#include <sd_thread/sd_thread.h>
#include <dsipc/ds_server.h>

#define LQR_CLTI_NAME_LEN                        17
#define IFNAMSIZ                                 16
#define LQR_DS_SOCKET_PATH                        "/tmp/lqr/.DS_LQR"
#define LQR_CLTI_NUM                              128
#define LQR_PTHREAD_STACK_SIZE                    (1024 * 26)
#define LQR_MODULENAME_MLLB                       "mllb"
#define LQR_MODULENAME_SDWAN                      "sdwan"

typedef enum {
    LQR_EVENT_QUALITY_V4_UP,        /* 接口质量ipv4 up事件 */
    LQR_EVENT_QUALITY_V4_DOWN,      /* 接口质量ipv4 down 事件*/
    LQR_EVENT_QUALITY_V6_UP,        /* 接口质量ipv6 up 事件*/
    LQR_EVENT_QUALITY_V6_DOWN,      /* 接口质量ipv6 down 事件*/
    LQR_EVENT_QUALITY_SHOW_MLLB,    /* mllb模块全量查询事件 */
    _LQR_EVENT_TYPE_MAX
} lqr_event_quality_type_e;

typedef enum {
    _LQR_DS_TYPE_UNUSED,
    LQR_DS_INTF_UP,                     /* 接口up */
    LQR_DS_INTF_DOWN,                   /* 接口down */
    _LQR_DS_TYPE_MAX
} lqr_intf_quality_type_e;

typedef struct lqr_clt_info {
    char name[LQR_CLTI_NAME_LEN];                  /*模块名*/
    char intf_name[IFNAMSIZ];                      /* 接口名,eg:wan,wan1*/
    char ipv4_quality_status;                      /* 接口的ipv4质量 */
    char ipv6_quality_status;                      /* 接口的ipv6质量 */
} lqr_clt_info_t;

typedef struct {
    unsigned char cltnum;
    lqr_clt_info_t clt_info[LQR_CLTI_NUM];
} lqr_ds_msg_t;

void lqr_ds_client_dereg_event(void);
int lqr_ds_client_reg_event(long events, void (*event_handle_func)(__u8, __u16, char *));
int lqr_ds_client_func_call(__u8 code, __u16 data_len, void *data);

#endif /* _LQR_DSIPC_LIB_H_ */
