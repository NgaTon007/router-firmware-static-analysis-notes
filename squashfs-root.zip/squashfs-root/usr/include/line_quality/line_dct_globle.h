#ifndef LINE_DCT_GLOBLE_H
#define LINE_DCT_GLOBLE_H

#include <stdio.h>
#include <sd_thread/sd_thread.h>
#include <dsipc/ds_server.h>

#define LINE_DCT_DS_SOCKET_PATH         "/tmp/.DS_LINE_QUALITY"
#define LINE_ICMP_REAL_ICMP_INFO_FILE   "/tmp/icmp_info/icmp_info.json"
#define LINE_DCT_DS_INTF_LEN             16
#define LINE_DCT_INTF_NUM                256

#define LINE_DCT_EVENT_V4_UP          1 << 0    /* 接口ipv4 up */
#define LINE_DCT_EVENT_V4_DOWN        1 << 1    /* 接口ipv4 down */
#define LINE_DCT_EVENT_V6_UP          1 << 2    /* 接口ipv6 up */
#define LINE_DCT_EVENT_V6_DOWN        1 << 3    /* 接口ipv6 down */
#define LINE_DCT_EVENT_STATUS         1 << 4    /* 接口全量查询 */
#define LINE_DCT_EVENT_ADDR4_UPDATE   1 << 5    /* 接口IP4变更 */
#define LINE_DCT_EVENT_ADDR6_UPDATE   1 << 6    /* 接口IP6变更 */

typedef enum {
    _INE_DCT_DS_TYPE_UNUSED,
    LINE_DCT_DS_INTF_V4_UP,                     /* 接口ipv4 up */
    LINE_DCT_DS_INTF_V4_DOWN,                   /* 接口ipv4 down */
    LINE_DCT_DS_INTF_V6_UP,                     /* 接口ipv6 up */
    LINE_DCT_DS_INTF_V6_DOWN,                   /* 接口ipv6 down */
    LINE_DCT_DS_INTF_STATUS,                    /* 接口全量查询 */
    LINE_DCT_DS_INTF_ADDR4_UPDATE,              /* 接口IP4变更 */
    LINE_DCT_DS_INTF_ADDR6_UPDATE,              /* 接口IP6变更 */
    __LINE_DCT_DS_TYPE_MAX,
} line_dct_ds_type_e;

typedef struct {
    char intf_name[LINE_DCT_DS_INTF_LEN];       /* 接口名,eg:br-wan */
    char intf_ipv4_status;                      /* 接口的ipv4状态 */
    char intf_ipv6_status;                      /* 接口的ipv6状态 */
} line_dct_ds_intf_t;

/* 注册事件消息结构体 */
typedef struct {
    char intf_name[LINE_DCT_DS_INTF_LEN];       /* 接口名,eg:br-wan */
} line_ds_reg_msg_t;

/*
* 客户端主动查询接口状态结构体
*/
typedef struct {
    __u16 intf_num;
    line_dct_ds_intf_t intf_info[LINE_DCT_INTF_NUM];
} line_ds_call_msg_t;

/* line_dct_ds_client_reg_event - 注册事件
* @events              : 关心的事件
* @event_handle_func   : 事件处理函数
* @master              : 伪线程管理器
* return: -1 for error, 0 for success.
*/
int line_dct_ds_client_reg_event(long events, void (*event_handle_func)(__u8, __u16, char *));

/* 
*line_dct_ds_client_dereg_event - 解注册事件
*/
void line_dct_ds_client_dereg_event();

/**
 * line_dct_ds_client_func_call - 调用domain socket将函数调用信息发送给服务端
 * @server_path: domain_socket服务端地址
 * @code: 函数编码
 * @data_len: 消息结构的长度，即data的长度
 * @data: 存放消息结构的缓冲区，同时保存发送和接收的消息
 *
 * return: -1 for error, 0 for success.
 */
int line_dct_ds_client_func_call(__u8 code, __u32 data_len, void *data);

#endif /* LINE_DCT_GLOBLE_H */

