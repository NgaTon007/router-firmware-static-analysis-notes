#!/bin/sh
/usr/sbin/wan_ip_mnt.elf &