#!/bin/sh

nat_log_monitor()
{
	local PROC_RESTART_CMD="/etc/init.d/nat_log restart > /dev/null 2>&1"
	local proc_num
	cap=$(uci show nat_log.main|grep 1)
	if [ -z $cap ]; then
		exit 0
	fi
	proc_num=$(ps -w |grep -w "nat_log.elf" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 ]; then
		eval $PROC_RESTART_CMD
	fi

}

#main
nat_log_monitor

exit 0
