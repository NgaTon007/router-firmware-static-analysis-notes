#!/bin/sh
. /usr/share/libubox/jshn.sh

mkdir -p /tmp/sddir/oam/http_client/
log_file="/tmp/sddir/oam/http_client/check_service.log"
log_file_bak="/tmp/sddir/oam/http_client/check_service.log.bak"
restart_file="/tmp/sddir/oam/http_client/service_restart.log"
restart_file_bak="/tmp/sddir/oam/http_client/service_restart.log.bak"

if [ ! -f "/tmp/etc/sw_cap.json" ]; then
    return
fi

cap=$(sw_cap_opt_get.sh "/usr/sbin/http_client.elf")
if [ "$cap" == "0" ]; then
    return
fi

enable=`uci -q get http_client.@http_client[0].enable |xargs echo`
if [ "$enable"x != "1"x ] ; then
    return
fi

# Set log size (byte)
max_log_size=10240

if [ ! -f /tmp/.http_status_err_cnt ]; then
    echo 0 > /tmp/.http_status_err_cnt
fi
failure_count=$(cat /tmp/.http_status_err_cnt)
old_failure_count=$failure_count

# Use curl to access the specified address
response=$(timeout -t 2 dev_sta get -m http_client_status|jq .)

# Check if the response is empty
if [ -z "$response" ]; then
    # If no response, increment the counter
    failure_count=$((failure_count + 1))
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Error, current failure count: $failure_count" >> "$log_file"

    # If failure count reaches 5, restart the service
    if [ "$failure_count" -ge 5 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - restarting http_client..." >> "$restart_file"
        /etc/init.d/http_client restart
        # Reset counter
        failure_count=0
    fi
else
    json_load "$response" 2>/dev/null >/dev/null
    json_get_var upgrading upgrading 2>/dev/null >/dev/null
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Response received upgrading: $upgrading" >> "$log_file"
    if [ "$upgrading" == "0" ]; then
        failure_count=0
    else
        failure_count=$((failure_count + 1))
        echo "$(date '+%Y-%m-%d %H:%M:%S') - upgrading, current count: $failure_count" >> "$log_file"
        echo "$(date '+%Y-%m-%d %H:%M:%S') - upgrading, status: $response" >> "$log_file"

        # If failure count reaches 5, restart the service
        if [ "$failure_count" -ge 5 ]; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') - restarting http_client..." >> "$restart_file"
            /etc/init.d/http_client restart
            # Reset counter
            failure_count=0
        fi
    fi
fi

if [ "$old_failure_count" != "$failure_count" ]; then
    echo $failure_count > /tmp/.http_status_err_cnt
fi

size=$(stat -c %s $log_file 2>/dev/null)
if [ "$size" != "" -a "$size" -ge "$max_log_size" ]; then
    mv $log_file $log_file_bak
fi

size=$(stat -c %s $restart_file 2>/dev/null)
if [ "$size" != "" -a "$size" -ge "$max_log_size" ]; then
    mv $restart_file $restart_file_bak
fi

