#!/bin/sh
. /lib/functions.sh

LOG_DIR="/tmp/account_mgr/debug"
LOG_PATH="$LOG_DIR/third_party_user_update.log"
LOCK_FILE="/tmp/thirdAccount.lock"

# ������־Ŀ¼
mkdir -p "$LOG_DIR"
mkdir -p "$(dirname "$LOCK_FILE")"
touch "$LOCK_FILE"
chmod 644 "$LOCK_FILE"
exec >> "$LOG_PATH" 2>&1

# ��־��¼����
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

# ���崦��ÿ��section�Ļص�����
process_each_section() {
    local expire_time username
    config_get expire_time "$1" "expire_time"
    config_get username "$1" "username"
    
    log "section: $1, username: $username, expire_time: $expire_time"
    
    if [ -n "$expire_time" ] && 
       [ "$expire_time" -eq "$expire_time" ] 2>/dev/null && 
       [ "$expire_time" -ne 0 ] && 
       [ $(date +%s) -gt "$expire_time" ]; then
        log "del expired user: $username"
        uci delete "third_party_mgr.$1"
        processed_count=$((processed_count + 1))
    fi
}

# ��������
process_users() {
    local processed_count=0
    
    log "start processing..."
    config_load third_party_mgr
    config_foreach process_each_section third_party
    if [ $processed_count -gt 0 ]; then
        uci commit third_party_mgr
        log "success, deleted $processed_count expired users"
        account_mgr_cmd.elf -R -t third_party 2>/dev/null
    else
        log "no expired users found"
    fi
}

# ������
apiService_enable=$(jq -e '.eweb.apiService // 0' /tmp/rg_device/rg_device.json 2>/dev/null) || apiService_enable=0
apiService_enable=1

if [ "${apiService_enable:-0}" -eq 1 ]; then
    # ���Ի�ȡ��
    if flock -n -x "$LOCK_FILE" -c "true"; then
        log "lock acquired, starting processing"
        process_users
    else
        log "lock busy, skipping processing"
    fi
else
    log "apiService not enabled"
fi
