#!/bin/sh

if [ -x /usr/sbin/monitor_radiusd_mem.sh ]; then
    if ! pgrep -f monitor_radiusd_mem.sh > /dev/null 2>&1; then
        /usr/sbin/monitor_radiusd_mem.sh &
    fi
fi
