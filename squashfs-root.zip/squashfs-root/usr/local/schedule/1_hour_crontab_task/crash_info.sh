#!/bin/sh

sh /usr/sbin/crash_info.sh
