#!/bin/sh

TMP_KEYINFO_LOG_PATH="/tmp/keyinfo_log/keyinfo_log.log"
ROOT_KEYINFO_LOG_PATH="/root/keyinfo_log.log"
keyinfo_log_lock="/tmp/keyinfo_log.lock"

if [ -f "$TMP_KEYINFO_LOG_PATH" ]; then
    (
        flock -x 90
        if [ ! -f "$ROOT_KEYINFO_LOG_PATH" ]; then
            cp $TMP_KEYINFO_LOG_PATH $ROOT_KEYINFO_LOG_PATH
        else
            md5_tmp="$(md5sum ${TMP_KEYINFO_LOG_PATH} | awk '{print $1}')"
            md5_root="$(md5sum ${ROOT_KEYINFO_LOG_PATH} | awk '{print $1}')"
            if [ "${md5_tmp}" != "${md5_root}" ]; then
                cp $TMP_KEYINFO_LOG_PATH $ROOT_KEYINFO_LOG_PATH
            fi
        fi
        flock -u 90
    )90>"$keyinfo_log_lock"
fi
