#!/bin/sh

lua /usr/sbin/devRemark.lua
