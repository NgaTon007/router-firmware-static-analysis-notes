#!/bin/sh

if [ -f "/usr/sbin/xlog_server_domain_monitor.lua" ]; then
    /usr/bin/lua /usr/sbin/xlog_server_domain_monitor.lua
fi
