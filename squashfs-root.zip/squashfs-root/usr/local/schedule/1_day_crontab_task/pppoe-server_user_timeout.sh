#!/bin/sh
. /lib/functions.sh
. /usr/share/libubox/jshn.sh

TIMEOUT_PATH="/etc/sd_config/single/pppoeserver_user_timeout.json"
LOG_DIR="/tmp/pppoe-server/debug"
LOG_PATH="$LOG_DIR/pppoe-server_user_timeout.log"
BATCH_SIZE=100
MAX_RETRIES=3
RETRY_DELAY=1
LOG_MAX_LINES=200
web_node=$(product capacity.web)

# ������־Ŀ¼
mkdir -p "$LOG_DIR"
exec >> "$LOG_PATH" 2>&1

# ״̬����
processed_count=0
total_processed=0
batch_number=1

rotate_log() {
    [ -f "$LOG_PATH" ] && {
        local line_count=$(wc -l < "$LOG_PATH")
        [ "$line_count" -ge $LOG_MAX_LINES ] && {
            tail -n $((LOG_MAX_LINES/2)) "$LOG_PATH" > "${LOG_PATH}.tmp"
            mv "${LOG_PATH}.tmp" "$LOG_PATH"
        }
    }
}

# ��־��¼����
log() {
    rotate_log
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

# ��ʼ��JSON�ṹ
init_json() {
    json_init
    json_add_string "timeout" "1"
    json_add_array "list"
}

# �ύ��������
submit_batch() {
    local json_data
    json_close_array
    json_data=$(json_dump)
    
    log "submit  #$batch_number ($1)"

    dev_config update -m pppoeserver_user "$json_data"
    total_processed=$((total_processed + $1))

    return 0
}

# ���������û�
process_user() {
    local user_time user_name user_enable user_pwd enc_type timeout
    
    config_get user_time "$1" "dealline" || return
    config_get user_name "$1" "name" || return
    config_get user_enable "$1" "enable" || return 0
    config_get user_pwd "$1" "passwd" || return
    config_get enc_type "$1" "enc_type" "0"

    # ����ʣ������
    user_time="${user_time} 00:00:00"
    timeout=$(($(date -d "$user_time" +%s 2>/dev/null) - $(date +%s))) || return
    timeout=$((timeout / 86400))

    # ����Ƿ���Ҫ����
    [ $timeout -ge 0 ] && return
    [ "$user_enable" != "1" ] && return

    # ���ӵ�JSON
    json_add_object ""
    json_add_string "old" "$user_name"
    json_add_object "new"
    json_add_string "passwd" "$user_pwd"
    json_add_string "encType" "$enc_type"
    json_add_string "enable" "0"
    json_add_string "src" "regular"
    json_close_object
    json_close_object

    # ���ο���
    processed_count=$((processed_count + 1))
    if [ $processed_count -ge $BATCH_SIZE ]; then
        submit_batch $processed_count || return 1
        batch_number=$((batch_number + 1))
        processed_count=0
        init_json
    fi
}

init_json

LDATE=$(date +%s)
remind_enable=$(jq -e ".${web_node}.spt_expire_remind // 0" /tmp/sd_device/sd_device.json 2>/dev/null) || remind_enable=0
expired_user_enable=$(uci -q get pppoeserver_global.global.expired_user_enable) || expired_user_enable=0

if [ "${remind_enable:-0}" -eq 0 ] || [ "${expired_user_enable:-0}" != "1" ]; then
    config_load pppoeserver_user
    config_foreach process_user pppoeserver_user || {
        log "error: submit #$batch_number"
        exit 1
    }
fi

# �ύ���һ������
[ $processed_count -gt 0 ] && {
    submit_batch $processed_count || exit 1
}

log "success!total timeout user: $total_processed"
exit 0