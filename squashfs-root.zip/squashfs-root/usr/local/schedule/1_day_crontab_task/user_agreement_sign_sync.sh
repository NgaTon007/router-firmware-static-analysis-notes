#!/bin/sh

# �û�Э��ǩ���б�ͬ���ű�
# ���ܣ����û�Э��ǩ���б�ͬ���������е�����ES�豸

# ��־����
. /usr/lib/shell/log.sh
log_init "/tmp/user_agreement_sign" "user_agreement_sign_sync.log" 100

# ����Ƿ�Ϊ���豸
is_master_device() {
    local master_info=$(dev_sta get -m master 2>/dev/null)

    [ $? -ne 0 ] && {
        return 1
    }

    [ -z "$master_info" ] && {
        return 1
    }

    # ��֤JSON��ʽ����ȡip�ֶ�
    local ip_addr=$(echo "$master_info" | jq -r '.ip // empty' 2>/dev/null)
    
    [ $? -ne 0 ] && {
        return 1
    }

    [ -z "$ip_addr" ] && {
        return 1
    }

    # �ж��Ƿ�Ϊ���豸 (ip����127.0.0.1)
    if [ "$ip_addr" = "127.0.0.1" ]; then
        return 0
    else
        return 1
    fi
}

# ��ȡnetworkId
get_network_id() {
    local network_id=$(uci -q get mqtt.mqtt.networkId)
    [ -z "$network_id" ] && {
        log "Failed to get networkId"
        exit 1
    }
    echo "$network_id"
}

# ��ȡES�豸�б�
get_es_devices() {
    local devices_json=$(dev_sta get -m esw_neighbor "{\"networkId\":\"$1\"}")
    [ $? -ne 0 ] || [ -z "$devices_json" ] && {
        log "Failed to get ES device list"
        exit 1
    }
    echo "$devices_json"
}

# ��ȡ�û�Э��ǩ���б�
get_user_agreement() {
    local agreement_json=$(ac_config get -m user_agreement_sign)
    [ $? -ne 0 ] || [ -z "$agreement_json" ] && {
        log "Failed to get user agreement list"
        exit 1
    }
    echo "$agreement_json"
}

# ͬ�����õ��豸
sync_to_device() {
    local ip="$1" sn="$2" agreement_json="$3"

    if esw set -i "$ip" -sn "$sn" -url user_agreement_sign.cgi "$agreement_json" >/dev/null 2>&1; then
        return 0
    else
        log "Failed to sync to $ip ($sn)"
        return 1
    fi
}

# ������ͬ���豸
parse_and_sync() {
    local devices_json="$1" agreement_json="$2"
    local total=0 success=0 skip=0

    # ��ȡ�豸����
    local devices_array
    if echo "$devices_json" | jq -e '.neighbor' >/dev/null 2>&1; then
        devices_array=$(echo "$devices_json" | jq -c '.neighbor')
    else
        devices_array="$devices_json"
    fi

    local device_count=$(echo "$devices_array" | jq '. | length')
    [ "$device_count" -eq 0 ] && {
        log "No ES devices found"
        return 0
    }

    # �����豸
    for i in $(seq 0 $((device_count-1))); do
        local device=$(echo "$devices_array" | jq -r ".[$i]")
        local ip=$(echo "$device" | jq -r '.ip // empty')
        local sn=$(echo "$device" | jq -r '.devSN // empty')
        local notsame=$(echo "$device" | jq -r '.notsame // "false"')

        # ������Ч�豸
        [ -z "$ip" ] || [ -z "$sn" ] && {
            log "Skip invalid device: IP=$ip, SN=$sn"
            skip=$((skip+1))
            continue
        }

        # �������벻һ���豸
        [ "$notsame" = "true" ] && {
            log "Skip password mismatch device: IP=$ip, SN=$sn"
            skip=$((skip+1))
            continue
        }

        total=$((total+1))
        sync_to_device "$ip" "$sn" "$agreement_json" && success=$((success+1))
    done

    log "Sync completed: $total total, $success success, $skip skipped"
}

# ������
main() {
    # �ж��Ƿ�Ϊ���豸��ֻ�����豸��ͬ��
    if is_master_device; then
		local network_id=$(get_network_id)
		local devices_json=$(get_es_devices "$network_id")
		local agreement_json=$(get_user_agreement)
		parse_and_sync "$devices_json" "$agreement_json"
    else
        exit 0
    fi
}

# �ű����
main "$@"
