#!/bin/sh
LOG_FILE="/tmp/ubusd_monitor.log"

debug_log_file()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -gt 1000 ] && { echo > ${LOG_FILE}; }
    fi
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    echo -e "${cur_time} ${1}" >> $LOG_FILE
}
#main
ubus list network > /dev/null  2>&1
[ $? -eq 0 ] && { return; }

#异常，删除ubusd进程
debug_log_file "ubusd process exception, reload..."
ubusd_pids="$(ps | grep -w "/sbin/ubusd" | grep -v grep | awk '{print $1}')"
[ -n "$ubusd_pids" ] && { debug_log_file "kill ubusd pids:$ubusd_pids..."; kill -9 $ubusd_pids; }
mkdir -p /tmp/run
#procd会自动启动/sbin/ubusd
if [ -f /etc/init.d/ubus ]; then
    /etc/init.d/ubus start
fi 
sleep 5
if [ -f /lib/functions/elisten_function.sh ]; then
    . /lib/functions/elisten_function.sh
    network_restart
else
    /etc/init.d/network restart
fi 

/etc/init.d/mqtt restart
/etc/init.d/easydisc restart
/etc/init.d/stad restart
/etc/init.d/rlog restart
