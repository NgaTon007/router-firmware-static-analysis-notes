#!/bin/sh
product_class=$(uci get sysinfo.@sysinfo[0].product_class)
software_version=$(uci get sysinfo.@sysinfo[0].software_version)
rlog_enable=$(uci get syslog.main.enable)
process_list=""
logfile="/tmp/procd_respawn.log"
directory="/tmp/ap_log/all/system_monitor"
rlog_file="$directory/pcd_respawn"

if [ ! -f "$logfile" ] || [ ! -d "$directory" ] || [ $rlog_enable == 0 ]; then
    exit 1
fi

if [ -f "$rlog_file" ]; then
    rm "$rlog_file"
fi

while IFS= read -r line
do
    exit_time=$(echo "$line" | awk -F", " '{print $1}' | awk -F":" '{print $2}')
    respawn_process=$(echo "$line" | awk -F", " '{print $2}' | awk -F":" '{print $2}')
    process_list="$process_list{\"exit_time\":\"$exit_time\",\"respawn_process\":\"$respawn_process\"},"
done < "$logfile"

process_list=${process_list%?}

current_timestamp=$(date +%s)

json_data="{\"type\":\"procd_respawn\",\"product_class\":\"$product_class\",\"software_version\":\"$software_version\",\"time\":\"$current_timestamp\",\"data\":{\"process_list\":[$process_list]}}"

echo "$json_data" >$rlog_file

rm $logfile
