#!/bin/sh
passwad_log=/tmp/log/openvpn/openvpn-password.log

openvpn_monitor()
{
    local proc_num
    
    [ ! -f $passwad_log ] && {
       return 
    }
    passwad_num=`cat $passwad_log | wc -l`
    if [ $passwad_num -gt 500 ];then
        echo " " >$passwad_log
    fi
    
}
#main
openvpn_monitor
