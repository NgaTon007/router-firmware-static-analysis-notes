#!/bin/sh
# refresh_quotaIntfTemp.sh
# Purpose: Periodically clean up expired quotaIntfTemp temporary traffic quota records, checking each ts entry individually
# Logic:
#   - cycleType=once: do not delete
#   - cycleType=day:  if current date > date of ts, delete the ts entry
#   - cycleType=month: based on cycleDay, if current time >= cycleDay 00:00:00 of the month after the ts month, delete the ts entry
# Finally write back quotaIntfTemp in a single dev_config set call

LOG_DIR="/tmp/run/quota"
LOG_FILE="${LOG_DIR}/refresh_quotaIntfTemp.log"
LOG_MAX_SIZE=20480

mkdir -p "$LOG_DIR" 2>/dev/null

log() {
	local sz
	if [ -f "$LOG_FILE" ]; then
		sz=$(wc -c <"$LOG_FILE" 2>/dev/null || echo 0)
		if [ "$sz" -gt "$LOG_MAX_SIZE" ]; then
			local tmp="${LOG_FILE}.tmp"
			tail -c 5120 "$LOG_FILE" > "$tmp" 2>/dev/null
			mv "$tmp" "$LOG_FILE" 2>/dev/null
		fi
	fi
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE" 2>/dev/null
}
web_node=$(product capacity.web)
quotaIntfTemp=$(jq -r ".${web_node}.quotaIntfTemp // 0" /tmp/sd_device/sd_device.json 2>/dev/null) || quotaIntfTemp=0
if [ "$quotaIntfTemp" -ne 1 ]; then
    log "quotaIntfTemp is disabled (value=$quotaIntfTemp), exiting"
    exit 0
fi
# Get quotaIntf config
quota_intf_json=$(dev_config get -m quotaIntf 2>/dev/null)
if [ -z "$quota_intf_json" ]; then
	log "Failed to get quotaIntf config, exit"
	exit 0
fi

# Get quotaIntfTemp config
quota_temp_json=$(dev_config get -m quotaIntfTemp 2>/dev/null)
if [ -z "$quota_temp_json" ]; then
	log "Failed to get quotaIntfTemp config, exit"
	exit 0
fi

# Get all name entries from quotaIntfTemp list
temp_names=$(echo "$quota_temp_json" | jq -r '.list[]?.name // empty' 2>/dev/null)
if [ -z "$temp_names" ]; then
	log "quotaIntfTemp list is empty, nothing to process"
	exit 0
fi

# Get the number of days in a given month (handles leap year)
days_in_month() {
	local y=$1 m=$2
	case $m in
		1|3|5|7|8|10|12) echo 31 ;;
		4|6|9|11) echo 30 ;;
		2)
			if [ $((y % 400)) -eq 0 ] || { [ $((y % 4)) -eq 0 ] && [ $((y % 100)) -ne 0 ]; }; then
				echo 29
			else
				echo 28
			fi
			;;
		esac
}

now=$(date +%s)
result_json="$quota_temp_json"
changed=0

for temp_name in $temp_names; do
	# Find matching config in quotaIntf by name
	cycle_type=$(echo "$quota_intf_json" | jq -r --arg n "$temp_name" \
		'.list[] | select(.name==$n) | .cycleType // empty' 2>/dev/null)

	if [ -z "$cycle_type" ]; then
		log "[$temp_name] no matching config found in quotaIntf, skip"
		continue
	fi

	case "$cycle_type" in
	once)
		log "[$temp_name] cycleType=once, no action needed"
		continue
		;;
	day)
		# Get all ts values from temp_list for this name (from original data)
		ts_list=$(echo "$quota_temp_json" | jq -r --arg n "$temp_name" \
			'.list[] | select(.name==$n) | .temp_list[]?.ts // empty' 2>/dev/null)

		if [ -z "$ts_list" ]; then
			log "[$temp_name] cycleType=day, no ts records, skip"
			continue
		fi

		for ts in $ts_list; do
			# Next day 00:00:00 after the date of ts
			ts_date=$(date -d "@$ts" '+%Y-%m-%d' 2>/dev/null)
			if [ -z "$ts_date" ]; then
				log "[$temp_name] cycleType=day, ts=$ts date parse failed, skip"
				continue
			fi
			ts_midnight=$(date -d "$ts_date 00:00:00" '+%s' 2>/dev/null)
			next_day_ts=$((ts_midnight + 86400))

			if [ "$now" -ge "$next_day_ts" ]; then
				log "[$temp_name] cycleType=day, ts=$ts expired(next_day=$next_day_ts, now=$now), removing entry"
				result_json=$(echo "$result_json" | jq --arg n "$temp_name" --arg t "$ts" \
					'(.list[] | select(.name==$n) | .temp_list) |= map(select(.ts != $t))')
				changed=1
			else
				log "[$temp_name] cycleType=day, ts=$ts not expired, keep"
			fi
		done
		;;
	month)
		cycle_day=$(echo "$quota_intf_json" | jq -r --arg n "$temp_name" \
			'.list[] | select(.name==$n) | .cycleDay // empty' 2>/dev/null)

		if [ -z "$cycle_day" ]; then
			log "[$temp_name] cycleType=month, cycleDay not found, skip"
			continue
		fi

		ts_list=$(echo "$quota_temp_json" | jq -r --arg n "$temp_name" \
			'.list[] | select(.name==$n) | .temp_list[]?.ts // empty' 2>/dev/null)

		if [ -z "$ts_list" ]; then
			log "[$temp_name] cycleType=month, no ts records, skip"
			continue
		fi

		for ts in $ts_list; do
			# Get year and month of ts
			ts_year=$(date -d "@$ts" '+%Y' 2>/dev/null)
			ts_month=$(date -d "@$ts" '+%m' 2>/dev/null)

			if [ -z "$ts_year" ] || [ -z "$ts_month" ]; then
				log "[$temp_name] cycleType=month, ts=$ts date parse failed, skip"
				continue
			fi

			# Strip leading zero for arithmetic, then calculate next month
			ts_month_val=$(echo "$ts_month" | sed 's/^0*//')
			[ -z "$ts_month_val" ] && ts_month_val=0
			next_month=$((ts_month_val + 1))
			next_year=$ts_year
			if [ "$next_month" -gt 12 ]; then
				next_month=1
				next_year=$((ts_year + 1))
			fi

			# Zero-pad cycleDay and month
			cycle_day_fmt=$(printf '%02d' "$cycle_day")
			next_month_fmt=$(printf '%02d' "$next_month")

			# Timestamp of next month's cycleDay 00:00:00
			threshold_ts=$(date -d "${next_year}-${next_month_fmt}-${cycle_day_fmt} 00:00:00" '+%s' 2>/dev/null)

			if [ -z "$threshold_ts" ]; then
				# If cycleDay exceeds days in the month, use the last day of that month
				last_day=$(days_in_month "$next_year" "$next_month")
				last_day_fmt=$(printf '%02d' "$last_day")
				threshold_ts=$(date -d "${next_year}-${next_month_fmt}-${last_day_fmt} 00:00:00" '+%s' 2>/dev/null)

				if [ -z "$threshold_ts" ]; then
					log "[$temp_name] cycleType=month, ts=$ts unable to calculate threshold time, skip"
					continue
				fi
			fi

			if [ "$now" -ge "$threshold_ts" ]; then
				log "[$temp_name] cycleType=month(cycleDay=$cycle_day), ts=$ts expired(threshold=$threshold_ts, now=$now), removing entry"
				result_json=$(echo "$result_json" | jq --arg n "$temp_name" --arg t "$ts" \
					'(.list[] | select(.name==$n) | .temp_list) |= map(select(.ts != $t))')
				changed=1
			else
				log "[$temp_name] cycleType=month(cycleDay=$cycle_day), ts=$ts not expired, keep"
			fi
		done
		;;
	*)
		log "[$temp_name] unknown cycleType=$cycle_type, skip"
		;;
	esac
done

# Write back: remove nodes with empty temp_list, then set all at once
if [ "$changed" -eq 1 ]; then
	result_json=$(echo "$result_json" | jq -c '.list |= map(select(.temp_list | length > 0)) | del(.configId, .configTime, .currentTime)')
	log "Expired entries detected, executing dev_config set -m quotaIntfTemp to update config"
	dev_config set -m quotaIntfTemp "$result_json"
else
	log "No expired entries, no update needed"
fi

log "refresh_quotaIntfTemp completed"
exit 0