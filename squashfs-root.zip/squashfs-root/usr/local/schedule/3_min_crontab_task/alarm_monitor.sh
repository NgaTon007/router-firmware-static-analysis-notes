#!/bin/sh
. /usr/share/libubox/jshn.sh

alarm_monitor() {
	echo `date` > /tmp/alarm/monitor.log
	
	#内存泄露时，重启进程。设备进程内存达到3M重启进程
	#ps：R86灰度版本从ap设备发现内存泄露，未找到原因，暂时先使用规避方法处理，后续处理完再去掉
	def_VmRSS=3500
	
	pid=`ps |grep alarm.elf|grep -v grep|awk '{print $1}'`
	echo "pid:$pid" >> /tmp/alarm/monitor.log
	
	VmRSS=`cat /proc/$pid/status |grep VmRSS|awk '{print $2}'`
	echo "VmRSS:$VmRSS" >> /tmp/alarm/monitor.log
	
	if [ $VmRSS -gt $def_VmRSS ];then
		echo "$VmRSS > $def_VmRSS" >> /tmp/alarm/monitor.log
		/etc/init.d/alarm restart &
		return
	else
		echo "$VmRSS < $def_VmRSS" >> /tmp/alarm/monitor.log
	fi
	
	#R86版本进程mosq异常卡死，重启设备，未找到原因，暂时先使用规避方法处理，后续处理完再去掉

	local json_str=$(ubus -t 20 call alarm monitor)
	echo "$json_str"
	if [ -z "$json_str" ]; then
		echo "ubus call is timeout. /etc/init.d/alarm restart..." >> /tmp/alarm/monitor.log
		/etc/init.d/alarm restart &
		return
	fi

	json_load "$json_str"
	json_get_var ret "ret"

	if [ "$ret" = "true" ];then
		echo "alarm ubus is running..." >> /tmp/alarm/monitor.log
	else
		echo "alarm ubus is error. /etc/init.d/alarm restart..." >> /tmp/alarm/monitor.log
		/etc/init.d/alarm restart &
	fi
}

#main
alarm_monitor
