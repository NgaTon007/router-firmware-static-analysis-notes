#!/bin/sh

# debug
debug() {
    local curTime=$(date '+%Y-%m-%d %H:%M:%S')
    local debugFile="/tmp/alarm/alarm_exec.log"
    
    [ ! -d "/tmp/alarm" ] && { mkdir -p "/tmp/alarm"; }
    
    [ -f "$debugFile" ]&& {
        local fileSize=$(du -shk $debugFile | awk '{print $1}')
        # debug 文件大小控制为20K
        if [ $fileSize -ge 10 ];then
            mv $debugFile ${debugFile}.old
        fi
    }
    
    echo -e "[$curTime] $1" >> $debugFile
}

# 单实例检测
check_instance_is_running()
{
    local lockfile=$1
    local scriptname=`basename $0`
    local CURRENT_PID=$$

    if [ -f $lockfile ]; then
        prepid=`cat $lockfile`
        #当前pid 不等于锁文件pid，检查锁文件pid是否在运行
        if [ "$$" != "${prepid}" ]; then
            if [ -z "`ps | grep ${prepid} |grep -v 'grep' | grep $scriptname`" ]; then
                echo "$$" > $lockfile
            else
                debug "current_pid:$CURRENT_PID another $scriptname is already running!"
                exit 1
            fi
        fi
    else
        echo "$$" > $lockfile
    fi
}

# ----主函数----
LOG_DIR="/tmp/alarm"
LOCK_FILE="$LOG_DIR/$(basename $0).lock"
[ ! -d "$LOG_DIR" ] && { mkdir -p "$LOG_DIR"; }
check_instance_is_running "$LOCK_FILE"

# 调用告警源
ALARM_USER_DIR="/usr/local/alarm/bin"
[ -d $ALARM_USER_DIR ] && {
    debug "start"
    for SCRIPT in $(ls $ALARM_USER_DIR)
    do
        if [ "$1" != "test" ]; then
            echo "lua $ALARM_USER_DIR/$SCRIPT"
            lua $ALARM_USER_DIR/$SCRIPT
        else
            debug "lua $ALARM_USER_DIR/$SCRIPT test"
            lua $ALARM_USER_DIR/$SCRIPT test
        fi
        sleep 1
    done
    debug "end"
}
