#! /usr/bin/lua
local lfs = require "lfs"
local cjson = require "cjson";
local tool = require "dev.tools.common"
local SNOSVPN_DIR = "/tmp/pptp/updown/"
local snosvpn = require "utils.debug"

function debug_init()
    snosvpn.debug_init(table.concat({SNOSVPN_DIR, "log/"}), "updown.log", 100, snosvpn.INFO, "1");
end

function file_size_limit()
    if (tool.file_exist(SNOSVPN_DIR) == false) then
        return;
    end
    for f in lfs.dir(SNOSVPN_DIR) do
        local file = table.concat({SNOSVPN_DIR, f});
        local old_file = table.concat({SNOSVPN_DIR, f, "_old"});
        attr = lfs.attributes(file)
        assert (type(attr) == "table")
        if (attr.mode ~= "directory") then
            snosvpn.lua_debug(snosvpn.INFO, "File: %s", file)
            snosvpn.lua_debug(snosvpn.INFO, table.concat({"Size: ", attr.size}))
            if (attr.size > 10000) then
                os.rename(file, old_file)
            end
        end
    end
end

------------------------------------------main----------------------------------------------------------
debug_init()
file_size_limit()
