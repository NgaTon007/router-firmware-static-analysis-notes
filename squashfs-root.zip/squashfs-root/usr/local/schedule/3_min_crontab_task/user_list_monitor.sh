#!/bin/sh
. /usr/share/libubox/jshn.sh

user_list_monitor() {
	echo `date` > /tmp/user_list/monitor.log

	local json_str=$(ubus -t 120 call user_list monitor)
	echo "$json_str"
	if [ -z "$json_str" ]; then
		echo "ubus call is timeout. /etc/init.d/user_list restart..." >> /tmp/user_list/monitor.log
		/etc/init.d/user_list restart &
		return
	fi

	json_load "$json_str"
	json_get_var ret "ret"

	if [ "$ret" = "true" ];then
		echo "user_list ubus is running..." >> /tmp/user_list/monitor.log
	else
		echo "user_list ubus is error. /etc/init.d/user_list restart..." >> /tmp/user_list/monitor.log
		/etc/init.d/user_list restart &
	fi
}

#main
user_list_monitor
