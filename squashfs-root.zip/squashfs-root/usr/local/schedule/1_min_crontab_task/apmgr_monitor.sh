#!/bin/sh

PROC="apmgr"
LOG_FILE="/tmp/apmgr/apmgr_monitor.log"

debug()
{
    local logsize=50  # 日志文件大小, 单位KB
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")

    if [ -f  ${LOG_FILE} ]; then
       local size=$(du -shk $LOG_FILE | awk '{print $1}' | tr -d ' \n\t')

        [ $size  -gt $logsize ] && {
            mv -f ${LOG_FILE} ${LOG_FILE}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

proc_restart()
{
    /etc/init.d/${PROC} restart >/dev/null 2>&1 &
    exit 0
}

is_proc_ok()
{
    proc_num=$(ps -w |grep -w /sbin/apmgr |grep -v grep |wc -l)
    proc_ok=$(ps -w |grep -w /sbin/apmgr |grep -v grep |awk -F " " '{print $5}')
    if [ $proc_num -gt 1 ];then
        debug "proc_num: $proc_num"
        killall -9 apmgr
    elif [ $proc_num == 1 ];then
        if [ $proc_ok != "/sbin/apmgr" ];then
            debug "proc_ok: $proc_ok"
            killall -9 apmgr
        fi
    fi
}

check_proc_exist()
{
    #if [ -f "$IPKG_INSTROOT/lib/functions/procd.sh" ]; then
        #exit 0
    #else
    check=$(ps | grep apmgr | grep -v "grep\|log\|sh")
    [ -z "$check" ] && {
        debug "$PROC restart"
        proc_restart
    }
    #fi
}

check_ubus()
{
    local retry=6
    #监控apmgr的ubus是否异常
    proc_pid=$(ps -w |grep -w /sbin/apmgr |grep -v grep |awk -F " " '{print $1}')

    while  [ $retry -gt  0 ]; do
            ubus -t 8 call apmgr show_proc_status 2>&1 >/dev/null
            if [ $? != 0  ]; then
                let retry=retry-1
                debug "apmgr ubus abnormal, retry=$retry!"
                sleep 5
                continue
            else
                break
            fi 
    done

    if  [ $retry -eq 0 ]; then
        debug "apmgr ubus abnormal, restart apmgr !!!"
        kill -9 $proc_pid
    fi
}

main()
{
    local rlink_enable=$(uci -q get apmgr.global.rlink_enable)
    ##开apmesh功能，才检查进程状态
    [ "$rlink_enable" = "0" ] && {
        debug "rlink_enable is 0, just return!"
        return
    }

    is_proc_ok
    check_proc_exist

    #check_ubus

    return
}

main