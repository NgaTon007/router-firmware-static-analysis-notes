#!/bin/sh
FC_MONITOR_LOG="/tmp/flowctrl/fc_monitor.log"
FC_MONITOR_LOG_SIZE=5        # 日志文件大小, 单位KB; du最小都是4k，而且是4的整数倍，故不能设置小于4k。

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
	local file_size=$(du -shk $FC_MONITOR_LOG | awk '{print $1}' | tr -d ' \n\t')

	[ $file_size  -gt $FC_MONITOR_LOG_SIZE ] && {
		mv -f $FC_MONITOR_LOG ${FC_MONITOR_LOG}.old
	}

	echo -e "${cur_time} ${1}" >> $FC_MONITOR_LOG
}

fc_monitor()
{
	local PROC="flow_ctrl.elf"
	local PROC_RESTART_CMD="/etc/init.d/flowctrl.init restart > /dev/null 2>&1"
	local cap=$(sw_cap_opt_get.sh "/usr/sbin/flow_ctrl.elf")

	if [ "$cap" == "0" ]; then
		return
	fi

	fc_status=$(uci get flowctrl.@global[0].tc_switch)
	if [ $fc_status == "on" ]; then
		if [ ! -f "/tmp/flowctrl/flowctrl_config" ];then
			mkdir /tmp/flowctrl
			:> /tmp/flowctrl/flowctrl_config 2>/dev/null
			mkdir /tmp/flowctrl/fc_monitor.log 2>/dev/null
		fi

		proc_num=$(ps -w |grep -w "$PROC" |grep -v grep |wc -l)
		#非服务主动重启情况下，flowloop进程不存在才重启流控服务。(flow_start restart会重启flow_loopcheck)
		if [ $proc_num -eq 0 ]; then
			debug_log "fc_monitor restart flowctrl"
			eval $PROC_RESTART_CMD
		fi
	fi
}

#main
fc_monitor

exit 0