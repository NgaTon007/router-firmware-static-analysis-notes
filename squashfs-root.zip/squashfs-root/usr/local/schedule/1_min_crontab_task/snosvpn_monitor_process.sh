#! /bin/sh

### L2TP&PPTP
if [ -f "/usr/lib/snosvpn/snosvpn_monitor_process.lua" ]; then
    ubus -t 3 send "snosvpn_monitor_process"
fi

### SDWAN
if [ -f "/usr/sbin/web/sdwan_monitor_process.sh" ]; then
    /bin/sh /usr/sbin/web/sdwan_monitor_process.sh &
fi

### IPsec
if [ -f "/usr/sbin/web/ipsec_manage_process.sh" ]; then
    /bin/sh /usr/sbin/web/ipsec_manage_process.sh &
fi

### OpenVPN
if [ -f "/usr/sbin/web/openvpn_process_monitor.sh" ]; then
    /bin/sh /usr/sbin/web/openvpn_process_monitor.sh &
fi

### QualtiyRouing
if [ -f "/usr/sbin/web/qualityRouting_monitor_process.sh" ]; then
    /bin/sh /usr/sbin/web/qualityRouting_monitor_process.sh &
fi
