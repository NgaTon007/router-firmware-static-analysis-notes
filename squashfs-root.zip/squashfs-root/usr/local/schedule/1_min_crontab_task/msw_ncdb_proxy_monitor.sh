#!/bin/sh

process_cnt=`ps | grep /usr/sbin/msw_ncdb_proxy | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/msw_ncdb_proxy_init restart
fi
