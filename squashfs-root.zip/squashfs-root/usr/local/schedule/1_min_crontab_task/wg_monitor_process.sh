#!/bin/sh

. /usr/share/libubox/jshn.sh

wireguard_conf="/etc/sd_config/single/wireguard.json"
running_flag=0

check_conf_enable() {
    json_get_type val "serverlist"
        if [ -n "$val" ]; then
        json_select "serverlist"

        local index="1"
        while json_is_a ${index} object; do
            json_select "$index"
            json_get_var enable "enable"

            if [ "$enable" == "1" ]; then
                running_flag=1
                json_select ".."
                return
            fi

            index=$((index+1))
            json_select ".."
        done
    fi

    json_select ".."

    json_get_type val "clientlist"
        if [ -n "$val" ]; then
        json_select "clientlist"

        local index="1"
        while json_is_a ${index} object; do
            json_select "$index"
            json_get_var enable "enable"

            if [ "$enable" == "1" ]; then
                running_flag=1
                json_select ".."
                return
            fi

            index=$((index+1))
            json_select ".."
        done
    fi

    json_select ".."
}

process_cnt=`ps | grep /usr/sbin/wg.elf | grep -v grep | wc -l`

if [ ! -e "$wireguard_conf" ]; then
    ko_num=$(lsmod | grep wireguard | wc -l)
    if [ $ko_num -eq 1 ]; then
        rmmod wireguard  2>/dev/null
    fi
    return
fi

content=$(cat $wireguard_conf)

json_init
json_load "$content"
check_conf_enable
json_cleanup

if [ "$running_flag" -eq 0 ]; then
    /etc/init.d/wireguard stop 

    ko_num=$(lsmod | grep wireguard | wc -l)
    if [ $ko_num -eq 1 ]; then
        rmmod wireguard  2>/dev/null
    fi
    return
fi

forwardMode=$(uci -q get sysinfo.@sysinfo[0].forwardMode)
if [ "$process_cnt" == "0" -a "$forwardMode" == "ROUTER" ];then
    ko_num=$(lsmod | grep wireguard | wc -l)
    if [ $ko_num -eq 0 ]; then
        find /lib/modules/  -name "wireguard.ko" | xargs insmod 2>/dev/null
    fi

    /usr/sbin/wg.elf &

    rule=$(ip rule 2>/dev/null|grep -w 'lookup 330'|wc -l)
    if [ "$rule" -eq 0 ]; then
        ip rule add from all table 330 prio 330 2> /dev/null
    fi

    rule6=$(ip -6 rule 2>/dev/null|grep -w 'lookup 330'|wc -l)
    if [ "$rule6" -eq 0 ]; then
        ip -6 rule add from all table 330 prio 330 2> /dev/null
    fi

    rule=$(ip rule 2>/dev/null|grep -w 'lookup 530'|wc -l)
    if [ "$rule" -eq 0 ]; then
        ip rule add from all table 530 prio 530 2> /dev/null
    fi
fi
