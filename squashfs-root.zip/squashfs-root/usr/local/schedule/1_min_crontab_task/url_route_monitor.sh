#!/bin/sh

url_route_monitor()
{
	local PROC_RESTART_CMD="/etc/init.d/url_route restart > /dev/null 2>&1"
	local file_path="/etc/init.d/url_route"
	local proc_num

    # URL路由无配置时，不拉起用户进程
    config_cnt=`dev_config get -m urlRoute | jq .total 2>/dev/null`
    if [ "$config_cnt" == "\"0\"" ]; then
        return
    fi

	local cap=$(sw_cap_opt_get.sh "/usr/sbin/url_route.elf")
	if [ "$cap" == "0" ]; then
		return
	fi

	proc_num=$(ps -w |grep -w "url_route.elf" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 -a -e "$file_path" ]; then
		eval $PROC_RESTART_CMD
	fi
	
}

#main
url_route_monitor

exit 0