#!/bin/sh
. /usr/share/libubox/jshn.sh

check_ip() {
    IP=$1
    VALID_CHECK=$(echo $IP|awk -F. '$1<=255&&$2<=255&&$3<=255&&$4<=255{print "yes"}')
    if echo $IP|grep -E "^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$">/dev/null; then
        if [ ${VALID_CHECK:-no} == "yes" ]; then
            #IP available
            return 1
        else
            return 0
        fi
    else
        return 0
    fi
}

miniupnpd_monitor() {
    local __up
	local tmpconf="/var/etc/miniupnpd.conf"
	enable=`uci -q get upnpd.config.enable_upnp |xargs echo`
	[ "$enable"x == "0"x ] && return
    ifname=$(cat /var/miniupnpd_ext_iface)
	last_ext_ip=$(cat $tmpconf | grep ext_ip)
	if [ -z "$last_ext_ip" ];then
		ip_addr=$(curl http://ip1.dynupdate.no-ip.com/ --connect-timeout 3 2>/dev/null)
		check_ip $ip_addr
		if [ "$?" == "1" ];then
			echo "ext_ip=${ip_addr}" >>$tmpconf
			/etc/init.d/miniupnpd restart
		else
			ip_addr=$(curl http://checkip.amazonaws.com/ --connect-timeout 3 2>/dev/null)
			check_ip $ip_addr
			if [ "$?" == "1" ];then
				echo "ext_ip=${ip_addr}" >>$tmpconf
				/etc/init.d/miniupnpd restart
			fi
		fi
		return
	fi
    local json_str=$(ubus call network.interface dump)
	json_load "$json_str"
	json_select interface
	index=1
	while json_get_type status $index && [ "$status" = object ]; do
		json_select $index >/dev/null
		json_get_var interface 'interface' >/dev/null
        if [ "$interface" == "$ifname" ]; then
			json_get_var up 'up' >/dev/null
			if [ "$up" == "0" ] ;then
				/etc/init.d/miniupnpd restart
				break
			fi
		fi
		index=`expr $index + 1`
		json_select ..
	done

	memory_usage=$(ps -f | grep "miniupnpd" | grep -v grep | awk '{print $5}')
	if [ "$memory_usage" -gt "5120" ]; then
		echo "Memory usage exceeds 5M. restart process miniupnpd"
		/etc/init.d/miniupnpd restart
	fi
}

#main
miniupnpd_monitor

exit 0