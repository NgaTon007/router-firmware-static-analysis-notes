#!/bin/sh

. /usr/lib/shell/log.sh
log_init "/tmp/crond" "crond_monitor.log" 100

SCHEDULE_PATH="/usr/local/schedule/*"
CROND_PATH="/tmp/crond"
PRE_FLAG="$CROND_PATH/.pre_time"

[ ! -f $PRE_FLAG ] && { stat -c %Z $SCHEDULE_PATH > $PRE_FLAG; }
pre_time=$(cat $PRE_FLAG)
cur_time=$(stat -c %Z $SCHEDULE_PATH)
log "pre_time:\n$pre_time"
log "cur_time:\n$cur_time"
if [ "$pre_time" == "$cur_time" ]; then
    log "no restart"
else
    echo "$cur_time" > $PRE_FLAG
    log "ready restart"
    /etc/init.d/schedule restart
fi

#ps_buf=$(ps|awk '{if ($4=="D"||$4=="Z") print}')
#log "$ps_buf"
#kill -9 $(echo "$ps_buf"|awk '{print $1}')
