#!/bin/sh

PROC="redbs_contrl"
LOG_FILE="/tmp/redbs/${PROC}_monitor.log"

debug()
{
    local logsize=50  # 日志文件大小, 单位KB
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")

    if [ -f  ${LOG_FILE} ]; then
       local size=$(du -shk $LOG_FILE | awk '{print $1}' | tr -d ' \n\t')

        [ $size  -gt $logsize ] && {
            mv -f ${LOG_FILE} ${LOG_FILE}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

process_cnt=`ps | grep /usr/sbin/redbs_contrl | grep -v grep | wc -l`

if [ -f "/usr/sbin/redbs_contrl" ]; then
    if [ "$process_cnt" == "0" ]; then
        debug "restart"
        /usr/sbin/redbs_contrl  >/dev/null 2>&1 &
    fi
fi

process_cnt2=`ps | grep 6380 | grep -v grep | wc -l`
if [ -f "/sbin/redishost.conf" ]; then
    if [ "$process_cnt2" == "0" ]; then
        debug "restart hostdb"
        /sbin/redis-server /sbin/redishost.conf  >/dev/null 2>&1 &
    fi
fi
