#!/bin/sh

PROC="enet_disp.elf"
LOG_FILE="/tmp/easyson/enet_disp_monitor.log"

debug()
{
    local logsize=50  # 日志文件大小, 单位KB
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")

    if [ -f  ${LOG_FILE} ]; then
       local size=$(du -shk $LOG_FILE | awk '{print $1}' | tr -d ' \n\t')

        [ $size  -gt $logsize ] && {
            mv -f ${LOG_FILE} ${LOG_FILE}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

proc_start()
{
    /etc/init.d/enet_disp start >/dev/null 2>&1 &
}

check()
{
    local chk=$(ps | grep -w enet_disp.elf | grep -v grep | wc -l)
    if [ $chk -eq 0 ]; then
        debug "restart $PROC"
        proc_start
    fi
}

main()
{
    check
    return
}

### 程序main流程 ###
main