#!/bin/sh

# 定义coredump文件所在目录
COREDUMP_DIR="/tmp/coredump/"

# 找到目录中包含nt_mgr的文件
files=$(find $COREDUMP_DIR -type f -name '*nt_mgr*')

# 初始化一个计数器
count=0

process_cnt=`ps | grep /usr/sbin/nt_mgr_v2.elf | grep -v grep | wc -l`

# 循环删除找到的文件
for file in $files
do
  count=$((count+1))  # 每次迭代时，计数器加1
  
  # 如果这不是第一次迭代，就删除文件
  if [ $count -ne 1 ]; then
    rm -f "$file"
  fi
done

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/nt_mgr_v2 restart
fi

