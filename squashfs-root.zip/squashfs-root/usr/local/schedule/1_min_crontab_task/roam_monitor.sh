#!/bin/sh
ROAM_MONITOR_LOG="/tmp/roam/roam_monitor.log"
ROAM_MONITOR_LOG_SIZE=5        # 日志文件大小, 单位KB; du最小都是4k，而且是4的整数倍，故不能设置小于4k。

mkdir -p "/tmp/roam/"

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
	local file_size=$(du -shk $ROAM_MONITOR_LOG | awk '{print $1}' | tr -d ' \n\t')

	[ $file_size  -gt $ROAM_MONITOR_LOG_SIZE ] && {
		mv -f $ROAM_MONITOR_LOG ${ROAM_MONITOR_LOG}.old
	}

	echo -e "${cur_time} ${1}" >> $ROAM_MONITOR_LOG
}

roam_monitor()
{
	local PROC="roam.elf"
	local PROC_RESTART_CMD="/etc/init.d/roam restart > /dev/null 2>&1"
	local proc_num

	proc_num=$(ps -w |grep -w "$PROC" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 ]; then
		debug_log "$PROC start"
		eval $PROC_RESTART_CMD
	fi
}

#main
roam_monitor

exit 0