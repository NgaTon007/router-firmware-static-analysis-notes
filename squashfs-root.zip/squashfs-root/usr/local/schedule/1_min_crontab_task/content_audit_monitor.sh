#!/bin/sh

content_audit_monitor()
{
	local PROC="content_audit.elf"
	local PROC_RESTART_CMD="/etc/init.d/content_audit restart > /dev/null 2>&1"
	local proc_num
	local cap=$(sw_cap_opt_get.sh "/usr/sbin/content_audit.elf")
	if [ "$cap" == "0" ]; then
		return
	fi
	proc_num=$(ps -w |grep -w "content_audit.elf" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 ]; then
		eval $PROC_RESTART_CMD
	fi
	
}

#main
content_audit_monitor

exit 0