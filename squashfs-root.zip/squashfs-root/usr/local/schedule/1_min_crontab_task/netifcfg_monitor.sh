#!/bin/sh

process_cnt=`ps | grep /usr/sbin/netifcfg.elf | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/netifcfg restart
    echo "$(date) netifcfg restart" >> /tmp/netifcfg/schedule_rec.log
fi
