#!/bin/sh

lua /usr/sbin/network_indicator_led.lua &
