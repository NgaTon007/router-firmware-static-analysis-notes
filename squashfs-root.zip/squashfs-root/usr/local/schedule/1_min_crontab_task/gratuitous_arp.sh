#!/bin/sh
. /usr/share/libubox/jshn.sh

logsize=10        # 日志文件大小, 单位KB
log_root="/tmp/arp_mng"
log_file="$log_root/gratuitous_arp.log"
lock_file="$log_root/lock"

interval="$1"

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    if [ -f  $log_file ]; then
       file_size=$(du -shk $log_file | awk '{print $1}' | tr -d ' \n\t')

        [ $file_size -gt $logsize ] && {
            mv -f $log_file ${log_file}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $log_file
}

rlog_check_instance_is_running()
{
    local lockfile=$1
    local scriptname=`basename $0`

    if [ -f $lockfile ]; then
        prepid=`cat $lockfile`
        #当前pid 不等于锁文件pid，检查锁文件pid是否在运行
        if [ "$$" != "${prepid}" ]; then
            if [ -z "`ps | grep ${prepid} |grep -v 'grep' | grep $scriptname`" ]; then
                echo "$$" > $lockfile
            else
                debug_log "Other instance is running"
                exit 1
            fi
        fi
    else
        echo "$$" > $lockfile
    fi
}

parameter_detection()
{
    [ -z "$interval" ] && {
        interval=10
    }
}

main()
{
    mkdir -p "$log_root"
    debug_log "start gratuitous_arp..."
    rlog_check_instance_is_running "$lock_file"
    parameter_detection

    data=$(cat /etc/config/network  | grep interface | grep lan* | awk '{print $3}' | sed "s/'//g") 
    for interface in $data
    do
        address=$(ip addr 2>/dev/null |grep -w "br-$interface" |grep inet |awk '{print $2}'| cut -d / -f 1) 
        if [ -n "$address" ]; then
            arping -I "br-$interface" -f  "$address" -c 1 -q
        fi
    done
    debug_log "end gratuitous_arp..."
}

main
