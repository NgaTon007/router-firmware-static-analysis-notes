#!/bin/sh
#
#切换上联eg的lan口地址池，easyson发送的广播报文会触发设备发送255的广播arp报文
#会产生255的未解析arp表项，设备每天处理最多100次这种故障(假定用户不会一天改变nat地址池超过100次)
#AP存在该问题，EG不存在该问题，见bug422563
#root@test:~# arp -a
#IP address       HW type     Flags       HW address            Mask     Device
#xxx.xxx.xxx.xxx    0x1         0x2         xx:xx:xx:xx:xx:xx     *        br-wan
#xxx.xxx.xxx.255  0x1         0x0         00:00:00:00:00:00     *        br-wan
#root@test:~#
#
# root@test:/tmp/easyson# cat mqtt_bcast_arp.log
# ? (xxx.xxx.xxx.xxx) at xx:xx:xx:xx:xx:xx [ether]  on br-wan
# ? (xxx.xxx.xxx.xxx) at <incomplete>  on br-wan
#通过脚本执行，show出来的是这个样子的。
MQTT_BCAST_ARP_TIMES="/tmp/easyson/easyson_bcast_arp_times"   #本脚本被调用的次数，每天清零一次
MQTT_BCAST_ARP_TIMES_MAX=1440 #24*3600/60  (crontab 1min执行一次)

MQTT_BCAST_ARP_CLEAR_TIMES="/tmp/easyson/easyson_bcast_arp_clear_times" #清除bcast ARP次数
MQTT_BCAST_ARP_CLEAR_TIMES_MAX=100
LOG_FILE="/tmp/easyson/easyson_bcast_arp.log"
debug_log_file()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -gt 1000 ] && { echo > ${LOG_FILE}; }
    fi
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

route_add_default_gw()
{
    proto=$(uci -q get network.wan.proto)
    [ -z "proto" ] && { echo "get proto empty, exit"; exit 1; }
    if [ "$proto" = "dhcp" ]; then
        kill -17 $(cat /var/run/udhcpc-br-wan.pid)
        sleep 1
        kill -16 $(cat /var/run/udhcpc-br-wan.pid)
        sleep 3
    elif [ "$proto" = "static" ]; then
        gateway=$(uci -q get network.wan.gateway)
        [ -z "gateway" ] && { echo "gw empty, exit"; exit 1; }
        route add default gw $gateway
    fi
}

#非EAP设备不执行该脚本
devType=$(uci -q get sysinfo.@sysinfo[0].dev_type)
[ "$devType" != "eap" ] && exit

#定时器crontab 20s钟执行一次，每天执行4320次
mkdir -p /tmp/easyson/
do_times=0
[ -f $MQTT_BCAST_ARP_TIMES ] && { do_times=$(cat $MQTT_BCAST_ARP_TIMES); }
[ -z "$do_times" ] && { do_times=0; }
if [ $do_times -gt $MQTT_BCAST_ARP_TIMES_MAX ]; then
    echo 0 > $MQTT_BCAST_ARP_TIMES
    echo 0 > $MQTT_BCAST_ARP_CLEAR_TIMES
    #debug_log_file "do bcast arp times gt $MQTT_BCAST_ARP_TIMES_MAX, reset!"
else
    #debug_log_file "inc, do arp clear check."
    do_times=$((do_times+1))
    echo "$do_times" > $MQTT_BCAST_ARP_TIMES
fi
clear_times=0
[ -f $MQTT_BCAST_ARP_CLEAR_TIMES ] && { clear_times=$(cat $MQTT_BCAST_ARP_CLEAR_TIMES); }
[ -z "$clear_times" ] && { clear_times=0; }
[ $clear_times -gt $MQTT_BCAST_ARP_CLEAR_TIMES_MAX ] && {
    #debug_log_file "bcast arp cleat times gt $MQTT_BCAST_ARP_CLEAR_TIMES_MAX. exit"
    exit 0
} #每天超过指定次数，则不再修复
localhost_ip=$(product capacity.localhost_ip)
master_ip=$(product capacity.master_ip)
swmng_ip=$(product capacity.swmng_ip)
[ -z "$localhost_ip" ] && { debug_log_file "get localhost_ip empty, exit"; exit 1; }
[ -z "$master_ip" ] && { debug_log_file "get master_ip empty, exit"; exit 1; }
[ -z "$swmng_ip" ] && { debug_log_file "get swmng_ip empty, exit"; exit 1; }
bcast_addr="$(ip addr show br-wan | grep -w inet | grep -v "$localhost_ip" | grep -v "$master_ip" | grep -v "$swmng_ip" | awk '{print $4}')"
[ -z "$bcast_addr" ] && { debug_log_file "get bcast_addr empty, exit."; exit 1; }
bcast_arp=$(arp -an | grep -wc "$bcast_addr")
[ $bcast_arp -gt 0 ] && {
    ifconfig br-wan down && ifconfig br-wan up
    sleep 1
    route_add_default_gw
    echo $((clear_times+1)) > $MQTT_BCAST_ARP_CLEAR_TIMES
    #debug_log_file "do arp clear, times $((clear_times+1))"
}
#debug_log_file "do clear arp finish."
exit 0



