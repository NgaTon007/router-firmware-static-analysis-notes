#!/bin/sh

SD_DEVICE="/tmp/sd_device/sd_device.json"
SNMP_CONFIG="/etc/sd_config/global/snmp*.json"
CONTACT_CONFIG="/etc/sd_config/global/contact*.json"
LOCATION_CONFIG="/etc/sd_config/global/location*.json"

webname=$(product capacity.web)
if [ -f $SD_DEVICE ]; then
    result=$(cat $SD_DEVICE | jq -r .$webname.snmp)
    # result等于0或者等于null时，删除相关配置文件
    if [ -z "$result" ] || [ "$result" = "null" ] || [ "$result" = "0" ]; then
        if [ -f $SNMP_CONFIG ]; then
            rm -f $SNMP_CONFIG
        fi
        if [ -f $CONTACT_CONFIG ]; then
            rm -f $CONTACT_CONFIG
        fi
        if [ -f $LOCATION_CONFIG ]; then
            rm -f $LOCATION_CONFIG
        fi
    fi
fi
