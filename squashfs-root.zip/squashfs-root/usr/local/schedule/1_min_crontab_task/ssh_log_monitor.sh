#! /bin/sh

BASE_DIR="/tmp/sshtunnel"
FILE_ESTABLISH="$BASE_DIR/establish.log.old"

# 日志模块，已做适配无需修改
LOG_DIR="$BASE_DIR"
LOG_NAME="$(basename $0.log)"
LOG_FILE="$LOG_DIR/$LOG_NAME"
LOG_MAX_LINE_NUM=200
log()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -ge $LOG_MAX_LINE_NUM ] && { mv -f $LOG_FILE ${LOG_FILE}.old; }
    else
        if [ ! -d ${LOG_DIR} ]; then
            mkdir $LOG_DIR
        fi
    fi
    if [ -n "$1" ]; then
        local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
        echo -e "${cur_time} ${1}" >> $LOG_FILE
    else
        echo -e "" >> $LOG_FILE
    fi
}

[ -f $FILE_ESTABLISH ] && {
    # cut不靠谱，当文件大小有变化时，获取值不准，有时候会获取空值
    # filesize=$(ls -l $FILE_ESTABLISH | cut -d ' ' -f 20)
    filesize=$(ls -l $FILE_ESTABLISH | awk '{printf $5}')
    # 不能mv重命名，重命名的文件还会继续增大
    [ $filesize -gt 10240 ] && {
        log "$FILE_ESTABLISH filesize:$filesize is great than 10240, remove it"
        rm -rf $FILE_ESTABLISH
    }
}
