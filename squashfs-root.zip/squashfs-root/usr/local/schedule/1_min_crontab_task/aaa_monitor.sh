#!/bin/sh

process_cnt=`ps | grep /usr/sbin/aaa.elf | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/aaa restart
fi
