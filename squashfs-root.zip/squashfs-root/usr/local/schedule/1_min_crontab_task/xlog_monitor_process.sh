#!/bin/sh
enable=`uci get xlog.main.enable`
process_path=`ps |grep xlog |grep -v grep | awk '{print $6}'`

if [ "$enable" == 1 ] && [ "$process_path" != "/usr/sbin/xlog.elf" ];then
    /etc/init.d/xlog start
fi 
