#!/bin/sh
NOIP_READY=/var/log/noipdns.log
LAST_STATUS_FILE="/var/log/noipdns.status"

noipdns_monitor()
{
    local PROC_STOP_CMD="/etc/init.d/noipdns stop > /dev/null 2>&1"
    local PROC_RESTART_CMD="/etc/init.d/noipdns start > /dev/null 2>&1"
    local proc_num
    local status
    local flag=0
    local szUserID=`uci get noipdns.@noipdns[0].szUserID`
	local szUserPWD=`uci get noipdns.@noipdns[0].szUserPWD`
    local use_ipv6=`uci get noipdns.@noipdns[0].use_ipv6`
    local use_ipv4_and_ipv6=`uci get noipdns.@noipdns[0].use_ipv4_and_ipv6 2>/dev/null`

    last_status=`cat $LAST_STATUS_FILE 2>/dev/null`
    #账号密码不存在，表示noipdns功能未开启
    [ "$szUserID"x == " "x ] && {
        exit 0
    }

    [ "$szUserPWD"x == " "x ] && {
        exit 0
    }
    #账号密码存在时，进程应该存在
    if [ "$use_ipv6" == "0" ];then
        proc_num=$(ps -w |grep "noipdns.elf" |grep -v grep |wc -l)
        if [ $proc_num -eq 0 ]; then
           flag=1
           break
        fi
        #进程存在时，文件应该存在
        [ ! -f $NOIP_READY ] && {
            flag=1
            break
        }
    else
        IPV6_EXIST=`ps -w | grep ddns_ipv6_noip |grep -v grep`
        [ -z "$IPV6_EXIST" ] && {
            flag=1
            break
        }
    fi

    #文件存在时，如果文件内不包含对应状态信息，那么就重新启动进程
    if [ "$use_ipv6" == "0" ]; then
        if grep -q "set to" $NOIP_READY
        then
            status="s"
        elif grep -q "auth failed" $NOIP_READY
        then
            status="passerror"
        elif grep -q "errorConnectFailed" $NOIP_READY
        then
            status="neterror"
        elif grep -q "No Hosts" $NOIP_READY
        then
            status="hosterror"
        elif grep -q "Hosts Err" $NOIP_READY
        then
            status="hosterror"
        elif grep -q "WANERROR" $NOIP_READY
        then
            status="wanerror"
        else
            status="get"
            flag=1
        fi
    elif [ "$use_ipv6" == "1" ] && [ "$use_ipv4_and_ipv6" != "1" ];then
        DATA_FILE="/var/run/ddns/ddns_ipv6_noip.dat"
        LOG_FILE="/var/log/ddns/ddns_ipv6_noip.log"
        ERR_FILE="/var/run/ddns/ddns_ipv6_noip.err"
        if grep -q "record good" $LOG_FILE 2>/dev/null || grep -q "record nochg" $LOG_FILE 2>/dev/null
        then
            status="s"
        elif grep -q "record badauth" $LOG_FILE 2>/dev/null
        then
            status="passerror"
        elif grep -q "connection timed out" $ERR_FILE 2>/dev/null \
            || grep "Get local IP" $LOG_FILE 2>/dev/null | grep -q "failed"
        then
            status="neterror"
        elif grep -q "record nohost" $LOG_FILE 2>/dev/null || grep -q "record notfqdn" $LOG_FILE 2>/dev/null || grep -q "nslookup" $ERR_FILE 2>/dev/null
        then
            status="hosterror"
        elif grep -q "No update send to DDNS Provider" $LOG_FILE 2>/dev/null \
            || grep -q "IP update not accepted by DDNS Provider" $LOG_FILE 2>/dev/null \
            || grep -q "Updating IP at DDNS provider failed" $LOG_FILE 2>/dev/null
		then
			status="neterror"
        elif grep -q "WANERROR" $DATA_FILE 2>/dev/null
        then
            status="wanerror"
        else
            status="get"
            flag=1
        fi
    elif [ "$use_ipv6" == "1" ] && [ "$use_ipv4_and_ipv6" == "1" ];then
        ipv4Status=""
        ipv6Status=""
        if grep -q "set to" $NOIP_READY
        then
            ipv4Status="s"
        elif grep -q "auth failed" $NOIP_READY
        then
            ipv4Status="passerror"
        elif grep -q "errorConnectFailed" $NOIP_READY
        then
            ipv4Status="neterror"
        elif grep -q "No Hosts" $NOIP_READY
        then
            ipv4Status="hosterror"
        elif grep -q "Hosts Err" $NOIP_READY
        then
            ipv4Status="hosterror"
        elif grep -q "WANERROR" $NOIP_READY
        then
            ipv4Status="wanerror"
        else
            ipv4Status="get"
            flag=1
        fi

        DATA_FILE="/var/run/ddns/ddns_ipv6_noip.dat"
        LOG_FILE="/var/log/ddns/ddns_ipv6_noip.log"
        ERR_FILE="/var/run/ddns/ddns_ipv6_noip.err"
        if grep -q "record good" $LOG_FILE 2>/dev/null || grep -q "record nochg" $LOG_FILE 2>/dev/null
        then
            ipv6Status="s"
        elif grep -q "record badauth" $LOG_FILE 2>/dev/null
        then
            ipv6Status="passerror"
        elif grep -q "connection timed out" $ERR_FILE 2>/dev/null \
            || grep "Get local IP" $LOG_FILE 2>/dev/null | grep -q "failed"
        then
            ipv6Status="neterror"
        elif grep -q "record nohost" $LOG_FILE 2>/dev/null || grep -q "record notfqdn" $LOG_FILE 2>/dev/null || grep -q "nslookup" $ERR_FILE 2>/dev/null
        then
            ipv6Status="hosterror"
        elif grep -q "No update send to DDNS Provider" $LOG_FILE 2>/dev/null \
            || grep -q "IP update not accepted by DDNS Provider" $LOG_FILE 2>/dev/null \
            || grep -q "Updating IP at DDNS provider failed" $LOG_FILE 2>/dev/null
        then
            ipv6Status="neterror"
        elif grep -q "WANERROR" $DATA_FILE 2>/dev/null
        then
            ipv6Status="wanerror"
        else
            ipv6Status="get"
            flag=1
        fi

        if [ "$ipv4Status"x != "s"x ]; then
            status=$ipv4Status
        elif [ "$ipv6Status"x != "s"x ]; then
            status=$ipv6Status
        else
            status="s"
        fi
    fi

    echo $status > $LAST_STATUS_FILE 2>/dev/null
    [ "$status"x != "$last_status"x ] && {
        exec 1>/tmp/null 2>&1
        dev_config update -m noipdns '{}' 2>/dev/null &
    }

    [ $flag -eq 1 ] && {
        eval $PROC_STOP_CMD
        eval $PROC_RESTART_CMD
    }
}

#main
noipdns_monitor

exit 0
