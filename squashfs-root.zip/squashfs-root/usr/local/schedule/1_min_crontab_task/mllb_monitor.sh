#!/bin/sh

CHECK_MLLB_STATE_LOG="/tmp/mllb/mllb_monitor.log"
CHECK_MLLB_STATE_LOG_SIZE=5        # ��־�ļ���С, ��λKB; du��С����4k��������4�����������ʲ�������С��4k��

mkdir -p "/tmp/mllb/"

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
	local file_size
	if [ -e $CHECK_MLLB_STATE_LOG ] ; then
		file_size=$(du -shk $CHECK_MLLB_STATE_LOG | awk '{print $1}' | tr -d ' \n\t')
	else
		file_size=0
	fi
	[ $file_size  -gt $CHECK_MLLB_STATE_LOG_SIZE ] && {
		mv -f $CHECK_MLLB_STATE_LOG ${CHECK_MLLB_STATE_LOG}.old
	}

	echo -e "${cur_time} ${1}" >> $CHECK_MLLB_STATE_LOG
}

mllb_monitor()
{
	local PROC="mllb.elf"
	local PROC_RESTART_CMD="/etc/init.d/mllb restart > /dev/null 2>&1"
	local proc_num
	local cap=$(sw_cap_opt_get.sh "/usr/sbin/mwan3")
	if [ "$cap" == "0" ]; then
		return
	fi
	proc_num=$(ps -w |grep -w "mllb.elf" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 ]; then
		debug_log "proc num : $proc_num "
		eval $PROC_RESTART_CMD
	fi
}

#main
mllb_monitor

exit 0
