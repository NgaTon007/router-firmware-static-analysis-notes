#!/bin/sh

sh /usr/sbin/flow_flip.sh &