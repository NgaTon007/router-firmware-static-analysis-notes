#!/bin/sh
IPV4_DATA_FILE="/var/run/ddns/ddns_ipv4.dat"
IPV6_DATA_FILE="/var/run/ddns/ddns_ipv6.dat"
STATUS_FILE="/var/log/ddns/ddns_status.log"
IPV4_ERR_FILE="/var/run/ddns/ddns_ipv4.err"
IPV6_ERR_FILE="/var/run/ddns/ddns_ipv6.err"
IPV4_LOG_FILE="/var/log/ddns/ddns_ipv4.log"
IPV6_LOG_FILE="/var/log/ddns/ddns_ipv6.log"
LAST_STATUS_FILE="/var/run/ddns/ddns.status"
ddns_monitor()
{
local PROC_RESTART_CMD="/etc/init.d/ddns restart > /dev/null 2>&1"
local proc_num_ipv4
local proc_num_ipv6
local status
local flag=0
local enabled=`uci get ddns.ddns.enabled`
local user=`uci get ddns.ddns.user`
local pass=`uci get ddns.ddns.pass`
local use_ipv6=`uci get ddns.ddns.use_ipv6`
local use_ipv4_and_ipv6=`uci get ddns.ddns.use_ipv4_and_ipv6 2>/dev/null`
#enabled为0时，表示dyndns功能未开启
[ "$enabled"x == "0"x ] && {
exit 0
}
[ "$user"x == " "x ] && {
exit 0
}
[ "$pass"x == " "x ] && {
exit 0
}
#enabled为1时，进程应该存在
proc_num_ipv4=$(ps -w |grep -wr "\-S ddns_ipv4" |grep -v grep |wc -l)
proc_num_ipv6=$(ps -w |grep -wr "\-S ddns_ipv6" |grep -v grep |wc -l)
if [ $proc_num_ipv4 -eq 0 ] && [ $proc_num_ipv6 -eq 0 ]; then
eval $PROC_RESTART_CMD
exit 0
fi
if [ "$use_ipv6" == "0" ];then
DATA_FILE=$IPV4_DATA_FILE
LOG_FILE=$IPV4_LOG_FILE
ERR_FILE=$IPV4_ERR_FILE
else
DATA_FILE=$IPV6_DATA_FILE
LOG_FILE=$IPV6_LOG_FILE
ERR_FILE=$IPV6_ERR_FILE
fi
#如果文件内不包含对应状态信息，那么就重新启动进程
#dyndns noip 3322 cloudware:"success"
if [ "$use_ipv4_and_ipv6"x != "1"x ];then
if grep -q "record good" $LOG_FILE 2>/dev/null || grep -q "record nochg" $LOG_FILE 2>/dev/null #aliyun
then
status="s"
elif grep -q "record badauth" $LOG_FILE 2>/dev/null \
|| grep -q "Unknown X-Auth-Key or X-Auth-Email" $DATA_FILE 2>/dev/null \
|| grep -q "Invalid format for X-Auth-Key header" $DATA_FILE 2>/dev/null \
|| grep -q "Specified access key is not found" $DATA_FILE 2>/dev/null \
|| grep -q "Specified signature is not matched" $DATA_FILE 2>/dev/null #aliyun
then
status="passerror"
elif grep -q "Failed" $ERR_FILE 2>/dev/null || grep -q "connection timed out" $ERR_FILE 2>/dev/null \
|| grep "Get local IP" $LOG_FILE 2>/dev/null| grep -q "failed"  2>/dev/null \
|| grep -q "DNS record type is invalid" $LOG_FILE 2>/dev/null \
|| grep -q "Could not resolve host" $LOG_FILE 2>/dev/null
then
status="neterror"
elif grep -q "record nohost" $LOG_FILE 2>/dev/null || grep -q "record notfqdn" $LOG_FILE 2>/dev/null \
|| grep -q "!yours" $DATA_FILE 2>/dev/null \
|| grep -q "nslookup" $ERR_FILE 2>/dev/null \
|| grep -q "Could not detect.*domain.tld" $LOG_FILE 2>/dev/null \
|| grep -q "Invalid domain name" $LOG_FILE 2>/dev/null \
|| grep -q "This record type cannot be proxied" $LOG_FILE 2>/dev/null \
|| grep -q "InvalidDomainName.NoExist" $DATA_FILE 2>/dev/null #aliyun
then
status="hosterror"
elif grep -q "Update successful" $LOG_FILE 2>/dev/null
then
status="s"
elif grep -q "cURL Error" $LOG_FILE 2>/dev/null \
|| grep -q "No update send to DDNS Provider" $LOG_FILE 2>/dev/null \
|| grep -q "IP update not accepted by DDNS Provider" $LOG_FILE 2>/dev/null \
|| grep -q "Updating IP at DDNS provider failed" $LOG_FILE 2>/dev/null
then
status="neterror"
elif grep -q "WANERROR" $STATUS_FILE 2>/dev/null
then
status="wanerror"
else
status="get"
flag=1
fi
else
if grep -q "record good" $IPV4_LOG_FILE 2>/dev/null || grep -q "record nochg" $IPV4_LOG_FILE 2>/dev/null #aliyun
then
ipv4Status="s"
elif grep -q "record badauth" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "Unknown X-Auth-Key or X-Auth-Email" $IPV4_DATA_FILE 2>/dev/null \
|| grep -q "Invalid format for X-Auth-Key header" $IPV4_DATA_FILE 2>/dev/null \
|| grep -q "Specified access key is not found" $IPV4_DATA_FILE 2>/dev/null \
|| grep -q "Specified signature is not matched" $IPV4_DATA_FILE 2>/dev/null #aliyun
then
ipv4Status="passerror"
elif grep -q "Failed" $IPV4_ERR_FILE 2>/dev/null || grep -q "connection timed out" $IPV4_ERR_FILE 2>/dev/null \
|| grep "Get local IP" $IPV4_LOG_FILE 2>/dev/null| grep -q "failed"  2>/dev/null \
|| grep -q "DNS record type is invalid" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "Could not resolve host" $IPV4_LOG_FILE 2>/dev/null
then
ipv4Status="neterror"
elif grep -q "record nohost" $IPV4_LOG_FILE 2>/dev/null || grep -q "record notfqdn" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "!yours" $IPV4_DATA_FILE 2>/dev/null \
|| grep -q "nslookup" $IPV4_ERR_FILE 2>/dev/null \
|| grep -q "Could not detect.*domain.tld" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "Invalid domain name" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "This record type cannot be proxied" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "InvalidDomainName.NoExist" $IPV4_DATA_FILE 2>/dev/null #aliyun
then
ipv4Status="hosterror"
elif grep -q "Update successful" $IPV4_LOG_FILE 2>/dev/null
then
ipv4Status="s"
elif grep -q "cURL Error" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "No update send to DDNS Provider" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "IP update not accepted by DDNS Provider" $IPV4_LOG_FILE 2>/dev/null \
|| grep -q "Updating IP at DDNS provider failed" $IPV4_LOG_FILE 2>/dev/null
then
ipv4Status="neterror"
elif grep -q "WANERROR" $STATUS_FILE 2>/dev/null
then
ipv4Status="wanerror"
else
ipv4Status="get"
flag=1
fi
if grep -q "record good" $IPV6_LOG_FILE 2>/dev/null || grep -q "record nochg" $IPV6_LOG_FILE 2>/dev/null #aliyun
then
ipv6Status="s"
elif grep -q "record badauth" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "Unknown X-Auth-Key or X-Auth-Email" $IPV6_DATA_FILE 2>/dev/null \
|| grep -q "Invalid format for X-Auth-Key header" $IPV6_DATA_FILE 2>/dev/null \
|| grep -q "Specified access key is not found" $IPV6_DATA_FILE 2>/dev/null \
|| grep -q "Specified signature is not matched" $IPV6_DATA_FILE 2>/dev/null #aliyun
then
ipv6Status="passerror"
elif grep -q "Failed" $IPV6_ERR_FILE 2>/dev/null || grep -q "connection timed out" $IPV6_ERR_FILE 2>/dev/null \
|| grep "Get local IP" $IPV6_LOG_FILE 2>/dev/null| grep -q "failed"  2>/dev/null \
|| grep -q "DNS record type is invalid" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "Could not resolve host" $IPV6_LOG_FILE 2>/dev/null
then
ipv6Status="neterror"
elif grep -q "record nohost" $IPV6_LOG_FILE 2>/dev/null || grep -q "record notfqdn" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "!yours" $IPV6_DATA_FILE 2>/dev/null \
|| grep -q "nslookup" $IPV6_ERR_FILE 2>/dev/null \
|| grep -q "Could not detect.*domain.tld" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "Invalid domain name" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "This record type cannot be proxied" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "InvalidDomainName.NoExist" $IPV6_DATA_FILE 2>/dev/null #aliyun
then
ipv6Status="hosterror"
elif grep -q "Update successful" $IPV6_LOG_FILE 2>/dev/null
then
ipv6Status="s"
elif grep -q "cURL Error" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "No update send to DDNS Provider" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "IP update not accepted by DDNS Provider" $IPV6_LOG_FILE 2>/dev/null \
|| grep -q "Updating IP at DDNS provider failed" $IPV6_LOG_FILE 2>/dev/null
then
ipv6Status="neterror"
elif grep -q "WANERROR" $STATUS_FILE 2>/dev/null
then
ipv6Status="wanerror"
else
ipv6Status="get"
flag=1
fi
if [ "$ipv4Status"x != "s"x ]; then
status=$ipv4Status
elif [ "$ipv6Status"x != "s"x ]; then
status=$ipv6Status
else
status="s"
fi
fi
last_status=`cat $LAST_STATUS_FILE 2>/dev/null`
echo $status > $LAST_STATUS_FILE 2>/dev/null
[ "$status"x != "$last_status"x ] && {
exec 1>/tmp/null 2>&1
dev_config update -m dyndns '{}' 2>/dev/null &
}
[ $flag -eq 1 ] && {
eval $PROC_RESTART_CMD
}
exit 0
}
#main
ddns_monitor
exit 0
