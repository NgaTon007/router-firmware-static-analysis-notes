#!/bin/sh

RESET_CNT_FILE="/proc/mt7621/reset_cnt"
TMP_FILE="/tmp/reset_cnt_tmp"
LOCK_FILE="/tmp/reset_cnt_lock"

RESTART_COMMAND="/sbin/hwnat_reload &"

lock_file() {
    exec 9>"$LOCK_FILE" || exit 1
    flock -n 9 || exit 1
}

unlock_file() {
    flock -u 9
    exec 9>&-
}

lock_file

if [ -f "$RESET_CNT_FILE" ]; then
    CURRENT_CNT=$(cat "$RESET_CNT_FILE")
else
    unlock_file
    return
fi

if [ -f "$TMP_FILE" ]; then
    LAST_CNT=$(cat "$TMP_FILE")
else
    echo "$CURRENT_CNT" > "$TMP_FILE"
    $RESTART_COMMAND
    unlock_file
    return
fi

if [ "$CURRENT_CNT" -gt "$LAST_CNT" ]; then
    $RESTART_COMMAND
fi

echo "$CURRENT_CNT" > "$TMP_FILE"

unlock_file

