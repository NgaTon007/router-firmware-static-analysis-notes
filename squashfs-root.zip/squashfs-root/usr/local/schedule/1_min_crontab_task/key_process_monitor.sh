#!/bin/sh
SW_CAP_PATH="/tmp/etc/sw_cap.json"
SAVE_PS_FILE="/tmp/save_ps"
if [ ! -f /lib/functions/elisten_function.sh ]; then
    logger "[ERROR] elisten not exist!"
    return;
fi
. /lib/functions/elisten_function.sh

logsize=10        # 日志文件大小, 单位KB
log_root="/tmp/key_process_monitor"

log_file="$log_root/key_process_monitor.log"
TMNGTD_INIT_FILE="/tmp/tmngtd/tmngtd_init_flag"
COUNTER_FILE="$log_root/counter"

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    if [ -f  $log_file ]; then
       file_size=$(du -shk $log_file | awk '{print $1}' | tr -d ' \n\t')

        [ $file_size  -gt $logsize ] && {
            mv -f $log_file ${log_file}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $log_file
}

ps > $SAVE_PS_FILE 2> /dev/null

check_and_restart_process()
{
    proc="$1"
    restart_cmd="$2"
    is_disable=$(cat $SW_CAP_PATH 2> /dev/null| grep -w "$proc" |grep '"0"' |wc -l)
    if [ $is_disable == '1' ]; then
        return
    fi

    if [ -f $SAVE_PS_FILE ]; then
        proc_num=$(cat $SAVE_PS_FILE 2> /dev/null |grep -w "$proc" |grep -v grep |wc -l)
        if [ $proc_num -eq 0 ]; then
            #进程个数为0，则重启
            debug_log "$proc not running, start it"
            eval $restart_cmd
        fi
    fi
}

    if [ ! -f  $log_file ]; then
        mkdir -p $log_root
        debug_log "key process monitor start..."
    fi

    #check lighttpd
    if [ -f "/etc/init.d/lighttpd" ]; then
        proc="lighttpd"
        restart_cmd="/etc/init.d/lighttpd restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check sd_syslog
    if [ -f "/etc/init.d/sd_syslog" ]; then
        proc="sd_syslog.elf"
        restart_cmd="/etc/init.d/sd_syslog restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check dnsmasq
    if [ -f "/etc/init.d/dnsmasq" ]; then
        proc="dnsmasq"
        #check_and_restart_process "$proc" "$restart_cmd"
        proc_num_1=$(cat $SAVE_PS_FILE 2> /dev/null  |grep -w dnsmasq |grep -v grep |grep -w root |wc -l)
        proc_num_2=$(cat $SAVE_PS_FILE 2> /dev/null  |grep -w "/etc/init.d/dnsmasq" |grep -v grep  |wc -l)
        if [ $proc_num_1 -eq 0 -a $proc_num_2 -eq 0 ]; then
            #进程个数为0或没有执行重启，则重启
            debug_log "$proc not running, start it"
            dnsmasqRestart
        fi
    fi

    #check tmngtd.elf
    if [ -f "/etc/init.d/tmngtd" ]; then
        proc="tmngtd.elf"
        restart_cmd="/etc/init.d/tmngtd restart > /dev/null 2>&1"
        # 解决bugid【1353370】：tmngtd进程未起来之前，过五分钟之后，再拉tmngtd进程
        if [ -f "$TMNGTD_INIT_FILE" ]; then
            check_and_restart_process "$proc" "$restart_cmd"
        else
            if [ ! -f "$COUNTER_FILE" ]; then
                echo "0" > "$COUNTER_FILE"
            fi
            counter=$(cat "$COUNTER_FILE")
            counter=$((counter + 1))
            echo "$counter" > "$COUNTER_FILE"
            if [ $counter -gt 5 ]; then
                touch "$TMNGTD_INIT_FILE"
            fi
        fi
    fi

    #stad
    if [ -f "/etc/init.d/stad" ]; then
        proc="stad.elf"
        restart_cmd="/etc/init.d/stad restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check rlog.elf
    if [ -f "/etc/init.d/rlog" ]; then
        proc="rlog.elf"
        restart_cmd="/etc/init.d/rlog restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check user_list.elf
    if [ -f "/etc/init.d/user_list" ]; then
        proc="user_list.elf"
        restart_cmd="/etc/init.d/user_list restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check sysinfo.elf
    if [ -f "/etc/init.d/sysinfo" ]; then
        proc="sysinfo.elf"
        restart_cmd="/etc/init.d/sysinfo restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check led_core.elf
    if [ -f "/etc/init.d/sd_led" ]; then
        proc="led_core.elf"
        restart_cmd="/etc/init.d/sd_led restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check /sbin/netifd
    if [ -f "/etc/init.d/network" ]; then
        proc="/sbin/netifd"
        restart_cmd="killall -9 udhcpc> /dev/null 2>&1; /etc/init.d/network restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check /sbin/ubusd
    if [ -f "/etc/init.d/ubus" ]; then
        proc="/sbin/ubusd"
        restart_cmd="/etc/init.d/ubus restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check selfchk_monitor
    if [ -f "/sbin/sd_dev_selfchk" ]; then
        proc="sd_dev_selfchk"
        restart_cmd="/sbin/sd_dev_selfchk &"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check elisten.elf
    if [ -f "/etc/init.d/elisten" ]; then
        proc="elisten.elf"
        restart_cmd="/etc/init.d/elisten restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi


    #check cwmp_notify.elf
    if [ -f "/etc/init.d/cwmp_notify" ]; then
        proc="cwmp_notify.elf"
        restart_cmd="/etc/init.d/cwmp_notify restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #exec cloud_upload_log.sh
    if [ -f "/sbin/cloud_upload_log.sh" ]; then
        #proc="cloud_upload_log.sh"
        # 1 min exec cloud_upload_log.sh
        /sbin/cloud_upload_log.sh & > /dev/null 2>&1
        #check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check cls-sshd
    if [ -f "/etc/init.d/cls-sshd" ]; then
        proc="/sbin/cls-sshd"
        restart_cmd="/etc/init.d/cls-sshd restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check alarm
    if [ -f "/etc/init.d/alarm" ]; then
         proc="alarm.elf"
         restart_cmd="/etc/init.d/alarm restart > /dev/null 2>&1"
         check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check poe_drv
    if [ -f "/etc/init.d/poe_sh" ]; then
        proc="/sbin/poe_drv"
        restart_cmd="/etc/init.d/poe_sh restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check network_monitor
    if [ -f "/etc/init.d/network_monitor" ]; then
        proc="/usr/sbin/network_monitor"
        restart_cmd="/etc/init.d/network_monitor restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi

    #check hotnet
    if [ -f "/etc/init.d/hotnet" ]; then
        proc="/usr/sbin/hotnet.elf"
        restart_cmd="/etc/init.d/hotnet restart > /dev/null 2>&1"
        check_and_restart_process "$proc" "$restart_cmd"
    fi
