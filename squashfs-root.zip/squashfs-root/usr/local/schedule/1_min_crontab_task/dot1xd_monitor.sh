#!/bin/sh

process_cnt=`ps | grep /usr/bin/dot1xd | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/dot1xd restart
fi
