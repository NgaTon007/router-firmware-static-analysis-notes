#!/bin/sh

# Set log file
mkdir -p /tmp/log
webslog_file="/tmp/log/check_service.log"
webslog_file_bak="/tmp/log/check_service.log.bak"
restart_file="/tmp/log/service_restart.log"
restart_file_bak="/tmp/log/service_restart.log.bak"
PROC_RESTART_CMD="/etc/init.d/app_auth restart > /dev/null 2>&1"

auth_ip=$(product capacity.auth_ip)
monitor_mem()
{
    PROCESS_NAME="app_auth.elf"
    THRESHOLD_PERCENT=30

    mkdir -p /tmp/log
    max_log_size=10240
    log_file="/tmp/log/app_auth_mem.log"
    log_file_bak="/tmp/log/app_auth_mem.logbak"

    TOTAL_MEM=$(free | awk '/Mem:/ {print $2}')
    if [ -z "$TOTAL_MEM" ] || [ "$TOTAL_MEM" -eq 0 ]; then
        return
    fi

    PIDS=$(pgrep "$PROCESS_NAME")
    if [ -z "$PIDS" ]; then
        return
    fi

    OVER_THRESHOLD=0
    if [ -f "/proc/$PIDS/status" ]; then
        RSS=$(grep 'VmRSS' /proc/$PIDS/status | awk '{print $2}')
    else
        return
    fi

    THRESHOLD_MEM=$(awk -v total="$TOTAL_MEM" -v percent="$THRESHOLD_PERCENT" 'BEGIN { print int(total * percent / 100) }')
    if [ "$RSS" -ge "$THRESHOLD_MEM" ]; then
        OVER_THRESHOLD=1
    fi

    if [ "$OVER_THRESHOLD" -eq 1 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - restart...meminfo : $RSS" >> "$log_file"
        eval $PROC_RESTART_CMD

        size=$(stat -c %s /tmp/log/app_auth_mem.log 2>/dev/null)
        if [ "$size" != "" -a "$size" -ge "$max_log_size" ]; then
            mv $log_file $log_file_bak
        fi
    fi
}

monitor_pem()
{
    cap=$(cat /tmp/sd_device/sd_device.json | jq .gateway.webs_sup_rsa)
    cap=${cap//\"/}
    if [ -z "$cap" ]
    then
        cap="0"
    fi
    if [ $cap == "1" ] && [ ! -f "/tmp/app_auth/private.pem" ]; then
        openssl genpkey -algorithm RSA -out /tmp/app_auth/private.pem -pkeyopt rsa_keygen_bits:2048 2>/dev/null
        openssl pkey -in /tmp/app_auth/private.pem -pubout -out /tmp/app_auth/public.pem 2>/dev/null

        curl 127.0.0.1:2060/ga_rsapem_reload 2>/dev/null
    fi

}

app_auth_monitor()
{
    local proc_num
    local enable
    local ko_num
    local cap=$(sw_cap_opt_get.sh "/usr/sbin/app_auth.elf")
    if [ "$cap" == "0" ]; then
        return
    fi
    enable=`uci -q get app_auth.app_auth.enable |xargs echo`
    proc_num=$(ps -w |grep -w "app_auth.elf" |grep -v grep |wc -l)
    ko_num=$(lsmod | grep app_auth | wc -l)
    if [ $proc_num -eq 0 -o $ko_num -eq 0 ]; then
        if  [ "$enable"x == "1"x ]
        then
            eval $PROC_RESTART_CMD
        fi
    fi
    addr_exist=$(ip addr show lo|grep ${auth_ip})
    if [ "$enable"x == "1"x ] && [ -z "$addr_exist" ]; then
        ip addr add ${auth_ip}/32 dev lo 2>&1 > /dev/null
    fi
    if  [ "$enable"x == "1"x ]
    then
        monitor_mem
        monitor_pem
    fi
}

webservice_httpd_monitor()
{
    # ���ܿ����ж�
    ap_portal_enable=`uci -q get ap_portal.ap_portal.enable |xargs echo`
    app_auth_enable=`uci -q get app_auth.app_auth.enable |xargs echo`
    if  [ "$ap_portal_enable"x != "1"x ] && [ "$app_auth_enable"x != "1"x ] ; then
        return
    fi

    # Set log size (byte)
    max_log_size=10240
    use_cnt=$(jq .max_user_num /tmp/sd_device/sd_device.json | sed 's/"//g')
    if [ "$use_cnt" -ge 1000 ]; then
        max_log_size=1024000
    else 
        if [ "$use_cnt" -ge 300 ]; then
            max_log_size=500000
        else
            max_log_size=10240
        fi
    fi

    if [ ! -f /tmp/.webservice_fail_cnt ]; then
        echo 0 > /tmp/.webservice_fail_cnt
    fi
    failure_count=$(cat /tmp/.webservice_fail_cnt)
    old_failure_count=$failure_count

    # Use curl to access the specified address
    response=$(curl -s --connect-timeout 3 127.0.0.1:2060/show_err_cnt)

    # Check if the response is empty
    if [ -z "$response" -o "${response:0:1}" != "{" ]; then
        # If no response, increment the counter
        failure_count=$((failure_count + 1))
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Error, current failure count: $failure_count" >> "$webslog_file"

        # If failure count reaches 5, restart the service
        if [ "$failure_count" -ge 5 ]; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') - restarting wenservice..." >> "$restart_file"
            /etc/init.d/webservice restart
            # Reset counter
            failure_count=0
        fi
    else
        # If a response is received, reset the counter
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Response received: $response" >> "$webslog_file"
        failure_count=0
    fi

    if [ "$old_failure_count" != "$failure_count" ]; then
        echo $failure_count > /tmp/.webservice_fail_cnt
    fi
    if [ -f /tmp/log/check_service.log ]; then
        size=$(stat -c %s /tmp/log/check_service.log 2>/dev/null)
        if [ "$size" != "" -a "$size" -ge "$max_log_size" ]; then
            mv $webslog_file $webslog_file_bak
        fi
    fi
    if [ -f /tmp/log/service_restart.log ]; then
        size=$(stat -c %s /tmp/log/service_restart.log 2>/dev/null)
        if [ "$size" != "" -a "$size" -ge "10240" ]; then
            mv $restart_file $restart_file_bak
        fi
    fi
}

webservice_monitor()
{
    local WEBSPROC_RESTART_CMD="/etc/init.d/webservice start > /dev/null 2>&1"
    local proc_num

    proc_num=$(ps -w |grep -w "webservice.elf" |grep -v grep |wc -l)
    if [ $proc_num -eq 0 ]; then
        enable=`uci -q get app_auth.app_auth.enable |xargs echo`
        if  [ "$enable"x == "1"x ]
        then
            eval $WEBSPROC_RESTART_CMD
        fi  
    fi
}

#main
app_auth_monitor
webservice_monitor
webservice_httpd_monitor

exit 0
