#!/bin/sh
CHECK_FA_STATE_LOG="/tmp/ip_connlimit/ip_connlimit_debug.log"
CHECK_FA_STATE_LOG_SIZE=5        # 日志文件大小, 单位KB; du最小都是4k，而且是4的整数倍，故不能设置小于4k。

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    local file_size=$(du -shk $CHECK_FA_STATE_LOG | awk '{print $1}' | tr -d ' \n\t')

    [ $file_size  -gt $CHECK_FA_STATE_LOG_SIZE ] && {
        mv -f $CHECK_FA_STATE_LOG ${CHECK_FA_STATE_LOG}.old
    }

    echo -e "${cur_time} ${1}" >> $CHECK_FA_STATE_LOG
}

ip_connlimit_monitor()
{
    local PROC_RESTART_CMD="/etc/init.d/ip_connlimit restart > /dev/null 2>&1"
    local file_path="/etc/init.d/ip_connlimit"
    local proc_num

    local cap=$(sw_cap_opt_get.sh "/usr/sbin/ip_connlimit.elf")
    if [ "$cap" == "0" ]; then
        return
    fi

    policy_cnt=$(dev_config get -m ip_connlimit | jq '.list | length')
    if [ $policy_cnt -gt 0 ]; then
        proc_num=$(ps -w |grep -w "/usr/sbin/ip_connlimit.elf" |grep -v grep |wc -l)
        if [ $proc_num -eq 0 -a -e "$file_path" ]; then
            eval $PROC_RESTART_CMD
            debug_log "[ip_connlimit_monitor] start ip_connlimit"
        fi
    fi
}

#main
ip_connlimit_monitor

exit 0