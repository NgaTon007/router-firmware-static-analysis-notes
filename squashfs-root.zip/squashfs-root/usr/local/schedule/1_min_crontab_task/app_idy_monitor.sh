#!/bin/sh /etc/rc.common
. /lib/functions.sh

clear_app_idy_files()
{
	if [ -d "/tmp/signature" ]; then
		rm -rf /tmp/signature/*
	fi
}

app_idy_monitor()
{
	local PROC_RESTART_CMD="/etc/init.d/app_identify restart > /dev/null 2>&1"
	local proc_num
	
	local cap=$(sw_cap_opt_get.sh "/usr/sbin/app_identify.elf")
	if [ "$cap" == "0" ]; then
		return
	fi

	proc_num=$(ps -w | grep -w "app_identify.elf" | grep -v grep | wc -l)
	# �ж�funcmgr����Ƿ����
	funcmgr_status=`jq -r ".gateway.funcmgr" /tmp/sd_device/sd_device.json 2>/dev/null`
	if [ "$funcmgr_status" == "1" ]; then
		# funcmgr�����Ӧ��ʶ���������ҽ���δ�������ִ��
		if [ "$(func_mgr_get_status "app_identify")" == true -a $proc_num -eq 0 ]; then
			clear_app_idy_files
			eval $PROC_RESTART_CMD
		fi
	else
		if [ $proc_num -eq 0 ]; then
			clear_app_idy_files
			eval $PROC_RESTART_CMD
		fi
	fi
}

#main
app_idy_monitor

exit 0