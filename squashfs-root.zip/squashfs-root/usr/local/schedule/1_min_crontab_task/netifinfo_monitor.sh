#!/bin/sh

process_cnt=`ps | grep /usr/sbin/netifinfo.elf | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/netifinfo restart
    echo "$(date) netifinfo restart" >> /tmp/netifinfo/schedule_rec.log
fi
