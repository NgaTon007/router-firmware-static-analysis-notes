#!/bin/sh
TOPO_MONITOR_LOG="/tmp/topo/topo_monitor.log"
TOPO_MONITOR_LOG_SIZE=5        # 日志文件大小, 单位KB; du最小都是4k，而且是4的整数倍，故不能设置小于4k。

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
	local file_size=$(du -shk $TOPO_MONITOR_LOG | awk '{print $1}' | tr -d ' \n\t')

	[ $file_size  -gt $TOPO_MONITOR_LOG_SIZE ] && {
		mv -f $TOPO_MONITOR_LOG ${TOPO_MONITOR_LOG}.old
	}

	echo -e "${cur_time} ${1}" >> $TOPO_MONITOR_LOG
}

topo_monitor()
{
	local PROC="local_topology.elf"
	local PROC_RESTART_CMD="/etc/init.d/local_topology restart > /dev/null 2>&1"
	local proc_num

	proc_num=$(ps -w |grep -w "$PROC" |grep -v grep |wc -l)
	if [ $proc_num -eq 0 ]; then
		debug_log "$PROC start"
		eval $PROC_RESTART_CMD
	fi
}

#main
topo_monitor

exit 0