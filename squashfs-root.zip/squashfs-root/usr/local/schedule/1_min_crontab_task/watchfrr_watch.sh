#!/bin/sh /etc/rc.common

PROG=/usr/sbin/watchfrr

#日志模块，已做适配无需修改
LOG_DIR="/tmp/watchfrr_watch"
LOG_NAME="$(basename $0.log)"
LOG_FILE="$LOG_DIR/$LOG_NAME"
LOG_LINE_NUM_MAX=1000

#If this file exist, dont't excute /etc/init.d/frr start
WATCHFRR_FLAG_FILE="/var/run/frr/stoping_watchfrr"

isRun=1
#交换其它线卡不运行
if [ -f "/usr/sbin/sw_process_status_get.sh" ]; then
    isRun=$(sw_process_status_get.sh /usr/sbin/watchfrr)
fi

if [ "$isRun" != "1" ]; then
	echo "dont need /usr/sbin/watchfrr"
	return
fi

log()
{
	if [ -f ${LOG_FILE} ]; then
		log_line=$(cat ${LOG_FILE} | wc -l)
		[ ${log_line} -ge $LOG_LINE_NUM_MAX ] && { mv -f $LOG_FILE ${LOG_FILE}.old; }
	else
		if [ ! -d ${LOG_DIR} ]; then
			mkdir $LOG_DIR
		fi
	fi
	if [ -n "$1" ]; then
		local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
		echo -e "${cur_time} ${1}" >> $LOG_FILE
	else
		echo -e "" >> $LOG_FILE
	fi
}

# 判断进程是否在运行
pro_is_running_() {
	prog=$1
	status=$(ps | grep $prog | grep -v grep | wc -l)
	if [ $status != "0" ]; then
		echo "true"
	else
		echo "false"
	fi
}

vtysh_stop_watchfrr() {
	if [ -f $WATCHFRR_FLAG_FILE ];then
		echo "true"
	else
		echo "false"
	fi
}

chk_watchfrr_run() {
	pro_is_running=$(pro_is_running_ $PROG)
	vtysh_action=$(vtysh_stop_watchfrr)
	if type "func_mgr_get_status" |grep -q 'function'; then
		if [ $pro_is_running == "false" ] && [ $vtysh_action == "false" ] && [ "$(func_mgr_get_status "frr")" == true  ]; then
			/etc/init.d/frr start
			log "(funcmgr support)CMD /etc/init.d/frr start"
		fi
	else
		if [ $pro_is_running == "false" ] && [ $vtysh_action == "false" ]; then
			/etc/init.d/frr start
			log "CMD /etc/init.d/frr start"
		fi
	fi
}

#chk_watchfrr_run
chk_watchfrr_run