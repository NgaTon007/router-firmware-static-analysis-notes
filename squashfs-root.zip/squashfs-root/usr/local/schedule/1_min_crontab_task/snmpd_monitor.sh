#!/bin/sh

PROG="/usr/sbin/snmpd"

result=$(dev_cap get -m snmp)
if [ -n "$result" ]; then
    snmp_enable=$(uci get snmpd.snmp_parameter.snmp_enable)
    pid=$(ps|grep $PROG|grep -v grep|awk '{print $1}')
    if [ "$snmp_enable" = "true" ]; then
        if [ "$pid" = "" ]; then
            $PROG -f -r &
        fi
    fi
    if [ "$snmp_enable" = "false" ]; then
        if [ "$pid" != "" ]; then
            kill -9 $pid
        fi
    fi
fi