#!/bin/sh

CHECK_FA_STATE_LOG="/tmp/flow_audit/flow_audit_monitor.log"
CHECK_FA_STATE_LOG_SIZE=5        # ��־�ļ���С, ��λKB; du��С����4k��������4�����������ʲ�������С��4k��

mkdir -p "/tmp/flow_audit/"

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
	local file_size
	if [ -e $CHECK_FA_STATE_LOG ] ; then
		file_size=$(du -shk $CHECK_FA_STATE_LOG | awk '{print $1}' | tr -d ' \n\t')
	else
		file_size=0
	fi

	[ $file_size  -gt $CHECK_FA_STATE_LOG_SIZE ] && {
		mv -f $CHECK_FA_STATE_LOG ${CHECK_FA_STATE_LOG}.old
	}

	echo -e "${cur_time} ${1}" >> $CHECK_FA_STATE_LOG
}

flow_audit_monitor()
{
    local PROC_RESTART_CMD="/etc/init.d/flow_audit restart 2> /dev/null"
    local proc_num
    local enable
    local cap=$(sw_cap_opt_get.sh "/usr/sbin/flow_audit.elf")
    if [ "$cap" == "0" ]; then
        return
    fi
    proc_num=$(ps -w |grep -w "flow_audit.elf" |grep -v grep |grep -v '{'|wc -l)
    if [ $proc_num -eq 0 ]; then
        debug_log "proc num : $proc_num "
        eval $PROC_RESTART_CMD
    elif [ $proc_num -ge 2 ]; then
        #���¼���һ�ˣ���������������
        proc_num=$(ps -w | grep -v grep | grep -wc "/usr/sbin/flow_audit.elf")
        if [ $proc_num -lt 2 ]; then
            cmd_log=$(ps -w | grep -v grep | grep -w "/usr/sbin/flow_audit.elf")
            debug_log "$cmd_log"
            debug_log "next proc num : $proc_num, return "
            return
        fi

        debug_log "proc num : $proc_num " 
        cmd_log=$(ps -w |grep -w "flow_audit.elf")
        debug_log "$cmd_log"
        cnt=0
        for pid in $(pgrep -f "flow_audit.elf"); do
            if [ -n "$(cat /proc/$pid/cmdline)" ]; then
                cnt=$((cnt+1))
            fi
        done
        if [ $cnt -ge 2 ]; then
            for pid in $(pgrep -f "flow_audit.elf"); do
                debug_log "kill $pid"
                kill -9 $pid
            done
            eval $PROC_RESTART_CMD
        fi
    fi
}

#main
flow_audit_monitor

exit 0