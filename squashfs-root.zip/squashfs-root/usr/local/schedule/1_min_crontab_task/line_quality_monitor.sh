#!/bin/sh

process_cnt=`ps | grep /usr/sbin/line_quality.elf | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/line_quality restart
fi
