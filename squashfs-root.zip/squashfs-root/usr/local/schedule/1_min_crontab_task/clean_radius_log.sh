#!/bin/sh

RADIUS_LOG_FILE="/tmp/log/radius.log"
RADIUS_LOG_FILE_OLD="/tmp/log/radius_old.log"
MAX_SIZE=10485760  #10MB
if [ -f "$RADIUS_LOG_FILE" ];then
    SIZE=$(stat -c%s "$RADIUS_LOG_FILE")
    if [ "$SIZE" -ge "$MAX_SIZE" ]; then
        cp $RADIUS_LOG_FILE $RADIUS_LOG_FILE_OLD
        > "$RADIUS_LOG_FILE"
    fi
fi
