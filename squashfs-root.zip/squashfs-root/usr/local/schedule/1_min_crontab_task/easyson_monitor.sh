#!/bin/sh

PROC="easyson.elf"
LOG_FILE="/tmp/easyson/easyson_monitor.log"

debug()
{
    local logsize=50  # 日志文件大小, 单位KB
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")

    if [ -f  ${LOG_FILE} ]; then
       local size=$(du -shk $LOG_FILE | awk '{print $1}' | tr -d ' \n\t')

        [ $size  -gt $logsize ] && {
            mv -f ${LOG_FILE} ${LOG_FILE}.old
        }
    fi

    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

proc_start()
{
    /etc/init.d/easyson start >/dev/null 2>&1 &
}

check()
{
    local chk=$(ps | grep -w easyson.elf | grep -v grep | wc -l)
    if [ $chk -eq 0 ]; then
        debug "restart $PROC"
        proc_start
    fi
}

check_moquitto()
{
    #[BUGID 586162] 解决EAP由master变更为slave时，概率性出现mosquitto服务不能关闭问题
    local chk=$(ps | grep -w mosquitto | grep -v grep | wc -l)
    local filename="/tmp/easyson/mosq_monitor.tmp"
    [ $chk -eq 1 ] && {
        local isMaster=$(dev_sta get -m role 2>/dev/null | grep AC | wc -l)
        if [ $isMaster -eq 0 ];then
            [ -f "$filename" ] && {
                rm -f ${filename}
                debug "mosq_monitor stop mosq"
                /etc/init.d/mosquitto stop  #不是master，需要关闭mosquitto服务
                killall -9 mosquitto          #bugid:906834 使用stop删除不掉
                return
            }
            touch $filename
        fi
        return
    }
    [ -f "$filename" ] && {
        rm -f ${filename}
    }
}

check_moquitto_memory()
{
    local mosqfile="/tmp/easyson/mosquitto_mem_limit"
    local isSlave=$(dev_sta get -m role 2>/dev/null | grep AC | wc -l)

    if [ $isSlave -eq 0 ]; then
        return;
    fi

    if [ -f "$mosqfile" ]; then
        local mem=$(ps | grep mosquitto | grep -v grep | awk '{print $3}')
        local limitmem=$(cat $mosqfile) 
        [ $mem -gt $limitmem ] && {
            debug "mosquitto memory abnormal, restart mosquitto"
            /etc/init.d/mosquitto restart
        }
    fi
}

main()
{
    check

    check_moquitto

    check_moquitto_memory

    return
}

### 程序main流程 ###
main