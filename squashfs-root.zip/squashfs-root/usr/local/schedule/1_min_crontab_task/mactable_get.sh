#!/bin/sh

path="/tmp/snmp/mac_table.json"
if [ ! -f $path ]; then
    mkdir -p /tmp/snmp
    touch $path

    dev_sta get -m mactable_json > $path
fi
