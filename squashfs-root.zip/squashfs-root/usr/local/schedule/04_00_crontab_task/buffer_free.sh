#!/bin/sh
LOG_FILE="/tmp/buffer_free.log"

debug_log_file()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -gt 500 ] && { echo > ${LOG_FILE}; }
    fi
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    echo -e "${cur_time} ${1}" >> $LOG_FILE
}

#main
before_size=$(free)
debug_log_file "start free buffer, the buffer size before buffer free:\n${before_size}"
echo 3 > /proc/sys/vm/drop_caches
#sleep 1
after_size=$(free)
debug_log_file "end free buffer, the buffer size after buffer free:\n${after_size}\n"
