#!/usr/bin/lua
-- ac_config set -m "ntpserver" '{"ntpserver":["0.cn.pool.ntp.org ", "1.cn.pool.ntp.org"]}'
module("ntpserver", package.seeall);  --必须要有
local console = require "console"
local cjson = require "cjson"
local lib_debug = require "utils.debug";
local uci = require "luci.model.uci".cursor()
local ntp_file = "/etc/ntp/ntp_replacement_list.json"

function file_read(conf_file)
	local file = io.open(conf_file,"r")
	if (file == nil) then
		print("Could not open file for reading")
		return nil
	end

	local content = file:read("*all")
	file:close()
	return cjson.decode(content)
end

function file_write(conf_file, data)
	local file = io.open(conf_file,"w")
	if (file == nil) then
		print("Could not open file for writing")
		return
	end

	local content = cjson.encode(data)
	file:write(content)
	file:close()
end

function check_ntp_config(ntp_config)
	local data = file_read(ntp_file)
	if (data == nil) then
		print("Open file ntp_replacement_list.json for dir fail")
		return
	end

	for i, set_ntp_entry in pairs(ntp_config["ntpserver"]) do
		for j, check_ntp_entry in pairs(data["ntp_replacement_list"]) do
			if check_ntp_entry.src_ntp == set_ntp_entry then
				check_ntp_entry.user_config = "1"
				break
			end
		end
	end

	file_write(ntp_file, data)
end

function module_default_config_get()
	local default_config = {
		ntpserver = {}
	}
	local uci = require("uci").cursor("/rom/etc/config")
	--default_config = json.decode(default_string);
	server_list = uci:get_list("system", "ntp", "server")
	for i, v in pairs(server_list) do
		table.insert (default_config["ntpserver"], i, v)
		--default_config.ntpserver[i]. = v
		console.debug("ntpserver", 'ntpserver['..i..']='..default_config["ntpserver"][i]..'  ')
	end

	t = cjson.encode(default_config)
	console.debug("ntpserver", t)
	return t
end

function module_set(param)
    local data = cjson.decode(param)
    if (data["ntpserver"] == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "Param is error, ntpserver is nil")
    end 
	
	--for i,v in pairs(data["ntpserver"]) do 
	--	ntpserver+=v
	--	ntpserver+=' '
	--end
    uci:set_list("system", "ntp", "server", data["ntpserver"])
    uci:commit("system")
	t = io.popen('/etc/init.d/sysntpd restart > /dev/null')
    t:close()
    check_ntp_config(data)
end
