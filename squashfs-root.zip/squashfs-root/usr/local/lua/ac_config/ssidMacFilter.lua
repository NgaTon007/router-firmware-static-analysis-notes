#!/usr/bin/lua
--ac_config add --module 'wirelessMacFilter' '{"mac":"22:22:22:22:22:22","type":"deny","name":"22","wlanId":"1,2,3"}'
--ac_config update --module 'wirelessMacFilter' '{"type":"deny","old":{"mac":"11:11:11:11:11:11","name":"11","wlanId":"1,2,3"},"new":{"mac":"11:11:11:11:11:22","name":"11","wlanId":"1,2,3"}}'
--ac_config del --module 'wirelessMacFilter' '{"type":"deny","macList":["22:22:22:22:22:22"]}'
module("ssidMacFilter",package.seeall)
local json = require "dkjson"
local console = require "console"
local uci = require "luci.model.uci".cursor()
local dev_sta = require "dev_sta"
local is_support_wifi = uci:get_first("sysinfo","sysinfo","support_wifi") or ""
local hide_ssid_idx = uci:get("wifiinfo", "global", "hide_ssid_idx") or ""
local device_model = uci:get_first("sysinfo","sysinfo","model") or ""
local is_rap = string.find(device_model,"RAP")
local groupId = uci:get("mqtt", "mqtt", "groupId") or ""
local ap_acl_num = uci:get("wifiinfo", "global", "ap_acl_num") or uci:get("macfilterinfo", "global", "ap_acl_num") or "30"
local total_acl_num = uci:get("wifiinfo", "global", "total_acl_num") or uci:get("macfilterinfo", "global", "total_acl_num") or "1024"
local g_macList_num = 30
local dev_role = nil
--debug
local function debug(msg)
    console.debug("ssidMacFilter", msg)
end

local function lock()
    os.execute("lock /tmp/sd_config/ssidMacFilter.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/ssidMacFilter.lock")
end

function string.split(str, delimiter)
    local result = {}

    if str==nil or str=='' or delimiter==nil then
        return result
    end
    
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end

local function del_acl_string(AccessControlList, MacList, addAccessControlList)
    if AccessControlList==nil or AccessControlList=='' or MacList==nil or MacList=='' then
        debug("maclist is empty")
        return ""
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
    local AccessControlList = ""
    for i,j in pairs(list) do
        local flag = false
        for k, v in pairs(MacList) do
            if string.upper(v) == string.upper(j) then
                flag = true
                debug(string.upper(v) .. ", del find same")
            end
        end
        if flag == false then
            if AccessControlList ~= "" then
                AccessControlList = AccessControlList .. ";" .. string.upper(j)
            else
                AccessControlList = string.upper(j)
            end
        end
    end
    if addAccessControlList and addAccessControlList ~= ""then
        AccessControlList = AccessControlList .. ";" .. addAccessControlList
    end
    return AccessControlList
end

local function update_acl_string(AccessControlList, OldMac, NewMac)
    if AccessControlList==nil or AccessControlList=='' or OldMac==nil or OldMac=='' or NewMac==nil or NewMac=='' then
        debug("maclist is empty")
        return nil
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
    local AccessControlList = ""
    for i,j in pairs(list) do
        if string.upper(j) ~= string.upper(NewMac) then
            if string.upper(j) == string.upper(OldMac) then
                debug(string.upper(j) .. ",update mac is same")
                j = NewMac
            end
            if AccessControlList ~= "" then
                AccessControlList = AccessControlList .. ";" .. string.upper(j)
            else
                AccessControlList = string.upper(j)
            end
        else
            debug("new mac is exist")
        end
    end

    return AccessControlList
end

local function add_find_acl(AccessControlList, Mac)
    if AccessControlList==nil or AccessControlList=='' or Mac==nil or Mac=='' then
        debug("maclist is empty")
        return nil
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
    for i,j in pairs(list) do
        if string.upper(j) == string.upper(Mac) then
            return true
        end
    end

    return false
end

function wlanId_default_setting(wlanId)
    local result = {}
    result.wlanId=wlanId
    result.type="deny"
    result.macList={}
    --return json.encode(result)
    return result
end

local function acl_and_axacl_sort(ssidList, wlanId)
    local macListNum
    local AccessControlList = ""

    for m,n in pairs(ssidList) do
        if n.wlanId == wlanId then
            macListNum = 30 - #n.macList
            debug("macListNum:"..macListNum)
            if macListNum > 0 then
                if n.axMacList then
                    for a,b in pairs(n.axMacList) do
                        if macListNum > 0 then
                            table.insert(n.macList, b)
                            table.remove(n.axMacList, a)
                            macListNum = macListNum - 1
                            if AccessControlList ~= "" then
                                AccessControlList = AccessControlList .. ";" .. string.upper(b.mac)
                            else
                                AccessControlList = string.upper(b.mac)
                            end
                        else
                            break
                        end
                    end
                end
            end
        end
    end
    return AccessControlList
end

local function device_is_eg()
    local dev_type = uci:get_first("sysinfo", "sysinfo", "product_class")
    if dev_type and (string.find(dev_type, "EG") or string.find(dev_type, "NBC")) then
        ap_acl_num = "256"
        return true
    else
        return false
    end
end

local function get_total_ssidacl_num(groupId)
    --local ret = ac_config.fetch("get","network_group", nil)
    local nid = uci:get("mqtt", "mqtt", "networkId")
    local gid = uci:get("mqtt", "mqtt", "groupId")
    local config_table
    local config_path
    local num
    local total_num = 0
    local network_group_path = "/etc/sd_config/global/network_group_"..nid.."_0.json"
    debug(network_group_path)
    local group_table
    if console.is_file_exist(network_group_path) then
        group_table = json.decode(console.read_file(network_group_path))
        debug(json.encode(group_table))
    end
    if group_table then
        for k,v in pairs(group_table.groupInfo) do
            if not groupId or v.groupId ~= groupId then
                config_path = "/etc/sd_config/global/ssidMacFilter_"..nid.."_"..v.groupId..".json"
                debug(config_path)
                num = 0
                if console.is_file_exist(config_path) then
                    config_table = json.decode(console.read_file(config_path))
                    for i,j in pairs(config_table.ssidList) do 
                        num = num + #j.macList
                        if j.axMacList then
                            num = num + #j.axMacList
                        end
                    end
                    debug("num: "..num)
                    total_num = total_num + num
                end
            end
        end
        debug("total_num:"..total_num)
    end
    return total_num
end

local function get_ssidlist_num(ssidList)
    local num = 0
    for k,v in pairs(ssidList) do
        num = num + #v.macList
        if tonumber(ap_acl_num) ~= g_macList_num then
            if v.axMacList then
                num = num + #v.axMacList
            end
        end
    end
    debug("get_ssidlist_num is:"..num)
    return num
end

local function get_dev_role()
    dev_role = json.decode(dev_sta.fetch("get","role").data).role
    debug("dev_role:"..(dev_role or ""))
end

--add config
local function add_config(param, old_ssidList)
    local found = nil
    local find_wlanid = false
    local AccessPolicy
    local policy_check = false
    local is_config_acl = false
    local num = 0
    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_ssidList then
        old_ssidList = {}
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    if not param_table.mac or param_table.mac == "" then
        msg = "mac is empty"
        return nil, msg
    end
    if not param_table.name then
        param_table.name = ""
        debug("name is nil,default empty")
    end
    local ssidList = old_ssidList
    if not param_table.wlanId then
        msg = "wlanId is nil"
        return nil, msg
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end
    if ssidList ~= '' then
        for k,v in pairs(ssidList) do
            if v.wlanId == param_table.wlanId then
                num = #v.macList
                if v.axMacList then
                    num = num + #v.axMacList
                end
                if num >= tonumber(ap_acl_num) then
                    msg = "add mac greater than 256"
                    debug(msg)
                    return nil, msg
                end
                for i,j in pairs(v.macList) do
                    if string.upper(j.mac) == string.upper(param_table.mac) then
                        found = true
                        msg = "have exist ssid mac, add config fail"
                        return nil, msg
                    end
                end
                if v.axMacList and v.axMacList ~= '' then
                    for i,j in pairs(v.axMacList) do
                        if string.upper(j.mac) == string.upper(param_table.mac) then
                            found = true
                            msg = "have exist ssid axmac, add config fail"
                            return nil, msg
                        end
                    end
                end
                break
            end
        end
    end
    --写配置文件
    --配置文件没有wlandId则补齐默认配置
    for k, v in pairs(ssidList) do
        if v.wlanId == param_table.wlanId then
            debug("The wlanId:"..param_table.wlanId.." is exist")
            find_wlanid = true
        end
    end
    if find_wlanid == false then
        if 1 <= tonumber(param_table.wlanId) and tonumber(param_table.wlanId) <= 8 then
            debug("The wlanId is legal")
            --local ret = wlanId_default_setting(param_table.wlanId)
            local ret = {wlanId = param_table.wlanId, type = param_table.type, macList={}, axMacList={}}
            debug("add default wlanId configuration is "..json.encode(ret))
            table.insert(ssidList, ret)
        end
    end
    if not found then
        local data = {mac = string.upper(param_table.mac), name = param_table.name}
        if param_table.wlanId ~= "0" then
            --基于ssid，配置文件添加mac，需要判断wlanId
            if ssidList ~= '' then
                for k, v in pairs(ssidList) do
                    if v.wlanId == param_table.wlanId then
                        if #v.macList < 30 then
                            table.insert(v.macList, data)
                            is_config_acl = true
                        else
                            if not v.axMacList then
                                v.axMacList = {}
                            end
                            table.insert(v.axMacList, data)
                            is_config_acl = false
                        end
                    end
                end
            end
        else
            --table.insert(macList, data)
            msg = "The wlanId is not exised"
            return nil, msg
        end
        msg = "add config, mac:"..param_table.mac.." name:"..param_table.name.." wlanId:"..param_table.wlanId
        debug(msg)
    end
    
    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end

    if is_rap == 1 and groupId == param_table.groupId and is_config_acl == true then
        debug("device is RAP and groupId is the same")
        --设置ssid的uci
        uci:foreach("wireless", "wifi-iface", function(s)
            --if s.wlan_id == hide_ssid_idx then
            --    debug("dev_type is ehr, do not set hide ssid")
            --    return
            --end
            if param_table.wlanId == s.wlan_id then
                --过滤uci的mac
                local is_find = add_find_acl(s.AccessControlList, param_table.mac)
                if is_find == true then
                    debug(param_table.mac .. ",the mac uci already exised")
                    return true
                end
                --policy不一致返回
                if tostring(AccessPolicy) ~= s.AccessPolicy then
                    msg = "ssid_policy not same, add config fail"
                    debug(msg)
                    --if not s.AccessPolicy then
                    uci:set("wireless", s[".name"], "AccessPolicy", AccessPolicy)
                    --end
                end
                if not s.AccessControlList then
                    s.AccessControlList = string.format('%s', string.upper(param_table.mac))
                else
                    s.AccessControlList = string.format('%s;%s', string.upper(s.AccessControlList), string.upper(param_table.mac))
                end
                uci:set("wireless", s[".name"], "AccessControlList", (s.AccessControlList or ""))
            end
        end)

        uci:commit("wireless")
    end

    return true
end

--del config
local function del_config(param, old_ssidList)
    local new_maclist
    local found = false
    local pre_maclist
    local AccessPolicy
    local policy_check = false
    local addAccessControlList = ""
    local sort_flag = true
    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_ssidList or old_ssidList == "" then
        msg = "old ssidList is null"
        return nil, msg
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    local macList = param_table.macList
    if not macList then
        msg = "macList is nil, del config fail"
        return nil, msg
    end
    if not param_table.wlanId then
        msg = "wlanId is nil"
        return nil, msg
    end
    --修改配置文件
    --删除ssid下的黑白名单配置文件
    if macList == "all" then
        debug("del ssid all mac, wlanId:"..param_table.wlanId)
        for m,n in pairs(old_ssidList) do
            if string.find(param_table.wlanId, n.wlanId) then
                n.macList={}
                n.axMacList={}
                n.type="deny"
            end
        end
    else
        for k,v in pairs(macList) do
            for m,n in pairs(old_ssidList) do
                if n.wlanId == param_table.wlanId then
                    for i,j in pairs(n.macList) do
                        if string.upper(v) == string.upper(j.mac) then
                            debug("del ssid mac " .. v)
                            table.remove(n.macList, i)
                            break
                        end
                    end
                    if n.axMacList then
                        if tonumber(ap_acl_num) == g_macList_num then
                            --clear axMacList
                            sort_flag = false
                            n.axMacList = {}
                            debug("clean axMacList")
                        else
                            for a,b in pairs(n.axMacList) do
                                if string.upper(v) == string.upper(b.mac) then
                                    debug("del ssid mac " .. v)
                                    table.remove(n.axMacList, a)
                                    break
                                end
                            end
                        end
                    end
                    break
                end
            end
        end
        debug("old_ssidList:"..json.encode(old_ssidList))
        if sort_flag == true then
            addAccessControlList = acl_and_axacl_sort(old_ssidList, param_table.wlanId)
            debug("addAccessControlList:"..addAccessControlList)
        end
    end

    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end
    
    if is_rap == 1 and groupId == param_table.groupId then
        debug("device is RAP and groupId is the same")
        --设置ssid的uci
        uci:foreach("wireless","wifi-iface",function(s)
            --if s.wlan_id == hide_ssid_idx then
            --    debug("dev_type is ehr, do not set hide ssid")
            --    return
            --end
            if string.find(param_table.wlanId, s.wlan_id) then
                --policy不一致返回
                if tostring(AccessPolicy) ~= s.AccessPolicy then
                    msg = "ssid_policy not same, add config fail"
                    debug(msg)
                    if not s.AccessPolicy then
                        uci:set("wireless", s[".name"], "AccessPolicy", AccessPolicy)
                    end
                end
                if not s.AccessControlList then
                    AccessControlList = nil
                    debug("AccessControlList is nil")
                    return
                else
                    AccessControlList = string.upper(s.AccessControlList)
                end
                pre_maclist = string.upper(s.AccessControlList)
                if not pre_maclist then
                    debug("pre_maclist is nil")
                    return
                end
                if macList == "all" then
                    AccessControlList = nil
                else
                    AccessControlList = del_acl_string(pre_maclist, macList, addAccessControlList)
                end
                debug("Ssid AccessControlList is "..(AccessControlList or "empty"))
                uci:set("wireless", s[".name"], "AccessControlList", (AccessControlList or ""))
            end
        end)

        uci:commit("wireless")
    end

    return true
end
--update config
local function update_config(param, old_ssidList)
    local AccessPolicy
    local policy_check = false
    local change_name_flag = nil
    local find_wlanid = nil
    --入参校验
    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_ssidList or old_ssidList == "" then
        msg = "old old_ssidList is null"
        return nil, msg
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    if not param_table.old then
        msg = "input old is nil"
        return nil, msg
    end
    if not param_table.old.mac then
        msg = "input old mac is nil"
        return nil, msg
    end
    if not param_table.new then
        msg = "input new is nil"
        return nil, msg
    end
    if not param_table.new.mac then
        msg ="input new mac is nil"
        return nil, msg
    end
    --new.name不存在，默认为空
    if not param_table.new.name then
        param_table.new.name = ""
    end
    --配置文件修改
    if not param_table.new.wlanId then
        msg = "input new wlanId is nil"
        return nil, msg
    end

    for k,v in pairs(old_ssidList) do
        --基于ssid配置
        if v.wlanId == param_table.new.wlanId then
            for i,j in pairs(v.macList) do
                --需要修改uci
                if string.upper(j.mac) == string.upper(param_table.old.mac) and string.upper(j.mac) ~= string.upper(param_table.new.mac) then
                    j.mac = string.upper(param_table.new.mac)
                    j.name = param_table.new.name
                    msg = "update config,old mac:" .. param_table.old.mac .. " new mac:" .. param_table.new.mac .. " new name:" .. param_table.new.name
                    debug(msg)
                    break
                --只需要修改配置文件
                elseif string.upper(j.mac) == string.upper(param_table.new.mac) and j.name ~= param_table.new.name then
                    msg = "update config,old name:" .. j.name .. " new name:" .. param_table.new.name
                    j.name = param_table.new.name
                    debug(msg)
                    return true
                end
            end
            if v.axMacList then
                if tonumber(ap_acl_num) == g_macList_num then
                    --clear axMacList
                    sort_flag = false
                    v.axMacList = {}
                    debug("clean axMacList")
                    break
                end
                for m,n in pairs(v.axMacList) do
                    --需要修改uci
                    if string.upper(n.mac) == string.upper(param_table.old.mac) and string.upper(n.mac) ~= string.upper(param_table.new.mac) then
                        n.mac = string.upper(param_table.new.mac)
                        n.name = param_table.new.name
                        msg = "update config,old mac:" .. param_table.old.mac .. " new mac:" .. param_table.new.mac .. " new name:" .. param_table.new.name
                        debug(msg)
                        break
                    --只需要修改配置文件
                    elseif string.upper(n.mac) == string.upper(param_table.new.mac) and n.name ~= param_table.new.name then
                        msg = "update config,old name:" .. n.name .. " new name:" .. param_table.new.name
                        n.name = param_table.new.name
                        debug(msg)
                        return true
                    end
                end
            end
            break
        end
    end
    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end
    
    if is_rap == 1 and groupId == param_table.groupId then
        debug("device is RAP and groupId is the same")
        --设置ssid的uci
        uci:foreach("wireless", "wifi-iface", function(s)
            --if s.wlan_id == hide_ssid_idx then
            --    debug("dev_type is ehr, do not set hide ssid")
            --    return
            --end
            if param_table.new.wlanId == s.wlan_id then
                --policy不一致返回
                if tostring(AccessPolicy) ~= s.AccessPolicy then
                    msg = "ssid_policy not same, add config fail"
                    debug(msg)
                    if not s.AccessPolicy then
                        uci:set("wireless", s[".name"], "AccessPolicy", AccessPolicy)
                    end
                end
                s.AccessControlList = update_acl_string(s.AccessControlList, string.upper(param_table.old.mac), string.upper(param_table.new.mac))
                debug("Ssid update maclist:" .. s.AccessControlList)
                uci:set("wireless", s[".name"], "AccessControlList", (s.AccessControlList or ""))
            end
        end)
        uci:commit("wireless")
    end
    return true
end
--增量配置
function module_update(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end
    local ok, err, msg = pcall(update_config, param, all_config_table.ssidList or "")
--保存配置文件
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug("Update Completed")
    unlock()
end

function ssid_default_setting()
    local ret = {}
    for i=1, 8 do
        local result = {}
        result.wlanId=tostring(i)
        result.type="deny"
        result.macList={}
        result.axMacList={}
        table.insert(ret, result)
    end
    return json.encode(ret)
end

function module_add(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end
    if not all_config_table.ssidList then
        local ret = ssid_default_setting()
        debug("add ssid_default_setting" .. ret)
        all_config_table.ssidList=json.decode(ret)
    end

    if get_total_ssidacl_num() >= tonumber(total_acl_num) then
        local data = {status = "failed", msg = "add great than 1024", rcode = "01450002", num = total_acl_num}
        debug(json.encode(data))
        unlock()
        return json.encode(data)
    end

    local ok, err, msg = pcall(add_config, param, all_config_table.ssidList or "")
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    debug("Add Completed")
    unlock()
end
function module_del(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end

    local ok, err, msg = pcall(del_config, param, all_config_table.ssidList or "")
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    debug("Delete Completed")
    unlock()
end
--全量配置
--获取默认配置
function module_default_config_get()
    local default_config = '{"ssidList":[{"wlanId":"1","type":"deny","macList":[],"axMacList":[]},{"wlanId":"2","type":"deny","macList":[],"axMacList":[]},{"wlanId":"3","type":"deny","macList":[],"axMacList":[]},{"wlanId":"4","type":"deny","macList":[],"axMacList":[]},{"wlanId":"5","type":"deny","macList":[],"axMacList":[]},{"wlanId":"6","type":"deny","macList":[],"axMacList":[]},{"wlanId":"7","type":"deny","macList":[],"axMacList":[]},{"wlanId":"8","type":"deny","macList":[],"axMacList":[]}]}'
    return default_config
end
--ssid过滤
local function ssidMacFilter_set_ssid(SsidAccessControlList)
    local AccessPolicy

    if is_rap == 1 then
        debug("device is RAP")
        --设置基于ssid黑白名单
        uci:foreach("wireless", "wifi-iface", function(s)
            if s.not_need_set ~= "true" then
                --恢复出产后可能不存在wlan_id
                if not s.wlan_id then
                    s.wlan_id = s.vifidx
                    uci:set("wireless", s['.name'], "wlan_id", s.wlan_id)
                    debug("s.wlan_id is nil, set:"..s.vifidx)
                end
                --if s.wlan_id == hide_ssid_idx then
                --    debug("dev_type is ehr, do not set hide ssid")
                --    return
                --end
                new_AccessControlList = ''  --这里不能用nil，不然clear时会报错
                AccessPolicy = 2

                if SsidAccessControlList ~= "" then
                    for i, j in pairs(SsidAccessControlList) do
                        if j.wlanId == s.wlan_id then
                            for k, v in pairs(j.macList) do
                                if new_AccessControlList == '' then
                                    new_AccessControlList = string.format('%s', string.upper(v.mac))
                                else
                                    new_AccessControlList = string.format('%s;%s', new_AccessControlList, string.upper(v.mac))
                                end
                            end
                            if j.type == "allow" then
                                AccessPolicy = 1
                            elseif j.type == "deny" then
                                AccessPolicy = 2
                            elseif j.type == "disable" then
                                AccessPolicy = 0
                            end
                            break
                        end
                    end
                end
                uci:set("wireless", s[".name"], "AccessControlList", (new_AccessControlList or ""))
                uci:set("wireless", s[".name"], "AccessPolicy", (AccessPolicy or ""))
            end
        end)
    else
        debug("device not RAP")
        uci:foreach("wireless","wifi-iface",function(s)
            uci:set("wireless", s[".name"], "AccessControlList", "")
            uci:set("wireless", s[".name"], "AccessPolicy", 2)
        end)
    end
    uci:commit("wireless")
    return true
end
--框架调用的macFilter模块set接口
function module_set(param)
    lock()
    local AclType
    local AccessControlList
    local msg
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local paramTable = json.decode(param)
    local SsidAccessControlList = paramTable.ssidList
    if not SsidAccessControlList then
        SsidAccessControlList = ""
        msg = "SsidAccessControlList is nil"
        unlock()
        return console.fail(msg)
    end
    get_dev_role()
    if dev_role and string.find(dev_role, "AC") then
        local ssidList_num = get_ssidlist_num(SsidAccessControlList)
        total_num = get_total_ssidacl_num(paramTable.groupId) + ssidList_num
        debug("total_num:"..total_num)
        if total_num > tonumber(total_acl_num) then
            local data = {status = "failed", msg = "set great than 1024", rcode = "01450002", num = total_acl_num}
            debug(json.encode(data))
            unlock()
            return json.encode(data)
        elseif ssidList_num > tonumber(ap_acl_num) then
            local data = {status = "failed", msg = "set great than 256", rcode = "01450003", num = ap_acl_num}
            debug(json.encode(data))
            unlock()
            return json.encode(data)
        end
    end
    if is_support_wifi == "1" then
        local ok, err, msg = pcall(ssidMacFilter_set_ssid, SsidAccessControlList)
        if not ok then
            debug(err)
            unlock()
            return
        end
        if not err then
            debug(msg)
            unlock()
            return console.fail(msg)
        end
--wifi reload
        sh_cmd = "wifi reload"
        console.forkExec(sh_cmd)
    end
    debug("wireless success")
    unlock()
end

function module_apply()
    if is_rap == 1 then
        sh_cmd = "wifi reload"
        console.forkExec(sh_cmd)
        debug("Apply Completed")
    end
end
debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")