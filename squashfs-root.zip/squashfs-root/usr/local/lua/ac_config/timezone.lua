#!/usr/bin/lua
-- ac_config set -m timezone '{"timezone":"CST-8", "zonename":"Asia/Shanghai"}'
module("timezone", package.seeall);  --必须要有
local cjson = require "cjson"
local lib_debug = require "utils.debug";
local uci = require "luci.model.uci".cursor()
local console = require "console"

local function debug(msg)
    console.debug("timezone", msg)
end

function module_default_config_get()
    local uci = require("uci").cursor("/rom/etc/config")
    timezone = uci:get_first("system", "system", "timezone")
    zonename = uci:get_first("system", "system", "zonename")
    -- GMT 时间与常规定义相反
    if string.find (timezone, "-") then
        timezone = string.gsub(timezone, "-", "+") 
    else
        timezone = string.gsub(timezone, "+", "-") 
    end

    default_config = '{"timezone": "'..timezone..'", "zonename": "'..zonename..'"}'
    return default_config
end

-- Support daylight saving time BUGID#745722
local function timezoneConvert(zoneName)
    local jpath = "/etc/timezone.json"
    local timezoneTable = {}
    local file = io.open(jpath ,"r")
	local timezone = ""

    if (file == nil) then
        debug("Open file /etc/timezone.json fail")
    else
        local str = file:read("*all")
        file:close()
        if (string.len(str) ~= 0) then
            timezoneTable = cjson.decode(str)
            timezone = timezoneTable[zoneName] or ""
            debug(string.format("Get timezone[%s] from /etc/timezone.json", timezone))
        else
            debug("File /etc/timezone.json is empty")
        end
    end

    debug(string.format("Get zoneName[%s] timezone[%s]", zoneName, timezone))
    if timezone == "" then
        debug(string.format("Get zoneName[%s] is no daylight saving time", zoneName))
    end
    return timezone
end

function module_set(param)
    local data = cjson.decode(param)

    if (data["timezone"] == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "Param is error, timezone is nil")
        return'{"result":"failed"}'
    end

    -- linux 时间与常规定义相反
    if string.find (data["timezone"], "-") then
        data["timezone"] = string.gsub(data["timezone"], "-", "+") 
    else
        data["timezone"] = string.gsub(data["timezone"], "+", "-") 
    end

    local timeZone = timezoneConvert(data["zonename"])
    if timeZone and timeZone ~= "" then
        data["timezone"] = timeZone
        debug(string.format("Set data[timezone] = %s", data["timezone"]))
    end

    uci:foreach("system", "system", function(s)
        uci:set("system", s['.name'], "timezone", data["timezone"])
        if (data["zonename"] ~= nil) then
            uci:set("system", s['.name'], "zonename", data["zonename"])
        end
    end)

    uci:commit("system")

    -- syslog：设备时区变更写syslog
    if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
        local std_syslog= require("std_syslog_lua");

        local ret_code;
        local ret_msg;

        ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_INFO,
            std_syslog.SSG_UNRELIABLE or std_syslog.SSG_LOW_RATE, 0, "SYSTIME", "TIMEZONE_CHANGE",
            "Time zone change. region {" .. data["zonename"] .. "}, timezone {" .. data["timezone"] .. "}")
        if (ret_code > std_syslog.NORMALLY_RET_CODE) then
            debug("std_syslog_lua failed ret_msg:" .. ret_msg)
        end

    end

    -- BUGID：738255
    local file = io.open("/tmp/TZ_new", "w+")
    if (file == nil) then
        return'{"result":"failed"}'
    end

    file:write(data["timezone"],'\n')
    file:close()
    t = io.popen('mv /tmp/TZ_new /tmp/TZ')
    t:close()
    t = io.popen('date -k')
    t:close()
end
