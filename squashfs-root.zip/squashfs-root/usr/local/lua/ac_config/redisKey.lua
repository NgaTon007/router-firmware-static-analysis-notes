#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("redisKey", package.seeall); 
local console = require "console"

function module_default_config_get()
    return "{\"key\":\"\"}"
end

function module_set()
    return console.uf_lua_success()
end
