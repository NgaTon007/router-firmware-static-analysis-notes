#!/usr/bin/lua
module("wirelessMacFilter",package.seeall)
local json = require "dkjson"
local console = require "console"
local uci = require "luci.model.uci".cursor()
local dev_sta = require "dev_sta"
local is_support_wifi = uci:get_first("sysinfo","sysinfo","support_wifi") or ""
local hide_ssid_idx = uci:get("wifiinfo", "global", "hide_ssid_idx") or ""
local ap_acl_num = uci:get("wifiinfo", "global", "ap_acl_num") or uci:get("macfilterinfo", "global", "ap_acl_num") or "30"
local g_macList_num = 30
local dev_role = nil
--debug
local function debug(msg)
    console.debug("wirelessMacFilter", msg)
end

local function lock()
    os.execute("lock /tmp/sd_config/wirelessMacFilter.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/wirelessMacFilter.lock")
end

function string.split(str, delimiter)
    local result = {}

    if str==nil or str=='' or delimiter==nil then
        return result
    end
    
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end

local function del_acl_string(AccessControlList, MacList)
    if AccessControlList==nil or AccessControlList=='' or MacList==nil or MacList=='' then
        debug("maclist is empty")
        return ""
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
    local AccessControlList = ""
	for i,j in pairs(list) do
		local flag = false
		for k, v in pairs(MacList) do
			if string.upper(v) == string.upper(j) then
				flag = true
				debug(string.upper(v) .. ", del find same")
			end
		end
		if flag == false then
			if AccessControlList ~= "" then
				AccessControlList = AccessControlList .. ";" .. string.upper(j)
			else
				AccessControlList = string.upper(j)
			end
		end
	end
    
    return AccessControlList
end

local function get_dev_role()
    dev_role = json.decode(dev_sta.fetch("get","role").data).role
    debug("dev_role:"..(dev_role or ""))
end

local function ability_threshold(macList, axMacList)
	local macList_num = 0
	if macList then
		macList_num = #macList
	end
	if axMacList then
		macList_num = macList_num + #axMacList
	end
	return macList_num
end

local function update_acl_string(AccessControlList, OldMac, NewMac)
    if AccessControlList==nil or AccessControlList=='' or OldMac==nil or OldMac=='' or NewMac==nil or NewMac=='' then
        debug("maclist is empty")
        return ""
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
    local AccessControlList = ""
	for i,j in pairs(list) do
		if string.upper(j) ~= string.upper(NewMac) then
			if string.upper(j) == string.upper(OldMac) then
				debug(string.upper(j) .. ",update mac is same")
				j = NewMac
			end
			if AccessControlList ~= "" then
				AccessControlList = AccessControlList .. ";" .. string.upper(j)
			else
				AccessControlList = string.upper(j)
			end
		else
			debug("new mac is exist")
		end
	end
    
    return AccessControlList
end

local function add_find_acl(AccessControlList, Mac)
    if AccessControlList==nil or AccessControlList=='' or Mac==nil or Mac=='' then
        debug("maclist is empty")
        return false
    end
    --以分号为分隔符取出mac
    local list = string.split(AccessControlList, ";")
	for i,j in pairs(list) do
		if string.upper(j) == string.upper(Mac) then
			return true
		end
	end

    return false
end

function acl_and_axacl_sort(old_macList, old_axmacList)
	local macListNum
	local AccessControlList = ""

	macListNum = 30 - #old_macList
	debug("macListNum:"..macListNum)
	if macListNum > 0 then
		if old_axmacList then
			for a,b in pairs(old_axmacList) do
				table.insert(old_macList, b)
				table.remove(old_axmacList, a)
				macListNum = macListNum - 1
				if AccessControlList ~= "" then
					AccessControlList = AccessControlList .. ";" .. string.upper(b.mac)
				else
					AccessControlList = string.upper(b.mac)
				end
				if macListNum <= 0 then
					break
				end
			end
		end
	end
	return AccessControlList
end

--add config
local function add_config(param, old_macList, old_axmacList)
    local found = nil
    local AccessPolicy
    local policy_check = false
	local macList_num
	local axmacList_num
	local axMacFlag = false
	local AccessControlList

    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_macList then
        old_macList = {}
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    if not param_table.mac or param_table.mac == "" then
        msg = "mac is empty"
        return nil, msg
    end
    if not param_table.name then
        param_table.name = ""
        debug("name is nil,default empty")
    end
    if not old_axmacList then
        old_axmacList = {}
    end
    local macList = old_macList
	local axMacList = old_axmacList
    for k,v in pairs(macList) do
        if string.upper(v.mac) == string.upper(param_table.mac) then
            found = true
            msg = "have exist mac, add config fail"
            return nil, msg
        end
    end
	if not found and axMacList then
		for k,v in pairs(axMacList) do
			if string.upper(v.mac) == string.upper(param_table.mac) then
				--found = true
				msg = "axList have exist mac, add config fail"
				--return nil, msg
				debug(msg)
			end
		end
	end
	macList_num = #macList
    if not found then
        local data = {mac = string.upper(param_table.mac), name = param_table.name}
		if macList_num < 30 then
			table.insert(macList, data)
		else
			table.insert(axMacList, data)
			axMacFlag = true
		end
        msg = "add config, mac:"..param_table.mac.." name:"..param_table.name
        debug(msg)
    end
    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" or axMacFlag then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end
	uci:foreach("wireless", "wifi-device", function(s)
		local is_find = add_find_acl(s.AP_AccessControlList, param_table.mac)
		if is_find == true then
			debug(param_table.mac .. ",the mac uci already exised")
			return true
		end
		--check accesspolicy existence
		if not s.AP_AccessPolicy then
			msg = string.format("Set %s AP_AccessPolicy %d", s[".name"], AccessPolicy)
			debug(msg)
			uci:set("wireless", s[".name"], "AP_AccessPolicy", AccessPolicy)
		end
	
		--set acl
		if tostring(AccessPolicy) ~= s.AP_AccessPolicy then
			msg = string.format("Configuration accesspolicy is not the same")
			debug(msg)
			return
		end

		if not s.AP_AccessControlList then
			AccessControlList = string.format('%s', string.upper(param_table.mac))
		else
			AccessControlList = string.format('%s;%s', string.upper(s.AP_AccessControlList), string.upper(param_table.mac))
		end
		msg = string.format("AccessControlList after add is %s", AccessControlList)
		debug(msg)
		uci:set("wireless", s[".name"], "AP_AccessControlList", AccessControlList)
	end)

    uci:foreach("wireless", "wifi-iface", function(s)
        if s.wlan_id == hide_ssid_idx then
            debug("dev_type is ehr, do not set hide ssid")
            uci:set("wireless", s[".name"], "repeater_hidden", "1")
        end
    end)
    uci:commit("wireless")
    return true
end
--del config
local function del_config(param, old_macList, old_axmacList)
    local new_maclist
    local found = false
    local pre_maclist
    local AccessPolicy
    local policy_check = false
	local addAccessControlList = ""
	local AccessControlList = ""

    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_macList or old_macList == "" then
        msg = "old maclist is null"
        return nil, msg
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    local macList = param_table.macList
    if not macList then
        msg = "macList is nil, del config fail"
        return nil, msg
    end
    for k,v in pairs(macList) do
        for m,n in pairs(old_macList) do
            if not n.mac then
                msg = "old mac is nil, del fail"
                debug(msg)
            else
                if string.upper(v) == string.upper(n.mac) then
                    debug("del mac " .. v)
                    table.remove(old_macList, m)
                    break
                end
            end
        end
		if old_axmacList then
			if tonumber(ap_acl_num) == g_macList_num then
				old_axmacList = {}
				debug("clear old_axmacList")
			else
				for i,j in pairs(old_axmacList) do
					if not j.mac then
						msg = "old axmac is nil, del fail"
						debug(msg)
					else
						if string.upper(v) == string.upper(j.mac) then
							debug("del axmac " .. v)
							table.remove(old_axmacList, i)
							break
						end
					end
				end
			end
		end
    end
	debug("macList num:"..#old_macList.."  old_axmacList:"..#old_axmacList)
	if #old_macList < 30 and #old_axmacList > 0 then
		addAccessControlList = acl_and_axacl_sort(old_macList, old_axmacList)
		debug("addAccessControlList:"..addAccessControlList)
	end
    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end

	uci:foreach("wireless", "wifi-device", function(s)
		--check accesspolicy existence
		if not s.AP_AccessPolicy then
			msg = string.format("Set %s AP_AccessPolicy %d", s[".name"], AccessPolicy)
			debug(msg)
			uci:set("wireless", s[".name"], "AP_AccessPolicy", AccessPolicy)
		end
		--set acl
		if tostring(AccessPolicy) ~= s.AP_AccessPolicy then
			msg = string.format("Configuration accesspolicy is not the same")
			debug(msg)
			return
		end
		if s.AP_AccessControlList then
			AccessControlList = del_acl_string(string.upper(s.AP_AccessControlList), macList)
			if addAccessControlList ~= "" then
				if AccessControlList ~= "" then
					AccessControlList = AccessControlList .. ";" .. addAccessControlList
				else
					AccessControlList = addAccessControlList
				end
			end
			msg = string.format("AccessControlList after delete is %s", AccessControlList)
			debug(msg)
			uci:set("wireless", s[".name"], "AP_AccessControlList", AccessControlList)
		else
			msg = string.format("AccessControlList is empty")
			debug(msg)
		end
	end)

    uci:commit("wireless")
    return true
end
--update config
local function update_config(param, old_macList, old_axmacList)
    local AccessPolicy
    local policy_check = false
    local change_name_flag = nil
	local AccessControlList

    --入参校验
    if not param then
        msg = "param is nil"
        return nil, msg
    end
    if not old_macList or old_macList == "" then
        msg = "old maclist is null"
        return nil, msg
    end
    local param_table = json.decode(param)
    local AclType = param_table.type
    if not param_table.old then
        msg = "input old is nil"
        return nil, msg
    end
    if not param_table.old.mac then
        msg = "input old mac is nil"
        return nil, msg
    end
    if not param_table.new then
        msg = "input new is nil"
        return nil, msg
    end
    if not param_table.new.mac then
        msg ="input new mac is nil"
        return nil, msg
    end
    --new.name不存在，默认为空
    if not param_table.new.name then
        param_table.new.name = ""
    end
    local is_old_exist = false
    for k,v in pairs(old_macList) do
        if not v.mac then
            msg = "old mac is nil, update fail"
            debug(msg)
        else
            if string.upper(v.mac) == string.upper(param_table.old.mac) then
                is_old_exist = true
                break
            end
        end
    end
	if old_axmacList then
		for m,n in pairs(old_axmacList) do
			if not n.mac then
				msg = "old mac is nil, update fail"
				debug(msg)
			else
				if string.upper(n.mac) == string.upper(param_table.old.mac) then
					is_old_exist = true
					break
				end
			end
		end
	end
    if not is_old_exist then
        msg = "old mac is not existed,update fail"
        return nil, msg
    end
--配置文件修改
    for k,v in pairs(old_macList) do
        if string.upper(v.mac) == string.upper(param_table.old.mac) and string.upper(v.mac) ~= string.upper(param_table.new.mac) then
            v.mac = string.upper(param_table.new.mac)
            v.name = param_table.new.name
            msg = "update config,old mac:" .. param_table.old.mac .. " new mac:" .. param_table.new.mac .. " new name:" .. param_table.new.name
            debug(msg)
            break
        elseif string.upper(v.mac) == string.upper(param_table.new.mac) and v.name ~= param_table.new.name then
            change_name_flag = true
            msg = "update config,old name:" .. v.name .. " new name:" .. param_table.new.name
            v.name = param_table.new.name
            debug(msg)
            return true
        end
    end
	if old_axmacList then
		for m,n in pairs(old_axmacList) do
			if string.upper(n.mac) == string.upper(param_table.old.mac) and string.upper(n.mac) ~= string.upper(param_table.new.mac) then
				n.mac = string.upper(param_table.new.mac)
				n.name = param_table.new.name
				msg = "update config,old axmac:" .. param_table.old.mac .. " new axmac:" .. param_table.new.mac .. " new axname:" .. param_table.new.name
				debug(msg)
				break
			elseif string.upper(n.mac) == string.upper(param_table.new.mac) and n.name ~= param_table.new.name then
				change_name_flag = true
				msg = "update config,old axname:" .. n.name .. " new axname:" .. param_table.new.name
				n.name = param_table.new.name
				debug(msg)
				return true
			end
		end
	end
    --判断是否支持wifi功能，是则继续执行
    if is_support_wifi ~= "1" then
        msg = "device is not support wifi, uci operation cancel"
        debug(msg)
        return true
    end
    if AclType == "allow" then
        AccessPolicy = 1
    else
        AccessPolicy = 2
    end

	uci:foreach("wireless", "wifi-device", function(s)
		--check accesspolicy existence
		if not s.AP_AccessPolicy then
			msg = string.format("Set %s AP_AccessPolicy %d", s[".name"], AccessPolicy)
			debug(msg)
			uci:set("wireless", s[".name"], "AP_AccessPolicy", AccessPolicy)
		end
		--set acl
		if tostring(AccessPolicy) ~= s.AP_AccessPolicy then
			msg = string.format("Configuration accesspolicy is not the same")
			debug(msg)
			return
		end

		AccessControlList = update_acl_string(s.AP_AccessControlList, string.upper(param_table.old.mac), string.upper(param_table.new.mac))
		msg = string.format("AccessControlList after update is %s", AccessControlList)
		debug(msg)
		uci:set("wireless", s[".name"], "AP_AccessControlList", AccessControlList)
	end)

    uci:commit("wireless")
    return true
end
--增量配置
function module_update(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end
	if all_config_table.axMacList and tonumber(ap_acl_num) == g_macList_num then
		all_config_table.axMacList = {}
		debug("update clear axMacList")
	end
    local ok, err, msg = pcall(update_config, param, all_config_table.macList or "", all_config_table.axMacList)
--保存配置文件
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug("Update Completed")
    unlock()
end
function module_add(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end
	if not all_config_table.macList then
		all_config_table.macList = {}
	end
	if not all_config_table.axMacList then
		all_config_table.axMacList = {}
	end

	debug("ap_acl_num:"..ap_acl_num)
	if tonumber(ap_acl_num) == g_macList_num then
		if #all_config_table.macList >= g_macList_num then
			local data = {status = "failed", msg = "add great than 256", rcode = "01450002", num = ap_acl_num}
			debug(json.encode(data))
			unlock()
			return json.encode(data)
		end
	else
		if ability_threshold(all_config_table.macList, all_config_table.axMacList) >= tonumber(ap_acl_num) then
			local data = {status = "failed", msg = "add great than 256", rcode = "01450002", num = ap_acl_num}
			debug(json.encode(data))
			unlock()
			return json.encode(data)
		end
	end
    local ok, err, msg = pcall(add_config, param, all_config_table.macList or "", all_config_table.axMacList)
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    debug("Add Completed")
    unlock()
end
function module_del(param, config_path)
    lock()
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local all_config_table = json.decode(console.read_file(config_path))
    local i = 0
    while(not all_config_table)
    do
        if i >= 9 then
            unlock()
            return console.fail("config is nil")
        end
        i = i + 1
        all_config_table = json.decode(console.read_file(config_path))
    end
	if all_config_table.axMacList and tonumber(ap_acl_num) == g_macList_num then
		all_config_table.axMacList = {}
		debug("del clear axMacList")
	end
    local ok, err, msg = pcall(del_config, param, all_config_table.macList or "", all_config_table.axMacList)
    if not ok then
        debug(err)
        unlock()
        return
    end
    if not err then
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    local config = json.encode(all_config_table)
    console.write_file(config_path, config, "w")
    debug("Delete Completed")
    unlock()
end
--全量配置
--获取默认配置
function module_default_config_get()
    local default_config = '{"type":"deny","macList":[],"axMacList":[]}'
    return default_config
end
--ssid过滤
local function wirelessMacFilter_set_ssid(AclType, AccessControlList)
    local AccessPolicy
--提取出输入的所有mac
    local new_AccessControlList = ''  --这里不能用nil，不然clear时会报错
    for k, v in pairs(AccessControlList) do
        if not v.mac or v.mac == "" then
            msg = "mac is not existed"
            return nil, msg
        end
    end
    for k, v in pairs(AccessControlList) do
        if new_AccessControlList == '' then
            new_AccessControlList = string.format('%s', string.upper(v.mac))
        else
            new_AccessControlList = string.format('%s;%s', new_AccessControlList, string.upper(v.mac))
        end
    end
    if AclType == "allow" then
        AccessPolicy = 1
    elseif AclType == "deny" then
        AccessPolicy = 2
    elseif AclType == "disable" then
        AccessPolicy = 0
    end

	uci:foreach("wireless", "wifi-device", function(s)
		msg = string.format("AccessControlList after set is %s", (new_AccessControlList or ""))
		debug(msg)
		uci:set("wireless", s[".name"], "AP_AccessControlList", (new_AccessControlList or ""))
		uci:set("wireless", s[".name"], "AP_AccessPolicy", (AccessPolicy or ""))
	end)

    uci:foreach("wireless", "wifi-iface", function(s)
        if s.wlan_id == hide_ssid_idx then
            debug("dev_type is ehr, do not set hide ssid")
            uci:set("wireless", s[".name"], "repeater_hidden", "1")
        end
    end)
    uci:commit("wireless")
    return true
end
--框架调用的macFilter模块set接口
function module_set(param)
    lock()
    local AclType
    local AccessControlList
    local msg
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        unlock()
        return console.fail(msg)
    end
    debug(param)
    local paramTable = json.decode(param)
    AclType = paramTable.type
    if AclType ~= "allow" and AclType ~= "deny" then
        AclType = "disable"
    end
    local AccessControlList = paramTable.macList
    if not AccessControlList then
        AccessControlList = ""
        msg = "AccessControlList is nil"
        unlock()
        return console.fail(msg)
    end
	get_dev_role()
	if dev_role and string.find(dev_role, "AC") then
		if tonumber(ap_acl_num) == g_macList_num then
			if #paramTable.macList > g_macList_num then
				local data = {status = "failed", msg = "set great than 256", rcode = "01450002", num = ap_acl_num}
				debug(json.encode(data))
				unlock()
				return json.encode(data)
			end
		else
			if ability_threshold(paramTable.macList, paramTable.axMacList) > tonumber(ap_acl_num) then
				local data = {status = "failed", msg = "set great than 256", rcode = "01450002", num = ap_acl_num}
				debug(json.encode(data))
				unlock()
				return json.encode(data)
			end
		end
	end
    if is_support_wifi == "1" then
        local ok, err, msg = pcall(wirelessMacFilter_set_ssid, AclType, AccessControlList)
        if not ok then
            debug(err)
            unlock()
            return
        end
        if not err then
            debug(msg)
            unlock()
            return console.fail(msg)
        end
--wifi reload
        sh_cmd = "wifi reload"
        console.forkExec(sh_cmd)
    end
    debug("wireless success")
    unlock()
end

function module_apply()
    sh_cmd = "wifi reload"
    console.forkExec(sh_cmd)
    debug("Apply Completed")
end
debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")