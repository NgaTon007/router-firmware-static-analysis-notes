#!/usr/bin/lua
module("apmeshNetworkSetup", package.seeall);  --必须要有
package.path = "/usr/lib/lua/?.lua;" .. package.path;
local console = require 'console'
local dkjson = require "dkjson" 
local uci = require "luci.model.uci".cursor()

local function debug(msg)
    console.debug("apmeshNetworkSetup", msg)
end

function module_default_config_get()
    local data = {
        onboarding = {
            routescan = "1",
            meshdisc  = "1",
            choicepair = "11:22:33:44:55:66"
        }
    }
    return dkjson.encode(data)
end

function module_set(param)
    debug("param:"..param)
    local paramTable = dkjson.decode(param)
    local table = {rcode= "04090014", rmsg= "parameter apmeshNetworkSetup:mode or bssid is invalid, require <apmesh_scan|apmesh_choicepair> or [xx:xx:xx:xx:xx:xx]"}
    if paramTable ~= nil and paramTable.mode then
        if paramTable.mode == "apmesh_scan" then
            local apmesh_scan_enable   = paramTable.enable or "0"
            debug("apmesh_scan_enable=" .. apmesh_scan_enable)
            if apmesh_scan_enable and (apmesh_scan_enable == "0" or apmesh_scan_enable == "1") then
                debug(string.format("uci set apmgr.onboarding.routescan_enable=%s", apmesh_scan_enable))
                debug("uci commit apmgr")
                os.execute(string.format("uci set apmgr.onboarding.routescan_enable=%s", apmesh_scan_enable))
                os.execute("uci commit apmgr")
            else
                return console.uf_lua_fail(table)
            end
            if apmesh_scan_enable and apmesh_scan_enable == '1' then
                debug("ubus -t 3 call apmgr apmesh_apdisc_scan")
                os.execute("ubus -t 3 call apmgr apmesh_apdisc_scan")
            end
        elseif paramTable.mode == "apmesh_choicepair" then
            local bssid         = paramTable.bssid or "11:22:33:44:55:66"
            local mac_str       = ""
            if bssid and #bssid ~= 0 then
                local flag = 0
                debug("uci delete apmgr.onboarding.choicepair")
                os.execute("uci delete apmgr.onboarding.choicepair")
                if type(bssid) ~= "table" then
                    return console.uf_lua_fail(table)
                end
                for i, v in ipairs(bssid) do
                    if string.match(v, "^%x+:%x+:%x+:%x+:%x+:%x+$") then
                        flag = 1
                    else
                        debug("Invalid BSSID format: "..v)
                        return console.uf_lua_fail(table)
                    end

                    debug(string.format("uci add_list apmgr.onboarding.choicepair=%s", v))
                    os.execute(string.format("uci add_list apmgr.onboarding.choicepair=%s", v))
                    if i == 1 then
                        mac_str = v
                    else
                        mac_str =  mac_str .. "#".. v
                    end
                end

                if flag == 0 then
                    debug("Invalid BSSID format: "..bssid)
                    return console.uf_lua_fail(table)
                end
                debug(string.format("ubus -t 3 call apmgr apmesh_choicepair '{\"mac_str\":\"%s\",\"mac_num\":\"%d\"}'", mac_str, #bssid))
                os.execute(string.format("ubus -t 3 call apmgr apmesh_choicepair '{\"mac_str\":\"%s\",\"mac_num\":\"%d\"}'", mac_str, #bssid))
                debug("uci commit apmgr")
                os.execute("uci commit apmgr")
				debug(string.format("lua /usr/lib/lua/smb/apmeshMergeSn.lua '{\"mac_str\":\"%s\",\"mac_num\":\"%d\"}'", mac_str, #bssid))
				console.forkExec(string.format("lua /usr/lib/lua/smb/apmeshMergeSn.lua '{\"mac_str\":\"%s\",\"mac_num\":\"%d\"}'", mac_str, #bssid))
            end
        else
            return console.uf_lua_fail(table)
        end
    else
        return console.uf_lua_fail(table)
    end
    return console.uf_lua_success()
end
