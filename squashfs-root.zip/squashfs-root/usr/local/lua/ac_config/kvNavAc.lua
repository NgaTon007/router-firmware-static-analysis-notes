#!/usr/bin/lua
module("kvNavAc",package.seeall)
local console = require "console"
local cjson = require("cjson")
local libc2lua = require("libc2lua")
local table = {rcode= "04100014", rmsg= "parameter kvNavAc:param is invalid"}

local function debug(msg)
    console.debug("kvNavAc", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/kvNavAc.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/kvNavAc.lock")
end

local function method_check(method)
    if (method == "start" or method == "clear"or method == "global" or method == "ap" or method == "sta") then
        return true
    else
        return false
    end
end

local function kv_nav_enable_check(method, n_data, z_data)
    if (method == "global" and n_data == "roamNavEnable" and z_data == 2 or z_data == 3) then --force sacn flag
        return true
    else
        return false
    end
end

local function execute_cmd(method, json_data)
    local cmd = "ubus -t 5 call kv_nav " .. method .. " '" .. cjson.encode(json_data) .. "'"
    debug("exec:" .. cmd)
    os.execute(cmd);
end

function module_update(param, config_path)
    debug("update:" .. param)
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    lock()
    local config = cjson.decode(console.read_file(config_path))
    local info = cjson.decode(param)
    for k_method, v_method in pairs(info) do
        if method_check(k_method) then
            if (config[k_method] == nil) then
                config[k_method] = {}
            end
            for k_data, v_data in pairs(v_method) do
                if kv_nav_enable_check(k_method, k_data, v_data) then
                    config[k_method][k_data] = 1 --force sacn save as kv nav enable
                    config[k_method]["roamOptiMode"] = tostring(v_data)
                    config[k_method]["start_scan_time"] = os.time()
                else
                    config[k_method][k_data] = v_data
                end
            end
            execute_cmd(k_method, v_method)
            if (k_method == "start") then
                config[k_method] = nil
            end
        end
    end
    
    console.write_file(config_path, cjson.encode(config), "w")
    unlock()

    debug("update succ.")
    return console.uf_lua_success()
end

function module_default_config_get()
    local default_config = '{"global": {"roamNavEnable": 0}}'
    return default_config
end

function module_set(param)
    debug(param);
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    local info = cjson.decode(param)
    for k_method, v_method in pairs(info) do
        if method_check(k_method) then
            execute_cmd(k_method, v_method)
        end
    end
    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")

