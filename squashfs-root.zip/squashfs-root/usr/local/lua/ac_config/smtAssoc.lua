#!/usr/bin/lua
module("smtAssoc",package.seeall)
local console = require "console"
local json = require("dkjson")
local libc2lua = require("libc2lua");
local table = {rcode= "04120014", rmsg= "parameter smtAssoc:param is invalid"}

local function debug(msg)
    console.debug("smtAssoc", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/smtAssoc.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/smtAssoc.lock")
end

local function execute_cmd(method, json_data)
    local cmd = "ubus -t 8 call rmtAssoc " .. method .. " '" .. "{\"smt_cfg\":" .. json.encode(json_data) .. "}'"
    debug("exec:" .. cmd)
    os.execute(cmd)
end

function module_default_config_get()
    local default_config = '{"global":{"aSmtCfg":[]}}'
    return default_config
end

function module_set(param)
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        msg = "input is invalid"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    debug(param);
    local jsonData = json.decode(param)
    execute_cmd("set_config", jsonData.global.aSmtCfg)
    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")