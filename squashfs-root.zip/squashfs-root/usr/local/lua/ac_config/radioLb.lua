#!/usr/bin/lua
module("radioLb",package.seeall)
local console = require "console"
local cjson = require("cjson")
local libc2lua = require("libc2lua");
local table = {rcode= "04170014", rmsg= "parameter radioLb:param is invalid"}

local function debug(msg)
    console.debug("radioLb", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/radioLb.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/radioLb.lock")
end

local function execute_cmd(json_data)
    local cmd = "ubus -t 5 call radio_lb config '" ..json_data .. "'"
    debug("exec:" .. cmd)
    os.execute(cmd);
end

function module_update()
    return console.uf_lua_success()
end

function module_default_config_get()
    local default_config = '{"enable": "0", "start_num" : "3", "max_diff" : "3", "reject_num" : "10"}'
    return default_config
end

function module_set(param)
    debug(param);
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    execute_cmd(param)
    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")

