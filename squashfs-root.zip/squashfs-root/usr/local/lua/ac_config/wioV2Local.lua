#!/usr/bin/lua
module("wioV2Local",package.seeall)
local console = require "console"
local cjson = require("cjson")
local libc2lua = require("libc2lua");
local table = {rcode= "04190014", rmsg= "parameter wioV2Local:param is invalid"}

local function debug(msg)
    console.debug("wioV2Local", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/wioV2Local.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/wioV2Local.lock")
end

local function method_check(method)
    if (method == "wiov2Global") then
        return true
    else
        return false
    end
end


local function debug_cmd(method, json_data)
    local cmd = "wio v2 local info" .. method .. " '" .. cjson.encode(json_data) .. "'"
    debug("exec:" .. cmd)
end

function module_update(param, config_path)
    debug("update:" .. param)
    if (param == nil or config_path == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    lock()
    local config = cjson.decode(console.read_file(config_path))
    local info = cjson.decode(param)
    for k_method, v_method in pairs(info) do
        if method_check(k_method) then
            if (config[k_method] == nil) then
                config[k_method] = {}
            end
            for k_data, v_data in pairs(v_method) do
                config[k_method][k_data] = v_data
            end
            debug_cmd(k_method, v_method)
        end
    end
    
    console.write_file(config_path, cjson.encode(config), "w")
    unlock()
    
    debug("update succ.")
    return console.uf_lua_success()
end

function module_default_config_get()
    local default_config = '{"wiov2Global":{"wioV2FsmStatus": 0}}'
    return default_config
end

function module_set(param)
    debug(param);
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    local info = cjson.decode(param)
    for k_method, v_method in pairs(info) do
        if method_check(k_method) then
            debug_cmd(k_method, v_method)
        end
    end
    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")