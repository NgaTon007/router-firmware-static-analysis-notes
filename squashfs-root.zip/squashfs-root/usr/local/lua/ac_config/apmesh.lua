#! /usr/bin/lua

module("apmesh", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local dev_config = require "dev_config"
local libc2lua = require("libc2lua")
local sd_product = require("product")

local web_cap_key = sd_product.get_product("capacity.web");

--debug
local function debug(msg)
    console.debug("apmesh", msg)
end

function module_default_config_get()
    local data = {}
    --local rlink_enable = uci:get("apmgr",'global','rlink_enable') or '0'
    --data.rlink_enable = rlink_enable == "1" and "true" or "false"
    local auto_join = uci:get_first("sysinfo", "sysinfo", "autoJoin")
    data.rlink_enable = auto_join
    return dkjson.encode(data)
end

function module_set(param)
    -- 入参检查，防止shell注入安全漏洞
    local table = {rcode= "04090014", rmsg= "parameter apmesh:rlink_enable is invalid, require <true|false>"}
    if (param ~= nil) then
        if (libc2lua.lua_param_safety_check(param) ~= true) then
            debug(string.format("param is invalid!  param is %s\n", param))
            return console.uf_lua_fail(table)
        end
    end

    local paramTable = dkjson.decode(param)
    debug(paramTable.rlink_enable)
    local sd_device_file = string.format("/tmp/sd_device/sd_device.json")
    if console.is_file_exist(sd_device_file) then
        debug("config file "..sd_device_file.." is exist")
        data = dkjson.decode(console.read_file(sd_device_file))
        if not data then
            debug("sd_device json decode is not exist")
            return console.uf_lua_fail(table)
        else
            if data[web_cap_key].ap_mesh == null then 
                debug("data[web_cap_key].ap_mesh is null")
                return console.uf_lua_fail(table)
            end
            if (data[web_cap_key].ap_mesh == "0") then 
                debug("this dev is not support apmesh")
                return console.uf_lua_fail(table)
            end
            debug("data[web_cap_key].ap_mesh:"..data[web_cap_key].ap_mesh)
        end
    end
    if paramTable and paramTable.rlink_enable and paramTable.rlink_enable == "true" then
        debug("dev_config set -m mesh \'{\"rlink_enable\":\"true\"}\'")
        --os.execute("dev_config set -m mesh \'{\"rlink_enable\":\"true\"}\'")
        dev_config.fetch("set","mesh",'{"rlink_enable":"true"}')
        debug("end true")
    elseif paramTable and paramTable.rlink_enable and paramTable.rlink_enable == "false" then
        debug("dev_config set -m mesh \'{\"rlink_enable\":\"false\"}\'")
        --console.forkExec("dev_config set -m mesh \'{\"rlink_enable\":\"false\"}\'")
        dev_config.fetch("set","mesh",'{"rlink_enable":"false"}',"1")
        debug("end false")
    else
        return console.uf_lua_fail(table)
    end
    return console.uf_lua_success()
end

