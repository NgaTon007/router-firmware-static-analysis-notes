#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_func",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
require "public_module"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_func.lock"

function module_default_config_get()
    local data = {}
    get_type = tool.exec("uci get nt_mgr.@main[0].enable")
    if (string.find(get_type, "on")) then
        data.func = "enable"
    elseif (string.find(get_type, "off")) then
        data.func = "disable"
    else
        data.func = "disable"
    end
    return cjson.encode(data)
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        return false;
    else
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

function nt_mgr_funcmgr_execute_command(command)
    local file = io.popen(command)
    local output = file:read("*a")
    file:close()
    return output
end

function nt_mgr_funcmgr_update()
    local command1 = 'jq -r .gateway.funcmgr "/tmp/sd_device/sd_device.json" 2>/dev/null'
    local result = nt_mgr_funcmgr_execute_command(command1)

    if result ~= nil and result ~= "null" and result ~= "0" then
        local command2 = 'dev_config update -m funcmgr \'{"cmd":"upSta","data":{"funcName": ["nt_mgr_v2"],"switch":0},"callSource":"module"}\''
        local output = nt_mgr_funcmgr_execute_command(command2)
        print(output)
    end
end

--@nt_mgr_func_set
function nt_mgr_func_set(param)
    if (param == nil or tool.json_check(param) == false) then
        return -1
    end

    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        return -1
    end

    local set_type = param_tab["func"]
    if (set_type == "enable") then
        --uci:set("nt_mgr", "main", "enable",  "on")
        --uci:commit("nt_mgr")
        -- tool.exec("echo 1 > /sys/module/nt_sniffer/parameters/hook")
        -- hook should be enabled by nt_mgr_v2.elf via iotcl after nt_mgr_v2 is started.
        tool.exec("uci set nt_mgr.@main[0].enable='on'")
        tool.exec("uci commit nt_mgr")
        os.execute("ubus -t 3 send \"nt_mgr_v2_restart\"")
        tool.sleep(10);
    elseif (set_type == "disable") then
        --uci:set("nt_mgr", "main", "enable",  "off")
        --uci:commit("nt_mgr")
        tool.exec("[ -w /sys/module/nt_sniffer/parameters/hook ] && echo 0 > /sys/module/nt_sniffer/parameters/hook 2>/dev/null")
        tool.exec("[ -w /sys/class/misc/nt_sniffer/mac_flush ] && echo f > /sys/class/misc/nt_sniffer/mac_flush 2>/dev/null")
        tool.exec("uci set nt_mgr.@main[0].enable='off'")
        tool.exec("uci commit nt_mgr")
        nt_mgr_funcmgr_update()
        os.execute("ubus -t 3 send \"nt_mgr_v2_restart\"")
    else
        return -1
    end

    return 0
end

--@module_set
function module_set(param)
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"Fail!\"}"
    end

    if (nt_mgr_func_set(param) < 0) then
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"Fail!\"}"
    end

    os.remove(LOCK_FILE)
    return "{\"code\":\"0\",\"msg\":\"Success\"}"
end

--@module_get
function module_get()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"Fail!\"}"
    end
    --get_type = uci:get("nt_mgr", "main", "enable")
    get_type = tool.exec("uci get nt_mgr.@main[0].enable")
    if (string.find(get_type, "on")) then
        os.remove(LOCK_FILE)
        return "{\"code\":\"1\",\"msg\":\"Process open status\"}"
    elseif (string.find(get_type, "off")) then
        os.remove(LOCK_FILE)
        return "{\"code\":\"2\",\"msg\":\"Process close status\"}"
    end
    os.remove(LOCK_FILE)
    return "{\"code\":\"-1\",\"msg\":\"Fail!\"}"
end

function module_apply()
end
