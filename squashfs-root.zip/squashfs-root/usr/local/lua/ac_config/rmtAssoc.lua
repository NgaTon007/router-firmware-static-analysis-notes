#!/usr/bin/lua
module("rmtAssoc",package.seeall)
local console = require "console"
local json = require("dkjson")
local libc2lua = require("libc2lua");
local table = {rcode= "04110014", rmsg= "parameter rmtAssoc:param is invalid"}

local function debug(msg)
    console.debug("rmtAssoc", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/rmtAssoc.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/rmtAssoc.lock")
end

local function execute_cmd(method, json_data)
    local cmd = "ubus -t 5 call rmtAssoc " .. method .. " '" .. "{\"ap_cache\":" .. json.encode(json_data) .. "}'"
    debug("exec:" .. cmd)
    os.execute(cmd)
end

function module_default_config_get()
    local default_config = '{"global":{"aStaList":[]}}'
    return default_config
end

function module_set(param)
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        msg = "input is invalid"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    debug(param);
    local jsonData = json.decode(param)
    execute_cmd("set_config", jsonData.global.aStaList)
    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")