#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("mqlink", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libtab = require("utils.table");
local libubs = require("utils.ubus");
local dkjson = require("dkjson");

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/mqlink/", "mqlink.lua.log", 200, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("mqlink"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- ���󷵻�
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = require("dkjson").encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return require("dkjson").encode(res);
end

-- @mqlink_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ

    -- 1���������
    -- {"user":"uni","show":"<sysinfo|config|status|retrans_list|retrans_count>"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink get parameter is nil");
        return module_ret("0012", "mqlink get parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta get -m mqlink '%s'", param);

    -- 2����������
    local tab = require("dkjson").decode(param);
    -- 2.1������������user
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink get require parameter:user");
        return module_ret("0013", "mqlink get require parameter:user");
    end
    -- 2.2������������show
    local show_tab = {
        "sysinfo",
        "config",
        "status",
        "retrans_list",
        "retrans_count",
    }
    if (tab["show"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:show is nil");
        return module_ret("0013", "mqlink get require parameter:show");
    elseif (type(tab["show"]) ~= "string" or require("utils.table").val_in_table(show_tab, tab["show"]) == false) then
        libdbg.lua_debug(libdbg.ERROR, "parameter show is invalid, require <sysinfo|config|status|retrans_list|retrans_count>");
        return module_ret("0014", "parameter show is invalid, require <sysinfo|config|status|retrans_list|retrans_count>");
    end

    if (tab["show"] == "sysinfo") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink sysinfo");
        local ubus_tab = libubs.ubus_call("mqlink", "sysinfo", {}, 3);
        return require("dkjson").encode(ubus_tab);
    elseif (tab["show"] == "config") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink config");
        local libtbl = require("utils.table");
        tab = libtbl.remove_by_key(tab, "user");
        tab = libtbl.remove_by_key(tab, "show");
        local ubus_tab = libubs.ubus_call("mqlink", "config", tab, 3);
        return require("dkjson").encode(ubus_tab);
    elseif (tab["show"] == "status") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink status");
        local ubus_tab = libubs.ubus_call("mqlink", "status", {}, 3);
        return require("dkjson").encode(ubus_tab);
    elseif (tab["show"] == "retrans_list") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_list");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_list", {}, 3);
        return require("dkjson").encode(ubus_tab);
    elseif (tab["show"] == "retrans_count") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_count");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_count", {}, 3);
        return require("dkjson").encode(ubus_tab);
    end

    ret_str = '{"rcode":"00000000","rmsg":"OK"}';
    libdbg.lua_debug(libdbg.INFO, "return:%s", ret_str);

    return ret_str;
    -- return;
end

-- @mqlink_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_set()********************");

    -- 1���������
    -- {"user":"uni","op":"<start|stop|restart|sync_notify>"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink set parameter is nil");
        return module_ret("0012", "mqlink set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m mqlink '%s'", param);

    -- 2����������
    local tab = require("dkjson").decode(param);
    -- 2.1������������user
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink set require parameter:user");
        return module_ret("0013", "mqlink set require parameter:user");
    end
    -- 2.2������������op
    local op_tab = {
        "start",
        "stop",
        "restart",
        "sync_notify",
        "retrans_set_enable",
        "retrans_set_period",
        "retrans_set_limit",
        "retrans_delete",
        "retrans_clean",
    }
    if (tab["op"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:op is nil");
        return module_ret("0013", "mqlink set require parameter:op");
    elseif (type(tab["op"]) ~= "string" or require("utils.table").val_in_table(op_tab, tab["op"]) == false) then
        libdbg.lua_debug(libdbg.ERROR, "parameter op is invalid, require <start|stop|restart|sync_notify|retrans_set_enable|retrans_set_period|retrans_set_limit|retrans_delete|retrans_clean>");
        return module_ret("0014", "parameter op is invalid, require <start|stop|restart|sync_notify|retrans_set_enable|retrans_set_period|retrans_set_limit|retrans_delete|retrans_clean>");
    end

    if (tab["op"] == "start") then
        libdbg.lua_debug(libdbg.DEBUG, "/etc/init.d/mqlink start 2>/dev/null 1>&2");
        os.execute("/etc/init.d/mqlink start 2>/dev/null 1>&2");
    elseif (tab["op"] == "stop") then
        libdbg.lua_debug(libdbg.DEBUG, "/etc/init.d/mqlink stop 2>/dev/null 1>&2");
        os.execute("/etc/init.d/mqlink stop 2>/dev/null 1>&2");
    elseif (tab["op"] == "restart") then
        libdbg.lua_debug(libdbg.DEBUG, "/etc/init.d/mqlink restart 2>/dev/null 1>&2");
        os.execute("/etc/init.d/mqlink restart 2>/dev/null 1>&2");
    elseif (tab["op"] == "sync_notify") then
        libtab.remove_by_key(tab, "user");
        libtab.remove_by_key(tab, "op");
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink sync_notify '"..require("dkjson").encode(tab).."'");
        local ubus_tab = libubs.ubus_call("mqlink", "sync_notify", tab, 3);
        if (ubus_tab["code"] == nil or #ubus_tab["code"] == 0 or ubus_tab["code"] ~= "0") then
            libdbg.lua_debug(libdbg.ERROR, "errmsg:%s", ubus_tab["errmsg"]);
            return module_ret(ubus_tab["code"], "errmsg:%s", ubus_tab["errmsg"]);
        end
    elseif (tab["op"] == "retrans_set_enable") then
        libtab.remove_by_key(tab, "user");
        libtab.remove_by_key(tab, "op");
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_set_enable '"..require("dkjson").encode(tab).."'");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_set_enable", tab, 3);
        if (ubus_tab["code"] == nil or #ubus_tab["code"] == 0 or ubus_tab["code"] ~= "0") then
            libdbg.lua_debug(libdbg.ERROR, "errmsg:%s", ubus_tab["errmsg"]);
            return module_ret(ubus_tab["code"], "errmsg:%s", ubus_tab["errmsg"]);
        end
    elseif (tab["op"] == "retrans_set_period") then
        libtab.remove_by_key(tab, "user");
        libtab.remove_by_key(tab, "op");
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_set_period '"..require("dkjson").encode(tab).."'");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_set_period", tab, 3);
        if (ubus_tab["code"] == nil or #ubus_tab["code"] == 0 or ubus_tab["code"] ~= "0") then
            libdbg.lua_debug(libdbg.ERROR, "errmsg:%s", ubus_tab["errmsg"]);
            return module_ret(ubus_tab["code"], "errmsg:%s", ubus_tab["errmsg"]);
        end
    elseif (tab["op"] == "retrans_set_limit") then
        libtab.remove_by_key(tab, "user");
        libtab.remove_by_key(tab, "op");
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_set_limit '"..require("dkjson").encode(tab).."'");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_set_limit", tab, 3);
        if (ubus_tab["code"] == nil or #ubus_tab["code"] == 0 or ubus_tab["code"] ~= "0") then
            libdbg.lua_debug(libdbg.ERROR, "errmsg:%s", ubus_tab["errmsg"]);
            return module_ret(ubus_tab["code"], "errmsg:%s", ubus_tab["errmsg"]);
        end
    elseif (tab["op"] == "retrans_delete") then
        libtab.remove_by_key(tab, "user");
        libtab.remove_by_key(tab, "op");
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_delete '"..require("dkjson").encode(tab).."'");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_delete", tab, 3);
        if (ubus_tab["code"] == nil or #ubus_tab["code"] == 0 or ubus_tab["code"] ~= "0") then
            libdbg.lua_debug(libdbg.ERROR, "errmsg:%s", ubus_tab["errmsg"]);
            return module_ret(ubus_tab["code"], "errmsg:%s", ubus_tab["errmsg"]);
        end
    elseif (tab["op"] == "retrans_clean") then
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call mqlink retrans_clean");
        local ubus_tab = libubs.ubus_call("mqlink", "retrans_clean", {}, 3);
        return require("dkjson").encode(ubus_tab);
    end

    ret_str = '{"rcode":"00000000","rmsg":"OK"}';
    libdbg.lua_debug(libdbg.INFO, "return:%s", ret_str);

    return ret_str;
    -- return;
end
