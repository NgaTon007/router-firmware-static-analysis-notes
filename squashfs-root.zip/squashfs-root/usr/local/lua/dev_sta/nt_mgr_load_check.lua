#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_load_check",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local OUI_FILE = "/tmp/nt_info/nt_idy_oui.txt"
local RULE_FILE = "/tmp/nt_info/nt_rule.db"
local MD5_FILE = "/tmp/nt_info/md5.txt"
local OUI_TAR_FILE = "/tmp/nt_info/nt_oui.tar.gz"
local RULE_TAR_FILE = "/tmp/nt_info/nt_rule.tar.gz"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_load_check.lock"

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_load_check.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 检查文件完整性
function net_tml_load_md5_check(tmpPath)
    module_debug.lua_debug(module_debug.INFO, "tmpPath %s", tmpPath)
    --获取到文件的md5
    local file_md5_str = tool.split(tool.exec("md5sum "..tmpPath), "  ")[1]
    module_debug.lua_debug(module_debug.INFO, "file_md5_str %s", file_md5_str)
    -- 过滤字符串首尾的空白符
    local md5 =  string.gsub(tool.file_read(MD5_FILE), "^%s*(.-)%s*$", "%1")
    module_debug.lua_debug(module_debug.INFO, "md5 %s", md5)

    if (md5 ~= file_md5_str) then
        return -1
    end

    return 0
end

--@net_tml_load_set
function nt_mgr_load_check_set(param)
    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return -1
    end
    local update_type = param_tab["type"]
    if (update_type == "oui") then
        file_name = OUI_TAR_FILE
    end
    if (update_type == "rule") then
        file_name = RULE_TAR_FILE
    end

    if (tool.file_exist(file_name) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", file_name)
        return -1
    end

    cmd = "tar -zxvf "..file_name.." -C/tmp/nt_info"
    module_debug.lua_debug(module_debug.ERROR, "cmd %s", cmd)
    os.execute(cmd)
    -- 解压特征库压缩文件
    if (file_name == OUI_TAR_FILE) then      
        if (tool.file_exist(OUI_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", OUI_FILE)
            return -1
        end
        if (tool.file_exist(MD5_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", MD5_FILE)
            return -1
        end
        if (net_tml_load_md5_check(OUI_FILE) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: net_tml_load_md5_check is error")
            return -1
        end
    elseif (file_name == RULE_TAR_FILE) then
        if (tool.file_exist(RULE_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", RULE_FILE)
            return -1
        end
        if (tool.file_exist(MD5_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", MD5_FILE)
            return -1
        end
        if (net_tml_load_md5_check(RULE_FILE) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: net_tml_load_md5_check is error")
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] filename is error")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "################################SET END################################")
    return 0
end

--@module_set
function module_set(param)
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (nt_mgr_load_check_set(param) < 0) then
        os.remove(RULE_TAR_FILE)
        os.remove(OUI_TAR_FILE)
        os.remove(OUI_FILE)
        os.remove(RULE_FILE)
        os.remove(MD5_FILE)
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"md5 check failed\"}"
    end

    os.remove(MD5_FILE)
    os.remove(LOCK_FILE)

    return "{\"code\":\"0\",\"msg\":\"md5 check success\"}"
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end