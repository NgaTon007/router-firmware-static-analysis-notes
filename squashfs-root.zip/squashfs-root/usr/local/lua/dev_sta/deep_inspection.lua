--#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("deep_inspection", package.seeall)

local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lfs = require "lfs"
local libc2lua = require("libc2lua");
local cjson = require "cjson"

local DEBUG_LOG_DIR = "/tmp/deep_inspection/lua/"
local DEBUG_LOG_FILE = "deep_inspection.log"
local JSON_RESULT_FILE = "/etc/deep_inspection/result.json"

function param_check_safe(param)
    if (string.match(param, "([|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is unsafe");
        return false;
    end
    return true;
end

--判断文件夹是否存在,不存在创建
if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " > /dev/null 2>&1";
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, DEBUG_LOG_FILE, 500, module_debug.DEBUG, "1");
end

--深度检测进程状态查询
function get_process_stat()
    module_debug.lua_debug(module_debug.INFO, "################process_stat_get################");
    local proc_cnt = tonumber(tool.exec("ps | grep deep_inspection.elf | grep -v grep | wc -l"));
    module_debug.lua_debug(module_debug.INFO, "proc_cnt:%d", proc_cnt);
    return proc_cnt;
end

--开始检测
function start_detect(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################start_detect################");

    --进程已存在检测
    if (get_process_stat() ~= 0) then
        return "{\"error_code\":-99,\"msg\":\"already running\"}";
    end

    param_tab["log_level"] = "4";
    --重新转为json
    local json_str = cjson.encode(param_tab);

    --拉进程
    local cmd = string.format("/usr/sbin/deep_inspection.elf -j '%s' >/dev/null 2>&1", json_str);
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    tool.exec(cmd);
    tool.exec("sleep 1");

    return "{\"error_code\":0}";
end

--停止检测
function stop_detect(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################stop_detect################");

    --进程不存在直接返回
    if (get_process_stat() == 0) then
        return "{\"error_code\":-1,\"msg\":\"process not exsit\"}";
    end

    --通知主进程结束
    local cmd = string.format("/usr/sbin/deep_inspection_cmd.elf 'recv stop'");
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    local result = tool.exec(cmd);
    if (string.find(result, "connect_error") ~= nil) then
        tool.exec("usleep 20000");--给个20ms延时
        if (get_process_stat() ~= 0) then
            module_debug.lua_debug(module_debug.INFO, "cmd:%s", "killall -9 deep_inspection.elf");
            tool.exec("killall -9 deep_inspection.elf");--进程还在 强行结束 通常运行不到
        end
    end

    return "{\"error_code\":0}";
end

--获取结果
function get_result(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################get_result################");

    local result;
    local cmd;
    --进程不存在就读文件
    if (get_process_stat() == 0) then
        --判断文件是否存在 文件不存在说明从来没测速过 存在直接读文件
        if (tool.file_exist(JSON_RESULT_FILE) == false) then
            result = "{\"error_code\":-99,\"msg\":\"never detect\"}";
        else
            result = tool.file_read(JSON_RESULT_FILE);
        end
        return result;
    end

    --进程存在通过命令读
    cmd = string.format("/usr/sbin/deep_inspection_cmd.elf 'json_result'");
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    result = tool.exec(cmd);
    module_debug.lua_debug(module_debug.INFO, "result:%s", result);
    if (string.find(result, "connect_error") ~= nil) then
        tool.exec("usleep 20000");--给个20ms延时,让进程生成文件
        if (get_process_stat() ~= 0) then
          result = "{\"error_code\":-1,\"msg\":\"json file create error\"}";
          module_debug.lua_debug(module_debug.INFO, "result:%s", result);
        else
          result = tool.file_read(JSON_RESULT_FILE);
          module_debug.lua_debug(module_debug.INFO, "result:%s", result);
        end
        return result;
    end
    local result_tab = cjson.decode(result);
    if (result_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: cjson.decode error");
        return "{\"error_code\":-1,\"msg\":\"json decode error\"}";
    end
    if (result_tab["error_code"] == 0) then
        local result_file = result_tab["result_file"];
        module_debug.lua_debug(module_debug.INFO, "result_file:%s", result_file);
        if (tool.file_exist(result_file) == false) then
            if (tool.file_exist(JSON_RESULT_FILE) == false) then
            result = "{\"error_code\":-99,\"msg\":\"detect error\"}";
            module_debug.lua_debug(module_debug.INFO, "result:%s", result);
            else
                result = tool.file_read(JSON_RESULT_FILE);
            end
        else
            result = tool.file_read(result_file);
            cmd = string.format("rm -rf %s", result_file);
            tool.exec(cmd);
        end
    end

    return result;
end

--@module_get
function module_get(param)
    --debug初始化
    debug_init();

    --入参校验
    if (libc2lua.lua_param_safety_check(param) ~= true) then
    --if (param_check_safe(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe");
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil");
        end
        return "{\"error_code\":-1,\"msg\":\"param is unsafe!!\"}";
    end

    --json校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "Input data is not json mode.");
        return "{\"error_code\":-1,\"msg\":\"param is not json!\"}";
    end

    --json解析
    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] cjson.decode error");
        return;
    end

    --cmd提取
    local param_cmd = param_tab["cmd"];
    if(param_cmd == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] cmd is nil");
        return;
    end
    module_debug.lua_debug(module_debug.INFO, "param_cmd:%s", param_cmd);

    --cmd为开始检测
    if(param_cmd == "start") then
        module_debug.lua_debug(module_debug.INFO, "start");
        return start_detect(param_tab);
    end

    --cmd为停止检测
    if(param_cmd == "stop") then
        module_debug.lua_debug(module_debug.INFO, "stop");
        return stop_detect(param_tab);
    end

    --cmd为获取结果
    if(param_cmd == "get_result") then
        module_debug.lua_debug(module_debug.INFO, "get_result");
        return get_result(param_tab);
    end

end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end
