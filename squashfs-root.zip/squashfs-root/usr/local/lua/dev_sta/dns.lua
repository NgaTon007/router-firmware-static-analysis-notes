#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dns", package.seeall);

local console = require ("console")
local dkjson = require ("dkjson")
local utils_exec = require ("utils.exec")
local cjson_safe = require ("cjson.safe")
local cjson = require("cjson")
local libdbg = require ("utils.debug")
local moduleId = require ("dev_module_id")
local file_param = require "dev.tools.common"
local FILE_PATH = "/tmp/snmp/snmp.txt"
moduleName = "dns"
dbgDir = "/tmp/debug/dns/"
dbgFile = "dns.log"

--调试模块初始化
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

--错误返回
function module_ret(code, rdata, rmsg)
    local ret = {}
    ret["rdata"] = rdata
    ret["code"] = code
    ret["rmsg"] = rmsg
    res = ret
    if (code == "1") then
        local json_str = cjson_safe.encode(res)
        libdbg.lua_debug(libdbg.INFO,"return json_str:%s\n",json_str)
    end

    return cjson_safe.encode(ret)
end

--get操作
function module_get(param)
    local get_data = {}
    local file_data = nil
    local year,month,day,hour,min,sec

    --状态位
    local state = 0
    --现在时间
    local now_time = 0
    --进程运行时间
    local dns_ip_time = 0
    --第一次开启时间
    local dns_first_time = 0
 
    --name赋值
    get_data["name"] = "dnsmasq"
    --判断进程是否存在
    local read_pid = io.popen("pidof dnsmasq")
    local read_pid_state = read_pid:read("*a")
    read_pid:close()

    --进程不存在
    if (read_pid_state == nil or read_pid_state == "") then
        get_data["up_time"] = "0"
        get_data["reset_time"] = "0"
        get_data["reset"] = "1"
        return cjson_safe.encode(get_data)
    else
        get_data["reset"] = "4"
    end

    --进程存在（获取进程的运行时间）
    local pid_numb_get = string.sub(read_pid_state, 1, #read_pid_state - 1)
    local pid_time_get = io.popen("cat /proc/"..pid_numb_get.."/stat | cut -d\" \" -f22")
    dns_time_o = pid_time_get:read("*a")
    pid_time_get:close()
    dns_time_o = string.sub(dns_time_o, 1, #dns_time_o - 1)
    pid_time_get = io.popen("grep btime /proc/stat | cut -d\" \" -f2")
    local dns_pid_t = pid_time_get:read("*a")
    pid_time_get:close()
    dns_pid_t = string.sub(dns_pid_t, 1, #dns_pid_t - 1)
    dns_pid_t =math.modf(dns_pid_t + dns_time_o / 100)
    pid_time_get = io.popen("date -d @"..dns_pid_t.." \"+%Y-%m-%d %H:%M:%S\"")
    dns_pid_t = pid_time_get:read("*a")
    pid_time_get:close()
    dns_pid_t = string.sub(dns_pid_t, 1, #dns_pid_t - 1)
    local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
    year,month,day,hour,min,sec = dns_pid_t:match(pattern)
    dns_ip_time = os.time({day = day, month = month, year = year, hour = hour, min = min, sec = sec})

    --获取现在的时间
    now_time = os.time()

    --（查看文件是否存在，获取第一次开启时间）
    if (file_param.file_exist(FILE_PATH)) then
        --获取文件信息
        file_data = file_param.file_read(FILE_PATH)
        --读取内容不为空
        if (file_data ~= "" and file_data ~= nil) then
            --获取创建时间
            local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+):(%d+)"
            year,month,day,hour,min,sec = file_data:match(pattern)
            if (tostring(year) == "1970") then
                os.execute("echo "..tostring(dns_pid_t).." > /tmp/snmp/snmp.txt")
                dns_first_time = dns_ip_time
            else
                dns_first_time = os.time({day = day, month = month, year = year, hour = hour, min = min, sec = sec})
            end
        else
            dns_first_time = now_time;
            state = 1;
        end
    else
        os.execute("echo "..tostring(dns_pid_t).." > /tmp/snmp/snmp.txt")
        state = 1;
    end

    --数据赋值
    --文件不存在或者文件为1970
    if (dns_first_time > dns_ip_time) then
        --重新写如数据
        os.execute("echo "..tostring(dns_pid_t).." > /tmp/snmp/snmp.txt")
        get_data["up_time"] = tostring(now_time - dns_ip_time)
        get_data["reset_time"] = tostring(now_time - dns_ip_time)
    else
        if (state == 1) then
            get_data["up_time"] = tostring(now_time - dns_ip_time)
            get_data["reset_time"] = tostring(now_time - dns_ip_time)
        else
            get_data["up_time"] = tostring(now_time - dns_first_time)
            get_data["reset_time"] = tostring(now_time - dns_ip_time)
        end
    end

    return cjson_safe.encode(get_data)
end

--set操作
function module_set(param)
    local snmp_param_data = {}
    --1.对param文件进行判空
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is null")
        return module_ret("1", "faild", "param is null!")
    end
    --2.将param转化为table格式
    snmp_param_data = cjson_safe.decode(param)
    if (snmp_param_data == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parse snmp param failed.")
        return module_ret("1", "faild", "parse snmp param failed!")
    end
    if (snmp_param_data["reset"] == "2") then
        --reset查看进程是否开启（获取进程号）
        -- local reset_pid = io.popen("pidof dnsmasq")
        -- local reset_pid_result = reset_pid:read("*a")
        -- reset_pid:close()
        --restart该进程
        os.execute("/etc/init.d/dnsmasq restart")
        --utils_exec.fork_exec_cmd("/etc/init.d/dnsmasq restart")
        --重新获取进程号
        -- local reset_pid_l = io.popen("pidof dnsmasq")
        -- local reset_pid_result_1 = reset_pid_l:read("*a")
        -- reset_pid_l:close()
        --对进程号进行判空
        -- if (reset_pid_result_1 == nil or reset_pid_result_1 == "") then
            -- return module_ret("1", "faild", "dnsmasq close")
        -- end
        --比较进程号是否一样（不一样说明重置成功，一样说明未成功）
        -- if (reset_pid_result == reset_pid_result_1) then
            -- return module_ret("1", "faild", "restart faild")
        -- end
    else
        return module_ret("1", "faild", "reset must be 2")
    end
    return module_ret("0", "successful", "successful set")

end