#!/usr/bin/env lua
-- dev_sta get -m pkgInfo
-- dev_sta set -m pkgInfo '{"list":[{"name":"888","uuid":"5000","iprange":["192.168.11.1-192.168.11.255"]}]}'
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("pkgInfo",package.seeall)

require "public_module"
local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local pkg_info_path = "/etc/account_mgr"
local pkg_info_conf = "/etc/account_mgr/pkgInfo.json"
local DEBUG_LOG_DIR = "/tmp/account_mgr/"
local table_input_err = {rcode = "05630001", rmsg = "param error"}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug��ʼ��
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "pkgInfo.log", 200, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function set_config_pkg(param_tab)
    if (tool.file_exist(pkg_info_path) == false) then
        local path = "mkdir -p " .. pkg_info_path .. " >/dev/null 2>&1"
        os.execute(path);
    end
    module_debug.lua_debug(module_debug.INFO, "INFO: conffile:%s, %s",pkg_info_conf, cjson.encode(param_tab))
    local ret = public_module.write_file(param_tab, pkg_info_conf)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] public_module_set is failed")
        return
    end

    local cmd = string.format("curl --connect-timeout 2 http://127.0.0.1:2060/pkg_reload?type=cloud  2>/dev/null > /dev/null &")
    module_debug.lua_debug(module_debug.INFO, "cmd[%s]", cmd)
    os.execute(cmd)
    return 0
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

--------------------------------------------------------------------------------------------
function module_default_config_get()
    local default_config = [[{"list":[]}]]

    return default_config
end

function module_get()
    local default_config = [[{"list":[]}]]
    if (tool.file_exist(pkg_info_conf) == false) then
        return default_config
    end
    return file_read(pkg_info_conf)
end

function module_set(param)
    debug_init();

    --����У��
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end
    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end
    
    ret = set_config_pkg(param_tab)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] globalAuthConfSet is failed param is %s", param)
        return check_result("0001")
    end

    module_debug.lua_debug(module_debug.INFO, "[module_set] is OK")

    return check_result("0000")
end
-----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end