#!/usr/bin/lua
module("nbr_networkId_merge", package.seeall)

local curl = require "luacurl"
local json = require "dkjson"
local console = require "console"
local product = require("product");
local default_pre = product.get_product("capacity.default_pre");
local next_enc = product.get_product("capacity.next_enc");
local default_str = default_pre .. next_enc
local uci = require "luci.model.uci".cursor()

local function debug(msg)
    console.debug("nbr_merge", msg)
end

local function http_request(url, data)
    local result = { }
    c = curl.new()
    c:setopt(curl.OPT_URL, url)
    c:setopt(curl.OPT_WRITEDATA, result)
    c:setopt(curl.OPT_POST, true);
    c:setopt(curl.OPT_POSTFIELDS, data);
    c:setopt(curl.OPT_SSL_VERIFYHOST, 0);
    c:setopt(curl.OPT_SSL_VERIFYPEER, false);
    c:setopt(curl.OPT_TIMEOUT, 3);
    c:setopt(curl.OPT_WRITEFUNCTION, function(tab, buffer)     --call back函数，必须有
        table.insert(result, buffer)                      --tab参数即为result，参考http://luacurl.luaforge.net/
        return #buffer
    end)
    local ok = c:perform()
    local http_code = c:getinfo(curl.INFO_RESPONSE_CODE);
    return ok, table.concat(result), http_code
end

local function get_auth_key(ip, pwd)
    local url = string.format("http://%s:20099/devConfig.php?a=login", ip)
    local data = {admin = "admin", password = pwd, encry = true}
    local code
    local auth = nil
    data = json.encode(data)
    -- debug(string.format("get_auth_key:curl -X POST url:%s, -d data:%s", url, data))
    debug(string.format("get_auth_key:curl -X POST url:%s, -d ", url))
    ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 and result_table.data then
                code = "200"
                auth = result_table.data.auth
            else
                --鉴权失败
                code = "401"
                debug("get_auth_key:code 401")
            end
        else
            code = "401"
            debug("get_auth_key:code 401")
        end
    else
        code = "000"
        debug("get_auth_key:code 000")
    end
    
    return code, auth
end

function checkIp(str)
    -- 放宽IP校验(tipcIp需要)
    return str and string.len(str) < 50 and string.match(str, "[%d:%a]+$") ~= nil
end

function module_set(param)
    local url
    local ip
    local master_pwdFile = "/etc/sd_config/admin"
    local defpwd = default_str
    local cmd
    local code
    debug("**************************************************")
    -- debug(param)

    local paramTable = json.decode(param)
    if not paramTable then
        debug("input is not json")
        return
    end

    local detect_param = json.encode(paramTable)
    if string.match(detect_param, "[\n\r'`&$;|>]") or string.find(detect_param, "\\n") or string.find(detect_param, "\\r") then
        debug('param illegal:'..detect_param)
        return
    end

    nbr_pwd = paramTable.password
    enc_type = paramTable.type
    toNetworkId = paramTable.toNetworkId
    toNetworkName = paramTable.toNetworkName
    toParentId = paramTable.toParentId
    ip = paramTable.ip

    local ckip = checkIp(ip)
    if ckip == false then 
        debug("input nbr pwd is empty")
        return
    end

    if not nbr_pwd or nbr_pwd == "" then
        debug("input nbr pwd is empty")
        return 
    end
    
    if not toNetworkId then
        debug("toNetworkId is nil")
        return
    end

    if enc_type ~= "enc" then
        cmd = string.format("echo %s | /usr/sbin/sd_crypto enc -t C", nbr_pwd)
        nbr_pwd = console.exec_cmd(cmd)
    end
    
    if (console.is_file_exist(master_pwdFile)) then
        master_pwd = console.trim(console.read_file(master_pwdFile))
    else
        master_pwd = defpwd
    end

    debug(string.format("encry master_pwd:%s, encry nbr pws:%s",master_pwd, nbr_pwd))
    local cwmp_flag = nil
    if uci:get_first("cwmp", "cwmp", "Controller") == "CLOUD" or uci:get("mqtt", "mqtt", "parentGroupId") then
        cwmp_flag = true
    end
    
    code, auth_key = get_auth_key(ip, nbr_pwd)
    if code == "200" then
        code = set_lnid(auth_key, ip, toNetworkId, toNetworkName, toParentId)
        if code == "200" then
            if cwmp_flag then
                code1 = set_cwmp(auth_key, ip)
            end
            code2 = set_pwd(auth_key, ip, master_pwd)
        end
    end
    return code
end

function set_cwmp(auth_key, ip)
    local url = string.format("http://%s:20099/devConfig.php?a=setCwmp", ip)
    local data = {auth = auth_key}
    local code
    data = json.encode(data)
    debug(string.format("set cwmp:url:%s, data:%s", url, data))
    local ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 then
                code = "200"
            else
                code = "401"
                debug("set cwmp:code 401")
            end
        else
            code = "401"
            debug("set cwmp:code 401")
        end
    else
        code = "000"
        debug("set cwmp:code 000")
    end
    return code
end


function set_lnid(auth_key, ip, networkid, networkName, parentId)
    local url = string.format("http://%s:20099/devConfig.php?a=setNetworkId", ip)
    local data = {auth = auth_key, networkid = networkid, networkname = networkName, parentid = parentId}
    local code
    data = json.encode(data)
    debug(string.format("set lnid:url:%s, data:%s", url, data))
    local ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 then
                code = "200"
            else
                code = "401"
                debug("set lnid:code 401")
            end
        else
            code = "401"
            debug("set lnid:code 401")
        end
    else
        code = "000"
        debug("set lnid:code 000")
    end
    return code
end

function set_pwd(auth_key, ip, master_pwd)
    local url = string.format("http://%s:20099/devConfig.php?a=changPassword", ip)
    local data = {auth = auth_key, admin = "admin", password = master_pwd, encry = true, master = false}
    local code
    data = json.encode(data)
    debug(string.format("set pwd:url:%s, auth_key:%s", url, auth_key))
    local ok, result, code = http_request(url, data)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 then
                code = "200"
            else
                code = "401"
                debug(" set_pwd:code 401")
            end
        else
            code = "401"
            debug(" set_pwd:code 401")
        end
    else
        code = "000"
        debug(" set_pwd:code 000")
    end
    return code
end




