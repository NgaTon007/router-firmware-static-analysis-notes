#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("http_client_status",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local util = require "luci.util"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/sddir/oam/http_client/"
local LOCK_FILE = "/tmp/sddir/oam/http_client/.http_status.lock"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "http_status.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    local ret = tool.exec(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "%s %s", ubus_cmd, ret)

    return ret
end

function module_get()
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    tab = ubus_cmd_exe('ubus call http_client get_status')
    if (tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] get_status is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"get status is fail!\"}"
    end

    os.remove(LOCK_FILE)
    return tab
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end