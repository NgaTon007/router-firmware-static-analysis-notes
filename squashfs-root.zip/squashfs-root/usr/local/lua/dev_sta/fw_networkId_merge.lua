#!/usr/bin/lua
module("fw_networkId_merge", package.seeall)

local curl = require "luacurl"
local json = require "dkjson"
local console = require "console"
local uci = require "luci.model.uci".cursor()

local function debug(msg)
    console.debug("fw_merge", msg)
end

local function http_request(url, data, cookie_type, cookie)
    local result = { }
    c = curl.new()
    c:setopt(curl.OPT_URL, url)
    c:setopt(curl.OPT_WRITEDATA, result)
    c:setopt(curl.OPT_POST, true);
    c:setopt(curl.OPT_POSTFIELDS, data);
	
	c:setopt(curl.OPT_COOKIESESSION, true); 
	if cookie_type == "input" then
		c:setopt(curl.OPT_COOKIEFILE, cookie); 
	else
		c:setopt(curl.OPT_COOKIEJAR, cookie);  
    end
	c:setopt(curl.OPT_FORBID_REUSE, true);  
	
    c:setopt(curl.OPT_HTTPHEADER, "Content-type: application/json"); 
    c:setopt(curl.OPT_SSL_VERIFYHOST, 0);
    c:setopt(curl.OPT_SSL_VERIFYPEER, false);
    c:setopt(curl.OPT_TIMEOUT, 3);
    c:setopt(curl.OPT_WRITEFUNCTION, function(tab, buffer)     --call back函数，必须有
        table.insert(result, buffer)                      --tab参数即为result，参考http://luacurl.luaforge.net/
        return #buffer
    end)
    local ok = c:perform()
    local http_code = c:getinfo(curl.INFO_RESPONSE_CODE);
    return ok, table.concat(result), http_code
end

--data {"password":"xxxxxxx","username":"xxxxxxx","source":"merge","alg":1}
local function get_auth_key(user, ip, pwd, cookie, product)
    local url = string.format("http://%s:20099/api/v1/login/", ip)
	
    --debug(string.format("2222222 url:%s user:%s ip:%s pwd:%s cookie:%s", url, user, ip, pwd, cookie))
    --local data = {password = pwd, alg = 1, source = "merge", username = user}
    local code = 20000
    local auth = nil
	local data = nil
	
	--[[local data = string.format("'{\"username\":\"%s\",\"alg\":1,\"source\":\"merge\",\"password\":\"%s\"}'", user, pwd)
	cmd = string.format("curl -X POST -c %s -H \"Content-type: application/json\" '%s' -d %s", cookie, url, data)
    debug(cmd)
	]]
	--判断pwd如果是默认admin密码，那么将pwd设置为防火墙默认密码：firewall
	if not pwd or pwd == "" then
        debug("input fw pwd is empty")
        return 0
    end
	local cmd=string.format("echo \"%s\" | /usr/sbin/sd_crypto dec -t C", pwd)
    --debug(string.format(" cmd:%s ", cmd))
	result=console.exec_cmd(cmd)
    --debug(string.format(" password:%s ", result))
	if result == "admin" and product == "FW_NTOS" then
        local firewall = console.exec_cmd("echo firewall | /usr/sbin/sd_crypto enc -t C")
		data = {username = user, password = firewall, alg = 1, source = "master"}
	else 
		data = {username = user, password = pwd, alg = 1, source = "master"}
	end
	
	data = json.encode(data)
	
	--ok, result, code = http_request(url, data, "output", cookie)
	cmd = string.format("curl -X POST -c %s '%s' -d '%s' -H \"Content-type: application/json\" ", cookie, url, data)
	-- debug(cmd)
    debug(string.format("cookie:%s,url:%s", cookie, url))
	result=console.exec_cmd(cmd)
    debug(string.format("[get_auth_key] result:%s code:%s", result, code))

	if result then
		result_table = json.decode(result)
		if result_table.code == 20000 and result_table.data then
			code = "200"
			auth = result_table.data.sessionid
		else
			--鉴权失败
			code = "401"
			debug("get_auth_key:code 401")
		end
	else
		code = "401"
		debug("get_auth_key:code 401")
	end

    return code, auth
end

function is_valid_ip(ip)
    local pattern = "^%d+%.%d+%.%d+%.%d+$"
    
    if not ip:match(pattern) then
        return false
    end
    
    local parts = {}
    for part in ip:gmatch("%d+") do
        parts[#parts+1] = tonumber(part)
    end
    
    if #parts ~= 4 then
        return false
    end
    
    for _, part in ipairs(parts) do
        if part < 0 or part > 255 then
            return false
        end
    end
    
    return true
end

function module_set(param)
    local url
    local ip
    local master_pwdFile = "/etc/sd_config/admin"
    local cmd
    local code
    local product
	--local cookie = string.format("/tmp/cookie_%s.txt", os.time() )
	--local cookie_bak = cookie
    debug("******************* fw_networkId_merge  start *******************************")
	--cookie=string.format("/tmp/cookie_%s.txt", os.time() )
    -- debug(param)

    local paramTable = json.decode(param)
    if not paramTable then
        debug("input is not json")
        return
    end
    
    local detect_param = json.encode(paramTable)
    if string.match(detect_param, "[\n\r'`&$;|>]") or string.find(detect_param, "\\n") or string.find(detect_param, "\\r") then
        debug('param illegal:'..detect_param)
        return
    end

    fw_pwd = paramTable.password
    enc_type = paramTable.type
    toNetworkId = paramTable.toNetworkId
    toNetworkName = paramTable.toNetworkName
    toParentId = paramTable.toParentId
    ip = paramTable.ip
	fw_user = "admin"
    product = paramTable.product
    if not product or product == "" then
        product = "FW_NTOS"
    end
    
    debug(string.format("toNetworkId:%s, toNetworkName:%s, toParentId:%s, input ip is :%s",toNetworkId, toNetworkName, toParentId, ip))
    if not is_valid_ip(ip) then
        debug('ip illegal:'..ip)
        return
    end
    
	if not toParentId or toParentId == "" then
        toParentId="NA"
    end

    if not fw_pwd or fw_pwd == "" then
        debug("input fw pwd is empty")
        return 
    end
    
    if not toNetworkId then
        debug("toNetworkId is nil")
        return
    end
	
	if enc_type ~= "enc" then
        cmd = string.format("echo %s | /usr/sbin/sd_crypto enc -t C", fw_pwd)
        fw_pwd = console.exec_cmd(cmd)
    end

	local cmd = string.format("echo admin | /usr/sbin/sd_crypto enc -t C")
	--local cmd = string.format("echo admin | openssl enc -e -aes-256-cbc -a -k 'Ykhwzx\\$2018!'")
	--debug(string.format("cmd:%s", cmd))
	fw_user = console.exec_cmd(cmd)
	
	--[[cmd = string.format("echo %s | /usr/sbin/sd_crypto enc -t C", fw_pwd)
	--cmd = string.format("echo %s | openssl enc -e -aes-256-cbc -a -k 'Ykhwzx\\$2018!'", fw_pwd)
	debug(string.format("cmd:%s", cmd))
	fw_pwd = console.exec_cmd(cmd)
    ]]
    -- fixbug 1510434
    if console.is_file_exist(master_pwdFile) then
        local master_pwd_1 = console.trim(console.read_file(master_pwdFile))

        if master_pwd_1 ~= nil and master_pwd_1 ~= "" then
            local cmd = string.format("echo %s | /usr/sbin/sd_crypto dec -t C", master_pwd_1)
            local master_pwd_2 = console.trim(console.exec_cmd(cmd))

            if master_pwd_2 == "admin" or master_pwd_2 == nil or master_pwd_2 == "" then
                master_pwd = ""
                debug("default password, skip change password")
            else
                master_pwd = master_pwd_1
            end
        else
            master_pwd = ""
            debug("master_pwdFile is empty, skip change password")
        end
    else
        master_pwd = ""
        debug("master_pwdFile not exist, skip change password")
    end

    --debug(string.format("encry master_pwd:%s, encry fw pws:%s fw_user:%s",master_pwd, fw_pwd, fw_user))
    
    --debug(string.format("11111 user:%s ip:%s pwd:%s cookie:%s", fw_user, ip, fw_pwd, cookie))
	--先使用当前/tmp/cookie/下的cookie文件尝试执行lnid设置，失败再使用当前命令携带的密码登陆
	local cookie = string.format("/tmp/cookie/%s", ip)
	local old_cookie_status = 0
	local old_cookie_flag = 0
	local old_cookie_file = io.open(cookie, "rb") 
	if old_cookie_file then
		old_cookie_file:close()
		old_cookie_flag = 1
	end
	--debug(string.format("11111 old_cookie_flag:%d", old_cookie_flag))
	if old_cookie_flag == 0 then
		os.execute("mkdir /tmp/cookie")
		code, auth_key = get_auth_key(fw_user, ip, fw_pwd, cookie, product)
	else	
		code = set_lnid(ip, toNetworkId, toNetworkName, toParentId, cookie)
		if code == "200" then
			debug("cookie is true")
			old_cookie_status = 1
		else
			debug(string.format("code:%s", code))
			code, auth_key = get_auth_key(fw_user, ip, fw_pwd, cookie, product)
		end
	end
	
    if code == "200" then
		if old_cookie_status == 0 then
			code = set_lnid(ip, toNetworkId, toNetworkName, toParentId, cookie)
		end
		--debug(string.format("result:%s code:%s", result, code))
        if code == "200" then
		--防火墙无cwmp，且防火墙默认就是开启mqtt上云功能，不需要额外下发命令
          --[[  if cwmp_flag then
                code1 = set_cwmp(auth_key, ip)
            end]]
			
            code2 = set_pwd(fw_user, ip, master_pwd, cookie)
        end
		
    end
	--os.remove(cookie_bak)
    return code
end

function set_cwmp(auth_key, ip)
    local url = string.format("http://%s:20099/devConfig.php?a=setCwmp", ip)
    local data = {auth = auth_key}
    local code
    data = json.encode(data)
    debug(string.format("set cwmp:url:%s, data:%s", url, data))
    local ok, result, code = http_request(url, data, "input", cookie)
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 0 then
                code = "200"
            else
                code = "401"
                debug("set cwmp:code 401")
            end
        else
            code = "401"
            debug("set cwmp:code 401")
        end
    else
        code = "000"
        debug("set cwmp:code 000")
    end
    return code
end

--[[curl -X POST 'http://xxx.xxx.xxx.xxx:20099/api/v1/interface/set_mesh_info/' -d '{"network_id":"dev_00:D0:18:90:BC:FA_1656468203","network_name":"11111111","parent_id":"NA",
"source":"merge","ts":"1656482008"}' -b /tmp/cookie.txt -H "Content-type: application/json"
]]
function set_lnid(ip, networkid, networkName, parentId, cookie)
    local url = string.format("http://%s:20099/api/v1/interface/set_mesh_info/", ip)
    local data = {network_id = networkid, network_name = networkName, parent_id = parentId, source = "master", ts = os.time()}
    local code
    data = json.encode(data)
    --debug(string.format("set lnid:url:%s, data:%s cookie:%s", url, data, cookie))
    local ok, result, code = http_request(url, data, "input", cookie)  -- -b  -c区别
    debug(string.format("[set_lnid] result:%s code:%s", result, code))
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 20000 then
                code = "200"
            else
                code = "401"
                debug("set lnid:code 401")
            end
        else
            code = "401"
            debug("set lnid:code 401")
        end
    else
        code = "000"
        debug("set lnid:code 000")
    end
    return code
end

--[[修改密码 curl -X POST 'http://xxx.xxx.xxx.xxx:20099/api/v1/user/change_password/' 
-d '{"username":"xxxxxxx","password":"xxxxxxx","ts":"1656482008","alg":1,"source":"merge"}' 
-b /tmp/cookie.txt -H "Content-type: application/json"
]]
function set_pwd(user, ip, master_pwd, cookie)
    if not master_pwd or master_pwd == "" then
        return "200"
    end

    local url = string.format("http://%s:20099/api/v1/user/change_password/", ip)
    local data = {username = user, password = master_pwd, ts = os.time(), alg = 1, source = "master"}
    --local data = {username = user, password = "xxxxxxx", ts = "1656482008", alg = 1, source = "merge"}
    local code
    data = json.encode(data)
    --debug(string.format("set pwd:url:%s, data:%s", url, data))
    local ok, result, code = http_request(url, data, "input", cookie)
    debug(string.format("[set_pwd] result:%s code:%s", result, code))
    if ok then
        if result then
            result_table = json.decode(result)
            if result_table.code == 20000 then
                code = "200"
            else
                code = "401"
                debug(" set_pwd:code 401")
            end
        else
            code = "401"
            debug(" set_pwd:code 401")
        end
    else
        code = "000"
        debug(" set_pwd:code 000")
    end
    return code
end



--获取鉴权 curl -X POST -c /tmp/cookie.txt 'http://xxx.xxx.xxx.xxx:20099/api/v1/login/' -H "Content-type: application/json" -d '{"password":"xxxxxxx=","username":"xxxxxxx","source":"app","alg":1}'
--获取lnid curl -X GET 'http://xxx.xxx.xxx.xxx:20099/api/v1/interface/get_mesh_info/' -d '{"mesh_type":"info"}' -b /tmp/cookie.txt -H "Content-type: application/json"
--设置lnid curl -X POST 'http://xxx.xxx.xxx.xxx:20099/api/v1/interface/set_mesh_info/' -d '{"network_id":"dev_00:D0:18:90:BC:FA_1656468203","network_name":"11111111","parent_id":"NA","source":"web","ts":"1656482008"}' -b /tmp/cookie.txt -H "Content-type: application/json"
--修改密码 curl -X POST 'http://xxx.xxx.xxx.xxx:20099/api/v1/user/change_password/' -d '{"username":"xxxxxxx","password":"xxxxxxx","ts":"1656482008","alg":1,"source":"web"}' -b /tmp/cookie.txt -H "Content-type: application/json"


