#!/usr/bin/lua
module("radioInfo", package.seeall)
local console = require "console"
local json = require "cjson"
local uci = require "luci.model.uci".cursor()
local libwlan = require "libwlan"
local support_2g = uci:get("wifiinfo", "global", "support2g") or ""
local support_5g = uci:get("wifiinfo", "global", "support5g") or ""
local ext_ifname_2g = uci:get("wifiinfo", "band_2g", "ext_ifname") or ""
local ext_ifname_5g = uci:get("wifiinfo", "band_5g", "ext_ifname") or ""
local entryCountry = uci:get("wifiinfo", "global", "entryCountry") or uci:get("wifiinfo", "global", "country_limit") or ""
local appl_scen = uci:get("wifiinfo", "global", "appl_scen") or ""
local str
local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type")

--debug
local function debug(msg)
    console.debug("radioInfo", msg)
end

function module_get()
    local radio_info = {radio0={},radio1={}}
    if support_2g == "true" and console.is_file_exist("/sys/class/net/"..ext_ifname_2g.."0/address") and console.read_file("/sys/class/net/"..ext_ifname_2g.."0/address") ~= "" then
        sh_cmd = "wlanconfig "..ext_ifname_2g.."0 list radio 2>/dev/null"
        str = console.exec_cmd(sh_cmd)
        radio0_chutil = string.match(str, "utilization:(%-?%d+)")
        radio0_channf = string.match(str, "floornoise:(%-?%d+)")
        if dev_type == "est" then
            radio0_radioindex = "1"
            radio0_band = "2.4G"
            radio0_center_ch = string.match(str, "center_ch:(%-?%d+)")
            if radio0_center_ch == nil then
                radio0_center_ch = 0
            end
            radio0_center_freq = libwlan.channel_to_freq_mhz_2g(radio0_center_ch)
            debug("2.4G center channel : "..tostring(radio0_center_ch)..", center frequence : "..tostring(radio0_center_freq))
        end
		--获取tp_base
        radio0_tp_base = "20"

        sh_cmd = "iwconfig "..ext_ifname_2g.."0 | grep Channel 2>/dev/null"
        str = console.exec_cmd(sh_cmd)
        debug(str)
        if not str then
            msg = "channel is NULL"
            debug(msg)
            radio0_channel = "NULL"
        else
            radio0_channel = string.match(str, "%d+")
            if dev_type == "est" then
                radio0_freq = libwlan.channel_to_freq_mhz_2g(radio0_channel)
                debug("2.4G channel : "..tostring(radio0_channel)..", frequence : "..tostring(radio0_freq))
            end
        end
    else
        radio0_chutil = "NULL"
        radio0_channf = "NULL"
        radio0_channel = "NULL"
		radio0_tp_base = "NULL"
        if dev_type == "est" then
            radio0_radioindex = "NULL"
            radio0_band = "NULL"
            radio0_center_ch = "NULL"
            radio0_center_freq = "NULL"
            radio0_freq = "NULL"
        end
    end
    if support_5g == "true" and console.is_file_exist("/sys/class/net/"..ext_ifname_5g.."0/address") and console.read_file("/sys/class/net/"..ext_ifname_5g.."0/address") ~= "" then
        sh_cmd = "wlanconfig "..ext_ifname_5g.."0 list radio 2>/dev/null"
        str = console.exec_cmd(sh_cmd)
        radio1_chutil = string.match(str, "utilization:(%-?%d+)")
        radio1_channf = string.match(str, "floornoise:(%-?%d+)")
        if dev_type == "est" then
            radio1_radioindex = "2"
            radio1_band = "5G"
            radio1_center_ch = string.match(str, "center_ch:(%-?%d+)")
            if radio1_center_ch == nil then
                radio1_center_ch = 0
            end
            radio1_center_freq = libwlan.channel_to_freq_mhz(radio1_center_ch)
            debug("5G center channel : "..tostring(radio1_center_ch)..", center frequence : "..tostring(radio1_center_freq))
        end
		 --获取tp_base
		if appl_scen == "outdoor" then
				radio1_tp_base = "23"
		else
				radio1_tp_base = "20"
		end
        sh_cmd = "iwconfig "..ext_ifname_5g.."0 | grep Channel 2>/dev/null"
        str = console.exec_cmd(sh_cmd)
        debug(str)
        if not str then
            msg = "channel is NULL"
            debug(msg)
            radio1_channel = "NULL"
        else
            radio1_channel = string.match(str, "%d+")
            if dev_type == "est" then
                radio1_freq = libwlan.channel_to_freq_mhz(radio1_channel)
                debug("5G channel : "..tostring(radio1_channel)..", frequence : "..tostring(radio1_freq))
            end
        end
    else
        radio1_chutil = "NULL"
        radio1_channf = "NULL"
        radio1_channel = "NULL"
		radio1_tp_base = "NULL"
        if dev_type == "est" then
            radio1_radioindex = "NULL"
            radio1_band = "NULL"
            radio1_center_ch = "NULL"
            radio1_center_freq = "NULL"
            radio1_freq = "NULL"
        end
    end
    
    radio_info.radio0.chutil = radio0_chutil
    radio_info.radio0.channf = radio0_channf
    radio_info.radio0.channel = radio0_channel

   	--Egypt retutn txpower base
	if entryCountry == "EG" then
		radio_info.radio0.tp_base = radio0_tp_base
	end

    radio_info.radio1.chutil = radio1_chutil
    radio_info.radio1.channf = radio1_channf
    radio_info.radio1.channel = radio1_channel

	if entryCountry == "EG" then
		radio_info.radio1.tp_base = radio1_tp_base
	end

    if dev_type == "est" then
        radio_info.radio0.radioIndex = tostring(radio0_radioindex)
        radio_info.radio0.band = tostring(radio0_band)
        radio_info.radio0.frequency = tostring(radio0_freq)
        radio_info.radio0.centerCh = tostring(radio0_center_ch)
        radio_info.radio0.centerFreq = tostring(radio0_center_freq)
        radio_info.radio1.radioIndex = tostring(radio1_radioindex)
        radio_info.radio1.band = tostring(radio1_band)
        radio_info.radio1.frequency = tostring(radio1_freq)
        radio_info.radio1.centerCh = tostring(radio1_center_ch)
        radio_info.radio1.centerFreq = tostring(radio1_center_freq)
    end

    return(json.encode(radio_info))
end
