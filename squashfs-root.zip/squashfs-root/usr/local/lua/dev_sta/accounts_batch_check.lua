#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("accounts_batch_check",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"

local DEBUG_LOG_DIR = "/tmp/accounts_batch/"
local LOCK_FILE = "/tmp/accounts_batch/accounts_batch_check.lock"
local PPPOE_USER_JSON_FILE = "/etc/sd_config/single/pppoeserver_user.json"
local GET_FLOWCTRL_PPPOE_CMD = "dev_sta get -m flowctrl_pppoe"
local PPPOE_USER_CFG = "pppoeserver_user_cfg"
local GET_PPPOE_SERVER_MAXNUM_CMD = "jq -r .gateway.pppoe_server_maxnum \"/tmp/sd_device/sd_device.json\""
local GET_FLOWCTRL_SWITCH_CMD = "uci get flowctrl.@global[0].tc_switch"
local PPPOE_USER_CFG_STATUS = "/tmp/accounts_batch/pppoe_uer_cfg_status"
local PPPOE_USER_CFG_FILE = "/tmp/accounts_batch/pppoeserver_user_cfg_set"
local PPPOE_USER_CFG_FILE_UTF8 = "/tmp/accounts_batch/pppoeserver_user_cfg_set_UTF8"
local PPPOE_USER_CFG_FILE_TMP = "/tmp/pppoeserver_user_cfg_set.csv"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

if (tool.file_exist(PPPOE_USER_CFG_STATUS) == false) then
    tool.exec("touch /tmp/accounts_batch/pppoe_uer_cfg_status")
end

--debug初始化
function debug_init()
	module_debug.debug_init(DEBUG_LOG_DIR, "accounts_batch_check.log", 50, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--参数校验
function config_file_check(param)
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Input data is not json mode.")
        return
    end	
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end
	return param_tab
end	

function file_remove()
    os.remove(PPPOE_USER_CFG_FILE) 
    os.remove(LOCK_FILE)
end

-- 校验时间合法性
function isValidDate(year, month, day)
    if year < 1900 then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [isValidDate] year is err")
        return false
    end
    if month < 1 or month > 12 then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [isValidDate] month is err")
        return false
    end
    if day < 1 or day > 31 then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [isValidDate] day is err")
        return false
    end
    local maxDay = 31
    if month == 1 or month == 3 or month == 5 or month == 7 or month == 8 or month == 10 or month == 12 then
        maxDay = 31
    elseif month == 2 then
            if year % 4 == 0 and year % 100 ~= 0 or year % 400 == 0 then
                maxDay = 29
            else
                maxDay = 28
            end
    else
        maxDay = 30
    end
    return day <= maxDay
end

local function judge_len(str, max_len)
	local ss = {}
	for k = 1, #str do
		local c = string.byte(str,k)  
		if not c then break end
        --35 # 45 - 64 @ 95 _ 46 .
        -- 判断是否是字母/数字/#-_.@符号
		if (c >= 48 and c <= 57) or (c >= 64 and c <= 90) or (c >= 97 and c <= 122)
            or (c == 35) or ( c == 95) or (c >= 45 and c <= 46) then
			ss[#ss+1] = string.char(c)

        -- 判断是否是中文字符
		elseif c >= 228 and c <= 233 then  
			local c1 = string.byte(str,k+1)
			local c2 = string.byte(str,k+2)
			if c1 and c2 then
				local a1,a2,a3,a4 = 128,191,128,191
				if c == 228 then a1 = 184
				elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
				end
				if c1 >= a1 and c1 <= a2 and c2 >= a3 and c2 <= a4 then
					k = k + 2
					ss[#ss+1] = string.char(c,c1,c2)
				end
			end
		end
	end

	if #ss > max_len then
        module_debug.lua_debug(module_debug.ERROR, "#ss  %d", #ss)
		return false
	end
	return true
end

-- 检查流控开关是否开启 以及是否存在相应的账号套餐
function flowctrl_pppoe_package_check(package_name)
    -- 获取流控开关 流控关闭时 无法配置流控策略
    if (string.find(tool.exec(GET_FLOWCTRL_SWITCH_CMD), "on") == nil) then
        return false
    end
    local sh_ret = {}
    local num = 1
    sh_ret = cjson.decode(tool.exec(GET_FLOWCTRL_PPPOE_CMD))
    local length = table.maxn(sh_ret["list"])
    -- 查询要配置的账号套餐是否存在
    while ( num < length + 1 )
    do
		if (sh_ret["list"][num]["comment"] == package_name) then
            return true
        end
        num = num + 1
    end
    return false
end

-- Load File 
-- 调用方式：
-- local csvData = LoadCSV("./workpath/csvFileName.csv")

-- 完成调用后，用这个循环语句来输出所有数据
-- for k,v in pairs(csvData) do
--  for k2,v2 in pairs(v) do
--      print(k,k2,v2)
--  end
-- end

-- 内部所有CSV数据，可以通过指定X和Y来获得。
-- 即csvData[Y][X]代表在CSV表格中，位于横行第X个，纵行第Y个的数据。

function LoadCSV(filePath)

    local file = assert(io.open(filePath, 'r'))
    local content = string.gsub(file:read("*all"), "\r\n", "\n")
    file:close()
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [LoadCSV] config is nil")
        return
    end
    -- Read Word One By One   
    local c = content -- content
    local p = 0 -- content check pos
    local w = "" -- content check word
    local w_next = "" -- content check word(next one)
    local x = 1 -- content table x
    local y = 1 -- content table y
    
    local opt = {} -- output table
    opt[y] = {}
    opt[y][x] = ""
     
    local in_quote = false -- quote mode
     
    while true do
    p = p + 1
    w = string.sub(c,p ,p )
    w_next = string.sub(c,p+1,p+1)
        if w == ',' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                x = x + 1
                opt[y][x] = ""
            end
        elseif w == '"' then
            if in_quote then
                if w_next == '"' then
                    opt[y][x] = opt[y][x]..w
                    p = p + 1
                else
                    in_quote = false
                end
            else
                in_quote = true
            end
        elseif w == '\n' then
            if in_quote then
                opt[y][x] = opt[y][x]..w
            else
                y = y + 1
                x = 1
                opt[y] = {}
                opt[y][x] = ""
            end
        elseif w == "" or w == nil then
            opt[y][x] = nil
            break
        else
            opt[y][x] = opt[y][x]..w
        end
    end

    return opt
end

function pppoe_batch_check_get(filename)

    -- 获取当前已经配置的账号数量
    pppoe_cur_config = tool.file_read(PPPOE_USER_JSON_FILE)
    -- local pppoe_cur_config_tab = config_file_check(pppoe_cur_config)
    -- if (pppoe_cur_config_tab == nil) then
    --     module_debug.lua_debug(module_debug.ERROR, "ERROR: config_tab is nil")
    --     return
    -- end
	-- current_num = tonumber(pppoe_cur_config_tab["count"])
	pppoe_server_maxnum = tonumber(tool.exec(GET_PPPOE_SERVER_MAXNUM_CMD))

    -- if (current_num >= pppoe_server_maxnum) then
    --     module_debug.lua_debug(module_debug.ERROR, "ERROR: The number of pppoe user accounts is over the limit")
    --     return
    -- end

    --解析导入的配置文件信息
    local csvData = LoadCSV(filename)
    if (csvData == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information format error")
        return 
    end
    local cfg_count = 0

    data = {}
    data["code"] = "0"
    data["info"] = {}

    for k,v in pairs(csvData) do
        if (cfg_count > pppoe_server_maxnum) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: The number of configuration files exceeds the maximum!")
	        return
        end
        if (k > 1) then
            user_info = {}
            flag = 0
            for k2, v2 in pairs(v) do
                -- 用户名（name）格式校验 不能包含特殊字符（' " \），不可包含中文标点符号，不可包含中文,不可纯空格
                if (k2 == 1) then
                    if (v2 == nil or v2 == ""  or string.match(v2,  "^[%s]*(.-)[%s]*$") == "" or #v2 > 32) then
                        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information format error")
                        return
                    else
                        if (string.match(v2 , "^[%w%p ]+$") and string.match(v2,"^[^&|;\n\r$<>'`\"\\]+$")) then
                        else
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        end
                    end
                    user_info["name"] = v2
                -- 密码（passwd）格式校验 不能包含特殊字符（' " \），不可包含中文标点符号，不可包含中文
                elseif (k2 == 2) then
                    if (v2 == nil or v2 == "" or #v2 > 32) then
                        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information format error")
                        return
                    else
                        if (string.match(v2 , "^[%w%p ]+$") and string.match(v2,"^[^'\"\\$`]+$")) then
                        else
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        end
                    end
                    user_info["passwd"] = v2     
                -- 到期时间（dealline）格式校验 固定格式，如： 2022/11/22 %d%d%d%d/%d+%/%d+  
                elseif (k2 == 3) then
                    -- 校验格式是否正确  (%d+)%.(%d+)%.(%d+)%.(%d+)
                    if (v2 ~= "") then
                        if (string.match(v2, "(%d+)%/(%d+)%/(%d+)")) then
                            date_info = tool.split(v2, "/")
                        elseif (string.match(v2, "(%d+)%-(%d+)%-(%d+)")) then
                            date_info = tool.split(v2, "-")
                        else
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        end
                        -- 校验日期是否合法
                        local date_year = tonumber(date_info[1])
                        local date_month = tonumber(date_info[2])
                        local date_day = tonumber(date_info[3])
                        if (isValidDate(date_year, date_month, date_day) == false) then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        else
                            -- 校验日期是否在当期日期之后
                            local dealline = tonumber(os.time({day = date_day, month =  date_month, year = date_year, hour = 24, minute = 00, second = 00}))
                            local current = tonumber(os.time())
                            if (dealline < current) then
                                module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                                return
                            end
                        end
                    end
                    user_info["dealline"] = v2
                -- 备注（note）格式校验 不能包含特殊字符（' " \）
                elseif (k2 == 4) then
                    if(v2 ~= "") then
                        if (string.match(v2,"^[^\'\"\\\n]+$")) then
                        else
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        end
                        if (judge_len(v2, 50) == false) then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] Illegal characters in configuration information")
                            return
                        end 
                    end
                    user_info["note"] = v2

                -- 账户是否启用（enable）格式校验 on或者off（大小写不敏感）
                elseif (k2 == 5) then
                    if(v2 ~= "") then
                        v2 = string.upper(v2)
                        if (v2 ~= "ON" and  v2 ~= "OFF") then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get]s Illegal characters in configuration information")
                            return
                        end
                    else
                        v2 = "ON"
                    end
                    user_info["enable"] = v2
                -- 流控套餐（flow_name）格式校验 可选账号套餐（配置文件填写一个不存在（或不可选）的账号套餐，则视为校验不通过）
                elseif (k2 == 6) then
                    if(v2 ~= "") then
                        if (string.match(v2,"^[^\'\"\\\n]+$")) then
                        else
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: Illegal characters in configuration information")
                            return
                        end
                        if (judge_len(v2, 28) == false) then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] Illegal characters in configuration information")
                            return
                        end
                        if (flowctrl_pppoe_package_check(v2) == false) then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] Illegal characters in configuration information")
                            return
                        end
                    end
                    user_info["flow_name"] = v2
                else
                    module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] Configuration information format error")
                    return
                end
                flag = 1
            end
            if (flag == 1 ) then
                cfg_count = cfg_count + 1
                table.insert(data["info"], user_info)
            end
        end
    end
    if (cfg_count == 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Configuration information is null")
        return     
    end

    return cjson.encode(data)
end

function module_default_config_get()
end

--@module_get
function module_get(param)
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end
	if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        file_remove()
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end

    local param_tab = config_file_check(param)
    if (param_tab == nil) then
        file_remove()
        return "{\"code\":\"-1\",\"msg\":\"param is null!\"}"
    end

    if (param_tab["type"] == nil) then
        file_remove()
        return "{\"code\":\"-1\",\"msg\":\"config is null!\"}"
	end

	if (param_tab["type"] == PPPOE_USER_CFG) then
        if (tool.file_exist(PPPOE_USER_CFG_FILE_TMP) == false) then
            file_remove()
			return "{\"code\":\"-1\",\"msg\":\"get accounts_batch_check is fail!\"}"
        end
        tool.exec("mv "..PPPOE_USER_CFG_FILE_TMP.." ".. PPPOE_USER_CFG_FILE)
        if (tool.file_exist(PPPOE_USER_CFG_FILE) == false) then
            file_remove()
			return "{\"code\":\"-1\",\"msg\":\"get accounts_batch_check is fail!\"}"
        end
        tool.exec("cp "..PPPOE_USER_CFG_FILE.." "..PPPOE_USER_CFG_FILE_UTF8)
        data = pppoe_batch_check_get(PPPOE_USER_CFG_FILE_UTF8)
	    if (data == nil) then
            file_remove()
			return "{\"code\":\"-1\",\"msg\":\"get accounts_batch_check is fail!\"}"
		end
    else
        file_remove()
        return "{\"code\":\"-1\",\"msg\":\"config is error!\"}"
	end
    file_remove()
    return data
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end