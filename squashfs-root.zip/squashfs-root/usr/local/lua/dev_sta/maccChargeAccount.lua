-- dev_sta get -m maccChargeAccount

package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("maccChargeAccount",package.seeall)

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local account_mgr = require "account_mgr.account_mgr_common"
local DEBUG_LOG_DIR = "/tmp/account_mgr/"
local get_charge_usr_status = "account_mgr_cmd.elf -Q -u %s -t charge"

local conf_file = "/etc/account_mgr/account"
local status_conf_file = "/etc/config/account_mgr"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "maccChargeAccount.log", 200, module_debug.INFO, "1");
end

-----------------------------------------------------------------------------------------
local function is_number(str)
    return str:match("^%d+$") ~= nil
end

local function split(str, delimiter)
    local result = {}
    local start_pos = 1
    local end_pos = string.find(str, delimiter, 1, true)
    local name 
    local tmp
    local flag = 0
    while(end_pos ~= nil) do
        if flag == 0 then
            name = string.sub(str, start_pos, end_pos - 1)
            tmp = string.sub(str, end_pos + 1)
        else
            name = string.sub(tmp, start_pos, end_pos - 1)
            tmp = string.sub(tmp, end_pos + 1)
        end
        table.insert(result, name)
        end_pos = string.find(tmp, delimiter, 1, true)
        flag = 1
    end
    return result
end

local function user_status_get()
    local active_user_list = {}
    uci:foreach("account_mgr", "charge", function(s)
        local namecode = s[".name"]
        local user_name = uci:get("account_mgr", namecode, "username")
        if (user_name ~= nil) then
            active_user_list[user_name] = {}
            active_user_list[user_name]["active_time"] = uci:get("account_mgr", namecode, "active_time")
            active_user_list[user_name]["expire_time"] = uci:get("account_mgr", namecode, "expire_time")
            local cmd = string.format(get_charge_usr_status, user_name)
            module_debug.lua_debug(module_debug.INFO, "cmd:%s\n", cmd);
            local t = io.popen(cmd)
            local res = t:read("*all")
            t:close()
            local res_tab = cjson.decode(res);
            if (res_tab["result"] == "true" and res_tab["username"] == user_name) then
                active_user_list[user_name]["pkg_status"] = res_tab["pkg_status"]
                module_debug.lua_debug(module_debug.INFO, "user:%s, status:%s\n", user_name, active_user_list[user_name]["pkg_status"]);
            end
        end
    end
    )
    return active_user_list
end

function read_specific_line(filename, start_line_number, end_line_number)
    local user_list = {}
    local active_user_list = {}
    user_list["list"] = {}

    active_user_list = user_status_get()
    local file = io.open(filename, "r")
    if file then
        local current_line = 1
        for line in file:lines() do
            local user = {}
            local line_content = {}
            if current_line >= start_line_number and current_line <= end_line_number then
                module_debug.lua_debug(module_debug.INFO, "line:%s", line);
                line_content = split(line, ",")
                module_debug.lua_debug(module_debug.INFO, "Split content: %s", table.concat(line_content, ", "))
                for k, v in pairs(line_content) do
                    if k == 1 then
                        user["name"] = v
                    elseif k == 2 then
                        user["passwd"] = v
                    elseif k == 3 then
                        user["dealline"] = v
                    elseif k == 4 then
                        user["note"] = v
                    elseif k == 5 then
                        user["enable"] = v
                    elseif k == 6 then
                        user["pkg_uuid"] = v
                    elseif k == 7 then
                        user["pkg_name"] = v
                    elseif k == 8 then
                        if active_user_list[user["name"]] ~=nil and active_user_list[user["name"]]["active_time"] ~= nil then
                            user["pkg_active_time"] = active_user_list[user["name"]]["active_time"]
                        else
                            user["pkg_active_time"] = v
                        end
                    elseif k == 9 then
                        if active_user_list[user["name"]] ~=nil and active_user_list[user["name"]]["expire_time"] ~= nil then
                            user["pkg_expire_time"] = active_user_list[user["name"]]["expire_time"]
                        else
                            user["pkg_expire_time"] = v
                        end
                    elseif k == 10 then
                        user["spt_service"] = v
                    elseif k == 11 then
                        if user["pkg_expire_time"] ~= "" or user["pkg_active_time"] ~= ""then
                            user["status"] = "in_use"
                        else
                            user["status"] = "not_used"
                        end
                        if active_user_list[user["name"]] ~= nil and active_user_list[user["name"]]["pkg_status"] ~= nil then
                            user["status"] = active_user_list[user["name"]]["pkg_status"]
                        end
                        -- if v == "unused" then
                        --     user["status"] = "not_used"
                        -- end
                    elseif k == 12 then
                        user["enc_type"] = v
                        if user["enc_type"] ~= nil and user["enc_type"] == "1" then
                            user["passwd"] = account_mgr.aes256_decode(user["passwd"])
                        end
                    end
                end
                user["register_mothod"] = string.match(line, ",([^,]*)$")
                table.insert(user_list["list"], user)
            end
            current_line = current_line + 1
        end
        file:close()
    else
        module_debug.lua_debug(module_debug.ERROR, "/etc/account_mgr/account read err")
        return nil
    end
    return user_list
end

function module_get(param)
    -- ��ҳ
    -- /etc/account_mgr/account
    -- name,passwd,dealline,note,enable,pkg_uuid,pkg_name,pkg_active_time,pkg_expire_time,spt_service,status,enc_type
    debug_init()
    local result = {}
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil or is_number(param_tab["index"]) == false or is_number(param_tab["count"]) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end

    local start_line_number = param_tab["index"] + 2
    local end_line_number =  start_line_number + param_tab["count"] - 1

    local Info = {}

    local count = 0
    Info = read_specific_line(conf_file, start_line_number, end_line_number)  -- ��ȡ�ļ� "example.txt" �ĵ� 5 ��
    if Info ~= nil then
        if #Info.list == 0 then
            result = "{\"list\":[]}"
        else
            result = cjson.encode(Info)
        end
    else
        return "{\"code\":\"1\",\"msg\":\"read file error!\"}"
    end
    module_debug.lua_debug(module_debug.DEBUG, "module_get end,get %d account\n", count);
    return result
end