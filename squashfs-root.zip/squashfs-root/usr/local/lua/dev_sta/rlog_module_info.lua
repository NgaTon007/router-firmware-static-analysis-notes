#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("rlog_module_info", package.seeall); -- 第一个参数是本模块的文件名

local libdbg = require("utils.debug");
local libexec = require("utils.exec");
local libfile = require("utils.file");
local dkjson = require("dkjson");

local config_file = "/etc/rlog/module.json";
local module_dir = "/tmp/ap_log/all"; --存放业务数据文件夹
local tmp_dir = "/tmp/ap_log/tar_tmp"; --业务数据缓冲文件夹
local tar_dir = "/tmp/ap_log/tar"; --存放业务数据压缩包文件夹

-- 调试模块初始化
libdbg.debug_init("/tmp/rlog/", "rlog_module_info.lua.log", 500, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- 模块set|get的返回值
    @code：错误码0000为成功，其他为失败
    @msg:返回的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "0000") then
        result["result"] = msg;
    else
        result["result"] = "error";
        result["code"] = code;
        result["reason"] = msg;
    end

    return require("dkjson").encode(result);
end

-- @rlog_module_info_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- 日志之前打印一个空行，不包含时间戳等信息
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_info_get()********************");

    -- 参数检查
    -- example:{"module":"sta"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "rlog_module_info get parameter is nil");
        return module_ret("0001", "rlog_module_info get parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta get -m rlog_module_info '%s'", param);

    local tab = dkjson.decode(param);
    -- 参数检查：module
    if (tab["module"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "rlog_module_info get require parameter:module is nil");
        return module_ret("0002", "rlog_module_info get require parameter:module is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "module is %s", tab["module"]);

    -- 读取uci公共配置
    local global_tab = {};
    local uci = require("luci.model.uci").cursor();
    uci:foreach("rlog", "rlog",
    function(s)
        if (s["enable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.enable=%s", s["enable"]);
            global_tab["enable"] = s["enable"];
        end
        if (s["server"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.server=%s", s["server"]);
            global_tab["server"] = s["server"];
        end
        if (s["protocol"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.protocol=%s", s["protocol"]);
            global_tab["protocol"] = s["protocol"];
        end
        if (s["uploadPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.uploadPeriod=%s", s["uploadPeriod"]);
            global_tab["uploadPeriod"] = s["uploadPeriod"];
        end
        if (s["logLevel"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.logLevel=%s", s["logLevel"]);
            global_tab["logLevel"] = s["logLevel"];
        end
        if (s["tarsaveAll"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.tarsaveAll=%s", s["tarsaveAll"]);
            global_tab["tarsaveAll"] = s["tarsaveAll"];
        end
        if (s["retransEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransEnable=%s", s["retransEnable"]);
            global_tab["retransEnable"] = s["retransEnable"];
        end
        if (s["retransPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransPeriod=%s", s["retransPeriod"]);
            global_tab["retransPeriod"] = s["retransPeriod"];
        end
        if (s["retransFileLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransFileLimit=%s", s["retransFileLimit"]);
            global_tab["retransFileLimit"] = s["retransFileLimit"];
        end
        if (s["retransStreamLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransStreamLimit=%s", s["retransStreamLimit"]);
            global_tab["retransStreamLimit"] = s["retransStreamLimit"];
        end
        if (s["streamLenLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.streamLenLimit=%s", s["streamLenLimit"]);
            global_tab["streamLenLimit"] = s["streamLenLimit"];
        end
        if (s["tlscafil"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.tlscafil=%s", s["tlscafil"]);
            global_tab["tlscafil"] = s["tlscafil"];
        end
        if (s["domainSuffix"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.domainSuffix=%s", s["domainSuffix"]);
            global_tab["domainSuffix"] = s["domainSuffix"];
        end
    end);

    -- 判断配置文件是否存在
    result = {};
    resule_data = {};
    resule_tab = {};
    if(libfile.file_is_exist(config_file) == true) then
        -- 读取配置文件
        local file_data = libfile.read_file(config_file);
        if (file_data == nil) then
            libdbg.lua_debug(libdbg.ERROR, "config_file : /etc/rlog/module.json is empty");
            return module_ret("0003", "config_file : /etc/rlog/module.json is empty");
        end

        -- 解析配置文件
        local module_tab = dkjson.decode(file_data);
        if (module_tab == nil) then
            libdbg.lua_debug(libdbg.ERROR, "module_tab is nil");
            return module_ret("0003", "module_tab is nil");
        end

        -- 解析业务列表
        for i, v in ipairs(module_tab["module_list"]) do
            libdbg.lua_debug(libdbg.INFO, "v is %s", v["module_name"]);
            if (v["module_name"] == tab["module"]) then
                resule_data["module_name"] = v["module_name"];

                -- 服务器地址
                if (v["server"] ~= nil) then
                    resule_data["server"] = v["server"];
                else
                    resule_data["server"] = global_tab["server"];
                end
                -- 上传周期
                if (v["upload_period"] ~= nil) then
                    resule_data["upload_period"] = v["upload_period"];
                else
                    resule_data["upload_period"] = global_tab["uploadPeriod"];
                end

                -- 创建周期
                if (v["create_period"] ~= nil) then
                    resule_data["create_period"] = v["create_period"];
                else
                    resule_data["create_period"] = global_tab["uploadPeriod"];
                end

                -- 单独上传
                if (v["single"] ~= nil) then
                    resule_data["single"] = v["single"];
                else
                    resule_data["single"] = 0;
                end

                -- 单独上传
                if (v["file"] ~= nil) then
                    resule_data["file"] = v["file"];
                else
                    resule_data["file"] = "";
                end

                -- 数据文件夹
                resule_data["module_dir"] = string.format("%s/%s", module_dir, resule_data["module_name"]);

                -- 缓冲文件夹
                resule_data["tmp_dir"] = string.format("%s/%s", tmp_dir, resule_data["module_name"]);

                -- 压缩包数据文件夹
                resule_data["tar_dir"] = string.format("%s/%s", tar_dir, resule_data["module_name"]);
            end
        end
        table.insert(resule_tab, resule_data);
        if (resule_data["module_name"] ~= nil) then
            result.module_list = resule_tab;
            -- result.module_list= resule_tab;
            result.total = 1;
        else
            -- 模块不存在
            libdbg.lua_debug(libdbg.ERROR, "module no exist");
            return module_ret("0004", "module no exist");
        end

        return dkjson.encode(result);
    else
        libdbg.lua_debug(libdbg.ERROR, "%s is no exist", config_file);
        return module_ret("0005", "config file is no exist");
    end
end

-- @rlog_module_info_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- 日志之前打印一个空行，不包含时间戳等信息
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_info_set()********************");
    libdbg.lua_debug(libdbg.ERROR, "rlog_module_info set is not support");
    return module_ret("0011", "rlog_module_info set is not support");
end
