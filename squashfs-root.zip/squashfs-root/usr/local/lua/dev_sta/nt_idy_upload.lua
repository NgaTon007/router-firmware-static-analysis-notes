#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_idy_upload",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/nt_idy_upload.lock"

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "nt_idy_upload.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--@module_get
function module_get()
    debug_init()
    sh_ret = {}
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"There is instance process running!\"}"
    end

    ubus_cmd = "ubus call nt_mgr.func call \"{\\\"cmd\\\":\\\"nt_mgr_idy_upload\\\"}\""
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd);
    local ubus_ret = tool.exec(ubus_cmd)
    if (ubus_ret == nil or ubus_ret == "") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] ubus call returned empty")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"ubus call returned empty!\"}"
    end
    local ok, sh_ret = pcall(cjson.decode, ubus_ret)
    if (not ok) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] cjson.decode failed: %s", sh_ret)
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"parse ubus response fail!\"}"
    end
    if (sh_ret["errcode"] ~= nil and sh_ret["errcode"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] nt_idy_upload_set is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"set nt_idy_upload is fail!\"}"
    end
    os.remove(LOCK_FILE)
    return "{\"code\":\"0\",\"msg\":\"all terminal idy msg upload\"}"
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end