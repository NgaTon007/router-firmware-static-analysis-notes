#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("mqlink_status", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libfil = require("utils.file");
local libubs = require("utils.ubus");
local libexc = require("utils.exec");
local dev_sta = require("dev_sta")
local dkjson = require("dkjson");

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/mqlink/", "mqlink_status.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("mqlink_status"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);

    return require("dkjson").encode(result);
end

-- @mqlink_status_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_status_get()********************");

    local status = {
        status = "connected",
        enable = "true",
        code   = "0",
        reason = "NA",
    };
    local boolean_switch = {
        ["1"] = "true",
        ["0"] = "false",
    }

    -- 1����ȡ���̿���enable
    local uci = require("luci.model.uci").cursor();
    local enable = uci:get_first("mqlink", "mqlink", "enable");
    libdbg.lua_debug(libdbg.INFO, "uci get mqlink.@mqlink[0].enable=%s", enable);
    status["enable"] = boolean_switch[enable];
    if (status["enable"] == "false") then
        status["status"] = "disconnect";
    end
    if (enable == "0") then
        status["code"] = "1";
        status["reason"] = "process is disable";
        libdbg.lua_debug(libdbg.ERROR, "process is disable");
        return require("dkjson").encode(status);
    end

    -- 2�����SN���к��Ƿ�Ϸ�
    local sn = uci:get_first("sysinfo", "sysinfo", "serial_num");
    local lib_sn_check = require("utils.sn_check");
    local ret_sn_check = lib_sn_check.input_sn_check(sn);
    if (ret_sn_check == -1) then
        status["status"] = "disconnect";
        status["code"] = "7";
        status["reason"] = string.format("sn:%s, sn is invalid", sn);
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

    -- 3���жϽ����Ƿ���
    -- local proc = "/usr/sbin/mqlink.elf";
    local proc = "/tmp/mqlink.elf.start";
    local sh_cmd = string.format("ps | grep -w %s | grep -v grep | wc -l", proc);
    local sh_ret = libexc.exec_cmd_ret(sh_cmd);
    -- ���ܼ򵥵� sh_ret == "0"����Ϊ�лس�
    if (sh_ret == nil or tonumber(sh_ret) == 0) then
        status["status"] = "disconnect";
        status["code"] = "2";
        status["reason"] = string.format("process:%s is not running", proc);
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        os.execute("/etc/init.d/mqlink restart 2>/dev/null 1>&2")
        return require("dkjson").encode(status);
    end

    local ubus_tab = libubs.ubus_call("mqlink", "status", {}, 3);
    if (ubus_tab["status"] == nil or #ubus_tab["status"] == 0 or ubus_tab["status"] ~= "CONNECTED") then
        if (ubus_tab["conn_code"] ~= nil and ubus_tab["conn_code"] == 5) then
            status["status"] = "disconnect";
            status["code"] = "25";
            status["reason"] = string.format("Connection Refused: not authorised");
            libdbg.lua_debug(libdbg.ERROR, status["reason"]);
            return require("dkjson").encode(status);
        elseif (ubus_tab["conn_code"] ~= nil and ubus_tab["conn_code"] == 30) then
            status["status"] = "disconnect";
            status["code"] = "50";
            if (ubus_tab["ha"] ~= nil) then
                status["reason"] = string.format("%s", ubus_tab["ha"]);
            else
                status["reason"] = string.format("");
            end
            libdbg.lua_debug(libdbg.ERROR, status["reason"]);
            return require("dkjson").encode(status);
        end
    end

    -- 4���ж��Ƿ���ע���ַ
    -- ��ȡ�����ĵ�ַ
    local rom_addr = require("luci.model.uci").cursor("/rom/etc/config/"):get_first("mqlink", "mqlink", "addr")
    libdbg.lua_debug(libdbg.INFO, "uci -c /rom/etc/config/ get mqlink.@mqlink[0].addr=%s", rom_addr);
    -- ��ȡ��ǰ�ĵ�ַ
    local cur_addr = require("luci.model.uci").cursor():get_first("mqlink", "mqlink", "addr")
    libdbg.lua_debug(libdbg.INFO, "uci get mqlink.@mqlink[0].addr=%s", cur_addr);
    if (rom_addr == cur_addr) then
        status["status"] = "disconnect";
        status["code"] = "3";
        status["reason"] = string.format("addr:%s is register addr", rom_addr);
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

        -- 5������Ƿ�ͨ��������������networkConnect̽��
    -- 1172521, ���DNS������mqlink_status���е�����
    local http_test = dev_sta.fetch("get", "networkConnect", '{"ifname": "quick"}').data;
    if (http_test == nil) then
        status["status"] = "disconnect";
        status["code"] = "4";
        status["reason"] = string.format("cannot connecte to Internet or dns failed");
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

    local http_test_table = dkjson.decode(http_test)
    if (http_test_table == nil 
        or (http_test_table["rcode"] ~= "01010022" and http_test_table["connnected"] ~= "true")) then
        status["status"] = "disconnect";
        status["code"] = "4";
        status["reason"] = string.format("cannot connecte to Internet or dns failed");
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

    -- 6�������broker����״̬��ע����30����ӳ٣��ӳ�ʱ��鿴uci get mqlink.@mqlink[0].keepAlivePeroid
    --local ubus_tab = libubs.ubus_call("mqlink", "status", {}, 3);
    if (ubus_tab["status"] == nil or #ubus_tab["status"] == 0 or ubus_tab["status"] ~= "CONNECTED") then
        status["status"] = "disconnect";
        status["code"] = "5";
        status["reason"] = string.format("device is not connect to cloud");
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

    -- 7��controller����ʱ���851478
    local controller = uci:get_first("mqlink", "mqlink", "controller");
    libdbg.lua_debug(libdbg.INFO, "uci get mqlink.@mqlink[0].controller=%s", controller or "nil");
    if (controller == nil or controller == "none") then
        status["status"] = "disconnect";
        status["code"] = "6";
        status["reason"] = string.format("controller:%s is nil or none", controller or "nil");
        libdbg.lua_debug(libdbg.ERROR, status["reason"]);
        return require("dkjson").encode(status);
    end

    return require("dkjson").encode(status);
end

-- @mqlink_status_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_status_set()********************");
    libdbg.lua_debug(libdbg.ERROR, "mqlink_status set is not support");
    return module_ret("0011", "mqlink_status set is not support");
end
