#! /usr/bin/env lua

module_name = "nfpp_status"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
cjson = require "cjson"
dkjson = require "dkjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"
CONF_FILE="/etc/sd_config/single/nfpp.json"
DEF_STATUS='{{"list":[{"zone_name":"lan","defend_ddos":{"icmp_flood_num":"0","arp_flood_num":"0","udp_flood_num":"0","syn_flood_num":"18","tcp_other_flood_num":"0","other_flood_num":"0"},"malformed_pkt":{"fraggle_atk_num":"0","icmp_check_num":"0","ip_check_num":"0","large_ping_num":"0"},"local_pkt_send":{"icmp_forbit_num":"0","icmpv6_forbit":{"msg_type":[],"icmpv6_forbit_num":"0"},"icmp_forbit":{"icmp_forbit_num":"0","msg_type":[]}},"session_safe":{"rate_limit_num":"10"}}],"total":"1"}'


----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 500, module_debug.DEBUG, "1")

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

-- execute sh command through popen
-- @sh_cmd: sh command
-- @If the execution is successful, return the execution result, otherwise return nil
local function cmd_exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil
    end

    local sh_ret
    local sh_ret_handle = io.popen(sh_cmd)

    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end

    return sh_ret
end

local function get_iptable_pkt(cmd)
    if (cmd == nil) then
        return nil
    end

    local content = cmd_exec(cmd)
    if (content == nil) then
        return nil
    end
    
    ret = string.find(content, "No")
    if (ret ~= nil) then
        return nil
    end
    
    local num = string.match(content, "%w+")
    if (num == nil) then
        return nil
    end
    
    return num
end

local function pkt_num_to_string(num)
    if (num < 99999) then
        numstr = tostring(num)
        return numstr
    end

    num = math.modf((num + 500) / 1000)
    if (num < 9999) then
        numstr = tostring(num).."K"
        return numstr
    end

    num = math.modf((num + 500) / 1000)
    if (num < 9999) then
        numstr = tostring(num).."M"
        return numstr
    end
    
    num = math.modf((num + 500) / 1000)
    if (num < 9999) then
        numstr = tostring(num).."G"
        return numstr
    end
    
    numstr = tostring(num).."T"
    return numstr
end

local function pkt_string_to_num(numstr)
    local num = 0
    
    ret = string.find(numstr, "K")
    if (ret ~= nil) then
        numstr = string.gsub(numstr, "K", "")
        num = tonumber(numstr) * 1000
    end

    ret = string.find(numstr, "M")
    if (ret ~= nil) then
        numstr = string.gsub(numstr, "M", "")
        num = tonumber(numstr) * 1000 * 1000
    end

    ret = string.find(numstr, "G")
    if (ret ~= nil) then
        numstr = string.gsub(numstr, "G", "")
        num = tonumber(numstr) * 1000 * 1000 * 1000
    end
    
    ret = string.find(numstr, "T")
    if (ret ~= nil) then
        numstr = string.gsub(numstr, "T", "")
        num = tonumber(numstr) * 1000 * 1000 * 1000 * 1000
    end
   
    if (num == 0) then
        num = tonumber(numstr)
    end
   
    return num
end

local function get_zone_syn_flood(zone_name, defend_ddos)
    defend_ddos["syn_flood_num"] = "0"

    local dropnum_file = "/proc/nfpp/nfpp_tcp_syn_drop_num"
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["syn_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_udp_flood(zone_name, defend_ddos)
    defend_ddos["udp_flood_num"] = "0"

    local dropnum_file = "/proc/nfpp/nfpp_udp_drop_num"
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["udp_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_icmp_flood(zone_name, defend_ddos)
    defend_ddos["icmp_flood_num"] = "0"

    local dropnum_file = "/proc/nfpp/nfpp_icmp_drop_num"
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["icmp_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_arp_flood(zone_name, defend_ddos)
    defend_ddos["arp_flood_num"] = "0"
    local dropnum_file = "/proc/nfpp/nfpp_arp_drop_num"
    
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["arp_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_tcp_other_flood(zone_name, defend_ddos)
    defend_ddos["tcp_other_flood_num"] = "0"
    local dropnum_file = "/proc/nfpp/nfpp_tcp_other_drop_num"
    
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["tcp_other_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_other_flood(zone_name, defend_ddos)
    defend_ddos["other_flood_num"] = "0"
    local dropnum_file = "/proc/nfpp/nfpp_other_ip_drop_num"
    
    local num, dropnum
    local content = file_read(dropnum_file)
    if (content ~= nil) then
        dropnum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            dropnum = tonumber(num)
        end

        dropnum = pkt_num_to_string(dropnum)

        defend_ddos["other_flood_num"] = tostring(dropnum)
    end
end

local function get_zone_defend_ddos(zone_name, defend_ddos)
    get_zone_syn_flood(zone_name, defend_ddos)
    get_zone_udp_flood(zone_name, defend_ddos)
    get_zone_icmp_flood(zone_name, defend_ddos)
    get_zone_arp_flood(zone_name, defend_ddos)
    get_zone_tcp_other_flood(zone_name, defend_ddos)
    get_zone_other_flood(zone_name, defend_ddos)    
end

local function get_zone_large_ping(zone_name, malformed_pkt)
    malformed_pkt["large_ping_num"] = "0"

    local cmd = string.format("iptables -t filter -nvL large_ping_%s 2>/dev/null |grep DROP 2>/dev/null", zone_name)
    
    local num = get_iptable_pkt(cmd)
    if (num ~= nil) then
        malformed_pkt["large_ping_num"] = num
    end
end

local function get_zone_fraggle_atk(zone_name, malformed_pkt)
    malformed_pkt["fraggle_atk_num"] = "0"

    local cmd = string.format("iptables -t filter -nvL fraggle_atk_%s 2>/dev/null |grep DROP 2>/dev/null", zone_name)
    
    local num = get_iptable_pkt(cmd)
    if (num ~= nil) then
        malformed_pkt["fraggle_atk_num"] = num
    end
end

local function get_zone_icmp_check(zone_name, malformed_pkt)
    malformed_pkt["icmp_check_num"] = "0"

    local cmd = string.format("iptables -t filter -nvL icmp_check_%s 2>/dev/null |grep DROP 2>/dev/null", zone_name)
    
    local num = get_iptable_pkt(cmd)
    if (num ~= nil) then
        malformed_pkt["icmp_check_num"] = num
    end
end

local function get_zone_ip_check(zone_name, malformed_pkt)
    malformed_pkt["ip_check_num"] = "0"

    local cmd = string.format("iptables -t filter -nvL ip_check_%s 2>/dev/null |grep DROP 2>/dev/null", zone_name)
    local drop_e_num = get_iptable_pkt(cmd)
    
    local cmd = string.format("iptables -t filter -nvL ip_check_port_%s 2>/dev/null |grep REJECT 2>/dev/null", zone_name)
    local drop_ip_num = get_iptable_pkt(cmd)
    
    local num = 0
    if (drop_e_num ~= nil) then
        num = num + pkt_string_to_num(drop_e_num)
    end
    
    if (drop_ip_num ~= nil) then
        num = num + pkt_string_to_num(drop_ip_num)
    end
    
    num = pkt_num_to_string(num)
    
    malformed_pkt["ip_check_num"] = num
end

local function get_zone_malformed_pkt(zone_name, malformed_pkt)
    get_zone_large_ping(zone_name, malformed_pkt)
    get_zone_fraggle_atk(zone_name, malformed_pkt)
    get_zone_icmp_check(zone_name, malformed_pkt)
    get_zone_ip_check(zone_name, malformed_pkt)
end

local function get_zone_icmp_forbit(zone_name, msg_type, local_pkt_send)
    local_pkt_send["icmp_forbit"] = {}
    local_pkt_send["icmp_forbit"]["icmp_forbit_num"] = "0"
    local_pkt_send["icmp_forbit"]["msg_type"] = {}

    local num = 0
    for k,v in pairs(msg_type) do
        if (v["enable"] == "1") then
            if (string.len(v["code"]) == 0) then
                cmd = string.format("iptables -t filter -nvL icmp_forbit_%s 2>/dev/null |grep 'icmptype %s' 2>/dev/null", zone_name, v["type"])
            else
                cmd = string.format("iptables -t filter -nvL icmp_forbit_%s 2>/dev/null |grep 'icmptype %s code %s' 2>/dev/null", zone_name, v["type"], v["code"])
            end
            
            local icmp = {}
            icmp["code"] = v["code"]
            icmp["type"] = v["type"]
            icmp["num"] = "0"
            
            local drop_num = get_iptable_pkt(cmd)
            if (drop_num ~= nil) then
                icmp["num"] = drop_num
            
                num = num + pkt_string_to_num(drop_num)
            end
            
            table.insert(local_pkt_send["icmp_forbit"]["msg_type"], icmp)
        end
    end

    numstr = pkt_num_to_string(num)
    local_pkt_send["icmp_forbit"]["icmp_forbit_num"] = numstr
end

local function get_zone_icmpv6_forbit(zone_name, msg_type, local_pkt_send)
    local_pkt_send["icmpv6_forbit"] = {}
    local_pkt_send["icmpv6_forbit"]["icmpv6_forbit_num"] = "0"
    local_pkt_send["icmpv6_forbit"]["msg_type"] = {}

    local num = 0
    for k,v in pairs(msg_type) do
        if (v["enable"] == "1") then
            if (string.len(v["code"]) == 0) then
                cmd = string.format("ip6tables -t filter -nvL icmpv6_forbit_%s 2>/dev/null |grep 'ipv6-icmptype %s' 2>/dev/null", zone_name, v["type"])
            else
                cmd = string.format("ip6tables -t filter -nvL icmpv6_forbit_%s 2>/dev/null |grep 'ipv6-icmptype %s code %s' 2>/dev/null", zone_name, v["type"], v["code"])
            end
            
            local icmpv6 = {}
            icmpv6["code"] = v["code"]
            icmpv6["type"] = v["type"]
            icmpv6["num"] = "0"
            
            local drop_num = get_iptable_pkt(cmd)
            if (drop_num ~= nil) then
                icmpv6["num"] = drop_num
            
                num = num + pkt_string_to_num(drop_num)
            end
            
            table.insert(local_pkt_send["icmpv6_forbit"]["msg_type"], icmpv6)
        end
    end
    
    numstr = pkt_num_to_string(num)
    
    local_pkt_send["icmpv6_forbit"]["icmpv6_forbit_num"] = numstr
end

local function get_zone_local_pkt_send(zone_name, local_pkt_send_conf, local_pkt_send)
    get_zone_icmp_forbit(zone_name, local_pkt_send_conf["icmp_forbit"]["msg_type"], local_pkt_send)
    get_zone_icmpv6_forbit(zone_name, local_pkt_send_conf["icmpv6_forbit"]["msg_type"], local_pkt_send)
end

local function get_zone_session_safe(zone_name, session_safe)
    session_safe["rate_limit_num"] = "0"
    local drop_session_file = "/proc/nfpp/nfpp_session_drop_num"
    
    local num, sessionum
    local content = file_read(drop_session_file)
    if (content ~= nil) then
        sessionum = 0
        num = string.gsub(content, "\n", "")
        if (num ~= nil) then
            sessionum = tonumber(num)
        end

        sessionum = pkt_num_to_string(sessionum)

        session_safe["rate_limit_num"] = tostring(sessionum)
    end
end

-- default config
function module_get()
    local config_json = file_to_json(CONF_FILE)
    if (config_json == nil) then
        return DEF_STATUS
    end

    local nfpp_status = {}
    nfpp_status["list"] = {}
    for k,v in pairs(config_json["list"]) do
        if (v["zone_name"] ~= nil) then
            zonelist = {}
            zonelist["zone_name"] = v["zone_name"]

            zonelist["defend_ddos"] = {}
            zonelist["malformed_pkt"] = {}
            zonelist["local_pkt_send"] = {}
            zonelist["session_safe"] = {}
            
            get_zone_defend_ddos(v["zone_name"], zonelist["defend_ddos"])
            get_zone_malformed_pkt(v["zone_name"], zonelist["malformed_pkt"])
            get_zone_local_pkt_send(v["zone_name"], v["local_pkt_send"], zonelist["local_pkt_send"])
            get_zone_session_safe(v["zone_name"], zonelist["session_safe"])
            
            table.insert(nfpp_status["list"], zonelist)
        end  
    end
    
    return dkjson.encode(nfpp_status)
end

