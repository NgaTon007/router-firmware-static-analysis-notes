#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("snmpsta", package.seeall);

local console = require ("console")
local uci = require ("luci.model.uci").cursor()
local dkjson = require ("dkjson")
cjson_safe = require ("cjson.safe")
cjson = require("cjson")
libdbg = require ("utils.debug")
moduleId = require ("dev_module_id")
file_param = require ("dev.tools.common")

moduleName = "snmpsta"
dbgDir = "/tmp/debug/snmpsta/"
dbgFile = "snmpsta.log"
SD_DEVICE = "/tmp/sd_device/sd_device.json"

--����ģ���ʼ��
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

--ģ��set|add|del|update�ķ���ֵ
function module_ret(code, rcode, rdata, rmsg)
    local err = {}
    local ret = {}
    ret["err"] = {}
    err["rdata"] = rdata
    err["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("snmp"), tonumber(rcode))
    ret["code"] = code
    err["rmsg"] = rmsg
    ret["err"] = err
    --table.insert(ret["err"], err)
    res = ret
    if (code == "1") then
        local json_str = cjson_safe.encode(res)
        libdbg.lua_debug(libdbg.INFO,"return json_str:%s\n",json_str)
    end

    return cjson_safe.encode(ret)
end

--���ļ�����������
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

--���ַ���ת��Ϊjson��ʽ
local function read_file_for_json(path)
    local content, content_json

    if (type(path) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "the file path is error.")
        return -1
    end
    content = file_read(path)
    if (content == nil) then
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] read failed.", path)
        return -1
    end
    content_json = cjson_safe.decode(content)
    if (content_json == nil or type(content_json) ~= "table") then
        libdbg.lua_debug(libdbg.ERROR, "parse the file [%s] read failed.", path)
        return -1
    end

    return 0, content_json
end

--Ĭ�ϳ�ʼ������
function module_default_config_get()
end

--get����
function module_get(param)
    --��ȡ���ݱ���λ��
    local get_data = {}
    get_data["list"] = {}
    local snmp_equipment_data
    local master_data
    local sd_device_data
    --��ȡ�豸�ͺ�
    ret, sd_device_data = read_file_for_json(SD_DEVICE)
    if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "file is null")
        return module_ret("1", "2", "NULL", "file is null")
    end
    if (sd_device_data["dev_type"] == nil and sd_device_data["dev_type"] == "") then
        return module_ret("1", "2", "NULL", "dev_type is null")
    end
    if (sd_device_data["dev_type"] ~= "est") then
        --�ж��Ƿ�Ϊ���豸
        local master = io.popen("dev_sta get -m master")
        local master_result = master:read("*a")
        master:close()

        if (master_result == nil) then
            libdbg.lua_debug(libdbg.ERROR, "master data is null")
            return module_ret("1", "2", "NULL", "master data is null!")
        end

        master_data = cjson_safe.decode(master_result)
        if (master_data == nil) then
            libdbg.lua_debug(libdbg.ERROR, "dev_sta get -m master data failed")
            return module_ret("1", "2", "NULL", "dev_sta get -m master data failed")
        end

        if (master_data["ip"] == "127.0.0.1") then
            --���ݻ�ȡ
            local handle = io.popen("dev_sta get -m ap_list")
            local result = handle:read("*a")
            handle:close()
            --�Բ�ѯ��������п�
            if (result == nil) then
                libdbg.lua_debug(libdbg.ERROR, "equipment data is null")
                return module_ret("1", "2", "NULL", "equipment data is null!")
            end
            --����ѯ���ת��Ϊtable��ʽ
            snmp_equipment_data = cjson_safe.decode(result)
            if (snmp_equipment_data == nil) then
                libdbg.lua_debug(libdbg.ERROR, "parse snmp equipment data failed.")
                return module_ret("1", "2", "NULL", "parse snmp equipment data failed!")
            end
        else
            --���ݻ�ȡ
            local handle = io.popen("dev_sta get -m ap_list -i "..master_data["ip"])
            local result = handle:read("*a")
            handle:close()
            --�Բ�ѯ��������п�
            if (result == nil) then
                libdbg.lua_debug(libdbg.ERROR, "equipment data is null")
                return module_ret("1", "2", "NULL", "equipment data is null!")
            end
            --����ѯ���ת��Ϊtable��ʽ
            snmp_equipment_data = cjson_safe.decode(result)
            if (snmp_equipment_data == nil) then
                libdbg.lua_debug(libdbg.ERROR, "parse snmp equipment data failed.")
                return module_ret("1", "2", "NULL", "parse snmp equipment data failed!")
            end
        end
        --�жϽ���Ƿ�Ϊ��
        if (snmp_equipment_data["list"] ~= nil and snmp_equipment_data["list"] ~= "") then
            for i=1,#snmp_equipment_data["list"] do
                local engineID_num = "80001f8804"
                local get_equipment_data = {}
                local engine_string = {}
                --��ȡengine_string��ֵ
                engine_string["engine_string"] = snmp_equipment_data["list"][i]["serialNumber"]
                if ( engine_string["engine_string"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "engine_string is nil")
                end
                --ת��Ϊ16������
                for t=1,#engine_string["engine_string"] do
                    --����ÿ����ĸ�ַ���תΪASCII
                    local ascii_engine = string.byte(engine_string["engine_string"],t)
                    --ASIIתΪ16����
                    local hex_engine = string.format("%x", ascii_engine)
                    --ƴ��16����
                    engineID_num = engineID_num..hex_engine
                end
                --��ֵ
                get_equipment_data["engineID"] = engineID_num
                --��ȡequipment_mode��ֵ
                get_equipment_data["equipment_mode"] = snmp_equipment_data["list"][i]["deviceType"]
                if (get_equipment_data["equipment_mode"] == nil or get_equipment_data["equipment_mode"] == "") then
                    libdbg.lua_debug(libdbg.WARNING, "equipment_mode is nil")
                    return module_ret("1", "2", "NULL", "equipment_mode is nil")
                end
                --��ȡequipment_ip��ֵ
                get_equipment_data["equipment_ip"] = snmp_equipment_data["list"][i]["ip"]
                if (get_equipment_data["equipment_ip"] == nil or get_equipment_data["equipment_ip"] == "") then
                    libdbg.lua_debug(libdbg.WARNING, "equipment_ip is nil")
                    get_equipment_data["equipment_ip"] = "127.0.0.1"
                end
                --���������
                table.insert(get_data["list"], get_equipment_data)
            end
        else
            local engineID_num = "80001f8804"
            local get_equipment_data = {}
            local engine_string = {}
            --��ȡengine_string��ֵ
            engine_string["engine_string"] = uci:get_first("sysinfo", "sysinfo", "serial_num")
            if (engine_string["engine_string"] == nil or engine_string["engine_string"] == "") then
                libdbg.lua_debug(libdbg.WARNING, "engine_string is nil")
                return module_ret("1", "2", "NULL", "engine_string is nil")
            end
            --ת��Ϊ16������
            for t=1,#engine_string["engine_string"] do
                --����ÿ����ĸ�ַ���תΪASCII
                local ascii_engine = string.byte(engine_string["engine_string"],t)
                --ASIIתΪ16����
                local hex_engine = string.format("%x", ascii_engine)
                --ƴ��16����
                engineID_num = engineID_num..hex_engine
            end
            --��ֵ
            get_equipment_data["engineID"] = engineID_num
            --��ȡequipment_mode��ֵ
            get_equipment_data["equipment_mode"] = uci:get_first("sysinfo", "sysinfo", "product_class")
            if (get_equipment_data["equipment_mode"] == nil or get_equipment_data["equipment_mode"] == "") then
                libdbg.lua_debug(libdbg.WARNING, "equipment_mode is nil")
                return module_ret("1", "2", "NULL", "equipment_mode is nil")
            end
            --��ȡequipment_ip��ֵ
            get_equipment_data["equipment_ip"] = uci:get_first("sysinfo", "sysinfo", "wan_ip")
            if (get_equipment_data["equipment_ip"] == nil or get_equipment_data["equipment_ip"] == "") then
                libdbg.lua_debug(libdbg.WARNING, "equipment_ip is nil")
                get_equipment_data["equipment_ip"] = "127.0.0.1"
            end
            --���������
            table.insert(get_data["list"], get_equipment_data)
        end
    else
        --���ݻ�ȡ
        local handle = io.popen("dev_sta get -m wds_list_all")
        local result = handle:read("*a")
        handle:close()
        --�Բ�ѯ��������п�
        if (result == nil) then
            libdbg.lua_debug(libdbg.ERROR, "equipment data is null")
            return module_ret("1", "2", "NULL", "equipment data is null!")
        end
        --����ѯ���ת��Ϊtable��ʽ
        snmp_equipment_data = cjson_safe.decode(result)
        if (snmp_equipment_data == nil) then
            libdbg.lua_debug(libdbg.ERROR, "parse snmp equipment data failed.")
            return module_ret("1", "2", "NULL", "parse snmp equipment data failed!")
        end
        for i=1,#snmp_equipment_data["list_all"] do
            for j=1,#snmp_equipment_data["list_all"][i]["list_pair"] do
                local engineID_num = "80001f8804"
                local get_equipment_data = {}
                local engine_string = {}
                --��ȡengine_string��ֵ
                engine_string["engine_string"] = snmp_equipment_data["list_all"][i]["list_pair"][j]["sn"]
                if (engine_string["engine_string"] == nil or engine_string["engine_string"] == "") then
                libdbg.lua_debug(libdbg.WARNING, "engine_string is nil")
                    return module_ret("1", "2", "NULL", "engine_string is nil")
                end
                --ת��Ϊ16������
                for t=1,#engine_string["engine_string"] do
                    --����ÿ����ĸ�ַ���תΪASCII
                    local ascii_engine = string.byte(engine_string["engine_string"],t)
                    --ASIIתΪ16����
                    local hex_engine = string.format("%x", ascii_engine)
                    --ƴ��16����
                    engineID_num = engineID_num..hex_engine
                end
                --��ֵ
                get_equipment_data["engineID"] = engineID_num
                --��ȡequipment_mode��ֵ
                get_equipment_data["equipment_mode"] = snmp_equipment_data["list_all"][i]["list_pair"][j]["dev_type"]
                if (get_equipment_data["equipment_mode"] == nil or get_equipment_data["equipment_mode"] == "") then
                    libdbg.lua_debug(libdbg.WARNING, "equipment_mode is nil")
                    return module_ret("1", "2", "NULL", "equipment_mode is nil")
                end
                --��ȡequipment_ip��ֵ
                get_equipment_data["equipment_ip"] = snmp_equipment_data["list_all"][i]["list_pair"][j]["userIp"]
                if (get_equipment_data["equipment_ip"] == nil or get_equipment_data["equipment_ip"] == "") then
                    libdbg.lua_debug(libdbg.WARNING, "equipment_ip is nil")
                    return module_ret("1", "2", "NULL", "equipment_ip is nil")
                end
                --���������
                table.insert(get_data["list"], get_equipment_data)
            end
        end
    end
    --����תΪjson��ʽ
    local json_str = cjson_safe.encode(get_data)
    if (json_str == nil) then
        libdbg.lua_debug(libdbg.WARNING, "def_cfg_json isn't json")
        return json_str
    end
    return json_str
end