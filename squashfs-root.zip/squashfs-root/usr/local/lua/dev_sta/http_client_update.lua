#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("http_client_update",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/sddir/oam/http_client/"
local LOCK_FILE = "/tmp/sddir/oam/http_client/.http_client_update.lock"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "http_client_update.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    local ret = tool.exec(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "%s %s", ubus_cmd, ret)

    return ret
end

function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end

    local param_table = cjson.decode(param)
    if (param_table == nil or next(param_table) == nil or param_table["upd_list"] == nil) then 
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is err")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is err!\"}"
    end

    local list = {}
    list["upd_list"] = param_table["upd_list"]
    cmd = string.format("ubus call http_client set_upd '%s'", cjson.encode(list))
    tab = ubus_cmd_exe(cmd)
    if (tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] update is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"update is fail!\"}"
    end

    os.remove(LOCK_FILE)
    return tab
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end