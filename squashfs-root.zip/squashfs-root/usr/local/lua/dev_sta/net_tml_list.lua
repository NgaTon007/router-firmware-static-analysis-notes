#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_list",package.seeall)
local lfs = require "lfs"
local ubus = require "ubus"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml_list.lock"
local JSON_FILE_DIR = "/tmp/nt_json/"
local METADATA_FILE = "nt_metadata.json"
local UBUS_WAIT_TIME = 3

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_list.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 检查用于执行ubus的指令是否有单引号、双引号，nil_flag用于说明此参数是否可以为空,nil_flag:1 可以为空 2：不可为空
local function ubus_cmd_param_check(param, nil_flag)
    if (nil_flag ~= 1) then
        if (param == "") then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is nil")
            return -1
        end
    end
    if ((string.match(param , "\"") ~= nil) or (string.match(param , "'") ~= nil)) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is dangrous")
        return -1
    end
    return 0
end

local function is_null(val)
    return val == nil or val == ""
end

-- 获取最新的厂商表文件
local function get_latest_metadata_file()
    local latest_file = nil
    for file in lfs.dir(JSON_FILE_DIR) do
        if file:match("^(%d+)_" .. METADATA_FILE .. "$") then
            if not latest_file or file > latest_file then
                latest_file = file
            end
        end
    end
    if latest_file then
        return JSON_FILE_DIR .. latest_file
    else
        return nil
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(object, method, param, conn_obj)
    -- module_debug.lua_debug(module_debug.INFO, "ubus_cmd ubus call %s %s '%s'", object, method, cjson.encode(param))

    local conn = conn_obj
    local need_close = false
    if not conn then
        conn = ubus.connect(nil, UBUS_WAIT_TIME)
        need_close = true
    end
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: connect to ubus fail!")
        return nil
    end

    local ret = conn:call(object, method, param or {})
    if need_close and conn then
        conn:close()
    end

    return ret
end

--@net_tml_list_get
function net_tml_list_get(param)
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end

    -- 全量查询时候的文件
    local file_name_all = "/tmp/nt_info/nt_info_all_web.json"
    -- 增量查询时候的文件
    local file_name_inc = "/tmp/nt_info/nt_info_inc_web"
    local file_name_tmp = file_name_inc
    local cnt = 1
    while (tool.file_exist(file_name_inc..".json") == true) do
        file_name_inc = file_name_tmp..cnt
        cnt = cnt + 1
    end
    file_name_inc =file_name_inc..".json"

    if (ubus_cmd_param_check(param_tab["start"], 1) < 0) then
        return
    end
    -- start为空默认为0
    if (param_tab["start"] == "") then
        param_tab["start"] = 0
    end

    if (ubus_cmd_param_check(param_tab["group_name"], 1) < 0) then
        return
    end

    if (ubus_cmd_param_check(param_tab["limit"], 1) < 0) then
        return
    end

    local ubus_param = {
        start = param_tab["start"],
        group_name = param_tab["group_name"],
        from = "web"
    }

    local all_query_flag
    if (param_tab["group_name"] == "") then
        all_query_flag = 1
    end

    if (all_query_flag == 1) then 
        -- limit为空 ubus不传
        ubus_param.file = file_name_all
        if (param_tab["limit"] ~= "") then
            ubus_param.limit = param_tab["limit"]
        end
    else
        -- limit为空 ubus不传
        ubus_param.file = file_name_inc
        if (param_tab["limit"] ~= "") then
            ubus_param.limit = param_tab["limit"]
        end
    end

    local ret = ubus_cmd_exe("nt_mgr.nt_info", "get_all", ubus_param, nil)
    if not ret or ret.code == nil or tostring(ret.code) ~= "0" then
        return
    end

    local config_tab

    if (all_query_flag == 1) then 
        config_tab = tool.file_read(file_name_all)
    else
        config_tab = tool.file_read(file_name_inc)
        -- 删除临时创建的文件
        tool.exec("rm -rf "..file_name_inc)
    end

    -- 追加文件分页设置
    if (config_tab == "" or config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] config is nil")
        return
    end

    module_debug.lua_debug(module_debug.INFO, "################################GET END################################")
    return config_tab
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"":[]}'
    return default_config
end

--@module_get
function module_get(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    config_tab = net_tml_list_get(param)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] net_tml_list_get is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"get net_tml_list is fail!\"}"
    end
    --module_debug.lua_debug(module_debug.DEBUG, "config_tab %s", config_tab)
    os.remove(LOCK_FILE)
    return config_tab
end

--@module_update
function module_update(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"err\":{\"rcode\":\"00500001\",\"rmsg\":\"There is instance process running!\"},\"code\":\"1\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param is not nil")
        end
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500002\",\"rmsg\":\"param is unsafe!\"},\"code\":\"1\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "################################UPDATE################################")

    local conn = ubus.connect(nil, UBUS_WAIT_TIME)
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] connect to ubus fail!")
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500003\",\"rmsg\":\"connect to ubus fail!\"},\"code\":\"1\"}"
    end

    local ret = ubus_cmd_exe("nt_mgr.idy", "pull_tml_info", {}, conn)
    if not ret or ret.code == nil or tostring(ret.code) ~= "0" then
        return "{\"err\":{\"rcode\":\"00500004\",\"rmsg\":\"pull_tml_info failed!\"},\"code\":\"1\"}"
    end

    local metadata_file = get_latest_metadata_file()
    local md5 = "all"
    if metadata_file then
        module_debug.lua_debug(module_debug.INFO, "using metadata file: %s", metadata_file)
        local content = tool.file_read(metadata_file, "r") or ""
        local success, result = pcall(cjson.decode, content)
        if success and not is_null(result["md5"]) then
            md5 = result["md5"]
            module_debug.lua_debug(module_debug.INFO, "metadata md5: %s", md5)
        else
            module_debug.lua_debug(module_debug.INFO, "use default md5: all")
        end
    else
        module_debug.lua_debug(module_debug.INFO, "No metadata file found, use default md5: all")
    end
    local mqlink_param = {
        name = "nt_mgr",
        bizid = "nt_mgr_01",
        ack = "true",
        val = {
            op = "tm",
            md5 = md5
        }
    }
    if ubus_cmd_exe("mqlink", "status_notify", mqlink_param, conn) == nil then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] mqlink status_notify failed")
        conn:close()
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500005\",\"rmsg\":\"mqlink status_notify failed!\"},\"code\":\"1\"}"
    end
    conn:close()

    module_debug.lua_debug(module_debug.INFO, "################################UPDATE END################################")

    os.remove(LOCK_FILE)
    return "{\"rcode\":\"00000000\",\"rmsg\": \"[update] success\"}"
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end