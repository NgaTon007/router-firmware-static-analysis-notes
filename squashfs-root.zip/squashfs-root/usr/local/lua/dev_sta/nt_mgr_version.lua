#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_version",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_version.lock"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_version.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)
    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))
    flag = 0
    rule_date = {}
    rule_date["signature"] = {}

    if (sh_ret["errcode"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return
    end

    rule_date["signature"]["update_state"] = sh_ret["update_state"]
    rule_date["signature"]["oui_detail"] = sh_ret["signature_oui_detail"]
    rule_date["signature"]["rule_detail"] = sh_ret["signature_rule_detail"]

    sh_ret = cjson.encode(rule_date)
    module_debug.lua_debug(module_debug.INFO, "[ubus_cmd] sh_ret %s!", sh_ret)
    return sh_ret
end

--@nt_mgr_version_get
function nt_mgr_version_get()
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################")

    ubus_cmd = "ubus call nt_mgr.func call \"{\\\"cmd\\\":\\\"nt_idy_version_get\\\"}\""
    config_tab = ubus_cmd_exe(ubus_cmd)
    if (config_tab == nil) then
        return
    end

    module_debug.lua_debug(module_debug.INFO, "################################GET END################################")
    return config_tab
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"signature":{}}'
    return default_config
end

--@module_get
function module_get()
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    config_tab = nt_mgr_version_get()
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] nt_mgr_version_get is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"get nt_mgr_version is fail!\"}"
    end
    os.remove(LOCK_FILE)
    return config_tab
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end