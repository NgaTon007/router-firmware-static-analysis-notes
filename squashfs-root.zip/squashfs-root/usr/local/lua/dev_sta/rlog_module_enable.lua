#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("rlog_module_enable", package.seeall); -- 第一个参数是本模块的文件名

local libdbg = require("utils.debug");
local libexec = require("utils.exec");
local libfile = require("utils.file");
local dkjson = require("dkjson");

local config_file = "/etc/rlog/module.json";
-- 调试模块初始化
libdbg.debug_init("/tmp/rlog/", "rlog_module_enable.lua.log", 500, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- 模块set|get的返回值
    @code：错误码0000为成功，其他为失败
    @msg:返回的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "0000") then
        result["result"] = msg;
    else
        result["result"] = "error";
        result["code"] = code;
        result["reason"] = msg;
    end

    return require("dkjson").encode(result);
end

-- @rlog_module_enable_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- 日志之前打印一个空行，不包含时间戳等信息
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_enable_get()********************");

    -- 参数检查
    -- {"module":"sta"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.WARNING, "rlog_module_enable get parameter is nil");
        -- return module_ret("0001", "rlog_module_enable get parameter is nil");
    end

    -- 判断配置文件是否存在
    local file_flag = libfile.file_is_exist(config_file);
    if (file_flag == false) then
        libdbg.lua_debug(libdbg.ERROR, "config_file : /etc/rlog/module.json is not exist");
        return module_ret("0004", "config_file : /etc/rlog/module.json is not exist");
    end

    -- 读取配置文件
    local file_data = libfile.read_file(config_file);
    if (file_data == nil) then
        libdbg.lua_debug(libdbg.ERROR, "config_file : /etc/rlog/module.json is empty");
        return module_ret("0003", "config_file : /etc/rlog/module.json is empty");
    end

    -- 解析配置文件
    local module_tab = dkjson.decode(file_data);
    if (module_tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "module_tab is nil");
        return module_ret("0003", "module_tab is nil");
    end

    -- 获取rlog上传使能
    local rlog_upload_enable = 0;
    local rlog_status_ret = libexec.exec_cmd_ret("rlog show status 2>&1");
    if (rlog_status_ret ~= nil and rlog_status_ret ~= "") then
        local rlog_upload_enable_tab = dkjson.decode(rlog_status_ret);
        if (rlog_upload_enable_tab ~= nil) then
            if (rlog_upload_enable_tab["enable"] == 1 or rlog_upload_enable_tab["enable"] == "1" ) then
                rlog_upload_enable = 1;
                libdbg.lua_debug(libdbg.INFO, "rlog_upload_enable 1");
            else
                libdbg.lua_debug(libdbg.INFO, "rlog_upload_enable 0");
            end
        else
            libdbg.lua_debug(libdbg.ERROR, "rlog_upload_enable_tab is nil");
        end
    else
            libdbg.lua_debug(libdbg.ERROR, "rlog_status_ret is nil");
    end

    local result_tab = {};
    libdbg.lua_debug(libdbg.INFO, "dev_sta get -m rlog_module_enable %s", param == nil and "" or param);
    if (param ~= nil) then
        local tab = dkjson.decode(param);
        -- 参数检查：tab
        if (tab == nil) then
            libdbg.lua_debug(libdbg.ERROR, "rlog_module_enable get require parameter:can not decode param");
            return module_ret("0002", "rlog_module_enable get require parameter:can not decode param");
        end
        -- 参数检查：module
        if (tab["module"] == nil) then
            libdbg.lua_debug(libdbg.ERROR, "rlog_module_enable get require parameter:module is nil");
            return module_ret("0002", "rlog_module_enable get require parameter:module is nil");
        end
        libdbg.lua_debug(libdbg.INFO, "module is %s", tab["module"]);

        -- 解析业务列表
        for i, v in ipairs(module_tab["module_list"]) do
            libdbg.lua_debug(libdbg.INFO, "v is %s", v["module_name"]);
            if (v["module_name"] == tab["module"]) then
                -- 配置存在
                if (rlog_upload_enable == 1) then
                    result_tab["result"] = "1";
                    libdbg.lua_debug(libdbg.INFO, "module exist, return enable 1");
                    return dkjson.encode(result_tab);
                else
                    result_tab["result"] = "0";
                    libdbg.lua_debug(libdbg.INFO, "module exist, but rlog_upload_enable 0");
                    return dkjson.encode(result_tab);
                end
            end
        end

        libdbg.lua_debug(libdbg.INFO, "module no exist, return enable 0");
        result_tab["result"] = "0";
    else
        result_tab = {
            enable_list = {}
        }
        local module_entry = {};

        -- 解析业务列表
        for i, v in ipairs(module_tab["module_list"]) do
            libdbg.lua_debug(libdbg.INFO, "v is %s", v["module_name"]);
            if (rlog_upload_enable == 1) then
                module_entry = {
                    module = v["module_name"],
                    result = "1"
                }
            else
                module_entry = {
                    module = v["module_name"],
                    result = "0"
                }
            end
            table.insert(result_tab["enable_list"], module_entry)
            libdbg.lua_debug(libdbg.INFO, "module: %s, exist, return enable 1", v["module_name"]);
        end
    end
    return dkjson.encode(result_tab);
end

-- @rlog_module_enable_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- 日志之前打印一个空行，不包含时间戳等信息
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_enable_set()********************");
    libdbg.lua_debug(libdbg.ERROR, "rlog_module_enable set is not support");
    return module_ret("0011", "rlog_module_enable set is not support");
end
