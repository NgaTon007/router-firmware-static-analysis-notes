#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("arp", package.seeall); -- 第一个参数是本模块的文件名

local ARP_FILE = "/proc/net/arp";
local libdbg = require "utils.debug";

--调试模块初始化
libdbg.debug_init("/tmp/arp/", "arp.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- 模块set|add|del|update的返回值
    @frm_code：返回给统一配置框架的错误码，参数类型[string, num]
               统一配置框架接收到该字段值字符串的"1"，或者数字的1都认为是模块内部错误返回，不保存配置
               框架最后不会打印本字段。
    @web_code：返回给web的错误码，参数类型[string, num]，框架最后会打印本字段。
    @web_msg:返回给web的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串，{"code":x, "err":"x;xxx"}，例如{"code":1, "err":"1;param is invalid"}
    @note：本接口只给ac_config或者dev_config的set|add|del|update操作使用的。
           最终打印消息是err的值也就是例子中的"1;param is invalid"
           一般只有错误时才需要返回。如果模块成功，不需要调用本接口，直接return。
--]]
function module_ret(frm_code, web_code, web_msg, ...)
    result = {};
    result["code"] = frm_code;
    result["err"] = table.concat({web_code, ";", string.format(web_msg, ...)});

    return require("dkjson").encode(result);
end

-- @arp_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- 日志之前打印一个空行，不包含时间戳等信息
    libdbg.lua_debug(libdbg.INFO, "********************Enter arp_get()********************");

    local json_str = {};
    local libfil = require("utils.file");
    if (libfil.file_is_exist(ARP_FILE) == false) then
        libdbg.lua_debug(libdbg.ERROR, "file:%s is not exist", ARP_FILE);
        return module_ret(2, 2, "file:%s is not exist", ARP_FILE);
    end
    local libstr = require("utils.string");
    local arp_str = libfil.read_file(ARP_FILE);
    if (arp_str == nil or #arp_str < 78) then -- 标题的长度是:78
        libdbg.lua_debug(libdbg.ERROR, "file:%s is empty or invalid, please check it", ARP_FILE);
        return module_ret(3, 3, "file:%s is empty or invalid, please check it", ARP_FILE);
    end
    local arp_line_tab = libstr.string_split_to_table(arp_str, "\n");
    local arp_meta_tab = {};
    local arp_sub_tab = {};
    local arp_tab = {};
    local mac = {};
    local Flags;
    for i = 1, #arp_line_tab do
        arp_meta_tab = libstr.string_split_to_table(arp_line_tab[i], " ");
        Flags = arp_meta_tab[3]
        if (string.find(arp_line_tab[i], "type") == nil and Flags ~= "0x0") then
            arp_sub_tab = {};
            arp_sub_tab["address"]  = arp_meta_tab[1];
            -- 暂时不用xxxx.xxxx.xxxx格式，仍旧使用xx:xx:xx:xx:xx:xx，如果要切换格式把注释代码开放即可
            -- mac = libstr.string_split_to_table(arp_meta_tab[4], ":");
            -- arp_sub_tab["hardware"] = string.format("%s%s.%s%s.%s%s", mac[1], mac[2], mac[3], mac[4], mac[5], mac[6]);
            arp_sub_tab["hardware"] = arp_meta_tab[4];
            arp_sub_tab["intf"]     = arp_meta_tab[6];
            table.insert(arp_tab, arp_sub_tab);
        end
    end
    local out_tab = {
        arpList = arp_tab
    }
    if (arp_tab ~= {}) then
        json_str = require("dkjson").encode(out_tab)
    end

    return json_str;
end

-- @arp_set
function module_set(param)
    libdbg.lua_debug(libdbg.INFO, "********************Enter arp_set()********************");
    -- 1、参数检查
    libdbg.lua_debug(libdbg.ERROR, "arp_set() is not support");
    return module_ret(1, 1, "arp_set() is not support");

end

-- 本地测试
-- module_get();