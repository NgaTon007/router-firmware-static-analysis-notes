#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("accounts_batch_cfg",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local luci_tool = require("luci.utils.tool")
local libc2lua = require("libc2lua")
require "public_module"
local sd_crypto = require("sd_crypto");

local DEBUG_LOG_DIR = "/tmp/accounts_batch/"
local LOCK_FILE = "/tmp/accounts_batch/accounts_batch_cfg.lock"
local PPPOE_USER_JSON_FILE = "/etc/sd_config/single/pppoeserver_user.json"
local PPPOE_USER_CFG = "pppoeserver_user_cfg"
local GET_PPPOE_SERVER_MAXNUM_CMD = "jq -r .gateway.pppoe_server_maxnum \"/tmp/sd_device/sd_device.json\""
local PPPOE_USER_SET_CFG_STATUS = "/tmp/accounts_batch/pppoe_uer_set_cfg_status"
local PPPOE_USER_GET_CFG_STATUS = "/tmp/accounts_batch/pppoe_uer_get_cfg_status"
local GET_FLOWCTRL_PPPOE_CMD = "dev_sta get -m flowctrl_pppoe"
if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

if (tool.file_exist(PPPOE_USER_SET_CFG_STATUS) == false) then
    tool.exec("touch /tmp/accounts_batch/pppoe_uer_set_cfg_status")
end

if (tool.file_exist(PPPOE_USER_GET_CFG_STATUS) == false) then
    tool.exec("touch /tmp/accounts_batch/pppoe_uer_get_cfg_status")
end
--debug初始化
function debug_init()
	module_debug.debug_init(DEBUG_LOG_DIR, "accounts_batch_cfg.log", 50, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--参数校验
function config_file_check(param)
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Input data is not json mode.")
        return
    end	
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end
	return param_tab
end

function module_default_config_get()
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    --参数校验
    local param_tab = config_file_check(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is null!\"}"
    end

	local cfg_type = param_tab["type"]
	
	if (cfg_type == PPPOE_USER_CFG) then
       if (tool.file_read(PPPOE_USER_SET_CFG_STATUS) ~= "set running") then
            os.execute("lua /usr/bin/pppoeserver_user_cfg.lua \"{\\\"action\\\":\\\"set\\\",\\\"language\\\":\\\"CN\\\"}\" >/dev/null 2>&1 &")
            tool.sleep(5)
            os.remove(LOCK_FILE)
            return "{\"code\":\"0\",\"msg\":\"config execute OK!\"}"
       else
            os.remove(LOCK_FILE)
            return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
       end
    else
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"Set pppoeserver_user_cfg is fail!\"}"       
	end
end

--@module_get
function module_get(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

	if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    --参数校验
    local param_tab = config_file_check(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is null!\"}"
    end
	local cfg_type = param_tab["type"]
	if (cfg_type == PPPOE_USER_CFG) then
       if (tool.file_read(PPPOE_USER_GET_CFG_STATUS) ~= "get running" and param_tab["language"] ~= nil) then
            if (param_tab["language"] == "CN") then
                os.execute("lua /usr/bin/pppoeserver_user_cfg.lua \"{\\\"action\\\":\\\"get\\\",\\\"language\\\":\\\"CN\\\"}\" >/dev/null 2>&1 &")
            elseif (param_tab["language"] == "EN") then
                os.execute("lua /usr/bin/pppoeserver_user_cfg.lua \"{\\\"action\\\":\\\"get\\\",\\\"language\\\":\\\"EN\\\"}\" >/dev/null 2>&1 &")
            else
                os.remove(LOCK_FILE)
                return "{\"code\":\"-1\",\"msg\":\"Set pppoeserver_user_cfg is fail!\"}"               
            end                 
            tool.sleep(5)
            os.remove(LOCK_FILE)
            return "{\"code\":\"0\",\"msg\":\"config execute OK!\"}"
       else
            os.remove(LOCK_FILE)
            return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
       end
    else
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"Set pppoeserver_user_cfg is fail!\"}"       
	end
end
