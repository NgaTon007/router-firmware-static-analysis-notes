#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_memory",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local util = require "luci.util"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_memory.lock"

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_memory.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--@module_get
function module_get()
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end
    module_debug.lua_debug(module_debug.INFO, "###############################GET###############################")

    local flash_min = 0
    local memery_min = 0
    
    flash_min = tonumber(uci:get("nt_mgr", "update", "flash"))
    memery_min = tonumber(uci:get("nt_mgr", "update", "memery"))

    local flash_size = tonumber(tool.exec("df | grep -w /overlay | awk '{print $4}' | head -n 1"))
    local memery_size = tonumber(tool.exec("cat /proc/meminfo | grep MemFree | awk '{print $2}'"))


    if(flash_min > flash_size or memery_min > memery_size) then
        module_debug.lua_debug(module_debug.INFO, "flash_min %d, flash_size %d, memery_min %d , memery_size %d",flash_min, flash_size, memery_min, memery_size)
        os.remove(LOCK_FILE) 
        return "{\"code\":\"-1\",\"msg\":\"out of memory\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "###############################GET END###############################")
    os.remove(LOCK_FILE)
    return "{\"code\":\"0\",\"msg\":\"memory is enough\"}"
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end

