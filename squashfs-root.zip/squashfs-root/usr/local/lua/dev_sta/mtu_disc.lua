--#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("mtu_disc", package.seeall)

local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lfs = require "lfs"
local libc2lua = require("libc2lua");
local cjson = require "cjson"

local DEBUG_LOG_DIR = "/tmp/mtu_disc/lua/"
local DEBUG_LOG_FILE = "mtu_disc.log"
local JSON_RESULT_FILE = "/etc/mtu_disc/result.json"
local SELF_CHECK_JSON_FILE = "/etc/mtu_disc/check.json"
local STOP_JSON_RESULT = "{\"error_code\":-1005,\"error_msg\":\"user aborted\"}"

function param_check_safe(param)
    if (string.match(param, "([|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is unsafe");
        return false;
    end
    return true;
end

--判断文件夹是否存在,不存在创建
if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " > /dev/null 2>&1";
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, DEBUG_LOG_FILE, 500, module_debug.DEBUG, "1");
end

--mtu探测进程状态查询
function get_process_stat()
    module_debug.lua_debug(module_debug.INFO, "################process_stat_get################");
    local proc_cnt = tonumber(tool.exec("ps | grep mtu_disc.elf | grep -v grep | wc -l"));
    module_debug.lua_debug(module_debug.INFO, "proc_cnt:%d", proc_cnt);
    return proc_cnt;
end

--获取结果
function get_result(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################get_result################");

    local result;
    local cmd;
    local result_filename, testing_filename, tty_filename;
    local never_disc = 0;

    if (param_tab["intf"] == nil) then
        result_filename = string.format("/etc/mtu_disc/null_result.json");
        testing_filename = string.format("/tmp/mtu_disc/null_testing");
        --tty_filename = string.format("/www/mtu_disc/null_tty.txt");
        tty_filename = string.format("/mtu_disc/null_tty.txt");
    else
        result_filename = string.format("/etc/mtu_disc/%s_result.json", param_tab["intf"]);
        testing_filename = string.format("/tmp/mtu_disc/%s_testing", param_tab["intf"]);
        --tty_filename = string.format("/www/mtu_disc/%s_tty.txt", param_tab["intf"]);
        tty_filename = string.format("/mtu_disc/%s_tty.txt", param_tab["intf"]);
    end
    module_debug.lua_debug(module_debug.INFO, "result_filename = [%s]", result_filename);
    module_debug.lua_debug(module_debug.INFO, "testing_filename = [%s]", testing_filename);
    module_debug.lua_debug(module_debug.INFO, "tty_filename = [%s]", tty_filename);

    --进程存在 且 测得是正在探测的
    if (get_process_stat() ~= 0 and tool.file_exist(testing_filename) == true) then
        result = "{\"error_code\":-1000,\"error_msg\":\"already running\"}";
    else
        --判断结果文件是否存在 文件不存在 读默认文件
        if (tool.file_exist(result_filename) == false) then
            --判断默认结果文件是否存在 文件不存在 说明从来没测过
            if (tool.file_exist(JSON_RESULT_FILE) == false) then
                never_disc = 1;
                result = "{\"error_code\":-1001,\"error_msg\":\"never mtu disc\"}";
            else
                result = tool.file_read(JSON_RESULT_FILE);
            end
        else
            result = tool.file_read(result_filename);
        end
    end
    module_debug.lua_debug(module_debug.INFO, "result:\n%s", result);

    local result_tab = cjson.decode(result);
    if (result_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: cjson.decode error");
        return result;
    end

    if (never_disc == 1) then
        result_tab["tty_log"] = "";
    else
        --local content = tool.file_read(tty_filename);
        --module_debug.lua_debug(module_debug.INFO, "content:\n%s", content);
        result_tab["tty_log"] = tty_filename;
    end
    result = cjson.encode(result_tab);

    return result;
end

--开始mtu探测
function start_mtu_disc(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################start_mtu_disc################");

    local filename;

    if (param_tab["intf"] == nil) then
        filename = string.format("/tmp/mtu_disc/null_testing");
    else
        filename = string.format("/tmp/mtu_disc/%s_testing", param_tab["intf"]);
    end

    --testing_file存在
    if (tool.file_exist(filename) == true) then
        return "{\"error_code\":-1000,\"error_msg\":\"already running\"}";
    end

    --重新转为json
    local json_str = cjson.encode(param_tab);

    tool.file_write(filename, "");

    --拉进程
    --local cmd = string.format("/usr/sbin/mtu_disc.elf -j '%s' > /tmp/mtu_disc/mtu_disc.log", json_str);
    local cmd = string.format("/usr/sbin/mtu_disc.elf -j '%s' > /tmp/mtu_disc/mtu_disc.log &", json_str);
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    tool.exec(cmd);

    --return get_result(param_tab);
    return "{\"error_code\":0,\"error_msg\":\"success\"}";
end

--停止mtu探测
function stop_mtu_disc(param_tab)
    module_debug.lua_debug(module_debug.INFO, "################stop_detect################");

    --进程不存在直接返回
    if (get_process_stat() == 0) then
        return "{\"error_code\":-1002,\"error_msg\":\"process not exsit\"}";
    end

    local result_filename, testing_filename, tty_filename;

    if (param_tab["intf"] == nil) then
        result_filename = string.format("/etc/mtu_disc/null_result.json");
        testing_filename = string.format("/tmp/mtu_disc/null_testing");
        tty_filename = string.format("/www/mtu_disc/null_tty.txt");
    else
        result_filename = string.format("/etc/mtu_disc/%s_result.json", param_tab["intf"]);
        testing_filename = string.format("/tmp/mtu_disc/%s_testing", param_tab["intf"]);
        tty_filename = string.format("/www/mtu_disc/%s_tty.txt", param_tab["intf"]);
    end
    module_debug.lua_debug(module_debug.INFO, "result_filename = [%s]", result_filename);
    module_debug.lua_debug(module_debug.INFO, "testing_filename = [%s]", testing_filename);

    module_debug.lua_debug(module_debug.INFO, "cmd:%s", "killall -9 mtu_disc.elf");
    tool.exec("killall -9 mtu_disc.elf");--进程还在 强行结束

    local cmd = string.format("rm -rf %s", testing_filename);
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    tool.exec(cmd);--删除testing文件

    --生成结果文件
    tool.file_write(result_filename, STOP_JSON_RESULT);

    --追加tty文件
    tool.file_write(tty_filename, "\nuser aborted\n", "a+");

    tool.exec("sync");

    return "{\"error_code\":0}";
end

--mtu自检
function self_check(param_tab)
    local param_peer = param_tab["peer"];
    if (param_peer == nil) then
        return "{\"error_code\":-1005,\"error_msg\":\"self_check peer param is null!\"}";
    end

    module_debug.lua_debug(module_debug.INFO, "################self_check################");

    local cmd = string.format("/usr/sbin/mtu_disc.elf -c -p %s > /tmp/mtu_disc/mtu_disc.log", param_peer);
    module_debug.lua_debug(module_debug.INFO, "cmd:%s", cmd);
    tool.exec(cmd);
    local result = tool.file_read(SELF_CHECK_JSON_FILE);

    return result;
end

--@module_get
function module_get(param)
    --debug初始化
    debug_init();

    --入参校验
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe");
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil");
        end
        return "{\"error_code\":-1003,\"error_msg\":\"param is unsafe!\"}";
    end

    --json校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "Input data is not json mode.");
        return "{\"error_code\":-1004,\"error_msg\":\"param is not json!\"}";
    end

    --json解析
    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] cjson.decode error");
        return;
    end

    --fixbug 965026 修订intf字段回车注入漏洞
    local param_intf = param_tab["intf"];
    if(param_intf ~= nil) then
        if not (string.match(param_intf, "^wan%d*$") or
                string.match(param_intf, "^wan%d*[_%-]%d+$")) then
          module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] intf param is unsafe");
          return "{\"error_code\":-1003,\"error_msg\":\"intf param is unsafe!\"}";
        end
    end

    --cmd提取
    local param_cmd = param_tab["cmd"];
    if(param_cmd == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] cmd is nil");
        return;
    end
    module_debug.lua_debug(module_debug.INFO, "param_cmd:%s", param_cmd);

    --cmd为开始检测
    if(param_cmd == "start") then
        module_debug.lua_debug(module_debug.INFO, "start");
        return start_mtu_disc(param_tab);
    end

    --cmd为停止检测
    if(param_cmd == "stop") then
        module_debug.lua_debug(module_debug.INFO, "stop");
        return stop_mtu_disc(param_tab);
    end

    --cmd为获取结果
    if(param_cmd == "get_result") then
        module_debug.lua_debug(module_debug.INFO, "get_result");
        return get_result(param_tab);
    end

    --cmd为自检
    if(param_cmd == "self_check") then
        module_debug.lua_debug(module_debug.INFO, "self_check");
        return self_check(param_tab);
    end

end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end
