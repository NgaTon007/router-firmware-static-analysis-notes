#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("sysinfo", package.seeall);

local cjson = require "cjson"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local sysinfo_debug = require "utils.debug"
local libfil = require "utils.file"
local libjsn = require "utils.json"
local SD_DEVICE_JSON = "/tmp/sd_device/sd_device.json"
local SLOT_FILE = "/tmp/sys_info_slot.json"
local VSU_FILE = "/tmp/sys_vsu_switch.json"
local list = {"manufacturer", "oui", "product_class", "model", "serial_num", "hardware_version", "software_version", "ostype", "product_id", "sys_mac", "wan_ip", "autoJoin", "acEnable", "egEnable", "config_version", "forwardMode", "productType", "support_wifi", "master_priority", "max_ap_num", "max_sta_num", "netAccessLicense", "modelFullName", "logo"}

sysinfo_debug.debug_init("/tmp/debug/sysinfo/", "sysinfo.log", 50, sysinfo_debug.ERROR, "1");

--获取json文件,返回table
function get_json_info(jpath)
    local data = {};
    local cjson = require "cjson";
    file = io.open(jpath ,"r");
    if (file == nil) then
        sysinfo_debug.lua_debug(sysinfo_debug.ERROR, "Open file for dir fail.");
    else
        local t = file:read("*all");
        file:close();
        if (string.len(t) ~= 0) then
            data = cjson.decode(t);
        else
            sysinfo_debug.lua_debug(sysinfo_debug.ERROR, "File is empty");
        end
    end
    return data;
end

------------框架调用-------------
function module_get(param)
    local data = {};
    local sd_device_data = get_json_info(SD_DEVICE_JSON);
    if (param ~= nil) then
        sysinfo_debug.lua_debug(sysinfo_debug.DEBUG, "param"..param);
        local param_json = cjson.decode(param)
        local result = tool.split(param_json["func"], " ");
        for i = 1, 100, 1 do
            if (result[i] == nil) then
                break;
            end
            local ret = uci:get_first("sysinfo", "sysinfo", result[i])
            if (result[i] == "productType") then
                ret = uci:get_first("sysinfo", "sysinfo", "dev_type")
            end

            if (ret == nil and next(sd_device_data) ~= nil) then
                ret = sd_device_data[result[i]];
            end

            if (ret == nil ) then
                ret = "";
            end
            data[result[i]] = ret;
        end
    else
        for i, var in ipairs(list) do
            local ret = uci:get_first("sysinfo", "sysinfo", var)
            if ( var == "productType") then
                ret = uci:get_first("sysinfo", "sysinfo", "dev_type")
            end

            if (ret == nil and next(sd_device_data) ~= nil) then
                ret = sd_device_data[var];
            end

            if (ret == nil ) then
                ret = "";
            end
            data[var] = ret;
        end
    end
	if (libfil.file_is_exist(SLOT_FILE) == true) then
		local slot_tab = libjsn.get_json_table_from_file(SLOT_FILE);
        if (slot_tab ~= nil) then
            sysinfo_debug.lua_debug(sysinfo_debug.DEBUG, "slot_tab: "..cjson.encode(slot_tab));
            data["switchSlot"] = slot_tab["switchSlot"];
        end
	end

    if (libfil.file_is_exist(VSU_FILE) == true) then                         
        local vsu_tab = libjsn.get_json_table_from_file(VSU_FILE);                   
        if (vsu_tab ~= nil) then                                                 
            sysinfo_debug.lua_debug(sysinfo_debug.DEBUG, "vsu_tab: "..cjson.encode(vsu_tab));
            data["vsuSwitch"] = vsu_tab["vsuSwitch"];                            
        end                  
    end      
    
    sysinfo_debug.lua_debug(sysinfo_debug.DEBUG, "return: "..cjson.encode(data));
    return cjson.encode(data)
end
