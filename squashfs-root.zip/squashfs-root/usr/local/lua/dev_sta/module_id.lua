#!/usr/bin/lua
module("module_id", package.seeall)

local json = require "dkjson"
local console = require "console"

local module_file = "/tmp/sd_device/dev_modules_info"

function module_get(param)
    if not console.is_file_exist(module_file) then
        return 
    end
    local content = console.read_file(module_file)
    local Table = json.decode(content)
    local mod = json.decode(param).func
    for k, v in pairs(Table.modules) do
        if v.moduleName == mod then
            return v.moduleId
        end
    end
end
