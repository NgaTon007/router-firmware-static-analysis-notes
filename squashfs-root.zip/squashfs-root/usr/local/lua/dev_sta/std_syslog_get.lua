#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("std_syslog_get", package.seeall); -- 第一个参数是本模块的文件名

local libdbg = require ("utils.debug")
local console = require ("console")
local cjson_safe = require ("cjson.safe")
local json_utils = require ("utils.json")

local logdir = "/tmp/std_syslog/"
local logfile = "std_syslog_get.log"

-- 日志初始化
libdbg.debug_init(logdir, logfile, 100, libdbg.DEBUG, libdbg.OPEN)

-- 处理模块的返回值格式
local function ret_val_handle(in_code, in_msg)
    local out_code
    local out_rmsg

    -- 空参防御, 出现空参可能是编码问题, 或者lua运行的系统级故障
    if (in_code == nil or in_code == "") then
        libdbg.lua_debug(libdbg.ERROR, "in_code is nil")
        out_code = "06060010"
    else
        out_code = in_code
    end
    if (in_msg == nil or in_msg == "") then
        libdbg.lua_debug(libdbg.ERROR, "in_msg is nil")
        out_rmsg = "msg loss"
    else
        out_rmsg = in_msg
    end

    if (out_code == "00000000") then
        -- 正确返回
        libdbg.lua_debug(libdbg.INFO, "%s", out_rmsg)
        return console.uf_lua_success()
    else
        -- 错误返回
        libdbg.lua_debug(libdbg.ERROR, "%s", out_rmsg)
        return console.uf_lua_fail({rcode = out_code, rmsg = out_rmsg})
    end
end

local function handler(param)
    local ret
    local param_parse_table
    local call_shell, call_shell_ret

    -- 一.参数校验
    param_parse_table = cjson_safe.decode(param)
    if (param == nil) then
        return ret_val_handle("06060001", "param nil")
    end
    if (param_parse_table == nil) then
        return ret_val_handle("06060002", "json_param parse to table failed")
    end
    if (param_parse_table["user"] == nil or param_parse_table["user"] == "") then
        return ret_val_handle("06060003", "param[user] is empty")
    end
    if (param_parse_table["option"] == nil or param_parse_table["option"] == "") then
        return ret_val_handle("06060004", "param[option] is empty")
    end

    -- 二.调用命令
    call_shell = io.popen("syslog show log.json")
    if (call_shell == nil) then
        return ret_val_handle("06060005", "call shell failed")
    end
    call_shell_ret = call_shell:read("*all")
    if (call_shell_ret == nil or call_shell_ret == "") then
        call_shell:close()
        libdbg.lua_debug(libdbg.ERROR, "call shell ret empty")
        return "{\"total\":\"0\", \"log_list\":[]}"
    end
    call_shell:close()

    -- 三.返回结果
    ret = json_utils.str_is_json(call_shell_ret)
    if (ret ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "call shell ret invalid")
        return "{\"total\":\"0\", \"log_list\":[]}"
    end

    return call_shell_ret
end

-- function module_default_config_get()
    -- dev_sta不需要get_default
-- end

-- std_syslog_get 模块的get处理函数
-- 测试方法: dev_config get -m std_syslog_get '{参数}'
function module_get(param)
    return handler(param)
end

-- std_syslog_get 模块的set处理函数
-- 测试方法: dev_sta set -m std_syslog_get '{参数}'
function module_set(param)
    return handler(param)
end