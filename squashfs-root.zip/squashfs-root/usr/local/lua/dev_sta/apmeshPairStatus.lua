#!/usr/bin/lua
module("apmeshPairStatus", package.seeall);  --必须要有
package.path = "/usr/lib/lua/?.lua;" .. package.path;

--*************************以下为加载库**************************
local console = require 'console'
local dkjson = require "dkjson" 
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"
local sys = require "luci.sys"

--*************************以下为全局变量************************
local PairStatusFile 		= "/tmp/master_pair_status"

local function debug(msg)
    console.debug("apmeshPairStatus", msg)
end

local function get_apmesh_pair_status()
	local data = {
		pair_status = {},
		dev_count 	= "0",
		pair_finish = "0",
		cost_time = "0"
	}

	local apmeshNetworkSetup = sys.exec(string.format("ac_config get -m apmeshNetworkSetup"))
	local cost_time
	if apmeshNetworkSetup ~= nil then
		local dataTable = dkjson.decode(apmeshNetworkSetup)
		if dataTable and dataTable.choicepair_time then
			cost_time = os.time() - tonumber(dataTable.choicepair_time)
		else
			cost_time = 0
		end
	end

	if fs.access(PairStatusFile) then
		local apmesh_pair_status = console.read_file(PairStatusFile) or ""
		data = dkjson.decode(apmesh_pair_status)
		if cost_time then
			data.cost_time = tostring(cost_time)
			--max time 200s
			if cost_time >= 200 then
				data.pair_finish = "1"
			end
		end
		return data
	end

	return data
end

function module_get(param)
	local data = {}
	data = get_apmesh_pair_status()
	data = dkjson.encode(data)
	return data
end	

