#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("port_user", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

require "public_module"
tool = require "dev.tools.common"
local dev_config = require("dev_config");
libdbg = require("utils.debug")
cjson = require("cjson")
cjson_safe = require "cjson.safe"
moduleId = require "dev_module_id"
moduleName = "port_user"
dbgDir = "/tmp/debug/port_user/"
dbgFile = "port_user.log"
port_user_conf_file = "/etc/sd_config/single/port_user.json"
port_base_conf_file = "/etc/sd_config/single/port_base.json"
port_virtual_conf_file = "/etc/sd_config/single/port_virtual.json"

-- ����ģ���ʼ��
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("mqlink_cfgntf"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- ���󷵻�
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = require("dkjson").encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return require("dkjson").encode(res);
end

-- �ļ���ȡ
function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

-- �ļ�д��
function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

-- ����tableԪ��
function conf_add(data, json)
    table.insert (json.data, data)
    return 0
end

-- ɾ��tableԪ��
function conf_del(data, json)
    local length = 0
    if (json.data ~= nil) then
        length = #json.data
    end
    while ( 0 < length ) do    
        if (json.data[length].lpid == data.lpid) then
            if (data.ifalias == nil) then
                data.ifalias = json.data[length].ifalias
            end
            break
        end
        length = length - 1
    end
    table.remove(json.data, length)
    return 0
end

-- �޸�ifalias
function conf_modify(data, json)
    local length = 0
    local flags = 0
    if (json.data ~= nil) then
        length = #json.data
    end
    while (0 < length) do
        if (json.data[length].lpid == data.lpid) then
            json.data[length].ifalias = data.ifalias
            flags = 1
            break
        end
        length = length - 1
    end

    if (flags == 0) then
        table.insert(json.data, data)
    end

    return 0
end

-- port_user config get
function module_get()
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter module_config get*******************");

    local num = 1
    local del_json_num = 1
    -- �ж��Ƿ����port_base.json�����ж��Ƿ����ifalias
    file = io.open(port_base_conf_file, "r")
    if (file == nil) then
        os.execute("dev_config get -m port_base")
        file = io.open(port_base_conf_file, "r")
        if (file == nil) then
            libdbg.lua_debug(libdbg.WARNING, "file is not exist")
            return module_ret("0012", "file is not exist");
        end
        io.close(file)
    else
        io.close(file)
    end

    local file_data = file_read(port_base_conf_file)
    local json = cjson.decode(file_data)
    if ( json["data"] ~= nil) then
        del_json_num = #json.data
    end

    -- ���������ں����������
    num = 1
    local json_str = {}
    json_str["data"] = {}
    while (num <= del_json_num) do
        local get_data = {}
        get_data["lpid"] = json.data[num].lpid
        if (json.data[num].ifalias == nil) then
            json.data[num]["ifalias"] = ""
        end
        get_data["ifalias"] = json.data[num].ifalias
        table.insert(json_str["data"], get_data)
        num = num + 1
    end

    file = io.open(port_virtual_conf_file, "r")
    if (file ~= nil) then
        num = 1
        virtual_json_num = 1
        local virtual_file_data = file_read(port_virtual_conf_file)
        local virtual_json = cjson.decode(virtual_file_data)
        if ( virtual_json["data"] ~= nil) then
            virtual_json_num = #virtual_json.data
        end
        while ( num <= virtual_json_num ) do

            tmp_t = virtual_json.data[num]
            table.insert(json_str["data"], tmp_t)
            num = num + 1
        end
    else
        os.execute("dev_config get -m port_virtual")
        file = io.open(port_virtual_conf_file, "r")
        if (file == nil) then
            libdbg.lua_debug(libdbg.WARNING, "File can not be generated")
            return module_ret("0012", "File can not be generated");
        end
    end
    io.close(file)
    port_user_encode = cjson_safe.encode(json_str)

    return port_user_encode
end

function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter module_config set*******************");

    -- �������
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "port_user set parameter is nil");
        return module_ret("0012", "port_user set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m port_user '%s'", param);

    local data = cjson.decode(param)
    local i = 1
    local max_lpid = 0
    local ifalias_limit_h = 64
    -- ���������ж�
    while ( i <= #data.data ) do
        if (#(data.data[i].ifalias) > ifalias_limit_h) then
            libdbg.lua_debug(libdbg.ERROR, "The ifalias exceeds the length limit");
            return module_ret("0012", "The ifalias exceeds the length limit");
        end
        i = i + 1
    end

    -- �ж��Ƿ����port_base.json�����ж��Ƿ����ifalias
    local num = 1
    local del_json_num = 1
    file = io.open(port_base_conf_file, "r")
    if (file == nil) then
        os.execute("dev_config get -m port_base")
        file = io.open(port_base_conf_file, "r")
        if (file == nil) then
            libdbg.lua_debug(libdbg.WARNING, "file is not exist")
            return module_ret("0012", "file is not exist");
        end
        io.close(file)
    else
        io.close(file)
    end

    local port_base_file_data = file_read(port_base_conf_file)
    local port_base_json = cjson.decode(port_base_file_data)
    if ( port_base_json["data"] ~= nil) then
        del_json_num = #port_base_json.data
    end
    while ( num <= del_json_num ) do
        if (port_base_json.data[num].ifalias == nil) then
            port_base_json.data[num]["ifalias"] = ""
        end
        if (port_base_json.data[num].lpid > max_lpid) then
            max_lpid = port_base_json.data[num].lpid
        end
        num = num + 1
    end

    file = io.open(port_virtual_conf_file, "r")
    if (file == nil) then
        os.execute("dev_config get -m port_virtual")
        file = io.open(port_virtual_conf_file, "r")
        if (file == nil) then
            libdbg.lua_debug(libdbg.WARNING, "File can not be generated")
            return module_ret("0012", "File can not be generated");
        end
    else
        io.close(file)
    end

    -- ����port_base.json��port_virtual.json
    local num = 1
    local del_json_num = 1

    local port_virtual_file_data = file_read(port_virtual_conf_file)
    local port_virtual_json = cjson.decode(port_virtual_file_data)

    if ( data["data"] ~= nil) then
        del_json_num = #data.data
    end
    while ( num <= del_json_num ) do
        if (data.data[num].lpid <= max_lpid) then
            -- �߼��ڣ�����port_base.json
            conf_modify(data.data[num], port_base_json)
            port_base_encode = cjson.encode(port_base_json)
            ret_str = dev_config.fetch("set", "port_base", port_base_encode, nil, nil, nil, "1").data;
            if (ret_str ~= nil) then
                libdbg.lua_debug(libdbg.INFO, "End port_base set, port_base ret_str:%s", ret_str);
            else
                libdbg.lua_debug(libdbg.INFO, "End port_base set, port_base ret_str is nil");
            end
        else
            -- �����,����port_virtual.json
            conf_modify(data.data[num], port_virtual_json)
            file_write(port_virtual_conf_file, cjson.encode(port_virtual_json))
        end
        num = num + 1
    end

    libdbg.lua_debug(libdbg.DEBUG, "module_set end")

    return

end
