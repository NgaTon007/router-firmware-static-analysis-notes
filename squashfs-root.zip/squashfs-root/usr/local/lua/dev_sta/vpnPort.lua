#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("vpnPort",package.seeall)

local cjson = require "cjson"
local tool = require "dev.tools.common"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local sdwan_config = "/etc/sd_config/single/sdwan.json"
local DEBUG_LOG_DIR = "/tmp/log/vpnPort/"
local vpnlist = {}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

local function addvpn(type, interfaces)
    local vpn_entry = {
        type = type,
        data = {}
    }
    for _, interface in ipairs(interfaces) do
        table.insert(vpn_entry.data, interface)
    end
    table.insert(vpnlist, vpn_entry)
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "vpnPort.log", 100, module_debug.INFO, "1");
end
--------------------------------------------------------------------------------------------
--@vpnPort
function module_get(param)
    local vpn_config_json = '{"vpnlist":[]}'
    debug_init()
    local l2tp_client_enable = tonumber(uci:get("xl2tpd", "client", "enable"))
    if l2tp_client_enable == 1 then
        addvpn("L2TP", {{ alias = "L2TP", interface = "l2tp-l2tp" }})
    end
    local pptp_client_enable = tonumber(uci:get("pptpd", "client", "enable"))
    if pptp_client_enable == 1 then
        addvpn("PPTP", {{ alias = "PPTP", interface = "pptp-pptp" }})
    end
    local openvpn_client_enable = tonumber(uci:get("openvpn", "sample_client", "enabled"))
    if openvpn_client_enable == 1 then
        addvpn("OpenVPN", {{ alias = "OpenVPN", interface = "ovpn-ovpn" }})
    end
    if (tool.file_exist(sdwan_config) == true) then
        local sdwan_json_tab = tool.file_read(sdwan_config)
        if (sdwan_json_tab ~= nil) then
            local config_tab = cjson.decode(sdwan_json_tab)
            if (config_tab ~= nil) and config_tab["enable"] == "1" then
                if config_tab["topology"]["type"] == "hubSpoke" and config_tab["topology"]["white"][1] ~= "00:00:00:00:00:00" then --R360 sdwan分部才允许配置策略路由
                    addvpn("SDWAN", {{ alias = "SDWAN", interface = "sdw0" }})
                end
            end
        end
    end
    local get_config_cmd = "dev_sta get -m wireguard '{\"gettype\":\"0\"}'"
    local t1 = io.popen(get_config_cmd)
    local out = t1:read("*all")
    t1:close()
    if out ~= nil and out ~= "" then
        local wireguard_config_tab = cjson.decode(out)
        if (wireguard_config_tab ~= nil) then
            local data = {}
            for _, client in ipairs(wireguard_config_tab.clientlist) do
                if client.enable == "1" then
                    local msg = {}
                    local alias = "WireGuard-"..client.desc
                    msg["alias"] = alias
                    msg["interface"] = client.localIfname
                    table.insert(data, msg)
                end
            end
            if #data > 0 then
                addvpn("WireGuard", data)
            end
        end
    end

    if #vpnlist > 0 then
        local vpn_config_tab = {vpnlist = vpnlist}
        vpn_config_json = cjson.encode(vpn_config_tab)
    end
    return vpn_config_json
end
----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end
