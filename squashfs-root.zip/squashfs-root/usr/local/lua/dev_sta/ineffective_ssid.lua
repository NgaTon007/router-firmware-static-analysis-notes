#!/usr/bin/lua
module("ineffective_ssid", package.seeall)
local console = require "console"
local json = require "dkjson"
local ac_config = require "ac_config"
local dev_config = require "dev_config"
local uci = require "luci.model.uci".cursor()

--dev_sta get -m ineffective_ssid

local function debug(msg)
	console.debug("ineffective_ssid", msg)
end

function module_get()
	local data = {}
	local independ_config = dev_config.fetch("get", "wirelessIndepend")
	local wireless_config
	local forwardmode = uci:get_first("sysinfo", "sysinfo", "forwardMode") or ""
	if forwardmode ~= "ROUTER" then
		debug("Current forwardMode is not ROUTER, do not need to check")
		return json.encode(data)
	end
	if json.decode(independ_config.data).independ and json.decode(independ_config.data).independ == "true" then
		debug("Current is independ")
		wireless_config = dev_config.fetch("get", "wireless")
	else
		debug("Current is not independ")
		wireless_config = ac_config.fetch("get", "wireless")
	end
	if not wireless_config or not wireless_config.data then
		debug("wireless config is not exist")
		return json.encode(data)
	end
	local ssid_list_table = (json.decode(wireless_config.data)).ssidList
	if ssid_list_table then
		-- 默认为旧方案
		result = 0
		if console.is_file_exist("/usr/lib/lua/utils/device_capability.lua") then
			-- 如果文件存在，则检查并更新 result
			result = require("utils.device_capability").check_dev_bridge_vlan_ability()
		end
		-- 根据全局变量 result 的值加载对应的模块
		local network_adapt = (result == 1) and require("libnetifapilua") or require("netmng.network_adapt")
		for k, v in pairs(ssid_list_table) do
			--查询下发的vlan是否可用，若不可用则取消配置
			local config_vlan = {}
			local wlanid_obj = {}
			if v.vlanId then
				if v.vlanId == "1" then
					table.insert(config_vlan, "233")
				else
					table.insert(config_vlan, v.vlanId)
				end
				local vlan_validity = network_adapt.is_vid_legal(config_vlan);
				if vlan_validity == "no" then
					wlanid_obj["wlanid"] = v.wlanId
					wlanid_obj["rcode"] = "02610001"
					wlanid_obj["msg"] = "与WAN口VLAN ID冲突不生效"
					table.insert(data, wlanid_obj)
				end
			end
		end
	end

	return json.encode(data)
end