#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_flush",package.seeall)
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml_flush.lock"
local product = require("product");

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_flush.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 检查用于执行ubus的指令是否有单引号、双引号，nil_flag用于说明此参数是否可以为空,nil_flag:1 可以为空 2：不可为空
local function ubus_cmd_param_check(param, nil_flag)
    if (nil_flag ~= 1) then
        if (param == "") then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is nil")
            return -1
        end
    end
    if ((string.match(param , "\"") ~= nil) or (string.match(param , "'") ~= nil)) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is dangrous")
        return -1
    end
    return 0
end

-- ubus执行，及返回值并判断
local function ubus_cmd_check(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)

    if (string.match(ubus_cmd, "([|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [ubus_cmd] is dangrous")
        return -1
    end

    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))

    if (sh_ret["code"] == nil or sh_ret["code"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return -1
    end

    return 0
end

--@net_tml_flush_set
function net_tml_flush_set(param)
    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:Input data is not json mode.")
        return
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)

    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end
    if (ubus_cmd_param_check(param_tab["from"], 0) < 0) then
        return
    end
    if (ubus_cmd_param_check(param_tab["cb_url"], 1) < 0) then
        return
    end
    -- 改成传入ubus的from只有web和cloud两种
    local cloud = product.get_product("capacity.cloud");
    if (cloud == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [cloud] is nil")
        return
    end
    if (param_tab["from"] == cloud) then
        param_tab["from"] = "cloud"
    elseif (param_tab["from"] ~= "web") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [from] is not cloud and web")
        return
    end
    -- 组建ubus执行命令
    from = "\"from\":\""..param_tab["from"].."\""
    -- 加转义是为了ubus传给进程的时候带上转义 
    cb_url = "\"cb_url\":\""..string.gsub(string.gsub(param_tab["cb_url"], "&", "\\\\&"), "http://", "").."\""
    ubus_cmd = "ubus call nt_mgr.nt_flush set '{"..from..","..cb_url.."}'"

    if (ubus_cmd_check(ubus_cmd) < 0) then
        return
    end

    module_debug.lua_debug(module_debug.INFO, "################################SET END################################")
    return  tool.exec(ubus_cmd)
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"":[]}'
    return default_config
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"There is instance process running!\"}"
    end

    if (string.match(param, "([|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"param is unsafe!\"}"
    end
    config_tab = net_tml_flush_set(param)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] net_tml_flush_set is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\", \"progress\":\"0\", \"msg\":\"set net_tml_flush is fail!\"}"
    end
    os.remove(LOCK_FILE)
    return config_tab
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end