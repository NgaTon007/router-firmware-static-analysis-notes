#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_cluster_query",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local NT_INFO_FILE = "/tmp/nt_info/nt_info.json"
local LOCK_FILE = "/tmp/nt_info/net_tml_cluster_query.lock"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_cluster_query.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)

    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))

    if (sh_ret["code"] == nil or sh_ret["code"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return -1
    end

    return 0
end

-- 自动聚类出来的hostname有可能会携带一些导致UBUS解析失败的字符，要检查
local function hostname_param_check(hostname)
    if((string.match(hostname , "\"") ~= nil) or (string.match(hostname , "'") ~= nil) or (string.match(hostname , ",") ~= nil))  then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [hostname] param is unsafe!")
        return -1
    end
    return 0
end

--@net_tml_cluster_query_get
function net_tml_cluster_query_get(param)
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:[module_get] Input data is not json mode.")
        return
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)

    local param_tab = cjson.decode(param)

    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end

    oui_val = ""
    hostname_val = ""
    type_val = ""

    for k,v in pairs(param_tab["cluster_rule"]) do
        if(v["type"] == nil or v["val"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] type or val is nil!")
            return
        end
        if(v["type"] == "oui") then
            if (oui_val == "") then
                oui_val = v["val"]
            else
                oui_val = oui_val..","..v["val"]
            end        
        elseif (v["type"] == "hostname") then
            if (hostname_val == "") then
                if (hostname_param_check(v["val"]) < 0) then
                    return "hostname error"
                end
                hostname_val = v["val"]
            else
                hostname_val = hostname_val..","..v["val"]
            end
        elseif(v["type"] == "type") then
            if (type_val == "") then
                type_val = v["val"]
            else
                type_val = type_val..","..v["val"]
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR:[module_get] type is invalid.")
            return
        end
    end

    oui_cmd = "\"oui\":\""..oui_val.."\""
    hostname_cmd = "\"hostname\":\""..hostname_val.."\""
    type_cmd = "\"type\":\""..type_val.."\""

    ubus_cmd = "ubus call nt_mgr.cluster_query set '{"..oui_cmd..","..hostname_cmd..","..type_cmd.."}'"

    module_debug.lua_debug(module_debug.ERROR, "ubus_cmd %s", ubus_cmd)
    if (ubus_cmd_exe(ubus_cmd) < 0) then
        return
    end
    config_date = tool.file_read(NT_INFO_FILE)
    os.remove(NT_INFO_FILE)
    module_debug.lua_debug(module_debug.INFO, "################################GET END################################")
    return config_date
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"cluster_rule":[]}'
    return default_config
end

--@module_get
function module_get(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    config_date = net_tml_cluster_query_get(param)
    if (config_date == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] net_tml_cluster_query_get is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"get net_tml_cluster_query is fail!\"}"
    elseif (config_date == "hostname error") then
        os.remove(LOCK_FILE)
        return "{\"code\":\"-2\",\"msg\":\"This hostname is unsafe!\"}"
    end
    os.remove(LOCK_FILE)
    return config_date
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end