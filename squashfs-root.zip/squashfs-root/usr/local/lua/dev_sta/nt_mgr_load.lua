#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_load",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local util = require "luci.util"
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local OUI_FILE = "/tmp/nt_info/nt_idy_oui.txt"
local RULE_FILE = "/tmp/nt_info/nt_rule.db"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_load.lock"

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_load.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)

    if (string.match(ubus_cmd, "([&|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [ubus_cmd] is dangrous")
        return -1
    end

    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))
    module_debug.lua_debug(module_debug.INFO, "errcode %s", sh_ret["errcode"])

    if (sh_ret["errcode"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return -1
    end

    return 0
end
--@nt_mgr_load_set
function nt_mgr_load_set(param)
    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return -1
    end

    local update_type = param_tab["type"]

    if (update_type == "oui") then
        if (tool.file_exist(OUI_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", OUI_FILE)
            return -1
        end
        ubus_cmd = "ubus call nt_mgr.func call \"{\\\"cmd\\\":\\\"nt_idy_update_load OUI\\\"}\""
        if (ubus_cmd_exe(ubus_cmd) < 0) then
            return -1
        end
        --os.execute("tar -zcvf  /tmp/nt_info/nt_oui.tar.gz  -C/tmp/nt_info/ nt_idy_oui.txt");
    elseif (update_type == "rule") then
        if (tool.file_exist(RULE_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: %s is nil", RULE_FILE)
            return -1
        end
        ubus_cmd = "ubus call nt_mgr.func call \"{\\\"cmd\\\":\\\"nt_idy_update_load RULE\\\"}\""
        if (ubus_cmd_exe(ubus_cmd) < 0) then
            return -1
        end
        --os.execute("tar -zcvf  /tmp/nt_info/nt_rule.tar.gz  -C/tmp/nt_info/ nt_rule.db");
    else
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] filename is error")
        return -1
    end
    
    module_debug.lua_debug(module_debug.INFO, "################################SET END################################")
    return 0
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    --config_tab = nt_mgr_load_set(param) 
    if (nt_mgr_load_set(param) < 0) then
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"load failed\"}"
    end

    os.remove(LOCK_FILE)
    tool.sleep(5);
    return "{\"code\":\"0\",\"msg\":\"load success\"}"
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end