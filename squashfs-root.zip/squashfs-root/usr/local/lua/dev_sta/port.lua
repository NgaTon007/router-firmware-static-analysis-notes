#! /usr/bin/lua
module("port",package.seeall)
local cjson = require "cjson";
local tool = require "dev.tools.common"
local net_debug = require "utils.debug"
package.cpath = package.cpath .. ";/usr/lib/libnetifapi.so"
local libnetifapi = require "libnetifapi"
local ports_json_file = "/etc/sd_config/single/port.json"
local ports_map = "/tmp/sd_device/ports_map.json"
local uci = require "luci.model.uci".cursor()
local libc2lua = require("libc2lua")

--�ж��豸ģʽ
function forwardMode_get()
    local mode = uci:get_first("sysinfo", "sysinfo", "forwardMode")
    local product = uci:get_first("sysinfo", "sysinfo", "model")
    if (mode == nil)then
        if (string.find(product, "EG") ~= nil) then
            mode = "ROUTER";
        elseif (string.find(product, "AP") ~= nil) then
            mode = "AP";
        else
            return;
        end
    end
    return mode, product;
end

local error_code = {
    ["SUCCESS"] = '{"rcode":"00000000","message":""}',
    ["UNSINGLE"] = '{"rcode":"01070001","message":"There is instance process running."}',
    ["PARAMETER_ILLEGAL"] = '{"rcode":"01070002","message":"Parameter is illegal."}',
    ["INIT_FAILED"] = '{"rcode":"01070009","message":"Initialization failed"}',
    ["FAILED"] = '{"rcode":"01070010","message":"Set configuration failed"}',
}

local ports_map_json = {};
--��ȡ�豸������Ϣ
local function basic_info_of_device_get()
    local file_data = tool.file_read(ports_map);
    if (file_data == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Read %s failed.", ports_map);
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Ports map: %s", file_data);

    ports_map_json = cjson.decode(file_data);
    if (ports_map_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "%s empty.", ports_map);
        return false;
    end

    return true
end

--debug��ʼ��
net_debug.debug_init("/tmp/port/", "port.log", 100, net_debug.INFO, "1");

function param_legality_check(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --caller����Ϊ��
    if (fn_json["caller"] == nil or fn_json["caller"] == "") then
        net_debug.lua_debug(net_debug.WARNING, "Parameter caller is empty.");
        return false;
    end

    --save����Ϊ��
    if (fn_json["save"] ~= "0" and fn_json["save"] ~= "1") then
        net_debug.lua_debug(net_debug.WARNING, "Parameter save is error.");
        return false;
    end

    return true;
end

--��������Ƿ��Ѿ�����
function check_config_is_same(fn_json)
    if (fn_json == nil or next(fn_json) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input json is empty.");
        return false;
    end

    if (fn_json["port"] == nil or next(fn_json["port"]) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Port of input is empty.");
        return false;
    end

    --��ȡ���ļ��е�����
    if (tool.file_exist(ports_json_file) == false) then
        net_debug.lua_debug(net_debug.INFO, "Configuration does not exist.");
        return false;
    end
    local file_data = tool.file_read(ports_json_file);
    if (tool.json_check(file_data) == false) then
        net_debug.lua_debug(net_debug.ERROR, "File of %s is not in JSON format.", ports_json_file);
        return false;
    end
    local file_json = cjson.decode(file_data);
    if (file_json["port"] == nil or next(file_json["port"]) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "port in %s is not exist.", ports_json_file);
        return false;
    end

    --�Ա�����
    local list = {"portId", "mode", "action", "type", "pvid"}
    for i, obj in ipairs(fn_json["port"]) do
        for j, var in ipairs(list) do
            if (file_json["port"][i] == nil or file_json["port"][i][var] ~= obj[var]) then
                net_debug.lua_debug(net_debug.INFO, "%s is different.", var);
                return false;
            end
        end
    end
    net_debug.lua_debug(net_debug.INFO, "Config is same.", var);

    return true;
end

--alone del ����
function alone_mode_del(fn_json)
    local res;
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Input: %s", cjson.encode(fn_json));

    if (ports_map_json["port"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Ports map json is empty.");
        return false;
    end

    for i, var in ipairs(ports_map_json["port"]) do
        if (var["intf_port"] == fn_json["portId"]) then
            port_info = var
        end
    end
    if (next(port_info) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Ports info is empty.");
        return false;
    end
    if (port_info["wan_name"] == nil or string.upper(port_info["wan_name"]) ~= "WAN" ) then
        net_debug.lua_debug(net_debug.ERROR, "Port is not wan.");
        return false;
    end
    --���ò���
    local forward_mode, product = forwardMode_get();
    if (forward_mode ~= "AP") then
        net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));
        return true;
    end
    if (libnetifapi.port_del(tonumber(fn_json["pvid"]), tonumber(port_info["intf_port"]) - 1, "port") ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "netifapi_port_del:%s fail", fn_json["pvid"]);
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));

    return true;
end

--alone add ����
function alone_mode_add(fn_json)
    local res;

    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    net_debug.lua_debug(net_debug.INFO, "Input: %s", cjson.encode(fn_json));
    if (ports_map_json["port"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Ports map json is empty.");
        return false;
    end
    for i, var in ipairs(ports_map_json["port"]) do
        if (var["intf_port"] == fn_json["portId"]) then
           port_info = var
        end
    end
    if (next(port_info) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Ports info is empty.");
        return false;
    end
    if (port_info["wan_name"] == nil or string.upper(port_info["wan_name"]) ~= "WAN" ) then
        net_debug.lua_debug(net_debug.ERROR, "Port is not wan.");
        return false;
    end
    --���ò���
    local forward_mode, product = forwardMode_get();
    if (forward_mode ~= "AP") then
        net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));
        return true;
    end
    if (libnetifapi.port_add(tonumber(fn_json["pvid"]), tonumber(port_info["intf_port"]) - 1, "port") ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "netifapi_port_add:%s %s, fail", fn_json["pvid"], port_info["intf_port"]);
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));

    return true;
end

--alone set ����
function alone_mode_set(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    net_debug.lua_debug(net_debug.INFO, "-------------alone-------------");
    if (fn_json["action"] == "add") then
        if (alone_mode_add(fn_json) == false) then
            net_debug.lua_debug(net_debug.ERROR, "Alone mode set failed");
            return false;
        end
    elseif (fn_json["action"] == "del") then
        if (alone_mode_del(fn_json) == false) then
            net_debug.lua_debug(net_debug.ERROR, "Alone mode set failed");
            return false;
        end
    end
    net_debug.lua_debug(net_debug.INFO, "Alone mode set success.");

    return true;
end

--port���ݻ�ȡ
local function port_info_get(fn_json)
    local ret = {};
    local file_json = {};
    local portInfo = {};
    local pvid = 0;

    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.INFO, "Input is empty.");
        return nil;
    end

    local portId = fn_json["portId"] ;
    if (portId == nil) then
        net_debug.lua_debug(net_debug.INFO, "Input portId is empty.");
        return nil;
    end
    if (ports_map_json["port"] == nil or next(ports_map_json["port"]) == nil) then
        net_debug.lua_debug(net_debug.INFO, "Port map json is empty.");
        return nil;
    end
    net_debug.lua_debug(net_debug.INFO, "portId: %s", portId);
    for i, var in ipairs(ports_map_json["port"]) do
        if (var["intf_port"] == portId) then
            portInfo = var;
        end
    end
    if (fn_json["key"] == nil) then
        net_debug.lua_debug(net_debug.INFO, "Input key is empty.");
        return nil;
    end
    --��ȡ���ļ��е�����
    if (tool.file_exist(ports_json_file) == true) then
        local file_data = tool.file_read(ports_json_file);
        if (tool.json_check(file_data) == true) then
            file_json = cjson.decode(file_data);
            if (file_json["port"] == nil or next(file_json["port"]) == nil) then
                net_debug.lua_debug(net_debug.ERROR, "port in %s is not exist.", ports_json_file);
                return nil;
            end
        end
    end
    if (file_json["port"] == nil) then
        net_debug.lua_debug(net_debug.WARNING, "port in is not exist.");
        return nil;
    end
    for i, obj in ipairs(file_json["port"]) do
        if (file_json["port"][i] == nil) then
            net_debug.lua_debug(net_debug.WARNING, "port in is not exist.");
            return nil;
        end
        if (file_json["port"][i]["portId"] == portId) then
            if (file_json["port"][i]["action"] ~= "add") then
                break;
            end
            pvid = file_json["port"][i]["pvid"];
            break;
        end
    end
    ret[portId] = {};
    if (pvid == 0) then
        return  nil;
    end
    portInfo["interface"] = portInfo["ifname"];
    if (portInfo["switch_enable"] == "1") then
        portInfo["interface"] = table.concat({portInfo["ifname"], ".", tostring(pvid)});
    end
    for i, var in ipairs(fn_json["key"]) do
        ret[portId][var] = portInfo[var];
    end
    net_debug.lua_debug(net_debug.INFO, "Get port info success. return: %s", cjson.encode(ret));

    return ret;
end

--port��������
function port_info_set(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    if (fn_json["port"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input port is empty.");
        return false;
    end

    local res = basic_info_of_device_get()
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Get basic info of device failed.");
        return false;
    end

    for i, var in ipairs(fn_json["port"]) do
        if (var["mode"] == "alone") then
            if (alone_mode_set(var) == false) then
                net_debug.lua_debug(net_debug.ERROR, "Alone mode set failed");
                return false;
            end
        end
    end

    return true;
end

--------------------------------module--------------------------------
function module_set(param)
    --�����пգ�
    if (param == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    net_debug.lua_debug(net_debug.INFO, "****************START****************\nInput: -->%s<--", param);

    --json��ʽ���
    if (tool.json_check(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Input is not in JSON format.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    -- ©��ע��У��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "Input is unsafe.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    local input_json = cjson.decode(param)
    --У��������Ƿ��Ѿ����ڣ�
    if (check_config_is_same(input_json) == true) then
        net_debug.lua_debug(net_debug.INFO, "*****************END*****************");
        return error_code["SUCCESS"];
    end
    --�����Ϸ���У��
    local res = param_legality_check(input_json)
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Parameter is illegal.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    --���ö˿�
    local res = port_info_set(input_json)
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Set port failed.");
        return error_code["FAILED"];
    end
    tool.file_write(ports_json_file, param, "w");
    net_debug.lua_debug(net_debug.INFO, "*****************END*****************");

    return error_code["SUCCESS"];
end

--���û�ȡ
function module_get(param)
    local port_info = nil;

    if (param == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    net_debug.lua_debug(net_debug.INFO, "****************START****************");

    net_debug.lua_debug(net_debug.INFO, "Input:%s.", param);
    --json��ʽ���
    if (tool.json_check(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Input is not in JSON format.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    -- ©��ע��У��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "Input is unsafe.");
        return error_code["PARAMETER_ILLEGAL"];
    end
    local input_json = cjson.decode(param)
    --�˿����û�ȡ
    if (input_json["port"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input port is empty.");
        return error_code["FAILED"];
    end
    --�豸������Ϣ��ȡ
    local res = basic_info_of_device_get()
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Get basic info of device failed.");
        return error_code["FAILED"];
    end
    --����ģʽʵ�ֲ�ͬ����
    for i, var in ipairs(input_json["port"]) do
        port_info = port_info_get(var)
        if (port_info == nil) then
            net_debug.lua_debug(net_debug.ERROR, "Get port info failed.");
            return error_code["FAILED"];
        end
    end
    if (port_info == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Get port info failed.");
        return error_code["FAILED"];
    end
    net_debug.lua_debug(net_debug.INFO, "*****************END*****************");

    return(cjson.encode(port_info));
end
