#! /usr/bin/lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
local cjson = require "cjson"
module("networkConnect", package.seeall);
local uci = require "luci.model.uci".cursor()
local libdbg  = require("utils.debug");
local lib_param = require("utils.param_check");

-- 1181549, ����ܳ�ʱ��networkConnect����coredumpʱ, ����ֵΪnil, ���������networkConnect���쳣������
-- ��ʱ�Ͳ���coredump������ÿ��̽�ⶼ�ﵽ�˳�ʱʱ�䣬���������¿�����Ϊ����δ����
local error_message = "{\"rcode\":\"01010004\",\"connected\":\"false\",\"message\":\"������ͨ|���ؿ�������֤����|DNS�����쳣\"}"
local error_message2 = "{\"rcode\":\"01010023\",\"connected\":\"false\",\"message\":\"ERROR: param error\"}"
--@module_get �������еĽ����Ϣ
libdbg.debug_init("/tmp/netconnect/", "networkConnect.lua.log", 500, libdbg.DEBUG, libdbg.OPEN);
function module_get(param)
    local sh_ret_handle;
    local data;

    if (param ~= nil) then
        data = cjson.decode(param);
        if (data["get_type"] ~= nil and data["get_type"] == "config") then
            local local_effect_type = uci.get("networkConnect",'check_period','effective_type') or "single";
            return "{\"rcode\":\"00000000\",\"msg\":\"success\",\"effective_type\":\""..local_effect_type.."\"}";
        end

        if (data["ifname"] ~= nil and data["ifname"] == "quick") then
                if data["valid_time"] ~= nil and type(data["valid_time"]) == "number" then
                    local valie_time = data["valid_time"];
                    if valie_time < 1 or valie_time > 30 then
                        return error_message2;
                    end
                    sh_ret_handle = io.popen("/usr/sbin/netconnect -q -t " .. tostring(valie_time) .. " 2>/dev/null");
                else
                    sh_ret_handle = io.popen("/usr/sbin/netconnect -q -t 5 2>/dev/null");
                end
        else 
            return error_message2;
        end
    else 
        sh_ret_handle = io.popen("/usr/sbin/netconnect 2>/dev/null");
    end
    if (sh_ret_handle == nil) then
        return error_message;
    end
    local sh_ret = sh_ret_handle:read("*all");
    sh_ret_handle:close();
    if (sh_ret ~= nil) then
        return sh_ret;
    end
    return error_message;
end

local function clear_existing_lists()
    local lists_to_clear = {"url_list", "ipv4_list", "ipv6_list"}
    for _, list in ipairs(lists_to_clear) do
        uci:delete("networkConnect", list)
    end

    for _, list in ipairs(lists_to_clear) do
        uci:set("networkConnect", list, list)
    end
    uci:commit("networkConnect");
end

local function parse_and_save_lists(json_path)
    local cmd;
    local ret;
    local type_map;
    local file = io.open(json_path, "r")
    if not file then 
        return false
    end
    local content = file:read("*a")
    file:close()
    
    local data = cjson.decode(content)
    if not data or type(data) ~= "table" then
        return false
    end

    type_map = {
        ipv4 = "ipv4_list",
        ipv6 = "ipv6_list",
        url = "url_list"
    }
    clear_existing_lists();
    if data.param and type(data.param) == "table" then
        for _, item in ipairs(data.param) do
            target_list = type_map[item.datatype]
            if target_list and item.value then
                cmd = string.format('uci -q add_list networkConnect.%s.%s="%s"', target_list, item.datatype, item.value);
                libdbg.lua_debug(libdbg.INFO, cmd);
                ret = os.execute(cmd);
            end
        end
    end
    -- д�� UCI
    local enable = data.enable
    if enable ~= nil then
        enable = tostring(enable)
        cmd = string.format('uci set networkConnect.check_period.enable="%s"; uci commit networkConnect', enable)
        ret = os.execute(cmd)
        if ret ~= 0 then
           return false
        end
    end
    return true
end

function module_set(param)
    if param == nil then
        return error_message2;
    end
    libdbg.lua_debug(libdbg.INFO, "module_set");
    if lib_param.param_safety_check(param) ~= true then
        return error_message2;
    end
    libdbg.lua_debug(libdbg.INFO, "module_set2");
   
    libdbg.lua_debug(libdbg.INFO,param);
    local data = cjson.decode(param);
    local param_effect_type = data["effective_type"];
    if param_effect_type ~= nil then
        param_effect_type = tostring(param_effect_type);
    end
    libdbg.lua_debug(libdbg.INFO,"module_set param_effect_type:[%s]", param_effect_type);
    local local_effect_type = uci.get("networkConnect",'check_period','effective_type') or "single";
    libdbg.lua_debug(libdbg.INFO,"module_set local_effect_type:[%s]", local_effect_type);
    if param_effect_type ~= nil then
        if param_effect_type ~= "single" and param_effect_type ~= "global" then
            return error_message2;
        end
    else
        libdbg.lua_debug(libdbg.INFO,"module_set param_effect_type is nil");
        return error_message2;
    end
    if param_effect_type ~= nil and param_effect_type ~= local_effect_type then
        uci.set("networkConnect","check_period","effective_type", param_effect_type);
        uci.commit("networkConnect");
        if param_effect_type == "single" then
            parse_and_save_lists("/etc/sd_config/single/networkConnect_single.json")
        elseif param_effect_type == "global" then
            local dev_type = uci:get_first("sysinfo", "sysinfo", "dev_type") or ""
            if dev_type == "est" then
                parse_and_save_lists("/etc/sd_config/single/networkConnect_global.json")
            else
                parse_and_save_lists("/etc/sd_config/global/link/networkConnect_global.json")
            end
        end
    end
    local result = {};
    result["rcode"] = "00000000";
    result["msg"] = "success";
    libdbg.lua_debug(libdbg.INFO,"module_set return success");
    local ret_json = cjson.encode(result);
    libdbg.lua_debug(libdbg.INFO,"module_set return json:[%s]", ret_json);
    return ret_json;
end
