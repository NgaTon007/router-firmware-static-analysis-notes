#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("sw_g_dot1x_sess", package.seeall);

local dkjson = require("dkjson");
local ubus = require("ubus");
local module_debug = require("utils.debug");
local ubus_module = "msw_ncdb_proxy"

----------初始化debug---------------
module_debug.debug_init("/tmp/", "sw_g_dot1x_sess.log", 50, module_debug.DEBUG, "1");

----------枚举初始化---------
function CreatEnumTable(tb, index)
    local enumtb = {}
    local enumindex = index or 0
    for i, v in ipairs(tb) do
        enumtb[v] = enumindex + i
    end
    return enumtb
end

----------通用错误码-----------------
local g_err_code = {
    "ERR_PARAM",
    "ERR_FILE_WRITE",
    "ERR_FILE_NOT_EXIST",
    "ERR_UBUS_CONNECT",
    "ERR_MALLOC_FAILED",
    "ERR_PARAM_TRANSFORM"
}
g_err_code = CreatEnumTable(g_err_code, 200)

--ret(uint)表示是否返回结果给web,0表示不返回，非0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return dkjson.encode(result)
end

--------------调用ubus call-------------------------
function ubus_call(method, data)
    local result = {}
    local conn = ubus.connect()

    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ubus.connect failed")
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
        return result
    end

    result = conn:call(ubus_module, method, data)

    if (result == nil) then
        result = {}
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
    end

    return result
end

------------框架调用-------------
function module_get(param)
    local data = dkjson.decode(param)
    module_debug.lua_debug(module_debug.DEBUG, "param: %s", param)

    if (data["index"] == nil or data["index"] == 0 or data["size"] == nil) then
        module_debug.lua_debug(module_debug.DEBUG, "param index or size is illegal!")
        return output(1, g_err_code["ERR_PARAM"], "ERROR: param index or size is illegal!")
    end

    local result

    result = ubus_call("sw_g_dot1x_sess_get", data)

    return dkjson.encode(result)
end

function module_del(param)
    local data = dkjson.decode(param)
    module_debug.lua_debug(module_debug.DEBUG, "param: %s", param)

    local result

    result = ubus_call("sw_g_dot1x_sess_del", data)

    return dkjson.encode(result)
end