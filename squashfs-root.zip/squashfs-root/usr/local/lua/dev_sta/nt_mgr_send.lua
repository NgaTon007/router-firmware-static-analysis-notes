#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_send", package.seeall)
local lfs = require "lfs"
local ubus = require "ubus"
local cjson = require "cjson"
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_send.lock"
local UBUS_WAIT_TIME = 3

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_send.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(object, method, param, conn_obj)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd ubus call %s %s '%s'", object, method, cjson.encode(param))

    local conn = conn_obj
    local need_close = false
    if not conn then
        conn = ubus.connect(nil, UBUS_WAIT_TIME)
        need_close = true
    end
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: connect to ubus fail!")
        return nil
    end

    local ret = conn:call(object, method, param or {})
    if need_close and conn then
        conn:close()
    end

    return ret
end

local function is_null(val)
    return val == nil or val == ""
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if single_instance_check(LOCK_FILE) == false then
        return "{\"err\":{\"rcode\":\"00500001\",\"rmsg\":\"There is instance process running!\"},\"code\":\"1\"}"
    end

    if libc2lua.lua_param_safety_check(param) ~= true then
        module_debug.lua_debug(module_debug.ERROR, "[module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "[module_set] param is not nil")
        end
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500002\",\"rmsg\":\"param is unsafe!\"},\"code\":\"1\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################")

    local param_tab = cjson.decode(param)
    if param_tab == nil then
        module_debug.lua_debug(module_debug.ERROR, "[module_set] param_tab is nil")
        return "{\"err\":{\"rcode\":\"00500003\",\"rmsg\":\"param decode fail!\"},\"code\":\"1\"}"
    end

    local protocol = param_tab["protocol"]
    if is_null(protocol) == true then
        module_debug.lua_debug(module_debug.ERROR, "[module_set] protocol is nil")
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500004\",\"rmsg\":\"protocol is nil!\"},\"code\":\"1\"}"
    end
    local valid_protocols = {SADP=true, ONVIF=true, MDNS=true, SSDP=true}
    if not valid_protocols[protocol] then
        module_debug.lua_debug(module_debug.ERROR, "[module_set] protocol is invalid")
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500005\",\"rmsg\":\"protocol is invalid!\"},\"code\":\"1\"}"
    end

    local vlan = param_tab["vlan"]
    local cmd_value
    if vlan == "all" then
        cmd_value = string.format("detect %s all", protocol)
    elseif not is_null(vlan) and type(vlan) == "string" and vlan:match("^%d+$") then
        cmd_value = string.format("detect %s br-lan_%s", protocol, vlan)
    else
        cmd_value = string.format("detect %s br-lan", protocol)
    end
    local param_ubus = { cmd = cmd_value }
    local ret = ubus_cmd_exe("nt_mgr.func", "call", param_ubus, nil)
    if ret == nil then
        module_debug.lua_debug(module_debug.ERROR, "[module_set] ubus call nt_mgr send fail")
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500006\",\"rmsg\":\"ubus call nt_mgr send fail!\"},\"code\":\"1\"}"
    end
    module_debug.lua_debug(module_debug.INFO, "###############################SET END###############################")

    os.remove(LOCK_FILE)
    return "{\"rcode\":\"00000000\",\"rmsg\": \"[set] success\"}"
end