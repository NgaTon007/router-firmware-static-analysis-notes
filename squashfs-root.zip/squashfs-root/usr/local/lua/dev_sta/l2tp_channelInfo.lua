#! /usr/bin/lua
module("l2tp_channelInfo",package.seeall)

local lfs = require "lfs"
local cjson = require "cjson";
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local uci = require "luci.model.uci".cursor()
local DEBUG_LOG_DIR = "/tmp/channelInfo/"
local SERVER_DIR = "/tmp/l2tp/server/"
local UPDOWN_DIR = "/tmp/l2tp/updown/"
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/l2tp_server_updown.lua"
local CLIENT_INFO_FILE = "/tmp/l2tp/l2tp/input_save"
local L2TP_XL2TPD_LOG_FILE = "/tmp/log/snosvpn/l2tp/l2tp_xl2tpd_process_log"
local L2TP_PPPD_CLIENT_LOG = "/tmp/log/snosvpn/l2tp/l2tp_pppd_client_log"
local CLIENT_JSON_FILE = "/etc/sd_config/single/l2tp_client.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(DEBUG_LOG_DIR, "l2tp_channelInfo.log", 500, l2tp.INFO, "1");
end

local function channelInfo_get(file)
    local result = {};
    local file_data = tool.file_read(file)
    if (file_data == nil or tool.json_check(file_data) == false) then
        return result;
    end
    result = cjson.decode(file_data);
    return result;
end

local function stop_client_connect(tunnelname)
    local kill_cmd = "kill -TERM"
    local rm_file_cmd = "rm -rf"

    local pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
    if (tool.file_exist(pid_file) == true) then
        local pid = tool.file_read(pid_file);
        kill_cmd = table.concat({kill_cmd, " ", pid});
        rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
    end

    local file = table.concat({tunnelname, "_client_save"});
    local save_file = table.concat({SERVER_DIR, file});
    local down_file = table.concat({UPDOWN_DIR, file});
    l2tp.lua_debug(l2tp.INFO, "save_file: %s", save_file);
    l2tp.lua_debug(l2tp.INFO, "down_file: %s", down_file);
    if (tool.file_exist(save_file) == true) then
        os.rename(save_file, down_file);
        l2tp.lua_debug(l2tp.INFO, "%s", SERVER_UPDOWN_CMD);
        os.execute(SERVER_UPDOWN_CMD);
    end

    l2tp.lua_debug(l2tp.INFO, "%s", kill_cmd);
    l2tp.lua_debug(l2tp.INFO, "%s", rm_file_cmd);
    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
end

function lua_string_split(str, split_char)
    local sub_str_tab = {}
    while (true) do
        local pos = string.find(str, split_char)
        if (not pos) then
            sub_str_tab[#sub_str_tab+1] = str
            break
        end
        local sub_str = string.sub(str, 1, pos - 1)
        sub_str_tab[#sub_str_tab + 1] = sub_str
        str = string.sub(str, pos + 1, #str)
    end
    return sub_str_tab
end

------------------------------------dev_module---------------------------------
function module_default_config_get()
    local default_config = '{"serverNum": 0,"client": {},"clientNum": 0,"server": {}}'
    return default_config
end

function module_get()
    local data = {};
    local num = 0
    local sub_data = {};
    local code_msg = {}
    local code = 6
    local jsonStr = '{"count":0,"list":[]}'

    debug_init();
    for file in lfs.dir(DEBUG_LOG_DIR) do
        if (string.find(file, "l2tp_server_") ~= nil) then
            local ret = channelInfo_get(table.concat({DEBUG_LOG_DIR, file}))
            if (next(ret) ~= nil) then
                num = num + 1;
                sub_data[num] = ret;
                sub_data[num]["type"] = "server";
                sub_data[num]["code"] = 0
            end
        elseif (string.find(file, "l2tp_client_") ~= nil) then
            local res = tool.exec("ip addr show l2tp-l2tp 2>/dev/null|wc -l")
            if (res == nil) then
                break;
            else
                if (tool.trim(res) ~= "4") then
                    break;
                end
            end
            local ret = channelInfo_get(table.concat({DEBUG_LOG_DIR, file}))
            if (next(ret) ~= nil) then
                num = num + 1;
                sub_data[num] = ret;
                sub_data[num]["type"] = "client";
                sub_data[num]["code"] = 0
            end
        end
    end

    if (sub_data[num] ~= nil) then
        data["list"] = sub_data
        data["count"] = num;
        jsonStr = cjson.encode(data);
    else
        local client_enabled = tonumber(uci:get("xl2tpd", "client", "enable"))
        if (client_enabled == 1) then
            local xl2tpd_info = {}
            local pppd_info = {}
            local peer_gateway_flag = false
            local tunnel_auth_flag = false
            local account_chap_flag = false
            local static_ip_flag = false
            local self_gateway_flag = false
            local dns_analysis_flag = false
            local con_timeout_flag = false
            local client_link_info = {}
            if (tool.file_exist(L2TP_XL2TPD_LOG_FILE) == true) then
                local xl2tpd_log_file = io.popen("cat /tmp/log/snosvpn/l2tp/l2tp_xl2tpd_process_log |tail -50")
                if io.type(xl2tpd_log_file) ~= nil then
                    local a = xl2tpd_log_file:read("*all")
                    xl2tpd_info = lua_string_split(a, "\n") 
                    xl2tpd_log_file:close()
                end
                if (tool.file_exist(CLIENT_INFO_FILE) == true) then
                    local link_file_data = tool.file_read(CLIENT_INFO_FILE)
                    if (link_file_data == nil or tool.json_check(link_file_data) == false) then
                        return(jsonStr)
                    end
                    client_link_info = cjson.decode(link_file_data)
                    local match_msg_1 = "Connection 0 closed to "..client_link_info["lns"]
                    local match_msg_2 = "Invalid challenge authentication"
                    local match_msg_3 = "write_packet: tty is not open yet"
                    local match_msg_4 = nil
                    if (tool.file_exist(CLIENT_JSON_FILE) == true) then
                        client_cfg_file = tool.file_read(CLIENT_JSON_FILE)
                        if (client_cfg_file ~= nil and tool.json_check(client_cfg_file) == true) then
                            client_cfg_data = cjson.decode(client_cfg_file)
                            if client_cfg_data ~= nil and client_cfg_data["list"] ~= nil then
                                if client_cfg_data["list"][1]["lns"] ~= nil then
                                    match_msg_4 = "Host name lookup failed for "..client_cfg_data["list"][1]["lns"]
                                    l2tp.lua_debug(l2tp.INFO, "match_msg_4:[%s]", match_msg_4);
                                end
                            end
                        end
                    end
                    for i=#xl2tpd_info,1,-1  do
                        if xl2tpd_info[i] ~= "" then
                            if (string.find(xl2tpd_info[i], match_msg_2)) then
                                tunnel_auth_flag = true
                            elseif (string.find(xl2tpd_info[i], match_msg_1)) then                 
                                peer_gateway_flag = true
                            elseif (string.find(xl2tpd_info[i], match_msg_3)) then
                                self_gateway_flag = true
                            elseif (match_msg_4 ~= nil) then
                                if (string.find(xl2tpd_info[i], match_msg_4)) then
                                    dns_analysis_flag = true
                                end
                            end
                        end
                    end
                end
            end

            if (tool.file_exist(L2TP_PPPD_CLIENT_LOG) == true) then
                local pppd_log_file = io.popen("cat /tmp/log/snosvpn/l2tp/l2tp_pppd_client_log | tail -50")
                if io.type(pppd_log_file) ~= nil then
                    local b = pppd_log_file:read("*all")
                    pppd_info = lua_string_split(b, "\n") 
                    pppd_log_file:close()
                end
                for i=#pppd_info,1,-1  do
                    if pppd_info[i] ~= "" then
                        if (string.find(pppd_info[i], "authentication failed")) then
                            account_chap_flag = true
                        elseif (string.find(pppd_info[i], "Peer refused to agree to our IP address")) then                 
                            static_ip_flag = true
                        elseif (string.find(pppd_info[i], "Connection terminated")) then
                            con_timeout_flag = true
                        end
                    end
                end
            end
            if peer_gateway_flag then
                code = 1
            elseif tunnel_auth_flag then
                code = 2
            elseif account_chap_flag then
                code = 3
            elseif static_ip_flag then
                code = 4
            elseif self_gateway_flag then
                code = 7
            elseif dns_analysis_flag then
                code = 6
            else
                code = 7
            end
            if (#xl2tpd_info > 20 or #pppd_info > 5) then
                code_msg["code"] = code
                code_msg["username"] = client_link_info["username"]
                code_msg["type"] = "client"
                code_msg["tunnelname"] = client_link_info["tunnelname"]
                code_msg["localIp"] = "-"
                code_msg["remoteIp"] = "-"
                code_msg["lns"] = client_link_info["lns"]
                code_msg["DNS"] = "-"
                table.insert(sub_data, code_msg)
                data["list"] = sub_data
                data["count"] = 0
                jsonStr = cjson.encode(data)
            end
        end
    end
    l2tp.lua_debug(l2tp.INFO,  "return: %s", jsonStr);
    return(jsonStr)
end

function module_del(input_data)
    debug_init();
    l2tp.lua_debug(l2tp.INFO, "################################DEL################################");
    l2tp.lua_debug(l2tp.INFO, "Input: %s", input_data);

    --参数获取
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.ERROR, "Input data is not json mode.");
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "Input: %s", input_data);
    input_json = cjson.decode(input_data);
    if (next(input_json.list) == nil) then
        l2tp.lua_debug(l2tp.ERROR, "Tunnelname is empty.");
        return;
    end

    --遍历要删除的用户
    for key,val in pairs(input_json.list) do
        local tunnelname = val.tunnelname;
        if string.match(tunnelname, "^[%w-_]+$") == nil then --匹配只包含数字、字母、"_"、"-"字符串
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
            if (input_data ~= nil) then
                l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", tunnelname)
            end
            return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
        end
        stop_client_connect(tunnelname)
    end
end
