#!/usr/bin/lua
module("apmeshDeviceSelect", package.seeall);  --必须要有
package.path = "/usr/lib/lua/?.lua;" .. package.path;

--*************************以下为加载库**************************
local console = require 'console'
local dkjson = require "dkjson" 
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"
local sys = require "luci.sys"

--*************************以下为全局变量************************
local ApDiscListFile 		= "/tmp/master_apdisc_report"
local ApMeshNeighborFile 	= "/tmp/apmesh_neighbor"
local apcli_info 			= "/tmp/apmgr/apcli_info"

local function debug(msg)
    console.debug("apmeshDeviceSelect", msg)
end

local crypto = require "crypto"

local function get_apmesh_neighbor()
	local data 				= {
		apmesh_neighbor 	= {},
		count	   			= "0"
	}
	local apmesh_neighbor 		= {}
	local apmesh_neighbor_new 	= {}
	local neighbor 			= {
		deviceType 	= "",
		product		= "",
		devSN		= "ABC",
		devBssid	= "", 
		networkId	= "networkId-123",
		networkName = "",
		web_passwd = "11111111",
		foundAPInfo = {
			devSN   = "ZZZ",
			rssi 	= "-99"
		}
	}

	--local i = 0
	if fs.access(ApDiscListFile) then
		local bcnie = console.read_file(ApDiscListFile) or ""
		local apdisclist = {}
		apdisclist = dkjson.decode(bcnie)
		for key, val in pairs(apdisclist) do
			for key2, val2 in pairs(val) do
				if #val2.apdisc_report ~= 0 then
					for key3, val3 in pairs(val2.apdisc_report) do
						local foundAPInfo = {
							devSN 	= "",
							rssi 	= ""
						}
						val3.web_passwd				= crypto.digest("md5", tostring(val3.web_passwd or ""))
						neighbor.product			= val3.dev_type
						neighbor.deviceType			= val3.model
						neighbor.devSN				= val3.serial_num
						neighbor.devBssid			= val3.bssid
						--neighbor.rssi 			= val3.rssi
						neighbor.networkId 			= val3.network_id
						neighbor.networkName		= val3.network_name
						--i = i + 1
						neighbor.web_passwd    	= val3.web_passwd
						neighbor.v1CompatWarn 	= val3.v1_compat_alarm
						foundAPInfo.devSN			= val2.sn 
						foundAPInfo.rssi 			= val3.rssi
						neighbor.foundAPInfo 		= foundAPInfo
						--neighbor.foundAPInfo.devSN	= val.sn
						--neighbor.foundAPInfo.rssi	= val3.rssi
						apmesh_neighbor[#apmesh_neighbor + 1] = neighbor
						neighbor 				= {}
					end
				end
			end
		end
		
		-- 去重处理
		for key, val in pairs(apmesh_neighbor) do
			local neighbor_tmp = val
			local find 		   = "0"
			if #apmesh_neighbor_new == 0 then
				apmesh_neighbor_new[#apmesh_neighbor_new + 1] = neighbor_tmp
			else 
				for key2, val2 in pairs(apmesh_neighbor_new) do
					if val2.devBssid == neighbor_tmp.devBssid then
						find = "1"
						if tonumber(neighbor_tmp.foundAPInfo.rssi) > tonumber(val2.foundAPInfo.rssi) then
							val2.foundAPInfo.devSN 	= neighbor_tmp.foundAPInfo.devSN
							val2.foundAPInfo.rssi 	= neighbor_tmp.foundAPInfo.rssi
						end
					end
				end
				if find and find == "0" then
					apmesh_neighbor_new[#apmesh_neighbor_new + 1] = neighbor_tmp
				end
			end
		end
		data.apmesh_neighbor 	= apmesh_neighbor_new
		data.count				= #apmesh_neighbor_new
		-- 生成apmesh neighbor临时文件（含MD5校验密码）
		local f = io.open("/tmp/apmesh_neighbor","w+")
		f:write(dkjson.encode(data))
		f:flush()
		f:close()
		-- 去掉web_passwd字段
		for key, val in pairs(apmesh_neighbor_new) do
			val.web_passwd = nil
		end
	else
		debug("get_apmesh_neighbor: can't found ".. ApDiscListFile)
	end
	data.apmesh_neighbor 	= apmesh_neighbor_new
	data.count				= #apmesh_neighbor_new
	debug("data: "..dkjson.encode(data))
	return data
end

local function check_web_passwd(autojoin, bssid, password)
	local data 		= {
		status 		= "ok",
		pass_list 	= {}, 
		fail_list 	= {}
	}
	local flag 		= 1
	local devBssid  = ""
	local pass_list = {}
	local fail_list = {}

	for i, v in ipairs(bssid) do
		if not string.match(v, "^%x+:%x+:%x+:%x+:%x+:%x+$") then
			debug("Invalid BSSID format: "..v)
			data.status = "no"
			return data
		end
	end

	if fs.access(ApMeshNeighborFile) then
		local apmesh_neighbor = console.read_file(ApMeshNeighborFile) or ""
		debug("apmesh_neighbor: " .. apmesh_neighbor)
		local apmesh_neighbor = dkjson.decode(apmesh_neighbor)
		local neighbor_tab = apmesh_neighbor.apmesh_neighbor
		for key1, val1 in pairs(bssid) do
			for key2, val2 in pairs(neighbor_tab) do
		 		if val2.devBssid == val1 then
		 			if val2.web_passwd == password then
		 				debug("check ok! devBssid:"..val2.devBssid)
		 				devBssid = val2.devBssid
						pass_list[#pass_list + 1] = devBssid
						flag = 0 
		 			else
		 				debug("check fail! devBssid:"..val2.devBssid)
		 				devBssid = val2.devBssid
		 				fail_list[#fail_list + 1] = devBssid
		 			end
		 		end
			end
		end
	end
	if flag == 1 then
		data.status = "no"
	else
		data.status = "yes"
		debug("@@@autojoin: " .. autojoin)
		if autojoin and autojoin == "true" then
			local cur_time = tostring(os.time())
			debug("cmd: " .. string.format("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_choicepair\", \"bssid\":%s, \"choicepair_time\":%s}' -b 1", dkjson.encode(bssid), cur_time))
			os.execute(string.format("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_choicepair\", \"bssid\":%s, \"choicepair_time\":%s}' -b 1", dkjson.encode(bssid), cur_time))
		else
			debug("autojoin is false, no need to exec apmeshNetworkSetup!!!")
		end
	end
	data.pass_list 	= pass_list
	data.fail_list	= fail_list
	debug("#data#: " .. dkjson.encode(data))
	return data
end

function module_get(param)
	local paramTable = {}
	debug("param:"..param)
    local paramTable = dkjson.decode(param)
	local product = require("product");
	local web_name = product.get_product("capacity.web")
	local check_web_str = 'check_'..web_name..'_passwd'
    if paramTable ~= nil then
		if paramTable.mode and paramTable.mode == "get_apmesh_neighbor" then
			local data = {}
			debug("fromChache=" .. paramTable.fromChache)
			if paramTable.fromChache and paramTable.fromChache == "1" then 
				data = get_apmesh_neighbor()
			elseif paramTable.fromChache and paramTable.fromChache == "0" then
				debug("rm /tmp/master_apdisc_report -rf")
				debug("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_scan\", \"enable\":\"1\"}' -b 1")
				os.execute("rm /tmp/master_apdisc_report -rf")
				os.execute("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_scan\", \"enable\":\"1\"}' -b 1")
				-- unifyframe max timeout 30s
				local retry = 9
				while retry > 0 do
					debug("sleep 3")
					os.execute("sleep 3")
					data = get_apmesh_neighbor()
					debug("data.count: " .. data.count)
					if data and data.count ~= 0 then
						debug("Get apmesh neighbor is ok !!!")
						break
					else
						debug("Get apmesh neighbor is empty, have a retry!")
					end
					retry = retry - 1
				end
			end

			data = dkjson.encode(data)
			return data
		elseif paramTable.mode and paramTable.mode == check_web_str then
			local data = {}
			local bssid 	= paramTable.bssid
			local password 	= paramTable.password
			local autojoin  = paramTable.autojoin or ""
			debug("rm -rf /tmp/master_pair_status")
			os.execute("rm -rf /tmp/master_pair_status")
			data = check_web_passwd(autojoin, bssid, password)
			return dkjson.encode(data)
		elseif paramTable.mode and paramTable.mode == "scan_offline_report" then
			debug("rm /tmp/master_offline_report -rf")
			debug("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_scan\", \"enable\":\"1\"}' -b 1")
			os.execute("rm /tmp/master_offline_report -rf")
			os.execute("ac_config set -m apmeshNetworkSetup '{\"mode\": \"apmesh_scan\", \"enable\":\"1\"}' -b 1")
		elseif paramTable.mode and paramTable.mode == "get_offline_report" then
			local offline_report 	= "/tmp/master_offline_report"
			local data = {}
			if fs.access(offline_report) then
				local tmp_offline_report = dkjson.decode(console.read_file(offline_report))
				debug("get_offline_report suc")
				return dkjson.encode(tmp_offline_report)
			else
				debug("get_offline_report: can't found ".. offline_report)
				return dkjson.encode(data)
			end
		elseif paramTable.mode and paramTable.mode == "col_acpli_info" then
			os.execute(string.format("rm %s -rf", apcli_info))
			os.execute("ubus -t 5 call apmgr save_apcli_info")
			debug("ubus -t 5 call apmgr save_apcli_info")
		elseif paramTable.mode and paramTable.mode == "get_acpli_info" then
			local data = {}
			if fs.access(apcli_info) then
				local tmp_apcli_info = dkjson.decode(console.read_file(apcli_info))
				debug("get_apcli_info suc")
				return dkjson.encode(tmp_apcli_info)
			end
			debug("get_apcli_info fail")
			return dkjson.encode(data)
		end
	end
end	

