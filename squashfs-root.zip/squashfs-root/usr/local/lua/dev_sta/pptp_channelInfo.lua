#! /usr/bin/lua
module("pptp_channelInfo",package.seeall)

local lfs = require "lfs"
local cjson = require "cjson";
local pptp = require "utils.debug"
local tool = require "dev.tools.common"
local uci = require "luci.model.uci".cursor()
local libc2lua = require "libc2lua"
local DEBUG_LOG_DIR = "/tmp/channelInfo/"
local SERVER_DIR = "/tmp/pptp/server/"
local UPDOWN_DIR = "/tmp/pptp/updown/"
local CLIENT_INFO_FILE = "/tmp/pptp/pptp/input_save"
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/pptp_server_updown.lua"
local PPTP_PPPD_CLIENT_LOG = "/tmp/log/snosvpn/pptp/pptp_pppd_client_log"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", DEBUG_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
local function debug_init()
    pptp.debug_init(DEBUG_LOG_DIR, "pptp_channelInfo.log", 500, pptp.INFO, "1");
end

local function channelInfo_get(file)
    local result = {};
    local file_data = tool.file_read(file)
    if (file_data == nil or tool.json_check(file_data) == false) then
        return result;
    end
    result = cjson.decode(file_data);
    return result;
end

local function stop_client_connect(tunnelname)
    local kill_cmd = "kill -TERM"
    local rm_file_cmd = "rm -rf"

    local pid_file = table.concat({SERVER_DIR, tunnelname, "_pid"});
    if (tool.file_exist(pid_file) == true) then
        local pid = tool.file_read(pid_file);
        kill_cmd = table.concat({kill_cmd, " ", pid});
        rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
    end

    local file = table.concat({tunnelname, "_client_save"});
    local save_file = table.concat({SERVER_DIR, file});
    local down_file = table.concat({UPDOWN_DIR, file});
    pptp.lua_debug(pptp.INFO, "save_file: %s", save_file);
    pptp.lua_debug(pptp.INFO, "down_file: %s", down_file);
    if (tool.file_exist(save_file) == true) then
        os.rename(save_file, down_file);
        pptp.lua_debug(pptp.INFO, "%s", SERVER_UPDOWN_CMD);
        os.execute(SERVER_UPDOWN_CMD);
    end

    pptp.lua_debug(pptp.INFO, "%s", kill_cmd);
    pptp.lua_debug(pptp.INFO, "%s", rm_file_cmd);
    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
end

function lua_string_split(str, split_char)
    local sub_str_tab = {}
    while (true) do
        local pos = string.find(str, split_char)
        if (not pos) then
            sub_str_tab[#sub_str_tab+1] = str
            break
        end
        local sub_str = string.sub(str, 1, pos - 1)
        sub_str_tab[#sub_str_tab + 1] = sub_str
        str = string.sub(str, pos + 1, #str)
    end
    return sub_str_tab
end

------------------------------------dev_module---------------------------------
function module_default_config_get()
    local default_config = '{"serverNum": 0,"client": {},"clientNum": 0,"server": {}}'
    return default_config
end

function module_get()
    local data = {};
    local num = 0
    local code = 6
    local code_msg = {}
    local sub_data = {};
    local jsonStr = '{"count":0,"list":[]}'

    debug_init();
    for file in lfs.dir(DEBUG_LOG_DIR) do
        if (string.find(file, "pptp_server_") ~= nil) then
            local ret = channelInfo_get(table.concat({DEBUG_LOG_DIR, file}))
            if (next(ret) ~= nil) then
                num = num + 1;
                sub_data[num] = ret;
                sub_data[num]["type"] = "server";
                sub_data[num]["code"] = 0
            end
        elseif (string.find(file, "pptp_client_") ~= nil) then
            local ret = channelInfo_get(table.concat({DEBUG_LOG_DIR, file}))
            if (next(ret) ~= nil) then
                num = num + 1;
                sub_data[num] = ret;
                sub_data[num]["type"] = "client";
                sub_data[num]["code"] = 0
            end
        end
    end
    if (sub_data[num] ~= nil) then
        data["list"] = sub_data
        data["count"] = num;
        jsonStr = cjson.encode(data);
    else
        local client_enabled = tonumber(uci:get("pptpd", "client", "enable"))
        if (client_enabled == 1) then
            local pppd_info = {}
            local lcp_log_msg = nil
            local connect_refuse_flag = false
            local peer_gateway_flag = false
            local account_chap_flag = false
            local mppe_required_flag = false
            local lcp_timeout_flag = false
            local static_ip_flag = false
            local client_link_info = {}
            if (tool.file_exist(CLIENT_INFO_FILE) == true) then
                local link_file_data = tool.file_read(CLIENT_INFO_FILE)
                if (link_file_data == nil or tool.json_check(link_file_data) == false) then
                    return(jsonStr)
                end
                client_link_info = cjson.decode(link_file_data)
            end
            if (tool.file_exist(PPTP_PPPD_CLIENT_LOG) == true) then
                local pppd_log_file = io.popen("cat /tmp/log/snosvpn/pptp/pptp_pppd_client_log | tail -50")
                if io.type(pppd_log_file) ~= nil then
                    local a = pppd_log_file:read("*all")
                    pppd_info = lua_string_split(a, "\n") 
                    pppd_log_file:close()
                end
                local match_msg = "Could not open control connection to "..client_link_info["lns"]
                local lcp_timeout_msg = "LCP: timeout sending Config-Requests"
                for i=#pppd_info,1,-1  do
                    if pppd_info[i] ~= "" then
                        if (string.find(pppd_info[i], "connect: Connection refused")) then
                            connect_refuse_flag = true
                        elseif (string.find(pppd_info[i], match_msg)) then                 
                            peer_gateway_flag = true
                        elseif (string.find(pppd_info[i], "authentication failed")) then
                            account_chap_flag = true
                        elseif (string.find(pppd_info[i], "MPPE required but not available")) then
                            mppe_required_flag = true
                        elseif (string.find(pppd_info[i], "MPPE required, but MS-CHAP[v2] auth not performed")) then
                            mppe_required_flag = true
                        elseif (string.find(pppd_info[i], "Peer refused to agree to our IP address")) then
                            static_ip_flag = true
                        end
                    end
                end
                local cmd = "cat "..PPTP_PPPD_CLIENT_LOG.." |grep '"..lcp_timeout_msg.."'"
                local lcp_log_file = io.popen(cmd, "r")
                if (lcp_log_file ~= nil) then
                    lcp_log_msg = lcp_log_file:read("*all")
                    lcp_log_file:close()
                end
                if (lcp_log_msg ~= nil) then 
                    lcp_timeout_flag = true
                end
            end
            if connect_refuse_flag or peer_gateway_flag then
                code = 1
            elseif account_chap_flag then
                code = 2
            elseif mppe_required_flag then
                code = 3
            elseif static_ip_flag then
                code = 4
            elseif lcp_timeout_flag then
                code = 5
            else
                code = 6
            end
            if (tool.file_exist(PPTP_PPPD_CLIENT_LOG) == true) then
                code_msg["username"] = client_link_info["username"]
                code_msg["type"] = "client"
                code_msg["tunnelname"] = client_link_info["tunnelname"]
                code_msg["localIp"] = "-"
                code_msg["remoteIp"] = "-"
                code_msg["lns"] = client_link_info["lns"]
                code_msg["DNS"] = "-"
                code_msg["code"] = code
                table.insert(sub_data, code_msg)
                data["list"] = sub_data
                data["count"] = 0
                jsonStr = cjson.encode(data)
            end
        end 
    end
    pptp.lua_debug(pptp.INFO,  "return: %s", jsonStr);
    return(jsonStr)
end

function module_del(input_data)
    debug_init();
    --参数安全检测
    if (input_data ~= nil) then
        if (libc2lua.lua_param_safety_check(input_data) ~= true)  then
            pptp.lua_debug(pptp.DEBUG, "input_data error.  input_data is %s\n", input_data)
            return
        end
    end
    pptp.lua_debug(pptp.INFO, "################################DEL################################");
    pptp.lua_debug(pptp.INFO, "Input: %s", input_data);

    --参数获取
    if (input_data == nil or tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.ERROR, "Input data is not json mode.");
        return;
    end
    pptp.lua_debug(pptp.INFO, "Input: %s", input_data);
    input_json = cjson.decode(input_data);
    if (next(input_json.list) == nil) then
        pptp.lua_debug(pptp.ERROR, "Tunnelname is empty.");
        return;
    end

    --遍历要删除的用户
    for key,val in pairs(input_json.list) do
        local tunnelname = val.tunnelname;
        if string.match(tunnelname, "^[%w-_]+$") == nil then --匹配只包含数字、字母、"_"、"-"字符串
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data is unsafe")
            if (input_data ~= nil) then
                pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data %s", tunnelname)
            end
            return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
        end
        stop_client_connect(tunnelname);
    end
end
