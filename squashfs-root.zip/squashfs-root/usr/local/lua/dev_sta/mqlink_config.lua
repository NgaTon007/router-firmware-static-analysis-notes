#! /usr/bin/lua
-- os.execute("echo ip:".."11".." > /dev/ttyS1")
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("mqlink_config", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libexec = require("utils.exec");
local libfile = require("utils.file");
local dkjson = require("dkjson");
local dev_config = require("dev_config");

local uf_conf_file = "/etc/sd_config/single/mqlink_configure.json";

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/mqlink/", "mqlink_config.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("mqlink_cfgntf"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- ���󷵻�
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = require("dkjson").encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return require("dkjson").encode(res);
end

-- @mqlink_config_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_config_get()********************");

    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink_config get parameter is nil");
        return module_ret("0012", "mqlink_config get parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta get -m mqlink_config '%s'", param);

    local tab = {};
    local uci = require("luci.model.uci").cursor();
    uci:foreach("mqlink", "mqlink",
    function(s)
        if (s["enable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].enable=%s", s["enable"]);
            tab["enable"] = s["enable"];
        end
        if (s["addr"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].addr=%s", s["addr"]);
            tab["addr"] = s["addr"];
        end
        if (s["port"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].port=%s", s["port"]);
            tab["port"] = s["port"];
        end
        if (s["tls"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].tls=%s", s["tls"]);
            tab["tls"] = s["tls"];
        end
        if (s["tlscafil"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].tlscafil=%s", s["tlscafil"]);
            tab["domainSuffix"] = string.match(s["tlscafil"], "/etc/mqlink/ca/(.+).pem");
        end
        if (s["keepAlivePeroid"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].keepAlivePeroid=%s", s["keepAlivePeroid"]);
            tab["alvPrd"] = s["keepAlivePeroid"];
        end
        if (s["reconnPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnPeriod=%s", s["reconnPeriod"]);
            tab["reconnPrd"] = s["reconnPeriod"];
        end
        if (s["reconnStep"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnStep=%s", s["reconnStep"]);
            tab["reconnStep"] = s["reconnStep"];
        end
        if (s["reconnMaxPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnMaxPeriod=%s", s["reconnMaxPeriod"]);
            tab["reconnMaxPrd"] = s["reconnMaxPeriod"];
        end
        if (s["retransEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransEnable=%s", s["retransEnable"]);
            tab["ackEna"] = s["retransEnable"];
        end
        if (s["retransPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransPeriod=%s", s["retransPeriod"]);
            tab["ackPrd"] = s["retransPeriod"];
        end
        if (s["retransStep"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransStep=%s", s["retransStep"]);
            tab["ackStep"] = s["retransStep"];
        end
        if (s["retransMaxPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransMaxPeriod=%s", s["retransMaxPeriod"]);
            tab["ackMaxPrd"] = s["retransMaxPeriod"];
        end
        if (s["retransLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransLimit=%s", s["retransLimit"]);
            tab["ackLimit"] = s["retransLimit"];
        end
        if (s["dnsFilter"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].dnsFilter=%s", s["dnsFilter"]);
            tab["dnsFilter"] = s["dnsFilter"];
        end
        if (s["controller"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].controller=%s", s["controller"]);
            tab["controller"] = s["controller"];
        end
        if (s["cmdRspMax"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].cmdRspMax=%s", s["cmdRspMax"]);
            tab["cmdRspMax"] = s["cmdRspMax"];
        end
        if (s["reconnmaxswalgo"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnmaxswalgo=%s", s["reconnmaxswalgo"]);
            tab["reconnmaxswalgo"] = s["reconnmaxswalgo"];
        end
    end);

    local json_str = dkjson.encode(tab);
    libdbg.lua_debug(libdbg.INFO, "End mqlink_get() json_str:%s\n", json_str);

    return json_str;
end

-- @mqlink_config_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_config set()********************");

    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink_config set parameter is nil");
        return module_ret("0012", "mqlink_config set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m mqlink_config '%s'", param);

    -- ��������
    local tab = dkjson.decode(param);

    -- ��ȡ���ÿ��json����,���ÿ���д������ö�param���������ã�����������
    if (libfile.file_is_exist(uf_conf_file) == true) then
        libdbg.lua_debug(libdbg.INFO, "%s is exist", uf_conf_file);

        local file_data = libfile.read_file(uf_conf_file);
        local json_tab = dkjson.decode(file_data);

        -- ����������user
        if (json_tab["user"] ~= nil) then
            if (tab["user"] == nil) then
                tab["user"] = json_tab["user"];
            end
        end
        -- ����������enable
        if (json_tab["enable"] ~= nil) then
            if (tab["enable"] == nil) then
                tab["enable"] = json_tab["enable"];
            end
        end
        -- ����������addr
        if (json_tab["addr"] ~= nil) then
            if (tab["addr"] == nil) then
                tab["addr"] = json_tab["addr"];
            end
        end
        -- ����������port
        if (json_tab["port"] ~= nil) then
            if (tab["port"] == nil) then
                tab["port"] = json_tab["port"];
            end
        end
        -- ����������un��username��
        if (json_tab["un"] ~= nil) then
            if (tab["un"] == nil) then
                tab["un"] = json_tab["un"];
            end
        end
        -- ����������pw��password��
        if (json_tab["pw"] ~= nil) then
            if (tab["pw"] == nil) then
                tab["pw"] = json_tab["pw"];
            end
        end
        -- ����������tls
        if (json_tab["tls"] ~= nil) then
            if (tab["tls"] == nil) then
                tab["tls"] = json_tab["tls"];
            end
        end
        -- ����������domainSuffix
        if (json_tab["domainSuffix"] ~= nil) then
            if (tab["domainSuffix"] == nil) then
                tab["domainSuffix"] = json_tab["domainSuffix"];
            end
        end
        -- ����������alvPrd��keepAlivePeroid��
        if (json_tab["alvPrd"] ~= nil) then
            if (tab["alvPrd"] == nil) then
                tab["alvPrd"] = json_tab["alvPrd"];
            end
        end
        -- ����������reconnPrd��reconnPeriod��
        if (json_tab["reconnPrd"] ~= nil) then
            if (tab["reconnPrd"] == nil) then
                tab["reconnPrd"] = json_tab["reconnPrd"];
            end
        end
        -- ����������reconnStep��reconnStep��
        if (json_tab["reconnStep"] ~= nil) then
            if (tab["reconnStep"] == nil) then
                tab["reconnStep"] = json_tab["reconnStep"];
            end
        end
        -- ����������reconnMaxPrd��reconnMaxPeriod��
        if (json_tab["reconnMaxPrd"] ~= nil) then
            if (tab["reconnMaxPrd"] == nil) then
                tab["reconnMaxPrd"] = json_tab["reconnMaxPrd"];
            end
        end
        -- ����������ackEna��retransEnable��
        if (json_tab["ackEna"] ~= nil) then
            if (tab["ackEna"] == nil) then
                tab["ackEna"] = json_tab["ackEna"];
            end
        end
        -- ����������ackPrd��retransPeriod��
        if (json_tab["ackPrd"] ~= nil) then
            if (tab["ackPrd"] == nil) then
                tab["ackPrd"] = json_tab["ackPrd"];
            end
        end
        -- ����������ackStep��retransStep��
        if (json_tab["ackStep"] ~= nil) then
            if (tab["ackStep"] == nil) then
                tab["ackStep"] = json_tab["ackStep"];
            end
        end
        -- ����������ackMaxPrd��retransMaxPeriod��
        if (json_tab["ackMaxPrd"] ~= nil) then
            if (tab["ackMaxPrd"] == nil) then
                tab["ackMaxPrd"] = json_tab["ackMaxPrd"];
            end
        end
        -- ����������ackLimit��retransLimit��
        if (json_tab["ackLimit"] ~= nil) then
            if (tab["ackLimit"] == nil) then
                tab["ackLimit"] = json_tab["ackLimit"];
            end
        end
        -- ����������dnsFilter
        if (json_tab["dnsFilter"] ~= nil) then
            if (tab["dnsFilter"] == nil) then
                tab["dnsFilter"] = json_tab["dnsFilter"];
            end
        end
        -- ����������controller
        if (json_tab["controller"] ~= nil) then
            if (tab["controller"] == nil) then
                tab["controller"] = json_tab["controller"];
            end
        end
        -- ����������cmdRspMax
        if (json_tab["cmdRspMax"] ~= nil) then
            if (tab["cmdRspMax"] == nil) then
                tab["cmdRspMax"] = json_tab["cmdRspMax"];
            end
        end
        -- ����������reconnmaxswalgo
        if (json_tab["reconnmaxswalgo"] ~= nil) then
            if (tab["reconnmaxswalgo"] == nil) then
                tab["reconnmaxswalgo"] = json_tab["reconnmaxswalgo"];
            end
        end
    end

    local ret_str = dev_config.fetch("set", "mqlink_configure", dkjson.encode(tab)).data;
    libdbg.lua_debug(libdbg.INFO, "End mqlink_config set(), mqlink_configure ret_str:%s\n", ret_str);

    return ret_str;
end
