#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("net_arp", package.seeall);

local cjson = require("cjson");
local ubus = require("ubus");
local tool = require("dev.tools.common");
local module_debug = require("utils.debug");
local libfil = require("utils.file");
local libstr = require("utils.string");
local device = "/tmp/sd_device/sd_device.json"
local ubus_module = "swconfig"
local forwardMode="ROUTER"
local ARP_STATIC_FILE = "/etc/sd_config/single/arp_static.json";
local ARP_FILE = "/proc/net/arp";
local dkjson = require("dkjson");
local cjson_safe = require "cjson.safe"
local dev_config = require "dev_config"
----------初始化debug---------------
module_debug.debug_init("/tmp/debug/switch_config/", "net_arp.log", 50, module_debug.DEBUG, "1");

----------枚举初始化---------
function CreatEnumTable(tb, index)
    local enumtb = {}
    local enumindex = index or 0
    for i, v in ipairs(tb) do
        enumtb[v] = enumindex + i
    end
    return enumtb
end

----------通用错误码-----------------
local g_err_code = {
    "ERR_PARAM",
    "ERR_FILE_WRITE",
    "ERR_FILE_NOT_EXIST",
    "ERR_UBUS_CONNECT",
    "ERR_MALLOC_FAILED",
    "ERR_PARAM_TRANSFORM"
}
g_err_code = CreatEnumTable(g_err_code, 200)

--ret(uint)表示是否返回结果给web,0表示不返回，非0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

--------------调用ubus call-------------------------
function ubus_call(method, data)
    local result = {}
    local conn = ubus.connect()

    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ubus.connect failed")
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
        return result
    end

    result = conn:call(ubus_module, method, data)

    if (result == nil) then
        result = {}
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
    end

    return result
end

function forward_get()
    if (libfil.file_is_exist(device) == false) then
        return;
    end
    
    local content = libfil.read_file(device);
    if (content == nil) then
        return;
    end
    
    local tconfig = cjson.decode(content);
    if (tconfig == nil) then
        return;
    end
    
    if (tconfig.forwardMode ~= nil) then
        forwardMode = tconfig.forwardMode;
    end
end

function arp_scan_checkip(input, result)
    local num = 1
    local found = 0;

    if (libfil.file_is_exist(ARP_STATIC_FILE) == false) then
        result["total"] = found;
        return;
    end
    
    local content = libfil.read_file(ARP_STATIC_FILE);
    if (content == nil) then
        result["total"] = found;
        return;
    end
    
    local tconfig = cjson_safe.decode(content);
    if (tconfig == nil or tconfig.arp_static == nil) then
        result["total"] = found;
        return;
    end

    local length = table.maxn(tconfig["arp_static"])
    --对比ip地址或mac地址是否已存在，存在返回存在数组中的编号。不存在返回0
    while ( num < length + 1 )
    do
        if ( tconfig["arp_static"][num]["ipaddr"] == input["checkip"] )
        then
            found = 1;
            break;
        end 
        
        --[[if ( string.upper(tconfig["arp_static"][num]["macaddr"]) == string.upper(input["checkip"]) ) then
            found = 1;
            break;
        end]]--
        num = num + 1
    end
    
    result["total"] = found;
end

function arp_scan_supplement(result)
    if (libfil.file_is_exist(ARP_STATIC_FILE) == false) then
        return;
    end
    
    local content = libfil.read_file(ARP_STATIC_FILE);
    if (content == nil) then
        return;
    end
    
    local tconfig = cjson_safe.decode(content);
    if (tconfig == nil or tconfig.arp_static == nil) then
        return;
    end

    local num = 1
    local length = table.maxn(tconfig["arp_static"])
    local found =0;
    local arp_sub_tab = {};
    
    result.static_count = length;
    while ( num < length + 1 )
    do
        found = 0;
        for i = 1, #result.list do
            if(tconfig["arp_static"][num]["ipaddr"] == result.list[i]["ipaddr"] and string.lower(tconfig["arp_static"][num]["macaddr"]) == string.lower(result.list[i]["macaddr"])) then
                found = 1;
                result.list[i]["type"] = 1
                break;
            end
        end

        if ( found == 0)
        then
            result.total = result.total + 1;
            arp_sub_tab = {};
            arp_sub_tab["ipaddr"]  = tconfig["arp_static"][num]["ipaddr"];
            arp_sub_tab["macaddr"] = string.lower(tconfig["arp_static"][num]["macaddr"]);
            arp_sub_tab["type"] = 1;
            table.insert(result.list, arp_sub_tab);
        end 
        
        num = num + 1
    end

end

function filter_special_char(str)
    local special_tab = {}
    for word in string.gmatch(str, "%X") do
        if (string.find(cjson.encode(special_tab), "%"..word) == nil) then
            table.insert(special_tab, word)
        end
    end

    for k, v in ipairs(special_tab) do
        str = string.gsub(str, "%"..v, "%%%"..v);
    end

    return str
end

function arp_scan_ipaddr(input, result)
    module_debug.lua_debug(module_debug.DEBUG, "")
    module_debug.lua_debug(module_debug.DEBUG, "**************arp_scan_ipaddr()****************")

    local json_str = {};
    if (libfil.file_is_exist(ARP_FILE) == false) then
        module_debug.lua_debug(module_debug.ERROR, "file:%s is not exist", ARP_FILE);
        result["code"] = g_err_code["ERR_FILE_NOT_EXIST"];
        return;
    end

    local arp_str = libfil.read_file(ARP_FILE);
    if (arp_str == nil or #arp_str < 78) then -- 标题的长度是:78
        module_debug.lua_debug(module_debug.ERROR, "file:%s is empty or invalid, please check it", ARP_FILE);
        result["code"] = 3;
        return;
    end
    local arp_line_tab = libstr.string_split_to_table(arp_str, "\n");
    local arp_meta_tab = {};
    local arp_sub_tab = {};
    local arp_tab = {};
    local mac = {};
    local Flags;
    local num = 0;
    local _start = (input.index - 1) * input.size + 1
    local _end = input.index * input.size

    for i = 1, #arp_line_tab do
        arp_meta_tab = libstr.string_split_to_table(arp_line_tab[i], " ");
        Flags = arp_meta_tab[3]
        intf = arp_meta_tab[6]
        if (string.find(arp_line_tab[i], "type") == nil and Flags ~= "0x0" and string.find(intf, "sdwtun") == nil) then
            arp_sub_tab = {};
            arp_sub_tab["ipaddr"]  = arp_meta_tab[1];
            arp_sub_tab["macaddr"] = arp_meta_tab[4];
            if (Flags == "0x6") then
                arp_sub_tab["type"] = 1;
            else 
                arp_sub_tab["type"] = 0;
            end 
            
            table.insert(arp_tab, arp_sub_tab);
            num = num + 1;
        end
    end

    result.list = arp_tab;
    result.static_count = 0;

    --将未生效到arp列表的静态arp，添加到结果列表
    result.total = num;
    arp_scan_supplement(result);

    arp_sub_tab = {};
    arp_tab = {};
    if (input.ipaddr ~= nil) then
        for i = 1, #result.list do
            if (input.ipaddr == result.list[i].ipaddr) then
                arp_sub_tab = {};
                arp_sub_tab["ipaddr"]  = result.list[i].ipaddr;
                arp_sub_tab["macaddr"] = result.list[i].macaddr;
                arp_sub_tab["type"] = result.list[i]["type"];
                table.insert(arp_tab, arp_sub_tab);
                break;
            end
        end
        result.list = arp_tab;
        result.total = #arp_tab;
    elseif (input.search ~= nil) then
        arp_tab_tmp = {}
        str = filter_special_char(input.search)
        for i = 1, #result.list do
            mac = string.upper(result.list[i].macaddr)
            if (string.find(result.list[i].ipaddr, str) ~= nil or string.find(mac, string.upper(str)) ~= nil) then
                arp_sub_tab = {};
                arp_sub_tab["ipaddr"]  = result.list[i].ipaddr;
                arp_sub_tab["macaddr"] = result.list[i].macaddr;
                arp_sub_tab["type"] = result.list[i]["type"];
                table.insert(arp_tab_tmp, arp_sub_tab);
            end
        end
        for i = _start, #arp_tab_tmp do
            if (i <= _end ) then
                arp_sub_tab = {};
                arp_sub_tab["ipaddr"]  = arp_tab_tmp[i].ipaddr;
                arp_sub_tab["macaddr"] = arp_tab_tmp[i].macaddr;
                arp_sub_tab["type"] = arp_tab_tmp[i]["type"];
                table.insert(arp_tab, arp_sub_tab);
            else
                break;
            end
        end
        result.list = arp_tab;
        result.total = #arp_tab_tmp;
    else
        for i = _start, #result.list do
            if (i <= _end ) then
                arp_sub_tab = {};
                arp_sub_tab["ipaddr"]  = result.list[i].ipaddr;
                arp_sub_tab["macaddr"] = result.list[i].macaddr;
                arp_sub_tab["type"] = result.list[i]["type"];
                table.insert(arp_tab, arp_sub_tab);
            else
                break;
            end
        end
        result.list = arp_tab;
    end

end

function arp_scan(input)
    --检查参数是否合格
    local result = {};

    if (input.checkip ~= nil) then
        --在静态arp列表是否存在该ip
        arp_scan_checkip(input, result);
    else 
        arp_scan_ipaddr(input, result);
    end
    
    return result;
end

------------框架调用-------------
function module_get(param)
    local data = cjson_safe.decode(param)
    module_debug.lua_debug(module_debug.DEBUG, "param: %s", param)

    if (data == nil or data["index"] == nil or data["index"] == 0 or data["size"] == nil) then
        module_debug.lua_debug(module_debug.DEBUG, "param index or size is illegal!")
        return output(1, g_err_code["ERR_PARAM"], "ERROR: param index or size is illegal!")
    end

    local result
    forward_get();
    module_debug.lua_debug(module_debug.DEBUG, "forwardMode: %s", forwardMode)
    if (forwardMode == "SWITCH") then
        --交换机通过ubus调用swconfig获取
        result = ubus_call("show_arp", data)
    else
        --网关通过本脚本直接实现
        result = arp_scan(data)
    end
    
    if (result["code"] ~= nil and result["code"] ~= 0) then
        module_debug.lua_debug(module_debug.DEBUG, "ERROR: ubus call show_show_arp failed!")
        return output(1, result["code"], "ERROR: ubus call show_show_arp failed!")
    end

    return dkjson.encode(result)
end

function module_set(param)

end
