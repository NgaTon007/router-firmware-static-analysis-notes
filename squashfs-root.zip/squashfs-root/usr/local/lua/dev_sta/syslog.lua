#!/usr/bin/env lua

module("syslog", package.seeall);
cjson = require "dkjson"
libdbg = require "utils.debug"
libtable = require "utils.table"
log_num = 100

--lua判断文件或则文件夹是否存在
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

function str_is_json(param)
    if
        pcall(
            function(param)
                require("cjson").decode(param)
            end,
            param
        )
    then
        return true;
    else
        return false;
    end
end

libdbg.debug_init("/tmp/syslog/", "syslog.log", 100, libdbg.INFO, "1")
-----------------main-----------------
function module_get(param)
    libdbg.lua_debug(libdbg.INFO, "********************Enter syslog_get()********************");
    local count = 0;
    local total = 0;
    local ret = {};
    local keylist = {};

    -- 参数检查param
    if (param == nil or param == '') then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get parameter is nil");
        return cjson.encode(ret);
    end
    if (str_is_json(param) == false) then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get parameter is not json");
        return cjson.encode(ret);
    end

    input_json = cjson.decode(param);

    if (input_json["type"] == "web") then
        ret["logs"] = {};
        if (file_exist("/tmp/weblog.log") == true) then
            local file = io.open("/tmp/weblog.log", "r")
            for line in file:lines() do
            line = string.gsub(line, '%[%s*%d+%.*%d*%]', "")
                count = count + 1;
                ret["logs"][count] = line;
            end
            file:close();
        end
        ret["count"] = count;
        return cjson.encode(ret);
    end

    -- 参数检查：index
    if (input_json["index"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get failed, index == nil");
        return cjson.encode(ret);
    end

    -- 参数检查：size
    if (input_json["size"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get failed, size == nil");
        return cjson.encode(ret);
    end

    ret["list"] = {};
    local file_lines = {};
    local index = tonumber(input_json["index"]);
    local size = tonumber(input_json["size"]);
    local skey = input_json["key"];
    local start = 0;
    local lend = size + 1;

    -- 1、参数检查index,size
    if (index == nil) then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get failed, index == nil");
        return cjson.encode(ret);
    end
    if (size == nil) then
        libdbg.lua_debug(libdbg.ERROR, "syslog_get failed, size == nil");
        return cjson.encode(ret);
    end

    if (index > 1) then
        start = (index -1) * size;
        lend = index * size + 1;
    end

    if (file_exist("/tmp/weblog.log.0") == true) then
        file_path = "/tmp/weblog.log.0";
    elseif (file_exist("/tmp/weblog.log") == true) then
        file_path = "/tmp/weblog.log";
    else
        libdbg.lua_debug(libdbg.ERROR, "syslog_get failed, no find weblog file");
        return cjson.encode(ret);
    end

    -- 读取文件内容
    local file = io.open(file_path, "r")
    for line in file:lines() do
        table.insert(file_lines, line);
    end
    file:close();

    -- bugid：876272，反转table内容
    file_lines = libtable.reverse_table(file_lines);

    for i, line in ipairs(file_lines) do
        line = string.gsub(line, '%[%s*%d+%.*%d*%]', "")
        ln = line:gsub("%s+", " ")
        local a, b, c, d, e, f = ln:match("^(%S+) (%S+) (%S+) (%S+) (%S+) (%S+)")
        keylist[e] = true;
        f = string.gsub(f, ':', "")
        keylist[f] = true;
        if (skey == nil or skey == "" or string.find(line, skey) ~= nil) then
            total = total + 1;
            if (total > start and total < lend) then
                count = count + 1;
                ret["list"][count] = line;
            end
        end
    end

    ret["keylist"] = {};
    local keynum = 0
    for key, val in pairs(keylist) do
        keynum = keynum + 1;
        ret["keylist"][keynum] = key;
    end

    ret["total"] = total;
    return cjson.encode(ret);
end
