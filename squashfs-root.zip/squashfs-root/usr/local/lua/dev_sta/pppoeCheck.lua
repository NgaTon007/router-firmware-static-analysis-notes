#!/usr/bin/env lua
--��Ŀ��
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("pppoeCheck", package.seeall);
cjson = require "dkjson"
require("uci")
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
local sd_crypto = require("sd_crypto")
require 'lfs'
local console = require "console"
local double_tag = require "utils.double_tag"

lib_debug.debug_init("/tmp/debug/rp-pppoe/", "rp-pppoe_check.log", 300, lib_debug.INFO, "1");

lib_debug.lua_debug(lib_debug.DEBUG, "start");

local g_timeout = 30

local g_pppoe_path         = "/tmp/debug/rp-pppoe"
local g_check_file_tmp    = "/tmp/debug/rp-pppoe/pppoe_check_C"
local g_check_file        = "/tmp/debug/rp-pppoe/pppoe_check_C"
local g_pppoe_cfg         = "/tmp/debug/rp-pppoe/pppoe_cfg_"

local g_disc_failed   = {"discovery failed", "δ���ҵ�pppoe������", "1"}
local g_disc_success  = {"discovery success", "���ҵ�pppoe������", "2"}
local g_auth_success  = {"account authentication passed" ,"�˺���֤�ɹ�", "3"}
local g_auth_failed   = {"account authentication failed" ,"�˺���֤ʧ��", "4"}
local g_ipcp_success  = {"ipcp success" ,"ipЭ�̳ɹ�", "5"}
local g_ipcp_failed   = {"ipcp failed" ,"ipЭ��ʧ��", "6"}
local g_pppoe_check   = {"pppoe���ųɹ�" ,"pppoe����ʧ��", "7"}

local g_time_expired  = {"connect time expired" ,"����ʱ�����", "8"}
local g_conn_terminat = {"connection terminated" ,"������ֹ", "9"}
local g_fail_disconn  = {"failed to disconnect pppoe socket" ,"�ж�����ʧ��", "10"}
local g_pppoe_disconnect    = {"disconnect device" ,"�Ͽ�pppoe������", "11"}
local g_pppoe_connect       = {"connect device" ,"��ʼ����pppoe������", "12"}
local g_check_timeout       = {"connect timeout" ,"���ų�ʱ", "13"}

local g_intf_nofind  = {"intf no find" ,"�ӿڲ�����", "14"}

-- �漰��ȫ������Ӧ���м���
function content_encrypt(param)
    local recode
    local ciphertext
    if (param == nil or param == "") then
        return ""
    end
    recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(param, #param, 'c');
    if(recode ~= 0) then
        return "crypto error"
    end
    return ciphertext
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function module_get(param)
    local cmd = nil
    local result = {}
    local fileTime = 0
    local sysTime = os.time();
    local intf = cjson.decode(param)

    result["data"] = {}
    result["code"] = {}
    result["res"] = "none"

    local x = uci.cursor()
    local proto = x:get("network", intf["intf_name"], "proto")
    if (proto == nil) then
        table.insert(result["data"], g_intf_nofind[2])
        table.insert(result["code"], g_intf_nofind[3])
        result["res"] = "success"
        return cjson.encode(result)
    end

    g_pppoe_cfg = g_pppoe_cfg..intf["intf_name"]
    g_check_file_tmp = g_check_file_tmp..intf["intf_name"]..".log"
    g_check_file = g_check_file..intf["intf_name"]

    local fd = io.open(g_pppoe_cfg)
    if (fd ~= nil) then
        io.close(fd)
        fileTime = lfs.attributes(g_pppoe_cfg)
    end
    local fd2 = io.open(g_check_file_tmp)
    if (fd2 ~= nil) then
        io.close(fd2)
    end
    if (fd == nil) then
        result["res"] = "none"
        return cjson.encode(result)
    end

    local num = sysTime - fileTime.modification
    lib_debug.lua_debug(lib_debug.INFO, "sysTime:%d", sysTime)
    lib_debug.lua_debug(lib_debug.INFO, "fileTime:%d", fileTime.modification)
    lib_debug.lua_debug(lib_debug.INFO, "num:%d", num)

    if (fd ~= nil and num > g_timeout) then
        result["res"] = "failed"
        table.insert(result["data"], g_check_timeout[2])
        table.insert(result["code"], g_check_timeout[3])
        os.remove(g_pppoe_cfg)
        return cjson.encode(result)
    end
    if (fd2 == nil) then
        result["res"] = "checking"
        return cjson.encode(result)
    end

    result["res"] = "checking"
    os.rename(g_check_file_tmp, g_check_file)

    for line in io.lines(g_check_file) do
        if (line == g_disc_failed[1]) then
            table.insert(result["data"], g_disc_failed[2])
            table.insert(result["code"], g_disc_failed[3])
            result["res"] = "failed"
            break
        elseif(line == g_disc_success[1]) then
            table.insert(result["data"], g_disc_success[2])
            table.insert(result["code"], g_disc_success[3])
        elseif(line == g_auth_success[1]) then
            table.insert(result["data"], g_auth_success[2])
            table.insert(result["code"], g_auth_success[3])
            result["res"] = "success"
        elseif(line == g_auth_failed[1]) then
            table.insert(result["data"], g_auth_failed[2])
            table.insert(result["code"], g_auth_failed[3])
            result["res"] = "failed"
            break
        elseif(line == g_ipcp_failed[1]) then
            table.insert(result["data"], g_ipcp_failed[2])
            table.insert(result["code"], g_ipcp_failed[3])
            result["res"] = "failed"
            break
        elseif(line == g_ipcp_success[1]) then
            table.insert(result["data"], g_ipcp_success[2])
            table.insert(result["code"], g_ipcp_success[3])
            result["res"] = "success"
            break
        end
    end
    if (result["res"] == "success" or result["res"] == "failed") then
        cmd = file_read(g_pppoe_cfg)
        os.remove(g_pppoe_cfg)
        os.execute(cmd)
        os.execute("/etc/init.d/network_wan_monitor restart >/dev/null 2>&1")
    end

    os.remove(g_check_file)

    return cjson.encode(result)
end

function param_safety_check(param)
    if (param == nil) then
        lib_debug.lua_debug(lib_debug.INFO, "param is nil")
        return true
    end

    local data = cjson.decode(param)
    if (data == nil) then
        lib_debug.lua_debug(lib_debug.INFO, "data is nil")
        return true
    end

    -- ������ȡ�˺����룬���޳�Դ�����е��˺�����
    local user_passwd_data = {}
    if (data.username ~= nil) then
        user_passwd_data.username = data.username
        data.username = nil
    end
    if (data.password ~= nil) then
        user_passwd_data.password = data.password
        data.password = nil
    end

    -- �޳��˺�����֮��������ֶ��ò���У���У��
    local libc2lua = require("libc2lua");
    local ret = libc2lua.lua_param_safety_check(cjson.encode(data))
    if (ret ~= true) then
        lib_debug.lua_debug(lib_debug.INFO, "lua_param_safety_check failed")
        return false
    end

    -- ���˺����뵥��У�� ' " \
    -- ���ԭʼ��username��password�ַ�����������JSON�������ַ���
    local invalid_char_pattern = "[\n\r\"'\\\\]"

    if (user_passwd_data.username ~= nil) then
        if (string.match(user_passwd_data.username, invalid_char_pattern) ~= nil) then
            lib_debug.lua_debug(lib_debug.INFO, "username contains invalid characters")
            return false
        end
    end

    if (user_passwd_data.password ~= nil) then
        if (string.match(user_passwd_data.password, invalid_char_pattern) ~= nil) then
            lib_debug.lua_debug(lib_debug.INFO, "password contains invalid characters")
            return false
        end
    end

    return true
end

function module_set(param)
    local result = {}
    local fileTime = 0
    local sysTime = os.time();

    lib_debug.lua_debug(lib_debug.INFO, "************** start pppoeCheck **************")

    if (param_safety_check(param) ~= true) then
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end

    local data = cjson.decode(param)
    if (data == nil) then
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end
    g_pppoe_cfg = g_pppoe_cfg..data["intf_name"]
    g_check_file_tmp = g_check_file_tmp..data["intf_name"]..".log"
    local fd = io.open(g_pppoe_cfg)
    if (fd ~= nil) then
        io.close(fd)
        fileTime = lfs.attributes(g_pppoe_cfg)
        local num = sysTime - fileTime.modification
        if (num > g_timeout) then
            os.remove(g_pppoe_cfg)
        else
            result["msg"] = "�����˺��ڼ����"
            result["code"] = "1"
            return cjson.encode(result)
        end
    end

    result["res"] = "�ɹ�"
    result["code"] = "0"

    if (data["intf_name"] ~= nil) then
        lib_debug.lua_debug(lib_debug.INFO, "intf_name:%s", data["intf_name"])
    else
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end
    if (data["intf_name"] ~= nil) then
        local check_ret = double_tag.check_double_tag()
        if (check_ret == 1) then
            --double_tag����
            package.cpath = package.cpath .. ";/usr/lib/libnetifapi.so"
            local libnetifapi = require "libnetifapi"
            local port = libnetifapi.wan_flow_port_get(data["intf_name"], "pppoeCheck")
            data["ifname"] = port
        elseif (check_ret == 0) then
            --�ɷ���
            local x = uci.cursor()
            data["ifname"] = x:get("network", data["intf_name"], "ifname")
        end
        lib_debug.lua_debug(lib_debug.INFO, "ifname:%s", data["ifname"])
    else
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end
    lib_debug.lua_debug(lib_debug.INFO, "ifname:%s", data["ifname"])

    local username_enc = nil
    local password_enc = nil
    if (data["username"] ~= nil) then
        username_enc = content_encrypt(data["username"])
        lib_debug.lua_debug(lib_debug.INFO, "username_enc:[xxsxx]%s", username_enc)
    else
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end
    if (data["password"] ~= nil) then
        password_enc = content_encrypt(data["password"])
        lib_debug.lua_debug(lib_debug.INFO, "password_enc:[xxsxx]%s", password_enc)
    else
        result["res"] = "��������"
        result["code"] = "2"
        lib_debug.lua_debug(lib_debug.INFO, "parameter error")
        return cjson.encode(result)
    end
    if (data["mtu"] ~= nil) then
        lib_debug.lua_debug(lib_debug.INFO, "mtu:%s", data["mtu"])
    else
        data["mtu"] = "1492"
    end
    if (data["metric"] ~= nil) then
        lib_debug.lua_debug(lib_debug.INFO, "metric:%s", data["metric"])
    else
        data["metric"] = "0"
    end

    local x = uci.cursor()
    local proto = x:get("network",data["intf_name"],"proto")
    if (proto == nil) then
        result["res"] = "�ɹ�"
        result["code"] = "0"
        lib_debug.lua_debug(lib_debug.INFO, "no find intf:%s", data["intf_name"])
        return cjson.encode(result)
    end
    local modul = " network.interface."..data["intf_name"]

    local link_cmd = "ifconfig |grep pppoe-"..data["intf_name"]
    local rsfile = io.popen(link_cmd)
    local link_s = rsfile:read("*all")
    if (link_s == "") then
        lib_debug.lua_debug(lib_debug.INFO, "%s is unlink", data["intf_name"])
    else
        lib_debug.lua_debug(lib_debug.INFO, "%s is link", data["intf_name"])

    end

    local logfile = g_pppoe_path.."/".."C"..data["intf_name"]..".log"
    local cmd_down = "ps |grep /usr/sbin/pppd |grep -v grep|awk '{print $1}'| xargs kill >/dev/null 2>&1"
    local file = assert(io.open(g_pppoe_cfg, "w+"));
    file:write(cmd_down);
    file:close(file)

    local cmd_teardown = "sh /lib/netifd/proto/ppp.sh pppoe teardown "..data["intf_name"].." '{\"ifname\":\"br-"..data["intf_name"].."\",\"ifname\":\""..data["ifname"].."\",\"proto\":\"pppoe\",\"metric\":"..data["metric"]..",\"username\":\""..data["username"].."\",\"password\":\""..data["password"].."\",\"ppp_mtu\":"..data["mtu"].."}' br-"..data["intf_name"].." >/dev/null 2>&1"

    data["ifname"]= "\'"..data["ifname"].."\'";
    data["username"]= "\'"..username_enc.."\'";
    data["metric"]= "\'"..data["metric"].."\'";
    data["password"]= "\'"..password_enc.."\'";
    data["mtu"]= "\'"..data["mtu"].."\'";

    local cmd_up = "/usr/sbin/pppd nodetach ipparam '"..data["intf_name"].."' ifname 'pppoe-"..data["intf_name"].."' +ipv6 nodefaultroute usepeerdns persist maxfail 1 user "..data["username"].." password "..data["password"].." account_enc ip-up-script /lib/netifd/ppp-up ipv6-up-script /lib/netifd/ppp-up ip-down-script /lib/netifd/ppp-down ipv6-down-script /lib/netifd/ppp-down mtu "..data["mtu"].." mru 1492 plugin rp-pppoe.so nic-br-"..data["intf_name"].." logfile "..logfile.."  >/dev/null 2>&1 &"

    lib_debug.lua_debug(lib_debug.INFO, "cmd_teardown:[xxsxx]%s", cmd_teardown)
    lib_debug.lua_debug(lib_debug.INFO, "cmd_up:[xxsxx]%s", cmd_up)
    lib_debug.lua_debug(lib_debug.INFO, "cmd_down:[xxsxx]%s", cmd_down)

    os.execute("rm "..g_check_file_tmp)
    if (proto == "dhcp" or proto == "static") then
        console.forkExec(cmd_up)
    else
        if (link_s ~= "") then
            console.forkExec(cmd_teardown..";sleep 2;"..cmd_up)
        else
            os.execute("sleep 3")
            console.forkExec(cmd_teardown..";sleep 2;"..cmd_up)
        end
    end

    return cjson.encode(result)
end
