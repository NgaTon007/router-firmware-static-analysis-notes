#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("vpn_export_log",package.seeall)

local cjson = require "cjson"
local lfs = require "lfs"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local util = require "luci.util"
local L2TP_LOG_DIR = "/tmp/l2tp_log/"
local PPTP_LOG_DIR = "/tmp/pptp_log/"
local SNOSVPN_L2TP_FILE = "/tmp/log/snosvpn/l2tp/l2tp_xl2tpd_process_log" 
local SNOSVPN_PPTP_FILE_1 = "/tmp/log/snosvpn/pptp/pptp_pppd_client_log"
local SNOSVPN_PPTP_FILE_2 = "/tmp/log/snosvpn/pptp/pptp_pppd_server_log"
local SNOSVPN_ISPEC_FILE_1 = "/tmp/log/strongswan-log"
local SNOSVPN_ISPEC_FILE_2 = "/tmp/log/strongswan.log"
local SNOSVPN_OPENVPN_FILE = "/tmp/log/openvpn/openvpn.log"

if (tool.file_exist(L2TP_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", L2TP_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(PPTP_LOG_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", PPTP_LOG_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end
 
--------------------------------------------------------------------------------------------
--@vpn_export_log_get
function module_get(param)
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        return "{\"code\":\"-1\",\"msg\":\"param is nil!\"}"
    end
    if (param_tab["type"] == nil) then
        return "{\"code\":\"-1\",\"msg\":\"type is nil!\"}"
    end
    if (param_tab["type"] == "l2tp") then
        if (tool.file_exist(SNOSVPN_L2TP_FILE) == true) then
            os.execute("rm -rf /tmp/l2tp_log.tar.gz >/dev/null 2>&1")
            os.execute("rm -rf /tmp/l2tp_log/* >/dev/null 2>&1")
            os.execute("cp /tmp/log/snosvpn/l2tp/* /tmp/l2tp_log/ >/dev/null 2>&1")
            os.execute("tar -zcvf /tmp/l2tp_log.tar.gz /tmp/l2tp_log/ >/dev/null 2>&1")
            os.execute("chmod 777 /tmp/l2tp_log.tar.gz >/dev/null 2>&1")
        else
            return "{\"code\":\"-1\",\"msg\":\"File has not been generated!\"}"
        end
    elseif (param_tab["type"] == "pptp") then
        if (tool.file_exist(SNOSVPN_PPTP_FILE_1) == true or tool.file_exist(SNOSVPN_PPTP_FILE_2) == true) then
            os.execute("rm -rf /tmp/pptp_log.tar.gz >/dev/null 2>&1")
            os.execute("rm -rf /tmp/pptp_log/* >/dev/null 2>&1")
            os.execute("cp /tmp/log/snosvpn/pptp/* /tmp/pptp_log/ >/dev/null 2>&1")
            os.execute("tar -zcvf /tmp/pptp_log.tar.gz /tmp/pptp_log/ >/dev/null 2>&1")
            os.execute("chmod 777 /tmp/pptp_log.tar.gz >/dev/null 2>&1")
        else
            return "{\"code\":\"-1\",\"msg\":\"File has not been generated!\"}"
        end
    elseif (param_tab["type"] == "ipsec") then
        if (tool.file_exist(SNOSVPN_ISPEC_FILE_1) == true) then
            os.execute("rm -rf /tmp/strongswan.log >/dev/null 2>&1")
            os.execute("cp /tmp/log/strongswan-log /tmp/strongswan.log >/dev/null 2>&1")
            os.execute("chmod 777 /tmp/strongswan.log >/dev/null 2>&1")
        elseif (tool.file_exist(SNOSVPN_ISPEC_FILE_2) == true) then
            os.execute("rm -rf /tmp/strongswan.log >/dev/null 2>&1")
            os.execute("cp /tmp/log/strongswan.log /tmp/strongswan.log >/dev/null 2>&1")
            os.execute("chmod 777 /tmp/strongswan.log >/dev/null 2>&1")
        else
            return "{\"code\":\"-1\",\"msg\":\"File has not been generated!\"}"
        end
    elseif (param_tab["type"] == "openvpn") then
        if (tool.file_exist(SNOSVPN_OPENVPN_FILE) == true) then
            os.execute("rm -rf /tmp/openvpn.log >/dev/null 2>&1")
            os.execute("cp /tmp/log/openvpn/openvpn.log /tmp/openvpn.log >/dev/null 2>&1")
            os.execute("chmod 777 /tmp/openvpn.log >/dev/null 2>&1")
        else
            return "{\"code\":\"-1\",\"msg\":\"File has not been generated!\"}"
        end
    end
end
----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end