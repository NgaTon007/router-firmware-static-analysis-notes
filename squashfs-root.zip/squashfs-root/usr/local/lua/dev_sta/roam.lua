#!/usr/bin/lua

module("roam", package.seeall)
local console = require "console"
local cjson = require("cjson")
local uci = require "luci.model.uci".cursor()
local lib_param = require "libc2lua"
local table = {rcode= "04130014", rmsg= "parameter roam:param is invalid"}

local function debug(msg)
    console.debug("roam", msg)
end

local function lock()
    os.execute("lock /tmp/sd_config/roamGet.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/roamGet.lock")
end

function execute_ubus_command(cmd)
    local handle = io.popen(cmd)
    local result = handle:read("*a")
    handle:close()
    if result then
        return result
    end

    return nil
  end

function module_get(param)
    local output
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (lib_param.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    lock()
    debug("get info:" .. param)
    local jsonData = cjson.decode(param)
    local mmode = jsonData.mmode
    local mstatus = jsonData.mstatus
    debug("get mode:" .. mmode)
    debug("get status:" .. mstatus)
    if (mmode == "rmtAssoc" and mstatus == "assignStatus") then
        output = execute_ubus_command("ubus call rmtAssoc get_config '{\"rmt_sta_list\":\"\"}' ")
    end
    if (mmode == "rmtAssoc" and mstatus == "smtStatus") then
        output = execute_ubus_command("ubus call rmtAssoc get_config '{\"smart_list\":\"\"}' ")
    end
    unlock()

    if output then
        return output
      else
        debug("Failed to execute ubus command.")
        return console.uf_lua_fail(table)
    end
end

function module_set(param)
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (lib_param.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    debug("set info:" .. param)
    local cmd = "ubus call kv_nav sta '" .. param .. "'"
    debug("exec:" .. cmd)
    os.execute(cmd)
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")