#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("redbscontrl", package.seeall);

cjson = require "cjson"
tool = require "dev.tools.common"
console = require "console"
module_debug = require "utils.debug"
dev_sta = require "dev_sta"
local lsys = require "luci.sys"
local libc2lua = require("libc2lua");

module_name = "[redbscontrl]:"

redbs_ncdb_start = "redis-server /usr/sbin/redisncdb.conf &"
cmd_master_msg = "mqtt show master"
cmd_tipc = "dev_sta  get -m ap_list -i %s '{\"sn\":\"%s\"}' -caller redbscontrl |jq .list[].tI -r"
cmd_tcp = "dev_sta  get -m ap_list -i %s '{\"sn\":\"%s\"}' -caller redbscontrl |jq .list[].ip -r"

-- 白名单规则：只允许字符集 A-Z a-z 0-9 _ : . -，最大长度 64
local function sanitize_sn(s)
    if s == nil then return nil end
    if type(s) ~= "string" then s = tostring(s) end
    if #s == 0 or #s > 64 then return nil end
    if not s:match("^[A-Za-z0-9_:%.%-]+$") then return nil end
    return s
end

----------初始化debug---------------
module_debug.debug_init("/tmp/redbs/", "redbscontrl_lua.log", 100, module_debug.INFO, "1");

----------枚举初始化---------
function CreatEnumTable(tb, index)
    local enumtb = {}
    local enumindex = index or 0
    for i, v in ipairs(tb) do
        enumtb[v] = enumindex + i
    end
    return enumtb
end

----------通用错误码-----------------
local g_err_code = {
    "ERR_PARAM",
    "ERR_FILE_WRITE",
    "ERR_FILE_NOT_EXIST",
    "ERR_PARAM_TRANSFORM"
}
g_err_code = CreatEnumTable(g_err_code, 200)

-- 读取文件内容到字符串
local function read_file(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local content = file:read "*a"
    file:close()
    return content
end

-- 比较两个文件中指定字段的内容是否一致
local function compare_content(file1, file2)
    -- 获取文件内容
    local content1 = read_file(file1)
    local content2 = read_file(file2)

    if not content1 or not content2 then return 0 end

    -- 查找需要比较的内容
    local master_sn, master_tipc, master_tcp = content1:match("master_sn:(.-)\n.*master_tipc:(.-),.*master_tcp:(.*)")
    local sn, sdtipc, tcp = content2:match("sn:(.-)\n.*sdtipc:(.-)\n.*tcp:(.*)")

    -- 比较内容是否一致
    if master_sn == sn and master_tipc == sdtipc and master_tcp == tcp then
        return 1
    else
        return 0
    end
end

function get_option_43()
    local dev_sta_op = dev_sta.fetch("get","easysonStatus").data
    if (dev_sta_op == nil) then
        module_debug.lua_debug(module_debug.ERROR,"get status failed !")
        return nil
    end

    local op_status = cjson.decode(dev_sta_op)

    return op_status.status
end

local function param_element_check(jnData)
    --check param
    if (jnData.networkid == nil ) then
        module_debug.lua_debug(module_debug.ERROR, "param networkid is nil")
        return g_err_code["ERR_PARAM"]
    end

    if (jnData.selfsn == nil) then
        module_debug.lua_debug(module_debug.ERROR, "param selfsn is nil")
        return g_err_code["ERR_PARAM"]
    end

    if (jnData.dispinfo == nil) then
        module_debug.lua_debug(module_debug.ERROR, "param dispinfo is nil")
        return g_err_code["ERR_PARAM"]
    end

    if (jnData.dispinfo.l1 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "param sn is nil")
        return g_err_code["ERR_PARAM"]
    end

    return 0
end

function get_master_msg()
    local dev_sta = dev_sta.fetch("get","master").data
    if (dev_sta == nil) then
        module_debug.lua_debug(module_debug.ERROR,"get master failed !")
        return nil
    end

    local master = cjson.decode(dev_sta)
    return master.ip
end

function get_self_sn()
    local dev_sta = dev_sta.fetch("get","sysinfo").data

    if (dev_sta == nil) then
        module_debug.lua_debug(module_debug.ERROR,"get sysinfo failed !")
        return nil
    end

    local sysinfo = cjson.decode(dev_sta)
    return sysinfo.serial_num
end

function get_tipc_dest(data,role)
    local fp
    local cmd
    local msg
    local master_ip
    local option_43
    local res

    option_43 = get_option_43()
    if (option_43 == 200) then
        res = string.format("%s%s", role, "null")
        return res
    end

    master_ip = get_master_msg();
    if(master_ip == nil) then
        module_debug.lua_debug(module_debug.ERROR, "get master_ip failed!")
        return g_err_code["ERR_FILE_WRITE"]
    end

    local sn = sanitize_sn(data)
    if not sn then
        module_debug.lua_debug(module_debug.ERROR, "get_tipc_dest, illegal sn: %s", tostring(data))
        return string.format("%s%s", role, "null")
    end
    cmd = string.format(cmd_tipc, master_ip, sn)
    module_debug.lua_debug(module_debug.ERROR, "gget_tipc_dest, cmd: %s", cmd)
    res = lsys.exec(cmd)
    if (res == nil) then
        module_debug.lua_debug(module_debug.ERROR, "exec cmd: %s failed", cmd)
        res = string.format("%s%s", role, "null")
        return res
    end

    res = res:gsub("\n", "") -- 替换所有的 "\n"
    res = res:gsub("\r", "") -- 替换所有的 "\r"
    res = string.format("%s%s", role, res)
    module_debug.lua_debug(module_debug.ERROR, "get_tipc_dest res: %s", res)

    return res
end

function get_tcp_dest(data,role)
    local fp
    local cmd
    local msg
    local master_ip
    local res

    master_ip = get_master_msg()
    if(master_ip == nil) then
        module_debug.lua_debug(module_debug.ERROR, "get master_ip failed!")
        return g_err_code["ERR_FILE_WRITE"]
    end

    local sn = sanitize_sn(data)
    if not sn then
        module_debug.lua_debug(module_debug.ERROR, "get_tcp_dest, illegal sn: %s", tostring(data))
        return string.format("%s%s", role, "null")
    end
    cmd = string.format(cmd_tcp, master_ip, sn)
    module_debug.lua_debug(module_debug.ERROR, "get_tcp_dest, cmd: %s", cmd)
    res = lsys.exec(cmd)
    if (res == nil) then
        module_debug.lua_debug(module_debug.ERROR, "exec cmd: %s failed", cmd)
        res = string.format("%s%s", role, "null")
        return res
    end

    res = res:gsub("\n", "") -- 替换所有的 "\n"
    res = res:gsub("\r", "") -- 替换所有的 "\r"
    res = string.format("%s%s", role, res)
    module_debug.lua_debug(module_debug.ERROR, "get_tcp_dest res: %s ", res)

    return res
end

function get_self_msg()
     local fp
     local tipc_msg
     local tcp_msg
     local data
     local res

     fp = io.popen("sdtipc-config -a |grep main |awk '{print $4}'")
     if (fp == nil) then
         module_debug.lua_debug(module_debug.ERROR, "show mqtt master failed")
         return g_err_code["ERR_FILE_WRITE"]
     end
     tipc_msg = fp:read()
     fp:close()

     fp = io.popen("cat /proc/sd_sys/wan_ip")
     if (fp == nil) then
         module_debug.lua_debug(module_debug.ERROR, "show mqtt master failed")
         return g_err_code["ERR_FILE_WRITE"]
     end
     tcp_msg = fp:read()
     fp:close()

     res = string.format("self_tipc:%s,self_tcp:%s\n", tipc_msg, tcp_msg)
     return res
end

function write_msg_to_flash(data)
    local i = 1
    local f1
    local f2
    local self_msg
    local tipc_dest
    local tcp_dest
    local slave_tipc
    local slave_tcp
    local all_str

    self_msg = get_self_msg()

    all_str = string.format("networkid:%s\n", data.networkid)
    all_str = string.format("%sself_sn:%s\n", all_str, data.selfsn)
    all_str = string.format("%s%s", all_str, self_msg)

    --data.dispinfo.l1[i].flag % 2 == 1说明最低位是有值的，表示不支持启动redis-server
    if (data.dispinfo.l1[i].sn ~= nil and data.dispinfo.l1[i].flag ~= nil and data.dispinfo.l1[i].flag % 2 == 1) then
        module_debug.lua_debug(module_debug.ERROR, "l1 sn(" .. data.dispinfo.l1[i].sn .. ") not support redis server.")
        return 1
    end

    if (data.dispinfo.l1[i].sn ~= nil and data.dispinfo.l1[i].tipc ~= nil and data.dispinfo.l1[i].ip ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "master is new version.")
        local safe_master_sn = sanitize_sn(data.dispinfo.l1[i].sn) or ""
        all_str = string.format("%smaster_sn:%s\n", all_str, safe_master_sn)
        all_str = string.format("%smaster_tipc:%s,master_tcp:%s\n", all_str, data.dispinfo.l1[i].tipc, data.dispinfo.l1[i].ip)
    elseif (data.dispinfo.l1[i].sn ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "master is old version, going to get master info.")
        all_str = string.format("%smaster_sn:%s\n", all_str, data.dispinfo.l1[i].sn)
        tipc_dest = get_tipc_dest(data.dispinfo.l1[i].sn,"master_tipc:")
        tcp_dest = get_tcp_dest(data.dispinfo.l1[i].sn,"master_tcp:")
        all_str = string.format("%s%s,%s\n", all_str, tipc_dest, tcp_dest)
    else
        module_debug.lua_debug(module_debug.ERROR, "master sn is nil")
    end

    while(data.dispinfo.l2 ~= nil and data.dispinfo.l2[i] ~= nil and data.dispinfo.l2[i].sn ~= nil)
    do
        -- 如果 flag为nil 或者 flag不为nil且不等1，则表示需要写配置
        if (data.dispinfo.l2[i].flag == nil or data.dispinfo.l2[i].flag ~= 1) then
            if (data.dispinfo.l2[i].tipc ~= nil and data.dispinfo.l2[i].ip ~= nil) then
                module_debug.lua_debug(module_debug.ERROR, "master is new version.")
                local safe_slave_sn = sanitize_sn(data.dispinfo.l2[i].sn) or ""
                all_str = string.format("%sslave_sn:%s\n", all_str, safe_slave_sn)
                all_str = string.format("%sslave_tipc:%s,slave_tcp:%s\n", all_str, data.dispinfo.l2[i].tipc, data.dispinfo.l2[i].ip)
            else
                module_debug.lua_debug(module_debug.ERROR, "master is old version, going to get slave info.")
                slave_tipc = get_tipc_dest(data.dispinfo.l2[i].sn, "slave_tipc:")
                slave_tcp = get_tcp_dest(data.dispinfo.l2[i].sn, "slave_tcp:")
                local safe_slave_sn2 = sanitize_sn(data.dispinfo.l2[i].sn) or ""
                all_str = string.format("%sslave_sn:%s\n%s,%s\n", all_str, safe_slave_sn2, slave_tipc, slave_tcp)
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "sn(%s) flag is not null, and flag is 1", data.dispinfo.l2[i].sn)
        end

        module_debug.lua_debug(module_debug.ERROR, "all_str: %s", all_str)
        i = i+1
    end

    f1 = io.open("/tmp/redbs/prioprity_sn","w+");
    if (f1 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "create / open /tmp/redbs/prioprity_sn failed")
        return g_err_code["ERR_FILE_WRITE"]
    end

    --去掉最后的换行符
    all_str = all_str:gsub("\n$", "")

    f1:write(all_str)
    f1:close()

    return 0
end

function compare_networkid(data)
    local old_networkid
    local a

    local f1 = io.open("/tmp/redbs/prioprity_sn","r");
    if (f1 == nil) then
        return 1
    end
    old_networkid = f1:read()

    a = string.format("networkid:%s",data.networkid)

    if (old_networkid ~= a) then
        fp = io.open("/var/run/redis_6379.pid","r");
        if (fp == nil) then
            f1:close()
            return 1
        end
        io.close(fp);
        return 1
    end
    f1:close()
    return 0
end

function Candidate_equipment(result)
    local kill
    local file

    module_debug.lua_debug(module_debug.ERROR, "killl")
    file =io.popen("ps | grep redis | grep -v grep | grep ncdb | awk '{print $1}'")
    local pid = file:read()
    if(pid ~= nil) then
        kill = string.format("kill %s",pid)
        console.forkExec(kill)
    end
    io.close(file)

    file =io.popen("ps | grep redis | grep -v grep | grep 6378 | awk '{print $1}'")
    local pid = file:read()
    if(pid ~= nil) then
        kill = string.format("kill %s",pid)
        console.forkExec(kill)
    end
    io.close(file)
end

function update_encflag(data)
    local value = 0

    if data.enc ~= nil then
        value = data.enc
    end

    local file, err = io.open("/tmp/redis_encflag", "w")
    if not file then
        module_debug.lua_debug(module_debug.ERROR, "Error: Cannot open /tmp/redis_encflag for writing: " .. err)
        return false
    end

    file:write(tostring(value))  -- 整数转字符串写入
    file:close()

    module_debug.lua_debug(module_debug.ERROR, "Wrote to /tmp/redis_encflag: " .. value)
    return true
end

------------框架调用-------------
function module_set(param)
    local data
    local result = 0

    module_debug.lua_debug(module_debug.ERROR, "comming")
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is null")
        return -1
    end

    if string.match(param, "[\n\r'`&$;|<>]")
        or param:lower():match("\\u00(27|60|24|7c|3e|3c|3b)") then
        module_debug.lua_debug(module_debug.ERROR,"param ==> illegal:"..param)
        return -1
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR,"2param ==> illegal:"..param)
        return -1
    end
--[[
新主旧从，从设备收到的命令：
dev_sta set -m redbscontrl '{"dispinfo":{"l1":["ZAT62DC006424"],"l2":["RAP1261E2"]},"selfsn":"ZAT62DC006424","networkid":"dev_98:4A:6B:5A:84:CE_1722322489"}'
新主新从，从设备收到的命令：R360新增flag，flag默认为0，为1表示该设备不支持当server
dev_sta set -m redbscontrl '{"dispinfo":{"l1":[{"sn":"ZAT62DC006424","ip":"xxx.xxx.xxx.xxx","tipc":"5a6b841c","flag":"0"}],"l2":[{"sn":"RAP1261E2","ip":"192.168.130.3","tipc":"44009444","flag":"1"}]},"selfsn":"ZAT62DC006424","networkid":"dev_98:4A:6B:5A:84:CE_1722322489"}'
旧主新从，从设备收到的命令：
dev_sta set -m redbscontrl '{"dispinfo":{"l1":[{"sn":"ZAT62DC006424"}],"l2":[{"sn":"RAP1261E2"}]},"selfsn":"ZAT62DC006424","networkid":"dev_98:4A:6B:5A:84:CE_1722322489"}'

networkid:dev_98:4A:6B:5A:84:CE_1722322489
self_sn:ZAT62DC006424
self_tipc:5a6b841c,self_tcp:10.52.49.48
master_sn:ZAT62DC006424
master_tipc:5a6b841c,master_tcp:xxx.xxx.xxx.xxx
slave_sn:RAP1261E2
slave_tipc:44009444,slave_tcp:xxx.xxx.xxx.xxx
--]]
    data = cjson.decode(param)
    --白牌不需要执行该函数，即不存在不支持加密的情况
    update_encflag(data)
    --check param
    result = param_element_check(data)
    if (result ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is error: %s", data)
        return -1
    end

    result = compare_networkid(data)
    module_debug.lua_debug(module_debug.ERROR, "compare_networkid result: %d", result)
    if(result ~= 0) then
        Candidate_equipment(result)
    end

    result = write_msg_to_flash(data)
    if (result ~= 0) then
         module_debug.lua_debug(module_debug.ERROR, "write_msg_to_flash msg fail")
         return -1
    end

    local ubus_command = string.format([[ubus -t 3 send easyson_event '{"event":"mosq_event","msg":"enetdisp_change_for_redbs_ctrl"}']])
    module_debug.lua_debug(module_debug.INFO, "ubus_command: %s", ubus_command)
    local handle = io.popen(ubus_command)
    if (handle == nil) then
        module_debug.lua_debug(module_debug.ERROR, "send ubus topic failed")
        return -1
    end
    handle:close()

    module_debug.lua_debug(module_debug.ERROR, "out")
    return 0
end

function module_update(param)
    local data
    local result = 0

    module_debug.lua_debug(module_debug.ERROR, "update comming")
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is null")
        return -1
    end

    if string.match(param, "[\n\r'`&$;|<>]")
        or param:lower():match("\\u00(27|60|24|7c|3e|3c|3b)") then
        module_debug.lua_debug(module_debug.ERROR,"param ==> illegal:"..param)
        return -1
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR,"2param ==> illegal:"..param)
        return -1
    end

    data = cjson.decode(param)
    module_debug.lua_debug(module_debug.ERROR,"update param:"..param)

    if (data.networkId == nil) then
        module_debug.lua_debug(module_debug.ERROR, "param networkid is nil")
        return -1
    end

    local file, err = io.open("/tmp/redbs/prioprity_sn", "r")
    if not file then
        module_debug.lua_debug(module_debug.ERROR, "1 open file failed: " .. err)
        return
    end

    local content = file:read("*a")
    file:close()

    -- 查找并替换 networkid: 后面的内容
    local new_content = content:gsub("(networkid:[^%c]*)%S+", function(match)
        local prefix = match:match("networkid:") -- 获取 networkid: 前缀部分
        return prefix .. data.networkId -- 返回替换后的新字符串
    end)

    file, err = io.open("/tmp/redbs/prioprity_sn", "w")
    if not file then
        module_debug.lua_debug(module_debug.ERROR, "2 open file failed: " .. err)
        return
    end

    file:write(new_content)
    file:close()

    local ubus_command = string.format([[ubus -t 3 send easyson_event '{"event":"mosq_event","msg":"enetdisp_change_update_lnid"}']])
    module_debug.lua_debug(module_debug.INFO, "ubus_command: %s", ubus_command)
    local handle = io.popen(ubus_command)
    if (handle == nil) then
        module_debug.lua_debug(module_debug.ERROR, "send ubus topic failed")
        return -1
    end
    handle:close()

    module_debug.lua_debug(module_debug.ERROR, "update networkid success.")
end
