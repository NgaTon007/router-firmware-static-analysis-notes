-- dev_sta set -m kickOnlineUser '{"list":[{"auth_type":"pppoe","ip":"192.168.1.2","mac":"7085.c45b.acb7"},{"auth_type":"user_pwd_auth","ip":"192.168.1.2","mac":"7085.c45b.acb7"}]}'

package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("kickOnlineUser",package.seeall)

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/account_mgr/"
local pppoe_userinfo_path = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local flowctrl = "/tmp/pppoe-server/pppoeserver_status/flowctrl"
local table_input_err = {rcode = "05630001", rmsg = "param error"}
local kick_user_cmd = "dev_config set -m app_auth '{\"func\": \"app_auth_set_user_online\", \"ip\":\"%s\", \"mac\":\"%s\", \"status\": \"down\"}' &"
local kick_pppoe_cmd = "dev_sta del -m pppoeserver_userinfo '%s' &"
local kick_pppoe_flag = false

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "kickOnlineUser.log", 200, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

function mac_to_colon_format(mac)
    if mac == nil or mac == "" then
        return nil
    end
    
    local mac_plain = mac:gsub("[%.:]", "")
    
    if #mac_plain ~= 12 then
        return nil
    end

    local result = {}
    for i = 1, 12, 2 do
        table.insert(result, mac_plain:sub(i, i+1))
    end
    
    return table.concat(result, ":"):upper()
end

function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end
   
    return sub_str_tab
end
-- ����ֵ: table (�ֵ�), key=MAC��ַ(��дð�Ÿ�ʽ), value=PID
-- ʾ��: { ["00:10:94:00:00:01"] = "22798", ["00:10:94:00:00:02"] = "22801" }
function get_pppd_process_list()
    local pppd_dict = {}
    local handle = io.popen("ps -w 2>/dev/null | grep pppd | grep -v grep")
    
    if handle == nil then
        module_debug.lua_debug(module_debug.ERROR, "Failed to execute ps command")
        return pppd_dict
    end
    
    local line_count = 0
    for line in handle:lines() do
        line_count = line_count + 1
        if (string.sub(line, -1) == "\r") then
            line = string.sub(line, 1, string.len(line) - 1)
        end
        
        --22798 root 4860 S pppd plugin /etc/ppp/plugins/rp-pppoe.so nic-br-lan rp_pppoe_sess 1:00:10:94:00:00:01 rp_pppoe_service
        local info = lua_string_split_space(line)
        
        if info and #info >= 10 and info[10] then
            -- info[1] = PID
            -- info[10] = session_id:mac (��ʽ: 1:00:10:94:00:00:01)
            local mac_with_colon = info[10]:match("^%d+:(.+)$")
            if mac_with_colon then
                local mac_upper = mac_with_colon:upper()
                pppd_dict[mac_upper] = info[1]
                module_debug.lua_debug(module_debug.DEBUG, "Found pppd: PID=%s, MAC=%s", info[1], mac_upper)
            else
                module_debug.lua_debug(module_debug.INFO, "Invalid session_id format: %s", info[10])
            end
        else
            module_debug.lua_debug(module_debug.INFO, "Invalid ps output line: %s", line)
        end
    end
    handle:close()

    module_debug.lua_debug(module_debug.INFO, "Total pppd processes found: %d", line_count)
    return pppd_dict
end

--kill pppd���̣�ɾ��userinfo����
function pppd_userinfo_del(ip, mac, pppd_id_list, pppoe_list)
    local mac_format = mac_to_colon_format(mac)
    pppoe_node = {}
    pppoe_node.ifname = ""
    pppoe_node.pppd_pid = pppd_id_list[mac_format] or ""
    pppoe_node.ipremote = ip
    pppoe_node.macremote = mac_format
    pppoe_node.src = "conf"
    table.insert(pppoe_list, pppoe_node)
    kick_pppoe_flag = true
    module_debug.lua_debug(module_debug.INFO, "INFO:pppoe node : %s", cjson.encode(pppoe_node))
end

function module_set(param)
    debug_init()
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return check_result("0001")
    end

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);

    if (param_tab["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is err")
        return check_result("0001")
    end

    local pppd_id_list = get_pppd_process_list()
    local pppoe_list = {}
    pppoe_list.list = {}
    for k,v in pairs(param_tab["list"]) do
        local auth_type = v["auth_type"]
        local ip = v["ip"]
        local mac = v["mac"]
        local cmd
        if (auth_type ~= nil and ip ~= nil and mac ~= nil) then
            if (auth_type == "pppoe" or auth_type == "pppoe_charge") then
                -- 2026.01.20 ��1521705�޸�pppoe�û��޷��������� 
                -- pppoe_offline�ӿڲ���ص� pppoeserver_userinfo����������pppd���̲��� 
                -- ������pppoeserver_userinfo���������ӳ� 
                -- ���������ӿڶ����� 
                pppd_userinfo_del(ip, mac, pppd_id_list, pppoe_list.list)
                cmd = string.format("curl --connect-timeout 2 'http://127.0.0.1:2060/pppoe_offline?ip=%s&mac=%s' 2>/dev/null > /dev/null &", 
                    ip, mac)
                module_debug.lua_debug(module_debug.INFO, "INFO:cmd : %s", cmd)
                os.execute(cmd)
            else
                cmd = string.format(kick_user_cmd, ip, mac)
                os.execute(cmd)
            end
        end
    end
    -- dev_sta del -m pppoeserver_userinfo '{\"list\": [{\"ifname\": \"%s\", \"pppd_pid\": \"%s\", \"ipremote\": \"%s\",\"macremote\": \"%s\", \"src\": \"%s\"}]}'
    if kick_pppoe_flag == true then
        local pppoe_json_str = cjson.encode(pppoe_list)
        cmd = string.format(kick_pppoe_cmd, pppoe_json_str)
        module_debug.lua_debug(module_debug.INFO, "INFO:cmd : %s", cmd)
        os.execute(cmd)
    end
end