#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("firmware_exist", package.seeall);

local libdbg = require("utils.debug");
local libfil = require("utils.file");
local dkjson = require("dkjson");

libdbg.debug_init("/tmp/firmware_exist/", "firmware_exist.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

-- @firmware_exist_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");
    libdbg.lua_debug(libdbg.INFO, "********************Enter firmware_exist_get()********************");

    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is nil");
        return '{"code":-2,"msg":"firmware_exist_get() param is nil"}';
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m firmware_exist '%s'", param);

    local tab = require("dkjson").decode(param);
    if (tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "firmware_exist_get() param is invalid, param is invalid");
        return '{"code":"-2","msg":"firmware_exist_get() param is invalid, require json"}';
    end
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:user is nil");
    end

    if (libfil.file_is_exist("/tmp/firmware.img") == true) then
        return '{"code":"00000000", "msg":"firmware is exist"}';
    else
        return '{"code":"00000015", "msg":"firmware is not exist"}';
    end
end

function module_set(param)
    return '{"code":-1,"msg":"firmware_exist_set() is not support"}';
end
