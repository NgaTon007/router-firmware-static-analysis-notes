#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dev_diag", package.seeall);

local libdbg  = require("utils.debug");
local libfil  = require("utils.file");
local libexc  = require("utils.exec");
local libjsn  = require("utils.json");
local dkjson  = require("dkjson");
local resfil  = "/tmp/dev_diag/result.json";
local lckfil  = "/tmp/dev_diag/.lock";

local g_ret = {
    rcode = "00000000",
    process = "0%",
    start_time = tostring(os.time()),
    error_count = "0",
    list = {},
}

libdbg.debug_init("/tmp/dev_diag/", "dev_diag.lua.log", 500, libdbg.DEBUG, libdbg.OPEN);

function start_diag(action)
    libdbg.lua_debug(libdbg.INFO, "********************Enter start_diag()********************");
    local cmd = string.format("lua /usr/sbin/start_diag.lua %s", action);
    libexc.fork_exec_cmd(cmd);
end

function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = table.concat({require("dev_module_id").get_module_id("dev_diag"), code});
    end
    result["msg"] = string.format(msg, ...);

    return dkjson.encode(result);
end

function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");
    libdbg.lua_debug(libdbg.INFO, "********************Enter dev_diag_get()********************");

    if (libfil.file_is_exist(resfil) == false) then
        libdbg.lua_debug(libdbg.ERROR, "file or directory %s is not exist", resfil);
        return module_ret("0015", "file or directory %s is not exist", resfil);
    end

    local resstr = libfil.read_file(resfil);
    if (resstr == nil or #resstr == 0) then
        libdbg.lua_debug(libdbg.ERROR, "file:%s is empty", resfil);
        return module_ret("0017", "file:%s is empty", resfil);
    end

    if(libjsn.str_is_json(resstr) == false) then
        libdbg.lua_debug(libdbg.ERROR, "file:%s is not a json format file", resfil);
        return module_ret("0027", "file:%s is not a json format file", resfil);
    end

    return resstr;
end

function module_set(param)
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_diag set parameter is nil");
        return module_ret("0012", "dev_diag set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta get -m dev_diag '%s'", param);

    local tab = require("dkjson").decode(param);
    if (tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_diag set parameter is invalid, require json");
        return module_ret("0014", "dev_diag set parameter is invalid, require json");
    end
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_diag set require parameter:user");
        return module_ret("0013", "dev_diag set require parameter:user");
    end
    if (tab["action"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:action is nil");
        return module_ret("0013", "dev_diag set require parameter:action");
    elseif (tab["action"] ~= "start" and tab["action"] ~= "stop" and tab["action"] ~= "test") then
        libdbg.lua_debug(libdbg.ERROR, "parameter action:%s is invalid, require <start|stop|test>", tab["action"]);
        return module_ret("0014", "parameter action:%s is invalid, require <start|stop|test>", tab["action"]);
    end

    if (tab["action"] ~= "stop") then
        libdbg.lua_debug(libdbg.INFO, "exist file:/tmp/dev_diag/result.json, then init it");
        libfil.write_file(resfil, dkjson.encode(g_ret), "w");
    end

    if (libfil.file_is_exist(lckfil) == true) then
        libdbg.lua_debug(libdbg.ERROR, "another dev_diag process is already running");
        return module_ret("0020", "another dev_diag process is already running");
    end

    start_diag(tab["action"]);

    return module_ret("00000000", "ok");
end
