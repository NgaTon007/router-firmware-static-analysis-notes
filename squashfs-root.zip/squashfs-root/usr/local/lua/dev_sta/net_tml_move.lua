#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_move",package.seeall)
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml_move.lock"
local NT_TML_UCI_CFG = "/etc/config/net_tml"

if (tool.file_exist(NT_TML_UCI_CFG) == false) then
    tool.exec("touch /etc/config/net_tml")
end

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_move.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 检查用于执行ubus的指令是否有单引号、双引号，nil_flag用于说明此参数是否可以为空,nil_flag:1 可以为空 2：不可为空
local function ubus_cmd_param_check(param, nil_flag)
	if (nil_flag ~= 1) then
	    if (param == "") then
	        module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is nil")
	        return -1
		end
	end
    if ((string.match(param , "\"") ~= nil) or (string.match(param , "'") ~= nil)) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is dangrous")
        return -1
    end
	return 0
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)

    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))

    if (sh_ret["code"] == nil or sh_ret["code"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return -1
    end

    return 0
end

--@net_tml_move_set
function net_tml_move_get(param)
    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return -1
    end

    local mac_list = ""
    if (param_tab["nt_info"] ~= "") then
        for k , v in ipairs(param_tab["nt_info"]) do
            if (ubus_cmd_param_check(v["grp_name"], 0) < 0) then
                return -1
            end
            grp_name = "\"grp_name\":\""..v["grp_name"].."\""
            sectionname = string.gsub(v["mac"], ":", "_")
            if (sectionname == nil) then
                return -1
            end
            --uci 配置文件修改（没有就是添加）
            uci:set("net_tml", sectionname, "nt_info")
            uci:set("net_tml", sectionname, "mac",  v["mac"])
            uci:set("net_tml", sectionname, "grp_name", v["grp_name"])
            uci:set("net_tml", sectionname, "hand_grp", "true")
            uci:set("net_tml", sectionname, "cluster", "false")

            if (k == 1) then
                mac_list = v["mac"]
            elseif (k ~= #param_tab) then
                mac_list = mac_list..","..v["mac"]
            end          
        end
    end
    if (mac_list == "") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] mac_list is empty")
        return -1
    end
    mac = "\"mac\":\""..mac_list.."\""
    ubus_cmd = "ubus call nt_mgr.terml_move_to_grp set '{"..grp_name..","..mac.."}'"
    if (ubus_cmd_exe(ubus_cmd) < 0) then
        return -1
    end

    uci:commit("net_tml")
    module_debug.lua_debug(module_debug.INFO, "################################SET END################################")
    return 0
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"":[]}'
    return default_config
end

--@module_get
function module_get(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe\"}"
    end

    if (net_tml_move_get(param) < 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] net_tml_move_get is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"set net_tml_move is fail!\"}"
    end
    os.remove(LOCK_FILE)
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end