#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dhcp_static_scan", package.seeall);-- 第一个参数是本模块的文件名

-- 调试模块初始化
local libdbg = require("utils.debug");
local dkjson = require("dkjson");
local cjson_safe = require "cjson.safe"
local search = require("search");
local uci = require("uci")
tool = require "dev.tools.common"
--libdbg.debug_init("/tmp/dhcp_static/", "dhcp_static.log", 200, libdbg.DEBUG, libdbg.OPEN);
uci_example = uci.cursor()

-- 模糊搜索
function fuzzy_search(key, content)
    local array = content.dhcp_static[1]
    local condition = {}
    local dlist = {}
    local total = 0
    local i = 1
    local tlist = {}
    
    ------------------过滤特殊字符-----------------------
    local special_str = {'(', ')', '%', '+', '-', '*', '?', '[', '^', '$', '.'}

    for k, v in ipairs(special_str) do
        key = string.gsub(key, "%"..v, "%%%"..v);
    end
    
    while (content.dhcp_static[i] ~= nil) do
        for k, v in pairs(content.dhcp_static[i]) do
        -- 过滤不做检索条件
            if (k ~= "name_uuid" and string.find(v, key) ~= nil) then
                table.insert(dlist, content.dhcp_static[i])
                total = total + 1
                break
            end
        end

        i = i + 1
    end

    tlist["list"] = dlist;
    tlist["total"] = tostring(total)
    
    return tlist
end

local function file_copy(src, dst)
    local cmd = "cp " .. src .. " " .. dst .." > /dev/null 2>&1";
    libdbg.lua_debug(libdbg.INFO, "exe cmd [%s]", cmd)
    os.execute(cmd);
end

local function file_write(path, content, mode)
    libdbg.lua_debug(libdbg.INFO, "write json:%s to file[%s] start", content, path)

    local dir = string.match(path, "^(.*[/\\])[^/\\]+%.[^/.]+$")
    if (tool.file_exist(dir) == false) then
        libdbg.lua_debug(libdbg.INFO, "the dir [%s] not exist, creat it", dir)
        local cmd = "mkdir -p " .. dir .. " > /dev/null 2>&1";
        libdbg.lua_debug(libdbg.INFO, "exe cmd [%s]", cmd)
        os.execute(cmd);
    end

    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            libdbg.lua_debug(libdbg.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

function uci_cfg_to_json(path)
    local root = {}
    local dhcp_static = {}
    libdbg.lua_debug(libdbg.INFO, "UCI cfg to json start")
    -- 遍历 host 配置项
    uci_example:foreach("dhcp", "host", function(host)
        -- 检查 host 配置项是否具有所需的选项
        if host.mac and host.ip then
            -- 创建一个新的表来存储 host 信息
            local host_info = {
                name_uuid = host[".name"],
                macaddr = host.mac,
                ipaddr = host.ip
            }
            -- 将 host 信息添加到 dhcp_static 数组
            table.insert(dhcp_static, host_info)
        end
    end)

    root["dhcp_static"] = dhcp_static;
    local root_tab = cjson_safe.encode(root)
    return file_write(path, root_tab)
end

--[[
输入：
    '{"level":1,"index":a, "size":b}'   1-----全部搜索
    '{"level":2,"index":a, "size":b, "macaddr":"00:11"}'  2-----模糊搜索
    '{"level":3,"index":a, "size":b, "macaddr":"00:11:22:33:44:55", "ipaddr":"192.168.1.1"}'  3-----精确搜索
输出：
    {"list":[], "total":a, "count":b, "code":c}
]]--
function module_get(param)
    
    libdbg.debug_init("/tmp/dhcp_static/", "dhcp_static.log", 200, libdbg.DEBUG, libdbg.OPEN);

    local tdata = cjson_safe.decode(param)
    if (tdata == nil or tdata.level == nil) then
        ret = {};
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        ret["max"] = tostring(0);
        return dkjson.encode(ret);
    end
    
    local dev_data
    local data
    local ret 
    local fpath = "/etc/sd_config/single/dhcp_static.json"
    local ffpath = "/tmp/sd_device/sd_device.json"
    local tsearch = {}
    local fpath_backup = "/etc/dhcp_static/dhcp_static_uci.json"
     
    local f = io.open(ffpath, 'r');
    if (f == nil) then
        ret = {};
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        ret["max"] = tostring(0);
        return dkjson.encode(ret);
    end
    
    local content = f:read("*all");
    f:close();
    
    dev_data = dkjson.decode(content);
    
    local f = io.open(fpath, 'r');
    if (f == nil) then
        ret = {};
        ret["list"] = {};
        ret["count"] = tostring(0);
        ret["total"] = tostring(0);
        ret["max"] = dev_data["dnsmasq"].static_dhcp_num;
        return dkjson.encode(ret);
    else
        local content = f:read("*all");
        content_json = cjson_safe.decode(content)
        if (content_json == nil or type(content_json) ~= "table") then
            libdbg.lua_debug(libdbg.ERROR, "parse the file [%s] read failed.", fpath)
            f:close();
            local res = uci_cfg_to_json(fpath_backup);
            if (res == -1) then
                ret = {};
                ret["list"] = {};
                ret["count"] = tostring(0);
                ret["total"] = tostring(0);
                ret["max"] = dev_data["dnsmasq"].static_dhcp_num;
                return dkjson.encode(ret);
            end
            file_copy(fpath_backup, fpath);
            f = io.open(fpath, 'r');
        end
    end

    f:seek("set", 0)
    local content = f:read("*all");
    f:close();

    if (tdata.level == 1) then
        tsearch.index = tdata.index
        tsearch.size = tdata.size
        tsearch.listname = "dhcp_static"
        ret = search.search_all(dkjson.encode(tsearch), content)
    elseif (tdata.level == 2) then
        local key = string.lower(tdata.macaddr)
        local tlist = fuzzy_search(key, dkjson.decode(content))
        ret = search.search_result_format(tdata.index, tdata.size, tlist["list"]);
    else
        tsearch.index = tdata.index
        tsearch.size = tdata.size
        tsearch.listname = "dhcp_static"
        tsearch.condition = {}
        local condition = {}
        condition["key"] = ""
        condition["value"] = ""
        table.insert(tsearch.condition, condition)

        if (string.len(tdata.macaddr) ~= 0) then
            condition["key"] = "macaddr"
            condition["value"] = tdata.macaddr
            ret = search.search_exact(dkjson.encode(tsearch), content)
            data = dkjson.decode(ret);
            if (data.count ~= "0") then
                data["max"] = dev_data["dnsmasq"].static_dhcp_num;
                return dkjson.encode(data);
            end
        end
        
        if (string.len(tdata.ipaddr) ~= 0) then
            condition["key"] = "ipaddr"
            condition["value"] = tdata.ipaddr
            ret = search.search_exact(dkjson.encode(tsearch), content)
        end
        
    end
    
    data = dkjson.decode(ret);
    data["max"] = dev_data["dnsmasq"].static_dhcp_num;
    
    return dkjson.encode(data);
end