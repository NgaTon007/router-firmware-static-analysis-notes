#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("pppoeLog", package.seeall);
cjson = require "dkjson"
tool = require "dev.tools.common"

local g_run_file    = "/tmp/debug/rp-pppoe/pppoe_running_"
local g_run_file_old    = "/tmp/debug/rp-pppoe/pppoe_running_"

local g_disc_failed   = {"discovery failed", "未查找到pppoe服务器", "1"}
local g_disc_success  = {"discovery success", "查找到pppoe服务器", "2"}
local g_auth_success  = {"account authentication passed" ,"账号认证成功", "3"}
local g_auth_failed  = {"account authentication failed" ,"账号认证失败", "4"}
local g_ipcp_success  = {"ipcp success" ,"ip协商成功", "5"}
local g_ipcp_failed   = {"ipcp failed" ,"ip协商失败", "6"}
local g_pppoe_check   = {"pppoe拨号成功" ,"pppoe拨号失败", "7"}

local g_time_expired  = {"connect time expired" ,"连接时间过期", "8"}
local g_conn_terminat = {"connection terminated" ,"连接终止", "9"}
local g_fail_disconn  = {"failed to disconnect pppoe socket" ,"中断连接失败", "10"}
local g_pppoe_disconnect    = {"disconnect device" ,"断开pppoe服务器", "11"}
local g_pppoe_connect       = {"connect device" ,"开始连接pppoe服务器", "12"}

local g_pppoe_peer_term     = {"LCP terminated by peer" ,"服务器主动断开", "15"}
local g_pppoe_no_response   = {"No response to echo-requests" ,"服务器不响应LCP", "16"}
local g_pppoe_sigterm       = {"handle_events, signal 15" ,"设备主动断开连接", "17"}
local g_pppoe_modem_hangup  = {"Modem hangup" ,"设备被动断开连接", "18"}

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function intf_log_get(intf_name)
    local file = {}
    local file_num = 1
    local result = {}
    
    local run_file = g_run_file..intf_name..".log"
    local run_file_old = g_run_file_old..intf_name..".log.old"
    
    local fd = io.open(run_file_old)
    if (fd ~= nil) then
        file[file_num] = run_file_old
        file_num = file_num + 1
        io.close(fd)
    end
    
    fd = io.open(run_file)
    if (fd ~= nil) then
        file[file_num] = run_file
        io.close(fd)
    end

    i = 1
    for j=1,#file do
        for line in io.lines(file[j]) do
        repeat
            local len = string.find(line, "]:", 1)
            if (len == nil) then
                break
            end
            result[i] = {}
            result[i]["time"] = string.sub(line, 2, len - 1)
            result[i]["msg"] = string.sub(line, len + 2, string.len(line))
            
            if (result[i]["msg"] == g_disc_failed[1]) then
                result[i]["code"] =  g_disc_failed[3]
            elseif(result[i]["msg"] == g_disc_success[1]) then
                result[i]["code"] =  g_disc_success[3]
            elseif(result[i]["msg"] == g_auth_success[1]) then
                result[i]["code"] =  g_auth_success[3]
            elseif(result[i]["msg"] == g_auth_failed[1]) then
                result[i]["code"] =  g_auth_failed[3]
            elseif(result[i]["msg"] == g_ipcp_failed[1]) then
                result[i]["code"] =  g_ipcp_failed[3]
            elseif(result[i]["msg"] == g_ipcp_success[1]) then
                result[i]["code"] =  g_ipcp_success[3]
            elseif(result[i]["msg"] == g_time_expired[1]) then
                result[i]["code"] =  g_time_expired[3]
            elseif(result[i]["msg"] == g_conn_terminat[1]) then
                result[i]["code"] =  g_conn_terminat[3]
            elseif(result[i]["msg"] == g_fail_disconn[1]) then
                result[i]["code"] =  g_fail_disconn[3]
            elseif(result[i]["msg"] == g_pppoe_disconnect[1]) then
                result[i]["code"] =  g_pppoe_disconnect[3]
            elseif(result[i]["msg"] == g_pppoe_connect[1]) then
                result[i]["code"] =  g_pppoe_connect[3]
            elseif(result[i]["msg"] == g_pppoe_peer_term[1]) then
                result[i]["code"] =  g_pppoe_peer_term[3]
            elseif(result[i]["msg"] == g_pppoe_no_response[1]) then
                result[i]["code"] =  g_pppoe_no_response[3]
            elseif(result[i]["msg"] == g_pppoe_sigterm[1]) then
                result[i]["code"] =  g_pppoe_sigterm[3]
            elseif(result[i]["msg"] == g_pppoe_modem_hangup[1]) then
                result[i]["code"] =  g_pppoe_modem_hangup[3]
            end
            result[i]["order"] = string.format([[%s]], i)
            i = i + 1
        until true 
        end
    end

    return result
end

function module_get(param)
    local intf = cjson.decode(param)
    local buf = {}

    for key, val in pairs(intf["intf_name"]) do
        buf[val] = intf_log_get(val)

    end
    return cjson.encode(buf)
end
