#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("xlog_get",package.seeall)

local cjson = require "cjson"
local uci = require "luci.model.uci".cursor()
local lfs = require "lfs"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/xlog/web/"
local XLOG_STATUS_FILE = "/tmp/xlog/xlog_status"
local XLOG_UBUS_GET_STATUS = "ubus call xlog.status get_status >/dev/null 2>&1"
local XLOG_REMOVE_STATUS_FILE = "rm -rf /tmp/xlog/xlog_status >/dev/null 2>&1"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "xlog_dev_sta.log", 500, module_debug.INFO, "1");
end

--@dev_mode_get
function module_get()
    debug_init()
    local sub_data = {}
    local jsonStr = '{"server_status":[], "log_status":[]}'
    local nat_log_status = {}
    local dhcp_log_status = {}
    local url_log_status = {}
    local auth_log_status = {}
    local server_list = {}
    local xlog_server_enable = 0

    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################")
    sub_data["server_status"] = {}
    sub_data["log_status"] = {}

    uci:foreach("xlog", "server", function(s)
        local namecode = s[".name"]
        local server_switch = tonumber(uci:get("xlog", namecode, "server_switch"))
        if (server_switch == 1) then
           xlog_server_enable = 1
        end
    end
    )
    if (xlog_server_enable == 1) then
        if (tool.file_exist(XLOG_STATUS_FILE) == true) then
           os.execute(XLOG_REMOVE_STATUS_FILE)
        end
        os.execute(XLOG_UBUS_GET_STATUS)
        if (tool.file_exist(XLOG_STATUS_FILE) == false) then
            module_debug.lua_debug(module_debug.ERROR, "UBUS failed to call command to generate file")
            return jsonStr
        end
        local file_data = tool.file_read(XLOG_STATUS_FILE)
        module_debug.lua_debug(module_debug.INFO, "file_data:%s", file_data)
        file_json = cjson.decode(file_data)
        sub_data["server_status"] = file_json["server_status"]
        nat_log_status["log_name"] = "nat"
        nat_log_status["recv"] = file_json["log_status"]["nat_recv"]
        nat_log_status["drop"] = file_json["log_status"]["nat_drop"]
        nat_log_status["send"] = file_json["log_status"]["nat_send"]
        table.insert(sub_data["log_status"], nat_log_status)
        dhcp_log_status["log_name"] = "dhcp"
        dhcp_log_status["recv"] = file_json["log_status"]["dhcp_recv"]
        dhcp_log_status["drop"] = file_json["log_status"]["dhcp_drop"]
        dhcp_log_status["send"] = file_json["log_status"]["dhcp_send"]
        table.insert(sub_data["log_status"], dhcp_log_status)
        url_log_status["log_name"] = "url"
        url_log_status["recv"] = file_json["log_status"]["url_recv"]
        url_log_status["drop"] = file_json["log_status"]["url_drop"]
        url_log_status["send"] = file_json["log_status"]["url_send"]
        table.insert(sub_data["log_status"], url_log_status)
        auth_log_status["log_name"] = "auth_user"
        auth_log_status["recv"] = file_json["log_status"]["auth_user_recv"]
        auth_log_status["drop"] = file_json["log_status"]["auth_user_drop"]
        auth_log_status["send"] = file_json["log_status"]["auth_user_send"]
        table.insert(sub_data["log_status"], auth_log_status)
        config_tab = cjson.encode(sub_data)
        module_debug.lua_debug(module_debug.INFO, "config_tab:%s", config_tab)
        if (config_tab ~= nil) then
            return config_tab
        end
    else
        return jsonStr
    end
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end