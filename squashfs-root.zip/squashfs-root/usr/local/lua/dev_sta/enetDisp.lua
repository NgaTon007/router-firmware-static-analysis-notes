#! /usr/bin/lua

module("enetDisp", package.seeall);

local console = require "console"
local json = require "dkjson"
local uci = require "luci.model.uci".cursor()
local dev_sta = require "dev_sta"

local ENET_CAP_MODULES_FILE_PATH="/tmp/enetCap/single/modules/"
local ERR_RET_PARAM="{\"rcode\":\"02160001\",\"rmsg\":\"enetDisp: param is invalid\"}"
local ERR_RET_1="{\"rcode\":\"02160001\",\"rmsg\":\"enetDisp: param is invalid\"}"
local ERR_RET_2="{\"rcode\":\"02160003\",\"rmsg\":\"enetDisp: get failed\"}"

local function debug(msg)
    console.debug("enetDisp", msg)
end

function module_set(param)

end

function module_get(param)
	if (param == nil) then
        debug("module_get: param is nil!")
        return ERR_RET_PARAM
    end

	local paramTable = json.decode(param)
	if (paramTable == nil or paramTable.module == nil) then
		debug("module_get: param invalid: "..param)
		return ERR_RET_PARAM
	end

	local file = string.format("/tmp/easyson/disp_%s.json", paramTable.module)

	local f = io.open(file, "r")
	if f == nil then
		debug("module_get: open file failed: "..file)
		return ERR_RET_2
	end
	local content = f:read("*a")
	f:close()

	return content
end

--'{"module":"test","prio":1,"level":{"l1":1,"l2":2},"onlyNewFlag":true}'
function module_add(param)
    if (param == nil) then
        debug("module_add: param is nil!")
        return ERR_RET_PARAM
    end

	paramTable = json.decode(param)
	if (paramTable == nil or paramTable.module == nil or paramTable.prio == nil) then
		debug("module_add: param invalid: "..param)
		return ERR_RET_PARAM
	end
	
	local ret=dev_sta.fetch("get","enetCap","{\"obj\":{\"modules\":{\"enetDisp\":{}}}}")
	local all_content
	--if (ret and ret.data and ret.data.data[1] and ret.data.data[1].modules) then
	if (ret and ret.data) then
		local capdataTable = json.decode(ret.data)
		debug("add capdataTable.data:"..json.encode(capdataTable.data))
		if (capdataTable and capdataTable.data and capdataTable.data[1] and capdataTable.data[1].modules and capdataTable.data[1].modules["enetDisp"]) then
			debug("add capdataTable.data[1].modules:"..json.encode(capdataTable.data[1].modules))
			all_content = capdataTable.data[1].modules["enetDisp"]
		else
			all_content=json.decode("{\"moduleList\":{}}")
			local uci = require("luci.model.uci").cursor();
			all_content.mac = uci:get_first("sysinfo", "sysinfo", "sys_mac");
			all_content.mqtt_prio = uci:get_first("sysinfo", "sysinfo", "master_priority");
		end
	else
		all_content=json.decode("{\"moduleList\":{}}")
		local uci = require("luci.model.uci").cursor();
		all_content.mac = uci:get_first("sysinfo", "sysinfo", "sys_mac");
		all_content.mqtt_prio = uci:get_first("sysinfo", "sysinfo", "master_priority");
	end

	local m_name = paramTable["module"]
	paramTable["module"] = nil
	all_content.moduleList[m_name]=paramTable
	local cmdTable = {}
	cmdTable["module"]="enetDisp"
	cmdTable["caps"]=json.encode(all_content)
    local param_string = json.encode(cmdTable)
	dev_sta.fetch("set","enetCap",param_string)
	--todo ubus notify mqtt update Disp msg
end

function module_del(param)
    if (param == nil) then
        debug("module_add: param is nil!")
        return ERR_RET_PARAM
    end

	paramTable = json.decode(param)
	if (paramTable == nil or paramTable.module == nil) then
		debug("module_del: param invalid: "..param)
		return ERR_RET_PARAM
	end
	
	local ret=dev_sta.fetch("get","enetCap","{\"obj\":{\"modules\":{\"enetDisp\":{}}}}")
	local all_content
	--if (ret and ret.data and ret.data.data[1] and ret.data.data[1].modules) then
	if (ret and ret.data) then
		local capdataTable = json.decode(ret.data)
		debug("del capdataTable.data:"..json.encode(capdataTable.data))
		debug("del capdataTable.data[1].modules:"..json.encode(capdataTable.data[1].modules))
		if (capdataTable and capdataTable.data and capdataTable.data[1] and capdataTable.data[1].modules and capdataTable.data[1].modules["enetDisp"]) then
			all_content = capdataTable.data[1].modules["enetDisp"]
		else
			all_content=json.decode("{\"moduleList\":{}}")
			local uci = require("luci.model.uci").cursor();
			all_content.mac = uci:get_first("sysinfo", "sysinfo", "sys_mac");
			all_content.mqtt_prio = uci:get_first("sysinfo", "sysinfo", "master_priority");
		end
	else
		all_content=json.decode("{\"moduleList\":{}}")
		local uci = require("luci.model.uci").cursor();
		all_content.mac = uci:get_first("sysinfo", "sysinfo", "sys_mac");
		all_content.mqtt_prio = uci:get_first("sysinfo", "sysinfo", "master_priority");
	end

	local m_name = paramTable["module"]
	all_content.moduleList[m_name]=nil
	local cmdTable = {}
	cmdTable["module"]="enetDisp"
	cmdTable["caps"]=json.encode(all_content)
    local param_string = json.encode(cmdTable)
	dev_sta.fetch("set","enetCap",param_string)
	--todo ubus notify mqtt update Disp msg	
end
