#! /usr/bin/env lua

module_name = "safeZoneCap"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

dkjson = require "dkjson"
cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"
dev_cap = require "dev_cap"
cfg = "/etc/safeConf/safeZoneCap.json"
defValue = '{"servList":["web","ping","dns","dhcp"]}'

----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- default config
function module_get()
    local content = file_read(cfg)
    local web = require("product").get_product("capacity.web")
    
    if (content ~= nil and web ~= nil) then
        contentJson = cjson_safe.decode(content)
        if (contentJson ~= nil) then
            cap = dev_cap.fetch("get",web, "", 1)
            capJson = cjson_safe.decode(cap["data"])
     
            if (capJson["snmp"] == "1") then
                table.insert(contentJson["servList"], "snmp")
                content = dkjson.encode(contentJson)
            end
        end
        
        return content
    end

    return defValue
end
