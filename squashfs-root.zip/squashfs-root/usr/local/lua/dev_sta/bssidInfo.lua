#!/usr/bin/lua

module("bssidInfo", package.seeall)
local console = require "console"
local json = require "dkjson"
local uci = require "luci.model.uci".cursor()

local function debug(msg)
    console.debug("bssidInfo", msg)
end

function module_get()
    local data = {}
    local sn = uci:get_first("sysinfo", "sysinfo", "serial_num") or ""
    local support_wifi = uci:get_first("sysinfo", "sysinfo", "support_wifi") or ""
    local bssid_table = {}

    if (support_wifi == '1')
    then
        local bssid_list_io = io.popen("ifconfig -a | grep HWaddr | grep ra | awk {'print $5'}")
        for bssid in bssid_list_io:lines() do
            table.insert(bssid_table, bssid)
        end
    end

    data['sn'] = sn
    data['bssidList'] = bssid_table

    return json.encode(data)
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")
