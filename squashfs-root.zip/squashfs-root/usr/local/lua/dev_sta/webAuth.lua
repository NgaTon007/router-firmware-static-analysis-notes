#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("webAuth", package.seeall);

local cjson = require "cjson"
local console = require "console"
local dev_sta = require "dev_sta"
local ac_config = require "ac_config"
local webpw = require("product").get_product("capacity.webpw.module")
local list = {"type", "url", "auth", "time", "msg"};

local  SUCCESS_CHECK_RETURN = "{\"rcode\":\"00000000\",\"msg\":\"success\"}"
local  FAILED_CHECK_RETURN = "{\"err\":\"{\"rcode\":\"03520001\",\"message\":\"check failed!\"}\",\"code\":\"1\"}"
local  PARAM_ERROR_CHECK_RETURN =  "{\"err\":\"{\"rcode\":\"03520002\",\"message\":\"Param is invalid!\"}\",\"code\":\"1\"}"
--debug
local function debug(msg)
    console.debug("webAuth", msg)
end

function get_ip_sn()
    local dev_sta = dev_sta.fetch("get","sysinfo").data
    if (dev_sta == nil) then
	    debug("get sysinfo failed !")
        return nil,nil
    end
    local sysinfo = cjson.decode(dev_sta)
    return sysinfo.wan_ip,sysinfo.serial_num
end

function get_webpassword()
    local ac_web = ac_config.fetch("get",webpw).data
    if (ac_web == nil) then
        debug("get ac_web failed !")
        return nil
    end
    local ac_config = cjson.decode(ac_web)
    return ac_config.password
end

function checkTime(time)
    local df
    local now = os.time()
    local expired
     
    expired = console.exec_cmd("cat /etc/config/luci |grep sessiontime | awk '{print $3}'|awk -F \"'\" '{print $2}'")
    expired = string.match(expired, "^%d+$") -- 纯数字字符串
    if type(time) == 'number' then
        df = now - time
        if (df <= expired) then
            return true;
        end
    end
    
    if type(time) == 'string' then
        df = string.match(time, "^%d+$") -- 纯数字字符串
        df = now - df
        if (expired - df > 0) then
            return true;
        end
    end
    
    return false
end
    
function checkIp(str)
    -- 放宽IP校验(tipcIp需要)
    return str and string.len(str) < 50 and string.match(str, "^[\.%d:%a]+$") ~= nil
end

function checkSn(str)
    return string.match(str, "^%w+$") ~= nil
end

function checkT(str)
    return  string.match(str, "^%d+$") ~= nil
end

function checktype(str)
    if (str == "check") then
       return true
    end
    
    return false;
end

function getMd5(sn, ip, time)
    local md5
    
    if checkIp(ip) and checkSn(sn) and checkT(time) then
        -- local shell = "echo -n '" .. time .. sn .. ip .. "' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1"
        local shell = string.format("echo -n '%s%s%s' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1", time, sn, ip) 
        md5 = console.exec_cmd(shell)
    end
    
    return md5
end

function getMd5_new(sn, ip)
    local md5
    local webpswd	
    webpswd = get_webpassword()
    if (webpswd == nil) then
        debug("get webpswd failed !")
        return nil
    end
	
    if checkIp(ip) and checkSn(sn) then
        -- local shell = "echo -n '" .. time .. sn .. ip .. "' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1"
        local shell = string.format("echo -n '%s%s%s' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1", webpswd, sn, ip) 
        md5 = console.exec_cmd(shell)
    end
    if checkSn(sn) then
        local shell = string.format("echo -n '%s%s%s' |/usr/sbin/sd_crypto -t A|cut -d ' ' -f1", webpswd, sn, ip) 
        md5 = console.exec_cmd(shell)
    end
    
    return md5
end

function docheck(sn, ip, jdata)
    local data = {}
    local md5
    if (jdata.new == nil) then 
        md5 = getMd5(sn, ip, jdata.time)
    else
        md5 = getMd5_new(sn, ip)
    end

    if (jdata.auth == md5) and checkTime(jdata.time)then
        data = SUCCESS_CHECK_RETURN
    else
        data = FAILED_CHECK_RETURN
    end
    
    return data
end

-- 0:error  1:ok
function param_element_check(jdata)
    if (jdata.type ~= nil) then 
        if (jdata.auth == nil) then
           debug("param_element_check failed jdata.auth == nill")
           return 0
        end
        if (jdata.time == nil) then
           debug("param_element_check failed jdata.time == nill")
           return 0
        end
        return 1
    elseif (jdata.devip ~= nil and jdata.hostip ~= nil ) then
        return 1
    end

    debug("param_element_check faile")
    return 0
end

function get_device_msg(key)
    local data
    local fp
    local device_msg
    
    device_msg = console.read_file("/tmp/sd_device/sd_device.json")
    if (device_msg == nil) then
        debug("get sd_device.json failed")
        return nil
    end
     
    data = cjson.decode(device_msg)
    if (key == "webPort") then
        if (data.webPort == nil) then
            return nil
        else 
            debug("data.key =="..data.webPort)
            return data.webPort
        end
    end
    
    if (key == "webProtocol") then
        if (data.webProtocol == nil) then
            return nil
        else 
            debug("data.key =="..data.webProtocol)
            return data.webProtocol
        end
    end
    
    return nil
end

function set_msg_list(md5, jdata, time)
    local data = {}
    
    local ret = "get auth failed";
    if(md5 == nil) then 
        for i, var in ipairs(list) do
            if (var == "type") then
                ret = "iframe";
            end
            if (var == "url") then
                ret = "null"
            end
            if (var == "auth") then
                ret = "get auth failed"
            end
            if (var == "time") then
                ret = time;
            end
            if (var == "msg") then
                ret = "get auth failed";
            end
            if (ret == nil ) then
                ret = "";
            end
            data[var] = ret;
        end
    else
        for i, var in ipairs(list) do
            if (var == "type") then
                ret = "iframe";
            end
            if (var == "url") then
                local webPort = get_device_msg("webPort")
                if(webPort == nil) then
                    webPort = "80"
                end
                
                local webProtocol = get_device_msg("webProtocol")
                if(webProtocol == nil) then
                    webProtocol = "http"
                end
                if(jdata.isSnosUrl == false ) then
                    ret = string.format('%s://%s/cgi-bin/luci/;stok=iframe?auth=%s', webProtocol, jdata.hostip, md5)
                else 
                    ret = string.format('%s://%s/snos_red_%s/cgi-bin/luci/;stok=iframe?auth=%s&snosRed=/snos_red_%s', webProtocol, jdata.hostip, jdata.devip, md5, jdata.devip)
                end
            end
            if (var == "auth") then
                ret = md5;
            end
            if (var == "time") then
                ret = time;
            end
            if (var == "msg") then
                ret = "success";
            end
            if (ret == nil ) then
                ret = "";
            end
            data[var] = ret;
        end   
    end
    
    return data
end
    
------------框架调用-------------
function module_get(param)
    local data = {};
    local time = os.time()
    local ip,sn = get_ip_sn()
    
    if (param == nil) then
        debug("param is null")
        return
    end
    
    if (sn == nil or ip == nil) then
        debug("sn or ip is null")
        return
    end

    local jdata = cjson.decode(param)
    local result = param_element_check(jdata)
    if (result == 0) then
         data = PARAM_ERROR_CHECK_RETURN
    end
    
    if checktype(jdata.type) then
        data = docheck(sn, ip, jdata)
    elseif (jdata.devip ~= nil and jdata.hostip ~= nil ) then
        local md5 = getMd5_new(sn, ip)
        data = set_msg_list(md5, jdata, time)
        debug("return: "..cjson.encode(data))
        return cjson.encode(data)
    else 
        debug("param is invalid")
        data = PARAM_ERROR_CHECK_RETURN
    end

    debug("return: "..data)
    
    return data
end
