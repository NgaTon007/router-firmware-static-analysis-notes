#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("openvpn_export_config",package.seeall)

local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local uci = require "luci.model.uci".cursor()
local DEBUG_LOG_DIR = "/tmp/log/openvpn/"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "openvpn_export_config.log", 300, module_debug.INFO, "1");
end
--------------------------------------------------------------------------------------------
--@openvpn_export_config_get
function module_get(param)
    debug_init();
    local cfg_time = nil
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param %s", param)
        end
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"-1\",\"msg\":\"param is not json mode!\"}"
    end
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################");
    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return "{\"code\":\"-1\",\"msg\":\"param is nil!\"}"
    end
    if (param_tab["url"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] url is nil")
        return "{\"code\":\"-1\",\"msg\":\"param is nil!\"}"
    end

    if (string.sub(param_tab["url"], 1, 8) ~= "https://") and (string.sub(param_tab["url"], 1, 7) ~= "http://") then 
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] url is not https protocol")
        return "{\"code\":\"-1\",\"msg\":\"param is not https protocol!\"}"
    end

    if (string.find(param_tab["url"],'/service/api/vpn/upload/uploadstream') == nil) then 
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] url is illegal character")
        return "{\"code\":\"-1\",\"msg\":\"param is illegal!\"}"
    end

    local serial_num = uci:get_first("sysinfo", "sysinfo", "serial_num")
    local date_fd = io.popen("date +%Y-%m-%d", "r")
    if io.type(date_fd) ~= nil then
        cfg_time = date_fd:read("*l")
        date_fd:close()
    end
    local openvpn_config = cfg_time.."_openvpn-client-cfg.tar"
    module_debug.lua_debug(module_debug.INFO, "openvpn_config:%s", openvpn_config)
    local url_filename = param_tab["url"].."&sn="..serial_num.."&filename="..openvpn_config
    module_debug.lua_debug(module_debug.INFO, "url_filename:%s", url_filename)
    local header = "Content-Type: application/octet-stream"
--  local form = openvpn_config.."=@".."/etc/openvpn/openvpn-client-cfg.tar"
    local data_binary = "@/etc/openvpn/openvpn-client-cfg.tar"
    module_debug.lua_debug(module_debug.INFO, "data_binary:%s", data_binary)
    -- 定义加密套件变量
    local cipher_list = "ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-GCM-SHA256"
    local curl_post_cmd = "curl -m 30 --tlsv1.2 --ciphers \"" .. cipher_list .. "\" --location -g --request POST '"..url_filename.."' --header '"..header.."' --data-binary '"..data_binary.."' >/dev/null 2>&1"
    module_debug.lua_debug(module_debug.INFO, "curl_post_cmd:%s", curl_post_cmd)
    os.execute(curl_post_cmd)
    module_debug.lua_debug(module_debug.INFO, "################################GET END################################")
end
----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end