#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("pppoeserver_userinfo", package.seeall);
cjson = require "cjson"
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
require "public_module"
require("uci")
lib_param = require("libc2lua")

local modul = "pppoe-server"
local module_name = "pppoeserver_userinfo"
local userinfo_dir = "/tmp/pppoe-server/pppoeserver_status/"
local flowctrl = "/tmp/pppoe-server/pppoeserver_status/flowctrl"
local conf_file = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local port_status_path = "/usr/lib/lua/pppoeserver/pppoeserver_port_status.lua"

----------枚举初始化---------
function CreatEnumTable(tb, index)  
    local enumtb = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tb) do 
        enumtb[v] = enumindex + i 
    end 
    return enumtb
end 
----------lua通用错误码-----------------
local g_err_code = {"ERR_PARAM", "ERR_FILE_WRITE", "ERR_FILE_NOT_EXIST","ERR_UBUS_CONNECT"}
local g_err_code = CreatEnumTable(g_err_code, 200)
--return output(1, g_err_code["ERR_PARAM"], "rate_limit_set failed:param error")

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_userinfo.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")
local uci_r = uci.cursor()

function module_default_config_get()
    local def_cfg = '{"list":[]}' 
    return def_cfg
end

function file_read(conf_file)
    local file, err = io.open(conf_file, "r")
    if (file == nil) 
    then
        return nil, err
    end
    local data = file:read("*a")
    file:close()
    return data
end

-- 带重试机制的文件读取函数
-- @param conf_file: 文件路径
-- @param max_retry: 最大重试次数，默认3次
-- @param retry_interval: 重试间隔(秒)，默认1秒
-- @return data: 文件内容，失败返回nil
-- @return err: 错误信息
function file_read_with_retry(conf_file, max_retry, retry_interval)
    max_retry = max_retry or 3
    retry_interval = retry_interval or 1
    
    local count = 0
    local data, err
    
    while count < max_retry do
        data, err = file_read(conf_file)
        if (data ~= nil) then
            lib_debug.lua_debug(lib_debug.INFO, "file_read success: %s", conf_file)
            return data, nil
        end
        
        lib_debug.lua_debug(lib_debug.ERROR, "file_read error: %s, retry %d/%d", 
            err or "unknown", count + 1, max_retry)
        
        if count < max_retry - 1 then
            tool.sleep(retry_interval)
        end
        count = count + 1
    end
    
    lib_debug.lua_debug(lib_debug.ERROR, "file_read failed after %d retries: %s", 
        max_retry, conf_file)
    return nil, err
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

function file_write_a(conf_file, data)
    local file = io.open(conf_file,"a+")
    file:write(data)
    file:close()
end

--ret(uint)表示是否返回结果给web,0表示不返回，1表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

function get_peername_by_mac(macremote, old_json)
    if (old_json == nil) then
        return "", "", ""
    end
    local mac_remote_peername = ""
    local mac_remote_ip = ""
    local mac_remote_ifname = ""
    for i = 1, #old_json["list"] do
        if (old_json["list"][i]["macremote"] == macremote)
        then
            lib_debug.lua_debug(lib_debug.INFO, "INFO: found macremote %s in old_json", macremote)
            mac_remote_peername = old_json["list"][i]["peername"]
            mac_remote_ip = old_json["list"][i]["ipremote"]
            mac_remote_ifname = old_json["list"][i]["ifname"]
            break
        end
    end
    return mac_remote_peername, mac_remote_ip, mac_remote_ifname
end

function module_get()
    --os.execute("lua "..port_status_path)
    return file_read(conf_file)
end

function module_del(param)
    lib_debug.lua_debug(lib_debug.DEBUG, "module_del:%s\n", param)
    if (lib_param.lua_param_safety_check(param) ~= true) 
	then
		if (param ~= nil)
		then
			lib_debug.lua_debug(lib_debug.DEBUG, "param error.  param is %s\n", param)
		else
			lib_debug.lua_debug(lib_debug.DEBUG, "param error.\n")
		end
		return
	end

    if string.match(param, "\\n") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end

    if string.match(param, "\\t") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end

    if string.match(param, ">") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end

    local del_data = cjson.decode(param)
	local del_length = table.maxn(del_data.list)
    local cmd
    local res
    local num = 1

    local old_data, err = file_read_with_retry(conf_file, 4, 1)
    if (old_data == nil) 
    then
        cmd = string.format("dev_sta del -m pppoeserver_userinfo '%s'", param)
        os.execute(cmd)
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: file read failed, exec: %s", cmd)
        return
    end
    local old_json = cjson.decode(old_data)

    while(num <= del_length)
    do
        del_data.list[num].mac_format = string.gsub(del_data.list[num].macremote, ":", "")
        lib_debug.lua_debug(lib_debug.DEBUG, "DEBUG: del_data.list[num].mac_format %s", del_data.list[num].mac_format)
		if (cmd == nil) then
			cmd = string.format([[kill -9 %s]], del_data.list[num].pppd_pid)
		else            
			cmd = string.format([[%s;kill -9 %s]], cmd, del_data.list[num].pppd_pid)
		end
        del_data.list[num].peername, del_data.list[num].ipremote, del_data.list[num].ifname = get_peername_by_mac(del_data.list[num].macremote, old_json)
        num = num + 1
	end
    lib_debug.lua_debug(lib_debug.DEBUG, "cmd:%s\n", cmd)
    
    if (cmd ~= nil) then
		os.execute(cmd)
	end
    
    
    --del json
    -- local old_data = file_read(conf_file)
    -- local old_json = cjson.decode(old_data)
	local old_length = table.maxn(old_json.list)
    local num_list={}
    
    num = 1
    while(del_length >= num)
    do
        num_list[num] = static_route_match(old_json, del_data.list[num].ifname, old_length) 
        num = num + 1
    end
    table.sort(num_list) 
    
    if (tool.file_exist(userinfo_dir) == false) then
        local path = "mkdir -p " .. userinfo_dir .. " >/dev/null 2>&1"
        os.execute(path);
    end
    local del_len = del_length
    local delstr
    while(del_len > 0)
    do
        -- 文件写会有冲突，冲突概率小，暂不考虑互斥 
        del_file_name = string.format([[%sppp_%s]], userinfo_dir, del_data.list[del_len].mac_format)
        if (tool.file_exist(del_file_name)) then
            delstr = string.format([[{"peername": "%s", "ifname": "%s", "pppd_pid": "%s", "ipremote": "%s", "macremote": "%s", "src": "%s", "status": "down"}]], 
                del_data.list[del_len].peername, del_data.list[del_len].ifname, del_data.list[del_len].pppd_pid, del_data.list[del_len].ipremote, del_data.list[del_len].macremote, del_data.list[del_len].src)
            lib_debug.lua_debug(lib_debug.INFO, "INFO: %s", delstr)
            file_write_a(del_file_name, delstr .. "\n")
        else
            delstr = string.format([[{"peername": "%s", "ifname": "%s", "pppd_pid": "%s", "ipremote": "%s","macremote": "%s", "src": "%s", "status": "down"}]], 
                del_data.list[del_len].peername, del_data.list[del_len].ifname, del_data.list[del_len].pppd_pid, del_data.list[del_len].ipremote, del_data.list[del_len].macremote, del_data.list[del_len].src)
            lib_debug.lua_debug(lib_debug.INFO, "INFO: %s", delstr)
            file_write(del_file_name, delstr .. "\n")
        end
        
        del_len = del_len - 1
    end
    
    --执行elisten命令
    os.execute("ubus -t 3 send \"pppoe_server_status\" &");
    -- os.execute("ubus -t 3 send \"pppoe_server_flowctrl\" &");
end

function del_user_ip(name, ipremote, status)
--写数据到临时文件，为后续流控设置做准备
    local elisten_json = {}
    elisten_json["name"] = name
    elisten_json["ipaddr"] = ipremote
    elisten_json["status"] = status
    file_write_a(flowctrl, cjson.encode(elisten_json).."\n")
end

function static_route_match(old_json, data, old_length)
    local num = 1
    local length = old_length   
    while ( num < length + 1 )
    do
		if ((old_json["list"][num]["ifname"] == data))
        then
            --将该ip从流控地址池中删除
            del_user_ip(old_json["list"][num]["peername"], old_json["list"][num]["ipremote"], "down")
            break
        end
        num = num + 1
    end
    return num
end

function module_apply(param)

end
