#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("upnp", package.seeall);
 
local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"
local fs  = require "nixio.fs"
local libc2lua = require("libc2lua");

--debug
local function debug(msg)
    console.debug("upnp", msg)
end

local function get_upnpds()
    local cmd1 = 'iptables -vxnL MINIUPNPD -t nat'
    local cmd2 = 'cat /var/upnp.leases'
    local upnpds = {}
    local app_data = {}
    if fs.access("/var/upnp.leases") then
        local fp2 = io.popen(cmd2,"r")
        if fp2 then
            local l2
            repeat 
                l2 = fp2:read("*l")
                if l2 then  
                    local member = l2:split(":")
                    local tmp = member[1]..":"..tostring(member[4])
                    app_data[tmp] = member[6]
                end
            until not l2
            fp2:close()
        end
    end

    local fp1 = io.popen(cmd1,"r")
    if fp1 then                                            
        local l1                                        
        repeat                                         
            l1 = fp1:read("*l") 
            if l1 then                              
                local _1,_2,_3,_4,_5,_6,_7,_8,_9,proto,dport,sip,sport = l1:match("^ *(%d+) +(%d+) +(%S+) +(%S+) +(%S+) +(%S+) +(%S+) +(%S+) +(%S+) +(%S+) +dpt:(%d+) +to:(%S+):(%d+)")
                if  proto and  dport and sip and sport then
                    local tmp = string.upper(proto) .. ":" .. tostring(sport)
                    upnpds[#upnpds + 1] = {
                        proto = string.upper(proto),
                        name = app_data[tmp],
                        sip = sip,
                        dport = dport,
                        sport = sport
                    }
                end                                                                                      
            end                                                  
        until not l1                                                       
        fp1:close()                                                      
    end 
    return upnpds
end

function module_set(param)
    local paramTable = dkjson.decode(param)
    debug(paramTable.enable_upnp)
    if (paramTable and libc2lua.lua_param_safety_check(paramTable.enable_upnp) ~= true) then
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    if paramTable and paramTable.enable_upnp == "true" then
        if (paramTable and libc2lua.lua_param_safety_check(paramTable.wan) ~= true) then
            return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
        end
        -- 修改/etc/config/firewall
        uci:delete("firewall", "miniupnpd")
        uci:set("firewall", "miniupnpd", "include")
        uci:set("firewall", "miniupnpd", "type", "script")
        uci:set("firewall", "miniupnpd", "path", "/usr/share/miniupnpd/firewall.include")
        uci:set("firewall", "miniupnpd", "family", "IPv4")
		uci:set("firewall", "miniupnpd", "reload", "1")
        uci:commit("firewall")
        --os.execute("/etc/init.d/firewall reload >/dev/null 2>&1")
		os.execute("sh /usr/share/miniupnpd/firewall.include >/dev/null 2>&1")
        -- 修改/etc/config/upnpd
        uci:set("upnpd", "config", "enable_upnp", "1")
        uci:set("upnpd", "config", "enable_natpmp", "1")
        if paramTable.wan then
            uci:set("upnpd", "config", "external_iface", string.lower(paramTable.wan)) 
        end
        uci:commit("upnpd")
        os.execute("touch /var/upnp.leases")
        debug("/etc/init.d/miniupnpd restart")
        os.execute("/etc/init.d/miniupnpd restart")
        os.execute("iptables -A MINIUPNPD -m conntrack --ctstate DNAT -j ACCEPT >/dev/null 2>&1")
    elseif paramTable and paramTable.enable_upnp == "false" then
        -- 修改/etc/config/upnpd
        uci:set("upnpd", "config", "enable_upnp", "0")
        uci:set("upnpd", "config", "enable_natpmp", "0")
        uci:commit("upnpd")
		debug("/etc/init.d/miniupnpd stop")
        os.execute("/etc/init.d/miniupnpd stop")
        -- 修改/etc/config/firewall
		uci:delete("firewall", "miniupnpd")
        uci:commit("firewall")
		--os.execute("/etc/init.d/firewall reload >/dev/null 2>&1")
		os.execute("iptables -t filter -D  zone_wan_forward -j MINIUPNPD >/dev/null 2>&1")
		os.execute("iptables -t filter -X MINIUPNPD >/dev/null 2>&1")
		os.execute("iptables -t nat -D  zone_wan_prerouting -j MINIUPNPD >/dev/null 2>&1")
		os.execute("iptables -t nat -X MINIUPNPD >/dev/null 2>&1")
		os.execute("iptables -t nat -X MINIUPNPD-POSTROUTING >/dev/null 2>&1")
    end
end

function module_get(param)
    local data = {}
    local enable_upnp = uci:get("upnpd",'config','enable_upnp') or '0'
    local wan = uci:get("upnpd", "config", "external_iface") or 'wan'
    data.enable_upnp = enable_upnp=="1" and "true" or "false"
    local fp1 = io.popen("cat /tmp/sd_device/sd_device.json | jq -r .eth_port.wan_number","r")
    if fp1 then
        local wan_number = fp1:read("*l")
        if wan_number ~= "null" then
            --EG DEVICE
            data.upnp_line="1"
        end
        fp1:close()
    end
    data.wan=wan
    if enable_upnp == "1" then
        data.upnpds = get_upnpds()
    else
        data.upnpds = {}
    end
    return dkjson.encode(data)
end
