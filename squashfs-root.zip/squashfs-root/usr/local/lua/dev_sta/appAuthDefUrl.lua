#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("appAuthDefUrl", package.seeall);
cjson = require "cjson"
lib_debug = require "utils.debug"
local tool = require "dev.tools.common"
local sd_crypto = require "sd_crypto"
local uci_r = require("luci.model.uci").cursor()
local DEBUG_LOG_DIR = "/tmp/app_auth"
-- 与app_auth/webservice两侧128字节密钥缓冲区（含结尾'\0'）保持一致，此处限制的是明文长度
local WIFIDOG_SECRET_MAX_LEN = 127
local ERR_RESP = "{\"code\":\"1\",\"err\":{\"rcode\":\"1\",\"message\":\"param error\"}}"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

lib_debug.debug_init(DEBUG_LOG_DIR, "appAuthDefUrl.log", 100, lib_debug.DEBUG, "1")

function module_get()
    local json = {}

    json["portal_url"] = uci_r:get("app_auth", "def_url", "ad_url")
    json["service_url"] = uci_r:get("app_auth", "def_url", "service_url")
    -- 密钥不回显明文，仅回显是否已配置
    json["wifidogSecret"] = (uci_r:get("app_auth", "app_auth", "wifidogSecret") or "") ~= "" and "1" or ""

    if (json["portal_url"] == nil) then
        json["portal_url"] = ""
    end

    if (json["service_url"] == nil) then
        json["service_url"] = ""
    end

    return cjson.encode(json)
end

function module_del(param)

end

function module_set(param)
    local param_json = cjson.decode(param)
    if (next(param_json) == nil or param_json["portal_url"] == nil
            or param_json["service_url"] == nil) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: param_json is error")
        return ERR_RESP
    end

    local portal_url = param_json["portal_url"]
    local service_url = param_json["service_url"]
    -- 字段缺失或类型非法一律按清空处理，避免设备侧残留已被云端撤销的旧密钥
    local wifidog_secret = param_json["wifidogSecret"]
    if (type(wifidog_secret) ~= "string") then
        wifidog_secret = ""
    end

    -- 超长密钥会被两侧daemon丢弃，此处放行会造成云端以为已配置而设备实际不签名；
    -- 校验放在所有uci set之前，保证整次下发要么全部生效要么全部不生效
    if (#wifidog_secret > WIFIDOG_SECRET_MAX_LEN) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: wifidogSecret is too long")
        return ERR_RESP
    end

    -- 密钥在uci中以密文存储，两侧进程读取后自行解密；加密失败则整次下发不生效，
    -- 避免落一份两侧都解不开的脏数据
    local wifidog_secret_enc = ""
    if (wifidog_secret ~= "") then
        local recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(wifidog_secret,
            #wifidog_secret, 'C')
        if (recode ~= 0) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: wifidogSecret encrypt failed, recode:%d", recode)
            return ERR_RESP
        end
        wifidog_secret_enc = string.gsub(ciphertext, "\n", "")
    end

    uci_r:set("app_auth", "def_url", "ad_url", portal_url)
    uci_r:set("app_auth", "def_url", "service_url", service_url)
    -- 直接下发到两个消费方各自的运行态配置，app_auth侧不另存def_url缓存
    uci_r:set("app_auth", "app_auth", "wifidogSecret", wifidog_secret_enc)
    uci_r:set("webservice", "webservice", "wifidogSecret", wifidog_secret_enc)
    uci_r:commit("webservice")

    uci_r:commit("app_auth")

    return
end

function module_apply(param)

end
