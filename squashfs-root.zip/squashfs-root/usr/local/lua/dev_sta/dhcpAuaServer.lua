#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dhcpAuaServer", package.seeall);

local dkjson = require("dkjson");
local ubus = require("ubus");
local module_debug = require("utils.debug");
local ubus_module = "msw_ncdb_proxy"

----------初始化debug---------------
module_debug.debug_init("/tmp/", "dhcpAuaServer.log", 50, module_debug.DEBUG, "1");

----------枚举初始化---------
function CreatEnumTable(tb, index)
    local enumtb = {}
    local enumindex = index or 0
    for i, v in ipairs(tb) do
        enumtb[v] = enumindex + i
    end
    return enumtb
end

----------通用错误码-----------------
local g_err_code = {
    "ERR_PARAM",
    "ERR_FILE_WRITE",
    "ERR_FILE_NOT_EXIST",
    "ERR_UBUS_CONNECT",
    "ERR_MALLOC_FAILED",
    "ERR_PARAM_TRANSFORM"
}
g_err_code = CreatEnumTable(g_err_code, 200)

--ret(uint)表示是否返回结果给web,0表示不返回，非0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return dkjson.encode(result)
end

--------------调用ubus call-------------------------
function ubus_call(method, data)
    local result = {}
    local conn = ubus.connect()

    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ubus.connect failed")
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
        return result
    end

    result = conn:call(ubus_module, method, data)

    if (result == nil) then
        result = {}
        result["code"] = g_err_code["ERR_UBUS_CONNECT"]
    end

    return result
end

------------框架调用-------------
function module_get(param)
    local data = dkjson.decode("{}")
    local result
	
    local tmp_file = io.popen("dev_sta get -m master")
    local master_str = tmp_file:read("*all")
    tmp_file:close()

    module_debug.lua_debug(module_debug.INFO, "master_str:%s", master_str)

    if (master_str ~= nil) then
        local master_json = dkjson.decode(master_str)
		
        module_debug.lua_debug(module_debug.INFO, "master_json.ip:%s",master_json.ip)

        if (master_json.ip ~= nil and master_json.ip ~= "127.0.0.1") then
            cmd_strings = table.concat({"dev_sta get -m dhcpAuaServer -i ", master_json.ip})
			module_debug.lua_debug(module_debug.INFO, "LOCAL is not master,so excute:%s", cmd_strings)
			tmp_file = io.popen(cmd_strings)

            result = tmp_file:read("*all")
			tmp_file:close()
			return result
        end
    end
    
    result = ubus_call("sw_g_dhcp_aua_server_get", data)

    return dkjson.encode(result)
end