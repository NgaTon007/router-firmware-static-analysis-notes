#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("cloud_unbind", package.seeall); -- ��һ�������Ǳ�ģ����ļ���
local libdbg = require("utils.debug");
local libfile = require("utils.file");
local libmqlink = require("libmqlink");
local dkjson = require("dkjson");
local ac_config = require("ac_config");
local uci = require("luci.model.uci").cursor();

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/mqlink/", "cloud_unbind.lua.log", 100, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|get�ķ���ֵ
    @code�������룬0000Ϊ�ɹ�������Ϊʧ��
    @msg: ���ظ�web�Ĵ�����Ϣ����������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg)
    result = {};
    if (tostring(code) == "0") then
        result["result"] = "success";
    else
        result["result"] = "fail";
        result["code"] = tostring(code);
        result["reason"] = msg;
    end

    return dkjson.encode(result);
end

-- @cloud_unbind_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter cloud_unbind_get()********************");
    libdbg.lua_debug(libdbg.ERROR, "cloud_unbind get is not support");
    return module_ret("0011", "cloud_unbind get is not support");
end

-- @cloud_unbind_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter cloud_unbind_set()********************");

    -- 1��������飺param
    -- example��{"user":"web"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "cloud_unbind set parameter is nil");
        return module_ret("0002", "cloud_unbind set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m cloud_unbind '%s'", param);

    local tab_check = dkjson.decode(param);
    -- 1.1��������飺user
    if (tab_check["user"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "cloud_unbind set require parameter:user is nil");
        return module_ret("0003", "cloud_unbind set require parameter:user is nil");
    end

    -- 2�����ݻ�ȡ
    -- 2.1������libmqlink����ǩ��
    local tab = libmqlink.get_authentic_info_tab();
    if (tab == {}) then
        libdbg.lua_debug(libdbg.ERROR, "Device get info error");
        return module_ret("0013", "get_authentic_info_tab failed");
    end
    tab["timestamp"] = tostring(os.time() * 1000);
    ret, tab["signature"] = libmqlink.get_authentic_signature("sha1", tab);-- ����ǩ��
    if (ret == false) then
        libdbg.lua_debug(libdbg.ERROR, "get_authentic_signature fail");
        return module_ret("0014", "get_authentic_signature failed");
    end
    libdbg.lua_debug(libdbg.INFO, "tab signature is %s", tab["signature"]);

    -- 2.2 ��ȡlnid
    tab["lnid"] = uci:get_first("mqtt", "mqtt", "networkId");
    if (tab["lnid"] == nil or #tab["lnid"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get mqtt.mqtt.networkId failed!");
        return module_ret("0012", "uci get mqtt.mqtt.networkId failed");
    end
    libdbg.lua_debug(libdbg.INFO, "get mqtt networkId success, lnid is %s", tab["lnid"]);

    -- 2.3���ж���cwmp����mqlink�豸����ȡurl��key
    if (libfile.file_is_exist("/etc/config/mqlink_reg")) then
        libdbg.lua_debug(libdbg.INFO, "this is mqlink device, get /etc/config/mqlink_reg");
        url = uci:get_first("mqlink_reg", "mqlink_reg", "unbind_url");
        -- BUGID:1153608
        key = tab["unbind_key"]
    elseif (libfile.file_is_exist("/etc/config/cwmp_reg")) then
        libdbg.lua_debug(libdbg.INFO, "this is cwmp device, get /etc/config/cwmp_reg");
        url = uci:get_first("cwmp_reg", "cwmp_reg", "unbind_url");
        key = uci:get_first("cwmp_reg", "cwmp_reg", "unbind_key");
    end
    if (url == nil or #url == 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci get mqlink_reg.@mqlink_reg[0].unbind_url failed!");
        return module_ret("0008", "uci get mqlink_reg.@mqlink_reg[0].unbind_url failed");
    end
    if (key == nil or #key == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get key failed!");
        return module_ret("0009", "get key failed");
    end
    libdbg.lua_debug(libdbg.INFO, "unbind url is %s", url);
    libdbg.lua_debug(libdbg.INFO, "unbind key is %s", key);

    -- 2.4 ͨ��md5���ܻ�ȡsign
    local sign_str = string.format("%s|%s|%s|%s", tab["sn"], tab["lnid"], tab["timestamp"], key);
    libdbg.lua_debug(libdbg.INFO, "sign_str is %s", sign_str);
    tab["sign"] = require("crypto").digest("md5", sign_str);
    if (tab["sign"] == false or #tab["sign"] == 0) then
        libdbg.lua_debug(libdbg.ERROR, "get sign failed!");
        return module_ret("0011", "get sign failed");
    end
    libdbg.lua_debug(libdbg.INFO, "tab sign is %s", tab["sign"]);

    -- 3����������
    local data = string.format('{\
    "appid": "%s",\
    "nonce": "%s",\
    "signature": "%s",\
    "timestamp": "%s",\
    "sn": "%s",\
    "lnid": "%s",\
    "sign": "%s"\n}\n',
    tab["appid"],
    tab["nonce"],
    tab["signature"],
    tab["timestamp"],
    tab["sn"],
    tab["lnid"],
    tab["sign"]);
    local status, http_rsp, http_code = libmqlink.http_send(url, "POST", data, 8);

    -- 4����������
    -- ���ж�http������Ͳ���Ҫ��ȥ����http����ֵ
    if (status == false or (http_code ~= 200 and http_code ~= 204)) then
        libdbg.lua_debug(libdbg.ERROR, "http post failed, http_code: %s", http_code);
        return module_ret("0006", "http post failed");
    end
    local http_rsp_tab = dkjson.decode(http_rsp);
    -- �����ж�httpӦ��� code��ֻҪpcall����һ�μ��ɣ���֤��json
    local status, retval = pcall(function() http_rsp_code = http_rsp_tab["code"] end);
    if (status == false or http_rsp_code == nil) then
        -- ����json����ʧ��ֵΪ�յ��������ʱ�����httpӦ����json�ģ�http_rsp_tab���Ǳ���
        libdbg.lua_debug(libdbg.ERROR, "json decode http rsp code failed, error: %s", retval or "http rsp code is nil");
        return module_ret("0007", "json decode http rsp code failed");
    end
    libdbg.lua_debug(libdbg.DEBUG, "json decode http rsp code success");

    local mqlink_cfg_tab = {
        user = "cloud_unbind",
        controller = "none"
    }

    local mqlink_res_str = ac_config.fetch("set", "mqlink_configure", dkjson.encode(mqlink_cfg_tab)).data;

    if (mqlink_res_str == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_sta set mqlink_config controller error, return is nil");
        return module_ret("0008","dev_sta set mqlink_config controller error, return is nil");
    end

    libdbg.lua_debug(libdbg.INFO, "%s", mqlink_res_str);

    local mqlink_res_tab = dkjson.decode(mqlink_res_str);
    if(mqlink_res_tab["rcode"] ~= "00000000") then
        libdbg.lua_debug(libdbg.ERROR, "dev_sta set mqlink_config controller error, return is nil, reason is %s", mqlink_res_tab["rmsg"]);
        return module_ret("0009", mqlink_res_tab["rmsg"]);
    end

    return module_ret(http_rsp_tab["code"], http_rsp_tab["msg"]);
end