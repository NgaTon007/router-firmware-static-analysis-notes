-- dev_sta get -m pppoeActiveTime

package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("pppoeActiveTime",package.seeall)

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/account_mgr/"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "pppoeActiveTime.log", 200, module_debug.INFO, "1");
end

-----------------------------------------------------------------------------------------
local function is_number(str)
    return str:match("^%d+$") ~= nil
end

local function pppoe_active_user_get(param_index, param_count)
    local user_info_list = {}
    user_info_list["list"] = {}
    local count = 0
    local read_first_page = true

    if param_index ~= 0 then
        read_first_page = false
    end

    local total = uci:get("account_mgr", "main", "charge_active_count")
    if total ~= nil and total ~= "" then
        user_info_list["total"] = total
        if (tonumber(total) > param_index + param_count) then
            user_info_list["index"] = tostring(param_index + param_count)
        else
            user_info_list["index"] = "-1"
        end
    else
        return nil
    end
    module_debug.lua_debug(module_debug.INFO, "INFO: user_info_list[\"index\"]:%s; user_info_list[\"total\"]:%s", user_info_list["index"], user_info_list["total"])
    if read_first_page == true then
        -- ��ǰn����¼
        module_debug.lua_debug(module_debug.DEBUG, "DEBUG: Read the first n records.")
        uci:foreach("account_mgr", "charge", function(s)
            local name = s[".name"]
            local user_info = {}
            user_info["name"] = uci:get("account_mgr", name, "username")
            user_info["type"] = "pppoe_charge"
            user_info["pkg_active_time"] = uci:get("account_mgr", name, "active_time")
            user_info["pkg_expired_time"] = uci:get("account_mgr", name, "expire_time")
            table.insert(user_info_list["list"], user_info)
            count = count + 1
            if count == param_count then
                return false
            end
        end
        )
    else
        -- ����ǰn����¼ 
        module_debug.lua_debug(module_debug.DEBUG, "DEBUG: Skip the first n records." )
        uci:foreach("account_mgr", "charge", function(s)
            count = count + 1
            if count <= param_index then
                return
            end
            local name = s[".name"]
            local user_info = {}
            user_info["name"] = uci:get("account_mgr", name, "username")
            user_info["type"] = "pppoe_charge"
            user_info["pkg_active_time"] = uci:get("account_mgr", name, "active_time")
            user_info["pkg_expired_time"] = uci:get("account_mgr", name, "expire_time")
            table.insert(user_info_list["list"], user_info)
            if count == (param_index + param_count) then
                return false
            end
        end
        )

    end
    
    result = cjson.encode(user_info_list)
    module_debug.lua_debug(module_debug.INFO, "INFO: res:%s", result)
    return result
end

function module_get(param)
    debug_init()
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil or is_number(param_tab["index"]) == false or is_number(param_tab["count"]) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end

    return pppoe_active_user_get(tonumber(param_tab["index"]), tonumber(param_tab["count"]))
end