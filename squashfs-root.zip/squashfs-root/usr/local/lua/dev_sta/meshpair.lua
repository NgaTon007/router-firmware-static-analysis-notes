#! /usr/bin/lua

module("meshpair", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local fs  = require "nixio.fs"

local meshListFile = "/tmp/mesh.list"
local routeListFile = "/tmp/bcnie_report"

--debug
local function debug(msg)
    console.debug("meshpair", msg)
end

local function route_list_get()
	debug("route_list_get: get routelist from "..routeListFile)
	if fs.access(routeListFile) then
		local bcnie = console.read_file(routeListFile) or ""
		local rlist = {}
		debug("route_list_get: get routelist: "..bcnie)
		rlist = dkjson.decode(bcnie)
		if rlist and rlist.count then
			debug("route_list_get: get count: "..rlist.count)
			return bcnie
		else
			debug("route_list_get: cant get count")
		end
	else
		debug("route_list_get: can't found ".. routeListFile)
	end
	return ""
end
	
function module_set(param)
	local paramTable = {}
	if param == nil then
		debug("mesh set: input param is nil, do nothing!")
	end
	paramTable = dkjson.decode(param)
	if paramTable then
		if paramTable.pairing then
			debug("mesh pairing")
			debug("rm -rf "..meshListFile)
			os.execute("rm -rf "..meshListFile)
			debug("ubus -t 2 call apmgr meshdisc")
			os.execute("ubus -t 2 call apmgr meshdisc")
			return
		elseif paramTable.scanning then
			debug("mesh scanning")
			debug("ubus -t 2 call apmgr routescan")
			os.execute("ubus -t 2 call apmgr routescan")
			return
		elseif paramTable.choicepair then
			debug("mesh choice pair")
			if string.match(paramTable.choicepair, "^%x+:%x+:%x+:%x+:%x+:%x+$") then
				debug("ubus -t 2 call apmgr choicepair '{\"mac\":\"%s\"}'" %{paramTable.choicepair})
				os.execute("ubus -t 2 call apmgr choicepair '{\"mac\":\"%s\"}'" %{paramTable.choicepair})
			else
				debug("Invalid BSSID format: "..paramTable.choicepair)
			end
			return
		end
	end
	debug("mesh set:  unknow param, do nothing")
end

function module_get(param)
    local paramTable = {}
    local data = {}
	
	if param == nil then
		debug("mesh get: input param is nil, do nothing!")
	end
	paramTable = dkjson.decode(param)
    debug("mesh get")
    if paramTable and paramTable.pairstatus then
		local ifname2G = uci:get("wifiinfo", 'band_2g', 'ext_ifname') or ''
		if ifname2G ~= '' then
			debug("wappctrl ra0 wapp set_partialscan %s0 1" %{ifname2G})
			os.execute("wappctrl ra0 wapp set_partialscan %s0 1" %{ifname2G})
		end
        local MultiNetwork = uci:get("apmgr",'global','MultiNetwork') or '0'
		debug("mesh get: get pairstatus from apmgr.global.MultiNetwork="..MultiNetwork)
        data.pairstatus = MultiNetwork == "1" and "true" or "false"
        return dkjson.encode(data) 
	end

    if paramTable then
		if paramTable.meshlist then
			debug("mesh get: get meshlist from "..meshListFile)
			local meshlist = {}
			local total = 0
			if fs.access(meshListFile) then
				local fp = io.popen("cat "..meshListFile, "r")
				if fp then
					local line
					repeat 
						line = fp:read("*l")
						if line then
							local option = line:split(";")
							meshlist[#meshlist + 1] = {
								model = option[1],
								mac = option[2]
							}
						end
					until not line
					fp:close()
				end
			end
			data.meshlist = meshlist
			data.total = #meshlist
			return dkjson.encode(data)
		elseif paramTable.routelist then
			local rlist = {}
			local bcnie = ""
			debug("mesh get: starting")
			debug("ubus -t 2 call apmgr routescan")
			os.execute("ubus -t 2 call apmgr routescan")
			for i=1, 13, 1 do
				debug("mesh get: times: "..i)
				bcnie = route_list_get()
				if bcnie ~= "" then
					rlist = dkjson.decode(bcnie)
					if rlist and rlist.count then
						debug("mesh get: get count: "..rlist.count)
						if rlist.count ~= "0" then
							debug("mesh get: ok!")
							return bcnie
						else
							debug("mesh get: get count: 0, continue")
						end
					else
						debug("mesh get: cant get count, continue")
					end
				end
				if i ~= 10 then
					os.execute("sleep 1");
				end
			end
			debug("mesh get: finish")
			data.list = {}
			data.count = 0
			return dkjson.encode(data)
		end
    end
	debug("mesh get:  unknow param, do nothing")
	return dkjson.encode(data)
end
