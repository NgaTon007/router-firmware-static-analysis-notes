#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("user_group",package.seeall)

local cjson = require "cjson"
local lfs = require "lfs"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/user_group/web/"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "user_group_get.log", 800, module_debug.INFO, "1");
end

--@user_group_get
function user_group_get(param)
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################");
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"-1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return "{\"code\":\"-1\",\"msg\":\"param is nil!\"}"
    end

    if (param_tab["type"] == nil) then
        param_tab["type"] = "all"
    end
    
    if (param_tab["type"] == "all") then
        local t1 = io.popen("/usr/sbin/user_mgr_cmd.elf -Q -t all")
        config_tab = t1:read("*all")
        t1:close()
    elseif (param_tab["type"] == "auth") then
        local t1 = io.popen("/usr/sbin/user_mgr_cmd.elf -Q -t auth")
        config_tab = t1:read("*all")
        t1:close()
    elseif (param_tab["type"] == "static") then
        local t1 = io.popen("/usr/sbin/user_mgr_cmd.elf -Q -t static")
        config_tab = t1:read("*all")
        t1:close()
    else
        local t1 = io.popen("/usr/sbin/user_mgr_cmd.elf -Q -t all")
        config_tab = t1:read("*all")
        t1:close()
    end
    
    module_debug.lua_debug(module_debug.INFO, "################################GET END################################");
    return config_tab
end
--------------------------------------------------------------------------------------------
--@module_get
function module_get(param)
    debug_init();

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param %s", param)
        end
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    
    config_tab = user_group_get(param);
    return config_tab
end
----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end