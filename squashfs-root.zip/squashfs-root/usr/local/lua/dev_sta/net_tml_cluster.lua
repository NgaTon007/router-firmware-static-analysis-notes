#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_cluster",package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml_cluster.lock"

--cjson.encode_empty_table_as_object(false)

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_cluster.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.ERROR, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.ERROR, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end
-- 过滤字符串中的乱码
local function filter_name_string(str)
    ss = {}
	for k = 1, #str do
		local c = string.byte(str,k)  
		if not c then break end
        -- 判断是否是字母/数字/#-_.@符号
		if (c >= 32 and c <= 127) then
            ss[#ss+1] = string.char(c)
        -- 判断是否是中文字符
        elseif c >= 228 and c <= 233 then  
            local c1 = string.byte(str,k+1)
            local c2 = string.byte(str,k+2)
            if c1 and c2 then
                local a1,a2,a3,a4 = 128,191,128,191
                if c == 228 then
                    a1 = 184
                elseif c == 233 then
                    a2,a4 = 190,c1 ~= 190 and 191 or 165
                end
                if c1 >= a1 and c1 <= a2 and c2 >= a3 and c2 <= a4 then
                    k = k + 2
                    ss[#ss+1] = string.char(c,c1,c2)
                end
            end
        end
    end
    if #ss > 0 then
        for index = 1, #ss do
            if index == 1 then
                ret = ss[index]
            else 
                ret = ret..ss[index]
            end
        end
        module_debug.lua_debug(module_debug.INFO, "ret %s", ret)
        return ret
    end
    return
    
end

-- 将终端管理返回的数据进行处理
local function cluster_rule_array(rule_type, rule_val)

    local table_info = {}
    table_info["val"] = rule_val
    table_info["type"] = rule_type   
   return table_info
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)
    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))
    flag = 0
    rule_date = {}
    rule_date["cluster_rule"] = {}

    if (sh_ret["code"] == "0") then
        if (sh_ret["oui"] ~= "") then
            flag = 1
            table.insert(rule_date["cluster_rule"], cluster_rule_array("oui", sh_ret["oui"]))
        end
        if (sh_ret["type"] ~= "") then
            flag = 1
            table.insert(rule_date["cluster_rule"], cluster_rule_array("type", sh_ret["type"]))
        end
        if (sh_ret["hostname"] ~= "") then
            flag = 1
            -- 这个hostname有BUG 当中英文同时出现在hostname中时会有乱码符号  暂时先在脚本中过滤掉乱码  后期再改进
            sh_ret["hostname"] = filter_name_string(sh_ret["hostname"])
            if (sh_ret["hostname"] ~= nil) then
                table.insert(rule_date["cluster_rule"], cluster_rule_array("hostname", sh_ret["hostname"]))
            end 
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [ubus_cmd] ubus execute fail!")
        return
    end
    if (flag == 0) then
        return "{\"cluster_rule\":[]}"
    end

    sh_ret = cjson.encode(rule_date)
    return sh_ret
end

--@net_tml_cluster_get
function net_tml_cluster_get(param)
    module_debug.lua_debug(module_debug.INFO, "###############################GETETE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: Input data is not json mode.")
        return
    end

    local param_tab = cjson.decode(param)
    local mac_list

    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param_tab is nil")
        return
    end
    for k,v in pairs(param_tab["nt_info"]) do
        if (v["mac"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] mac is nil")
            return
        end
        if (k > 1) then
            mac_list = mac_list..","
        end
        if (k == 1) then
            mac_list = v["mac"]
        end
        if (k > 1) then
            mac_list = mac_list..v["mac"]
        end
    end
    ubus_cmd = "ubus call nt_mgr.cluster_nlys set '{\"mac\":\""..mac_list.."\"}'"
    grp_rule = ubus_cmd_exe(ubus_cmd)
    if (grp_rule == nil) then
        return
    end
    module_debug.lua_debug(module_debug.INFO, "grp_rule %s", grp_rule)
    
    module_debug.lua_debug(module_debug.INFO, "################################GET END################################")
    return grp_rule
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"cluster_rule":[]}'
    return default_config
end

--@module_get
function module_get(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"code\":\"-1\",\"msg\":\"There is instance process running!\"}"
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] param is nil")
        end
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"param is unsafe!\"}"
    end
    config_tab = net_tml_cluster_get(param)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_get] net_tml_cluster_get is nil")
        os.remove(LOCK_FILE)
        return "{\"code\":\"-1\",\"msg\":\"get net_tml_cluster is fail!\"}"
    end
    os.remove(LOCK_FILE)
    return config_tab
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end