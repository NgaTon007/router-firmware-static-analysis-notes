#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("pppoeserver_user_timeout", package.seeall);
cjson = require "cjson"
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
require "public_module"
require("uci")

local sd_cfg = "/etc/sd_config/single/pppoeserver_user.json"

----------枚举初始化---------
function CreatEnumTable(tb, index)  
    local enumtb = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tb) do 
        enumtb[v] = enumindex + i 
    end 
    return enumtb
end 
----------lua通用错误码-----------------
local g_err_code = {"ERR_PARAM", "ERR_FILE_WRITE", "ERR_FILE_NOT_EXIST","ERR_UBUS_CONNECT"}
local g_err_code = CreatEnumTable(g_err_code, 200)
--return output(1, g_err_code["ERR_PARAM"], "rate_limit_set failed:param error")

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_user_timeout.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

function module_default_config_get()
    os.execute("cp "..def_cfg.." "..sd_cfg);
    return file_read(sd_cfg)
end

function guid()
        local template ="xxxxxxxxxxxxxxxxxxxx"---xxxx-xxxx-xxxxxxxxxxxx"
        local d = io.open("/dev/urandom", "r"):read(4)
		local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)
		--os.time()  + d:byte(1) --+ (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 4294967296)
        math.randomseed(num)
        return string.upper(string.gsub(template, "x", function (c)
                                        local v = (c == "x") and math.random(0, 0xf) or math.random(8, 0xb)
                                                return string.format("%x", v)
                                        end
                        ))
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if file == nil then
        return
    end    
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

--ret(uint)表示是否返回结果给web,0表示不返回，0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

function module_get()
    local timeout = "{}"
    local timeout_json = cjson.decode(timeout)
    local old_data = file_read(sd_cfg)
    if old_data == nil then
        return '{}'
    end
    local old_json = cjson.decode(old_data)
    local old_length = table.maxn(old_json.list)
    local num = 1
    local year_c = 2020
    local dealline
    local cur_time
    local user_time
    
    while ( num < old_length + 1 )
    do
        repeat
        if(old_json.list[num].dealline == "" or old_json.list[num].enable == '0') 
        then
            num = num + 1
            break 
        end
		local _, _, deal_y, deal_m, deal_d = string.find(old_json.list[num].dealline, "(%d+)-(%d+)-(%d+)")
        local _, _, cur_y, cur_m, cur_d = string.find(os.date("%Y-%m-%d", os.time()), "(%d+)-(%d+)-(%d+)")
        local name = old_json.list[num].name
        local year_num = tonumber(deal_y) - tonumber(cur_y)
        
        lib_debug.lua_debug(lib_debug.DEBUG, "name:%s year_num:%d\n", name, year_num)
        if (year_num > 1)
        then
            num = num + 1
            break 
        elseif(year_num == 1)
        then
            dealline = os.time({year = year_c + 1, month = deal_m, day =deal_d, hour =00, min =00, sec = 00})
            cur_time = os.time({year = year_c, month = cur_m, day =cur_d, hour =00, min =00, sec = 00})
        elseif(year_num == 0)
        then
            dealline = os.time({year = year_c, month = deal_m, day =deal_d, hour =00, min =00, sec = 00})
            cur_time = os.time({year = year_c, month = cur_m, day =cur_d, hour =00, min =00, sec = 00})
        else
            timeout_json[name] = old_json.list[num].dealline
            num = num + 1
            break 
        end
        
        user_time = math.modf( (dealline - cur_time) / 86400 )  
        
        lib_debug.lua_debug(lib_debug.DEBUG, "name:%s user_time:%d\n", name, user_time)
        if ( user_time <= 10 ) 
        then
            timeout_json[name] = old_json.list[num].dealline
        end

        num = num + 1
        until true
    end
    
    return cjson.encode(timeout_json)
    
end
