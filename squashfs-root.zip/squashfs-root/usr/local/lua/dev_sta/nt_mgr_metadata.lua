#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("nt_mgr_metadata", package.seeall)
local lfs = require "lfs"
local cjson = require "cjson"
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/nt_mgr_metadata.lock"
local JSON_FILE_DIR = "/tmp/nt_json/"
local METADATA_FILE = "nt_metadata.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "nt_mgr_metadata.log", 100, module_debug.DEBUG, "1")
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 获取最新的厂商表文件
local function get_latest_metadata_file()
    local latest_file = nil
    for file in lfs.dir(JSON_FILE_DIR) do
        if file:match("^(%d+)_" .. METADATA_FILE .. "$") then
            if not latest_file or file > latest_file then
                latest_file = file
            end
        end
    end
    if latest_file then
        return JSON_FILE_DIR .. latest_file
    else
        return nil
    end
end

--@module_get
function module_get()
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return "{\"err\":{\"rcode\":\"00500001\",\"rmsg\":\"There is instance process running!\"},\"code\":\"1\"}"
    end
    module_debug.lua_debug(module_debug.INFO, "###############################GET###############################")

    local metadata_file = get_latest_metadata_file()
    if not metadata_file then
        module_debug.lua_debug(module_debug.ERROR, "No metadata file found")
        os.remove(LOCK_FILE)
        return "{\"rcode\":\"00000000\",\"rmsg\":\"No metadata file found!\"}"
    end
    module_debug.lua_debug(module_debug.INFO, "using metadata file: %s", metadata_file)
    local content = tool.file_read(metadata_file, "r")
    local success, result = pcall(cjson.decode, content)
    if success == false then
        module_debug.lua_debug(module_debug.ERROR, "json decode failed: %s", result)
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500003\",\"rmsg\":\"JSON decode failed!\"},\"code\":\"1\"}"
    end
    if not result["list"] or #result["list"] == 0 then
        module_debug.lua_debug(module_debug.ERROR, "metadata list is empty or not exist")
        os.remove(LOCK_FILE)
        return "{\"err\":{\"rcode\":\"00500004\",\"rmsg\":\"Metadata list is empty!\"},\"code\":\"1\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "###############################GET END###############################")
    os.remove(LOCK_FILE)
    return cjson.encode(result)
end
