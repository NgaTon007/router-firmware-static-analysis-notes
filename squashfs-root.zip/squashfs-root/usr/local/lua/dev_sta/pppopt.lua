#! /usr/bin/lua
module("pppopt", package.seeall)
local cjson = require "cjson"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local ldebug = require "utils.debug"
local libc2lua = require("libc2lua")
local DEFAULT_PPP_OPTIONS_FILE = "/etc/ppp/options"
local PPP_OPTIONS_FILE = DEFAULT_PPP_OPTIONS_FILE
local PPP_OPTIONS_FILE_TMP = DEFAULT_PPP_OPTIONS_FILE.."_tmp"
local PPP_LOCK_FILE = "/tmp/debug/rp-pppoe/pppopt_lock"
local g_ifname = ""

local error_code = {
    SUCCESS =           { code = "0", rcode = "00000000", message = "" },
    UNSINGLE =          { code = "1", rcode = "06251001", message = "There is instance process running" },
    PARAMETER_ILLEGAL = { code = "1", rcode = "06251002", message = "Parameter is illegal" },
    FAILED =            { code = "1", rcode = "06251003", message = "Set configuration failed" },
}

local CAMEL_TO_OPTION = {
    lcpEchoFailure = "lcp-echo-failure",
    lcpEchoInterval = "lcp-echo-interval"
}

local OPTION_TO_CAMEL = {
    ["lcp-echo-failure"] = "lcpEchoFailure",
    ["lcp-echo-interval"] = "lcpEchoInterval"
}

-- DEBUG��ʼ��
ldebug.debug_init("/tmp/debug/rp-pppoe/", "pppopt.log", 50, ldebug.INFO, "1")

-- ����pppdӦ�������ã�ֻ������Ӧ�ӿڵ�pppd���̣�������޸�Ĭ�ϵ������ļ�������������pppd����
local function pppopt_apply()
    local cmd = ""

    if (g_ifname ~= nil and g_ifname ~= "") then
        cmd = "ppppid=$(ps -wwf | grep ppp | grep 'ipparam "
            .. g_ifname
            .. " ' | awk '{print $2}' 2>/dev/null); "
            .. "if [ ! -z \"$ppppid\" ]; then kill -9 $ppppid 2>/dev/null; fi &"
    else
        cmd = "killall pppd >/dev/null 2>/dev/null &"
    end
    os.execute("sync")
    os.execute(cmd)
    ldebug.lua_debug(ldebug.INFO, "execute success:[%s]", cmd)

    return true
end

local function single_instance_check(lockfile)
    --��ֹ����
    if (tool.file_exist(lockfile) == true) then
        local lfs = require "lfs"
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change)
        local current_time = tonumber(os.time())
        local lifetime = current_time - change_time
        if (lifetime > 120) then
            os.remove(lockfile)
        end
    end

    if (tool.file_exist(lockfile) == true) then
        ldebug.lua_debug(ldebug.WARNING, "single instance check failed")
        return false
    else
        ldebug.lua_debug(ldebug.DEBUG, "single instance check passed")
        tool.file_write(lockfile, "running", "w")
        return true
    end
end

local function pppopt_file_create(path)
    if (tool.file_exist(path) == true) then
        return true
    end

    local fh = io.open(path, "w")
    if (fh == nil) then
        ldebug.lua_debug(ldebug.ERROR, "create file failed:[%s]", path)
        return false
    end
    fh:close()

    return true
end

local function pppopt_lines_read(path)
    local lines = {}
    local fh = io.open(path, "r")
    if (fh == nil) then
        return lines
    end
    for line in fh:lines() do
        table.insert(lines, line)
    end
    fh:close()
    return lines
end

local function pppopt_lines_write(path, lines)
    local fh, err = io.open(path, "w")
    if (fh == nil) then
        ldebug.lua_debug(ldebug.ERROR, "open:[%s] failed:[%s]", path, err or "")
        return false
    end
    if (#lines > 0) then
        fh:write(table.concat(lines, "\n"))
        fh:write("\n")
    end
    fh:close()
    return true
end

local function pppopt_collect_updates(params)
    local updates = {}
    if (params == nil) then
        return updates
    end

    for camel, option_key in pairs(CAMEL_TO_OPTION) do
        local value = params[camel]
        if (value ~= nil) then
            local val_str = tostring(value)
            if (string.match(val_str, "^%d+$") == nil) then
                ldebug.lua_debug(ldebug.ERROR, "option:[%s] value:[%s] illegal", camel, val_str)
                return nil, "PARAMETER_ILLEGAL"
            end
            updates[option_key] = val_str
        end
    end

    return updates
end

local function pppopt_apply_updates(lines, updates)
    if (updates == nil or next(updates) == nil) then
        return lines or {}
    end

    local touched = {}
    local new_lines = {}

    for _, line in ipairs(lines) do
        local stripped = line:match("^%s*(.-)%s*$")
        local key = nil
        if (stripped ~= "") then
            if (stripped:sub(1, 1) == "#") then
                key = stripped:sub(2):match("^%s*(%S+)")
            else
                key = stripped:match("^(%S+)")
            end
        end

        local value = key and updates[key]
        if (value == nil) then
            table.insert(new_lines, line)
        else
            touched[key] = true
            ldebug.lua_debug(ldebug.INFO, "set option:[%s] [%s]", key, value)
            table.insert(new_lines, string.format("%s %s", key, value))
        end
    end

    for key, value in pairs(updates) do
        if (touched[key] ~= true) then
            ldebug.lua_debug(ldebug.INFO, "add option: %s %s", key, value)
            table.insert(new_lines, string.format("%s %s", key, value))
        end
    end

    return new_lines
end

local function pppopt_set(updates)
    if (updates == nil or next(updates) == nil) then
        ldebug.lua_debug(ldebug.INFO, "no valid options to update")
        return true
    end

    if (pppopt_file_create(PPP_OPTIONS_FILE) ~= true) then
        ldebug.lua_debug(ldebug.ERROR, "ensure file %s failed", PPP_OPTIONS_FILE)
        return false
    end

    local options_line = pppopt_lines_read(PPP_OPTIONS_FILE)
    local new_lines = pppopt_apply_updates(options_line, updates)
    if (new_lines == nil or #new_lines == 0) then
        ldebug.lua_debug(ldebug.ERROR, "no lines to write to %s", PPP_OPTIONS_FILE_TMP)
        return false
    end

    if (pppopt_lines_write(PPP_OPTIONS_FILE_TMP, new_lines) ~= true) then
        ldebug.lua_debug(ldebug.ERROR, "write temporary file:[%s] failed", PPP_OPTIONS_FILE_TMP)
        return false
    end

    local ret, rename_err = os.rename(PPP_OPTIONS_FILE_TMP, PPP_OPTIONS_FILE)
    if (ret ~= true) then
        ldebug.lua_debug(ldebug.ERROR, "rename:[%s]->[%s] failed:[%s]", PPP_OPTIONS_FILE_TMP, PPP_OPTIONS_FILE, tostring(rename_err))
        os.remove(PPP_OPTIONS_FILE_TMP)
        return false
    end

    return true
end

local function pppopt_result_edit(result, trimmed)
    local raw_key, rest = trimmed:match("^(%S+)%s*(.*)$")
    if (raw_key == nil or raw_key == "") then
        return result
    end

    local camel = OPTION_TO_CAMEL[raw_key]
    if (camel ~= nil and rest ~= nil and rest ~= "") then
        result[camel] = rest
    end

    return result
end

local function pppopt_get()
    if (tool.file_exist(PPP_OPTIONS_FILE) ~= true) then
        return "{}"
    end
    ldebug.lua_debug(ldebug.DEBUG, "reading options from file: %s", PPP_OPTIONS_FILE)

    local lines = pppopt_lines_read(PPP_OPTIONS_FILE)
    local result = {}

    for _, line in ipairs(lines) do
        local trimmed = line:match("^%s*(.-)%s*$")
        if (trimmed ~= nil and trimmed ~= "") then
            result = pppopt_result_edit(result, trimmed)
        end
    end

    return cjson.encode(result)
end

-- �ж��ļ��Ƿ���ڣ��������ڣ����Ĭ��λ�ø���
local function pppopt_file_check()
    if (tool.file_exist(PPP_OPTIONS_FILE) == false) then
        local cmd = table.concat({"cp ", DEFAULT_PPP_OPTIONS_FILE, " ", PPP_OPTIONS_FILE, " 2>/dev/null"})
        os.execute(cmd)
        ldebug.lua_debug(ldebug.INFO, "success:[%s]", cmd)
    end
end

local function pppopt_uci_list_get()
    local intfs = {}

    uci:foreach("network", "interface", function(section)
        local ifname = section[".name"]
        if (ifname ~= nil and section.proto == "pppoe") then
            ldebug.lua_debug(ldebug.INFO, "found network interface:[%s]", ifname)
            table.insert(intfs, ifname)
        end
    end)

    return intfs
end

local function pppopt_file_list_get()
    local intfs = {}

    -- ִ�� shell ��������ļ�
    local p = io.popen('ls /etc/ppp/options.wan* 2>/dev/null')
    if (p == nil) then
        ldebug.lua_debug(ldebug.INFO, "No options files found")
        return intfs
    end
    for filename in p:lines() do
        -- ��ȡ�ļ�����ȥ·����
        local basename = filename:match("^.+/(.+)$") or filename
        -- ȥ��ǰ׺ options.��ʣ�µ��Ǻ�׺
        local suffix = basename:match("^options%.(.+)$")
        if suffix then
            table.insert(intfs, suffix)
        end
    end
    p:close()
    ldebug.lua_debug(ldebug.DEBUG, "found options files:[%s]", cjson.encode(intfs))

    return intfs
end

-- ��ȡ /etc/ppp/options.wan* �ļ��б���������� options_intf �У���ɾ��
local function pppopt_obsolete_del(options_intf)
    local exist_intfs = pppopt_file_list_get()
    if (#exist_intfs == 0) then
        ldebug.lua_debug(ldebug.INFO, "no existing options files to delete")
        return true
    end
    ldebug.lua_debug(ldebug.DEBUG, "exist options_intf:[%s]", cjson.encode(options_intf))

    for _, ifname in ipairs(exist_intfs) do
        local option_file = DEFAULT_PPP_OPTIONS_FILE.."."..ifname
        local found = false
        for _, existing in ipairs(options_intf) do
            if (option_file == existing) then
                found = true
                break
            end
        end
        if (found == false) then
            os.remove(option_file)
            ldebug.lua_debug(ldebug.INFO, "removed obsolete options file:[%s]", option_file)
        end
    end

    return true
end

local function pppopt_diff_check(params)
    local old_json = pppopt_get()
    if (old_json == nil or old_json == "") then
        ldebug.lua_debug(ldebug.INFO, "intf:[%s] has no old options", g_ifname)
        return false, {}
    end
    local old_params = cjson.decode(old_json)
    if (old_params == nil or type(old_params) ~= "table") then
        ldebug.lua_debug(ldebug.INFO, "intf:[%s] old options decode failed", g_ifname)
        return false, {}
    end

    local updates, err_code = pppopt_collect_updates(params)
    if (err_code ~= nil) then
        return false, nil, err_code
    end

    if (updates == nil or next(updates) == nil) then
        ldebug.lua_debug(ldebug.INFO, "intf:[%s] no valid options provided", g_ifname)
        return false, {}
    end

    for camel, option_key in pairs(CAMEL_TO_OPTION) do
        local old_value = old_params[camel] or ""
        local new_value = updates[option_key] or ""
        if (old_value ~= new_value) then
            ldebug.lua_debug(ldebug.INFO, "intf:[%s] [%s]:[%s]->[%s]", g_ifname, option_key, old_value, new_value)
            return true, updates
        end
    end
    ldebug.lua_debug(ldebug.INFO, "intf:[%s] no diff between old and new options", g_ifname)

    return false, {}
end

local function pppopt_all_set(input_json)
    local options_intf = {}
    for ifname, params in pairs(input_json) do
        if (ifname == nil or ifname == "") then
            ldebug.lua_debug(ldebug.INFO, "invalid key in input_json")
            return false
        end
        if (type(params) ~= "table") then
            ldebug.lua_debug(ldebug.INFO, "invalid value for key:[%s] in input_json", ifname)
            return false
        end

        g_ifname = ifname
        PPP_OPTIONS_FILE = DEFAULT_PPP_OPTIONS_FILE.."."..g_ifname
        PPP_OPTIONS_FILE_TMP = DEFAULT_PPP_OPTIONS_FILE.."_tmp."..g_ifname
        ldebug.lua_debug(ldebug.INFO, "options:[%s] options_tmp:[%s]", PPP_OPTIONS_FILE, PPP_OPTIONS_FILE_TMP)
        pppopt_file_check()

        local changed, updates, err_code = pppopt_diff_check(params)
        if (err_code ~= nil) then
            return false, err_code
        end

        if (changed == true) then
            if (pppopt_set(updates) == false) then
                ldebug.lua_debug(ldebug.INFO, "set failed key:[%s]", ifname)
                return false
            end
            pppopt_apply()
        end

        table.insert(options_intf, PPP_OPTIONS_FILE)
    end
    ldebug.lua_debug(ldebug.INFO, "options_intf:[%s]", cjson.encode(options_intf))

    if (pppopt_obsolete_del(options_intf) ~= true) then
        ldebug.lua_debug(ldebug.INFO, "pppopt_obsolete_del failed")
        return false
    end

    return true
end

local function pppopt_proto_check(intfs)
    if (intfs == nil or #intfs == 0) then
        ldebug.lua_debug(ldebug.INFO, "no interfaces to check proto")
        return true
    end

    -- ������������proto����pppoe����ɾ���ýӿ�
    for i = #intfs, 1, -1 do
        local ifname = intfs[i]
        local proto = uci:get("network", ifname, "proto")
        if (proto ~= "pppoe") then
            ldebug.lua_debug(ldebug.INFO, "interface:[%s] proto:[%s] is not pppoe, deleted", ifname, tostring(proto))
            table.remove(intfs, i)
        end
    end

    return true
end

function module_set(param)
    if (param == nil) then
        ldebug.lua_debug(ldebug.ERROR, "input is empty")
        return cjson.encode(error_code["PARAMETER_ILLEGAL"])
    end
    ldebug.lua_debug(ldebug.INFO, "******** START ********\nInput:[%s]", param)

    -- ��ʵ�����м��
    if (single_instance_check(PPP_LOCK_FILE) == false) then
        return cjson.encode(error_code["UNSINGLE"])
    end

    -- ������ʽУ�� - JSON��ʽ
    if (tool.json_check(param) == false) then
        os.remove(PPP_LOCK_FILE)
        ldebug.lua_debug(ldebug.ERROR, "input is not in json format")
        return cjson.encode(error_code["PARAMETER_ILLEGAL"])
    end

    -- ������ȫ��У�� - ����У���
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        os.remove(PPP_LOCK_FILE)
        ldebug.lua_debug(ldebug.ERROR, "lua_param_safety_check failed")
        return cjson.encode(error_code["PARAMETER_ILLEGAL"])
    end

    -- �����Ϸ���У�� - ��Ҫ���� caller �ֶ�
    local input_json = cjson.decode(param)
    if (input_json == nil or input_json.caller == nil or input_json.caller == "") then
        os.remove(PPP_LOCK_FILE)
        ldebug.lua_debug(ldebug.ERROR, "invalid input_json -- empty or caller lost")
        return cjson.encode(error_code["PARAMETER_ILLEGAL"])
    end

    local intfs_json = input_json.intfs
    if (intfs_json == nil or type(intfs_json) ~= "table") then
        os.remove(PPP_LOCK_FILE)
        ldebug.lua_debug(ldebug.ERROR, "invalid input_json -- empty or intfs lost")
        return cjson.encode(error_code["PARAMETER_ILLEGAL"])
    end

    -- �����ӿڲ���������
    local ret, err_code = pppopt_all_set(intfs_json)
    if (ret == false) then
        os.remove(PPP_LOCK_FILE)
        ldebug.lua_debug(ldebug.INFO, "set configuration failed")
        if (err_code ~= nil and error_code[err_code] ~= nil) then
            return cjson.encode(error_code[err_code])
        end
        return cjson.encode(error_code["FAILED"])
    end
    os.remove(PPP_LOCK_FILE)
    ldebug.lua_debug(ldebug.INFO, "******** END ********")

    return cjson.encode(error_code["SUCCESS"])
end

function module_get(param)
    local intfs = nil
    local results = {}
    local result_intfs = {}

    -- Я���������򰴲����еĽӿ��б���ȡ����
    if (param ~= nil and param ~= "") then
        ldebug.lua_debug(ldebug.INFO, "module_get called - param:[%s]", param)
        -- ������ʽУ�� - JSON��ʽ
        if (tool.json_check(param) == false) then
            ldebug.lua_debug(ldebug.ERROR, "input is not in json format")
            return cjson.encode(error_code["PARAMETER_ILLEGAL"])
        end

        -- ������ȫ��У�� - ����У���
        if (libc2lua.lua_param_safety_check(param) ~= true) then
            ldebug.lua_debug(ldebug.ERROR, "lua_param_safety_check failed")
            return cjson.encode(error_code["PARAMETER_ILLEGAL"])
        end

        -- ����intfs��������ȡ�ӿ��б�
        local input_json = cjson.decode(param)
        if (input_json == nil or input_json.intfs == nil or input_json.intfs == "") then
            ldebug.lua_debug(ldebug.ERROR, "invalid input_json -- empty or intfs lost")
            return cjson.encode(error_code["PARAMETER_ILLEGAL"])
        end
        if (type(input_json.intfs) ~= "table") then
            ldebug.lua_debug(ldebug.ERROR, "invalid input_json -- intfs is not table")
            return cjson.encode(error_code["PARAMETER_ILLEGAL"])
        end
        intfs = input_json.intfs
    end

    -- ���ӿ��б�Ϊ�գ����UCI�����л�ȡ���нӿڵ�����
    if (intfs == nil or #intfs == 0) then
        intfs = pppopt_uci_list_get()
        if (#intfs == 0) then
            return "{}"
        end
    end
    ldebug.lua_debug(ldebug.DEBUG, "get intfs:[%s]", cjson.encode(intfs))

    -- ���ӿڶ�Ӧ��proto����pppoe�����޳��ýӿ�
    local ret = pppopt_proto_check(intfs)
    if (ret == false) then
        ldebug.lua_debug(ldebug.INFO, "pppopt_proto_check done, but no valid interfaces left")
        return "{}"
    end

    -- ����intfs����ȡ���нӿڵ�����
    for _, ifname in ipairs(intfs) do
        g_ifname = ifname
        PPP_OPTIONS_FILE = DEFAULT_PPP_OPTIONS_FILE.."."..g_ifname
        PPP_OPTIONS_FILE_TMP = DEFAULT_PPP_OPTIONS_FILE.."_tmp."..g_ifname
        ldebug.lua_debug(ldebug.DEBUG, "options:[%s] options_tmp:[%s]", PPP_OPTIONS_FILE, PPP_OPTIONS_FILE_TMP)
        pppopt_file_check()
        local res = pppopt_get()
        if (res == nil or res == "") then
            res = "{}"
        end
        result_intfs[g_ifname] = cjson.decode(res)
    end
    results["intfs"] = result_intfs

    return cjson.encode(results)
end
