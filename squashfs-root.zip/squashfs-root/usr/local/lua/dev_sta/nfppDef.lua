#! /usr/bin/env lua

module_name = "nfppDef"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"
nfpp_manager = require("nfpp_manager")

----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 500, module_debug.DEBUG, "1")

-- default config
function module_get()

    return nfpp_manager.get_nfpp_defcfg_json()
end
