#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("rlog_config", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local dkjson = require("dkjson");
local min_upload_prd = 0;
local max_upload_prd = 86400;
local min_retrans_prd = 1;
local max_retrans_prd = 3600;
local min_retrans_file = 1;
local max_retrans_file = 20;
local min_retrans_stream = 1;
local max_retrans_stream = 20;
local min_stream_len = 1;
local max_stream_len = 51200;
local min_uploadTimeout = 3;
local max_uploadTimeout = 30;

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/rlog/", "rlog_config.lua.log", 100, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};

    result["rcode"] = code;
    result["rmsg"] = string.format(msg, ...);
    res = result;

    res = {
        err = result;
        code = "1";
    };

    local json_str = require("dkjson").encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return require("dkjson").encode(res);
end

-- @rlog_config_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_config_get()********************");

    local tab = {};
    local uci = require("luci.model.uci").cursor();
    uci:foreach("rlog", "rlog",
    function(s)
        if (s["enable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.enable=%s", s["enable"]);
            tab["enable"] = s["enable"];
        end
        if (s["server"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.server=%s", s["server"]);
            tab["server"] = s["server"];
        end
        if (s["protocol"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.protocol=%s", s["protocol"]);
            tab["protocol"] = s["protocol"];
        end
        if (s["uploadPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.uploadPeriod=%s", s["uploadPeriod"]);
            tab["uploadPeriod"] = s["uploadPeriod"];
        end
        if (s["logLevel"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.logLevel=%s", s["logLevel"]);
            tab["logLevel"] = s["logLevel"];
        end
        if (s["tarsaveAll"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.tarsaveAll=%s", s["tarsaveAll"]);
            tab["tarsaveAll"] = s["tarsaveAll"];
        end
        if (s["retransEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransEnable=%s", s["retransEnable"]);
            tab["retransEnable"] = s["retransEnable"];
        end
        if (s["retransPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransPeriod=%s", s["retransPeriod"]);
            tab["retransPeriod"] = s["retransPeriod"];
        end
        if (s["retransFileLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransFileLimit=%s", s["retransFileLimit"]);
            tab["retransFileLimit"] = s["retransFileLimit"];
        end
        if (s["retransStreamLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.retransStreamLimit=%s", s["retransStreamLimit"]);
            tab["retransStreamLimit"] = s["retransStreamLimit"];
        end
        if (s["streamLenLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.streamLenLimit=%s", s["streamLenLimit"]);
            tab["streamLenLimit"] = s["streamLenLimit"];
        end
        if (s["tlscafil"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.tlscafil=%s", s["tlscafil"]);
            tab["tlscafil"] = s["tlscafil"];
        end
        if (s["domainSuffix"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get rlog.global.domainSuffix=%s", s["domainSuffix"]);
            tab["domainSuffix"] = s["domainSuffix"];
        end
    end);

    local json_str = require("dkjson").encode(tab);
    libdbg.lua_debug(libdbg.INFO, "End rlog_get() json_str:%s\n", json_str);

    return json_str;
end

-- @rlog_config_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ

    -- �������
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "rlog_config set parameter is nil");
        return module_ret("0012", "rlog_config set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_sta set -m rlog_config '%s'", param);

    -- ��������
    local tab = require("dkjson").decode(param);
    -- ����������enable
    if (tab["enable"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:enable is nil");
    elseif (type(tab["enable"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter server is invalid, require string");
        return module_ret("0014", "parameter server is invalid, require string");
    end
    -- ����������server
    if (tab["server"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:server is nil");
    elseif (type(tab["server"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter server is invalid, require string");
        return module_ret("0014", "parameter server is invalid, require string");
    end
    -- ����������protocol
    if (tab["protocol"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:protocol is nil");
    elseif (type(tab["protocol"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter protocol is invalid, require string");
        return module_ret("0014", "parameter protocol is invalid, require string");
    end
    -- ����������uploadPeriod
    if (tab["uploadPeriod"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:uploadPeriod is nil");
    elseif (tonumber(tab["uploadPeriod"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter uploadPeriod is invalid, require string number");
        return module_ret("0014", "parameter uploadPeriod is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["uploadPeriod"]) < min_upload_prd or tonumber(tab["uploadPeriod"]) > max_upload_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter uploadPeriod is invalid, value range [%d-%d]", min_upload_prd, max_upload_prd);
        return module_ret("0014", string.format("parameter uploadPeriod is invalid, value range [%d-%d]", min_upload_prd, max_upload_prd));
    end
    -- ����������uploadTimeout
    if (tab["uploadTimeout"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:uploadTimeout is nil");
    elseif (tonumber(tab["uploadTimeout"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter uploadTimeout is invalid, require string number");
        return module_ret("0014", "parameter uploadTimeout is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["uploadTimeout"]) < min_uploadTimeout or tonumber(tab["uploadTimeout"]) > max_uploadTimeout) then
        libdbg.lua_debug(libdbg.ERROR, "parameter uploadTimeout is invalid, value range [%d-%d]", min_uploadTimeout, max_uploadTimeout);
        return module_ret("0014", string.format("parameter uploadTimeout is invalid, value range [%d-%d]", min_uploadTimeout, max_uploadTimeout));
    end
    -- ����������logLevel
    if (tab["logLevel"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:logLevel is nil");
    elseif (type(tab["logLevel"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter logLevel is invalid, require string");
        return module_ret("0014", "parameter logLevel is invalid, require string");
    end
    -- ����������tarsaveAll
    if (tab["tarsaveAll"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:tarsaveAll is nil");
    elseif (tonumber(tab["tarsaveAll"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter tarsaveAll is invalid, require string number");
        return module_ret("0014", "parameter tarsaveAll is invalid, require string number");
    elseif (tonumber(tab["tarsaveAll"]) ~= 0 and tonumber(tab["tarsaveAll"]) ~= 1) then
        libdbg.lua_debug(libdbg.ERROR, "parameter tarsaveAll is invalid, out of range <0|1>");
        return module_ret("0014", "parameter tarsaveAll is invalid, out of range <0|1>");
    end
    -- ����������retransEnable
    if (tab["retransEnable"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransEnable is nil");
    elseif (tonumber(tab["retransEnable"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransEnable is invalid, require string number");
        return module_ret("0014", "parameter retransEnable is invalid, require string number");
    elseif (tonumber(tab["retransEnable"]) ~= 0 and tonumber(tab["retransEnable"]) ~= 1) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransEnable is invalid, out of range <0|1>");
        return module_ret("0014", "parameter retransEnable is invalid, out of range <0|1>");
    end
    -- ����������retransStreamEnable
    if (tab["retransStreamEnable"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransStreamEnable is nil");
    elseif (tonumber(tab["retransStreamEnable"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStreamEnable is invalid, require string number");
        return module_ret("0014", "parameter retransStreamEnable is invalid, require string number");
    elseif (tonumber(tab["retransStreamEnable"]) ~= 0 and tonumber(tab["retransStreamEnable"]) ~= 1) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStreamEnable is invalid, out of range <0|1>");
        return module_ret("0014", "parameter retransStreamEnable is invalid, out of range <0|1>");
    end
    -- ����������retransPeriod
    if (tab["retransPeriod"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransPeriod is nil");
    elseif (tonumber(tab["retransPeriod"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransPeriod is invalid, require string number");
        return module_ret("0014", "parameter retransPeriod is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["retransPeriod"]) < min_retrans_prd or tonumber(tab["retransPeriod"]) > max_retrans_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransPeriod is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd);
        return module_ret("0014", string.format("parameter retransPeriod is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd));
    end
    -- ����������retransStep
    if (tab["retransStep"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransStep is nil");
    elseif (tonumber(tab["retransStep"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStep is invalid, require string number");
        return module_ret("0014", "parameter retransStep is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["retransStep"]) < min_retrans_prd or tonumber(tab["retransStep"]) > max_retrans_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStep is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd);
        return module_ret("0014", string.format("parameter retransStep is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd));
    end
    -- ����������retransMaxPeriod
    if (tab["retransMaxPeriod"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransMaxPeriod is nil");
    elseif (tonumber(tab["retransMaxPeriod"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransMaxPeriod is invalid, require string number");
        return module_ret("0014", "parameter retransMaxPeriod is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["retransMaxPeriod"]) < min_retrans_prd or tonumber(tab["retransMaxPeriod"]) > max_retrans_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransMaxPeriod is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd);
        return module_ret("0014", string.format("parameter retransMaxPeriod is invalid, value range [%d-%d]", min_retrans_prd, max_retrans_prd));
    end
    -- ����������retransFileLimit
    if (tab["retransFileLimit"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransFileLimit is nil");
    elseif (tonumber(tab["retransFileLimit"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransFileLimit is invalid, require string number");
        return module_ret("0014", "parameter retransFileLimit is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["retransFileLimit"]) < min_retrans_file or tonumber(tab["retransFileLimit"]) > max_retrans_file) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransFileLimit is invalid, value range [%d-%d]", min_retrans_file, max_retrans_file);
        return module_ret("0014", string.format("parameter retransFileLimit is invalid, value range [%d-%d]", min_retrans_file, max_retrans_file));
    end
    -- ����������retransStreamLimit
    if (tab["retransStreamLimit"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:retransStreamLimit is nil");
    elseif (tonumber(tab["retransStreamLimit"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStreamLimit is invalid, require string number");
        return module_ret("0014", "parameter retransStreamLimit is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["retransStreamLimit"]) < min_retrans_stream or tonumber(tab["retransStreamLimit"]) > max_retrans_stream) then
        libdbg.lua_debug(libdbg.ERROR, "parameter retransStreamLimit is invalid, value range [%d-%d]", min_retrans_stream, max_retrans_stream);
        return module_ret("0014", string.format("parameter retransStreamLimit is invalid, value range [%d-%d]", min_retrans_stream, max_retrans_stream));
    end
    -- ����������streamLenLimit
    if (tab["streamLenLimit"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:streamLenLimit is nil");
    elseif (tonumber(tab["streamLenLimit"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter streamLenLimit is invalid, require string number");
        return module_ret("0014", "parameter streamLenLimit is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["streamLenLimit"]) < min_stream_len or tonumber(tab["streamLenLimit"]) > max_stream_len) then
        libdbg.lua_debug(libdbg.ERROR, "parameter streamLenLimit is invalid, value range [%d-%d]", min_stream_len, max_stream_len);
        return module_ret("0014", string.format("parameter streamLenLimit is invalid, value range [%d-%d]", min_stream_len, max_stream_len));
    end
    -- ����������domainSuffix
    if (tab["domainSuffix"] == nil) then
        -- ����Ϊ��
        libdbg.lua_debug(libdbg.WARNING, "param:domainSuffix is nil");
    elseif (type(tab["domainSuffix"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter domainSuffix is invalid, require string");
        return module_ret("0014", "parameter domainSuffix is invalid, require string");
    end

    -- дuci����
    local uci_change_flag = false;
    local uci = require("luci.model.uci").cursor();
    uci:foreach("rlog", "rlog",
    function(s)
        if (tab["enable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.enable=%s", tab["enable"]);
            uci:set("rlog", s[".name"], "enable", tab["enable"]);
            --BUGID:971075 ��ֹ������˦��������˵��rlog���õ�sysogȫ�ֿ���Ϊ0
            uci:set("syslog","main","enable",tab["enable"]);
            uci:commit("syslog");
            uci:revert("syslog");
            uci_change_flag = true;
        end
        if (tab["server"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.server=%s", tab["server"]);
            uci:set("rlog", s[".name"], "server", tab["server"]);
            uci_change_flag = true;
        end
        if (tab["protocol"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.protocol=%s", tab["protocol"]);
            uci:set("rlog", s[".name"], "protocol", tab["protocol"]);
            uci_change_flag = true;
        end
        if (tab["uploadPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.uploadPeriod=%s", tab["uploadPeriod"]);
            uci:set("rlog", s[".name"], "uploadPeriod", tab["uploadPeriod"]);
            uci_change_flag = true;
        end
        if (tab["uploadTimeout"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.uploadTimeout=%s", tab["uploadTimeout"]);
            uci:set("rlog", s[".name"], "uploadTimeout", tab["uploadTimeout"]);
            uci_change_flag = true;
        end
        if (tab["logLevel"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.logLevel=%s", tab["logLevel"]);
            uci:set("rlog", s[".name"], "logLevel", tab["logLevel"]);
            uci_change_flag = true;
        end
        if (tab["tarsaveAll"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.tarsaveAll=%s", tab["tarsaveAll"]);
            uci:set("rlog", s[".name"], "tarsaveAll", tab["tarsaveAll"]);
            uci_change_flag = true;
        end
        if (tab["retransEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransEnable=%s", tab["retransEnable"]);
            uci:set("rlog", s[".name"], "retransEnable", tab["retransEnable"]);
            uci_change_flag = true;
        end
        if (tab["retransStreamEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransStreamEnable=%s", tab["retransStreamEnable"]);
            uci:set("rlog", s[".name"], "retransStreamEnable", tab["retransStreamEnable"]);
            uci_change_flag = true;
        end
        if (tab["retransPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransPeriod=%s", tab["retransPeriod"]);
            uci:set("rlog", s[".name"], "retransPeriod", tab["retransPeriod"]);
            uci_change_flag = true;
        end
        if (tab["retransStep"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransStep=%s", tab["retransStep"]);
            uci:set("rlog", s[".name"], "retransStep", tab["retransStep"]);
            uci_change_flag = true;
        end
        if (tab["retransMaxPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransMaxPeriod=%s", tab["retransMaxPeriod"]);
            uci:set("rlog", s[".name"], "retransMaxPeriod", tab["retransMaxPeriod"]);
            uci_change_flag = true;
        end
        if (tab["retransFileLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransFileLimit=%s", tab["retransFileLimit"]);
            uci:set("rlog", s[".name"], "retransFileLimit", tab["retransFileLimit"]);
            uci_change_flag = true;
        end
        if (tab["retransStreamLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.retransStreamLimit=%s", tab["retransStreamLimit"]);
            uci:set("rlog", s[".name"], "retransStreamLimit", tab["retransStreamLimit"]);
            uci_change_flag = true;
        end
        if (tab["streamLenLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.streamLenLimit=%s", tab["streamLenLimit"]);
            uci:set("rlog", s[".name"], "streamLenLimit", tab["streamLenLimit"]);
            uci_change_flag = true;
        end
        if (tab["domainSuffix"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set rlog.global.domainSuffix=%s", tab["domainSuffix"]);
            uci:set("rlog", s[".name"], "domainSuffix", tab["domainSuffix"]);
            -- ����֤���·��
            uci:set("rlog", s[".name"], "tlscafil", "/etc/rlog/ca/"..tab["domainSuffix"]..".pem");
            uci_change_flag = true;
        end
    end);

    if (uci_change_flag == true) then
        libdbg.lua_debug(libdbg.INFO, "uci commit rlog");
        uci:commit("rlog");
        uci:revert("rlog");--���uci����ռ䣬��������õĲ����������������������κ���δ�ύ�ĸ��ģ�
    end

    -- һ������Ҳû����
    if (uci_change_flag ~= true) then
        libdbg.lua_debug(libdbg.WARNING, "param is useless, no required parameters");
        return module_ret("0013", "param is useless, no required parameters");
    end

    ret_str = '{"rcode":"0","rmsg":"OK"}';
    libdbg.lua_debug(libdbg.INFO, "return:%s", ret_str);

    return ret_str;
end
