#! /usr/bin/lua
--[[
    os.execute("echo ip:".."11".." > /dev/ttyS1")
--]]
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("rlog_module_config", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libjson = require("utils.json");
local libfile = require("utils.file");
local dkjson = require("dkjson");
local libubs = require("utils.ubus");
local config_file = "/etc/rlog/module.json";
local liblock = require("utils.lock");
local libc2lua = require("libc2lua");

local config_file = "/etc/rlog/module.json";
local module_dir = "/tmp/ap_log/all"; --���ҵ�������ļ���
local tmp_dir = "/tmp/ap_log/tar_tmp"; --ҵ�����ݻ����ļ���
local tar_dir = "/tmp/ap_log/tar"; --���ҵ������ѹ�����ļ���

-- ��ʼ�����ñ��ͨ���б�
local notify_tab = {
    ["total"]     = 0,
    ["config"]    = {},
}

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/rlog/", "rlog_module_config.lua.log", 100, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|get�ķ���ֵ
    @code�������룬0000Ϊ�ɹ�������Ϊʧ��
    @msg: ���ظ�web�Ĵ�����Ϣ����������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg)
    result = {};
    if (code == "0000") then
        result["rcode"] = code;
    else
        result["rcode"] = code;
    end
    result["rmsg"] = string.format(msg);
    res = result;

    if (code ~= "0000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = dkjson.encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);
    return json_str;
end

--[[
    add_notify() -- �������ñ��ͨ��
    @module_name��ģ������
    @option: ģ�������
    @old_value: ��ֵ
    @new_value: ��ֵ
    @return���ɹ���0��ʧ�ܣ�-1
--]]
function add_notify(module_name, option, old_value, new_value)
    -- �������
    if (module_name == nil) then
        libdbg.lua_debug(libdbg.ERROR, "module_name is nil");
        return -1;
    end
    if (option == nil) then
        libdbg.lua_debug(libdbg.ERROR, "option is nil");
        return -1;
    end
    if (old_value == nil) then
        libdbg.lua_debug(libdbg.ERROR, "old_value is nil");
        return -1;
    end
    if (new_value == nil) then
        libdbg.lua_debug(libdbg.ERROR, "new_value is nil");
        return -1;
    end
    local config_table = {
        ["name"]     = module_name,
        ["option"]    = option,
        ["old_value"] = old_value,
        ["new_value"] = new_value,
        -- �����ļ���
        ["module_dir"] = string.format("%s/%s", module_dir, module_name),
        -- �����ļ���
        ["tmp_dir"] = string.format("%s/%s", tmp_dir, module_name),
        -- ѹ���������ļ���
        ["tar_dir"] = string.format("%s/%s", tar_dir, module_name),
    }
    table.insert(notify_tab["config"], config_table);
    notify_tab["total"] = tostring(tonumber(notify_tab["total"]) + 1);    -- �ӿڶ������⣬totalΪ�ַ�������

    libdbg.lua_debug(libdbg.INFO, "add module : %s %s notify success", module_name, option);
    return 0;
end

-- @rlog_module_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_get()********************");
    libdbg.lua_debug(libdbg.ERROR, "rlog_module_get get is not support");
    return module_ret("0001", "rlog_module_get get is not support");
end

-- @rlog_config_set
function module_set(param)
    local lock_file = "/tmp/rlog/rlog_module_config.lock";
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter rlog_module_set()********************");

    -- �������
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is nil");
        return module_ret("0005", "param is nil");
    end

    -- bugid:1154857,�����R300������ȫ©����rlogģ���������ע��©��
    -- ������ȫУ��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "param is unsafe");
        return module_ret("0005", "param is unsafe");
    end

    libdbg.lua_debug(libdbg.INFO, "cmd is dev_config set rlog_module_config '%s'", param);

    -- �������Ƿ�json��ʽ
    if (libjson.str_is_json(param) == false) then
        libdbg.lua_debug(libdbg.ERROR, "rlog_config_set param is no json type");
        return module_ret("0002", "rlog_config_set param is no json type");
    end
    local param_tab = dkjson.decode(param);
    if (param_tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param_tab is nil");
        return module_ret("0005", "param_tab is nil");
    end

    -- ����ļ��Ƿ����
    local file_flag = libfile.file_is_exist(config_file);
    if (file_flag == false) then
        libdbg.lua_debug(libdbg.ERROR, "/etc/rlog/module.json is no exist");
        return module_ret("0003", "/etc/rlog/module.json is no exist");
    end

    -- ��ȡ��ǰ�����ļ�
    local file_data = libfile.read_file(config_file);
    if (file_data == nil) then
        libdbg.lua_debug(libdbg.ERROR, "config_file : /etc/rlog/module.json is empty");
        return module_ret("0004", "config_file : /etc/rlog/module.json is empty");
    end
    local module_tab = dkjson.decode(file_data);
    if (module_tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "module_tab is nil");
        return module_ret("0005", "module_tab is nil");
    end

    -- ��������
    local module_flag;
    for i_param, v_param in ipairs(param_tab["module_list"]) do
        if (v_param["module_name"] == nil) then
            libdbg.lua_debug(libdbg.INFO, "get module name failed");
            break;
        end

        libdbg.lua_debug(libdbg.INFO, "module : %s ", v_param["module_name"]);
        module_flag = false;

        -- ������ǰ����
        for i_module, v_module in ipairs(module_tab["module_list"]) do
            -- ҵ����ڣ����������
            if (v_param["module_name"] == v_module["module_name"]) then
                module_flag = true;
                libdbg.lua_debug(libdbg.INFO, "module : %s config exist, update config", v_param["module_name"]);

                -- ����·����ǹرգ���ɾ����ǰ���ã���ͨ��
                if (v_param["enable"] ~= nil and v_param["enable"] == 0) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "enable", "0");
                    add_notify(v_param["module_name"], "enable", "1", "0");
                    table.remove(module_tab["module_list"], i_module);
                    module_tab["total"] = module_tab["total"] - 1;
                    libdbg.lua_debug(libdbg.INFO, "module_tab : %s", dkjson.encode(module_tab));
                    break;
                end

                -- single
                if (v_param["single"] ~= nil and v_param["single"] ~= v_module["single"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "single", v_param["single"]);
                    add_notify(v_param["module_name"], "single", tostring(v_module["single"]), tostring(v_param["single"]));
                    v_module["single"] = v_param["single"];
                end

                -- upload_period
                if (v_param["upload_period"] ~= nil and v_param["upload_period"] ~= v_module["upload_period"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "upload_period", v_param["upload_period"]);
                    add_notify(v_param["module_name"], "upload_period", tostring(v_module["upload_period"]), tostring(v_param["upload_period"]));
                    v_module["upload_period"] = v_param["upload_period"];
                end

                -- server
                if (v_param["server"] ~= nil and v_param["server"] ~= v_module["server"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "server", v_param["server"]);
                    add_notify(v_param["module_name"], "server", v_module["server"], v_param["server"]);
                    v_module["server"] = v_param["server"];
                end

                -- create_period
                if (v_param["create_period"] ~= nil and v_param["create_period"] ~= v_module["create_period"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "create_period", v_param["create_period"]);
                    add_notify(v_param["module_name"], "create_period", tostring(v_module["create_period"]), tostring(v_param["create_period"]));
                    v_module["create_period"] = v_param["create_period"];
                end

                -- file
                if (v_param["file"] ~= nil and v_param["file"] ~= v_module["file"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "file", v_param["file"]);
                    add_notify(v_param["module_name"], "file", v_module["file"], v_param["file"]);
                    v_module["file"] = v_param["file"];
                end

                -- protocol
                if (v_param["protocol"] ~= nil and v_param["protocol"] ~= v_module["protocol"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "protocol", v_param["protocol"]);
                    add_notify(v_param["module_name"], "protocol", v_module["protocol"], v_param["protocol"]);
                    v_module["protocol"] = v_param["protocol"];
                end

                -- header
                if (v_param["header"] ~= nil and v_param["header"] ~= v_module["header"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "header", v_param["header"]);
                    add_notify(v_param["module_name"], "header", v_module["header"], v_param["header"]);
                    v_module["header"] = v_param["header"];
                end

                -- tlscafil
                if (v_param["tlscafil"] ~= nil and v_param["tlscafil"] ~= v_module["tlscafil"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "header", v_param["tlscafil"]);
                    add_notify(v_param["module_name"], "tlscafil", v_module["tlscafil"], v_param["tlscafil"]);
                    v_module["tlscafil"] = v_param["tlscafil"];
                end

                -- domainSuffix
                if (v_param["domainSuffix"] ~= nil and v_param["domainSuffix"] ~= v_module["domainSuffix"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "domainSuffix", v_param["domainSuffix"]);
                    add_notify(v_param["module_name"], "domainSuffix", v_module["domainSuffix"], v_param["domainSuffix"]);
                    v_module["domainSuffix"] = v_param["domainSuffix"];
                end

                if (v_param["upload_fail_cmd"] ~= nil and v_param["upload_fail_cmd"] ~= v_module["upload_fail_cmd"]) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "upload_fail_cmd", v_param["upload_fail_cmd"]);
                    add_notify(v_param["module_name"], "upload_fail_cmd", v_module["upload_fail_cmd"], v_param["upload_fail_cmd"]);
                    v_module["upload_fail_cmd"] = v_param["upload_fail_cmd"];
                end

                break;
            end
        end

        -- ����ҵ������
        if (module_flag == false) then
            libdbg.lua_debug(libdbg.INFO, "module : %s config no exist, create config", v_param["module_name"]);

            if (v_param["enable"] ~= nil and v_param["enable"] == 0) then
                -- ���ò��������·��رգ��򲻴���
                libdbg.lua_debug(libdbg.INFO, "failed to close %s, module no exist", v_param["module_name"]);
            else
                -- ����ҵ�����ã�ֱ�Ӳ�������
                table.insert(module_tab["module_list"], v_param);
                module_tab["total"] = module_tab["total"] + 1;

                -- ���ñ��ͨ��
                -- enable
                add_notify(v_param["module_name"], "enable", "0", "1");

                -- single
                if (v_param["single"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "single", v_param["single"]);
                    add_notify(v_param["module_name"], "single", "", tostring(v_param["single"]));
                end

                -- upload_period
                if (v_param["upload_period"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "upload_period", v_param["upload_period"]);
                    add_notify(v_param["module_name"], "upload_period", "", tostring(v_param["upload_period"]));
                end

                -- server
                if (v_param["server"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "server", v_param["server"]);
                    add_notify(v_param["module_name"], "server", "", v_param["server"]);
                end

                -- create_period
                if (v_param["create_period"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "create_period", v_param["create_period"]);
                    add_notify(v_param["module_name"], "create_period", "", tostring(v_param["create_period"]));
                end

                -- file
                if (v_param["file"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "file", v_param["file"]);
                    add_notify(v_param["module_name"], "file", "", v_param["file"]);
                end

                -- protocol
                if (v_param["protocol"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "protocol", v_param["protocol"]);
                    add_notify(v_param["module_name"], "protocol", "", v_param["protocol"]);
                end

                -- header
                if (v_param["header"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "header", v_param["header"]);
                    add_notify(v_param["module_name"], "header", "", v_param["header"]);
                end

                -- tlscafil
                if (v_param["tlscafil"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "tlscafil", v_param["tlscafil"]);
                    add_notify(v_param["module_name"], "tlscafil", "", v_param["tlscafil"]);
                end

                -- domainSuffix
                if (v_param["domainSuffix"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "domainSuffix", v_param["domainSuffix"]);
                    add_notify(v_param["module_name"], "domainSuffix", "", v_param["domainSuffix"]);
                end

                if (v_param["upload_fail_cmd"] ~= nil) then
                    libdbg.lua_debug(libdbg.INFO, "module : %s %s change, new value : %s", v_param["module_name"], "upload_fail_cmd", v_param["upload_fail_cmd"]);
                    add_notify(v_param["module_name"], "upload_fail_cmd", "", v_param["upload_fail_cmd"]);
                end
            end
        end
    end

    -- ��json����д���ļ�
    -- �������Ƿ�json��ʽ
    if (libjson.str_is_json(dkjson.encode(module_tab)) == false) then
        libdbg.lua_debug(libdbg.ERROR, "module_tab param is no json type");
        return module_ret("0002", "module_tab param is no json type");
    end
    libdbg.lua_debug(libdbg.DEBUG, "ready to write %s to %s", dkjson.encode(module_tab), config_file);
    liblock.lock(lock_file)
    libjson.set_json_table_to_file(config_file, module_tab);
    liblock.unlock(lock_file);
    libdbg.lua_debug(libdbg.INFO, "write json to file success");

    -- ����2s,�����ļ��仯���
    os.execute("sleep 2");

    -- ���ͨ��
    libdbg.lua_debug(libdbg.INFO, "notify total is %d", notify_tab["total"]);
    if (notify_tab["total"] ~= 0) then
        -- ����ubus�ӿڣ�����ͨ��
        libubs.ubus_call("rlog", "notify", notify_tab, 3);
        libdbg.lua_debug(libdbg.DEBUG, "ubus -t 3 call rlog notify %s", dkjson.encode(notify_tab));
    end
    return module_ret("0000", "success");
end
