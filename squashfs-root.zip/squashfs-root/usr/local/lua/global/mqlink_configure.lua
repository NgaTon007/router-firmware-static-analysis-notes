#! /usr/bin/lua
-- os.execute("echo ip:".."11".." > /dev/ttyS1")
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("mqlink_configure", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

local libdbg = require("utils.debug");
local libubs = require("utils.ubus");
local dkjson = require("dkjson");
local product = require("product");
local min_prd = 1;
local max_prd = 3600;
local min_step = 1;
local max_step = 300;

-- ����ģ���ʼ��
libdbg.debug_init("/tmp/mqlink/", "mqlink_configure.lua.log", 100, libdbg.DEBUG, libdbg.OPEN);

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("mqlink_cfgntf"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- ���󷵻�
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = dkjson.encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return json_str;
end

-- @mqlink_configure_get
function module_get(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_configure_get()********************");
    libdbg.lua_debug(libdbg.ERROR, "mqlink_configure get is not support");
    return module_ret("0011", "mqlink_configure get is not support");
end

-- @mqlink_configure_set
function module_set(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ

    -- 1���������
    -- {"user":"cloud","addr":"x","port":"x","un":"x","pw":"x","tls":"<0|1>","domainSuffix":"xx.link","alvPrd":"x","ackEna":"<0|1>","ackPrd":"x","ackLimit":"x","dnsFilter","xxx.xxx.xxx.xxx","controller":"CLOUD"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink_configure set parameter is nil");
        return module_ret("0012", "mqlink_config set parameter is nil");
    end
    local controller_value = product.get_product("capacity.controller");
    if (controller_value == nill) then
        libdbg.lua_debug(libdbg.ERROR, "controller value     is nil");
        return module_ret("0012", "controller value is nil");
    end
        
    libdbg.lua_debug(libdbg.INFO, "dev_config set -m mqlink_configure '%s'", param);

    -- 2����������
    local tab = dkjson.decode(param);
    -- 2.1������������user
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "mqlink_configure set require parameter:user");
        return module_ret("0013", "mqlink_config set require parameter:user");
    end
    -- 2.2������������enable
    if (tab["enable"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:enable is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:enable");
    elseif (type(tab["enable"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter enable is invalid, require string");
        return module_ret("0014", "parameter enable is invalid, require string");
    end
    -- 2.3������������addr
    if (tab["addr"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:addr is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:addr");
    elseif (type(tab["addr"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter addr is invalid, require string");
        return module_ret("0014", "parameter addr is invalid, require string");
    end
    -- 2.4������������port
    if (tab["port"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:port is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:port");
    elseif (tonumber(tab["port"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter port is invalid, require string number");
        return module_ret("0014", "parameter port is invalid, require string number");
    elseif (tonumber(tab["port"]) < 0 or tonumber(tab["port"]) > 65535) then
        libdbg.lua_debug(libdbg.ERROR, "parameter port is invalid, out of range [0,65535]");
        return module_ret("0014", "parameter port is invalid, out of range [0,65535]");
    end
    -- 2.5������������un��username��
    if (tab["un"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:un is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:un");
    elseif (type(tab["un"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter un is invalid, require string");
        return module_ret("0014", "parameter un is invalid, require string");
    end
    -- 2.6������������pw��password��
    if (tab["pw"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:pw is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:pw");
    elseif (type(tab["pw"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter pw is invalid, require string");
        return module_ret("0014", "parameter pw is invalid, require string");
    end
    -- 2.7������������tls
    if (tab["tls"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:tls is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:tls");
    elseif (tonumber(tab["tls"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter tls is invalid, require string number");
        return module_ret("0014", "parameter tls is invalid, require string number");
    elseif (tonumber(tab["tls"]) ~= 0 and tonumber(tab["tls"]) ~= 1) then
        libdbg.lua_debug(libdbg.ERROR, "parameter tls is invalid, out of range <0|1>");
        return module_ret("0014", "parameter tls is invalid, out of range <0|1>");
    end
    -- 2.8������������domainSuffix
    if (tab["domainSuffix"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:domainSuffix is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:domainSuffix");
    elseif (type(tab["domainSuffix"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter domainSuffix is invalid, require string");
        return module_ret("0014", "parameter domainSuffix is invalid, require string");
    end
    -- 2.9������������alvPrd��keepAlivePeroid��
    if (tab["alvPrd"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:alvPrd is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:alvPrd");
    elseif (tonumber(tab["alvPrd"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter alvPrd is invalid, require string number");
        return module_ret("0014", "parameter alvPrd is invalid, require string number");
    end
    -- 2.10������������reconnPrd��reconnPeriod��
    if (tab["reconnPrd"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:reconnPrd is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:reconnPrd");
    elseif (tonumber(tab["reconnPrd"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnPrd is invalid, require string number");
        return module_ret("0014", "parameter reconnPrd is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["reconnPrd"]) < min_prd or tonumber(tab["reconnPrd"]) > max_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnPrd is invalid, value range [%d-%d]", min_prd, max_prd);
        return module_ret("0014", string.format("parameter reconnPrd is invalid, value range [%d-%d]", min_prd, max_prd));
    end
    -- 2.11������������reconnStep��reconnStep��
    if (tab["reconnStep"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:reconnStep is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:reconnStep");
    elseif (tonumber(tab["reconnStep"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnStep is invalid, require string number");
        return module_ret("0014", "parameter reconnStep is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["reconnStep"]) < min_step or tonumber(tab["reconnStep"]) > max_step) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnStep is invalid, value range [%d-%d]", min_step, max_step);
        return module_ret("0014", string.format("parameter reconnStep is invalid, value range [%d-%d]", min_step, max_step));
    end
    -- 2.12������������reconnMaxPrd��reconnMaxPeriod��
    if (tab["reconnMaxPrd"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:reconnMaxPrd is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:reconnMaxPrd");
    elseif (tonumber(tab["reconnMaxPrd"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnMaxPrd is invalid, require string number");
        return module_ret("0014", "parameter reconnMaxPrd is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["reconnMaxPrd"]) < min_prd or tonumber(tab["reconnMaxPrd"]) > max_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnMaxPrd is invalid, value range [%d-%d]", min_prd, max_prd);
        return module_ret("0014", string.format("parameter reconnMaxPrd is invalid, value range [%d-%d]", min_prd, max_prd));
    end
    -- 2.13������������ackEna��retransEnable��
    if (tab["ackEna"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:ackEna is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:ackEna");
    elseif (tonumber(tab["ackEna"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackEna is invalid, require string number");
        return module_ret("0014", "parameter ackEna is invalid, require string number");
    elseif (tonumber(tab["ackEna"]) ~= 0 and tonumber(tab["ackEna"]) ~= 1) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackEna is invalid, out of range <0|1>");
        return module_ret("0014", "parameter ackEna is invalid, out of range <0|1>");
    end
    -- 2.14������������ackPrd��retransPeriod��
    if (tab["ackPrd"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:ackPrd is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:ackPrd");
    elseif (tonumber(tab["ackPrd"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackPrd is invalid, require string number");
        return module_ret("0014", "parameter ackPrd is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["ackPrd"]) < min_prd or tonumber(tab["ackPrd"]) > max_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackPrd is invalid, value range [%d-%d]", min_prd, max_prd);
        return module_ret("0014", string.format("parameter ackPrd is invalid, value range [%d-%d]", min_prd, max_prd));
    end
    -- 2.15������������ackStep��retransStep��
    if (tab["ackStep"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:ackStep is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:ackStep");
    elseif (tonumber(tab["ackStep"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackStep is invalid, require string number");
        return module_ret("0014", "parameter ackStep is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["ackStep"]) < min_step or tonumber(tab["ackStep"]) > max_step) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackStep is invalid, value range [%d-%d]", min_step, max_step);
        return module_ret("0014", string.format("parameter ackStep is invalid, value range [%d-%d]", min_step, max_step));
    end
    -- 2.16������������ackMaxPrd��retransMaxPeriod��
    if (tab["ackMaxPrd"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:ackMaxPrd is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:ackMaxPrd");
    elseif (tonumber(tab["ackMaxPrd"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackMaxPrd is invalid, require string number");
        return module_ret("0014", "parameter ackMaxPrd is invalid, require string number");
    -- ����Ƿ񳬹���ֵ
    elseif (tonumber(tab["ackMaxPrd"]) < min_prd or tonumber(tab["ackMaxPrd"]) > max_prd) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackMaxPrd is invalid, value range [%d-%d]", min_prd, max_prd);
        return module_ret("0014", string.format("parameter ackMaxPrd is invalid, value range [%d-%d]", min_prd, max_prd));
    end
    -- 2.17������������ackLimit��retransLimit��
    if (tab["ackLimit"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:ackLimit is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:ackLimit");
    elseif (tonumber(tab["ackLimit"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter ackLimit is invalid, require string number");
        return module_ret("0014", "parameter ackLimit is invalid, require string number");
    end
    -- 2.18������������dnsFilter
    if (tab["dnsFilter"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:dnsFilter is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:dnsFilter");
    elseif (type(tab["dnsFilter"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter dnsFilter is invalid, require string");
        return module_ret("0014", "parameter dnsFilter is invalid, require string");
    end
    -- 2.19������������controller
    if (tab["controller"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:controller is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:controller");
    elseif (type(tab["controller"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter controller is invalid, require string");
        return module_ret("0014", "parameter controller is invalid, require string");
    elseif (tab["controller"] ~= "none" and tab["controller"] ~= controller_value) then
        libdbg.lua_debug(libdbg.ERROR, "parameter controller is invalid, require <none|CLOUD>");
        return module_ret("0014", "parameter controller is invalid, require <none|CLOUD>");
    end	
    -- 2.20������������cmdRspMax
    if (tab["cmdRspMax"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:cmdRspMax is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:cmdRspMax");
    elseif (tonumber(tab["cmdRspMax"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter cmdRspMax is invalid, require string number");
        return module_ret("0014", "parameter cmdRspMax is invalid, require string number");
    end
    -- 2.21������������reconnmaxswalgo
    if (tab["reconnmaxswalgo"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:reconnmaxswalgo is nil");
        -- ����Ϊ��
        -- return module_ret("0013", "mqlink_config set require parameter:reconnmaxswalgo");
    elseif (tonumber(tab["reconnmaxswalgo"]) == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parameter reconnmaxswalgo is invalid, require string number");
        return module_ret("0014", "parameter reconnmaxswalgo is invalid, require string number");
    end

    -- 3��дuci����
    local uci_change_flag = false;
    local mqlink_restart_flag = false;
    local uci = require("luci.model.uci").cursor();
    uci:foreach("mqlink", "mqlink",
    function(s)
        if (tab["enable"] ~= nil and tab["enable"] ~= s["enable"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].enable=%s", tab["enable"]);
            uci:set("mqlink", s[".name"], "enable", tab["enable"]);
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "enable is set, set mqlink_restart_flag true");
        end
        if (tab["addr"] ~= nil and tab["addr"] ~= s["addr"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].addr=%s", tab["addr"]);
            uci:set("mqlink", s[".name"], "addr", tab["addr"]);
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "addr is set, set mqlink_restart_flag true");
        end
        if (tab["port"] ~= nil and tab["port"] ~= s["port"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].port=%s", tab["port"]);
            uci:set("mqlink", s[".name"], "port", tab["port"]);
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "port is set, set mqlink_restart_flag true");
        end
        if (tab["tls"] ~= nil and tab["tls"] ~= s["tls"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].tls=%s", tab["tls"]);
            uci:set("mqlink", s[".name"], "tls", tab["tls"]);
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "tls is set, set mqlink_restart_flag true");
        end
        if (tab["domainSuffix"] ~= nil and tab["domainSuffix"] ~= s["domainSuffix"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].domainSuffix=%s", tab["domainSuffix"]);
            uci:set("mqlink", s[".name"], "domainSuffix", tab["domainSuffix"]);
            -- ����֤���·��
            uci:set("mqlink", s[".name"], "tlscafil", "/etc/mqlink/ca/"..tab["domainSuffix"]..".pem");
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "domainSuffix is set, set mqlink_restart_flag true");
        end
        if (tab["alvPrd"] ~= nil and tab["alvPrd"] ~= s["keepAlivePeroid"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].keepAlivePeroid=%s", tab["alvPrd"]);
            uci:set("mqlink", s[".name"], "keepAlivePeroid", tab["alvPrd"]);
            uci_change_flag = true;
            mqlink_restart_flag = true;
            libdbg.lua_debug(libdbg.DEBUG, "alvPrd is set, set mqlink_restart_flag true");
        end
        if (tab["reconnPrd"] ~= nil and tab["reconnPrd"] ~= s["reconnPeriod"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].reconnPeriod=%s", tab["reconnPrd"]);
            uci:set("mqlink", s[".name"], "reconnPeriod", tab["reconnPrd"]);
            uci_change_flag = true;
        end
        if (tab["reconnStep"] ~= nil and tab["reconnStep"] ~= s["reconnStep"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].reconnStep=%s", tab["reconnStep"]);
            uci:set("mqlink", s[".name"], "reconnStep", tab["reconnStep"]);
            uci_change_flag = true;
        end
        if (tab["reconnMaxPrd"] ~= nil and tab["reconnMaxPrd"] ~= s["reconnMaxPeriod"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].reconnMaxPeriod=%s", tab["reconnMaxPrd"]);
            uci:set("mqlink", s[".name"], "reconnMaxPeriod", tab["reconnMaxPrd"]);
            uci_change_flag = true;
        end
        if (tab["ackEna"] ~= nil and tab["ackEna"] ~= s["retransEnable"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].retransEnable=%s", tab["ackEna"]);
            uci:set("mqlink", s[".name"], "retransEnable", tab["ackEna"]);
            uci_change_flag = true;
        end
        if (tab["ackPrd"] ~= nil and tab["ackPrd"] ~= s["retransPeriod"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].retransPeriod=%s", tab["ackPrd"]);
            uci:set("mqlink", s[".name"], "retransPeriod", tab["ackPrd"]);
            uci_change_flag = true;
        end
        if (tab["ackStep"] ~= nil and tab["ackStep"] ~= s["retransStep"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].retransStep=%s", tab["ackStep"]);
            uci:set("mqlink", s[".name"], "retransStep", tab["ackStep"]);
            uci_change_flag = true;
        end
        if (tab["ackMaxPrd"] ~= nil and tab["ackMaxPrd"] ~= s["retransMaxPeriod"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].retransMaxPeriod=%s", tab["ackMaxPrd"]);
            uci:set("mqlink", s[".name"], "retransMaxPeriod", tab["ackMaxPrd"]);
            uci_change_flag = true;
        end
        if (tab["ackLimit"] ~= nil and tab["ackLimit"] ~= s["retransLimit"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].retransLimit=%s", tab["ackLimit"]);
            uci:set("mqlink", s[".name"], "retransLimit", tab["ackLimit"]);
            uci_change_flag = true;
        end
        if (tab["dnsFilter"] ~= nil and tab["dnsFilter"] ~= s["dnsFilter"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].dnsFilter=%s", tab["dnsFilter"]);
            uci:set("mqlink", s[".name"], "dnsFilter", tab["dnsFilter"]);
            uci_change_flag = true;
        end
        if (tab["controller"] ~= nil and tab["controller"] ~= s["controller"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].controller=%s", tab["controller"]);
            uci:set("mqlink", s[".name"], "controller", tab["controller"]);
            uci_change_flag = true;
            -- bugid:934302�����ƶ��·�controllerʱ����������״̬ͨ��
            if (tab["controller"] == controller_value) then
                local data = string.format("ubus -t 3 send cloud_server '{\"status\":\"connected\"}'");
                libdbg.lua_debug(libdbg.INFO, "controller is %s, send ubus notify : %s\n", tab["controller"], data);
                -- local tab = { status = "connected" }
                libubs.ubus_send("cloud_server", { status = "connected" }, 3);
                if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
                    local std_syslog= require("std_syslog_lua");
                    local ret_code;
                    local ret_msg;
                    -- 1263609, ���ƶ��·�controllerʱ����������syslog
                    ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_INFO, std_syslog.SSG_RELIABLE or std_syslog.SSG_LOW_RATE, 1000000, "CLOUDSERVER", "LINK_SUCCESS", "Device successfully connected to cloud server");
                    libdbg.lua_debug(libdbg.INFO, "ret_code: %s,ret_msg: %s", ret_code, ret_msg);
                end
            elseif (tab["controller"] == "none") then
                local data = string.format("ubus -t 3 send cloud_server '{\"status\":\"disconnect\"}'");
                libdbg.lua_debug(libdbg.INFO, "controller is %s, send ubus notify : %s\n", tab["controller"], data);
                libubs.ubus_send("cloud_server", { status = "disconnect" }, 3);
                if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
                    local std_syslog= require("std_syslog_lua");
                    local ret_code;
                    local ret_msg;
                    -- -- 1263609, ���������ʱ�������ƶ�����syslog
                    ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_NOTICE, std_syslog.SSG_RELIABLE or std_syslog.SSG_LOW_RATE, 1000000, "CLOUDSERVER", "LINK_DISCONNECT", "Device disconnected from cloud server");
                    libdbg.lua_debug(libdbg.INFO, "ret_code: %s,ret_msg: %s", ret_code, ret_msg);
                end
            end
        end
        if (tab["cmdRspMax"] ~= nil and tab["cmdRspMax"] ~= s["cmdRspMax"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].cmdRspMax=%s", tab["cmdRspMax"]);
            uci:set("mqlink", s[".name"], "cmdRspMax", tab["cmdRspMax"]);
            uci_change_flag = true;
        end

        if (tab["reconnmaxswalgo"] ~= nil and tab["reconnmaxswalgo"] ~= s["reconnmaxswalgo"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set mqlink.@mqlink[0].reconnmaxswalgo=%s", tab["reconnmaxswalgo"]);
            uci:set("mqlink", s[".name"], "reconnmaxswalgo", tab["reconnmaxswalgo"]);
            uci_change_flag = true;
        end
    end);

    if (uci_change_flag == true) then
        libdbg.lua_debug(libdbg.INFO, "uci commit mqlink");
        uci:commit("mqlink");
        uci:revert("mqlink");--���uci����ռ䣬��������õĲ����������������������κ���δ�ύ�ĸ��ģ�
    end
    -- TODO:��ʱ������޸����ú�mqlink��tls��������coredump
    if (mqlink_restart_flag == true) then
        libdbg.lua_debug(libdbg.INFO, "/etc/init.d/mqlink restart &");
        os.execute("/etc/init.d/mqlink restart &");
    end

    -- 4��дjson���ã�un pw
    if (tab["un"] ~= nil or tab["pw"] ~= nil) then
        -- ����mqlink��������Ϊ�������ƽ����̫���׵Ļ�ȡ���û���������Ϣ
        local auth_cfg = "/etc/auth_cfg/auth.json"
        local auth_tab = {};
        auth_tab = require("utils.json").get_json_table_from_file(auth_cfg);
        local jsn_change_flag = false;
        if (tab["un"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "json set username:%s", tab["un"]);
            auth_tab["username"] = tab["un"];
            jsn_change_flag = true;
        end
        if (tab["pw"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "json set password:%s", tab["pw"]);
            auth_tab["password"] = tab["pw"];
            jsn_change_flag = true;
        end
        if (jsn_change_flag == true) then
            libdbg.lua_debug(libdbg.DEBUG, "save %s to file:%s", dkjson.encode(auth_tab), auth_cfg);
            require("utils.json").set_json_table_to_file(auth_cfg, auth_tab);
        end
    end

--[[BUGID 957553 ���г�����֧�֡�����mqlink_configure������־�쳣[mqlink_configure]commit failed
    -- һ������Ҳû����
    if (uci_change_flag ~= true and jsn_change_flag ~= true) then
        libdbg.lua_debug(libdbg.WARNING, "no parameters are set");
        return module_ret("0013", "no parameters are set");
    end
]]--
    ret_str = '{"rcode":"00000000","rmsg":"OK"}';
    libdbg.lua_debug(libdbg.INFO, "return:%s", ret_str);

    return ret_str;
end

function module_default_config_get()
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter mqlink_configure_default_get()********************");

    local tab = {};
    local uci = require("luci.model.uci").cursor("/rom/etc/config");
    uci:foreach("mqlink", "mqlink",
    function(s)
        if (s["enable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].enable=%s", s["enable"]);
            tab["enable"] = s["enable"];
        end
        if (s["addr"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].addr=%s", s["addr"]);
            tab["addr"] = s["addr"];
        end
        if (s["port"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].port=%s", s["port"]);
            tab["port"] = s["port"];
        end
        if (s["tls"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].tls=%s", s["tls"]);
            tab["tls"] = s["tls"];
        end
        if (s["tlscafil"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].tlscafil=%s", s["tlscafil"]);
            tab["domainSuffix"] = string.match(s["tlscafil"], "/etc/mqlink/ca/(.+).pem");
        end
        if (s["keepAlivePeroid"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].keepAlivePeroid=%s", s["keepAlivePeroid"]);
            tab["alvPrd"] = s["keepAlivePeroid"];
        end
        if (s["reconnPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnPeriod=%s", s["reconnPeriod"]);
            tab["reconnPrd"] = s["reconnPeriod"];
        end
        if (s["reconnStep"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnStep=%s", s["reconnStep"]);
            tab["reconnStep"] = s["reconnStep"];
        end
        if (s["reconnMaxPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].reconnMaxPeriod=%s", s["reconnMaxPeriod"]);
            tab["reconnMaxPrd"] = s["reconnMaxPeriod"];
        end
        if (s["retransEnable"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransEnable=%s", s["retransEnable"]);
            tab["ackEna"] = s["retransEnable"];
        end
        if (s["retransPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransPeriod=%s", s["retransPeriod"]);
            tab["ackPrd"] = s["retransPeriod"];
        end
        if (s["retransStep"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransStep=%s", s["retransStep"]);
            tab["ackStep"] = s["retransStep"];
        end
        if (s["retransMaxPeriod"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransMaxPeriod=%s", s["retransMaxPeriod"]);
            tab["ackMaxPrd"] = s["retransMaxPeriod"];
        end
        if (s["retransLimit"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].retransLimit=%s", s["retransLimit"]);
            tab["ackLimit"] = s["retransLimit"];
        end
        if (s["dnsFilter"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].dnsFilter=%s", s["dnsFilter"]);
            tab["dnsFilter"] = s["dnsFilter"];
        end
        if (s["controller"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].controller=%s", s["controller"]);
            tab["controller"] = s["controller"];
        end
        if (s["cmdRspMax"] ~= nil) then
            libdbg.lua_debug(libdbg.DEBUG, "uci get mqlink.@mqlink[0].cmdRspMax=%s", s["cmdRspMax"]);
            tab["cmdRspMax"] = s["cmdRspMax"];
        end
    end);

    -- ����user:default
    tab["user"] = "default";
    local json_str = dkjson.encode(tab);
    libdbg.lua_debug(libdbg.INFO, "End mqlink_default_get() json_str:%s\n", json_str);

    return json_str;
end
