#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("snmp", package.seeall);

local uci = require ("luci.model.uci").cursor()
local sys = require ("luci.sys")
local console = require ("console")
local dkjson = require ("dkjson")
local sd_crypto = require("sd_crypto");
utils_exec = require ("utils.exec")
cjson_safe = require ("cjson.safe")
cjson = require("cjson")
libdbg = require ("utils.debug")
moduleId = require ("dev_module_id")
libc2lua = require("libc2lua")
file_param = require ("dev.tools.common")
ip_type = require ("utils.network")

moduleName = "snmp"
dbgDir = "/tmp/debug/snmp/"
dbgFile = "snmp.log"
SD_DEVICE = "/tmp/sd_device/sd_device.json"

--view�û���
view_param_num = 0
--v1v2�û���
v1v2_param_num = 0
--V3������
v3group_param_num = 0
--v3�û���
v3user_param_num = 0
--trap_v1v2�û�
trapv1v2_param_num = 0
--trap_v3�û�
trapv3_param_num = 0

--user ��������
USER_LIM_H = 64
USER_LIM_L = 1
--snmpd_port ��������
PORT_LIM_H = 65535
PORT_LIM_L = 0
--view_name ��������
VIEW_NAME_H = 32
VIEW_NAME_L = 1
--view_oid ��������
VIEW_OID_H = 255
VIEW_OID_L = 1
--v1v2_com ��������
V1V2_COM_H = 32
V1V2_COM_L = 8
--group_name ��������
GROUP_NAME_H = 32
GROUP_NAME_L = 1
--user_name ��������
USER_NAME_H = 32
USER_NAME_L = 1
--auth_password ��������
AUTH_PASSWORD_H = 31
AUTH_PASSWORD_L = 8
--priv_password ��������
PRIV_PASSWORD_H = 31
PRIV_PASSWORD_L = 8
--trap_v1v2_ip ��������
TRAPV1V2_IP_H = 64
TRAPV1V2_IP_L = 0
--trap_v1v2_port ��������
TRAPV1V2_PORT_H = 65535
TRAPV1V2_PORT_L = 0
--trap_v1v2_com ��������
TRAPV1V2_COM_H = 32
TRAPV1V2_COM_L = 8
--trap_v3_ip ��������
TRAP_V3_IP_H = 64
TRAP_V3_IP_L = 0
--trap_v3_port �����п�
TRAP_V3_PORT_H = 65535
TRAP_V3_PORT_L = 0
--trap_v3_name ��������
TRAP_V3_NAME_H = 32
TRAP_V3_NAME_L = 8
--trap_auth_password ��������
TRAP_AUTH_PASSWORD_H = 31
TRAP_AUTH_PASSWORD_L = 8
--trap_priv_password ��������
TRAP_PRIV_PASSWORD_H = 31
TRAP_PRIV_PASSWORD_L = 8

--vieWĬ������
VIEW_H = 20
--v1v2CĬ������
V1V2C_H = 20
--oidĬ������
OID_H = 100
--V3��Ĭ������
V3_GROUP_H = 20
--v3�û�Ĭ������
V3_H = 50
--trap_v1v2�û�Ĭ������
TRAP_V1V2_H = 20
--trap_v3�û�Ĭ������
TRAP_V3_H = 20

--����ģ���ʼ��
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

function module_ret(code, rcode, rdata, rmsg)
    local err = {}
    local ret = {}
    ret["err"] = {}
    err["rdata"] = rdata
    err["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("snmp"), tonumber(rcode))
    ret["code"] = code
    err["rmsg"] = rmsg
    ret["err"] = err
    --table.insert(ret["err"], err)
    res = ret
    if (code == "1") then
        local json_str = cjson_safe.encode(res)
        libdbg.lua_debug(libdbg.INFO,"return json_str:%s\n",json_str)
    end

    return cjson_safe.encode(ret)
end

--���ļ�����������
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end
--���ַ���ת��Ϊjson��ʽ
local function read_file_for_json(path)
    local content, content_json

    if (type(path) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "the file path is error.")
        return -1
    end
    content = file_read(path)
    if (content == nil) then
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] read failed.", path)
        return -1
    end
    content_json = cjson_safe.decode(content)
    if (content_json == nil or type(content_json) ~= "table") then
        libdbg.lua_debug(libdbg.ERROR, "parse the file [%s] read failed.", path)
        return -1
    end

    return 0, content_json
end

--uci���ݶ�ȡ
local function read_uci_data(cfg_type)
    local uci
    local snmp_json_data
    local get_uci_data = {}
    local get_v1 = 0
    local get_v2c = 0
    local get_v3 = 0
    local get_trapv1 = 0
    local get_trapv2c = 0
    local get_trapv3 = 0
    local ret = -1
    get_uci_data["snmp_ver"] = {}
    get_uci_data["trap_ver"] = {}
    get_uci_data["view_name_list"] = {}
    get_uci_data["view"] = {}
    get_uci_data["v1v2_auth"] = {}
    get_uci_data["v3_group"] = {}
    get_uci_data["v3_auth"] = {}
    get_uci_data["trap_v1v2_user"] = {}
    get_uci_data["trap_v3_user"] = {}

    if (cfg_type == "default") then
        uci = require ("luci.model.uci").cursor("/rom/etc/config/")
    elseif (cfg_type == "current") then
        uci = require ("luci.model.uci").cursor()
    else
        libdbg.lua_debug(libdbg.ERROR, "cfg_type error")
        return module_ret("1", "20", "NULL", "cfg_type error")
    end

    --����ȡ���ļ�ת��Ϊtable��ʽ
    ret, snmp_json_data = read_file_for_json(SD_DEVICE)
     if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "file is null")
        return module_ret("1", "20", "NULL", "file is null")
    end
    --user
    get_uci_data["user"] = uci:get("snmpd", "snmp_parameter", "user")
    --snmp_enable
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        get_uci_data["snmp_enable"] = uci:get("snmpd", "snmp_parameter", "snmp_enable")
    else
        get_uci_data["snmp_enable"] = "false"
    end
    --snmpd_port
    get_uci_data["snmpd_port"] = uci:get("snmpd", "snmp_parameter", "snmpd_port")
    --snmp_wan_enable
    get_uci_data["snmp_wan_enable"] = uci:get("snmpd", "snmp_parameter", "snmp_wan_enable")
    --trap_enable
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_trap_support"] ~= nil and snmp_json_data["snmp"]["snmp_trap_support"] ~= "") then
            --�ж���ֵΪ0��1
            if (snmp_json_data["snmp"]["snmp_trap_support"] == "1") then
                get_uci_data["trap_enable"] = uci:get("snmpd", "trap_parameter", "trap_enable")
            else
                get_uci_data["trap_enable"] = "false"
            end
        else
            get_uci_data["trap_enable"] = "false"
        end
    else
        get_uci_data["trap_enable"] = "false"
    end
    --snmp_v1
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v1_support"] ~= nil or snmp_json_data["snmp"]["snmp_v1_support"] ~= "") then
            --�ж��Ƿ�Ϊ1
            if (snmp_json_data["snmp"]["snmp_v1_support"] == "1") then
                get_v1 = uci:get("snmpd", "snmp_parameter", "v1")
                if (get_v1 == "1") then
                    table.insert(get_uci_data["snmp_ver"], "v1")
                end
            end
        end
    end
    --snmp_v2c
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v2c_support"] ~= nil and snmp_json_data["snmp"]["snmp_v2c_support"] ~= "") then
            --�ж��Ƿ�Ϊ1
            if (snmp_json_data["snmp"]["snmp_v2c_support"] == "1") then
                get_v2c = uci:get("snmpd", "snmp_parameter", "v2c")
                if(get_v2c == "1") then
                    table.insert(get_uci_data["snmp_ver"], "v2c")
                end
            end
        end
    end
    --snmp_v3
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v3_support"] ~= nil and snmp_json_data["snmp"]["snmp_v3_support"] ~= "") then
            if (snmp_json_data["snmp"]["snmp_v3_support"] == "1") then
                get_v3 = uci:get("snmpd", "snmp_parameter", "v3")
                if(get_v3 == "1") then
                    table.insert(get_uci_data["snmp_ver"], "v3")
                end
            end
        end
    end
    --get_trapv1
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v1_trap_support"] ~= nil and snmp_json_data["snmp"]["snmp_v1_trap_support"] ~= "") then
            if (snmp_json_data["snmp"]["snmp_v1_trap_support"] == "1") then
                get_trapv1 = uci:get("snmpd", "trap_parameter", "trap_v1")
                if (get_trapv1 == "1") then
                    table.insert(get_uci_data["trap_ver"], "v1")
                end
            end
        end
    end
    --get_trapv2c
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v2c_trap_support"] ~= nil and snmp_json_data["snmp"]["snmp_v2c_trap_support"] ~= "") then
            if (snmp_json_data["snmp"]["snmp_v2c_trap_support"] == "1") then
                get_trapv2c = uci:get("snmpd", "trap_parameter", "trap_v2")
                if(get_trapv2c == "1") then
                    table.insert(get_uci_data["trap_ver"], "v2c")
                end
            end
        end
    end
    --get_trapv3
    if (snmp_json_data["snmp"] ~= nil and snmp_json_data["snmp"] ~= "") then
        if (snmp_json_data["snmp"]["snmp_v3_trap_support"] ~= nil and snmp_json_data["snmp"]["snmp_v3_trap_support"] ~= "") then
            if (snmp_json_data["snmp"]["snmp_v3_trap_support"] == "1") then
                get_trapv3 = uci:get("snmpd", "trap_parameter", "trap_v3")
                if(get_trapv3 == "1") then
                    table.insert(get_uci_data["trap_ver"], "v3")
                end
            end
        end
    end
    --view_name_list
    local login_option = uci:get_list("snmpd", "snmp_parameter", "view_name_list")
    for key,value in pairs(login_option) do
        table.insert(get_uci_data["view_name_list"], value)
    end
    --view��ͼ
    uci:foreach("snmpd", "view", function(s)
        local get_view = {}
        local name = s[".name"]
        get_view["view_name"]= uci:get("snmpd", name, "view_name")
        get_view["view_type"]= uci:get("snmpd", name, "view_type")
        get_view["view_oid"]= uci:get("snmpd", name, "view_oid")
        table.insert(get_uci_data["view"], get_view)
    end
    )
    --v1v2_auth�û�
    uci:foreach("snmpd", "v1v2_auth", function(s)
        local get_v1v2_auth = {}
        local name = s[".name"]
        get_v1v2_auth["v1v2_com"]= uci:get("snmpd", name, "v1v2_com")
        get_v1v2_auth["v1v2_ac"]= uci:get("snmpd", name, "v1v2_ac")
        get_v1v2_auth["v1v2_view"]= uci:get("snmpd", name, "v1v2_view")
        table.insert(get_uci_data["v1v2_auth"], get_v1v2_auth)
    end
    )
    --v3_group�û�
    uci:foreach("snmpd", "v3_group", function(s)
        local get_v3_group = {}
        local name = s[".name"]
        get_v3_group["group_name"]= uci:get("snmpd", name, "group_name")
        get_v3_group["group_sec_level"]= uci:get("snmpd", name, "group_sec_level")
        get_v3_group["group_read_view"]= uci:get("snmpd", name, "group_read_view")
        get_v3_group["group_write_view"]= uci:get("snmpd", name, "group_write_view")
        get_v3_group["group_notify_view"]= uci:get("snmpd", name, "group_notify_view")
        table.insert(get_uci_data["v3_group"], get_v3_group)
    end
    )
    --v3_auth�û�
    uci:foreach("snmpd", "v3_auth", function(s)
        local get_v3_group = {}
        local name = s[".name"]
        get_v3_group["user_name"]= uci:get("snmpd", name, "user_name")
        get_v3_group["user_group_name"]= uci:get("snmpd", name, "user_group_name")
        get_v3_group["user_sec_level"]= uci:get("snmpd", name, "user_sec_level")
        get_v3_group["user_auth_algo"]= uci:get("snmpd", name, "user_auth_algo")
        get_v3_group["auth_password"]= uci:get("snmpd", name, "auth_password")
        get_v3_group["user_priv_algo"]= uci:get("snmpd", name, "user_priv_algo")
        get_v3_group["priv_password"]= uci:get("snmpd", name, "priv_password")
        table.insert(get_uci_data["v3_auth"], get_v3_group)
    end
    )
    --trap_v1v2_user�û�
    uci:foreach("snmpd", "trap_v1v2_user", function(s)
        local get_trapv1v2 = {}
        local name = s[".name"]
        get_trapv1v2["trap_v1v2_ip"]= uci:get("snmpd", name, "trap_v1v2_ip")
        get_trapv1v2["trap_v1v2_port"]= uci:get("snmpd", name, "trap_v1v2_port")
        get_trapv1v2["trap_v1v2_com"]= uci:get("snmpd", name, "trap_v1v2_com")
        get_trapv1v2["trap_v1v2_type"]= uci:get("snmpd", name, "trap_v1v2_type")
        table.insert(get_uci_data["trap_v1v2_user"], get_trapv1v2)
    end
    )
    --trap_v3_user�û�
    uci:foreach("snmpd", "trap_v3_user", function(s)
        local get_v3_user = {}
        local name = s[".name"]
        get_v3_user["trap_v3_ip"]= uci:get("snmpd", name, "trap_v3_ip")
        get_v3_user["trap_v3_port"]= uci:get("snmpd", name, "trap_v3_port")
        get_v3_user["trap_v3_name"]= uci:get("snmpd", name, "trap_v3_name")
        get_v3_user["trap_user_sec_level"]= uci:get("snmpd", name, "trap_user_sec_level")
        get_v3_user["trap_user_auth_algo"]= uci:get("snmpd", name, "trap_user_auth_algo")
        get_v3_user["trap_auth_password"]= uci:get("snmpd", name, "trap_auth_password")
        get_v3_user["trap_user_priv_algo"]= uci:get("snmpd", name, "trap_user_priv_algo")
        get_v3_user["trap_priv_password"]= uci:get("snmpd", name, "trap_priv_password")
        table.insert(get_uci_data["trap_v3_user"], get_v3_user)
    end
    )

    return get_uci_data
end

--����������
local function parameter_check(snmp_param_data)
    --�鿴�����Ƿ�ഫ
    for key,value in pairs(snmp_param_data) do
        local value = 0
        local key_value = tostring(key)
        --�ش�����
        if (key_value == "user") then
            value = 1
        end
        --�ش�����
        if (key_value == "snmp_enable") then
            value = 1
        end
        --�ش�����
        if (key_value == "snmpd_port") then
            value = 1
        end
        if (key_value == "snmp_wan_enable") then
            value = 1
        end
        --�ش�����
        if (key_value == "snmp_ver") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "suConfigId") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "version") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "ConfigTime") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "currentTime") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "configId") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "networkId") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "groupId") then
            value = 1
        end
        --ϵͳĬ�ϲ���
        if (key_value == "engine_string") then
            value = 1
        end
        --�ش�����
        if (key_value == "view") then
            value = 1
            for ke,va in pairs(snmp_param_data[tostring(key)]) do
                for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                    local value_view = 0
                    if (tostring(k) == "view_name") then
                        value_view = 1
                    end
                    if (tostring(k) == "view_type") then
                        value_view = 1
                    end
                    if (tostring(k) == "view_oid") then
                        value_view = 1
                    end
                    if (value_view == 0) then
                        value = 0
                        break
                    end
                end
                if (value == 0) then
                    break
                end
            end
        end
        --�ش�����
        if (key_value == "view_name_list") then
            value = 1
        end
        --ѡ������
        if (key_value == "v1v2_auth") then
            value = 1
            --�п�
            if (snmp_param_data["v1v2_auth"] ~= nil or snmp_param_data["v1v2_auth"] ~= "") then
                for ke,va in pairs(snmp_param_data[tostring(key)]) do
                    for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                        local value_view = 0
                        if (tostring(k) == "v1v2_com") then
                            value_view = 1
                        end
                        if (tostring(k) == "v1v2_ac") then
                            value_view = 1
                        end
                        if (tostring(k) == "v1v2_view") then
                            value_view = 1
                        end
                        if (value_view == 0) then
                            value = 0
                            break
                        end
                    end
                    if (value == 0) then
                        break
                    end
                end
            end
        end
        --ѡ������
        if (key_value == "v3_group") then
            value = 1
            --�п�
            if (snmp_param_data["v3_group"] ~= nil or snmp_param_data["v3_group"] ~= "") then
                for ke,va in pairs(snmp_param_data[tostring(key)]) do
                    for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                        local value_view = 0
                        if (tostring(k) == "group_name") then
                            value_view = 1
                        end
                        if (tostring(k) == "group_sec_level") then
                            value_view = 1
                        end
                        if (tostring(k) == "group_write_view") then
                            value_view = 1
                        end
                        if (tostring(k) == "group_notify_view") then
                            value_view = 1
                        end
                        if (tostring(k) == "group_read_view") then
                            value_view = 1
                        end
                        if (value_view == 0) then
                            value = 0
                            break
                        end
                    end
                    if (value == 0) then
                        break
                    end
                end
            end
        end
        --ѡ������
        if (key_value == "v3_auth") then
            value = 1
            --�п�
            if (snmp_param_data["v3_auth"] ~= nil or snmp_param_data["v3_auth"] ~= "") then
                for ke,va in pairs(snmp_param_data[tostring(key)]) do
                    for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                        local value_view = 0
                        if (tostring(k) == "user_name") then
                            value_view = 1
                        end
                        if (tostring(k) == "user_group_name") then
                            value_view = 1
                        end
                        if (tostring(k) == "user_sec_level") then
                            value_view = 1
                        end
                        if (tostring(k) == "user_auth_algo") then
                            value_view = 1
                        end
                        if (tostring(k) == "auth_password") then
                            value_view = 1
                        end
                        if (tostring(k) == "user_priv_algo") then
                            value_view = 1
                        end
                        if (tostring(k) == "priv_password") then
                            value_view = 1
                        end
                        if (value_view == 0) then
                            value = 0
                            break
                        end
                    end
                    if (value == 0) then
                        break
                    end
                end
            end
        end
        --�ش�����
        if (key_value == "trap_enable") then
            value = 1
        end
        --ѡ������
        if (key_value == "trap_ver") then
            value = 1
        end
        --ѡ������
        if (key_value == "trap_v1v2_user") then
            value = 1
            --�п�
            if (snmp_param_data["trap_v1v2_user"] ~= nil or snmp_param_data["trap_v1v2_user"] ~= "") then
                for ke,va in pairs(snmp_param_data[tostring(key)]) do
                    for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                        local value_view = 0
                        if (tostring(k) == "trap_v1v2_ip") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_v1v2_port") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_v1v2_type") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_v1v2_com") then
                            value_view = 1
                        end
                        if (value_view == 0) then
                            value = 0
                            break
                        end
                    end
                    if (value == 0) then
                        break
                    end
                end
            end
        end
        --ѡ������
        if (key_value == "trap_v3_user") then
            value = 1
            --�п�
            if (snmp_param_data["trap_v3_user"] ~= nil or snmp_param_data["trap_v3_user"] ~= "") then
                for ke,va in pairs(snmp_param_data[tostring(key)]) do
                    for k,v in pairs(snmp_param_data[tostring(key)][ke]) do
                        local value_view = 0
                        if (tostring(k) == "trap_v3_name") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_v3_ip") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_v3_port") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_user_sec_level") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_user_auth_algo") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_auth_password") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_user_priv_algo") then
                            value_view = 1
                        end
                        if (tostring(k) == "trap_priv_password") then
                            value_view = 1
                        end
                        if (value_view == 0) then
                            value = 0
                            break
                        end
                    end
                    if (value == 0) then
                        break
                    end
                end
            end
        end
        if (value == 0) then
            return 0
        else
            return 1
        end
    end
end

--Ĭ�ϳ�ʼ������
function module_default_config_get()
    --uci���ݵĶ�ȡ
    local get_uci_data = read_uci_data("default")
    def_cfg_encode = dkjson.encode(get_uci_data)
    if (def_cfg_encode == nil) then
        libdbg.lua_debug(libdbg.WARNING, "def_cfg_json isn't json")
        return def_cfg_encode
    end

    return def_cfg_encode
end

--��ȡ�豸��SN��ת��Ϊ16����
function sn_to_scale()
    local get_sn_data
    local engineID_num = "80001f8804"
    local engine_string = {}
    --��ȡSN��
    engine_string["engine_string"] = uci:get_first("sysinfo", "sysinfo", "serial_num")
    if (engine_string["engine_string"] == nil or engine_string["engine_string"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "engine_string is nil")
        return -1 , engineID_num
    end
    --ת��SN��
    for t=1,#engine_string["engine_string"] do
        --����ÿ����ĸ�ַ���תΪASCII
        local ascii_engine = string.byte(engine_string["engine_string"],t)
        --ASIIתΪ16����
        local hex_engine = string.format("%x", ascii_engine)
        --ƴ��16����
        engineID_num = engineID_num..hex_engine
    end
    return 0, engineID_num
end

--set����
function module_set(param)
   --###################################��ȡ���ݼ�鲿��###############################
    local snmp_uci_data,snmp_param_data,snmp_json_data
    local ret
    local recode
    local ciphertext
    --����ȡ���ļ�ת��Ϊtable��ʽ
    ret, snmp_json_data = read_file_for_json(SD_DEVICE)
     if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "file is null.")
        return module_ret("1", "20", "NULL", "file is null!")
    end
    --�ж��豸�Ƿ�֧��snmp����; bugID[1159399]-��֧�ֵĲ��ܷ��ش��󣬷������豸�����ͬ����������־ˢ��
    if (snmp_json_data["snmp"] == nil or snmp_json_data["snmp"] == "") then
        return module_ret("0", "1", "NULL", "successful set, but not support start snmpd")
    end
    --1.��param�ļ������п�
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is null")
        return module_ret("1", "2", "param", "param is null!")
    end
    --2.param���и�ʽ���
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        if (param ~= nil) then
            libdbg.lua_debug(libdbg.WARNING, "param is unsafe",param)
        end
        libdbg.lua_debug(libdbg.ERROR, "param is unsafe")
        return module_ret("1", "2", "param", "param is unsafe!")
    end
    --3.��paramת��Ϊtable��ʽ
    snmp_param_data = cjson_safe.decode(param)
    if (snmp_param_data == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parse snmp param failed.")
        return module_ret("1", "2", "param", "parse snmp param failed!")
    end
    --4.��ȡuci�������
    snmp_uci_data = read_uci_data("current")
    --############################�����пպͲ������ƴ�������###########################
    if (parameter_check(snmp_param_data) == 0) then
        return module_ret("1", "2", "NULL", "invalid parameter passed in")
    end
    --user �����п�
     if (snmp_param_data["user"] == nil or snmp_param_data["user"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "param:user is nil")
        return module_ret("1", "2", "user", "param:user is nil")
     end
    if (snmp_uci_data["user"] == nil or snmp_uci_data["user"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "UCI:user is nil")
    end
    --user ��������
    if (#snmp_param_data["user"] > USER_LIM_H or #snmp_param_data["user"] < USER_LIM_L) then
        libdbg.lua_debug(libdbg.WARNING, "snmp param user:%s is invalid, require [1,64]", snmp_param_data["user"])
        return module_ret("1", "2", "user", "snmp_mode set require [1,64]")
    end
    --user ��������
    if (snmp_param_data["user"] ~= "snmp") then
        libdbg.lua_debug(libdbg.WARNING, "param:user is nil")
        return module_ret("1", "2", "user", "param:user shoule be snmp")
    end
    --snmp_enable �����п�
    if (snmp_param_data["snmp_enable"] == nil or snmp_param_data["snmp_enable"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "param:snmp_enable is nil")
        return module_ret("1", "2", "snmp_enable", "param:snmp_enable is nil")
    end
    if (snmp_uci_data["snmp_enable"] == nil or snmp_uci_data["snmp_enable"] =="") then
        libdbg.lua_debug(libdbg.WARNING, "UCI:snmp_enable is nil")
    end
     --snmp_enable ��������
    if (snmp_param_data["snmp_enable"] ~= "true" and snmp_param_data["snmp_enable"] ~= "false") then
        libdbg.lua_debug(libdbg.WARNING, "snmp param snmp_enable:%s is invalid, require <true|false>", snmp_param_data["snmp_enable"])
        return module_ret("1", "2", "snmp_enable", "snmp_mode set require <true|false>")
    end
    --snmpd_port �����п�
    if (snmp_param_data["snmpd_port"] == nil or snmp_param_data["snmpd_port"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "param:snmpd_port is nil")
        return module_ret("1", "2", "snmpd_port","param:snmpd_port is nil")
    end
    if (snmp_uci_data["snmpd_port"] == nil or snmp_uci_data["snmpd_port"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "UCI:snmpd_port is nil")
    end
    --snmpd_port ���������ұ���Ϊ����
    local port_numb = tonumber(snmp_param_data["snmpd_port"])
    if (port_numb == nil or port_numb > PORT_LIM_H or port_numb < PORT_LIM_L) then
        libdbg.lua_debug(libdbg.WARNING, "snmp param port_numb:%s is invalid, require [0, 65535]", snmp_param_data["snmpd_port"])
        return module_ret("1", "2", "snmpd_port", "snmp_mode set require [0, 65535]")
    end

    --snmp_wan_enable �����п�
    if (snmp_param_data["snmp_wan_enable"] == nil or snmp_param_data["snmp_wan_enable"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "param:snmp_wan_enable is nil")
        snmp_param_data["snmp_wan_enable"] = "false"
    end
    if (snmp_uci_data["snmp_wan_enable"] == nil or snmp_uci_data["snmp_wan_enable"] == "") then
        libdbg.lua_debug(libdbg.WARNING, "UCI:snmp_wan_enable is nil")
    end
    --snmp_wan_enable ��������
    if (snmp_param_data["snmp_wan_enable"] ~= "true" and snmp_param_data["snmp_wan_enable"] ~= "false") then
        libdbg.lua_debug(libdbg.WARNING, "snmp param snmp_wan_enable:%s is invalid, require <true|false>", snmp_param_data["snmp_wan_enable"])
        return module_ret("1", "2", "snmp_wan_enable", "snmp_mode set require <true|false>")
    end

    --�ж��Ƿ�֧��trap����
    if (snmp_json_data["snmp"]["snmp_trap_support"] ~= "1") then
        if (snmp_param_data["trap_enable"] == "true") then
            return module_ret("1", "22", "NULL", "the device does not support the trap services")
        end
    end
    if (snmp_json_data["snmp"]["snmp_trap_support"] == "1") then
    --trap_enable �����п�
        if (snmp_param_data["trap_enable"] == nil or snmp_param_data["trap_enable"] == "") then
            libdbg.lua_debug(libdbg.WARNING, "param:trap_enable is nil")
            return module_ret("1", "2", "trap_enable", "param:trap_enable is nil")
        end
        if (snmp_uci_data["trap_enable"] == nil or snmp_uci_data["trap_enable"] == "") then
            libdbg.lua_debug(libdbg.WARNING, "UCI:trap_enable is nil")
        end
        --trap_enable ��������
        if (snmp_param_data["trap_enable"] ~= "true" and snmp_param_data["trap_enable"] ~= "false") then
            libdbg.lua_debug(libdbg.WARNING, "snmp param trap_enable:%s is invalid, require <true|false>", snmp_param_data["trap_enable"])
            return module_ret("1", "2", "trap_enable", "require <true|false>")
        end
    end
    --�ж�OID�Ƿ����Ҫ������������ʽ
    if (snmp_param_data["view"] ~= nil and snmp_param_data["view"] ~= "") then
        for t=1,#snmp_param_data["view"] do
            if (snmp_param_data["view"][t]["view_name"] ~= "none") then
                if (snmp_param_data["view"][t]["view_oid"] == "" or snmp_param_data["view"][t]["view_oid"] == nil) then
                    return module_ret("1", "2", "view_oid", "UCI:view_oid is nil")
                end
                local oid_read = ""
                for oid_word in string.gmatch(snmp_param_data["view"][t]["view_oid"],".%d+") do
                    oid_read = oid_read..tostring(oid_word)
                end
                if (snmp_param_data["view"][t]["view_oid"] ~= oid_read) then
                    return module_ret("1", "2", "view_oid", "oid Format error")
                end
            end
        end
    end
    --view�ظ����ж�
    if (snmp_param_data["view_name_list"] ~= nil and snmp_param_data["view_name_list"] ~= "") then
        for t=1,#snmp_param_data["view_name_list"] do
            local view_repeat_user = 0
            local count_view_user = 0
            for i=1,#snmp_param_data["view_name_list"] do
                count_view_user = count_view_user + 1
                if (snmp_param_data["view_name_list"][i] == snmp_param_data["view_name_list"][t]) then
                    view_repeat_user = view_repeat_user + 1
                end
                if (count_view_user == #snmp_param_data["view_name_list"]) then
                    if (view_repeat_user ~= 1) then
                        return module_ret("1", "3", "view", "repeat view")
                    end
                end
            end
        end
    end
    --v1v2�û��ظ����ж�
    if (snmp_param_data["v1v2_auth"] ~= nil and snmp_param_data["v1v2_auth"] ~= "") then
        for t=1,#snmp_param_data["v1v2_auth"] do
            local v1v2_repeat_user = 0
            local count_v1v2_user = 0
            for i=1,#snmp_param_data["v1v2_auth"] do
                count_v1v2_user = count_v1v2_user + 1
                if (snmp_param_data["v1v2_auth"][i]["v1v2_com"] == snmp_param_data["v1v2_auth"][t]["v1v2_com"]) then
                    v1v2_repeat_user = v1v2_repeat_user + 1
                end
                if (count_v1v2_user == #snmp_param_data["v1v2_auth"]) then
                    if (v1v2_repeat_user ~= 1) then
                        return module_ret("1", "2", "v1v2_auth", "repeat user")
                    end
                end
            end
        end
    end
    --v3_group���ظ����ж�
    if (snmp_param_data["v3_group"] ~= nil and snmp_param_data["v3_group"] ~= "") then
        for t=1,#snmp_param_data["v3_group"] do
            local v3g_repeat_user = 0
            local count_v3g_user = 0
            for i=1,#snmp_param_data["v3_group"] do
                count_v3g_user = count_v3g_user + 1
                if (snmp_param_data["v3_group"][i]["group_name"] == snmp_param_data["v3_group"][t]["group_name"]) then
                    v3g_repeat_user = v3g_repeat_user + 1
                end
                if (count_v3g_user == #snmp_param_data["v3_group"]) then
                    if (v3g_repeat_user ~= 1) then
                        return module_ret("1", "5", "v3_group", "repeat user")
                    end
                end
            end
        end
    end
    --v3_auth�û��ظ����ж�
    if (snmp_param_data["v3_auth"] ~= nil and snmp_param_data["v3_auth"] ~= "") then
        for t=1,#snmp_param_data["v3_auth"] do
            local v3_repeat_user = 0
            local count_v3_user = 0
            for i=1,#snmp_param_data["v3_auth"] do
                count_v3_user = count_v3_user + 1
                if (snmp_param_data["v3_auth"][i]["user_name"] == snmp_param_data["v3_auth"][t]["user_name"]) then
                    v3_repeat_user = v3_repeat_user + 1
                end
                if (count_v3_user == #snmp_param_data["v3_auth"]) then
                    if (v3_repeat_user ~= 1) then
                        return module_ret("1", "6", "v3_auth", "repeat user")
                    end
                end
            end
        end
    end
    --trap_v1v2_user �û��ظ����ж�
    if (snmp_param_data["trap_v1v2_user"] ~= nil and snmp_param_data["trap_v1v2_user"] ~= "") then
        for t=1,#snmp_param_data["trap_v1v2_user"] do
            local trapv1v2_repeat_user = 0
            local count_trapv1v2_user = 0
            for i=1,#snmp_param_data["trap_v1v2_user"] do
                count_trapv1v2_user = count_trapv1v2_user + 1
                local trap_v1v2_ip_value_i = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
                if (trap_v1v2_ip_value_i == nil) then
                    return module_ret("1", "2", "trap_v1v2_ip", "param:trap_v1v2_ip is nil")
                end
                local trap_v1v2_ip_value_t = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v1v2_user"][t]["trap_v1v2_ip"])
                if (trap_v1v2_ip_value_t == nil) then
                    return module_ret("1", "2", "trap_v1v2_ip", "param:trap_v1v2_ip is nil")
                end
                if (trap_v1v2_ip_value_i == trap_v1v2_ip_value_t) then
                    trapv1v2_repeat_user = trapv1v2_repeat_user + 1
                end
                if (count_trapv1v2_user == #snmp_param_data["trap_v1v2_user"]) then
                    if (trapv1v2_repeat_user ~= 1) then
                        return module_ret("1", "7", "trap_v1v2_user", "repeat user")
                    end
                end
            end
        end
    end
    --trap_v3_user �û��ظ����ж�
    if (snmp_param_data["trap_v3_user"] ~= nil and snmp_param_data["trap_v3_user"] ~= "") then
        for t=1,#snmp_param_data["trap_v3_user"] do
            local trapv3_repeat_user = 0
            local count_trapv3user = 0
            for i=1,#snmp_param_data["trap_v3_user"] do
                count_trapv3user = count_trapv3user + 1
                local trap_v3_ip_value_i = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
                if (trap_v3_ip_value_i == nil) then
                    return module_ret("1", "2", "trap_v3_ip", "param:trap_v3_ip is nil")
                end
                local trap_v3_ip_value_t = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v3_user"][t]["trap_v3_ip"])
                if (trap_v3_ip_value_t == nil) then
                    return module_ret("1", "2", "trap_v3_ip", "param:trap_v3_ip is nil")
                end
                if (trap_v3_ip_value_i == trap_v3_ip_value_t) then
                    trapv3_repeat_user = trapv3_repeat_user + 1
                end
                if (count_trapv3user == #snmp_param_data["trap_v3_user"]) then
                    if (trapv3_repeat_user ~= 1) then
                        return module_ret("1", "8", "trap_v3_user", "repeat user")
                    end
                end
            end
        end
    end
    --################################�߼���������##############################
    --�ж�snmp_type�Ǵ���
    if (uci:foreach("snmpd", "snmp_parameter", function(s) end) == false) then
        uci:set("snmpd", "snmp_parameter", "snmp_type")
    end
    --�ж�trap_type�Ǵ���
    if (uci:foreach("snmpd", "trap_parameter", function(s) end) == false) then
        uci:set("snmpd", "trap_parameter", "trap_type")
    end
    --user ���ݱȽ�
    if (snmp_param_data["user"] ~= snmp_uci_data["user"]) then
        uci:set("snmpd", "snmp_parameter", "user", snmp_param_data["user"])
    end
    --snmp_enable ���ݱȽ�
    if (snmp_param_data["snmp_enable"] ~= snmp_uci_data["snmp_enable"]) then
        uci:set("snmpd", "snmp_parameter", "snmp_enable", snmp_param_data["snmp_enable"])
    end
    --snmpd_port ���ݱȽ�
    if (snmp_param_data["snmpd_port"] ~= snmp_uci_data["snmpd_port"]) then
        uci:set("snmpd", "snmp_parameter", "snmpd_port", snmp_param_data["snmpd_port"])
    end
    --snmp_wan_enable ���ݱȽ�
    if (snmp_param_data["snmp_wan_enable"] ~= snmp_uci_data["snmp_wan_enable"]) then
        uci:set("snmpd", "snmp_parameter", "snmp_wan_enable", snmp_param_data["snmp_wan_enable"])
    end
    --trap_enable ���ݱȽ�
    if (snmp_param_data["trap_enable"] ~= snmp_uci_data["trap_enable"]) then
        uci:set("snmpd", "trap_parameter", "trap_enable", snmp_param_data["trap_enable"])
    end

    --�ж��豸�Ƿ�֧��IPv6
    if (snmp_json_data["snmp"]["snmp_config_ipv6"] ~= nil and snmp_json_data["snmp"]["snmp_config_ipv6"] ~= "") then
        local snmp_config_ipv6 = snmp_json_data["snmp"]["snmp_config_ipv6"]
        uci:set("snmpd", "snmp_parameter", "snmp_config_ipv6", tostring(snmp_config_ipv6))
    else
        uci:set("snmpd", "snmp_parameter", "snmp_config_ipv6", "0")
    end

    --����ת�����sn�ֶ�
    local state, sna_date = sn_to_scale()
    if (state == -1) then
        uci:set("snmpd", "snmp_parameter", "serial_num", "80001f880441")
    else
        uci:set("snmpd", "snmp_parameter", "serial_num", tostring(sna_date))
    end

    --trap_enable����snmp_enable���뿪��
    if (snmp_param_data["trap_enable"] == "true") then
        if (snmp_param_data["snmp_enable"] == "false") then
            return module_ret("1", "9", "trap_enable", "please open snmp server")
        end
    end

    --�ж� snmp_ver ����
    if (snmp_param_data["snmp_enable"] == "true") then
        --�ж��Ƿ�֧��"v1/v2c/v3"
        local snmp_v1 = snmp_json_data["snmp"]["snmp_v1_support"]
        local snmp_v2c = snmp_json_data["snmp"]["snmp_v2c_support"]
        local snmp_v3 = snmp_json_data["snmp"]["snmp_v3_support"]
        if (snmp_v1 ~= "1" and snmp_v2c ~= "1" and snmp_v3 ~= "1") then
            return module_ret("1", "23", "NULL", "the device does not support the SNMP_V1/V2C/V3 service")
        end
    else
        if (snmp_param_data["snmp_ver"] == nil or #snmp_param_data["snmp_ver"] == 0) then
            uci:set("snmpd", "snmp_parameter", "v1", "0")
            uci:set("snmpd", "snmp_parameter", "v2c", "0")
            uci:set("snmpd", "snmp_parameter", "v3", "0")
        end
    end
    if (snmp_param_data["snmp_enable"] == "true") then
        --snmp_ver �����п�
        if (snmp_param_data["snmp_ver"] == nil or table.getn(snmp_param_data["snmp_ver"]) == 0) then
            libdbg.lua_debug(libdbg.WARNING, "param:snmp_ver is nil")
            return module_ret("1", "2", "snmp_ver", "param:snmp_ver is nil")
        end
        if (snmp_uci_data["snmp_ver"] == nil or table.getn(snmp_uci_data["snmp_ver"]) == 0) then
            libdbg.lua_debug(libdbg.WARNING, "UCI:snmp_ver is nil")
        end
        for key,value in pairs(snmp_param_data["snmp_ver"]) do
            if (value ~= "v1" and value ~= "v2c" and value ~= "v3") then
                libdbg.lua_debug(libdbg.WARNING, "param:snmp_ver is nil")
                return module_ret("1", "2", "snmp_ver", "snmp_ver set require v1/v2c/v3")
            end
        end
        --set v1
        for key,value in pairs(snmp_param_data["snmp_ver"]) do
            if (value == "v1") then
                --�ж��Ƿ�֧��"v1"
                if (snmp_json_data["snmp"]["snmp_v1_support"] ~= "1") then
                    return module_ret("1", "24", "NULL", "the device does not support the SNMP_V1 service")
                end
                uci:set("snmpd", "snmp_parameter", "v1", "1")
                break
            end
            uci:set("snmpd", "snmp_parameter", "v1", "0")
        end
        --set v2c
        for key,value in pairs(snmp_param_data["snmp_ver"]) do
            if (value == "v2c") then
                --�ж��Ƿ�֧��"v2c"
                if (snmp_json_data["snmp"]["snmp_v2c_support"] ~= "1") then
                    return module_ret("1", "25", "NULL", "the device does not support the SNMP_V2C service")
                end
                uci:set("snmpd", "snmp_parameter", "v2c", "1")
                break
            end
            uci:set("snmpd", "snmp_parameter", "v2c", "0")
        end
        --set v3
        for key,value in pairs(snmp_param_data["snmp_ver"]) do
            if (value == "v3") then
                --�ж��Ƿ�֧��"v3"
                if (snmp_json_data["snmp"]["snmp_v3_support"] ~= "1") then
                    return module_ret("1", "26", "NULL", "the device does not support the V3 service")
                end
                uci:set("snmpd", "snmp_parameter", "v3", "1")
                break
            end
            uci:set("snmpd", "snmp_parameter", "v3", "0")
        end
    end
    --�ж� trap_ver ����
    if (snmp_param_data["snmp_enable"] == "true" and snmp_param_data["trap_enable"] == "true") then
        local trap_v1 = snmp_json_data["snmp"]["snmp_v1_trap_support"]
        local trap_v2c = snmp_json_data["snmp"]["snmp_v2c_trap_support"]
        local trap_v3 = snmp_json_data["snmp"]["snmp_v3_trap_support"]
        if (trap_v1 ~= "1" and trap_v2c ~= "1" and trap_v3 ~= "1") then
            return module_ret("1", "27", "snmp_ver", "the device does not support the trap V1/V2C/V3 service")
        end
        --trap_ver �����п�
        if (snmp_param_data["trap_ver"] == nil or #snmp_param_data["trap_ver"] == 0) then
            libdbg.lua_debug(libdbg.WARNING, "param:trap_ver is nil")
            return module_ret("1", "2", "trap_ver", "param:trap_ver is nil")
        end
        --trap_ver �����ж�
        for key,value in pairs(snmp_param_data["trap_ver"]) do
            if (value ~= "v1" and value ~= "v2c" and value ~= "v3") then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_ver is nil")
                return module_ret("1", "2", "trap_ver", "trap_ver set require v1/v2c/v3")
            end
        end
    end
    if (snmp_param_data["trap_ver"] == nil or #snmp_param_data["trap_ver"] == 0) then
        uci:set("snmpd", "trap_parameter", "trap_v1", "0")
        uci:set("snmpd", "trap_parameter", "trap_v2", "0")
        uci:set("snmpd", "trap_parameter", "trap_v3", "0")
    else
    --set trap_v1
        for key,value in pairs(snmp_param_data["trap_ver"]) do
            if (value == "v1") then
            --�ж��Ƿ�֧��"v1"
                if (snmp_json_data["snmp"]["snmp_v1_trap_support"] ~= "1") then
                    return module_ret("1", "28", "NULL", "the device does not support the trap V1 service")
                end
                uci:set("snmpd", "trap_parameter", "trap_v1", "1")
                break
            end
            uci:set("snmpd", "trap_parameter", "trap_v1", "0")
        end
        --set trap_v2
        for key,value in pairs(snmp_param_data["trap_ver"]) do
            if (value == "v2c") then
                --�ж��Ƿ�֧��"v2c"
                if (snmp_json_data["snmp"]["snmp_v2c_trap_support"] ~= "1") then
                    return module_ret("1", "29", "NULL", "the device does not support the trap V2C service")
                end
                uci:set("snmpd", "trap_parameter", "trap_v2", "1")
                break
            end
            uci:set("snmpd", "trap_parameter", "trap_v2", "0")
        end
        --set trap_v3
        for key,value in pairs(snmp_param_data["trap_ver"]) do
            if (value == "v3") then
                --�ж��Ƿ�֧��"v3"
                if (snmp_json_data["snmp"]["snmp_v3_trap_support"] ~= "1") then
                    return module_ret("1", "30", "NULL", "the device does not support the trap V3 service")
                end
                uci:set("snmpd", "trap_parameter", "trap_v3", "1")
                break
            end
        uci:set("snmpd", "trap_parameter", "trap_v3", "0")
        end
    end
--################################�û���������##############################
    --view_name_list�ж�
    if (snmp_param_data["view_name_list"] == nil or #snmp_param_data["view_name_list"] == 0) then
        libdbg.lua_debug(libdbg.WARNING, "param:view < 2")
        return module_ret("1", "10", "view", "view < 2")
     end
    --�����п�
    local view_number = 0
    if (snmp_json_data["snmp"]["snmp_view_num"] ~= nil and snmp_json_data["snmp"]["snmp_view_num"] ~= "") then
        --�ж��Ƿ�Ϊ�����Ҵ��ڵ���2
        local view_numb = tonumber(snmp_json_data["snmp"]["snmp_view_num"])
        if (view_numb == nil or view_numb < 2) then
            view_number = VIEW_H
        else
            view_number = view_numb
        end
    else
        view_number = VIEW_H
    end
    --��ΪĬ��ֵ
    if (#snmp_param_data["view_name_list"] > view_number) then
        libdbg.lua_debug(libdbg.WARNING, "snmp param view:%s is invalid, require [0, "..tostring(view_number).."]", tostring(#snmp_param_data["view"]))
        return module_ret("1", "31", "view", "snmp_mode set require [0, "..tostring(view_number).."]")
    end
    if (snmp_param_data["view_name_list"] ~= nil and #snmp_param_data["view_name_list"] ~= 0) then
        --�ж��Ƿ�all��none������ͼ
        local view_all = 0
        local vall_none = 0
        for j = 1,table.getn(snmp_param_data["view_name_list"]) do
            if (snmp_param_data["view_name_list"][j] == "all") then
                view_all = view_all + 1
            end
            if (snmp_param_data["view_name_list"][j] == "none") then
                vall_none = vall_none + 1
            end
            --view_name �����п�
            if (snmp_param_data["view_name_list"][j] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:view_name is nil")
                return module_ret("1", "2", "view_name", "param:view_name is nil")
            end
            --view_name ��������
            if (#snmp_param_data["view_name_list"][j] > VIEW_NAME_H or #snmp_param_data["view_name_list"][j] < VIEW_NAME_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param view_name:%s is invalid, require [1, 255]", snmp_param_data["view_name_list"][j])
                return module_ret("1", "2", "view_name", "snmp_mode set require [1, 255]")
            end
            --�ж�view_name_list��Ӧ��ͼ�Ƿ�Ϊ��
            local view_name_nam = 0
            if (snmp_param_data["view"] == nil or table.getn(snmp_param_data["view"]) == 0) then
                return module_ret("1", "10", "view", "view < 2")
            end
            for t = 1,table.getn(snmp_param_data["view"]) do
                if (snmp_param_data["view_name_list"][t] == snmp_param_data["view"][t]["view_name"]) then
                    view_name_nam = view_name_nam + 1
                    break
                end
            end
            --Ϊ�յ�ʱ��
            if (view_name_nam == 0) then
                return module_ret("1", "17", "view_name_list", "view_name_list not OID")
            end
        end
        if (view_all ~= 1 or vall_none ~= 1) then
            return module_ret("1", "10", "view", "all or none view is change or delede")
        end
        --view_name_list �ļ�������
        uci:set_list("snmpd", "snmp_parameter", "view_name_list", snmp_param_data["view_name_list"])
    end

    --����view��ͼ��view_name��view_type��view_oid��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["view"] == nil or table.getn(snmp_param_data["view"]) == 0) then
        return module_ret("1", "10", "view", "view < 2")
    end
    if (snmp_param_data["view"] ~= nil or table.getn(snmp_param_data["view"]) ~= 0) then
        --ɾ��view-uci����
        if (snmp_uci_data["view"] ~= nil or table.getn(snmp_uci_data["view"]) ~= 0) then
            uci:foreach("snmpd", "view", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
        local all_view = 0
        local none_view = 0
        for i = 1,table.getn(snmp_param_data["view"]) do
            --�ж��Ƿ����all��none
            if (snmp_param_data["view"][i]["view_name"] == "all") then
                if (snmp_param_data["view"][i]["view_type"] == "include") then
                    if (snmp_param_data["view"][i]["view_oid"] == ".1") then
                        all_view = all_view + 1
                    else
                        return module_ret("1", "10", "view_oid", "all view is change")
                    end
                else
                    return module_ret("1", "10", "view_type", "all view is change")
                end
            end
            if (snmp_param_data["view"][i]["view_name"] == "none") then
                if (snmp_param_data["view"][i]["view_type"] == "include") then
                    if (snmp_param_data["view"][i]["view_oid"] == "--") then
                        none_view = none_view + 1
                    else
                        return module_ret("1", "10", "view_oid", "none view is change")
                    end
                else
                    return module_ret("1", "10", "view_type", "none view is change")
                end
            end
            --�ж��Ƿ�������
            local view_name_group = 0
            for t = 1,table.getn(snmp_param_data["view_name_list"]) do
                if (snmp_param_data["view_name_list"][t] == snmp_param_data["view"][i]["view_name"]) then
                    view_name_group = view_name_group + 1
                    break
                end
            end
            --Ϊ�յ�ʱ��
            if (view_name_group == 0) then
                return module_ret("1", "18", "view", "view not included int the view_name_list")
            end
            --����view��׺(��ֹ�������
            local view_user = snmp_param_data["view"][i]["view_name"]
            view_param_num = view_param_num + 1
            local user_view = "user_"..tostring(view_param_num).."_view"
            --view_name �����п�
            if (snmp_param_data["view"][i]["view_name"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:view_name is nil")
                return module_ret("1", "2", "view_name", "param:view_name is nil")
            end
            --view_name ��������
            if (#snmp_param_data["view"][i]["view_name"] > VIEW_NAME_H or #snmp_param_data["view"][i]["view_name"] < VIEW_NAME_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param view_name:%s is invalid, require [1, 255]", snmp_param_data["view"][i]["view_name"])
                return module_ret("1", "2", "view_name", "snmp_mode set require [1, 255]")
            end
            --view_type �����п�
            if (snmp_param_data["view"][i]["view_type"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:view_type is nil")
                return module_ret("1", "2", "view_type", "param:view_type is nil")
            end
            --view_type ��������
            local comm_type = snmp_param_data["view"][i]["view_type"]
            if (comm_type ~= "include" and comm_type ~= "exclude") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param view_type:%s is invalid, require <include|exclude>", comm_type)
                return module_ret("1", "2", "view_type", "snmp_mode set require <include|exclude>")
            end
            --view_oid �����п�
            if (snmp_param_data["view"][i]["view_oid"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:view_oid is nil")
                return module_ret("1", "2", "view_oid", "param:view_oid is nil")
            end
            --view_oid ��������
            if (#snmp_param_data["view"][i]["view_oid"] > VIEW_OID_H or #snmp_param_data["view"][i]["view_oid"] < VIEW_OID_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param view_oid:%s is invalid, require [1, 255]", snmp_param_data["view"][i]["view_oid"])
                return module_ret("1", "2", "view_oid", "snmp_mode set require [1, 255]")
            end
            --�ж�oid�Ƿ�����ͬ�Ĳ���
            local oid_name = 0
            for t = 1,table.getn(snmp_param_data["view"]) do
                if (snmp_param_data["view"][i]["view_name"] == snmp_param_data["view"][t]["view_name"]) then
                    if (snmp_param_data["view"][i]["view_oid"] == snmp_param_data["view"][t]["view_oid"]) then
                        oid_name = oid_name + 1
                    end
                end
            end
            if (oid_name ~= 1) then
                return module_ret("1", "2", "view_oid", "view_oid set the same")
            end
            --�ж��Ƿ����������
            uci:set("snmpd", user_view, "view")
            uci:set("snmpd", user_view, "view_name", snmp_param_data["view"][i]["view_name"])
            uci:set("snmpd", user_view, "view_type", snmp_param_data["view"][i]["view_type"])
            uci:set("snmpd", user_view, "view_oid", snmp_param_data["view"][i]["view_oid"])
        end
        if (all_view ~= 1 or none_view ~= 1) then
            return module_ret("1", "2", "view", "all or none view is change or delede")
        end
    end
    --����v1v2_auth (v1v2_com��v1v2_ac��v1v2_view ��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["v1v2_auth"] == nil or table.getn(snmp_param_data["v1v2_auth"]) == 0) then
        if (snmp_uci_data["v1v2_auth"] ~= nil or table.getn(snmp_uci_data["v1v2_auth"]) ~= 0) then
            --������ȫ��ɾ��
            uci:foreach("snmpd", "v1v2_auth", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
    end
    --v1v2-uci���ݴ��ڽ�����ɾ��
    if (snmp_param_data["v1v2_auth"] ~= nil and table.getn(snmp_param_data["v1v2_auth"]) ~= 0) then
        --�����п�
        local snmp_v1v2_number = 0
        if (snmp_json_data["snmp"]["snmp_community_num"] ~= nil and snmp_json_data["snmp"]["snmp_community_num"] ~= "") then
            --�ж��Ƿ�Ϊ�����Ҵ��ڵ���2
            local snmp_v1v2_numb = tonumber(snmp_json_data["snmp"]["snmp_community_num"])
            if (snmp_v1v2_numb == nil) then
                snmp_v1v2_number = V1V2C_H
            else
                snmp_v1v2_number = snmp_v1v2_numb
            end
        else
            snmp_v1v2_number = V1V2C_H
        end
        --v1v2_auth��������С��20
        if (#snmp_param_data["v1v2_auth"] > snmp_v1v2_number) then
            libdbg.lua_debug(libdbg.WARNING, "snmp param v1v2_auth:%s is invalid, require [0, "..tostring(snmp_v1v2_number).."]", tostring(#snmp_param_data["v1v2_auth"]))
            libdbg.lua_debug(libdbg.WARNING, "param:v1v2_auth is nil")
            return module_ret("1", "11", "v1v2_auth", "snmp_mode set require [0, "..tostring(snmp_v1v2_number).."]")
        end
        --ɾ������v1v2�û�
        uci:foreach("snmpd", "v1v2_auth", function(s)
            local name = s[".name"]
            uci:delete("snmpd", name)
        end
        )
        for i=1,table.getn(snmp_param_data["v1v2_auth"]) do
            --����v1v2_user��׺(��ֹ�������
            local v1v2_user = snmp_param_data["v1v2_auth"][i]["com"]
            v1v2_param_num = v1v2_param_num + 1
            local user_v1v2 = "user_"..tostring(v1v2_param_num).."_v1v2"
            --v1v2_com  �����п�
            if (snmp_param_data["v1v2_auth"][i]["v1v2_com"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:v1v2_com is nil")
                return module_ret("1", "2", "v1v2_com", "param:v1v2_com is nil")
            end
            --v1v2_com ��������
            if (#snmp_param_data["v1v2_auth"][i]["v1v2_com"] > V1V2_COM_H or #snmp_param_data["v1v2_auth"][i]["v1v2_com"] < V1V2_COM_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param v1v2_com:%s is invalid, require [8, 32]", snmp_param_data["v1v2_auth"][i]["v1v2_com"])
                return module_ret("1", "2", "v1v2_com", "snmp_mode set require [8, 32]")
            end
            --v1v2_com ����������
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["v1v2_auth"][i]["v1v2_com"], #snmp_param_data["v1v2_auth"][i]["v1v2_com"], 'c')
            if (recode ~= 0) then
                libdbg.lua_debug(libdbg.WARNING, "v1v2_com encrypt failed")
                return module_ret("1", "2", "v1v2_com", "v1v2_com encrypt failed")
            end
            snmp_param_data["v1v2_auth"][i]["v1v2_com"] = ciphertext
            --v1v2_ac �����п�
            if (snmp_param_data["v1v2_auth"][i]["v1v2_ac"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:v1v2_ac is nil")
                return module_ret("1", "2", "v1v2_ac", "param:v1v2_ac is nil")
            end
            --v1v2_ac ��������
            local comm_type = snmp_param_data["v1v2_auth"][i]["v1v2_ac"]
            if (comm_type ~= "ro" and comm_type ~= "rw") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param v1v2_ac:%s is invalid, require <ro|rw>", comm_type)
                return module_ret("1", "2", "v1v2_ac", "snmp_mode set require <ro|rw>")
            end
            --v1v2_view �����п�
            if (snmp_param_data["v1v2_auth"][i]["v1v2_view"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:v1v2_view is nil")
                return module_ret("1", "2", "v1v2_view", "param:v1v2_view is nil")
            end
            --�ж�v1v2_view�Ƿ���view��ͼ����
            local v1v2_v = 0
            for j = 1,table.getn(snmp_param_data["view_name_list"]) do
                if (snmp_param_data["view_name_list"][j] == snmp_param_data["v1v2_auth"][i]["v1v2_view"]) then
                    v1v2_v = v1v2_v + 1
                    break
                end
            end
            if (v1v2_v == 0) then
                return module_ret("1", "12", "v1v2_view", "the variable is not in the optional range")
            end
            uci:set("snmpd", user_v1v2, "v1v2_auth")
            uci:set("snmpd", user_v1v2, "v1v2_com", snmp_param_data["v1v2_auth"][i]["v1v2_com"])
            uci:set("snmpd", user_v1v2, "v1v2_ac", snmp_param_data["v1v2_auth"][i]["v1v2_ac"])
            uci:set("snmpd", user_v1v2, "v1v2_view", snmp_param_data["v1v2_auth"][i]["v1v2_view"])
        end
    end

--����v3_group (group_name��group_sec_level��group_read_view��group_write_view��group_notify_view��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["v3_group"] == nil or table.getn(snmp_param_data["v3_group"]) == 0) then
        if (snmp_uci_data["v3_group"] ~= nil or table.getn(snmp_uci_data["v3_group"]) ~= 0) then
            --������ȫ��ɾ��
            uci:foreach("snmpd", "v3_group", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
    end
    --v3_group-uci���ݴ��ڽ�����ɾ��
    if (snmp_param_data["v3_group"] ~= nil and table.getn(snmp_param_data["v3_group"]) ~= 0) then
        local snmp_v3group_number = 0
        if (snmp_json_data["snmp"]["snmp_v3_group_num"] ~= nil and snmp_json_data["snmp"]["snmp_v3_group_num"] ~= "") then
            --�ж��Ƿ�Ϊ����
            local snmp_v3group_numb = tonumber(snmp_json_data["snmp"]["snmp_v3_group_num"])
            if (snmp_v3group_numb == nil) then
                snmp_v3group_number = V3_GROUP_H
            else
                snmp_v3group_number = snmp_v3group_numb
            end
        else
            snmp_v3group_number = V3_GROUP_H
        end
        --v3_group��������С��20
        if (#snmp_param_data["v3_group"] > snmp_v3group_number) then
            libdbg.lua_debug(libdbg.WARNING, "snmp param v3_group:%s is invalid, require [0, "..tostring(snmp_v3group_number).."]", tostring(#snmp_param_data["v3_group"]))
            return module_ret("1", "11", "v3_group", "snmp_mode set require [0, "..tostring(snmp_v3group_number).."]")
        end
        --ɾ������v3_group-�û�
        uci:foreach("snmpd", "v3_group", function(s)
            local name = s[".name"]
            uci:delete("snmpd", name)
        end
        )
        for i = 1,table.getn(snmp_param_data["v3_group"]) do
            --����v1v2_user��׺(��ֹ�������
            local v3group_user = snmp_param_data["v3_group"][i]["group_name"]
            v3group_param_num = v3group_param_num + 1
            local user_v3group = "user_"..tostring(v3group_param_num).."_v3group"
            --group_name �����п�
            if (snmp_param_data["v3_group"][i]["group_name"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:group_name is nil")
                return module_ret("1", "2", "group_name", "param:group_name is nil")
            end
            --group_name ��������
            if (#snmp_param_data["v3_group"][i]["group_name"] > GROUP_NAME_H or #snmp_param_data["v3_group"][i]["group_name"] < GROUP_NAME_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param group_name:%s is invalid, require [1, 32]", snmp_param_data["v3_group"][i]["group_name"])
                return module_ret("1", "2", "group_name", "snmp_mode set require [1, 32]")
            end
            --group_sec_level �����п�
            if (snmp_param_data["v3_group"][i]["group_sec_level"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:group_sec_level is nil")
                return module_ret("1", "2", "group_sec_level", "param:group_sec_level is nil")
            end
            --group_sec_level ��������
            local sec_type = snmp_param_data["v3_group"][i]["group_sec_level"]
            if (sec_type ~= "priv" and sec_type ~= "auth" and sec_type ~= "noauth") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param group_sec_level:%s is invalid, require priv/auth/noauth", sec_type)
                return module_ret("1", "2", "group_sec_level", "snmp_mode set require priv/auth/noauth")
            end
            --group_read_view �����п�
            if (snmp_param_data["v3_group"][i]["group_read_view"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:group_read_view is nil")
                return module_ret("1", "2", "group_read_view", "param:group_read_view is nil")
            end
            --group_write_view �����п�
            if (snmp_param_data["v3_group"][i]["group_write_view"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:group_write_view is nil")
                return module_ret("1", "2", "group_write_view", "param:group_write_view is nil")
            end
            --group_notify_view �����п�
            if (snmp_param_data["v3_group"][i]["group_notify_view"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:group_notify_view is nil")
                return module_ret("1", "2", "group_notify_view", "param:group_notify_view is nil")
            end
            --�ж�v3_group�Ƿ���view��ͼ����
            local v3_group_r = 0
            local v3_group_w = 0
            local v3_group_n = 0
            for j = 1,table.getn(snmp_param_data["view_name_list"]) do
                if (snmp_param_data["view_name_list"][j] == snmp_param_data["v3_group"][i]["group_read_view"]) then
                    v3_group_r = v3_group_r + 1
                end
                if (snmp_param_data["view_name_list"][j] == snmp_param_data["v3_group"][i]["group_write_view"]) then
                    v3_group_w = v3_group_w + 1
                end
                if (snmp_param_data["view_name_list"][j] == snmp_param_data["v3_group"][i]["group_notify_view"]) then
                    v3_group_n = v3_group_n + 1
                end
            end
            if (v3_group_r == 0) then
                return module_ret("1", "12", "group_read_view", "the variable is not in the optional range")
            end
            if (v3_group_w == 0) then
                return module_ret("1", "12", "group_write_view", "the variable is not in the optional range")
            end
            if (v3_group_n == 0) then
                return module_ret("1", "12", "group_notify_view", "the variable is not in the optional range")
            end
            uci:set("snmpd", user_v3group, "v3_group")
            uci:set("snmpd", user_v3group, "group_name", snmp_param_data["v3_group"][i]["group_name"])
            uci:set("snmpd", user_v3group, "group_sec_level", snmp_param_data["v3_group"][i]["group_sec_level"])
            uci:set("snmpd", user_v3group, "group_read_view", snmp_param_data["v3_group"][i]["group_read_view"])
            uci:set("snmpd", user_v3group, "group_write_view", snmp_param_data["v3_group"][i]["group_write_view"])
            uci:set("snmpd", user_v3group, "group_notify_view", snmp_param_data["v3_group"][i]["group_notify_view"])
        end
    end

    --����v3_auth (user_name��user_group_name��user_sec_level��user_auth_algo��auth_password��user_priv_algo��priv_password��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["v3_auth"] == nil or table.getn(snmp_param_data["v3_auth"]) == 0) then
        if (snmp_uci_data["v3_auth"] ~= nil or table.getn(snmp_uci_data["v3_auth"]) ~= 0) then
            --������ȫ��ɾ��
            uci:foreach("snmpd", "v3_auth", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
    end
    --v3_auth-uci���ݴ��ڽ�����ɾ��
    if (snmp_param_data["v3_auth"] ~= nil and table.getn(snmp_param_data["v3_auth"]) ~= 0) then
        local snmp_v3auth_number = 0
        if (snmp_json_data["snmp"]["snmp_v3_user_num"] ~= nil and snmp_json_data["snmp"]["snmp_v3_user_num"] ~= "") then
            --�ж��Ƿ�Ϊ����
            local snmp_v3auth_numb = tonumber(snmp_json_data["snmp"]["snmp_v3_user_num"])
            if (snmp_v3auth_numb == nil) then
                snmp_v3auth_number = V3_H
            else
                snmp_v3auth_number = snmp_v3auth_numb
            end
        else
            snmp_v3auth_number = V3_H
        end
        --v3_auth_auth��������С��50
         if (#snmp_param_data["v3_auth"] > snmp_v3auth_number) then
            libdbg.lua_debug(libdbg.WARNING, "snmp param v3_auth:%s is invalid, require [0, "..tostring(snmp_v3auth_number).."]", tostring(#snmp_param_data["v3_auth"]))
            return module_ret("1", "11", "v3_auth", "snmp_mode set require [0, "..tostring(snmp_v3auth_number).."]")
         end
        --ɾ������v3_auth-�û�
        uci:foreach("snmpd", "v3_auth", function(s)
            local name = s[".name"]
            uci:delete("snmpd", name)
        end
        )
        for i = 1,table.getn(snmp_param_data["v3_auth"]) do
            --����v1v2_user��׺(��ֹ�������
            local v3user_user = snmp_param_data["v3_auth"][i]["user_name"]
            v3user_param_num = v3user_param_num + 1
            local user_v3user = "user_"..tostring(v3user_param_num).."_v3"
            --user_name �����п�
            if (snmp_param_data["v3_auth"][i]["user_name"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:user_name is nil")
                return module_ret("1", "2", "user_name", "param:user_name is nil")
            end
            --user_name ��������
            if (#snmp_param_data["v3_auth"][i]["user_name"] > USER_NAME_H or #snmp_param_data["v3_auth"][i]["user_name"] < USER_NAME_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param user_name:%s is invalid, require [8, 32]", snmp_param_data["v3_auth"][i]["user_name"])
                return module_ret("1", "2", "user_name", "snmp_mode set require [8, 32]")
            end
            --user_name �û�������
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["v3_auth"][i]["user_name"], #snmp_param_data["v3_auth"][i]["user_name"], 'c')
            if (recode ~= 0) then
                libdbg.lua_debug(libdbg.WARNING, "user_name encrypt failed")
                return module_ret("1", "2", "user_name", "user_name encrypt failed")
            end
            snmp_param_data["v3_auth"][i]["user_name"] = ciphertext
            --user_sec_level �����п�
            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:user_sec_level is nil")
                return module_ret("1", "2", "user_sec_level", "param:user_sec_level is nil")
            end
            --user_sec_level ��������
            local sec_type = snmp_param_data["v3_auth"][i]["user_sec_level"]
            if (sec_type ~= "priv" and sec_type ~= "auth" and sec_type ~= "noauth") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param user_sec_level:%s is invalid, require priv/auth/noauth", sec_type)
                return module_ret("1", "2", "user_sec_level", "snmp_mode set require priv/auth/noauth")
            end
            --user_group_name �����п�
            if (snmp_param_data["v3_auth"][i]["user_group_name"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:user_group_name is nil")
                return module_ret("1", "2", "user_group_name", "param:user_group_name is nil")
            end
            --�ж�v3_auth �Ƿ��ڴ��ڵ�������
            if (snmp_param_data["v3_group"] ~= nil and table.getn(snmp_param_data["v3_group"]) ~= 0) then
                local v3_auth_g = 0
                for j = 1,table.getn(snmp_param_data["v3_group"]) do
                    if (snmp_param_data["v3_group"][j]["group_name"] == snmp_param_data["v3_auth"][i]["user_group_name"]) then
                        v3_auth_g = v3_auth_g + 1
                        if (snmp_param_data["v3_group"][j]["group_sec_level"] == "priv") then
                            if (snmp_param_data["v3_auth"][i]["user_sec_level"] ~= "priv") then
                                return module_ret("1", "13", "v3_auth", "this v3_auth permission is less than this group")
                            end
                        end
                        if (snmp_param_data["v3_group"][j]["group_sec_level"] == "auth") then
                            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == "noauth") then
                                return module_ret("1", "13", "v3_auth", "this v3_auth permission is less than this group")
                            end
                        end
                        break
                    end
                end
                if (v3_auth_g == 0) then
                    return module_ret("1", "14", "user_group_name", "the variable is not in the optional range")
                end
            else
                return module_ret("1", "15", "user_group_name", "please create group before creating a v3 user")
            end
            --�û��ķ��ʷ�ʽΪpriv
            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == "priv") then
                --user_auth_algo �����п�
                if (snmp_param_data["v3_auth"][i]["user_auth_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:user_auth_algo is nil")
                    return module_ret("1", "2", "user_auth_algo", "param:user_auth_algo is nil")
                end
                --user_auth_algo ��������
                local auth_algo_type = snmp_param_data["v3_auth"][i]["user_auth_algo"]
                if (auth_algo_type ~= "MD5" and auth_algo_type ~= "SHA" and auth_algo_type ~= "SHA224" and auth_algo_type ~= "SHA256" and auth_algo_type ~= "SHA384" and auth_algo_type ~= "SHA512") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param user_auth_algo:%s is invalid, require MD5/SHA/SHA224/SHA256/SHA384/SHA512", auth_algo_type)
                    return module_ret("1", "2", "user_auth_algo", "snmp_mode set require MD5/SHA/SHA224/SHA256/SHA384/SHA512")
                end
                --user_priv_algo �����п�
                if (snmp_param_data["v3_auth"][i]["user_priv_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:user_priv_algo is nil")
                    return module_ret("1", "2", "user_priv_algo ", "param:user_priv_algo is nil")
                end
                --user_priv_algo ��������
                local priv_algo_type = snmp_param_data["v3_auth"][i]["user_priv_algo"]
                if (priv_algo_type ~= "DES" and priv_algo_type ~= "AES" and priv_algo_type ~= "AES192" and priv_algo_type ~= "AES256") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param user_priv_algo:%s is invalid, DES/AES/AES192/AES256", priv_algo_type)
                    return module_ret("1", "2", "user_priv_algo", "snmp_mode set require DES/AES/AES192/AES256")
                end
                --auth_password �����п�
                if (snmp_param_data["v3_auth"][i]["auth_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:auth_password is nil")
                    return module_ret("1", "2", "auth_password", "param:auth_password is nil")
                end
                --auth_password ��������
                if (#snmp_param_data["v3_auth"][i]["auth_password"] > AUTH_PASSWORD_H or #snmp_param_data["v3_auth"][i]["auth_password"] < AUTH_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param auth_password :%s is invalid, require [8, 31]", snmp_param_data["v3_auth"][i]["auth_password"])
                    return module_ret("1", "2", "auth_password", "require [8, 31]")
                end
                --auth_password ��֤�������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["v3_auth"][i]["auth_password"], #snmp_param_data["v3_auth"][i]["auth_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "auth_password encrypt failed")
                    return module_ret("1", "2", "v3_auth", "auth_password encrypt failed")
                end
                snmp_param_data["v3_auth"][i]["auth_password"] = ciphertext
                --priv_password �����п�
                if (snmp_param_data["v3_auth"][i]["priv_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:priv_password is nil")
                    return module_ret("1", "2", "priv_password", "param:priv_password is nil")
                end
                --priv_password ��������
                if (#snmp_param_data["v3_auth"][i]["priv_password"] > PRIV_PASSWORD_H or #snmp_param_data["v3_auth"][i]["priv_password"] < PRIV_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param priv_password:%s is invalid, require [8, 31]", snmp_param_data["v3_auth"][i]["priv_password"])
                    return module_ret("1", "2", "priv_password", "snmp_mode set require [8, 31]")
                end
                --priv_password �����������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["v3_auth"][i]["priv_password"], #snmp_param_data["v3_auth"][i]["priv_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "priv_password encrypt failed")
                    return module_ret("1", "2", "v3_auth", "priv_password encrypt failed")
                end
                snmp_param_data["v3_auth"][i]["priv_password"] = ciphertext
            end
            --�û��ķ��ʷ�ʽΪauth
            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == "auth") then
                --user_auth_algo �����п�
                if (snmp_param_data["v3_auth"][i]["user_auth_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:user_auth_algo is nil")
                    return module_ret("1", "2", "user_auth_algo", "param:user_auth_algo is nil")
                end
                --user_auth_algo ��������
                local auth_algo_type = snmp_param_data["v3_auth"][i]["user_auth_algo"]
                if (auth_algo_type ~= "MD5" and auth_algo_type ~= "SHA" and auth_algo_type ~= "SHA224" and auth_algo_type ~= "SHA256" and auth_algo_type ~= "SHA384" and auth_algo_type ~= "SHA512") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param user_auth_algo:%s is invalid, require MD5/SHA/SHA224/SHA256/SHA384/SHA512", auth_algo_type)
                    return module_ret("1", "2", "user_auth_algo", "snmp_mode set require MD5/SHA/SHA224/SHA256/SHA384/SHA512")
                end
                --auth_password �����п�
                if (snmp_param_data["v3_auth"][i]["auth_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:auth_password is nil")
                    return module_ret("1", "2", "auth_password", "param:auth_password is nil")
                end
                --auth_password ��������
                if (#snmp_param_data["v3_auth"][i]["auth_password"] > AUTH_PASSWORD_H or #snmp_param_data["v3_auth"][i]["auth_password"] < AUTH_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param auth_password :%s is invalid, require [8, 31]", snmp_param_data["v3_auth"][i]["auth_password"])
                    return module_ret("1", "2", "auth_password", "require [8, 31]")
                end
                --auth_password ��֤�������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["v3_auth"][i]["auth_password"], #snmp_param_data["v3_auth"][i]["auth_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "auth_password encrypt failed")
                    return module_ret("1", "2", "v3_auth", "auth_password encrypt failed")
                end
                snmp_param_data["v3_auth"][i]["auth_password"] = ciphertext
            end
            --�û��ķ��ʷ�ʽΪauth
            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == "auth") then
                 if (snmp_param_data["v3_auth"][i]["user_priv_algo"] == "" or snmp_param_data["v3_auth"][i]["user_priv_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["user_priv_algo"] = "AES"
                 end
                 if (snmp_param_data["v3_auth"][i]["priv_password"] == "" or snmp_param_data["v3_auth"][i]["priv_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["priv_password"] = "Priv123"
                 end
            end
            --�û��ķ��ʷ�ʽΪnoauth
            if (snmp_param_data["v3_auth"][i]["user_sec_level"] == "noauth") then
                if (snmp_param_data["v3_auth"][i]["user_auth_algo"] == "" or snmp_param_data["v3_auth"][i]["user_auth_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["user_auth_algo"] = "MD5"
                end
                if (snmp_param_data["v3_auth"][i]["auth_password"] == "" or snmp_param_data["v3_auth"][i]["auth_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["auth_password"] = "Auth123"
                end
                if (snmp_param_data["v3_auth"][i]["user_priv_algo"] == "" or snmp_param_data["v3_auth"][i]["user_priv_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["user_priv_algo"] = "AES"
                end
                if (snmp_param_data["v3_auth"][i]["priv_password"] == "" or snmp_param_data["v3_auth"][i]["priv_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["v3_auth"][i]["priv_password"] = "Priv123"
                end
            end
            --v3�û�д��uci
            uci:set("snmpd", user_v3user, "v3_auth")
            uci:set("snmpd", user_v3user, "user_name", snmp_param_data["v3_auth"][i]["user_name"])
            uci:set("snmpd", user_v3user, "user_group_name", snmp_param_data["v3_auth"][i]["user_group_name"])
            uci:set("snmpd", user_v3user, "user_sec_level", snmp_param_data["v3_auth"][i]["user_sec_level"])
            uci:set("snmpd", user_v3user, "user_auth_algo", snmp_param_data["v3_auth"][i]["user_auth_algo"])
            uci:set("snmpd", user_v3user, "auth_password", snmp_param_data["v3_auth"][i]["auth_password"])
            uci:set("snmpd", user_v3user, "user_priv_algo", snmp_param_data["v3_auth"][i]["user_priv_algo"])
            uci:set("snmpd", user_v3user, "priv_password", snmp_param_data["v3_auth"][i]["priv_password"])
        end
    end

    --����trap_v1v2_user (trap_v1v2_ip��trap_v1v2_port��trap_v1v2_com��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["trap_v1v2_user"] == nil or table.getn(snmp_param_data["trap_v1v2_user"]) == 0) then
        if (snmp_uci_data["trap_v1v2_user"] ~= nil or table.getn(snmp_uci_data["trap_v1v2_user"]) ~= 0) then
            --������ȫ��ɾ��
            uci:foreach("snmpd", "trap_v1v2_user", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
    end

    --trap_v1v2_user-uci���ݴ��ڽ�����ɾ��
    if (snmp_param_data["trap_v1v2_user"] ~= nil and table.getn(snmp_param_data["trap_v1v2_user"]) ~= 0) then
        local trap_v1v2c_number = 0
        if (snmp_json_data["snmp"]["snmp_v1_v2c_trap_num"] ~= nil and snmp_json_data["snmp"]["snmp_v1_v2c_trap_num"] ~= "") then
            --�ж��Ƿ�Ϊ����
            local trap_v1v2c_numb = tonumber(snmp_json_data["snmp"]["snmp_v1_v2c_trap_num"])
            if (trap_v1v2c_numb == nil) then
                trap_v1v2c_number = TRAP_V1V2_H
            else
                trap_v1v2c_number = trap_v1v2c_numb
            end
        else
            trap_v1v2c_number = TRAP_V1V2_H
        end
        --v1v2_auth��������С��20
        if (#snmp_param_data["trap_v1v2_user"] > trap_v1v2c_number) then
            libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v1v2_user:%s is invalid, require [0, "..tostring(trap_v1v2c_number).."]", tostring(#snmp_param_data["trap_v1v2_user"]))
            libdbg.lua_debug(libdbg.WARNING, "param:trap_v1v2_user is nil")
            return module_ret("1", "11", "trap_v1v2_user", "snmp_mode set require [0, "..tostring(trap_v1v2c_number).."]")
        end
        --ɾ������trap_v1v2_user�û�
        uci:foreach("snmpd", "trap_v1v2_user", function(s)
            local name = s[".name"]
            uci:delete("snmpd", name)
        end
        )
        for i=1,table.getn(snmp_param_data["trap_v1v2_user"]) do
            --����trap_v1v2_user��׺(��ֹ�������
            local trap_v1v2_user = snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"]
            trapv1v2_param_num = trapv1v2_param_num + 1
            local user_trapv1v2 = "user_"..tostring(trapv1v2_param_num).."_trapv1v2"
            --trap_v1v2_ip �����п�
            if (snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v1v2_ip is nil")
                return module_ret("1", "2", "trap_v1v2_ip", "param:trap_v1v2_ip is nil")
            end
            --trap_v1v2_ip ��������
            if (#snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"] > TRAPV1V2_IP_H or #snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"] < TRAPV1V2_IP_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v1v2_ip:%s is invalid, require [0, 64]", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
                return module_ret("1", "2", "trap_v1v2_ip", "snmp_mode set require [0, 64]")
            end
            --�ж�v1v2��ip��v3ip�Ƿ���ͬ
            if (snmp_param_data["trap_v3_user"] ~= nil and table.getn(snmp_param_data["trap_v3_user"]) ~= 0) then
                local trapv1v2_ip = 0
                for j = 1,table.getn(snmp_param_data["trap_v3_user"]) do
                    local trap_v3_ip_value = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v3_user"][j]["trap_v3_ip"])
                    if (trap_v3_ip_value == nil) then
                        return module_ret("1", "2", "trap_v3_ip", "param:trap_v3_ip is nil")
                    end
                    local trap_v1v2_ip_value = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
                    if (trap_v1v2_ip_value == nil) then
                        return module_ret("1", "2", "trap_v1v2c_ip", "param:trap_v1v2c_ip is nil")
                    end
                    if (trap_v3_ip_value == trap_v1v2_ip_value) then
                        trapv1v2_ip = trapv1v2_ip + 1
                        break
                    end
                end
                if (trapv1v2_ip ~= 0) then
                    return module_ret("1", "16", "trap_v1v2_ip", "trapv1v2 and trapv3 have the same IP")
                end
            end
           --trap_v1v2_type �����п�
            if (snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_type"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v1v2_type is nil")
                return module_ret("1", "2", "trap_v1v2_type", "param:trap_v1v2_type is nil")
            end
            --trap_v1v2_type ��������
            local sec_type = snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_type"]
            if (sec_type ~= "v1" and sec_type ~= "v2c") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v1v2_type:%s is invalid, require v1/v2c", sec_type)
                return module_ret("1", "2", "trap_v1v2_type", "snmp_mode set require v1/v2c")
            end
            --trap_v1v2_port �����п�
            if (snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_port"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v1v2_port is nil")
                return module_ret("1", "2", "trap_v1v2_port", "param:trap_v1v2_port is nil")
            end
            --trap_v1v2_port ���������ұ���Ϊ����
            local trapport_numb = tonumber(snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_port"])
            if (trapport_numb == nil or trapport_numb > TRAPV1V2_PORT_H or trapport_numb < TRAPV1V2_PORT_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v1v2_port:%s is invalid, require [1, 65535]", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_port"])
                return module_ret("1", "2", "trap_v1v2_port", "snmp_mode set require [1, 65535]")
            end
            --trap_v1v2_com �����п�
            if (snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v1v2_com is nil")
                return module_ret("1", "2", "trap_v1v2_com", "param:trap_v1v2_com is nil")
            end
            --trap_v1v2_com ��������
            if (#snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"] > TRAPV1V2_COM_H or #snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"] < TRAPV1V2_COM_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v1v2_com:%s is invalid, require [1, 32]", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"])
                return module_ret("1", "2", "trap_v1v2_com", "snmp_mode set require [8, 32]")
            end
            --trap_v1v2_com trap����������
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"], #snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"], 'c')
            if (recode ~= 0) then
                libdbg.lua_debug(libdbg.WARNING, "trap_v1v2_com encrypt failed")
                return module_ret("1", "2", "trap_v1v2_user", "trap_v1v2_com encrypt failed")
            end
            snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"] = ciphertext
            --��ip4/ipv6����У�������ֶ�(ip_type)
            local ip_typev4 = ip_type.is_ipv4_address(snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
            if (ip_typev4 == 0) then
                uci:set("snmpd", user_trapv1v2, "trap_v1v2_user")
                uci:set("snmpd", user_trapv1v2, "ip_type", "ipv4")
                uci:set("snmpd", user_trapv1v2, "trap_v1v2_ip", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
                uci:set("snmpd", user_trapv1v2, "trap_v1v2_type", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_type"])
                uci:set("snmpd", user_trapv1v2, "trap_v1v2_port", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_port"])
                uci:set("snmpd", user_trapv1v2, "trap_v1v2_com", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"])
            else
                if (snmp_json_data["snmp"]["snmp_config_ipv6"] == "1") then
                    uci:set("snmpd", user_trapv1v2, "trap_v1v2_user")
                    uci:set("snmpd", user_trapv1v2, "ip_type", "ipv6")
                    uci:set("snmpd", user_trapv1v2, "trap_v1v2_ip", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_ip"])
                    uci:set("snmpd", user_trapv1v2, "trap_v1v2_type", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_type"])
                    uci:set("snmpd", user_trapv1v2, "trap_v1v2_port", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_port"])
                    uci:set("snmpd", user_trapv1v2, "trap_v1v2_com", snmp_param_data["trap_v1v2_user"][i]["trap_v1v2_com"])
                else
                    -- bugid[1452778]��trap����IPV6��ַʱ����֧��IPV6���豸ֻ��Чjson���ã�����Чuci����
                    libdbg.lua_debug(libdbg.INFO, "param:snmp_config_ipv6 not support ipv6")
                end
            end
        end
    end
    --����trap_v3_user (trap_v3_ip��trap_v3_port��trap_v3_name��trap_user_sec_level��trap_user_auth_algo��trap_auth_password��trap_user_priv_algo��trap_priv_password��
    --�ж�param�Ƿ�Ϊ��
    if (snmp_param_data["trap_v3_user"] == nil or table.getn(snmp_param_data["trap_v3_user"]) == 0) then
        if (snmp_uci_data["trap_v3_user"] ~= nil or table.getn(snmp_uci_data["trap_v3_user"]) ~= 0) then
            --������ȫ��ɾ��
            uci:foreach("snmpd", "trap_v3_user", function(s)
                local name = s[".name"]
                uci:delete("snmpd", name)
            end
            )
        end
    end
    --trap_v3_user-uci���ݴ��ڽ�����ɾ��
    if (snmp_param_data["trap_v3_user"] ~= nil and table.getn(snmp_param_data["trap_v3_user"]) ~= 0) then
        local trap_v3_number = 0
        if (snmp_json_data["snmp"]["snmp_v3_trap_num"] ~= nil and snmp_json_data["snmp"]["snmp_v3_trap_num"] ~= "") then
            --�ж��Ƿ�Ϊ����
            local trap_v3_numb = tonumber(snmp_json_data["snmp"]["snmp_v3_trap_num"])
            if (trap_v3_numb == nil) then
                trap_v3_number = TRAP_V3_H
            else
                trap_v3_number = trap_v3_numb
            end
        else
            trap_v3_number = TRAP_V3_H
        end
        --trap_v3_user��������С��20
        if (#snmp_param_data["trap_v3_user"] > trap_v3_number) then
            libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v3_user:%s is invalid, require [0, "..tostring(trap_v3_number).."]", tostring(#snmp_param_data["trap_v3_user"]))
            libdbg.lua_debug(libdbg.WARNING, "param:trap_v3_user is nil")
            return module_ret("1", "11", "trap_v3_user", "snmp_mode set require [0, "..tostring(trap_v3_number).."]")
        end
        --ɾ������trap_v3_user-�û�
        uci:foreach("snmpd", "trap_v3_user", function(s)
            local name = s[".name"]
            uci:delete("snmpd", name)
        end
        )
        for i = 1,table.getn(snmp_param_data["trap_v3_user"]) do
            --����trap_v3_user��׺(��ֹ�������
            local trap_v3_user = snmp_param_data["trap_v3_user"][i]["trap_v3_ip"]
            trapv3_param_num = trapv3_param_num + 1
            local user_trapv3user = "user_"..tostring(trapv3_param_num).."_trapv3"
            --trap_v3_ip �����п�
            if (snmp_param_data["trap_v3_user"][i]["trap_v3_ip"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v3_ip is nil")
                return module_ret("1", "2", "trap_v3_ip", "param:trap_v3_ip is nil")
            end
            --trap_v3_ip ��������
            if (#snmp_param_data["trap_v3_user"][i]["trap_v3_ip"] > TRAP_V3_IP_H or #snmp_param_data["trap_v3_user"][i]["trap_v3_ip"] < TRAP_V3_IP_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v3_ip:%s is invalid, require [0, 64]", snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
                return module_ret("1", "2", "trap_v3_ip", "snmp_mode set require [0, 64]")
            end
            --�ж�v1v2��ip��v3ip�Ƿ���ͬ
            if (snmp_param_data["trap_v1v2_user"] ~= nil and table.getn(snmp_param_data["trap_v1v2_user"]) ~= 0) then
                local trapv3_ip = 0
                for j = 1,table.getn(snmp_param_data["trap_v1v2_user"]) do
                    local trap_v3_ip_value = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
                    if (trap_v3_ip_value == nil) then
                        return module_ret("1", "2", "trap_v3_ip", "param:trap_v3_ip is nil")
                    end
                    local trap_v1v2_ip_value = ip_type.convert_to_standard_ipv6(snmp_param_data["trap_v1v2_user"][j]["trap_v1v2_ip"])
                    if (trap_v1v2_ip_value == nil) then
                        return module_ret("1", "2", "trap_v1v2c_ip", "param:trap_v1v2c_ip is nil")
                    end
                    if (trap_v3_ip_value == trap_v1v2_ip_value) then
                        trapv3_ip = trapv3_ip + 1
                        break
                    end
                end
                if (trapv3_ip ~= 0) then
                    return module_ret("1", "16", "trap_v3_ip", "trapv1v2 and trapv3 have the same IP")
                end
            end
            --trap_v3_port �����п�
            if (snmp_param_data["trap_v3_user"][i]["trap_v3_port"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v3_port is nil")
                return module_ret("1", "2", "trap_v3_port", "param:trap_v3_port is nil")
            end
            --trap_v3_port ���������ұ���Ϊ����
            local trapport_numb = tonumber(snmp_param_data["trap_v3_user"][i]["trap_v3_port"])
            if (trapport_numb == nil or trapport_numb > TRAP_V3_PORT_H or trapport_numb < TRAP_V3_PORT_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v3_port:%s is invalid, require [0, 65535]", snmp_param_data["trap_v3_user"][i]["trap_v3_port"])
                return module_ret("1", "2", "trap_v3_port", "snmp_mode set require [0, 65535]")
            end
            --trap_v3_name �����п�
            if (snmp_param_data["trap_v3_user"][i]["trap_v3_name"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_v3_name is nil")
                return module_ret("1", "2", "trap_v3_name", "param:trap_v3_name is nil")
            end
            --trap_v3_name ��������
            if (#snmp_param_data["trap_v3_user"][i]["trap_v3_name"] > TRAP_V3_NAME_H or #snmp_param_data["trap_v3_user"][i]["trap_v3_name"] < TRAP_V3_NAME_L) then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_v3_name:%s is invalid, require [8, 32]", snmp_param_data["trap_v3_user"][i]["trap_v3_name"])
                return module_ret("1", "2", "trap_v3_name", "snmp_mode set require [8, 32]")
            end
            --trap_v3_name trap�û�������
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["trap_v3_user"][i]["trap_v3_name"], #snmp_param_data["trap_v3_user"][i]["trap_v3_name"], 'c')
            if (recode ~= 0) then
                libdbg.lua_debug(libdbg.WARNING, "trap_v3_name encrypt failed")
                return module_ret("1", "2", "trap_v3_user", "trap_v3_name encrypt failed")
            end
            snmp_param_data["trap_v3_user"][i]["trap_v3_name"] = ciphertext
            --trap_user_sec_level �����п�
            if (snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"] == nil) then
                libdbg.lua_debug(libdbg.WARNING, "param:trap_user_sec_level is nil")
                return module_ret("1", "2", "trap_user_sec_level", "param:trap_user_sec_level is nil")
            end
            --trap_user_sec_level ��������
            local trapv3_type = snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"]
            if (trapv3_type ~= "priv" and trapv3_type ~= "auth" and trapv3_type ~= "noauth") then
                libdbg.lua_debug(libdbg.WARNING, "snmp param trap_user_sec_level:%s is invalid, require priv/auth/noauth", trapv3_type)
                return module_ret("1", "2", "trap_user_sec_level", "snmp_mode set require priv/auth/noauth")
            end
            --trap_user_sec_level �û��ķ��ʷ�ʽΪpriv
            if (snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"] == "priv") then
                --trap_user_auth_algo �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_user_auth_algo is nil")
                    return module_ret("1", "2", "trap_user_auth_algo", "param:trap_user_auth_algo is nil")
                end
                --trap_user_auth_algo ��������
                local auth_algo_type = snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"]
                if (auth_algo_type ~= "MD5" and auth_algo_type ~= "SHA" and auth_algo_type ~= "SHA224" and auth_algo_type ~= "SHA256" and auth_algo_type ~= "SHA384" and auth_algo_type ~= "SHA512") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_user_auth_algo:%s is invalid, require MD5/SHA/SHA224/SHA256/SHA384/SHA512", auth_algo_type)
                    return module_ret("1", "2", "trap_user_auth_algo", "snmp_mode set require MD5/SHA/SHA224/SHA256/SHA384/SHA512")
                end
                --trap_user_priv_algo �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_user_priv_algo  is nil")
                    return module_ret("1", "2", "trap_user_priv_algo ", "param:trap_user_priv_algo is nil")
                end
                --trap_user_priv_algo ��������
                local priv_algo_type = snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"]
                if (priv_algo_type ~= "DES" and priv_algo_type ~= "AES" and priv_algo_type ~= "AES192" and priv_algo_type ~= "AES256") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_user_priv_algo:%s is invalid, DES/AES/AES192/AES256", priv_algo_type)
                    return module_ret("1", "2", "trap_user_priv_algo", "snmp_mode set require DES/AES/AES192/AES256")
                end
                --trap_auth_password �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_auth_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_auth_password is nil")
                    return module_ret("1", "2", "trap_auth_password ", "param:trap_auth_password is nil")
                end
                --trap_auth_password ��������
                if (#snmp_param_data["trap_v3_user"][i]["trap_auth_password"] > TRAP_AUTH_PASSWORD_H or #snmp_param_data["trap_v3_user"][i]["trap_auth_password"] < TRAP_AUTH_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_auth_password :%s is invalid, require [8, 31]", snmp_param_data["trap_v3_user"][i]["trap_auth_password"])
                    return module_ret("1", "2", "trap_auth_password ", "require [8, 31]")
                end
                --trap_auth_password trap��֤�������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["trap_v3_user"][i]["trap_auth_password"], #snmp_param_data["trap_v3_user"][i]["trap_auth_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "trap_auth_password encrypt failed")
                    return module_ret("1", "2", "trap_v3_user", "trap_auth_password encrypt failed")
                end
                snmp_param_data["trap_v3_user"][i]["trap_auth_password"] = ciphertext
                --trap_priv_password �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_priv_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_priv_password is nil")
                    return module_ret("1", "2", "trap_priv_password", "param:trap_priv_password is nil")
                end
                --trap_priv_password ��������
                if (#snmp_param_data["trap_v3_user"][i]["trap_priv_password"] > TRAP_PRIV_PASSWORD_H or #snmp_param_data["trap_v3_user"][i]["trap_priv_password"] < TRAP_PRIV_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_priv_password:%s is invalid, require [8, 31]", snmp_param_data["trap_v3_user"][i]["trap_priv_password"])
                    return module_ret("1", "2", "trap_priv_password", "snmp_mode set require [8, 31]")
                end
                --trap_priv_password trap�����������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["trap_v3_user"][i]["trap_priv_password"], #snmp_param_data["trap_v3_user"][i]["trap_priv_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "trap_priv_password encrypt failed")
                    return module_ret("1", "2", "trap_v3_user", "trap_priv_password encrypt failed")
                end
                snmp_param_data["trap_v3_user"][i]["trap_priv_password"] = ciphertext
            end
            --trap_user_sec_level �û��ķ��ʷ�ʽΪauth
            if (snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"] == "auth") then
                --trap_user_auth_algo �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_user_auth_algo is nil")
                    return module_ret("1", "2", "trap_user_auth_algo", "param:trap_user_auth_algo is nil")
                end
                --trap_user_auth_algo ��������
                local auth_algo_type = snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"]
                if (auth_algo_type ~= "MD5" and auth_algo_type ~= "SHA" and auth_algo_type ~= "SHA224" and auth_algo_type ~= "SHA256" and auth_algo_type ~= "SHA384" and auth_algo_type ~= "SHA512") then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_user_auth_algo:%s is invalid, require MD5/SHA/SHA224/SHA256/SHA384/SHA512", auth_algo_type)
                    return module_ret("1", "2", "trap_user_auth_algo", "snmp_mode set require MD5/SHA/SHA224/SHA256/SHA384/SHA512")
                end
                --trap_auth_password �����п�
                if (snmp_param_data["trap_v3_user"][i]["trap_auth_password"] == nil) then
                    libdbg.lua_debug(libdbg.WARNING, "param:trap_auth_password is nil")
                    return module_ret("1", "2", "trap_auth_password ", "param:trap_auth_password is nil")
                end
                --trap_auth_password ��������
                if (#snmp_param_data["trap_v3_user"][i]["trap_auth_password"] > TRAP_AUTH_PASSWORD_H or #snmp_param_data["trap_v3_user"][i]["trap_auth_password"] < TRAP_AUTH_PASSWORD_L) then
                    libdbg.lua_debug(libdbg.WARNING, "snmp param trap_auth_password :%s is invalid, require [8, 31]", snmp_param_data["trap_v3_user"][i]["trap_auth_password"])
                    return module_ret("1", "2", "trap_auth_password ", "require [8, 31]")
                end
                --trap_auth_password trap��֤�������
                recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(snmp_param_data["trap_v3_user"][i]["trap_auth_password"], #snmp_param_data["trap_v3_user"][i]["trap_auth_password"], 'c')
                if (recode ~= 0) then
                    libdbg.lua_debug(libdbg.WARNING, "trap_auth_password encrypt failed")
                    return module_ret("1", "2", "trap_v3_user", "trap_auth_password encrypt failed")
                end
                snmp_param_data["trap_v3_user"][i]["trap_auth_password"] = ciphertext
            end
            --�û��ķ��ʷ�ʽΪauth
            if (snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"] == "auth") then
                if (snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] == "" or snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] = "AES"
                end
                if (snmp_param_data["trap_v3_user"][i]["trap_priv_password"] == "" or snmp_param_data["trap_v3_user"][i]["trap_priv_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_priv_password"] = "Priv123"
                end
            end
            --�û��ķ��ʷ�ʽΪnoauth
            if (snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"] == "noauth") then
                if (snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"] == "" or snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"] = "MD5"
                end
                if (snmp_param_data["trap_v3_user"][i]["trap_auth_password"] == "" or snmp_param_data["trap_v3_user"][i]["trap_auth_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_auth_password"] = "Auth123"
                end
                if (snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] == "" or snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"] = "AES"
                end
                if (snmp_param_data["trap_v3_user"][i]["trap_priv_password"] == "" or snmp_param_data["trap_v3_user"][i]["trap_priv_password"] == nil) then
                    --����ʼֵ
                    snmp_param_data["trap_v3_user"][i]["trap_priv_password"] = "Priv123"
                end
            end
            --v3�û�д��uci
            --��ip4/ipv6����У�������ֶ�(ip_type)
            local ip_typev4 = ip_type.is_ipv4_address(snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
            if (ip_typev4 == 0) then
                uci:set("snmpd", user_trapv3user, "trap_v3_user")
                uci:set("snmpd", user_trapv3user, "ip_type", "ipv4")
                uci:set("snmpd", user_trapv3user, "trap_v3_ip", snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
                uci:set("snmpd", user_trapv3user, "trap_v3_port", snmp_param_data["trap_v3_user"][i]["trap_v3_port"])
                uci:set("snmpd", user_trapv3user, "trap_v3_name", snmp_param_data["trap_v3_user"][i]["trap_v3_name"])
                uci:set("snmpd", user_trapv3user, "trap_user_sec_level", snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"])
                uci:set("snmpd", user_trapv3user, "trap_user_auth_algo", snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"])
                uci:set("snmpd", user_trapv3user, "trap_auth_password", snmp_param_data["trap_v3_user"][i]["trap_auth_password"])
                uci:set("snmpd", user_trapv3user, "trap_user_priv_algo", snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"])
                uci:set("snmpd", user_trapv3user, "trap_priv_password", snmp_param_data["trap_v3_user"][i]["trap_priv_password"])
            else
                if (snmp_json_data["snmp"]["snmp_config_ipv6"] == "1") then
                    uci:set("snmpd", user_trapv3user, "trap_v3_user")
                    uci:set("snmpd", user_trapv3user, "ip_type", "ipv6")
                    uci:set("snmpd", user_trapv3user, "trap_v3_ip", snmp_param_data["trap_v3_user"][i]["trap_v3_ip"])
                    uci:set("snmpd", user_trapv3user, "trap_v3_port", snmp_param_data["trap_v3_user"][i]["trap_v3_port"])
                    uci:set("snmpd", user_trapv3user, "trap_v3_name", snmp_param_data["trap_v3_user"][i]["trap_v3_name"])
                    uci:set("snmpd", user_trapv3user, "trap_user_sec_level", snmp_param_data["trap_v3_user"][i]["trap_user_sec_level"])
                    uci:set("snmpd", user_trapv3user, "trap_user_auth_algo", snmp_param_data["trap_v3_user"][i]["trap_user_auth_algo"])
                    uci:set("snmpd", user_trapv3user, "trap_auth_password", snmp_param_data["trap_v3_user"][i]["trap_auth_password"])
                    uci:set("snmpd", user_trapv3user, "trap_user_priv_algo", snmp_param_data["trap_v3_user"][i]["trap_user_priv_algo"])
                    uci:set("snmpd", user_trapv3user, "trap_priv_password", snmp_param_data["trap_v3_user"][i]["trap_priv_password"])
                else
                    -- bugid[1452778]��trap����IPV6��ַʱ����֧��IPV6���豸ֻ��Чjson���ã�����Чuci����
                    libdbg.lua_debug(libdbg.INFO, "param:snmp_config_ipv6 not support ipv6")
                end
            end
        end
    end
    --�������ö����ܳɹ�, ������enc_type�ֶ�
    uci:set("snmpd", "snmp_parameter", "enc_type", "1")
    uci:commit("snmpd")
    --os.execute("/etc/init.d/snmpd start")
    utils_exec.fork_exec_cmd("/etc/init.d/snmpd start")
    return module_ret("0", "1", "NULL", "successful set")
end