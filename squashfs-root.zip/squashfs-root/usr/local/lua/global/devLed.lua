#! /usr/bin/lua
-- dev_sta set -m devLed '{"led_all":"close"}'
-- dev_sta set -m devLed '{"led_all":"restore"}'
-- dev_sta set -m devLed '{"led_all":"blink","timeout":"5"}'

-- dev_sta set -m devLed '{"system_sw":"off"}'
-- dev_sta set -m devLed '{"system_sw":"on"}'

-- dev_sta set -m devLed '{"wifi_sw":"off"}'
-- dev_sta set -m devLed '{"wifi_sw":"on"}'

-- dev_sta set -m devLed '{"mesh_sw":"off"}'
-- dev_sta set -m devLed '{"mesh_sw":"on"}'

-- dev_sta set -m devLed '{"atm_sw":"off"}'
-- dev_sta set -m devLed '{"atm_sw":"on"}'

-- dev_sta get -m devLed

module("devLed", package.seeall);  --必须要有
local console = require "console"
local cjson = require "cjson"
local lib_debug = require "utils.debug";
local uci = require "luci.model.uci".cursor()
local lib_param = require "utils.param_check"
local DEVLED_JSON_FILE = "/tmp/sd_led/devLed.json"
local trigger_table = {rcode = "05550030",rmsg="led config has no trigger"}
local set_table = {rcode = "05550031",rmsg="devLed set failed"}
local nil_table = {rcode = "05550012",rmsg="devLed led_all parameter is nil"}
local unsafe_table = {rcode = "05550024",rmsg="parameter is unsafe"}

function module_default_config_get()  --外部调用函数: ac_config.lua -> get_config_from_module()
	local config = '{"led_all":"restore"}'
	return config
end

--获取json文件,返回table
function get_json_info(jpath)
	local data = {};
	file = io.open(jpath ,"r");
	if (file == nil) then
		print("Open file sd_device.json for dir fail")
	else
		local t = file:read("*all");
		file:close();
		if (string.len(t) ~= 0) then
			data = cjson.decode(t);
		else
			print("File sd_device.json is empty")
		end
	end

	return data;
end

--led配置保存
function led_trigger_set(trig)
	local dev_data = get_json_info("/tmp/sd_device/led.json")

	uci:foreach("led", "led", function(s) 
		local val = s["trigger"]
		local name = s["name"]
		local raw_trig
		if (val ~= trig) then
			if (trig == "none") then
				uci:set("led",s[".name"],"trigger",trig)
			elseif (trig == "multi_fun") then
				--恢复 trigger 值为 led.json 中的值
				for key, value in ipairs(dev_data.led.section) do
					if (value.type == "led") then
						if (name == value.option.name) then
							raw_trig = value.option.trigger
							uci:set("led",s[".name"],"trigger",raw_trig)
						end
					end
				end
			end
		end
	end)
	uci:commit("led")
end

function led_array_opt(leds, status)
	local ret
	local t

	for i = 1, #leds do  
		-- print('cmd: /sbin/led_send_message "'..leds[i]..';'..status..'"')
		t = io.popen('/sbin/led_send_message "'..leds[i]..';'..status..'"')
		ret = t:read("*all")
		if string.find(ret, "process_ret:success") == nil then
			break
		end
	end
	return ret
end

local function devLed_write_file(path, data)
	local file

	if (path == nil or path == "" or data == nil) then
		return
	end

	file = io.open(path, "w")
	if (file == nil) then
		return
	end
	file:write(data)
	file:close()

	return 0
end

local function devLed_ubus_call()
	local ubus
	local result

	ubus = require("ubus").connect(nil, 3)
	if (ubus == nil) then
		return
	end
	result = ubus:call("devLed", "set", {})
	print(result)
end

function module_set(param)
	--参数安全检测
	if (param ~= nil) then
		if (lib_param.param_safety_check(param) ~= true) then
			lib_debug.lua_debug(lib_debug.ERROR, "devLed Param is unsafe.")
			return console.uf_lua_fail(unsafe_table)
		end
	end

	local data = cjson.decode(param)
	local led_temp_open = 0
	local led_all_set
	local time
	local ret
	local t
	
	local led_all = 0
	local led_sys = 0
	local led_wifi = 0
	local led_mesh = 0
	local led_blink = 0
	local led_all_val = 0
	local led_array_opt_flag = 0

	if  (data["led_all"] == nil)
	and (data["system_sw"] == nil)
	and (data["wifi_sw"] == nil)
	and (data["mesh_sw"] == nil)
	and (data["atm_sw"] == nil) then
		lib_debug.lua_debug(lib_debug.ERROR, "Param is error, led_all is nil")
		return console.uf_lua_fail(nil_table)
	elseif (data["led_all"] == "close" or data["led_all"] == "restore" or (data["led_all"] == "blink" and tonumber(data["timeout"]))) then
		led_all = 1
	elseif (data["system_sw"] == "on" or data["system_sw"] == "off") then
		led_sys = 1
	elseif (data["wifi_sw"] == "on" or data["wifi_sw"] == "off") then
		led_wifi = 1
	elseif (data["mesh_sw"] == "on" or data["mesh_sw"] == "off") then
		led_mesh = 1
	elseif (data["atm_sw"] == "on" or data["atm_sw"] == "off") then
		led_atm = 1
	end

	if (led_sys == 1) then
		t = io.popen('/sbin/led_send_message "system_sw;'..data["system_sw"]..'"')
	elseif (led_wifi == 1) then
		t = io.popen('/sbin/led_send_message "wifi_sw;'..data["wifi_sw"]..'"')
	elseif (led_mesh == 1) then
		t = io.popen('/sbin/led_send_message "mesh_sw;'..data["mesh_sw"]..'"')
	elseif (led_atm == 1) then
		t = io.popen('/sbin/led_send_message "atm_sw;'..data["atm_sw"]..'"')
	elseif (led_all == 1) then
		if (data["led_all"] == "blink") then
			-- 将 "blink" 识别为 "begin"
			data["led_all"] = "begin"
			time = data["timeout"]
			if ((time == "nil") or (time == "0")) then
				time = 0
			else
				time = tonumber(time)
			end
			t = io.popen('/sbin/led_send_message "blink;'..data["led_all"]..';'..time..'"')
		else
			led_array_opt_flag = 1
			ret = devLed_write_file(DEVLED_JSON_FILE, param)
			if (ret == nil) then
				ret = "process_ret:fail"
			else
				devLed_ubus_call()
				ret = "process_ret:success"
			end
			-- local led_array = {}
			-- local dev_data

			-- led_array_opt_flag = 1
			
			-- uci:foreach("led", "event", function(s) 
			-- 	local val = s["control"]
			-- 	-- print("val:"..val)
			-- 	if (val == "user") then
			-- 		-- print("table.insert:"..s["name"])
			-- 		table.insert(led_array, s["name"])
			-- 	end
			-- end)

			-- if (next(led_array) ~= nil) then
			-- 	if (data["led_all"] == "close") then
			-- 		led_trigger_set("none")
			-- 		-- 将 "close" 识别为 "off"
			-- 		data["led_all"] = "off"
			-- 		led_all_val = "0"
			-- 	elseif (data["led_all"] == "restore") then
			-- 		led_trigger_set("multi_fun")
			-- 		-- 将 "restore" 识别为 "on"
			-- 		data["led_all"] = "on"
			-- 		led_all_val = "1"
			-- 	end

			-- 	ret = led_array_opt(led_array, data["led_all"])
			-- 	-- print("run:".."/usr/sbin/ephyLed.lua "..led_all_val)
			-- 	os.execute("lua /usr/sbin/ephyLed.lua "..led_all_val)
			-- else -- led.json 没有 ["control":"user"] 字段的设备不操作自身LED（如EG/NBC）
			-- 	if (data["led_all"] == "close") or (data["led_all"] == "restore") then
			-- 		return'{"result":"success"}'
			-- 	else
			-- 		return'{"result":"failed"}'
			-- 	end
			-- end
		end
	end

	if (led_array_opt_flag ~= 1) then
		ret = t:read("*all")
	end
	if string.find(ret, "process_ret:success") ~= nil then
		return console.uf_lua_success()
	else
		return console.uf_lua_fail(set_table)
	end

	print(param)
end

--dev_sta需要有，dev_config ac_config不调用这个
function module_get(param)
	local data = {}
	local trigger

	uci:foreach("led", "led", 
	function(s)
		trigger = s["trigger"]
		if (trigger == nil) then
			lib_debug.lua_debug(lib_debug.ERROR, "led config has no trigger")
			return console.uf_lua_fail(trigger_table)
		end
	end)

	if (trigger == "none") then
		data["led_all"] = "close"
	elseif (trigger == "multi_fun") then
		data["led_all"] = "restore"
	end
	return cjson.encode(data)
end
