#!/usr/bin/lua
module("wireless", package.seeall)
local json = require "dkjson"
local console = require "console"
local sd_product = require("product")
local ssid_config_path = "/etc/sd_config/wifi_tmngt/ssid_tmgnt.json"
local networkId = "0"
local groupId = "0"
local default_wifi_prefix = sd_product.get_product("wireless.wireless.default_wifi_prefix")
local ac_wireless_default_config='{"apIsolate": "false","ssidIsolate": "false","healthy": {"enable": "false","mode": "0","tmngtName": "","slot": ""},"radioList": [{"radioIndex": "1","type": "2.4G","country":"CN","hwmode":"11ng","enable": "true","maxSta": "32","bandWidth":"auto"}, { "radioIndex": "2","type": "5G","country":"CN","hwmode":"11ac","enable": "true","maxSta": "32","bandWidth":"auto"}],"ssidList": [{"wlanId": "1","relatedRadio": "1,2","mode":"ap","ssidName": "@' .. default_wifi_prefix .. '-mXXXX","ssidEncode": "utf-8","ishidden": "false","enable": "true","encryptionMode": "open","fowardType": "bridge","vlanId": "1","bandSelectEnable": "false","guest": "false","xpress": "false","tmMode": "all","tmValue": {"tmngtName": "所有时段","slot": ""}}]}'

local function debug(msg)
    console.debug("wireless", msg)
end

--R55_适配新框架:获取默认配置
function module_default_config_get()
    local default_config
    local configTable
    default_config = ac_wireless_default_config
    local mac = console.exec_cmd("cat /proc/sd_sys/sys_mac | awk -F : '{printf $5$6 }' | tr a-z A-Z")
    local def_ssid = string.format("%s-m%s", default_wifi_prefix, mac)
    configTable = json.decode(default_config)
    configTable.ssidList[1].ssidName = def_ssid
    return (json.encode(configTable))
end

--时间管理通告
local function tmngt_notify(module, opt, tmngtName)
    local cmd =
        'dev_sta set --module tmngt_notify \'{"moduleName":"' ..
        module .. '","opt":"' .. opt .. '","tmngtName":"' .. tmngtName .. '"}\''
    debug(cmd)
    console.forkExec(cmd)
end

-- 创建时间管理对象
local function creat_time_obj(tmngtName, slot)
    slot = json.encode(slot)
    local cmd =
        'ac_config add -m tmngt \'{"list":[{"tmngtName":"' .. tmngtName .. '","type":"auto","time":' .. slot .. "}]}'"
    debug(cmd)
    console.forkExec(cmd)
end

--深拷贝
local function deepcopy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == "table" then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[deepcopy(orig_key)] = deepcopy(orig_value)
        end
        setmetatable(copy, deepcopy(getmetatable(orig)))
    else -- number, string, boolean, etc
        copy = orig
    end
    return copy
end

--下发配置与本地配置对比，判断是否需要添加时间管理对象
local function compara_ssid_tmngtName(ssidListTable)
    local data = {}
    local tmngtName
    local found
    if console.is_file_exist(ssid_config_path) then
        data = json.decode(console.read_file(ssid_config_path))
    end
    local derefTable = deepcopy(data)
    local defTable = {}
    local configTable = {}
    --下发配置与本地配置对比
    for i, v in pairs(ssidListTable) do
        if (v.tmMode == "def" or v.tmMode == "all") and v.tmValue and v.tmValue.tmngtName then
            found = false
            configTable[v.wlanId] = v.tmValue.tmngtName
            if data then
                for j, k in pairs(data) do
                    if v.wlanId == j and k == configTable[v.wlanId] then
                        derefTable[j] = nil
                        found = true
                        break
                    end
                end
            end
            if not found then
                defTable[#defTable + 1] = {tmngtName = v.tmValue.tmngtName, slot = v.tmValue.slot}
            end
        end
    end
    if derefTable then
        for i, v in pairs(derefTable) do
            tmngt_notify("ssid", "deref", v)
        end
    end
    for i, v in pairs(defTable) do
        if v.slot then
            creat_time_obj(v.tmngtName, v.slot)
        end
        tmngt_notify("ssid", "ref", v.tmngtName)
    end

    console.write_file(ssid_config_path, json.encode(configTable), "w")
end

function module_set(param)
    debug(param)
    local paramTable = json.decode(param)
    if not paramTable then
        debug("input is not json")
        return
    end
    networkId = paramTable.networkId
    groupId = paramTable.groupId
    local ssidListTable = paramTable.ssidList
    compara_ssid_tmngtName(ssidListTable)
end
