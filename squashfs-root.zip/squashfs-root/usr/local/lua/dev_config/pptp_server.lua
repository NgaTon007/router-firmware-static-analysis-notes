#! /usr/bin/lua
package.path = string.format("%s;%s;", package.path, "/usr/lib/lua/ippool/?.lua;")
module("pptp_server",package.seeall)

local cjson = require "cjson";
local lfs = require "lfs"
local pptp = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local pptp_uci = require "luci.model.uci".cursor(nil, "/var/run/pptp_server_state")
local reference = require "ippool_reference"
local DEBUG_LOG_DIR = "/tmp/pptp/"
local SERVER_DIR = "/tmp/pptp/server/"
local LOCK_FILE = "/tmp/pptp/server_lock"
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown"});
local INPUT_SAVE = table.concat({SERVER_DIR, "server_input_save"});
local IPPOOL_JSON_FILE = "/etc/sd_config/single/ippool.json"
local SERVER_JSON_FILE = "/etc/sd_config/single/pptp_server.json"
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "pptp_server_rules"})
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/pptp_server_updown.lua & >/dev/null 2>&1"
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "pptp_server.json"});
local OPTION = "/etc/ppp/options.pptpd"
local CONFIG = "/etc/pptpd.conf"
local RELOAD = "/etc/init.d/pptpd reload"
local SNOSVPN_DIR = "/var/log/snosvpn/pptp/"
local SNOSVPN_PPP_SERVER_LOG = table.concat({SNOSVPN_DIR, "pptp_pppd_server_log"})

if (tool.file_exist(SNOSVPN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SNOSVPN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(SERVER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(UPDOWN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
local function debug_init()
    pptp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "pptp_server.log", 500, pptp.INFO, "1");
end

local function iptables_del()
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("iptables -w -D INPUT_sd_chain -p tcp -m tcp --dport 1723 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    os.remove(IPTABLES_RULES_FILE);
end

local function iptables_add()
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));

    file:write("iptables -w -D INPUT_sd_chain -p tcp -m tcp --dport 1723 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -I INPUT_sd_chain -p tcp -m tcp --dport 1723 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -I INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
end

local function ippool_is_exist(ippool_name)
    local is_exist = 0;
    if (tool.file_exist(IPPOOL_JSON_FILE) == false) then
        pptp.lua_debug(pptp.INFO, "Error, ippool_name is not find.")
        return false;
    end
    local ippool_data = tool.file_read(IPPOOL_JSON_FILE)
    if (ippool_data == nil or tool.json_check(ippool_data) == false) then
        pptp.lua_debug(pptp.INFO, "Error, ippool_name is not find.")
        return false;
    end

    local ippool_json = cjson.decode(ippool_data)
    pptp.lua_debug(pptp.INFO, "Ippool: %s", ippool_data);
    for i, conf_var in ipairs(ippool_json["list"]) do
        if (ippool_name == conf_var["ippool_name"]) then
            is_exist = 1
            break
        end
    end

    --若对象不存在，则返回错误信息
    if (is_exist == 0) then
        pptp.lua_debug(pptp.INFO, "Error, ippool_name is not find.")
        return false;
    end
    return true;
end

local function update_ippool_reference(old_json, new_json)
    local tmp_param = {}
    if (next(old_json) ~= nil) then
        tmp_param["ippool_name"] = old_json["ippool_name"];
        tmp_param["module"] = "pptp_server";
        reference.ippool_reference_del(cjson.encode(tmp_param));
    end

    tmp_param = {}
    if (next(new_json) ~= nil) then
        tmp_param["ippool_name"] = new_json["ippool_name"];
        tmp_param["module"] = "pptp_server";
        reference.ippool_reference_add(cjson.encode(tmp_param));
    end
end

local function kill_client_connect()
    local kill_cmd = "kill -TERM"
    --local rm_file_cmd = "rm -rf"
    for file in lfs.dir(SERVER_DIR) do
        if (string.find(file, "_pid") ~= nil) then
            local pid_file = table.concat({SERVER_DIR, file});
            if (tool.file_exist(pid_file) == true) then
                local pid = tool.file_read(pid_file);
                kill_cmd = table.concat({kill_cmd, " ", pid});
                --rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
            end
        end
    end
    
    if (kill_cmd ~= "kill -TERM") then
        os.execute(kill_cmd);
    end
    --[[
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
    --]]
 
    for file in lfs.dir(SERVER_DIR) do
        if (string.find(file, "_client_save") ~= nil) then
            local save_file = table.concat({SERVER_DIR, file});
            local down_file = table.concat({UPDOWN_DIR, "/", file});
            if (tool.file_exist(save_file) == true) then
                os.rename(save_file, down_file);
                --os.execute(SERVER_UPDOWN_CMD);
            end
        end
    end

    --pptp服务器网卡注销，一键下发VPN流控脚本
    local fc_del_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh clear PPTP & >/dev/null 2>&1"
    pptp.lua_debug(pptp.INFO, "fc_del_cmd: %s", fc_del_cmd)
    os.execute(fc_del_cmd)
    os.execute(SERVER_UPDOWN_CMD)
end

function server_start_pppd(fn_json)
    --写入控制文件
    local file = assert(io.open(CONFIG, "w+"));
    file:write("debug\n");
    file:write("speed 115200\n");
    file:write("stimeout 10\n");
    file:write("localip ",  fn_json["localip"], "\n");
    file:write("remoteip 192.168.0.2-254,192.168.1.2-254,192.168.2.2-254\n");
    file:close(file);

    --写入配置文件
    local file = assert(io.open(OPTION,"w+"));
    file:write("debug\n");
    file:write("auth\n");
    file:write("name pptpserver\n");
    file:write("mtu 1360\n");
    file:write("mru 1360\n");
    file:write("nobsdcomp\n");
    file:write("nodeflate\n");
    file:write("noaccomp\n");
    file:write("nopcomp\n");
    file:write("novj\n");
    file:write("novjccomp\n");
    file:write("proxyarp\n");
    file:write("require-mschap-v2\n");
    file:write("chap-secrets-file ", DEBUG_LOG_DIR, "chap-secrets\n");
    file:write("logfile ", SNOSVPN_PPP_SERVER_LOG, "\n");
    file:write("plugin ippool.so\n");
    file:write("lcp-echo-failure 3\n");
    file:write("lcp-echo-interval ", fn_json["lcpechointerval"], "\n");
    file:write("ippool_name ", fn_json["ippool_name"], "\n");
    file:write("ms-dns ", fn_json["DNS"], "\n");
    if (fn_json["mppe"] == "1") then
        file:write("refuse-pap\n");
        file:write("refuse-chap\n");
        file:write("refuse-mschap\n");
        file:write("mppe\n");
        file:write("stateless\n");   
    else
        file:write("noccp\n");
        file:write("require-pap\n");
        file:write("require-chap\n");
        file:write("require-mschap\n");
        file:write("pap-secrets-file ", DEBUG_LOG_DIR, "pap-secrets\n");
    end
    file:close(file)

    --设定firewall规则
    iptables_add();
end

function server_stop_pppd(fn_json)
    --删除iptables规则
    iptables_del();

    kill_client_connect();
end

local function is_configuration_changed(old_json, new_json)
    local ret = false
    local list = {"localip","DNS","lcpechointerval","enable","ippool_name"}
    for i, var in ipairs(list) do
        if (old_json[var] ~= new_json[var]) then
            ret = true
        end
    end
    return ret;
end

----------------------------------------------------------------------------------------------------
function pptp_set(input_data, conf_file)
    pptp.lua_debug(pptp.INFO, "###############################SET###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.INFO, "Input data is not json mode.");
        return;
    end
    pptp.lua_debug(pptp.INFO, "Input data: %s", input_data);
    local input_json = cjson.decode(input_data);

    --获取旧配置
    local old_json ={};
    if (tool.file_exist(INPUT_SAVE) == true) then
        conf_data = tool.file_read(INPUT_SAVE);
        if (tool.json_check(conf_data) == true) then
            old_json = cjson.decode(conf_data)
        end
    else
        if (tool.file_exist(SERVER_JSON_FILE) == true) then
            conf_data = tool.file_read(SERVER_JSON_FILE);
            if (tool.json_check(conf_data) == true) then
                old_json = cjson.decode(conf_data)
            end
        end
    end

    --输入保存
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        pptp.lua_debug(pptp.INFO, "Input save fail.");
    end

    --检查地址池是否创建
    if (ippool_is_exist(input_json["ippool_name"]) == false) then
        pptp.lua_debug(pptp.ERROR, "Ippool is not exist.");
        return;
    end

    --更新uci配置文件
    if (input_json["enable"] == "0") then
        pptp_uci:set("pptpd", "service", "pptpd")
        pptp_uci:set("pptpd", "service", "enable", "0");
    else
        pptp_uci:set("pptpd", "service", "pptpd")
        pptp_uci:set("pptpd", "service", "enable", "1");
    end
    --pptp client limits max
    local sd_device = "/tmp/sd_device/sd_device.json"
    local sd_device_json = nil
    local pptp_links_limit = nil
    if (tool.file_exist(sd_device) == true) then
        local file_data = tool.file_read(sd_device);
        sd_device_json = cjson.decode(file_data);
        pptp_links_limit = sd_device_json["gateway"]["pptp_links_limit"]
    end
    if pptp_links_limit ~= nil then
        pptp_uci:set("pptpd", "service", "connections", pptp_links_limit);
    end
    pptp_uci:commit("pptpd");

    server_stop_pppd(old_json);
    if (input_json["enable"] == "1") then
        pptp.lua_debug(pptp.INFO, "pppd server start.");
        server_start_pppd(input_json);
    end

    --更新ippool引用
    update_ippool_reference(old_json, input_json);

    pptp.lua_debug(pptp.INFO, "###############################END###############################");
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local lfs = require "lfs"
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        pptp.lua_debug(pptp.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        pptp.lua_debug(pptp.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

------------------------------------------dev_mode----------------------------------------------------------
--@module_default_config
function module_default_config_get()
    local default_config = '{"enable": "0"}'
    return default_config
end

--@module_set
function module_set(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_set] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_set] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    pptp_set(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        pptp_set(file_data, conf_file);
    end

    --清空pptp pppd服务器日志
    if (tool.file_exist(SNOSVPN_PPP_SERVER_LOG) == true) then
        os.execute("rm -rf /tmp/log/snosvpn/pptp/pptp_pppd_server_log* & >/dev/null 2>&1");
    end
    --启动进程
    pptp.lua_debug(pptp.INFO, "/etc/init.d/pptpd restart");
    os.execute("ubus -t 3 send pptpd_restart");
    os.remove(LOCK_FILE);
end
