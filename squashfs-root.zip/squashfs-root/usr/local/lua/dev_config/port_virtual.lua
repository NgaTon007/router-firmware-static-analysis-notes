#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("port_virtual", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

require "public_module"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
libdbg = require("utils.debug")
cjson = require("cjson")
cjson_safe = require "cjson.safe"
moduleId = require "dev_module_id"
moduleName = "port_virtual"
dbgDir = "/tmp/debug/port_virtual/"
dbgFile = "port_virtual.log"
json_name = "port_virtual.json"
path = "/etc/sd_config/single/"
conf_file = path..json_name

-- ����ģ���ʼ��
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

--[[
    module_ret() -- ģ��set|add|del|update�ķ���ֵ
    @code�������룬��������[string]�������"00000000"����Ҫ����ģ���𣬷���Ҫ����ģ����
    @msg:���ظ�web�Ĵ�����Ϣ��֧�ֿɱ䳤��������������[string]����������ӡ���ֶΡ�
    @return��json�ַ���
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("port_virtual_cfgntf"), tonumber(code));
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- ���󷵻�
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = require("dkjson").encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return require("dkjson").encode(res);
end

-- �ļ���ȡ
function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

-- �ļ�д��
function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

-- ɾ��tableԪ��
function conf_del(data, json)
    local length = 0
    if (json.data ~= nil) then
        length = #json.data
    end
    while ( 0 < length ) do    
        if (json.data[length].lpid == data.lpid) then
            if (data.ifalias == nil) then
                data.ifalias = json.data[length].ifalias
            end
            break
        end
        length = length - 1
    end
    table.remove(json.data, length)
    return 0
end

-- ����tableԪ��
function conf_add(data, json)
    table.insert (json.data, data)
    return 0
end

-- Ĭ������
function module_default_config_get()
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter module_default_config_get*******************");
	
    local cfg = {}
    cfg["data"] = {}
    def_cfg_encode = cjson_safe.encode(cfg)
	
    if (def_cfg_encode == nil) then
        libdbg.lua_debug(libdbg.WARNING, "def_cfg_json isn't json")
        return module_ret("0012", "default parameter is nil");
    end

    return def_cfg_encode
end

function module_get(param)

end

function module_set(param)

end

function module_update(param)
    libdbg.lua_debug(libdbg.CRLF, "");-- ��־֮ǰ��ӡһ�����У�������ʱ�������Ϣ
    libdbg.lua_debug(libdbg.INFO, "********************Enter port_virtual update*******************");
    
	-- �������
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "port_virtual update parameter is nil");
        return module_ret("0012", "port_virtual update parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_config update -m mqlink_config '%s'", param);

    local num = 1
    local del_json_num = 1	
    local ifalias_limit_h = 25
    local data = cjson.decode(param)
    local file_data = file_read(conf_file)
    local json = cjson.decode(file_data)
    
    if ( data["data"] ~= nil) then
        del_json_num = #data.data
    end
    while ( num <= del_json_num ) do
        if (#(data.data[num].ifalias) > ifalias_limit_h) then
            libdbg.lua_debug(libdbg.ERROR, "The ifalias exceeds the length limit");
            return module_ret("0012", "The ifalias exceeds the length limit");           
        end
        conf_del(data.data[num], json)
        conf_add(data.data[num], json)
        num = num + 1
    end
    file_write(conf_file, cjson.encode(json))
    
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update end")
    return 

end

