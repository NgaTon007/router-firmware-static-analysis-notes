#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("sysname", package.seeall); -- ��һ�������Ǳ�ģ����ļ���

liblog = require("utils.debug")
cjson = require("cjson")
cjson_safe = require "cjson.safe"
moduleId = require "dev_module_id"
moduleName = "sysname"
log_dir = "/tmp/debug/sysname/"
log_file = "sysname.log"
libc2lua = require("libc2lua")
product = require("product")

SYSNAME_LIM_H = 64
SYSNAME_LIM_L = 1
-- ����ģ���ʼ
-- ��־��ʼ��
liblog.debug_init(log_dir, log_file, 100, liblog.DEBUG, liblog.OPEN)

--ģ��set|add|del|update�ķ���ֵ
function module_ret(code, rcode, rdata, rmsg)
    local err = {}
    local ret = {}
    ret["err"] = {}
    err["rdata"] = rdata
    err["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("snmp"), tonumber(rcode))
    ret["code"] = code
    err["rmsg"] = rmsg
    ret["err"] = err
    --table.insert(ret["err"], err)
    res = ret
    if (code == "1") then
        local json_str = cjson_safe.encode(res)
        liblog.lua_debug(liblog.INFO,"return json_str:%s\n",json_str)
    end

    return cjson_safe.encode(ret)
end

function module_default_config_get()
-- Ĭ������
    local sysname = product.get_product("manufacturer.company")
    if (sysname == nil or sysname == "") then
        liblog.lua_debug(liblog.ERROR, "get sysname from product failed")
        return module_ret("1", "2", "NULL", "get sysname from product failed")
    end

    local def_cfg = cjson_safe.encode({ sysname = sysname })
    if (def_cfg == nil) then
        liblog.lua_debug(liblog.ERROR, "encode default sysname config failed.")
        return module_ret("1", "2", "NULL", "encode default sysname config failed")
    end

    def_cfg_json = cjson_safe.decode(def_cfg)
    if (def_cfg_json == nil) then
        liblog.lua_debug(liblog.ERROR, "parse default sysname config failed.")
        return def_cfg
    end

    def_cfg_encode = cjson_safe.encode(def_cfg_json)
    if (def_cfg_encode == nil) then
        liblog.lua_debug(liblog.WARNING, "def_cfg_json isn't json")
        return def_cfg
    end

    return def_cfg_encode
end

function module_get(param)

end

function module_set(param)
    if (param == nil) then
        liblog.lua_debug(liblog.ERROR, "param is null")
        return module_ret("1", "2", "NULL", "param data is null!")
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        liblog.lua_debug(liblog.ERROR, "param is unsafe")
        return module_ret("1", "2", "NULL", "param is unsafe!")
    end

    snmp_param_data = cjson_safe.decode(param)
    if (snmp_param_data == nil) then
        liblog.lua_debug(liblog.ERROR, "parse snmp param failed.")
        return module_ret("1", "2", "param", "parse snmp param failed!")
    end

    --sysname �����п�
    if (snmp_param_data["sysname"] ~= nil and snmp_param_data[""] ~= "") then
        if (#snmp_param_data["sysname"] > SYSNAME_LIM_H or #snmp_param_data["sysname"] < SYSNAME_LIM_L) then
            liblog.lua_debug(liblog.WARNING, "snmp param sysname:%s is invalid, require [1,64]", snmp_param_data["sysname"])
            return module_ret("1", "2", "sysname", "snmp param sysname set require [1,64]")
        end
    else
        return module_ret("0", "1", "NULL", "successful set")
     end
    return module_ret("0", "1", "NULL", "successful set")
end