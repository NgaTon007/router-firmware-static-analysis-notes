#! /usr/bin/env lua

module_name = "safeZone"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
dkjson = require "dkjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"
dev_config = require "dev_config"
safeZoneLib = require "safeZoneLib"
uci = require("luci.model.uci")
local nixio_ok, nixio = pcall(require, "nixio")

config_file_path = "/etc/sd_config/single/safeZone.json"
safeZoneRule = "/usr/sbin/safeZoneCreateRule.sh"
cap_file_path = "/tmp/sd_device/sd_device.json"


x = uci.cursor()

cfg_idx_tb = {}
cfg_tb_num = 0
log_enable = 0
cfg_access_tb = {}
cfg_accessed_tb = {}
----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")
math.randomseed(os.time())

local err_code = {
    ["SUCCESS"] = "00000000",
    ["ERR_SAFEZONE_PARAM_EXCEPTION"] = "04280001",
    ["ERR_SAFEZONE_CONFIG_EXCEPTION"] = "04280002",
}

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

local function file_sync(path)
    if (not (nixio_ok and nixio and nixio.open)) then
        return
    end

    local fd = nixio.open(path, "r")
    if (fd) then
        if (fd.sync) then
            fd:sync()
        end
        fd:close()
    else
        module_debug.lua_debug(module_debug.ERROR, "file_sync: failed to open [%s]", path)
    end
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"

    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        f:flush()
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- return error message if execution fails
-- @code: error code
-- @msg: error msg
-- @If it fails to return an error, it is considered that the configuration has failed
local function fail_reason(code, msg)
    local err = {}
    local ret = {}

    err["rcode"] = code
    err["message"] = msg
    ret["code"] = "1"
    ret["err"] = cjson_safe.encode(err)

    return cjson_safe.encode(ret)
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end

    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end

    return config_json
end

local function json_write_to_file(path, config_json)
    if (config_json == nil) then
        return 0
    end

    local config_str = dkjson.encode(config_json)
    if (config_str == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)

    -- use random suffix to avoid concurrent processes overwriting each other's temp file
    local temp_path = path .. ".tmp." .. tostring(math.random(100000, 999999))
    local res = file_write(temp_path, config_str)
    if (res ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "Failed to write to temp file [%s]", temp_path)
        os.remove(temp_path)
        return -1
    end

    local rename_success = os.rename(temp_path, path)
    if (not rename_success) then
        module_debug.lua_debug(module_debug.ERROR, "Failed to rename temp file [%s] to [%s]", temp_path, path)
        os.remove(temp_path)
        return -1
    end

    -- fsync the target file after rename to persist the directory entry on journaling filesystems
    file_sync(path)

    return 0
end

local function checkparam_for_type(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't string")
        return -1
    end

    if (string.lower(param) ~= "lan" and string.lower(param) ~= "wan") then
        module_debug.lua_debug(module_debug.ERROR, "the type is error")
        return -1
    end

    return 0
end

local function checkparam_for_array(param)
    if (type(param) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't array")
        return -1
    end

    for key,value in pairs(param) do
        if (string.match(value, "[^%w_]") ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't unsafe" )
            return -1
        end
    end

    return 0
end

local function checkparam_for_string_len(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the string style isn't string")
        return -1
    end

    if (string.len(param) < 0 or string.len(param) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "the string %s length is error", param)
        return -1
    end

    return 0
end

local function checkparam_for_uuid(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the uuid style isn't string")
        return -1
    end

    if (string.len(param) < 0 or string.len(param) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid length is error")
        return -1
    end

    if (string.match(param, "%W") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid isn't illegal")
        return -1
    end

    return 0
end

local function checkparam_is_json(param)
    if (type(param) ~= "string") then
        return nil
    end

    module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", module_name, param)

    local param_json = cjson_safe.decode(param)
    if (param_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter format is not json")
        return nil
    end

    return param_json
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end

    local sh_ret_handle = io.popen(sh_cmd);
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end

    return sh_ret;
end

local function config_index_table(config_json)
    for k,v in pairs(config_json["list"]) do
        cfg_idx_tb[v["uuid"]] = k
        cfg_tb_num = cfg_tb_num + 1

        cfg_access_tb[v["uuid"]] = {}
        cfg_accessed_tb[v["uuid"]] = {}

        if (v["zoneAccess"] ~= nil) then
            for ref_k,ref_v in pairs(v["zoneAccess"]) do
                cfg_access_tb[v["uuid"]][ref_v] = ref_k
            end
        end

        if (v["accessedZone"] ~= nil) then
            for ref_k,ref_v in pairs(v["accessedZone"]) do
                cfg_accessed_tb[v["uuid"]][ref_v] = ref_k
            end
        end
    end
end

local function find_config_exist_index(uuid)
    local idx
    idx = cfg_idx_tb[uuid]

    return idx
end

--生成随机值
local function guid()
    local d = io.open("/dev/urandom", "r"):read(4)
    local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)

    math.randomseed(num)
    local result = "safe"
    for i = 1, 4 do
            local v = math.random(1, 9)
            result = result .. string.format("%d", v)
    end
    return result
end

local function create_intf_group(param, setname, type)
    local intf_tb = {}
    local node = {}

    intf_tb["list"] = {}

    node["uuid"] = setname
    node["name"] = param["name"]
    node["type"] = "auto"
    node["mem"] = param["mem"]

    table.insert(intf_tb["list"], node)
    cmdstr = cjson_safe.encode(intf_tb)
    if (cmdstr ~= nil) then
        dev_config.fetch("add","intfGroup", cmdstr, 1)
        return 0
    end

    return -1
end

--[[
    param format:

    dev_config -m update intfGroup '{"list":[{"uuid":"xxxx","name":"lan","mem":["lan","lan_20","lan_30"]}]}'

]]--
local function update_intf_group(param, setname)
    local intf_tb = {}
    local node = {}

    intf_tb["list"] = {}

    node["uuid"] = setname
    node["name"] = param["name"]
    node["mem"] = param["mem"]

    table.insert(intf_tb["list"], node)
    cmdstr = cjson_safe.encode(intf_tb)
    if (cmdstr ~= nil) then
        dev_config.fetch("update","intfGroup", cmdstr, 1)
        return 0
    end

    return -1
end

--[[
    param format:

    dev_config -m del intfGroup '{
        "list":["lan"]
    }'
]]--
local function del_intf_group(param)
    local intf_tb = {}
    local node = {}

    intf_tb["list"] = {}
    table.insert(intf_tb["list"], param)

    cmdstr = cjson_safe.encode(intf_tb)
    if (cmdstr ~= nil) then
        dev_config.fetch("del","intfGroup", cmdstr, 1)
        return 0
    end

    return -1
end

local function add_accessZone_relation(node, config_json)
    local idx

    for k,v in pairs(node["zoneAccess"]) do
        idx = find_config_exist_index(v)
        if (idx ~= nil) then
            table.insert(config_json["list"][idx]["accessedZone"], node["uuid"])
            
            last_idx = table.maxn(config_json["list"][idx]["accessedZone"])
            cfg_accessed_tb[v][node["uuid"]] = last_idx + 1
        end
    end

    for k,v in pairs(node["accessedZone"]) do
        idx = find_config_exist_index(v)
        if (idx ~= nil) then
            table.insert(config_json["list"][idx]["zoneAccess"], node["uuid"])
            
            last_idx = table.maxn(config_json["list"][idx]["zoneAccess"])
            cfg_access_tb[v][node["uuid"]] = last_idx + 1
        end
    end
end

local function del_accessZone_relation(config_json, node)
    local idx

    for k,v in pairs(node["zoneAccess"]) do
        idx = find_config_exist_index(v)
        if (idx ~= nil and config_json["list"][idx] ~= nil and config_json["list"][idx]["accessedZone"]) then
            -- 获取本域在其他域中被访问域中的位置
            for conf_k, conf_v in pairs(config_json["list"][idx]["accessedZone"]) do
                if (node["uuid"] == conf_v) then
                    table.remove(config_json["list"][idx]["accessedZone"], conf_k)
                    if (cfg_accessed_tb[v] ~= nil and cfg_accessed_tb[v][node["uuid"]] ~= nil) then
                        cfg_accessed_tb[v][node["uuid"]] = nil
                    end
                end
            end
        end
    end

    -- 清除不在被访问域的域的访问规则,禁用的是该域不可访问的域
    for k, v in pairs(config_json["list"]) do
        if (cfg_access_tb[v["uuid"]] ~= nil) then
            idx = cfg_access_tb[v["uuid"]][node["uuid"]]
            if (idx == nil) then
               safeZoneLib.flush_deny_zone(v["setname"])
            end
        end
    end
  
    for k,v in pairs(node["accessedZone"]) do
        idx = find_config_exist_index(v)
        if (idx ~= nil and config_json["list"][idx] ~= nil and config_json["list"][idx]["zoneAccess"] ~= nil) then
            -- 获取本域在其他域中可访问域中的位置
            for conf_k, conf_v in pairs(config_json["list"][idx]["zoneAccess"]) do
                if (node["uuid"] == conf_v) then
                    table.remove(config_json["list"][idx]["zoneAccess"], conf_k)
                    if (cfg_access_tb[v] ~= nil and cfg_access_tb[v][node["uuid"]] ~= nil) then
                        cfg_access_tb[v][node["uuid"]] = nil
                    end
                end
            end
        end
    end
end

local function update_zoneAccess_relation(node, config_json)
    local access_idx, idx_accessed, idx, last_idx
    
    -- 初始化域可访问关系
    for ref_k,ref_v in pairs(node["zoneAccess"]) do
        cfg_access_tb[node["uuid"]][ref_v] = ref_k
    end
    
    for k,v in pairs(config_json["list"]) do
        idx = find_config_exist_index(v["uuid"])
        last_idx = table.maxn(v["accessedZone"])
        
        if (v["uuid"] ~= node["uuid"]) then
            access_zone = node["uuid"]
            accessed_zone = v["uuid"]
            
            -- 访问关系的id值会由于删除关系导致数据不准,但仅用于判断是否存在节点,因此可忽略影响
            idx_accessed = cfg_accessed_tb[accessed_zone][access_zone]
            access_idx = cfg_access_tb[access_zone][accessed_zone]
            
            -- 更新的域A的访问域中不存在对应的域B的信息, 但域B的可访问域中存在域A的信息,可认为域B已被在域A的访问域中删除
            if (access_idx == nil and idx_accessed ~= nil) then
                for conf_k, conf_v in pairs(v["accessedZone"]) do
                    if (node["uuid"] == conf_v) then
                        table.remove(config_json["list"][idx]["accessedZone"], conf_k)
                        cfg_accessed_tb[accessed_zone][access_zone] = nil
                    end
                end
            end
            
            -- 更新的域A的访问域中存在对应的域B的信息,但是域B的可访问域中不存在域A的信息，可认为域B中未添加对应的域A
            if (access_idx ~= nil and idx_accessed == nil) then
                table.insert(config_json["list"][idx]["accessedZone"], access_zone)
                cfg_accessed_tb[accessed_zone][access_zone] = last_idx + 1
            end
        end
    end
end

local function update_accessedZone_relation(node, config_json)
    local access_idx, idx_accessed, idx, last_idx
    
    for ref_k,ref_v in pairs(node["accessedZone"]) do
        cfg_accessed_tb[node["uuid"]][ref_v] = ref_k
    end
    
    for k,v in pairs(config_json["list"]) do
        idx = find_config_exist_index(v["uuid"])
        last_idx = table.maxn(v["zoneAccess"])
        
        if (v["uuid"] ~= node["uuid"]) then
            accessed_zone = node["uuid"]
            access_zone = v["uuid"]
        
            -- 访问关系的id值会由于删除关系导致数据不准,但仅用于判断是否存在节点,因此可忽略影响
            idx_accessed = cfg_accessed_tb[accessed_zone][access_zone]
            access_idx = cfg_access_tb[access_zone][accessed_zone]
            
            -- 更新的域A的可访问域中不存在对应的域B的信息, 但域B的访问域中存在域A的信息,可认为域B已被在域A的可访问域中删除
            if (access_idx == nil and idx_accessed ~= nil) then                
                table.insert(config_json["list"][idx]["zoneAccess"], accessed_zone)
                cfg_access_tb[access_zone][accessed_zone] = last_idx + 1
            end
            
            -- 更新的域A的可访问域中存在对应的域B的信息,但是域B的访问域中不存在域A的信息，可认为域B中未添加对应的可访问域
            if (access_idx ~= nil and idx_accessed == nil) then
                for conf_k, conf_v in pairs(v["zoneAccess"]) do
                    if (node["uuid"] == conf_v) then
                        table.remove(config_json["list"][idx]["zoneAccess"], conf_k)
                        cfg_access_tb[access_zone][accessed_zone] = nil
                    end
                end 
            end
        end
    end
end

local function remove_def_mem_by_param(node, config_json)
    local lanidx = find_config_exist_index("ZoneLan")
    local wanidx = find_config_exist_index("ZoneWan")
    
    local lanZone = config_json["list"][lanidx]
    local wanZone = config_json["list"][wanidx]
    local change_flag = 0

    if (node["uuid"] == "ZoneLan" or node["uuid"] == "ZoneWan") then
        return
    end

    if (node["type"] == "lan") then
        change_flag = 0
        for k,v in pairs(node["mem"]) do
            for lan_k, lan_v in pairs(lanZone["mem"]) do
                if (v == lan_v) then
                    table.remove(config_json["list"][lanidx]["mem"], lan_k)
                    change_flag = 1
                end
            end
        end
        
        if (change_flag == 1) then
            update_intf_group(config_json["list"][lanidx], config_json["list"][lanidx]["setname"])
        end
    end
    
    if (node["type"] == "wan") then
        change_flag = 0
        for k,v in pairs(node["mem"]) do
            for wan_k, wan_v in pairs(wanZone["mem"]) do
                if (v == wan_v) then
                    table.remove(config_json["list"][wanidx]["mem"], wan_k)
                    change_flag = 1
                end
            end
        end
        
        if (change_flag == 1) then
            update_intf_group(config_json["list"][wanidx], config_json["list"][wanidx]["setname"])
        end
    end 
end

local function add_def_mem_by_param(node, config_json, exist_intf)
    local lanidx = find_config_exist_index("ZoneLan")
    local wanidx = find_config_exist_index("ZoneWan")
    
    local lanZone = config_json["list"][lanidx]
    local wanZone = config_json["list"][wanidx]
    local change_flag = 0

    if (node["uuid"] == "ZoneLan" or node["uuid"] == "ZoneWan") then
        return
    end


    if (node["type"] == "lan") then
        change_flag = 0
        for k,v in pairs(node["mem"]) do
            if (exist_intf[v] == 1) then
                table.insert(config_json["list"][lanidx]["mem"], v)
                change_flag = 1
            end
        end
        
        if (change_flag == 1) then
            update_intf_group(config_json["list"][lanidx], config_json["list"][lanidx]["setname"])
        end
    end
    
    if (node["type"] == "wan") then
        change_flag = 0
        for k,v in pairs(node["mem"]) do
            if (exist_intf[v] == 1) then
                table.insert(config_json["list"][wanidx]["mem"], v)
                change_flag = 1
            end
        end
        
        if (change_flag == 1) then
            update_intf_group(config_json["list"][wanidx], config_json["list"][wanidx]["setname"])
        end
    end 
end

local function update_def_mem_by_param(old_node, new_node, config_json)
    local exist_intf = {}

    x:foreach("network", "interface", function(s)
        local intf = s[".name"]
        if (intf ~= nil and string.find(intf, "v6") == nil ) then
            exist_intf[intf] = 1
        end
    end
    )

    add_def_mem_by_param(old_node, config_json, exist_intf)
    remove_def_mem_by_param(new_node, config_json)
end

local function add_node_to_config(node, config_json, setname)
    local new_node = {}

    new_node["uuid"] = node["uuid"]
    new_node["name"] = node["name"]
    new_node["mem"] = node["mem"]
    new_node["type"] = node["type"]
    new_node["zoneAccess"] = node["zoneAccess"]
    new_node["accessedZone"] = node["accessedZone"]
    
    -- 将禁用服务转换为小写
    local disbaleList = {}
    for set_k, set_v in pairs(node["disbaleList"]) do
        table.insert(disbaleList, string.lower(set_v))
    end
    
    if (table.maxn(disbaleList) ~= 0) then
        new_node["disbaleList"] = disbaleList
    else
        new_node["disbaleList"] = node["disbaleList"]
    end
    
    new_node["setname"] = setname

    table.insert(config_json["list"], new_node)
end

local function update_node_to_config(node, cfg_node, config_json)
    if (node["name"] ~= nil) then
        if (cfg_node["name"] ~= node["name"]) then
            cfg_node["name"] = node["name"]
        end
    end

    -- 更新节点的接口成员
    if (node["mem"] ~= nil) then
        cfg_node_mem = cjson_safe.encode(cfg_node["mem"])
        node_mem = cjson_safe.encode(node["mem"])
        if (cfg_node_mem ~= node_mem) then
            update_def_mem_by_param(cfg_node, node, config_json)
            update_intf_group(node, cfg_node["setname"])
            
            cfg_node["mem"] = node["mem"]
            module_debug.lua_debug(module_debug.INFO, "update node %s mem", cfg_node["uuid"])
        end
    end

    if (node["zoneAccess"] ~= nil) then
        -- 更新节点的域可访问关系
        cfg_node_zoneAccess = cjson_safe.encode(cfg_node["zoneAccess"])
        node_zoneAccess = cjson_safe.encode(node["zoneAccess"])
        if (cfg_node_zoneAccess ~= node_zoneAccess) then
            -- 重置域访问关系
            for ref_k,ref_v in pairs(cfg_node["zoneAccess"]) do
                cfg_access_tb[node["uuid"]][ref_v] = nil
            end
        
            cfg_node["zoneAccess"] = node["zoneAccess"]
            update_zoneAccess_relation(node, config_json)
            module_debug.lua_debug(module_debug.INFO, "update node %s zoneAccess", cfg_node["uuid"])
        end
    end

    if (node["accessedZone"] ~= nil) then
        -- 更新节点的域被访问关系
        cfg_node_accessedZone = cjson_safe.encode(cfg_node["accessedZone"])
        node_accessedZone = cjson_safe.encode(node["accessedZone"])
        if (cfg_node_accessedZone ~= node_accessedZone) then
            -- 重置域被关系
            for ref_k,ref_v in pairs(cfg_node["accessedZone"]) do
                cfg_accessed_tb[node["uuid"]][ref_v] = nil
            end
        
            cfg_node["accessedZone"] = node["accessedZone"]
            update_accessedZone_relation(node, config_json)
            module_debug.lua_debug(module_debug.INFO, "update node %s accessedZone", cfg_node["uuid"])
        end
    end

    if (node["disbaleList"] ~= nil) then
        -- 更新节点的禁用服务情况
        cfg_node_disbaleList = cjson_safe.encode(cfg_node["disbaleList"])
        node_disbaleList = cjson_safe.encode(node["disbaleList"])
        if (cfg_node_disbaleList ~= node_disbaleList) then
            cfg_node["disbaleList"] = node["disbaleList"]
            
            local disbaleList = {}
            for set_k, set_v in pairs(cfg_node["disbaleList"] ) do
                table.insert(disbaleList, string.lower(set_v))
            end
            
            if (table.maxn(disbaleList) ~= 0) then
                cfg_node["disbaleList"] = disbaleList
            end
            
            if (table.maxn(cfg_node["disbaleList"]) ~= 0) then
                safeZoneLib.clear_serv_rule(cfg_node["setname"], cfg_node["disbaleList"])
                safeZoneLib.del_serv_rule(cfg_node["setname"])
                safeZoneLib.add_serv_rule(cfg_node["setname"])
                safeZoneLib.update_serv_rule(cfg_node["setname"], cfg_node["disbaleList"])
            else
                safeZoneLib.clear_serv_rule(cfg_node["setname"], cfg_node["disbaleList"])
                safeZoneLib.del_serv_rule(cfg_node["setname"])
            end
            
            module_debug.lua_debug(module_debug.INFO, "update node %s disbaleList", cfg_node["uuid"])
        end
    end
end

local function add_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0

    for k,v in pairs(param_json["list"]) do
        idx = find_config_exist_index(v["uuid"])
        if (idx == nil) then
            if (v["uuid"] == "ZoneRoute") then
                setname = "ZoneRoute"
            else
                setname = guid()
            end
            
            -- 创建接口组
            ret = create_intf_group(v, setname)
            if (ret == 0) then
                -- 生成安全域之间的关系
                add_accessZone_relation(v, config_json)
                
                --将自定义域中的成员从默认域中移除
                remove_def_mem_by_param(v, config_json)
                
                -- 添加节点至配置文件
                add_node_to_config(v, config_json, setname)

                cfg_tb_num = cfg_tb_num + 1
                cfg_idx_tb[v["uuid"]] = cfg_tb_num
                change_flag = 1
            end
        end
    end

    config_json["total"] = tostring(cfg_tb_num)

    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            for k,v in pairs(param_json["list"]) do
                idx = find_config_exist_index(v["uuid"])
                del_intf_group(config_json["list"][idx]["setname"])
            end
            
            return -1
        end
    end

    for k,v in pairs(param_json["list"]) do
        idx = find_config_exist_index(v["uuid"])
        if (idx ~= nil) then
            local setname = config_json["list"][idx]["setname"]
            
            --根据域间关系生成对应规则
            safeZoneLib.add_relation(v, setname, config_json["list"])
            
            --生成服务的禁用对应规则
            if (table.maxn(config_json["list"][idx]["disbaleList"]) ~= 0) then
                safeZoneLib.clear_serv_rule(setname, config_json["list"][idx]["disbaleList"])
                safeZoneLib.del_serv_rule(setname)
                safeZoneLib.add_serv_rule(setname)
                safeZoneLib.update_serv_rule(setname, config_json["list"][idx]["disbaleList"])
            end
        end
    end

    return 0
end

local function del_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0
    local del_tmp = {}
    local exist_intf = {}

    x:foreach("network", "interface", function(s)
        local intf = s[".name"]
        if (intf ~= nil and string.find(intf, "v6") == nil ) then
            exist_intf[intf] = 1
        end
    end
    )

    for k,v in pairs(param_json["list"]) do
        if (v ~= "ZoneLan" and v ~= "ZoneWan") then
            local idx = find_config_exist_index(v)
            if (idx ~= nil) then
                local node = config_json["list"][idx]
                local setname = node["setname"]
                local servArray = node["disbaleList"]
                
                -- 清除禁用服务规则
                safeZoneLib.clear_serv_rule(setname, servArray)
                safeZoneLib.del_serv_rule(setname)
                
                -- 移除域访问规则
                safeZoneLib.remove_relation_rule(setname, node["type"])
                safeZoneLib.flush_deny_zone(setname)
                safeZoneLib.destroy_deny_zone(setname)

                -- 删除配置中的域间关系
                del_accessZone_relation(config_json, node)

                -- 删除对应的接口组配置
                del_intf_group(setname)

                -- 将删除的域的成员添加到默认的域
                add_def_mem_by_param(node, config_json, exist_intf)
            end
        end
    end

    -- 删除配置中的节点
    for k,v in pairs(param_json["list"]) do
        for conf_k, conf_v in pairs(config_json["list"]) do
            if (v == conf_v["uuid"] and v ~= "ZoneLan" and v ~= "ZoneWan") then
                table.remove(config_json["list"], conf_k)
                cfg_tb_num = cfg_tb_num - 1
                change_flag = 1
            end
        end
    end

    config_json["total"] = tostring(cfg_tb_num)

    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "del json_write_to_file failed")
            return -1
        end
    end

    return 0
end

-- Helper: flush and rebuild ipset relation rules for a given zone config node
local function flush_and_update_zone(cfg_node, list)
    safeZoneLib.flush_deny_zone(cfg_node["setname"])
    safeZoneLib.update_relation_rule(cfg_node, cfg_node["setname"], list, cfg_node["type"])
end

-- Helper: rebuild ipset rules for all zones affected by an accessedZone change.
-- new_accessed: zones currently in accessedZone (rules need update)
-- old_accessed: zones previously in accessedZone (removed ones also need update)
local function rebuild_accessed_zone_rules(new_accessed, old_accessed, config_json)
    local new_accessed_set = {}
    for _, zone_v in pairs(new_accessed) do
        new_accessed_set[zone_v] = true
        local zone_idx = find_config_exist_index(zone_v)
        if (zone_idx ~= nil) then
            flush_and_update_zone(config_json["list"][zone_idx], config_json["list"])
        end
    end

    if (old_accessed == nil) then
        return
    end
    for _, old_zone_v in pairs(old_accessed) do
        if (new_accessed_set[old_zone_v] == nil) then
            local zone_idx = find_config_exist_index(old_zone_v)
            if (zone_idx ~= nil) then
                flush_and_update_zone(config_json["list"][zone_idx], config_json["list"])
            end
        end
    end
end

local function update_param_to_config(param_json, config_json, config_file_path)
    if (param_json["list"] == nil) then
        return 0
    end

    local change_flag = 0
    local old_accessed_zones = {}

    for k, v in pairs(param_json["list"]) do
        local idx = find_config_exist_index(v["uuid"])
        if (idx ~= nil) then
            -- 保存更新前的 accessedZone 快照：
            -- update_accessedZone_relation 会将被移除的域从其 zoneAccess 中删除，
            -- 这些域的 ipset 规则也需要重建，否则旧访问权限仍然有效
            if (v["accessedZone"] ~= nil) then
                local old_accessed = {}
                for _, ref_v in pairs(config_json["list"][idx]["accessedZone"]) do
                    table.insert(old_accessed, ref_v)
                end
                old_accessed_zones[v["uuid"]] = old_accessed
            end
            update_node_to_config(v, config_json["list"][idx], config_json)
            change_flag = 1
        end
    end

    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "update json_write_to_file failed")
            return -1
        end
    end

    for k, v in pairs(param_json["list"]) do
        local idx = find_config_exist_index(v["uuid"])
        if (idx ~= nil) then
            local cfg_node = config_json["list"][idx]
            if (v["zoneAccess"] ~= nil) then
                flush_and_update_zone(cfg_node, config_json["list"])
            end
            
            if (v["accessedZone"] ~= nil) then
                rebuild_accessed_zone_rules(v["accessedZone"], old_accessed_zones[v["uuid"]], config_json)
            end
        end
    end

    return 0
end

local function validate_zone_mem_params(zone_uuid, zone_intf, zone_intflist, op)
    -- 验证uuid
    if checkparam_for_uuid(zone_uuid) == -1 then
        module_debug.lua_debug(module_debug.ERROR, "zone_uuid is error")
        return false
    end

    -- 验证参数：必须有 mem_intf 或 mem_intflist 中的一个
    if zone_intf == nil and zone_intflist == nil then
        module_debug.lua_debug(module_debug.ERROR, "mem_intf or mem_intflist must be provided")
        return false
    end

    if zone_intf ~= nil and zone_intflist ~= nil then
        module_debug.lua_debug(module_debug.ERROR, "cannot provide both mem_intf and mem_intflist")
        return false
    end

    -- 验证单个接口参数
    if zone_intf ~= nil and string.match(zone_intf, "[^%w_]") ~= nil then
        module_debug.lua_debug(module_debug.ERROR, "the interface style isn't unsafe")
        return false
    end

    -- 验证接口列表参数
    if zone_intflist ~= nil then
        if type(zone_intflist) ~= "table" then
            module_debug.lua_debug(module_debug.ERROR, "mem_intflist must be an array")
            return false
        end
        for _, intf in pairs(zone_intflist) do
            if string.match(intf, "[^%w_]") ~= nil then
                module_debug.lua_debug(module_debug.ERROR, "interface %s in mem_intflist is invalid", intf)
                return false
            end
        end
    end

    -- 验证操作类型
    if op == nil or (op ~= "add" and op ~= "del" and op ~= "update") then
        module_debug.lua_debug(module_debug.ERROR, "the update zone mem op is error")
        return false
    end

    return true
end

local function process_mem_operation(current_mem, interfaces, op)
    local new_mem = {}
    
    -- 拷贝当前mem
    for _, v in pairs(current_mem) do
        table.insert(new_mem, v)
    end
    
    if op == "update" then
        -- update 操作：直接替换
        return interfaces
    elseif op == "add" then
        -- add 操作：添加不存在的接口
        for _, intf in pairs(interfaces) do
            local exists = false
            for _, existing in pairs(new_mem) do
                if existing == intf then
                    exists = true
                    break
                end
            end
            if not exists then
                table.insert(new_mem, intf)
            end
        end
    elseif op == "del" then
        -- del 操作：删除存在的接口
        for i = #new_mem, 1, -1 do
            for _, intf in pairs(interfaces) do
                if new_mem[i] == intf then
                    table.remove(new_mem, i)
                    break
                end
            end
        end
    end
    
    return new_mem
end

local function update_zone_mem(zone_uuid, zone_intf, zone_intflist, op, config_json, config_file_path)
    -- 参数验证
    if not validate_zone_mem_params(zone_uuid, zone_intf, zone_intflist, op) then
        return -1
    end
    
    -- 查找配置中的zone
    local idx = find_config_exist_index(zone_uuid)
    if idx == nil then
        module_debug.lua_debug(module_debug.ERROR, "the update zone is null")
        return -1
    end
    
    local zone_node = config_json["list"][idx]
    if zone_node == nil or zone_node["mem"] == nil or type(zone_node["mem"]) ~= "table" then
        module_debug.lua_debug(module_debug.ERROR, "the update zone mem isn't exist")
        return -1
    end
    
    -- 准备接口列表
    local interfaces = {}
    if zone_intf ~= nil then
        interfaces = {zone_intf}
    else
        interfaces = zone_intflist
    end
    
    -- 处理mem操作
    local new_mem = process_mem_operation(zone_node["mem"], interfaces, op)
    
    -- 检查是否有变化
    local mem_changed = false
    if #new_mem ~= #zone_node["mem"] then
        mem_changed = true
    else
        for i = 1, #new_mem do
            if new_mem[i] ~= zone_node["mem"][i] then
                mem_changed = true
                break
            end
        end
    end
    
    if not mem_changed then
        return 0 -- 无变化
    end
    
    -- 更新配置
    config_json["list"][idx]["mem"] = new_mem
    
    if json_write_to_file(config_file_path, config_json) == -1 then
        module_debug.lua_debug(module_debug.ERROR, "update json_write_to_file failed")
        return -1
    end

    -- 同步intfGroup配置
    os.execute("ubus -t 5 send safeZoneSync")
    
    return 0
end

-- default config
function module_default_config_get()
    local def_cfg_str = '{"list":[{"uuid":"ZoneLan","name":"DefLan","type":"lan","mem":["lan"],"zoneAccess":["ZoneWan","ZoneRoute"],"accessedZone":[],"disbaleList":[],"setname":"ZoneLan"},{"uuid":"ZoneWan","name":"DefWan","type":"wan","mem":["wan"],"zoneAccess":[],"accessedZone":["ZoneLan"],"disbaleList":[],"setname":"ZoneWan"},{"uuid":"ZoneRoute","name":"DefRoute","type":"wan","mem":[],"zoneAccess":["ZoneLan"],"accessedZone":["ZoneLan"],"disbaleList":[],"setname":"ZoneRoute"}],"total":"3","ver":"1.1"}'
    local wan_snmp_deny = 0
    local wan_web_deny = 0

    def_json = cjson_safe.decode(def_cfg_str)
    for k,v in pairs(def_json["list"]) do
        setname = v["setname"]
        create_intf_group(v, setname)
    end
    
    local web = require("product").get_product("capacity.web")
    if (file_exist(cap_file_path) == true and web ~= nil) then
        cap_json = file_to_json(cap_file_path)

        if (cap_json ~= nil) then
            if (cap_json[web] ~= nil and cap_json[web]["snmp"] ~= nil and cap_json[web]["snmp"] == "1") then
                wan_snmp_deny = 1
            end

            if (cap_json[web] ~= nil and cap_json[web]["denyWanWeb"] ~= nil and cap_json[web]["denyWanWeb"] == "1") then
                wan_web_deny = 1
            end

        end

        if (wan_snmp_deny == 1) then
            for k,v in pairs(def_json["list"]) do
                if (v["type"] == "wan") then
                    table.insert(v["disbaleList"], string.lower("snmp"))
                end
            end
            
            def_cfg_str = cjson_safe.encode(def_json)
        end
        
        if (wan_web_deny == 1) then
            for k,v in pairs(def_json["list"]) do
                if (v["type"] == "wan") then
                    table.insert(v["disbaleList"], string.lower("web"))
                end
            end
            
            def_cfg_str = cjson_safe.encode(def_json)
        end

    end

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_default_config_get] get default success")

    return def_cfg_str
end

--[[
    param format:
        dev_config add -m safeZone '{"list":[{"uuid":"lan10","name":"访客域","type":"lan","mem":["lan10"],"zoneAccess":["ZoneWan"],"accessedZone":["ZoneLan"],"disbaleList":["web","ping","dns","dhcp"]}]}'

]]--
function module_add(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        config_json = cjson_safe.decode(module_default_config_get())
    end
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param is error")
    end

    config_index_table(config_json)
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_uuid(v["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param uuid is error")
        end

        ret = checkparam_for_string_len(v["name"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param name is error")
        end

        ret = checkparam_for_array(v["mem"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param mem is error")
        end

        ret = checkparam_for_array(v["zoneAccess"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param zoneAccess is error")
        end

        ret = checkparam_for_array(v["accessedZone"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param accessedZone is error")
        end

        ret = checkparam_for_type(v["type"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param type is error")
        end

        ret = checkparam_for_array(v["disbaleList"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param disbaleList is error")
        end
    end

    ret = add_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "safezone add config failed")
    end

   return '{"rcode":"00000000", "message":"Configuration success"}'
end

--[[
    param format:

        dev_config del -m safeZone '{"list":["lan"]}'

]]--
function module_del(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        config_json = cjson_safe.decode(module_default_config_get())
    end
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param is error")
    end

    config_index_table(config_json)
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_uuid(v)
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param uuid is error")
        end
    end

    ret = del_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone del config failed")
    end

    return '{"rcode":"00000000", "message":"Configuration success"}'
end

--[[
    param format:

    dev_config update -m safeZone '{"list":[{"uuid":"lan10","name":"lan","type":"lan","mem":["lan","lan_100"],"zoneAccess":["ZoneWan"],"accessedZone":["ZoneLan"],"disbaleList":["web","ping","dns","dhcp"]}]}'

]]--
function module_update(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        config_json = cjson_safe.decode(module_default_config_get())
    end
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone update config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end

    config_index_table(config_json)

    -- 用于网络变更某个域单独更新单个接口成员变化
    if (param_json["uuid"] ~= nil and (param_json["mem_intf"] ~= nil or param_json["mem_intflist"] ~= nil) and param_json["op"] ~= nil) then
        module_debug.lua_debug(module_debug.INFO, "INFO: start update zone mem intf")
        
        local zone_uuid = param_json["uuid"]
        local zone_intf = param_json["mem_intf"]
        local zone_intflist = param_json["mem_intflist"]
        local op = param_json["op"]
        
        if (update_zone_mem(zone_uuid, zone_intf, zone_intflist, op, config_json, config_file_path) == 0) then
            module_debug.lua_debug(module_debug.INFO, "INFO: end update zone mem intf success")
            return '{"rcode":"00000000", "message":"Configuration success"}'
        else
            module_debug.lua_debug(module_debug.INFO, "INFO: end update zone mem intf failed")
            return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone update config failed")
        end
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param is error")
    end

    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_uuid(v["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param uuid is error")
        end

        if (v["name"] ~= nil) then
            ret = checkparam_for_string_len(v["name"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param name is error")
            end
        end

        if (v["mem"] ~= nil and v["mem"] ~= "") then
            ret = checkparam_for_array(v["mem"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param mem is error")
            end
        end

        if (v["zoneAccess"] ~= nil) then
            ret = checkparam_for_array(v["zoneAccess"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param zoneAccess is error")
            end
        end

        if (v["accessedZone"] ~= nil) then
            ret = checkparam_for_array(v["accessedZone"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param accessedZone is error")
            end
        end

        if (v["type"] ~= nil) then
            ret = checkparam_for_type(v["type"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param type is error")
            end
        end

        if (v["disbaleList"] ~= nil) then
            ret = checkparam_for_array(v["disbaleList"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "param disbaleList is error")
            end
        end
    end

    ret = update_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONE_CONFIG_EXCEPTION"], "ERROR: safezone update config failed")
    end

    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_set(param)
    return fail_reason(err_code["ERR_SAFEZONE_PARAM_EXCEPTION"], "ERROR: the operation is not support")
end

-- Configuration Framework Apply
function module_apply(param_json, config_file_path)
    if (file_exist(safeZoneRule) == true) then
        os.execute(safeZoneRule) 
    end
    
    if (file_exist("/usr/sbin/safeZoneApply.lua") == true) then
        os.execute("/usr/bin/lua /usr/sbin/safeZoneApply.lua >/dev/null 2>&1 &")
    end

    if (file_exist("/proc/shortcut_flush") == true) then
        os.execute("echo 'f' > /proc/shortcut_flush") 
    end

    if (file_exist("/usr/lib/lua/hnat/hwnat_clean_entry.lua") == true) then
        os.execute("/usr/bin/lua /usr/lib/lua/hnat/hwnat_clean_entry.lua >/dev/null 2>&1 &");
    end
end
