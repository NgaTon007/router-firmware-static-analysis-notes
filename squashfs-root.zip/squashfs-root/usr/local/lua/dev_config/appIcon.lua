#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("appIcon", package.seeall);
require("uci")
require "public_module"
local x = uci.cursor()
cjson_safe = require "cjson.safe"
local module_debug = require "utils.debug"
local conf_defult = "/etc/sd_config/single/appIcon.json";
local console = require "console"

local function split_string(str, reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

-- 获取应用图标和应用名称的映射关系
local function get_app_icon_map()
    local path
    local flag = 0
    local icon_table = {}
    local version = x:get("app_identify", "signature", "version")

    if (version == "2") then
        path = "/usr/sbin/signature/V2.0/app_file_list.txt"
    elseif (version == "3") then
        path = "/usr/sbin/signature/V3.0/app_file_list.txt"
    elseif (version == "4") then
        path = "/usr/sbin/signature/V4.0/app_file_list.txt"
    else
        print("{\"code\":\"-1\", \"msg\":\"version illegal\"}")
    end

    -- 读取/usr/sbin/signature/Vx.0/app_file_list.txt文件的[ICON_MAP]属性页
    local file = io.open(path, "r")
    local content = file:read("*all")
    file:close()
    local a = split_string(content, '\n')
    for i = 1, #a do
        if (flag == 0) then
            if (a[i] == "[ICON_MAP]") then
                flag = 1
            end
        else
            -- [ICON_MAP]属性页格式 name:index -> 映射关系放在icon_table中
            local line = split_string(a[i], ':')
            if (#line == 2) then
                local icon = {}
                icon["name"] = string.gsub(line[1], "%s+", "")
                icon["idx"] = string.gsub(line[2], "%s+", "")
                table.insert(icon_table, icon)
                -- icon_table[string.gsub(line[1], "%s+", "")] = string.gsub(line[2], "%s+", "")
            elseif (#line == 3) then
                local icon = {}
                icon["name"] = string.gsub(line[1], "%s+", "") .. ":" .. string.gsub(line[2], "%s+", "")
                icon["idx"] = string.gsub(line[3], "%s+", "")
                table.insert(icon_table, icon)
            end
        end
    end
    return icon_table
end

local function get_app_idy_version()
    local t = io.popen("/usr/sbin/idyc -v")
    local output = t:read("*all")

    return string.match(output, "Version:(.-)%s*$")
end

function module_default_config_get()
    local default_config = {}
    local version = x:get("app_identify", "signature", "version")
    local app_version = get_app_idy_version()

    default_config["app_ver"] = app_version
    default_config["sig_version"] = version
    default_config["app_icon"] = get_app_icon_map()
    return cjson_safe.encode(default_config)
end

function module_update()
    local config = {}
    local version = x:get("app_identify", "signature", "version")
    local app_version = get_app_idy_version()

    config = public_module.read_file(conf_defult)
    config["app_ver"] = app_version
    config["sig_version"] = version
    config["app_icon"] = get_app_icon_map()
    public_module.write_file(config, conf_defult)
    return console.uf_lua_success()
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end
