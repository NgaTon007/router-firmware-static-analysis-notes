#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("services", package.seeall);

local cjson = require("cjson")
local dkjson = require("dkjson")
local liblog = require("utils.debug")
local cjson_safe = require("cjson.safe")
local moduleId = require("dev_module_id")
local utils_json = require("utils.json")
local dev_config = require("dev_config")

local sd_device_file = "/tmp/sd_device/sd_device.json"
local log_dir = "/tmp/services/"
local log_file = "services.log"

liblog.debug_init(log_dir, log_file, 100, liblog.DEBUG, liblog.OPEN)

function module_ret(code, rcode, rdata, rmsg)
    local err = {}
    local ret = {}
    ret["err"] = {}
    err["rdata"] = rdata
    err["rcode"] = string.format("%s%04d", require("dev_module_id").get_module_id("snmp"), tonumber(rcode))
    ret["code"] = code
    err["rmsg"] = rmsg
    ret["err"] = err
    --table.insert(ret["err"], err)
    res = ret
    if (code == "1") then
        local json_str = cjson_safe.encode(res)
        liblog.lua_debug(liblog.INFO,"return json_str:%s\n",json_str)
    end

    return cjson_safe.encode(ret)
end

------------��ܵ���-------------
function module_default_config_get()
    local services
    local dev_mode_ret
    local dev_mode_table
    local forwardMode
    local sd_device_table

    --��ȡ�豸ģʽ
    dev_mode_ret = dev_config.fetch("get", "dev_mode").data
    dev_mode_table = dkjson.decode(dev_mode_ret)
    forwardMode = dev_mode_table["forwardMode"]
    if (forwardMode == nil) then
        liblog.lua_debug(liblog.ERROR, "get forwardMode from dev_mode failed")
        return module_ret("1", "2", "NULL", "get forwardMode from dev_mode failed")
    end

    if (forwardMode == "SWITCH") then 
        --�����豸�еĹ����ڶ��㣬�е������㣬���Ҳ����л�����ģʽ������������ֵ�ж�
        sd_device_table = utils_json.get_json_table_from_file(sd_device_file);
        if (sd_device_table["sysServices"] == nil) then
            liblog.lua_debug(liblog.ERROR, "get sysServices from sd_device failed")
            return module_ret("1", "2", "NULL", "get sysServices from sd_device failed")
        end
        services = sd_device_table["sysServices"]
    else
        --�ǽ����豸ͨ��ģʽ�л�����֪���豸�����ڼ���
        if (forwardMode == "AC" or forwardMode == "AP") then
            services = 3
        else
            if (forwardMode == "ROUTER") then
                services = 7
            else
                liblog.lua_debug(liblog.ERROR, "unknown forwardMode")
                return module_ret("1", "2", "NULL", "unknown forwardMode")
            end
        end
    end

    return string.format("{\"services\":%s}", services)
end

function module_get(param)

end

function module_set(param)

end