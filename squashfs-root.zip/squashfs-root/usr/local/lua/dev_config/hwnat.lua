#! /usr/bin/lua

module("hwnat", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local fs  = require "nixio.fs"
local uci = require "luci.model.uci".cursor()
local tool = require "dev.tools.common"
local cjson = require "cjson"
require "luci.sys"

--debug
local function debug(msg)
    console.debug("hwnat", msg)
end

local function my_exec(cmd)
    -- body
    if cmd and cmd:len() > 0 then
        debug(cmd)
        os.execute(cmd)
    end
end
local function is_module_load( ... )
    -- body
    return os.execute("lsmod|grep hw_nat")
end
function module_default_config_get()
    local data = {}
    uci:set_confdir("/rom/etc/config")
    local enabled = uci:get("mtkhnat",'global','enable') or '0'
    local hqos = uci:get("mtkhnat",'global','hqos') or '0'
    data.enabled = enabled == "1" and "true" or "false"
    data.hqos = hqos == "1" and "true" or "false"
    uci:set_confdir("/etc/config")
    return dkjson.encode(data)
end
local function shortcut_load(option)
    -- body
    if option and  option == 'start' then
        if fs.access('/proc/shortcut_enable') then
            my_exec('echo 1 >/proc/shortcut_enable')
        end
    elseif option and option == 'stop' then
        if fs.access('/proc/shortcut_enable') then
            my_exec('echo 0 >/proc/shortcut_enable')
        end
    end
end
local function get_changes(cfg_name)
    local changes = uci:changes(cfg_name)
    if next(changes) and changes[cfg_name] then
        return changes[cfg_name]
    else
        return {}
    end
end
function sd_split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function (w)
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

function module_set(param)
    local paramTable = dkjson.decode(param)
    local enabled = paramTable and paramTable.enabled == "true" and '1' or '0'

    if paramTable and (paramTable.enabled) then
        if paramTable.enabled then
            uci:set("mtkhnat", "global", "enable", enabled)
        end

        uci:commit("mtkhnat")

        local change = get_changes('mtkhnat')
        if change then
            debug(dkjson.encode(change))
            if change.global and change.global.enable then
                if change.global.enable == '1' then
                    local file_data
                    local sd_device_json
                    if (tool.file_exist("/tmp/sd_device/sd_device.json") == true) then
                        file_data = tool.file_read("/tmp/sd_device/sd_device.json");
                        sd_device_json = cjson.decode(file_data);
                        if (sd_device_json["gateway"]["hwnat_egw"] ~= "1") then
                            shortcut_load('stop')
                        end
                    else
                        shortcut_load('stop')
                    end
                    if is_module_load() ~= 0 then
                        my_exec("/sbin/mtkhnat start >/dev/null")
                    end
                    -- my_exec("echo $(uci show network|grep wan| grep vlan| cut -d= -f2| xargs echo) > /proc/hnat_ext_wan 2>/dev/null")
                    -- my_exec("echo $(dev_config get -m network  2>/dev/null | jq .lan |grep -wr vlanid| cut -d: -f2| cut -d, -f1 |xargs echo) > /proc/hnat_ext_lan 2>/dev/null")
                    my_exec("[ -f \"/proc/hnat_enable\" ] &&  echo 1 > /proc/hnat_enable 2>/dev/null")

                    my_exec("echo 1 > /proc/tc_switch_enable 2>/dev/null")
                    local flow_ctrl_data = luci.sys.exec("dev_sta get -m flowctrl 2>/dev/null")
                    local flow_ctrl_json = cjson.decode(flow_ctrl_data)
                    flow_ctrl_json["tcSwitch"]="off"
                    for i, element in ipairs(flow_ctrl_json["list"]) do
                        flow_ctrl_json["list"][i]["ifname"] = string.gsub(flow_ctrl_json["list"][i]["ifname"], "pppoe", "br")
                    end
                    --发通告给云端进行同步
                    flow_ctrl_data = cjson.encode(flow_ctrl_json)
                    os.execute("exec 1>/tmp/null 2>&1")
                    os.execute(string.format("dev_config set -m flowctrl '%s'  2>/dev/null &", flow_ctrl_data))
                elseif change.global.enable == '0' then
                    my_exec("/sbin/mtkhnat start >/dev/null")
                    shortcut_load('start')
                    my_exec("echo 0 > /proc/tc_switch_enable 2>/dev/null")
                end
            end
        end
    end
end

function module_get(param)
    local data = {}
    local enabled = uci:get("mtkhnat",'global','enable') or '0'
    data.enabled = enabled == "1" and "true" or "false"

    return dkjson.encode(data)
end
