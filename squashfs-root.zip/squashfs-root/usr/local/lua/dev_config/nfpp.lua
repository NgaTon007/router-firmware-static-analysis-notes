#! /usr/bin/env lua

module_name = "nfpp"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
cjson = require "cjson"
dkjson = require "dkjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"
nfpp_manager = require("nfpp_manager")

defValueCfg = "/usr/lib/app_auth/app_auth.cfg"

----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 15, module_debug.DEBUG, "1")

local err_code = {
    ["SUCCESS"] = "00000000",
    ["ERR_NFPP_PARAM_EXCEPTION"] = "04290001",
    ["ERR_NFPP_CONFIG_EXCEPTION"] = "04290002",
}

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- return error message if execution fails
-- @code: error code
-- @msg: error msg
-- @If it fails to return an error, it is considered that the configuration has failed
local function fail_reason(code, msg)
    local err = {}
    local ret = {}

    err["rcode"] = code
    err["message"] = msg
    ret["code"] = "1"
    ret["err"] = cjson_safe.encode(err)

    return cjson_safe.encode(ret)
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    local sh_ret_handle = io.popen(sh_cmd);
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret;
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = dkjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)
            res = file_write(path, config_str)
            if (res == -1) then
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end
    
    return 0
end

local function checkparam_is_num(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the param style isn't string")
        return -1
    end

    if (string.len(param) == 0) then
        module_debug.lua_debug(module_debug.ERROR, "the param string is null string")
        return -1
    end

    num = tonumber(param)
    if (type(num) ~= "number") then
        module_debug.lua_debug(module_debug.ERROR, "the param isn't number")
        return -1
    end
    
    return 0
end

local function checkparam_for_code(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the param style isn't string")
        return -1
    end

    if (string.len(param) == 0) then
        return 0
    end

    num = tonumber(param)
    if (type(num) ~= "number") then
        module_debug.lua_debug(module_debug.ERROR, "the param isn't number")
        return -1
    end
    
    return 0
end

local function checkparam_for_enable(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the enable style isn't string")
        return -1
    end

    enable = tonumber(param)
    if (type(enable) ~= "number") then
        module_debug.lua_debug(module_debug.ERROR, "the enable isn't number")
        return -1
    end

    if (enable == 1 or enable == 0) then
        return 0
    end
    
    return -1
end

local function checkparam_for_defend_ddos(param)
    for param_k,param_v in pairs(param) do
        ret = checkparam_for_enable(param_v["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the %s enable is error", param_v["enable"])
            return -1
        end 
    
        ret = checkparam_is_num(param_v["limit_rate"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the %s limit_rate is error", param_v["limit_rate"])
            return -1
        end
    end
    
    return 0
end

local function checkparam_for_malformed_pkt(param)
    local large_ping = param["large_ping"]
    local fraggle_atk = param["fraggle_atk"]
    local icmp_check = param["icmp_check"]
    local ip_check = param["ip_check"]

    if (large_ping ~= nil) then
        ret = checkparam_for_enable(large_ping["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the large_ping enable is error")
            return -1
        end
    
        ret = checkparam_is_num(large_ping["limit_length"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the large_ping limit_rate is error")
            return -1
        end
    end

    if (fraggle_atk ~= nil) then
        ret = checkparam_for_enable(fraggle_atk["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the fraggle_atk enable is error")
            return -1
        end
    end

    if (icmp_check ~= nil) then
        ret = checkparam_for_enable(icmp_check["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the icmp_check enable is error")
            return -1
        end
    end

    if (ip_check ~= nil) then
        ret = checkparam_for_enable(ip_check["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the ip_check enable is error")
            return -1
        end
    end

    return 0
end

local function checkparam_for_local_pkt_send(param)
    local icmp_forbit = param["icmp_forbit"]
    local icmpv6_forbit = param["icmpv6_forbit"]

    if (icmp_forbit ~= nil) then
        ret = checkparam_for_enable(icmp_forbit["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the icmp_forbit enable is error")
            return -1
        end
        
        for k,v in pairs(icmp_forbit["msg_type"]) do
            ret = checkparam_is_num(v["type"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "the icmp_forbit[%d] type is error", k)
                return -1
            end
            
            ret = checkparam_for_code(v["code"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "the icmp_forbit[%d] code is error", k)
                return -1
            end
        end
    end

    if (icmpv6_forbit ~= nil) then
        ret = checkparam_for_enable(icmpv6_forbit["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the icmpv6_forbit enable is error")
            return -1
        end
        
        for k,v in pairs(icmpv6_forbit["msg_type"]) do
            ret = checkparam_is_num(v["type"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "the icmpv6_forbit[%d] type is error", k)
                return -1
            end
            
            ret = checkparam_for_code(v["code"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "the icmpv6_forbit[%d] code is error", k)
                return -1
            end
        end
    end

    return 0
end

local function checkparam_for_session_safe(param)
    local rate_limit = param["rate_limit"]

    if (rate_limit ~= nil) then
        ret = checkparam_for_enable(rate_limit["enable"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the rate_limit enable is error")
            return -1
        end
        
        ret = checkparam_is_num(rate_limit["global_rate"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the arp_flood global_rate is error")
            return -1
        end
        
        ret = checkparam_is_num(rate_limit["record_rate"])
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "the arp_flood record_rate is error")
            return -1
        end
        
        global_rate = tonumber(rate_limit["global_rate"])
        record_rate = tonumber(rate_limit["record_rate"])
        if (global_rate < record_rate) then
            module_debug.lua_debug(module_debug.ERROR, "the rate_limit global_rate less than record_rate")
            return -1
        end
    end

    return 0
end

local function checkparam_is_json(param)
    if (type(param) ~= "string") then
        return nil
    end

    module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", module_name, param)

    local param_json = cjson_safe.decode(param)
    if (param_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter format is not json")
        return nil
    end

    return param_json
end

local function checkparam_for_update_node(param)
    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return nil
    end
    
    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return nil
    end

    for k,v in pairs(param_json["list"]) do
        if (v["zone_name"] == nil or type(v["zone_name"]) ~= "string") then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s zone name isn't set", k)
            return nil
        end
    
        if (v["defend_ddos"] ~= nil) then
            if (checkparam_for_defend_ddos(v["defend_ddos"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list zone name [%s]'s defend_ddos is error", v["zone_name"])
                return nil
            end
        end
        
        if (v["malformed_pkt"] ~= nil) then
            if (checkparam_for_malformed_pkt(v["malformed_pkt"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list zone name [%s]'s malformed_pkt is error", v["zone_name"])
                return nil
            end
        end

        if (v["local_pkt_send"] ~= nil) then
            if (checkparam_for_local_pkt_send(v["local_pkt_send"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list zone name [%s]'s local_pkt_send is error", v["zone_name"])
                return nil
            end
        end
        
        if (v["session_safe"] ~= nil) then
            if (checkparam_for_session_safe(v["session_safe"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list zone name [%s]'s session_safe is error", v["zone_name"])
                return nil
            end
        end 
    end
    
    return param_json
end

local function arp_flood_cfg(defend_ddos, param, config)
    local cmd

    -- arp flood
    if (param["arp_flood"]["enable"] ~= config["arp_flood"]["enable"] or param["arp_flood"]["limit_rate"] ~= config["arp_flood"]["limit_rate"]) then
        defend_ddos["arp_flood"] = 1
        
        limit_rate = tonumber(param["arp_flood"]["limit_rate"])
        burst_rate = limit_rate * 2
        
        if (param["arp_flood"]["enable"] == "0") then
            nfpp_manager.set_nfpp_bridge(zone_name, 0, 0) 
        else
            nfpp_manager.set_nfpp_bridge(zone_name, limit_rate, burst_rate)
        end
        
    else
        defend_ddos["arp_flood"] = 0
    end
    
    config["arp_flood"]["enable"] = param["arp_flood"]["enable"]
    config["arp_flood"]["limit_rate"] = param["arp_flood"]["limit_rate"]
end

local function update_node_for_other_defend_ddos(defend_ddos, param, config, ddos_type)
    local filename
    
    if (param[ddos_type]["enable"] ~= config[ddos_type]["enable"] or param[ddos_type]["limit_rate"] ~= config[ddos_type]["limit_rate"]) then
        defend_ddos[ddos_type] = 1
    else
        defend_ddos[ddos_type] = 0
    end
    
    config[ddos_type]["enable"] = param[ddos_type]["enable"]
    config[ddos_type]["limit_rate"] = param[ddos_type]["limit_rate"]
end

local function update_node_for_defend_ddos(defend_ddos, param, config)
    local cmd

    for param_k,param_v in pairs(param) do
        local ddos_type = param_k

        if (ddos_type ~= "arp_flood") then
            update_node_for_other_defend_ddos(defend_ddos, param, config, ddos_type)
        end
    end
    
    arp_flood_cfg(defend_ddos, param, config)
end

local function update_node_for_malformed_pkt(malformed_pkt, param, config)
    if (param["large_ping"]["enable"] ~= config["large_ping"]["enable"] or param["large_ping"]["limit_length"] ~= config["large_ping"]["limit_length"]) then
        malformed_pkt["large_ping"] = 1
    else
        malformed_pkt["large_ping"] = 0
    end

    config["large_ping"]["enable"] = param["large_ping"]["enable"]
    config["large_ping"]["limit_length"] = param["large_ping"]["limit_length"]

    if (param["fraggle_atk"]["enable"] ~= config["fraggle_atk"]["enable"]) then
        malformed_pkt["fraggle_atk"] = 1
    else
        malformed_pkt["fraggle_atk"] = 0
    end

    config["fraggle_atk"]["enable"] = param["fraggle_atk"]["enable"]

    if (param["icmp_check"]["enable"] ~= config["icmp_check"]["enable"]) then
        malformed_pkt["icmp_check"] = 1
    else
        malformed_pkt["icmp_check"] = 0
    end

    config["icmp_check"]["enable"] = param["icmp_check"]["enable"]

    if (param["ip_check"]["enable"] ~= config["ip_check"]["enable"]) then
        malformed_pkt["ip_check"] = 1
    else
        malformed_pkt["ip_check"] = 0
    end

    config["ip_check"]["enable"] = param["ip_check"]["enable"]
    
    return 0
end

local function update_node_for_local_pkt_send(local_pkt_send, param, config)
    if (param["icmp_forbit"]["enable"] ~= config["icmp_forbit"]["enable"]) then
        local_pkt_send["icmp_forbit"] = 1
    else
        local_pkt_send["icmp_forbit"] = 0
    end

    if (local_pkt_send["icmp_forbit"] == 0) then
        for param_k,param_v in pairs(param["icmp_forbit"]["msg_type"]) do
            icmp_forbit_flag = 1
            for config_k,config_v in pairs(config["icmp_forbit"]["msg_type"]) do
                if (param_v["code"] == config_v["code"] and param_v["code"] == config_v["code"] and param_v["enable"] == config_v["enable"]) then
                    icmp_forbit_flag = 0
                    break
                end
            end
            
            if (icmp_forbit_flag == 1) then
                local_pkt_send["icmp_forbit"] = 1
                break
            end
        end
    end

    config["icmp_forbit"]["enable"] = param["icmp_forbit"]["enable"]
    config["icmp_forbit"]["msg_type"] = param["icmp_forbit"]["msg_type"]
    
    if (param["icmpv6_forbit"]["enable"] ~= config["icmpv6_forbit"]["enable"]) then
        local_pkt_send["icmpv6_forbit"] = 1
    else
        local_pkt_send["icmpv6_forbit"] = 0
    end

    if (local_pkt_send["icmpv6_forbit"] == 0) then
        for param_k,param_v in pairs(param["icmpv6_forbit"]["msg_type"]) do
            icmp_forbit_flag = 1
            for config_k,config_v in pairs(config["icmpv6_forbit"]["msg_type"]) do
                if (param_v["code"] == config_v["code"] and param_v["code"] == config_v["code"] and param_v["enable"] == config_v["enable"]) then
                    icmp_forbit_flag = 0
                    break
                end
            end
            
            if (icmp_forbit_flag == 1) then
                local_pkt_send["icmpv6_forbit"] = 1
                break
            end
        end
    end

    config["icmpv6_forbit"]["enable"] = param["icmpv6_forbit"]["enable"]
    config["icmpv6_forbit"]["msg_type"] = param["icmpv6_forbit"]["msg_type"]

    return 0
end

local function update_node_for_session_safe(session_safe, param, config, zone_name)
    if (param["rate_limit"]["enable"] ~= config["rate_limit"]["enable"] or param["rate_limit"]["global_rate"] ~= config["rate_limit"]["global_rate"] or 
        param["rate_limit"]["record_rate"] ~= config["rate_limit"]["record_rate"]) then
        session_safe["rate_limit"] = 1
        
        global_rate = tonumber(param["rate_limit"]["global_rate"])
        record_rate = tonumber(param["rate_limit"]["record_rate"])
        
        if (param["rate_limit"]["enable"] == "0") then
            nfpp_manager.set_nfpp_conntrack(zone_name, 0, 0)
        else
            nfpp_manager.set_nfpp_conntrack(zone_name, record_rate, global_rate)
        end
    else
        session_safe["rate_limit"] = 0
    end


    config["rate_limit"]["enable"] = param["rate_limit"]["enable"]
    config["rate_limit"]["global_rate"] = param["rate_limit"]["global_rate"]
    config["rate_limit"]["record_rate"] = param["rate_limit"]["record_rate"]
    
    return 0
end

local function update_config_node(update_list, param, config, zone_name)
    if (param["defend_ddos"] ~= nil) then
        update_list["defend_ddos"] = {}
        update_node_for_defend_ddos(update_list, param["defend_ddos"], config["defend_ddos"], zone_name)
    end
    
    if (param["malformed_pkt"] ~= nil) then
        update_list["malformed_pkt"] = {}
        update_node_for_malformed_pkt(update_list, param["malformed_pkt"], config["malformed_pkt"])
    end

    if (param["local_pkt_send"] ~= nil) then
        update_list["local_pkt_send"] = {}
        update_node_for_local_pkt_send(update_list, param["local_pkt_send"], config["local_pkt_send"])
    end

    if (param["session_safe"] ~= nil) then
        update_list["session_safe"] = {}
        update_node_for_session_safe(update_list, param["session_safe"], config["session_safe"], zone_name)
    end
    
    if (param["flag"] ~= nil) then
        config["flag"] = param["flag"]
    end

    return 0
end

local function update_config(update_t, param_json, config_json)
    local config_list = {}

    for config_k,config_v in pairs(config_json["list"]) do
        if (config_v["zone_name"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s zone name isn't set", config_k)
            return -1
        end
        
        config_list[config_v["zone_name"]] = config_k
    end
    
    for param_k,param_v in pairs(param_json["list"]) do
        if (param_v["zone_name"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s zone name isn't set", param_k)
            return -1
        end
        
        if (config_list[param_v["zone_name"]] ~= nil) then
            update_t[param_v["zone_name"]] = {}
            idx = config_list[param_v["zone_name"]]
            ret = update_config_node(update_t[param_v["zone_name"]], param_json["list"][param_k], config_json["list"][idx], param_v["zone_name"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "update the node[%s] is error", param_v["zone_name"])
                return -1 
            end
        end
    end
    
    return 0
end

-- default config
function module_default_config_get()
    return nfpp_manager.get_nfpp_defcfg_json()
end

function module_add(param)
    return
end

function module_del(param)
    return
end

function module_update(param, config_file_path)
    local param_json = checkparam_for_update_node(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_NFPP_PARAM_EXCEPTION"], "param is error")
    end

    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_NFPP_CONFIG_EXCEPTION"], "ERROR: nfpp setting config is null")
    end
    
    local update_t = {}
    ret  = update_config(update_t, param_json, config_json)
    if (ret == -1) then
        return fail_reason(err_code["ERR_NFPP_CONFIG_EXCEPTION"], "ERROR: nfpp setting config is null")
    end
    
    ret = json_write_to_file(config_file_path, config_json)
    if (ret == -1) then
        return fail_reason(err_code["ERR_NFPP_CONFIG_EXCEPTION"], "ERROR: nfpp setting config is null")
    end

    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_set(param)
    return fail_reason(err_code["ERR_NFPP_CONFIG_EXCEPTION"], "the operation is not support.")
end

-- Configuration Framework Apply
function module_apply()
    local apply_file = "/usr/sbin/nfpp_apply.sh"

    if (file_exist(apply_file) == true) then
        os.execute(apply_file)
    end
end
