#! /usr/bin/lua
--[[
    os.execute("echo ip:".."11".." > /dev/ttyS1")
--]]

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dev_mode", package.seeall);-- 第一个参数是本模块的文件名

-- 调试模块初始化
local libdbg = require("utils.debug");
local libjsn = require("utils.json");
local libubs = require("utils.ubus");
local libexc = require("utils.exec");

libdbg.debug_init("/tmp/dev_mode/", "dev_mode.log", 200, libdbg.DEBUG, libdbg.OPEN);

--[[
    _module_ret() -- 模块set|add|del|update的返回值
    @frm_code：返回给统一配置框架的错误码，参数类型[string, num]
               统一配置框架接收到该字段值字符串的"1"，或者数字的1都认为是模块内部错误返回，不保存配置
               框架最后不会打印本字段。
    @web_code：返回给web的错误码，参数类型[string, num]，框架最后会打印本字段。
    @web_msg:返回给web的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串，{"code":x, "err":"x;xxx"}，例如{"code":1, "err":"1;param is invalid"}
    @note：本接口只给ac_config或者dev_config的set|add|del|update操作使用的。
           最终打印消息是err的值也就是例子中的"1;param is invalid"
           一般只有错误时才需要返回。如果模块成功，不需要调用本接口，直接return。
--]]
function _module_ret(frm_code, web_code, web_msg, ...)
    result = {};
    result["code"] = frm_code;
    result["err"] = table.concat({web_code, ";", string.format(web_msg, ...)});

    return require("dkjson").encode(result);
end

--[[
    module_ret() -- 模块set|add|del|update的返回值
    @code：错误码，参数类型[string]，如果是"00000000"则不需要加上模块吗，否则要加上模块码
    @status：状态信息，<success|failed>。
    @msg:返回给web的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串
--]]
function module_ret(code, status, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    else
        result["rcode"] = table.concat({require("dev_module_id").get_module_id("dev_mode"), code});
    end
    result["status"] = status;
    result["msg"] = string.format(msg, ...);
    res = result;

    -- 错误返回
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = require("dkjson").encode(res);
    -- libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return json_str;
end

------------框架调用-------------
function module_default_config_get()
    libdbg.lua_debug(libdbg.INFO, "********************Enter dev_mode_get()********************");
    local dev_mode = {};
    local uci = require("luci.model.uci").cursor();
    dev_mode["rcode"] = "00000000";
    -- 898475，user不写/etc/sd_config/single/dev_mode.json，配置框架同步配置到从，因没有user参数，从设备不生效
    dev_mode["user"]        = "default";
    dev_mode["forwardMode"] = uci:get_first("sysinfo", "sysinfo", "forwardMode");
    dev_mode["relayMode"]   = uci:get_first("sysinfo", "sysinfo", "relayMode");
    dev_mode["autoJoin"]    = uci:get_first("sysinfo", "sysinfo", "autoJoin");
    dev_mode["acEnable"]    = uci:get_first("sysinfo", "sysinfo", "acEnable");
    local json_str = require("dkjson").encode(dev_mode);
    libdbg.lua_debug(libdbg.INFO, "End dev_mode_get() json_str:%s\n", json_str);

    return json_str;
end

-- @module_get
function module_get(param)
end

-- @module_set
function module_set(param)
    libdbg.lua_debug(libdbg.INFO, "********************Enter dev_mode_set()********************");

    local forwardMode_tab = {
        "ROUTER",
        "AC",
        "AP",
        "SWITCH",
    }

    -- 获取基础信息
    local uci = require("luci.model.uci").cursor();

    -- 读取能力表
    local sd_device_tab = libjsn.get_json_table_from_file("/tmp/sd_device/sd_device.json");
    local support_wifi = sd_device_tab["support_wifi"];

    -- 1、参数检查
    -- {"forwardMode":"ROUTER","autoJoin":"true","acEnable":"true"}
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set parameter is nil");
        return module_ret("0012", "failed", "dev_mode set parameter is nil");
    end
    libdbg.lua_debug(libdbg.INFO, "dev_config set -m dev_mode '%s'", param);

    -- 2、参数解析
    local tab = require("dkjson").decode(param);
    if (tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set parameter is invalid, require json");
        return module_ret("0012", "failed", "dev_mode set parameter is nil, require json");
    end
    -- 2.1、解析参数：user
    if (tab["user"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:user is nil");
        return module_ret("0013", "failed", "dev_mode set require parameter:user");
    end
    -- 2.2、解析参数：forwardMode
    if (tab["forwardMode"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set require parameter:forwardMode");
        return module_ret("0013", "failed", "dev_mode set require parameter:forwardMode");
    elseif (require("utils.table").val_in_table(forwardMode_tab, tab["forwardMode"]) == false) then
        libdbg.lua_debug(libdbg.ERROR, "parameter forwardMode:%s is invalid, require <ROUTER|AC|AP|SWITCH>", tab["forwardMode"]);
        return module_ret("0014", "failed", "parameter forwardMode:%s is invalid, require <ROUTER|AC|AP|SWITCH>", tab["forwardMode"]);
    end
    -- 2.3、解析参数：relayMode
    -- 支持无线wifi且转发模式为AP时才检查中继模式参数
    -- if (support_wifi == "1" and tab["forwardMode"] == "AP" and tab["relayMode"] ~= nil) then
    if (tab["relayMode"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set require parameter:forwardMode");
        return module_ret("0013", "failed", "dev_mode set require parameter:relayMode");
    elseif (tab["relayMode"] ~= "wiredBridge" and tab["relayMode"] ~= "wirelessBridge" and tab["relayMode"] ~= "none") then
        libdbg.lua_debug(libdbg.ERROR, "parameter relayMode:%s is invalid, require <wiredBridge|wirelessBridge|none>", tab["relayMode"]);
        return module_ret("0014", "failed", "parameter relayMode:%s is invalid, require <wiredBridge|wirelessBridge|none>", tab["relayMode"]);
    end
    -- 2.4、解析参数：autoJoin
    if (tab["autoJoin"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set require parameter:autoJoin");
        return module_ret("0013", "failed", "dev_mode set require parameter:autoJoin");
    elseif (tab["autoJoin"] ~= "true" and tab["autoJoin"] ~= "false") then
        libdbg.lua_debug(libdbg.ERROR, "parameter autoJoin:%s is invalid, require <true|false>", tab["autoJoin"]);
        return module_ret("0014", "failed", "parameter autoJoin:%s is invalid, require <true|false>", tab["autoJoin"]);
    end
    -- 2.5、解析参数：acEnable
    if (tab["acEnable"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "dev_mode set require parameter:acEnable");
        return module_ret("0013", "failed", "dev_mode set require parameter:acEnable");
    elseif (tab["acEnable"] ~= "true" and tab["acEnable"] ~= "false") then
        libdbg.lua_debug(libdbg.ERROR, "parameter acEnable:%s is invalid, require <true|false>", tab["acEnable"]);
        return module_ret("0014", "failed", "parameter acEnable:%s is invalid, require <true|false>", tab["acEnable"]);
    end
    -- 2.6、解析参数：noreply
    if (tab["noreply"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "dev_mode set require parameter:noreply");
    elseif (tab["noreply"] ~= "true" and tab["noreply"] ~= "false") then
        libdbg.lua_debug(libdbg.ERROR, "parameter noreply:%s is invalid, require <true|false>", tab["noreply"]);
        return module_ret("0014", "failed", "parameter noreply:%s is invalid, require <true|false>", tab["noreply"]);
    end

    if (tab["relayMode"] == nil) then
        libdbg.lua_debug(libdbg.INFO, "Input dev_mode, forwardMode:%s, autoJoin:%s, acEnable:%s", tab["forwardMode"], tab["autoJoin"], tab["acEnable"]);
    else
        libdbg.lua_debug(libdbg.INFO, "Input dev_mode, forwardMode:%s, relayMode:%s, autoJoin:%s, acEnable:%s", tab["forwardMode"], tab["relayMode"], tab["autoJoin"], tab["acEnable"]);
    end

    -- relayMode为空时处理逻辑，TODO：要求调用到本接口的所有位置，都要下发relayMode
    if (tab["relayMode"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "param:relayMode is nil");
        tab["relayMode"] = uci:get_first("sysinfo", "sysinfo", "relayMode");
        libdbg.lua_debug(libdbg.WARNING, "uci get sysinfo.@sysinfo[0].relayMode=%s", tab["relayMode"]);
        -- 支持无线wifi且转发模式为AP，以及中继模式参数relayMode为空时才设置默认值：wireBridge
        if (tab["relayMode"] == nil and support_wifi == "1" and tab["forwardMode"] == "AP") then
            libdbg.lua_debug(libdbg.WARNING, "param:relayMode is nil, set to default: wiredBridge");
            tab["relayMode"] = "wiredBridge";
        else
            libdbg.lua_debug(libdbg.WARNING, "param:relayMode is nil, set to default: none");
            tab["relayMode"] = "none";
        end
    end

    -- 2、写sysinfo配置
    libdbg.lua_debug(libdbg.INFO, "-------->before set sysinfo<--------");
    libexc.exec_cmd_ret("uci show sysinfo");
    local forwardMode_changed = false;
    local relayMode_changed = false;
    local autoJoin_changed = false;
    local acEnable_changed = false;
    local fm_raw = nil;
    local fm_cur = nil;
    local rm_raw = nil;
    local rm_cur = nil;
    uci:foreach("sysinfo", "sysinfo",
    function(s)
        --[[
            -- 898475，user不写/etc/sd_config/single/dev_mode.json，配置框架同步配置到从，因没有user参数，从设备不生效
            解决交换机有多个线卡导致第二遍遍历的时候s["xxx"]是空的，也就是nil
            控制仅第一遍遍历才有读写操作，第二遍不执行任何操作
        --]]
        if (s[".index"] ~= 0) then
            return;
        end
        -- foreach已经把数据读出来了无需再get一次
        -- forwardMode = uci:get("sysinfo", s[".name"], "forwardMode");
        -- relayMode = uci:get("sysinfo", s[".name"], "relayMode");
        -- autoJoin = uci:get("sysinfo", s[".name"], "autoJoin");
        -- acEnable = uci:get("sysinfo", s[".name"], "acEnable");
        forwardMode = s["forwardMode"];
        fm_raw = forwardMode;
        fm_cur = tab["forwardMode"];
        relayMode = s["relayMode"];
        rm_raw = relayMode;
        rm_cur = tab["relayMode"];
        autoJoin = s["autoJoin"];
        acEnable = s["acEnable"];
        -- foreach里面不能打印日志
        -- uci get和set都放在一个foreach里面，避免重复遍历
        if (forwardMode ~= nil and forwardMode ~= tab["forwardMode"]) then
            -- 交换机不允许设置转发模式
            if (forwardMode == "SWITCH" or tab["forwardMode"] == "SWITCH") then
                libdbg.lua_debug(libdbg.ERROR, "switch machine not support change forwardMode");
            else
                uci:set("sysinfo", s[".name"], "forwardMode", tab["forwardMode"]);
                forwardMode_changed = true;
            end
        end
        -- 支持无线wifi时才检查中继模式参数，其他情况皆为none
        if (support_wifi == "1") then
            if (relayMode ~= nil and relayMode ~= tab["relayMode"]) then
                uci:set("sysinfo", s[".name"], "relayMode", tab["relayMode"]);
                relayMode_changed = true;
            end
        else
            if (relayMode == nil or relayMode ~= "none") then
                -- uci:set("sysinfo", s[".name"], "relayMode", tab["relayMode"]);
                uci:set("sysinfo", s[".name"], "relayMode", "none");
                relayMode_changed = true;
            end
        end

        if (autoJoin ~= nil and autoJoin ~= tab["autoJoin"]) then
            uci:set("sysinfo", s[".name"], "autoJoin", tab["autoJoin"]);
            autoJoin_changed = true;
        end
        if (acEnable ~= nil and acEnable ~= tab["acEnable"]) then
            uci:set("sysinfo", s[".name"], "acEnable", tab["acEnable"]);
            acEnable_changed = true;
        end
    end)
    if (forwardMode_changed == true or relayMode_changed == true
        or autoJoin_changed == true or acEnable_changed == true) then
        uci:commit("sysinfo");
        uci:revert("sysinfo");-- 清除uci缓存空间，清除不设置的参数（放弃对配置所做的任何尚未提交的更改）
    end
    
    libdbg.lua_debug(libdbg.INFO, "-------->after set sysinfo<--------");
    libexc.exec_cmd_ret("uci show sysinfo");
    if (support_wifi == "1") then
        libdbg.lua_debug(libdbg.INFO, "uci get sysinfo, forwardMode:%s, relayMode:%s, autoJoin:%s, acEnable:%s", forwardMode, relayMode, autoJoin, acEnable);
    else
        libdbg.lua_debug(libdbg.INFO, "uci get sysinfo, forwardMode:%s, autoJoin:%s, acEnable:%s", forwardMode, autoJoin, acEnable);
    end
    -- foreach里面不能打印日志，所以放在foreach外面
    if (forwardMode_changed == true) then
        libdbg.lua_debug(libdbg.INFO, "uci set sysinfo.@sysinfo[0].forwardMode=%s", tab["forwardMode"]);
        libdbg.lua_debug(libdbg.INFO, "forwardMode: [%s] --------> [%s]", forwardMode, tab["forwardMode"]);
    end
    if (relayMode_changed == true) then
        libdbg.lua_debug(libdbg.INFO, "uci set sysinfo.@sysinfo[0].relayMode=%s", tab["relayMode"]);
        libdbg.lua_debug(libdbg.INFO, "relayMode: [%s] --------> [%s]", relayMode, tab["relayMode"]);
    end
    if (autoJoin_changed == true) then
        libdbg.lua_debug(libdbg.INFO, "uci set sysinfo.@sysinfo[0].autoJoin=%s", tab["autoJoin"]);
    end
    if (acEnable_changed == true) then
        libdbg.lua_debug(libdbg.INFO, "uci set sysinfo.@sysinfo[0].acEnable=%s", tab["acEnable"]);
    end

    -- 3、模式切换通告
    if (forwardMode_changed == true or relayMode_changed == true
        or autoJoin_changed == true or acEnable_changed == true) then
        libdbg.lua_debug(libdbg.INFO, "ubus send dev_mode '%s'", require("dkjson").encode(tab));
        libubs.ubus_send("dev_mode", tab, 3);
    end

    -- 4、模式切换行为：切换软件能力值表+恢复出厂配置+重启程序
    -- 901507提出的新需求，wiredBridge|wirelessBridge|none这三种中继模式的切换不做任何事情
    -- if (forwardMode_changed == true or relayMode_changed == true) then
    if (forwardMode_changed == true) then
        local dev_mode_tab = sd_device_tab["dev_mode"] or nil;
        if (dev_mode_tab ~= nil and dev_mode_tab["reboot"] == "0") then
            -- 能力表指定：模式切换不重启
            cmd = string.format("/usr/sbin/dev_mode_sw_cap.lua fwrd %s %s %s %s", fm_raw, fm_cur, rm_raw, rm_cur);
            libdbg.lua_debug(libdbg.INFO, "call %s", cmd);
            -- 实测：考虑到传参，所以通过调用系统命令执行
            libexc.fork_exec_cmd(cmd);
        else
            cmd = string.format("/usr/sbin/dev_mode_sw_cap.lua reset %s %s %s %s", fm_raw, fm_cur, rm_raw, rm_cur);
            libdbg.lua_debug(libdbg.INFO, "call %s", cmd);
            libexc.fork_exec_cmd(cmd);
        end
    elseif (autoJoin_changed == true or acEnable_changed == true) then
        cmd = string.format("/usr/sbin/dev_mode_sw_cap.lua mngt %s %s %s %s", fm_raw, fm_cur, rm_raw, rm_cur);
        libdbg.lua_debug(libdbg.INFO, "call %s", cmd);
        libexc.fork_exec_cmd(cmd);
    elseif (relayMode_changed == true) then
        -- 901507提出的新需求，wiredBridge|wirelessBridge|none这三种中继模式的切换不做任何事情，但是要回调finish_script
        cmd = string.format("/usr/sbin/dev_mode_sw_cap.lua finish %s %s %s %s", fm_raw, fm_cur, rm_raw, rm_cur);
        libdbg.lua_debug(libdbg.INFO, "call %s", cmd);
        libexc.fork_exec_cmd(cmd);
    end

    libdbg.lua_debug(libdbg.DEBUG, "End dev_mode_set()\n");

    if (tab["noreply"] == nil or tab["noreply"] == "false") then
        return module_ret("00000000", "success", "NA");
    end
end

-- param = '{"user": "default", "forwardMode": "SWITCH", "autoJoin": "true", "relayMode": "none", "acEnable": "false"}';
-- module_set(param)