#! /usr/bin/lua
package.path = string.format("%s;%s;%s;", package.path, "/usr/sbin/web/?.lua", "/usr/lib/lua/ippool/?.lua;")
module("l2tp_server",package.seeall)

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson";
local lfs = require "lfs"
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local ipsec_cfg = require "ipsec_cfg_pub"
local reference = require "ippool_reference"
local sd_crypto = require "sd_crypto"
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local LOCK_FILE = "/tmp/l2tp/server_lock"
local UPDOWN_DIR = table.concat({DEBUG_LOG_DIR, "updown"});
local SERVER_DIR = table.concat({DEBUG_LOG_DIR, "server/"});
local INPUT_SAVE = table.concat({SERVER_DIR, "server_input_save"});
local IPPOOL_JSON_FILE = "/etc/sd_config/single/ippool.json"
local SERVER_JSON_FILE = "/etc/sd_config/single/l2tp_server.json"
local IPTABLES_COMMENT = "vpn"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "l2tp_server_rules"})
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/l2tp_server_updown.lua & >/dev/null 2>&1"
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "l2tp_server.json"});
local SNOSVPN_DIR = "/var/log/snosvpn/l2tp/"
local SNOSVPN_PPP_SERVER_LOG = table.concat({SNOSVPN_DIR, "l2tp_pppd_server_log"})
local SNOSVPN_PROCESS_LOG = table.concat({SNOSVPN_DIR, "l2tp_xl2tpd_process_log"})

if (tool.file_exist(SNOSVPN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SNOSVPN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(SERVER_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(UPDOWN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", UPDOWN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "l2tp_server.log", 500, l2tp.INFO, "1");
end

function ipsec_set_cfg(op, status, name, input)
    if (input["ike_proposal"] == nil) then
        input["ike_proposal"] = "sha1-3des-dh1"
    end

    if (input["ph2_proposal"] == nil) then
        input["ph2_proposal"] = "esp-sha1-aes128"
    end
    local data = {};
    data["func"] = "ipsec_set_cfg";
    data["mode"] = "l2tp";
    data["type"] = "ser";
    data["op"] = op;
    data["data"]={};
    data["data"]["status"] = status;
    data["data"]["name"] = name;
    data["data"]["secret"] = input["presharekey"];

    local is_ipsec_exist = false;
    uci:foreach("ipsec", "connection", function(s)
        local result = tool.split(s["ipsec_name"], "_");
        print(result[1], result[4]);
        if (result[1] == ipsec_cfg["mode"] and result[4] == ipsec_cfg["type"]) then
            is_ipsec_exist = true;
        end
    end)

    if (is_ipsec_exist == true) then
        l2tp.lua_debug(l2tp.INFO, "Ipsec rule is exist.");
        return;
    end

    l2tp.lua_debug(l2tp.DEBUG, "Ipsec set input: %s", cjson.encode(input));
    local list = {"ike_proposal", "ph2_proposal", "remote_id_type", "remote_id_value", "exchange_mode", "local_id_type", "local_id_value"}
    for i, var in ipairs(list) do
        if (input[var] ~= nil) then
            data["data"][var] = input[var];
        end
    end

    local config_tab = cjson.encode(data)
    --[[
    if (config_tab ~= nil) then
        l2tp.lua_debug(l2tp.INFO, "Ipsec set config: %s", config_tab)
    end
    --]]
    local cmd = "dev_config set -m ipsec '"..config_tab.."'"
    --ipsec_cfg.ipsec_set(cjson.encode(data));
    --l2tp.lua_debug(l2tp.INFO, "cmd: %s", cmd)
    local t = io.popen(cmd)
    t:close()
    return
end

local function ippool_is_exist(ippool_name)
    local is_exist = 0;
    if (tool.file_exist(IPPOOL_JSON_FILE) == false) then
        l2tp.lua_debug(l2tp.INFO, "Error, ippool_name is not find.")
        return false;
    end
    local ippool_data = tool.file_read(IPPOOL_JSON_FILE)
    if (ippool_data == nil or tool.json_check(ippool_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Error, ippool_name is not find.")
        return false;
    end

    local ippool_json = cjson.decode(ippool_data)
    l2tp.lua_debug(l2tp.INFO, "Ippool: %s", ippool_data);
    for i, conf_var in ipairs(ippool_json["list"]) do
        if (ippool_name == conf_var["ippool_name"]) then
            is_exist = 1
            break
        end
    end

    --若对象不存在，则返回错误信息
    if (is_exist == 0) then
        l2tp.lua_debug(l2tp.INFO, "Error, ippool_name is not find.")
        return false;
    end
    return true;
end

local function update_ippool_reference(old_json, new_json)
    local tmp_param = {}
    if (next(old_json) ~= nil) then
        tmp_param["ippool_name"] = old_json["ippool_name"];
        tmp_param["module"] = "l2tp_server";
        reference.ippool_reference_del(cjson.encode(tmp_param));
    end

    tmp_param = {}
    if (next(new_json) ~= nil) then
        tmp_param["ippool_name"] = new_json["ippool_name"];
        tmp_param["module"] = "l2tp_server";
        reference.ippool_reference_add(cjson.encode(tmp_param));
    end
end

local function stop_client_connect()
    local kill_cmd = "kill -TERM"
    --local rm_file_cmd = "rm -rf"
    for file in lfs.dir(SERVER_DIR) do
        if (string.find(file, "_pid") ~= nil) then
            local pid_file = table.concat({SERVER_DIR, file});
            if (tool.file_exist(pid_file) == true) then
                local pid = tool.file_read(pid_file);
                kill_cmd = table.concat({kill_cmd, " ", pid});
                --rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
            end
        end
    end

    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    --[[
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
    --]]

    for file in lfs.dir(SERVER_DIR) do
        if (string.find(file, "_client_save") ~= nil) then
            local save_file = table.concat({SERVER_DIR, file});
            local down_file = table.concat({UPDOWN_DIR, "/", file});
            if (tool.file_exist(save_file) == true) then
                os.rename(save_file, down_file);
                --bugid = 849160
                --os.execute(SERVER_UPDOWN_CMD);
            end
        end
    end
    --l2tp服务器网卡注销，一键下发VPN流控脚本
    local fc_del_cmd = "sh /usr/sbin/fc_vpn_intf_update.sh clear L2TP & >/dev/null 2>&1"
    l2tp.lua_debug(l2tp.INFO, "fc_del_cmd: %s", fc_del_cmd)
    os.execute(fc_del_cmd)
    os.execute(SERVER_UPDOWN_CMD);
end

local function iptables_del()
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("iptables -w -D INPUT_sd_chain -p udp -m udp --dport 1701 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -D INPUT_sd_chain -p udp -m udp --dport 1701 -j reject -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    os.remove(IPTABLES_RULES_FILE);
end

local function iptables_add(fn_json)
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));

    file:write("iptables -w -D INPUT_sd_chain -p udp -m udp --dport 1701 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -D INPUT_sd_chain -p udp -m udp --dport 1701 -j reject -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    if (fn_json["ipsecenc"] ~= "yes") then
        file:write("ipset flush zone_vpn_1701_reject 2>/dev/null\n");
        file:write("iptables -w -A INPUT_sd_chain -p udp -m udp --dport 1701 -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    else
        file:write("iptables -w -A INPUT_sd_chain -p udp -m udp --dport 1701 -j reject -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    end

    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -I INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
end

function server_start_xl2tpd(fn_json)
    local cmd = nil;
    local l2tphellointerval = uci:get("xl2tpd", "service", "l2tphellointerval");
    if (l2tphellointerval == nil) then
        l2tphellointerval = 60
    end

    --loacal ip，在/etc/xl2tpd/xl2tpd.conf文件中
    local file = assert(io.open("/etc/xl2tpd/xl2tpd.conf", "w+"));
    file:write("[global]\n");
    file:write("port = 1701\n");
  --file:write("auth file = /etc/xl2tpd/xl2tp-server-secrets\n");
    file:write("auth file = /tmp/xl2tpd/xl2tp-server-secrets\n");
    file:write("access control = no\n");
    file:write("hello timer = ", l2tphellointerval,"\n");
    file:write("\n");
    file:write("[lns default]\n");
    file:write("exclusive = yes\n");
    file:write("ip range = 192.168.254.202-192.168.254.210\n");
    file:write("length bit = yes\n");
    file:write("name = l2tpserver\n");
    file:write("ppp debug = yes\n");
    file:write("pppoptfile = /etc/ppp/options.xl2tpd\n");
    file:write("local ip = ", fn_json["localip"], "\n");
    file:write("challenge = ", fn_json["challenge"], "\n");
    file:close(file);
    if (fn_json["challenge"] == "yes" and fn_json["tunnelkey"]~= "") then
        --/etc目录下的xl2tpd隧道认证密码作为降级备份恢复为未加密隧道,不加密版本是使用etc目录
        local authfile = io.open("/etc/xl2tpd/xl2tp-server-secrets", "w+");
        if (authfile ~= nil) then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(fn_json["tunnelkey"],#fn_json["tunnelkey"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
            else
                authfile:write("# Secrets for authenticating l2tp tunnels\n");
                authfile:write("# us\tthem\tsecret\n");
                authfile:write("*\t*\t", ciphertext, "\n");
                authfile:close(authfile);
            end
        end
        local tmpfile = io.open("/tmp/xl2tpd/xl2tp-server-secrets", "w+");
        if (tmpfile ~= nil) then
            tmpfile:write("# Secrets for authenticating l2tp tunnels\n");
            tmpfile:write("# us\tthem\tsecret\n");
            tmpfile:write("*\t*\t", fn_json["tunnelkey"], "\n");
            tmpfile:close(tmpfile);
        end
    else
        os.execute(table.concat({"echo > ", "/etc/xl2tpd/xl2tp-server-secrets"}));
        os.execute(table.concat({"echo > ", "/tmp/xl2tpd/xl2tp-server-secrets"}));
    end
    --写入DNS和ippool_name，在/etc/ppp/options.xl2tpd文件中
    local file = assert(io.open("/etc/ppp/options.xl2tpd", "w+"));
    file:write("#\n");
    file:write("noauth\n");
    file:write("debug\n");
    file:write("dump\n");
    file:write("logfd 2\n");
    file:write("plugin ippool.so\n");
    file:write("noccp\n");
    file:write("novj\n");
    file:write("novjccomp\n");
    file:write("nopcomp\n");
    file:write("noaccomp\n");
    file:write("mtu 1360\n");
    file:write("mru 1360\n");
    file:write("require-pap\n");
    file:write("require-chap\n");
    file:write("require-mschap\n");
    file:write("require-mschap-v2\n");
    file:write("chap-secrets-file ", DEBUG_LOG_DIR, "chap-secrets\n");
    file:write("pap-secrets-file ", DEBUG_LOG_DIR, "pap-secrets\n");
    file:write("logfile ", SNOSVPN_PPP_SERVER_LOG, "\n");
    file:write("lcp-echo-failure 5\n");
    file:write("connect-delay 5000\n");
    file:write("nodefaultroute\n");
    file:write("noipdefault\n");
    file:write("proxyarp\n");
    file:write("lcp-echo-interval ", fn_json["lcpechointerval"], "\n");
    file:write("ippool_name ", fn_json["ippool_name"], "\n");
    file:write("ms-dns ", fn_json["DNS"], "\n");
    file:close(file)

    --设定iptables规则
    iptables_add(fn_json);
end

function server_stop_xl2tpd(fn_json)
    --loacal ip，在/etc/xl2tpd/xl2tpd.conf文件中
    local l2tphellointerval = uci:get("xl2tpd", "client", "l2tphellointerval");
    if (l2tphellointerval == nil) then
        l2tphellointerval = 60
    end

    local file = assert(io.open("/etc/xl2tpd/xl2tpd.conf", "w+"));
    file:write("[global]\n");
    file:write("port = 1701\n");
    --客户端使用的隧道认证密钥文件
    --file:write("auth file = /etc/xl2tpd/xl2tp-secrets\n");
    file:write("auth file = /tmp/xl2tpd/xl2tp-secrets\n");
    file:write("access control = no\n");
    file:write("hello timer = ", l2tphellointerval,"\n");
    file:close(file)

    --删除/etc/ppp/options.xl2tpd文件
    os.execute("rm -rf /etc/ppp/options.xl2tpd");

    --删除iptables规则
    iptables_del();

    stop_client_connect();
end

function update_ipsec_set_cfg(fn_json)
    if (fn_json["enable"] == "0") then
        if (fn_json["ipsecenc"] == "yes") then
            ipsec_set_cfg("delete", nil, "l2tpserver", fn_json);
            ipsec_set_cfg( "add", "disable", "l2tpserver", fn_json);
        else
            ipsec_set_cfg("delete", nil, "l2tpserver", fn_json);
        end
    else
        if (fn_json["ipsecenc"] == "yes") then
            ipsec_set_cfg("delete", nil, "l2tpserver", fn_json);
            ipsec_set_cfg( "add", "enable", "l2tpserver", fn_json);
        else
            ipsec_set_cfg("delete", nil, "l2tpserver", fn_json);
        end
    end
end

----------------------------------------------------------------------------------------------------
function l2tp_set(input_data, conf_file)
    l2tp.lua_debug(l2tp.INFO, "###############################SET###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Input data is not json mode.");
        return;
    end
    --l2tp.lua_debug(l2tp.INFO, "Input data: %s", input_data);
    input_json = cjson.decode(input_data);

    --获取旧配置
    local old_json ={};
    if (tool.file_exist(INPUT_SAVE) == true) then
        conf_data = tool.file_read(INPUT_SAVE);
        if (tool.json_check(conf_data) == true) then
            old_json = cjson.decode(conf_data)
        end
    else
        if (tool.file_exist(SERVER_JSON_FILE) == true) then
            conf_data = tool.file_read(SERVER_JSON_FILE);
            if (tool.json_check(conf_data) == true) then
                old_json = cjson.decode(conf_data)
            end
        end
    end

    --输入保存
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        l2tp.lua_debug(l2tp.INFO, "Input save fail.");
    end

    --检查地址池是否创建
    if (input_json["enable"] == "1") then
        if (ippool_is_exist(input_json["ippool_name"]) == false) then
            l2tp.lua_debug(l2tp.ERROR, "Ippool is not exist.");
            return;
        end
    end

    --更新uci配置文件
    if (input_json["enable"] == "0") then
        uci:set("xl2tpd", "service", "enable", "0");
    else
        uci:set("xl2tpd", "service", "enable", "1");
    end
    uci:commit("xl2tpd");

    --更新ippool引用
    if (input_json["enable"] == "1") then
        update_ippool_reference(old_json, input_json);
    end
    update_ipsec_set_cfg(input_json);

    server_stop_xl2tpd(old_json);
    if (input_json["enable"] == "1") then
        server_start_xl2tpd(input_json);
    end

    l2tp.lua_debug(l2tp.INFO, "###############################SET END###############################");
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local lfs = require "lfs"
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        l2tp.lua_debug(l2tp.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        l2tp.lua_debug(l2tp.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    local default_config = '{"enable": "0"}'
    return default_config
end

function module_set(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_set] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_set] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end

    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    l2tp_set(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        l2tp_set(file_data, conf_file);
    end

    --清空pppd 服务器日志
    if (tool.file_exist(SNOSVPN_PPP_SERVER_LOG) == true) then
        os.execute("rm -rf /tmp/log/snosvpn/l2tp/l2tp_pppd_server_log*");
    end
    
    --删除xl2tpd进程日志
    if (tool.file_exist(SNOSVPN_PROCESS_LOG) == true) then
        os.execute("rm -rf /tmp/log/snosvpn/l2tp/l2tp_xl2tpd_process_log*");
    end
    --启动进程
    l2tp.lua_debug(l2tp.INFO, "/etc/init.d/xl2tpd restart");
    os.execute("ubus -t 3 send xl2tpd_restart");
    os.execute("ubus -t 3 send snosvpn_monitor_process");
	os.remove(LOCK_FILE);
end
