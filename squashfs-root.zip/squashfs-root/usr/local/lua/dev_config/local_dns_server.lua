#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("local_dns_server", package.seeall); -- 第一个参数是本模块的文件名

local libdbg = require("utils.debug")
local dkjson = require("dkjson")
local uci = require("uci").cursor()
local moduleId = require "dev_module_id"
local moduleName = "local_dns_server"
local dbgDir = "/tmp/local_dns_server/"
local dbgFile = "local_dns_server.log"

local err_code = {
    ["SUCCESS"] = "0000000",
}

-- 调试模块初始
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

------------ip地址的合法检测--------------
function param_check(data)
    local lenght = table.maxn(data)
    while (lenght > 0) do 
        local tmp = data[lenght]
        local ip1, ip2, ip3, ip4 = string.match(tmp, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$");

        if (ip1 == nil or ip2 == nil or ip3 == nil or ip4 == nil) then
            return false
        end

        if (tonumber(ip1) > 223 or tonumber(ip1) == 127 or tonumber(ip1) < 0) then
            return false
        end
        
        lenght = lenght - 1 
    end
    
    return true
end

local function error_reason(code, msg)
    local err = {}
    local result = {}

    err["rcode"] = table.concat({moduleId.get_module_id(moduleName), code})
    err["message"] = msg
    result["code"] = "1"  
    result["err"] = dkjson.encode(err)

    return dkjson.encode(result)
end

function module_default_config_get()
    local data = {}
    data["dns_server"] = {}
    return dkjson.encode(data)
end

function module_get(param)

end

function module_set(param)
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is null")
        local msg = "param is null"
        local code = "0001"

        return error_reason(code, msg)
    end

    local data = dkjson.decode(param)
    if (data["dns_server"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param[dns_server] is null")
        local msg = "param[dns_server] is null"
        local code = "0002"

        return error_reason(code, msg)
    end

    if (#data["dns_server"] == 0 or data["dns_server"][1] == "") then
        uci:foreach("dhcp", "dnsmasq", function(s)
            local name = s[".name"]
            uci:delete("dhcp", name, "server")
        end
        )

        uci:commit("dhcp")
        uci:revert("dhcp")
        os.execute("ubus send 'dnsmasq_restart'")
        libdbg.lua_debug(libdbg.INFO, "Clear the dns server success")
        return '{"message":"Configuration success","rcode":"00000000"}'
    end

    local ret = param_check(data["dns_server"])
    if (ret == false) then
        libdbg.lua_debug(libdbg.ERROR, "param[dns_server] ip is illegal")
        local msg = "param[dns_server] ip is illegal"
        local code = "0003"

        return error_reason(code, msg)
    end

    uci:foreach("dhcp", "dnsmasq", function(s)
        local name = s[".name"]
        uci:set("dhcp", name, "server", data["dns_server"])
    end
    )

    uci:commit("dhcp")
    uci:revert("dhcp")
    os.execute("ubus send 'dnsmasq_restart'")
    libdbg.lua_debug(libdbg.INFO, "Deploy the dns server %s success", dkjson.encode(data["dns_server"]))
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

