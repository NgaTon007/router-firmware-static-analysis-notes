#! /usr/bin/lua
module("vpn_user",package.seeall)
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local lfs = require "lfs"
local cjson = require "cjson";
local vpn = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local sd_crypto = require "sd_crypto"
local snosvpn = require "common"
local openvpn = require "openvpn"
local OPENVPN_CONFIG_FILE = "/etc/config/openvpn"
local openvpn_exist = tool.file_exist(OPENVPN_CONFIG_FILE)
local DEBUG_LOG_DIR = "/tmp/vpn_user/"
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/l2tp_server_updown.lua"
local list = {"username","password","netmode","enable"}
local UPDOWN_DIR = {
    ["l2tpserver"] = "/tmp/l2tp/updown/",
    ["pptpserver"] = "/tmp/pptp/updown/"
}

local SERVER_DIR = {
    ["l2tpserver"] = "/tmp/l2tp/server/",
    ["pptpserver"] = "/tmp/pptp/server/"
}

local LINKS_LIMIT_NUM = {
    ["client2lan"] = "8",
    ["lan2lan"] = "1"
}

local sd_device = "/tmp/sd_device/sd_device.json"
local sd_device_json = nil
local support_vpn_account_fc = nil
if (tool.file_exist(sd_device) == true) then
    local file_data = tool.file_read(sd_device);
    sd_device_json = cjson.decode(file_data);
    support_vpn_account_fc = sd_device_json["gateway"]["vpn_account_fc"]
end

--debug初始化
local function debug_init()
    vpn.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "vpn_user.log", 500, vpn.INFO, "1");
end

local function input_data_format(fn_input)
    local ret_json = {};
    if (fn_input == nil or tool.json_check(fn_input) == false) then
        vpn.lua_debug(vpn.ERROR, "Input data is not json mode.");
        return ret_json;
    end
    vpn.lua_debug(vpn.INFO, "Input: %s", fn_input);

    fn_json = cjson.decode(fn_input);
    for i, var in ipairs(list) do
        if (fn_json[var] == nil) then
            vpn.lua_debug(vpn.ERROR, "%s is empty.", var);
            return ret_json;
        end
    end

    if (fn_json.netmode == "lan2lan" and fn_json.remotesubnet == nil) then
        vpn.lua_debug(vpn.ERROR, "remotesubnet is empty.");
        return ret_json;
    end

    ret_json = fn_json;

    return ret_json;
end

local function get_config_from_sd_config(file, username, provider)
    local ret_json = {};
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            vpn.lua_debug(vpn.DEBUG, "File data: %s", file_data);
            json = cjson.decode(file_data)
        end
    end
    if (json.list == nil) then
        json.list = {};
    end

    local index = -1;
    local total = table.maxn(json.list);
    for i = 1, total, 1 do
        if (json.list[i].username == username and json.list[i].provider == provider) then
            ret_json = json.list[i];
            index = i;
        end
    end

    if (index ~= -1) then
        table.remove(json.list, index);
        json.total = tostring(total - 1);
        tool.file_write(file, cjson.encode(json), "w+");
    end

    return ret_json;
end

local function read_json_from_file(fn_file)
    local data = {}
    local file_json = {}

    if (tool.file_exist(fn_file) == false) then
        return file_json;
    end

    local file_data = tool.file_read(fn_file)
    if (file_data ~= nil and tool.json_check(file_data) == true) then
        file_json = cjson.decode(file_data)
    end

    return file_json;
end

local function vpn_user_encrypt_config(config_json)
    local recode;
    local ciphertext;
    if config_json["encType"] == nil or config_json["encType"] == 0 then
        if config_json["password"] ~= nil then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(config_json["password"],#config_json["password"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
                return
            else
                config_json["password"] = tostring(ciphertext)
            end
        end
        config_json["encType"] = 1;
    end
end

local function save_config_to_sd_config(file, fn_json)
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end
    if (json.list == nil) then
        json.list = {}
    end

    local total = table.maxn(json.list);
    json.total = tostring(total + 1);
    vpn_user_encrypt_config(fn_json);
    table.insert(json.list, fn_json);
    --vpn.lua_debug(vpn.INFO, "Save config: %s", cjson.encode(json));
    tool.file_write(file, cjson.encode(json), "w+");
end

local function save_user_to_link_record_file(fn_json)
    local data = {}
    local file_json = {}
    local netmode = fn_json["netmode"]
    local provider = fn_json["provider"]
    local name = fn_json["username"];

    local LINK_RECORD_LOCK = table.concat({SERVER_DIR[provider], "link_record_lock"});
    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        local attr = lfs.attributes(LINK_RECORD_LOCK)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < 120) then
            return
        end
        os.remove(LINK_RECORD_LOCK);
    end

    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        return;
    end

    data[name] = {};
    data[name]["netmode"] = netmode;
    data[name]["links_num"] = "0";
    data[name]["limit"] = LINKS_LIMIT_NUM[netmode];
    data[name]["links"] = {};
    local LINK_RECORD_FILE = table.concat({SERVER_DIR[provider], "link_record"});
    local mkdir = table.concat({"mkdir -p ", SERVER_DIR[provider], " >/dev/null 2>&1"});
    os.execute(mkdir);

    vpn.lua_debug(vpn.INFO, "LINK_RECORD_FILE: %s", LINK_RECORD_FILE);
    if (tool.file_exist(LINK_RECORD_FILE) == false) then
        tool.file_write(LINK_RECORD_FILE, cjson.encode(data), "w+");
        return;
    end
    local file_data = tool.file_read(LINK_RECORD_FILE)
    if (file_data ~= nil and tool.json_check(file_data) == true) then
        file_json = cjson.decode(file_data)
    end
    if (file_json[name] ~= nil) then
        return;
    end
    file_json[name] = data[name];
    tool.file_write(LINK_RECORD_FILE, cjson.encode(file_json), "w+");
end

local function delete_user_to_link_record_file(fn_json)
    list = {"l2tpserver","pptpserver"}
    for i, var in ipairs(list) do
        local file_json = {}
        local name = nil
        local del_node = {}
        local LINK_RECORD_FILE = table.concat({SERVER_DIR[var], "link_record"})
        if (tool.file_exist(LINK_RECORD_FILE) == true) then
            local file_data = tool.file_read(LINK_RECORD_FILE)
            if (file_data ~= nil and tool.json_check(file_data) == true) then
                file_json = cjson.decode(file_data)
            end
            for key, val in pairs(fn_json.list) do
                local provider = val.provider
                if (provider == "all" or provider == var) then
                    name = val.username
                    table.insert(del_node, name)
                end
            end
        end
        if (name ~= nil and next(del_node) ~= nil) then
            for k, msg in ipairs(del_node) do
                if (file_json[msg] ~= nil) then
                    file_json[msg] = nil;
                end
            end
            tool.file_write(LINK_RECORD_FILE, cjson.encode(file_json), "w+");
        end
    end
end

local function save_to_user_dir(fn_json, fn_dir)
    --参数安全检测
    if (fn_dir ~= nil) then 
        if (libc2lua.lua_param_safety_check(fn_dir) ~= true) then
            vpn.lua_debug(vpn.DEBUG, "fn_dir error.  fn_dir is %s\n", fn_dir)
            return
        end
    end
    if (tool.file_exist(fn_dir) == false) then
        local mkdir = table.concat({"mkdir -p ", fn_dir, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    local file = table.concat({fn_dir, "input_save"});
    tool.file_write(file, cjson.encode(fn_json), "w+");
end

local function delete_user_dir(fn_json, fn_dir)
    --参数安全检测
    if (fn_dir ~= nil) then 
        if (libc2lua.lua_param_safety_check(fn_dir) ~= true) then
            vpn.lua_debug(vpn.DEBUG, "fn_dir error.  fn_dir is %s\n", fn_dir)
            return
        end
    end
    --vpn.lua_debug(vpn.INFO, "Remove: %s", fn_dir);
    os.execute(table.concat({"rm -rf ", fn_dir}));
end

--[[
local function update_username_and_password(fn_json)
    local provider = fn_json["provider"]
    local name = fn_json["username"];
    local is_create_account = true;
    vpn.lua_debug(vpn.INFO, "name: %s", name);
    local LINK_RECORD_FILE = table.concat({SERVER_DIR[provider], "link_record"});

    local LINK_RECORD_LOCK = table.concat({SERVER_DIR[provider], "link_record_lock"});
    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        local attr = lfs.attributes(LINK_RECORD_LOCK)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime < 120) then
            return
        end
        os.remove(LINK_RECORD_LOCK);
    end
    if (tool.file_exist(LINK_RECORD_LOCK) == true) then
        return;
    end

    if (tool.file_exist(LINK_RECORD_FILE) == true) then
        local file_data = tool.file_read(LINK_RECORD_FILE)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            file_json = cjson.decode(file_data)
            local total_links_num = 0
            for key, val in pairs(file_json) do
                local links = tonumber(val["links_num"]);
                total_links_num = total_links_num + links;
            end
            vpn.lua_debug(vpn.INFO, "Total links num: %s", total_links_num);
            local netmode = file_json[name]["netmode"];
            local links_num = tonumber(file_json[name]["links_num"]);
            local limit_num = tonumber(file_json[name]["limit"]);
            vpn.lua_debug(vpn.INFO, "limit num: %s", limit_num);
            vpn.lua_debug(vpn.INFO, "links num: %s", links_num);
            if (links_num >= limit_num or total_links_num >= 8) then
                is_create_account = false 
            end 
        end
    end

    if (fn_json.enable == "on") then
        snosvpn.write_to_chap_secrets(fn_json);
    end
    if (fn_json.enable == "off") then
        snosvpn.delete_from_chap_secrets(fn_json);
    end
end
]]

local function stop_client_connect(fn_json, fn_dir)
    local kill_cmd = "kill -TERM";
    local rm_file_cmd = "rm -rf";
    local provider = fn_json["provider"];
    local username = fn_json["username"];
    --参数安全检测
    if (fn_dir ~= nil) then
        if (libc2lua.lua_param_safety_check(fn_dir) ~= true) then
            vpn.lua_debug(vpn.DEBUG, "fn_dir error.  fn_dir is %s\n", fn_dir)
            return
        end
    end

    if (tool.file_exist(fn_dir) == false) then
        return;
    end

    for file in lfs.dir(fn_dir) do
        if (string.match(file, "limit") ~= nil) then
            local pid_file = table.concat({fn_dir, file});
            local pid = tool.file_read(pid_file);
            kill_cmd = table.concat({kill_cmd, " ", pid});
            rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
            vpn.lua_debug(vpn.INFO, "file: %s", file);
            local tunnelname = tool.split(file, "_")[1];
            --vpn.lua_debug(vpn.INFO, "tunnelname: %s", tunnelname);
            --vpn.lua_debug(vpn.INFO, "SERVER_DIR: %s", SERVER_DIR[provider]);
            local save_file = table.concat({SERVER_DIR[provider], tunnelname, "_client_save"});
            local down_file = table.concat({UPDOWN_DIR[provider], tunnelname, "_client_save"});
            --vpn.lua_debug(vpn.INFO, "save_file: %s", save_file);
            --vpn.lua_debug(vpn.INFO, "down_file: %s", down_file);
            vpn.lua_debug(vpn.INFO, "%s", kill_cmd);
            --vpn.lua_debug(vpn.INFO, "%s", rm_file_cmd);
            if (tool.file_exist(save_file) == true) then
                os.rename(save_file, down_file);
                vpn.lua_debug(vpn.INFO, SERVER_UPDOWN_CMD);
                os.execute(SERVER_UPDOWN_CMD);
            end
        end
    end

    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
end

local function is_the_configuration_changed(old_json, new_json)
    local ret = false
    local list = {"netmode","username","remotesubnet","enable","password"};

    for i, var in ipairs(list) do
        if (new_json[var] ~= nil and new_json[var] ~= old_json[var]) then
            vpn.lua_debug(vpn.INFO, "new_json: %s", new_json[var])
            --vpn.lua_debug(vpn.INFO, "old_json: %s", old_json[var])
            ret = true
        end
    end

    vpn.lua_debug(vpn.INFO, "The configuration is changed.");
    return ret;
end

local function vpn_user_delete_sd_config(file, del_json)
    local ret_json = {};
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end
    if (json.list == nil) then
        return;
    end
    for key, val in pairs(del_json.list) do
        local total = table.maxn(json.list);
        for i = 1, total, 1 do
            if (json.list[i].username == val.username and json.list[i].provider == val.provider) then
                table.remove(json.list, i);
                break;
            end
        end
    end
    tool.file_write(file, cjson.encode(json), "w+")
end

local function lua_string_split(str, split_char)
    local sub_str_tab = {}
    while (true) do
        local pos = string.find(str, split_char)
        if (not pos) then
            sub_str_tab[#sub_str_tab+1] = str
            break
        end
        local sub_str = string.sub(str, 1, pos - 1)
        sub_str_tab[#sub_str_tab + 1] = sub_str
        str = string.sub(str, pos + 1, #str)
    end
    return sub_str_tab
end

local function delete_username_and_password(fn_json)
    list = {"l2tpserver","pptpserver"}
    for i, var in ipairs(list) do
        local del_cfg = {}
        local match_cfg = nil
        local name = var:match("(%w+)server")
        local chap_file = table.concat({"/tmp/", name, "/chap-secrets"});
        local pap_file = table.concat({"/tmp/", name, "/pap-secrets"});
        local new_file = table.concat({chap_file, "_new"});
        local p_file = assert(io.open(pap_file, 'w+'));
        local n_file = assert(io.open(new_file, 'w+'));
        local msg = ""
        for key, val in pairs(fn_json.list) do
            local provider = val.provider
            --Statistics of deleted account and password
            if (provider == "all" or provider == var) then
                if (provider == "all") then
                    provider = var
                end
                local user_name_input = table.concat({ "'", val.username, "'"});
                local provider_input = table.concat({ "'", provider, "'"});
                local password_input = table.concat({ "'", val.password, "'"});
                match_cfg = user_name_input.."\t"..provider_input.."\t"..password_input.."\t".."*"
                table.insert(del_cfg, match_cfg)
            end
        end
        if (match_cfg ~= nil and next(del_cfg) ~= nil) then
            if (tool.file_exist(chap_file) == true) then
                local c_file = io.open(chap_file, "r+")
                if io.type(c_file) ~= nil then
                    local a = c_file:read("*all")
                    info = lua_string_split(a, "\n") 
                    c_file:close()
                end
                --The deleted content is compared with the original content and removed
                if (next(info) == nil) then
                    vpn.lua_debug(vpn.ERROR, "chap-secrets is nill")
                    return 
                end
                for i=#info,1,-1 do
                    if (info[i] ~= nil) then
                        for j=#del_cfg,1,-1 do
                            if (del_cfg[j] ~= nil) then
                                if (info[i] == del_cfg[j]) then
                                    table.remove(info, i)
                                    table.remove(del_cfg, j)
                                    break
                                end
                           end
                        end
                    end
                end
                for i,v in ipairs(info) do
                    if (v ~= "") then
                        local result=tool.split(v, "\t");
                        local user_name_in_file = result[1]
                        local provider_in_file = result[2]
                        if (provider_in_file == "'l2tpserver'" or provider_in_file == "'pptpserver'") then
                            msg = msg..v.."\n"
                        end
                    end
                end
                n_file:write(msg);
                p_file:write(msg);
                io.close(n_file);
                io.close(p_file);
                os.rename(new_file, chap_file);
            end
        end
    end
end

local function add_vpn_account_group(fn_json)
    local addr_root_grp = {}
    local addr_second_grp = {}
    local addr_first_grp = {}
    addr_root_grp["groups"] = {}
    addr_first_grp["id"] = "4"
    addr_first_grp["child"] = {}
    addr_second_grp["name"] = fn_json["username"]
    addr_second_grp["role"] = "group"
    addr_second_grp["auto"] = "false"
    addr_second_grp["type"] = "vpn"
    if (fn_json["provider"] == "l2tpserver") then
        addr_second_grp["owner_type"] = "l2tp"
    elseif (fn_json["provider"] == "pptpserver") then
        addr_second_grp["owner_type"] = "pptp"
    elseif (fn_json["provider"] == "openvpnserver") then
        addr_second_grp["owner_type"] = "openvpn"
    end
    table.insert(addr_first_grp["child"], addr_second_grp)
    table.insert(addr_root_grp["groups"], addr_first_grp)
    local config_tab = cjson.encode(addr_root_grp)
    if (config_tab == nil) then
        vpn.lua_debug(vpn.ERROR, "config_tab is nil");
        return -1
    end
    local cmd = "dev_config add -m user_group '"..config_tab.."'"
    vpn.lua_debug(vpn.INFO, "cmd: %s", cmd)
    local t1 = io.popen(cmd)
    local param = t1:read("*a")
    t1:close()
    vpn.lua_debug(vpn.INFO, "param = %s", param)
end

local function del_vpn_account_group(fn_json)
    local del_id_table = {}
    del_id_table["name"] = fn_json["username"]
    if (fn_json["provider"] == "l2tpserver") then
        del_id_table["type"] = "l2tp"
    elseif (fn_json["provider"] == "pptpserver") then
        del_id_table["type"] = "pptp"
    elseif (fn_json["provider"] == "openvpnserver") then
        del_id_table["type"] = "openvpn"
    end  
    local del_tab = cjson.encode(del_id_table)
    local del_cmd = "dev_config del -m user_group_vpn '"..del_tab.."' >/dev/null 2>&1 &"
    vpn.lua_debug(vpn.INFO, "del_cmd: %s", del_cmd)
    tool.exec("exec 1>/tmp/null 2>&1")
    tool.exec(del_cmd)
end

local function vpn_user_delete(fn_json)
    local list = {fn_json.provider}
    if (fn_json.provider == "all") then
        list = {"l2tpserver","pptpserver", "openvpnserver"}
    end
    for i, var in ipairs(list) do
        if var ~= "openvpnserver" then
            local data_json = fn_json;
            if (data_json ~= nil and next(data_json) ~= nil) then
                data_json.provider = var;
                local userdir = table.concat({DEBUG_LOG_DIR, data_json.provider, "_", data_json.username, "/"});
                stop_client_connect(data_json, userdir);
                delete_user_dir(data_json, userdir);
                if (support_vpn_account_fc ~= nil) then
                    del_vpn_account_group(data_json)
                end
            end
        else
            if (support_vpn_account_fc ~= nil) then
                fn_json.provider = var
                del_vpn_account_group(fn_json)
            end
        end
    end
end
--------------------------------dev_mode--------------------------------
function module_default_config_get()
    local default_config = '{}'
    return default_config
end

function module_update(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_update] input_data is unsafe")
        if (input_data ~= nil) then
            vpn.lua_debug(vpn.ERROR, "ERROR: [module_update] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    vpn.lua_debug(vpn.INFO, "###############################UPDATE##############################");

    --参数获取
    input_json = input_data_format(input_data);
    if (next(input_json) == nil) then
        return;
    end
    
    --bugid=1034804
    if string.match(input_json.username, "/") then
        vpn.lua_debug(vpn.ERROR, "username is unsafe")
        if (input_json.username ~= nil) then
            vpn.lua_debug(vpn.ERROR, "username %s", input_json.username)
        end
        return "{\"code\":\"-1\",\"msg\":\"username is unsafe!\"}"
    end

    --旧参数获取
    old_json = get_config_from_sd_config(conf_file, input_json.username, input_json.provider);
    vpn.lua_debug(vpn.INFO, "Old config: %s", cjson.encode(old_json));

    local provider = input_json.provider;
    local list = {}
    if (provider ~= "openvpnserver") then
        list = {provider}
    end
    if (provider == "all") then
        list = {"l2tpserver","pptpserver"}
    end

    for i, var in ipairs(list) do
        local data_json = input_json;
        data_json.provider = var;
        old_json.provider = var;
        vpn.lua_debug(vpn.INFO, "Data json: %s", cjson.encode(data_json));
        local userdir = table.concat({DEBUG_LOG_DIR, data_json.provider, "_", data_json.username, "/"});
        save_user_to_link_record_file(data_json);

        --执行
        if (data_json.enable == "off") then
            stop_client_connect(data_json, userdir);
            if (support_vpn_account_fc ~= nil) then
                del_vpn_account_group(input_json)
            end
        else
            if (support_vpn_account_fc ~= nil) then
                add_vpn_account_group(input_json)
            end
        end

        if (is_the_configuration_changed(old_json, data_json) == true) then
            stop_client_connect(data_json, userdir);
        end

        --保存配置
        save_to_user_dir(data_json, userdir);
    end

    input_json.provider = provider;
    save_config_to_sd_config(conf_file, input_json)
    if (provider == "all") then
        os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
        os.execute("ubus -t 3 send pptp_vpn_user_monitor");
    elseif (provider == "pptpserver") then
        os.execute("ubus -t 3 send pptp_vpn_user_monitor");
    elseif (provider == "l2tpserver") then
        os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
    else
        vpn.lua_debug(vpn.INFO, "provider: %s", provider);
    end
    if (provider == "all" or provider == "openvpnserver") then
        if (openvpn_exist == true) then
            openvpn.openvpn_user_update(input_json.username, input_json.password, input_json.enable)
            if (support_vpn_account_fc ~= nil) then
                input_json.provider = "openvpnserver"
                if (input_json.enable == "off") then
                    del_vpn_account_group(input_json)
                else
                    add_vpn_account_group(input_json)
                end
            end
        end
    end 
end

function module_add(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            vpn.lua_debug(vpn.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
 
    vpn.lua_debug(vpn.INFO, "################################ADD################################");
    --参数获取
    input_json = input_data_format(input_data);
    if (next(input_json) == nil) then
        return;
    end
    
    --bugid=1034804
    if string.match(input_json.username, "/") then
        vpn.lua_debug(vpn.ERROR, "username is unsafe")
        if (input_json.username ~= nil) then
            vpn.lua_debug(vpn.ERROR, "username %s", input_json.username)
        end
        return "{\"code\":\"-1\",\"msg\":\"username is unsafe!\"}"
    end

    --删除旧参数
    --get_config_from_sd_config(conf_file, input_json.username, input_json.provider);

    local provider = input_json.provider;
    local list = {}
    if (provider ~= "openvpnserver") then
        list = {provider}
    end
    if (provider == "all") then
        list = {"l2tpserver","pptpserver"}
    end

    for i, var in ipairs(list) do
        local data_json = input_json;
        data_json.provider = var;
        local userdir = table.concat({DEBUG_LOG_DIR, data_json.provider, "_", data_json.username, "/"});
        save_user_to_link_record_file(data_json);

        --执行
        if (data_json.enable == "off") then
            stop_client_connect(data_json, userdir);
        else
            if (support_vpn_account_fc ~= nil) then
                add_vpn_account_group(input_json)
            end
        end

        --保存配置
        save_to_user_dir(data_json, userdir);
    end

    input_json.provider = provider;
    if input_json["encType"] == nil or input_json["encType"] == 0 then
        --删除旧参数
        get_config_from_sd_config(conf_file, input_json.username, input_json.provider);
        save_config_to_sd_config(conf_file, input_json)
    end
    if (provider == "all") then
        os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
        os.execute("ubus -t 3 send pptp_vpn_user_monitor");
    elseif (provider == "pptpserver") then
        os.execute("ubus -t 3 send pptp_vpn_user_monitor");
    elseif (provider == "l2tpserver") then
        os.execute("ubus -t 3 send l2tp_vpn_user_monitor");
    else
        vpn.lua_debug(vpn.INFO, "provider: %s", provider);
    end

    if (provider == "all" or provider == "openvpnserver") then
        if (openvpn_exist == true) then
            openvpn.openvpn_user_add(input_json.username, input_json.password, input_json.enable)
            if (input_json.enable == "on" and support_vpn_account_fc ~= nil) then
                input_json.provider = "openvpnserver"
                add_vpn_account_group(input_json)
            end
        end
    end 
end

function module_del(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            vpn.lua_debug(vpn.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    vpn.lua_debug(vpn.INFO, "################################DEL################################");

    --参数获取
    if (input_data == nil or tool.json_check(input_data) == false) then
        vpn.lua_debug(vpn.ERROR, "Input data is not json mode.");
        return;
    end
    vpn.lua_debug(vpn.INFO, "input_data: %s", input_data);
    input_json = cjson.decode(input_data);
    if (next(input_json.list) == nil) then
        vpn.lua_debug(vpn.ERROR, "Username is empty.");
        return;
    end
    --bugid=1034804
    for key, val in pairs(input_json.list) do
        if string.match(val.username, "/") then
            vpn.lua_debug(vpn.ERROR, "username is unsafe")
            if (val.username ~= nil) then
                vpn.lua_debug(vpn.ERROR, "username %s", val.username)
            end
            return "{\"code\":\"-1\",\"msg\":\"username is unsafe!\"}"
        end
    end
    
    --遍历要删除的用户
    vpn_user_delete_sd_config(conf_file, input_json)
    if (openvpn_exist == true) then
        openvpn.openvpn_user_del(input_json)
    end
    delete_user_to_link_record_file(input_json)
    delete_username_and_password(input_json)
    for key, val in pairs(input_json.list) do
        local role = val.provider;
        if (role ~= "openvpnserver") then
            vpn_user_delete(val)
        else
            if (support_vpn_account_fc ~= nil) then
                del_vpn_account_group(val)
            end
        end
    end
end

function module_set(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_set] input_data is unsafe")
        if (input_data ~= nil) then
            vpn.lua_debug(vpn.ERROR, "ERROR: [module_set] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
 
    vpn.lua_debug(vpn.INFO, "################################SET################################");
end

function module_apply()
    vpn.lua_debug(vpn.INFO, "module_apply");
    vpn.lua_debug(vpn.INFO, "################################END################################");
end
