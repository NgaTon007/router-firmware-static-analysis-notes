#! /usr/bin/lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("rg_syslog", package.seeall); -- 第一个参数是本模块的文件名

local libdbg = require("utils.debug");
local dkjson = require("dkjson");

-- 调试模块初始化
libdbg.debug_init("/tmp/sd_syslog/", "sd_syslog.lua.log", 50, libdbg.DEBUG, libdbg.OPEN);

--安全校验
function param_safety_check(param)
    if (param == nil) then
        return true
    end

    if (string.match(param, "\\n") ~= nil) then
        return false
    end

    if (string.match(param, "([\n\r'`&$;>\<])") == nil) then
        return true
    else
        return false
    end
end

--[[
    module_ret() -- 模块set|get|del|update的返回值
    @code：错误码，参数类型[string]
    @msg:返回给web的错误信息，支持可变长参数，参数类型[string]，框架最后会打印本字段。
    @return：json字符串
--]]
function module_ret(code, msg, ...)
    result = {};
    if (code == "00000000") then
        result["rcode"] = code;
    end
    result["rmsg"] = string.format(msg, ...);
    res = result;

    -- 错误返回
    if (code ~= "00000000") then
        res = {
            err = result;
            code = "1";
        };
    end

    local json_str = dkjson.encode(res);
    libdbg.lua_debug(libdbg.INFO, "return json_str:%s\n", json_str);

    return json_str;
end

--@sd_syslog_set
--@2024Q1配置框架安全性整改，携带不安全字符的dev_config命令不会在/etc/sd_config/single/目录下生成配置文件
--@需要接口有返回值，框架才会创建配置文件
function module_set(param)
    libdbg.lua_debug(libdbg.INFO, "********************Enter sd_syslog_set()********************");
    -- 1、参数检查
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "sd_syslog_set parameter is nil");
        return module_ret("0012", "sd_syslog set parameter is nil");
    end
    if (param_safety_check(param) == false) then
        libdbg.lua_debug(libdbg.ERROR, "sd_syslog_set parameter is unsafe");
        return module_ret("0024", "sd_syslog set parameter is unsafe");
    else
        libdbg.lua_debug(libdbg.INFO, "sd_syslog_set parameter is safe");
    end
    -- 2、解析参数
    local tab = require("dkjson").decode(param);
    -- 2.1、解析参数：enable
    if (tab["enable"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:enable");
    elseif (type(tab["enable"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter enable is invalid, require string");
        return module_ret("0014", "parameter enable is invalid, require string");
    end
    -- 2.2、解析参数：keyword
    if (tab["keyword"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:keyword");
    elseif (type(tab["keyword"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter keyword is invalid, require string");
        return module_ret("0014", "parameter keyword is invalid, require string");
    end
    -- 2.3、解析参数：udp
    if (tab["udp"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:udp");
    elseif (type(tab["udp"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter udp is invalid, require string");
        return module_ret("0014", "parameter udp is invalid, require string");
    end
    -- 2.4、解析参数：debug_level
    if (tab["debug_level"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:debug_level");
    elseif (type(tab["debug_level"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter debug_level is invalid, require string");
        return module_ret("0014", "parameter debug_level is invalid, require string");
    end
    -- 2.5、解析参数：url
    if (tab["url"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:url");
    elseif (type(tab["url"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter url is invalid, require string");
        return module_ret("0014", "parameter url is invalid, require string");
    end
    -- 2.6、解析参数：pkgnum
    if (tab["pkgnum"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "sd_syslog_set require parameter:pkgnum");
    elseif (type(tab["pkgnum"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "parameter pkgnum is invalid, require string");
        return module_ret("0014", "parameter pkgnum is invalid, require string");
    end
    -- 3、同步uci配置
    local uci = require("luci.model.uci").cursor();
    uci:foreach("sd_syslog", "sd_syslog",
    function(s)
        if (tab["enable"] ~= nil and tab["enable"] ~= s["enable"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.enable=%s", tab["enable"]);
            uci:set("sd_syslog", s[".name"], "enable", tab["enable"]);
        end
        if (tab["keyword"] ~= nil and tab["keyword"] ~= s["keyword"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.keyword=%s", tab["keyword"]);
            uci:set("sd_syslog", s[".name"], "keyword", tab["keyword"]);
        end
        if (tab["udp"] ~= nil and tab["udp"] ~= s["udp"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.udp=%s", tab["udp"]);
            uci:set("sd_syslog", s[".name"], "udp", tab["udp"]);
        end
        if (tab["debug_level"] ~= nil and tab["debug_level"] ~= s["debug_level"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.debug_level=%s", tab["debug_level"]);
            uci:set("sd_syslog", s[".name"], "debug_level", tab["debug_level"]);
        end
        if (tab["url"] ~= nil and tab["url"] ~= s["url"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.url=%s", tab["url"]);
            uci:set("sd_syslog", s[".name"], "url", tab["url"]);
        end
        if (tab["pkgnum"] ~= nil and tab["pkgnum"] ~= s["pkgnum"]) then
            libdbg.lua_debug(libdbg.DEBUG, "uci set sd_syslog.main.pkgnum=%s", tab["pkgnum"]);
            uci:set("sd_syslog", s[".name"], "pkgnum", tab["pkgnum"]);
        end
    end);
    -- 4、保存配uci配置
    uci:commit("sd_syslog");
    --清除uci缓存空间，清除不设置的参数（放弃对配置所做的任何尚未提交的更改）
    uci:revert("sd_syslog");
    -- 5、返回
    return module_ret("00000000", "sd_syslog_set parameter success");
end