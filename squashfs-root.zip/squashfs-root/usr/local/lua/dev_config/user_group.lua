#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("user_group", package.seeall)

local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local console = require "console"
local DEBUG_DIR_LOGFILE = "/tmp/user_group/web/"
local LOCK_FILE = "/tmp/user_group/web/user_group.lock"
local USER_GROUP_JSON_FILE = "/etc/sd_config/single/user_group.json"
local USER_MRG_CMD_ELF = "/usr/sbin/user_mgr_cmd.elf"
local SD_CONFIG_FILE = table.concat({DEBUG_DIR_LOGFILE, "user_group.json"});
local table_input_err = {rcode = "05640001", rmsg = "param error"}
local lib_user = require "user_mgr.user_mgr_common"

if (tool.file_exist(DEBUG_DIR_LOGFILE) == false) then
    local path = "mkdir -p " .. DEBUG_DIR_LOGFILE .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_DIR_LOGFILE, "user_group.log", 2000, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function support_uuid_flag()
    local t = io.popen("cat /tmp/sd_device/sd_device.json | jq .gateway.userMgrSupportUuid | sed 's/\"//g'")
    local str = t:read("*all")
    t:close()
    if (str == "1\n") then
        module_debug.lua_debug(module_debug.INFO, ".gateway.userMgrSupportUuid is %s ", str);
        return true
    else
        return false
    end
end

local function multi_level_flag(param)
    for k,v in pairs(param) do
        if (v["child"] == nil) then
            return false
        end
        for key,value in pairs(v["child"]) do
            if (value["child"] ~= nil) then
                return true
            else
                return false
            end
        end
    end
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local temp_path = path .. ".tmp"

    local f = io.open(temp_path, mode)
    if (f) then
        if f:write(content) ~= nil then
            io.close(f)

            -- 原子重命名：将临时文件移动到目标路径
            local success, err = os.rename(temp_path, path)
            if success then
                return 0
            else
                module_debug.lua_debug(module_debug.ERROR, "failed to rename [%s] to [%s]: %s", temp_path, path, err)
                os.remove(temp_path)
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "write failed for [%s]", temp_path)
            io.close(f)
            os.remove(temp_path)
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "open failed for [%s]", temp_path)
        return -1
    end
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = cjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "file :[%s]", path)
            res = file_write(path, config_str)
            if (res == -1) then
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end

    return 0
end

local function ip_to_num(ip)
    local o1, o2, o3, o4 = ip:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if not o1 then return nil end
    o1, o2, o3, o4 = tonumber(o1), tonumber(o2), tonumber(o3), tonumber(o4)
    if o1 > 255 or o2 > 255 or o3 > 255 or o4 > 255 then return nil end
    return o1 * 16777216 + o2 * 65536 + o3 * 256 + o4
end

local function validate_ip_range(ip_range)
    local tab = tool.split(ip_range, "-")
    if (tab[2] == nil) then
        tab[2] = tab[1]
    end
    local ip_s_num = ip_to_num(tab[1])
    local ip_e_num = ip_to_num(tab[2])
    if not ip_s_num then
        module_debug.lua_debug(module_debug.ERROR, "invalid ip_s format: %s", tab[1])
        return nil
    end
    if not ip_e_num then
        module_debug.lua_debug(module_debug.ERROR, "invalid ip_e format: %s", tab[2])
        return nil
    end
    if ip_s_num > ip_e_num then
        module_debug.lua_debug(module_debug.ERROR, "ip_s(%s) > ip_e(%s), invalid range", tab[1], tab[2])
        return nil
    end
    return tab
end

--添加用户组
function user_group_config(section_name,msg,father_id)
    local exist_flag = 0
    local exist_id = 0
    local owner_type_list = {}
    --避免重复添加相同用户组配置
    uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local grp_name = uci:get("user_mgr", namecode, "name")
        local grp_type = uci:get("user_mgr", namecode, "type")
        if father_id ~= nil then
            local grp_parent = uci:get("user_mgr", namecode, "parent")
            if (grp_name == msg["name"] and grp_type == msg["type"] and grp_parent == father_id) then		    
                exist_flag = 1
                exist_id = namecode
            end
        else
            if (grp_name == msg["name"] and grp_type == msg["type"]) then		    
                exist_flag = 1
                exist_id = namecode
            end
        end
    end
    )
    if (exist_flag == 1) then
        module_debug.lua_debug(module_debug.INFO, "[module_add]The added grp configuration already exists");
        uci:set("user_mgr", "main", "static_cap", tonumber(section_name))
        uci:commit("user_mgr")
        if (msg["owner_type"] ~= nil) then
            local ori_owner_type = uci:get_list("user_mgr", exist_id, "owner_type")
            if (ori_owner_type[2] == nil) then
                owner_type_list[1] = ori_owner_type[1]
                owner_type_list[2] = msg["owner_type"]
            elseif (ori_owner_type[3] == nil) then
                owner_type_list[1] = ori_owner_type[1]
                owner_type_list[2] = ori_owner_type[2]
                owner_type_list[3] = msg["owner_type"]
            else
                module_debug.lua_debug(module_debug.INFO, "[module_add]The added type has exceeded the upper limit");
                return -1
            end
            uci:set("user_mgr", exist_id, "owner_type", owner_type_list)
            uci:commit("user_mgr")
            return 1
        end
        return -1
    end
    uci:set("user_mgr", section_name, "user_grp");
    uci:set("user_mgr", section_name, "name", msg["name"])
    uci:set("user_mgr", section_name, "auto", msg["auto"])
    uci:set("user_mgr", section_name, "type", msg["type"])
    if (msg["uuid"] ~= nil) then
        uci:set("user_mgr", section_name, "uuid", msg["uuid"])
    end
    if (msg["maxUsers"] ~= nil) then
        uci:set("user_mgr", section_name, "maxUsers", msg["maxUsers"])
    end
    if (msg["owner_type"] ~= nil) then
        owner_type_list[1] = msg["owner_type"]
        uci:set("user_mgr", section_name, "owner_type", owner_type_list)
    end
    if (father_id ~= nil) then
        uci:set("user_mgr", section_name, "parent", father_id)
    end
    uci:commit("user_mgr")  
    local t_bind = {}
    t_bind["name"] = msg["name"]
    t_bind["id"] = section_name
    t_bind["role"] = msg["role"]
    t_bind["auto"] = msg["auto"]
    t_bind["type"] = msg["type"]
    if (msg["uuid"] ~= nil) then
        t_bind["uuid"] = msg["uuid"]
    end
    if (msg["maxUsers"] ~= nil) then
        t_bind["maxUsers"] = msg["maxUsers"]
    end
    t_bind["child"] = {}
    add_id_cmd = USER_MRG_CMD_ELF .. " -R " .. section_name .. " >/dev/null 2>&1"
    module_debug.lua_debug(module_debug.INFO, "[module_add]add_id_cmd = %s", add_id_cmd);
    os.execute(add_id_cmd)
    return t_bind
end

--添加用户
function user_config(section_name,msg,father_id)
    t_bind = {}
    local exist_flag = 0
    --避免重复添加相同用户配置
    uci:foreach("user_mgr", "user", function(s)
        local namecode = s[".name"]
        local user_name = uci:get("user_mgr", namecode, "name")
        local user_type = uci:get("user_mgr", namecode, "type")
        if father_id ~= nil then
            local user_parent = uci:get("user_mgr", namecode, "parent")
            if (user_name == msg["name"] and user_type == msg["type"] and user_parent == father_id) then		    
                exist_flag = 1
            end
        else
            if (user_name == msg["name"] and user_type == msg["type"]) then		    
                exist_flag = 1
            end
        end
    end
    )
    if (exist_flag == 1) then
        module_debug.lua_debug(module_debug.INFO, "[module_add]The added user configuration already exists");
        uci:set("user_mgr", "main", "static_cap", tonumber(section_name))
        uci:commit("user_mgr")
        return -1
    end
    uci:set("user_mgr", section_name, "user")
    uci:set("user_mgr", section_name, "name", msg["name"])
    uci:set("user_mgr", section_name, "type", msg["type"])
    uci:set("user_mgr", section_name, "auto", msg["auto"])
    if support_uuid_flag() and msg["uuid"] ~= nil then
        uci:set("user_mgr", section_name, "uuid", msg["uuid"])
        t_bind["uuid"] = msg["uuid"]
    end
    t_bind["name"] = msg["name"]
    t_bind["id"] = section_name
    t_bind["role"] = msg["role"]
    t_bind["auto"] = msg["auto"]
    t_bind["type"] = msg["type"]
    if (father_id ~= nil) then
        uci:set("user_mgr", section_name, "parent", father_id)
    end
    if (msg["ip_range"] ~= nil and msg["ip_range"] ~= "") then
        local tab = validate_ip_range(msg["ip_range"])
        if not tab then
            module_debug.lua_debug(module_debug.ERROR, "[user_config] invalid ip_range: %s", msg["ip_range"])
            return -1
        end
        uci:set("user_mgr", section_name, "ip_s", tab[1])
        uci:set("user_mgr", section_name, "ip_e", tab[2])
        t_bind["ip_s"] = tab[1]
        t_bind["ip_e"] = tab[2]
    end
    if (msg["mac"] ~= nil and msg["mac"] ~= "") then
        uci:set("user_mgr", section_name, "mac", msg["mac"])
        t_bind["mac"] = msg["mac"]
    end
    uci:commit("user_mgr")
    return t_bind
end

--修改用户IP/MAC
local function user_modify_config(section_name, msg, child)
    if (msg["ip_range"] ~= nil and msg["ip_range"] ~= "") then
        local ip_tab = validate_ip_range(msg["ip_range"])
        if not ip_tab then
            module_debug.lua_debug(module_debug.ERROR, "[user_modify_config] invalid ip_range: %s", msg["ip_range"])
            return -1
        end
        child["ip_s"] = ip_tab[1]
        child["ip_e"] = ip_tab[2]
        uci:set("user_mgr", section_name, "ip_s", ip_tab[1])
        uci:set("user_mgr", section_name, "ip_e", ip_tab[2])
    else
        uci:delete("user_mgr", section_name, "ip_s")
        uci:delete("user_mgr", section_name, "ip_e")
        child["ip_s"] = nil
        child["ip_e"] = nil
    end
    if (msg["mac"] ~= nil and msg["mac"] ~= "") then
        child["mac"] = msg["mac"]
        uci:set("user_mgr", section_name, "mac", msg["mac"])
    else
        uci:delete("user_mgr", section_name, "mac")
        child["mac"] = nil
    end
    
    uci:commit("user_mgr")
end

local function user_generate_id()
    local id_tables = {}
    local num = nil
    local id = tonumber(uci:get("user_mgr", "main", "static_cap"))
    if (id > 9999) then
        module_debug.lua_debug(module_debug.INFO, "The automatic ID assigned has exceeded 10000. Start manual allocation")
        uci:foreach("user_mgr", "user", function(s)
            table.insert(id_tables, tonumber(s[".name"]))
        end
        ) 
        uci:foreach("user_mgr", "user_grp", function(s)
            table.insert(id_tables, tonumber(s[".name"]))
        end
        )

        for i = 100,10000,1 do
            for k,v in pairs(id_tables) do
                if (i == id_tables[k]) then
                    break;
                end
                num = k
            end
            if (num == table.maxn(id_tables)) then
                id = i
                break
            end
        end
        if (id == 10000) then
            module_debug.lua_debug(module_debug.INFO, "Up to 10000 ID assignments are supported")
            return nil
        end
    else
        uci:set("user_mgr", "main", "static_cap", tonumber(id+1))
    end
    local id_str = tostring(id)
    if (id_str == nil) then
        module_debug.lua_debug(module_debug.ERROR, "user_generate_id:id is nil")
        return nil
    end
    
    return id_str
end

--增加
function add_config_bind(bind, config_tab)
    local sectionname = nil
    local t_bind = {}
    local first_name
    local second_name
    local third_name
    local ip_tab
    
    for k,v in pairs(bind["child"]) do
        for label,msg_child in pairs(config_tab["groups"]) do
            flag_exsit = 0
            if (bind["id"] == msg_child["id"]) then
                if (v["type"] ~= msg_child["type"]) then
                    module_debug.lua_debug(module_debug.ERROR, "[module_add]: %s[type] is not the same %s[type]",v["type"], msg_child["type"])
                    return -1
                end
                flag_exsit = 1
                if (v["role"] == "group") then  --第一层用户组
                    module_debug.lua_debug(module_debug.INFO, "[module_add]add first group")
                    sectionname = user_generate_id()
                    if (sectionname == nil) then
                        module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                        return -1
                    end
                    module_debug.lua_debug(module_debug.INFO, "[module_add]set sectionname = %s", sectionname)
                    -- 为什么这里的parent_id为nil 
                    t_bind = user_group_config(sectionname,v,bind["id"])
                    if (t_bind == -1) then
                        return -1
                    elseif (t_bind == 1) then
                        return 1
                    end
                    if (msg_child["child"] == nil) then
                        msg_child["child"] = {}
                    end
                    table.insert(msg_child["child"], t_bind)
                    break
                else    --第一层用户名
                    first_name = 0
                    for i,first_child in pairs(msg_child["child"]) do --修改用户IP/MAC
                        if (first_child["name"] == v["name"]) then
                            module_debug.lua_debug(module_debug.INFO, "[module_add]update first user ip/mac")
                            sectionname = first_child["id"]
                            if (sectionname == nil) then
                                module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                return -1
                            end
                            user_modify_config(sectionname, v, first_child)
                            first_name = 1
                            break
                        end
                    end
                    if (first_name == 0) then  --添加用户
                        module_debug.lua_debug(module_debug.INFO, "[module_add]add first user")
                        sectionname = user_generate_id()
                        if (sectionname == nil) then
                            module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                            return -1
                        end
                        module_debug.lua_debug(module_debug.INFO, "[module_add]set sectionname = %s", sectionname)
                        t_bind = user_config(sectionname,v,bind["id"])
                        if (t_bind == -1) then
                            return -1
                        end
                        if (msg_child["child"] == nil) then
                            msg_child["child"] = {}
                        end
                        table.insert(msg_child["child"], t_bind)
                    end
                    add_id_cmd = USER_MRG_CMD_ELF .. " -R " .. sectionname .. " >/dev/null 2>&1"
                    module_debug.lua_debug(module_debug.INFO, "[module_add]add_id_cmd = %s", add_id_cmd);
                    os.execute(add_id_cmd); 
                    break
                end
            end
        end
        if (flag_exsit == 0) then
            flag_exsit = 1
            second_exsit = 0
            for label,msg_child in pairs(config_tab["groups"]) do
                exit_second_for = 0
                if (msg_child["child"] == nil) then
                    module_debug.lua_debug(module_debug.ERROR, "ERROR [module_add]:child is nil")
                    return -1
                end
                for m,n in pairs(msg_child["child"]) do
                    if (bind["id"] == n["id"]) then
                        if (v["type"] ~= n["type"] ) then
                            module_debug.lua_debug(module_debug.ERROR, "[module_add]: %s[type] is not the same %s[type]",v["type"], n["type"])
                            return -1
                        end
                        second_exsit = 1
                        if (v["role"] == "group") then ---二层用户组
                            module_debug.lua_debug(module_debug.INFO, "[module_add]add second group")
                            sectionname = user_generate_id()
                            if (sectionname == nil) then
                                module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                return -1
                            end
                            module_debug.lua_debug(module_debug.INFO, "[module_add]set sectionname = %s", sectionname)
                            t_bind = user_group_config(sectionname,v,bind["id"])
                            if (t_bind == -1) then
                                return -1
                            elseif (t_bind == 1) then
                                return 1
                            end
                            table.insert(n["child"], t_bind)
                            exit_second_for = 1
                            break
                        else  ---二层用户名
                            second_name = 0
                            for i,second_child in pairs(n["child"]) do --修改用户ip/mac
                                if (second_child["name"] == v["name"]) then
                                    module_debug.lua_debug(module_debug.INFO, "[module_add]update second user ip/mac")
                                    sectionname = second_child["id"]
                                    if (sectionname == nil) then
                                        module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                        return -1
                                    end
                                    user_modify_config(sectionname, v, second_child)
                                    second_name = 1
                                    break
                                end
                            end
                            if (second_name == 0) then  --添加用户
                                module_debug.lua_debug(module_debug.INFO, "[module_add]add second user")
                                sectionname = user_generate_id()
                                if (sectionname == nil) then
                                    module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                    return -1
                                end
                                module_debug.lua_debug(module_debug.INFO, "[module_add]set sectionname = %s", sectionname)
                                t_bind = user_config(sectionname,v,bind["id"])
                                if (t_bind == -1) then
                                    return -1
                                end
                                table.insert(n["child"], t_bind)
                            end
                            add_id_cmd = USER_MRG_CMD_ELF .. " -R " .. sectionname .. " >/dev/null 2>&1"
                            module_debug.lua_debug(module_debug.INFO, "[module_add]add_id_cmd = %s", add_id_cmd);
                            os.execute(add_id_cmd)
                            exit_second_for = 1                            
                            break
                        end
                    end
                end
                if (exit_second_for == 1) then
                    exit_second_for = 0
                    break
                end
            end
            if (second_exsit == 0) then
                second_exsit = 1
                for label,msg_child in pairs(config_tab["groups"]) do
                    first_table = 0
                    for m,n in pairs(msg_child["child"]) do
                        third_table = 0
                        a = true 
                        while a do
                            a = false
                            if (n["role"] == "user") then
                                break
                            end
                            if (n["role"] == "group" and n["child"] == nil) then
                                module_debug.lua_debug(module_debug.ERROR, "ERROR [module_add]:child is nil")
                                return -1
                            end
                            for x,y in pairs(n["child"]) do
                                if (bind["id"] == y["id"]) then --三层用户名
                                    if (v["type"] ~= y["type"] ) then
                                        module_debug.lua_debug(module_debug.ERROR, "[module_add]: %s[type] is not the same %s[type]",v["type"], y["type"])
                                        return -1
                                    end
                                    third_name = 0
                                    for i,third_child in pairs(y["child"]) do  --修改用户ip/mac
                                        if (third_child["name"] == v["name"]) then
                                            module_debug.lua_debug(module_debug.INFO, "INFO [module_add]update third user ip/mac")
                                            sectionname = third_child["id"]
                                            if (sectionname == nil) then
                                                module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                                return -1
                                            end
                                            user_modify_config(sectionname, v, third_child)
                                            third_name = 1
                                            break
                                        end
                                    end
                                    if (third_name == 0) then  --添加用户
                                        module_debug.lua_debug(module_debug.INFO, "INFO [module_add]add third user")
                                        sectionname = user_generate_id()
                                        if (sectionname == nil) then
                                            module_debug.lua_debug(module_debug.ERROR, "[module_add]:sectionname is nil")
                                            return -1
                                        end
                                        module_debug.lua_debug(module_debug.INFO, "[module_add]set sectionname = %s", sectionname)
                                        t_bind = user_config(sectionname,v,bind["id"])
                                        if (t_bind == -1) then
                                            return -1
                                        end
                                        table.insert(y["child"], t_bind)
                                    end
                                    add_id_cmd = USER_MRG_CMD_ELF .. " -R " .. sectionname .. " >/dev/null 2>&1"
                                    module_debug.lua_debug(module_debug.INFO, "[module_add]add_id_cmd = %s", add_id_cmd);
                                    os.execute(add_id_cmd);
                                    third_table = 1
                                    first_table = 1
                                    break
                                end
                            end
                        end
                        if (third_table == 1) then
                            third_table = 0
                            break
                        end
                    end
                    if (first_table == 1) then
                        first_table = 0
                        break
                    end
                end
            end
        end        
    end
    
    if (sectionname ~= nil) then
        return sectionname
    else
        return -1
    end
end

local function user_group_process(param_groups_idx, id, config_tab)
    if param_groups_idx == nil then
        module_debug.lua_debug(module_debug.INFO, "return %s", id)
        return tonumber(id)
    end
    -- 递归退出条件？
    if (param_groups_idx["role"] == nil) then
        if (param_groups_idx["child"] == nil) then
            return -1
        else
            local repacked_param = {} -- 单层下发的单位
            repacked_param["groups"] = {}
            local repacked_param_groups = {}
            table.insert(repacked_param["groups"], repacked_param_groups)
            repacked_param_groups["id"] = id
            repacked_param_groups["child"] = {}
            local repacked_param_child = {}
            table.insert(repacked_param_groups["child"], repacked_param_child)
            for k,v in pairs(param_groups_idx["child"]) do
                repacked_param_child["uuid"] = v["uuid"]
                repacked_param_child["role"] = v["role"]
                repacked_param_child["auto"] = v["auto"]
                repacked_param_child["type"] = v["type"]
                repacked_param_child["name"] = v["name"]
                if (v["role"] == "user") then
                    repacked_param_child["ip_range"] = v["ip_range"]
                    repacked_param_child["mac"] = v["mac"]
                end
                module_debug.lua_debug(module_debug.INFO, "%s \n", repacked_param_child["uuid"]);
                module_debug.lua_debug(module_debug.INFO, "%s \n", cjson.encode(repacked_param_child));
                module_debug.lua_debug(module_debug.INFO, "%s \n", cjson.encode(repacked_param));
                -- module_debug.lua_debug(module_debug.INFO, "%s \n", cjson.encode(config_tab));
                idx = add_config_bind(repacked_param["groups"][1], config_tab)
                if (idx == -1) then
                    module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
                    return -1
                elseif (idx == 1) then
                    module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] add the same vpn account is success")
                    return 1
                end
                module_debug.lua_debug(module_debug.INFO, "id %d", idx)
                for key,value in pairs(v["child"]) do
                    module_debug.lua_debug(module_debug.INFO, "value: %s", cjson.encode(value))
                    user_group_process(value, tostring(idx), config_tab)
                end
            end 
        end
    else
        -- {"id":"1","child":[{"role":"group","auto":"false","name":"t3","type":"static","uuid":"3"}
        local add_table = {}
        add_table["id"] = id
        add_table["child"] = {}
        local add_table_child = {}
        table.insert(add_table["child"], add_table_child)
        add_table_child["uuid"] = param_groups_idx["uuid"]
        add_table_child["role"] = param_groups_idx["role"]
        add_table_child["auto"] = param_groups_idx["auto"]
        add_table_child["type"] = param_groups_idx["type"]
        add_table_child["name"] = param_groups_idx["name"]
        if (param_groups_idx["role"] == "user") then
            add_table_child["ip_range"] = param_groups_idx["ip_range"]
            add_table_child["mac"] = param_groups_idx["mac"]
        end
        module_debug.lua_debug(module_debug.INFO, "%s \n", cjson.encode(add_table));
        idx = add_config_bind(add_table, config_tab)
        if (idx == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
            return -1
        elseif (idx == 1) then
            module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] add the same vpn account is success")
            return 1
        end
        module_debug.lua_debug(module_debug.INFO, "id %d", idx)
        if (param_groups_idx["child"] == nil) then
            user_group_process(nil, tostring(idx), config_tab)
        else
            for key,value in pairs(param_groups_idx["child"]) do
                module_debug.lua_debug(module_debug.INFO, "value: %s", cjson.encode(value))
                user_group_process(value, tostring(idx), config_tab)
            end
        end
    end
end

function del_uci_config(id)
    module_debug.lua_debug(module_debug.INFO, "sectionname %s", id)
    local del_section = {}
    uci:delete("user_mgr", id)
    uci:foreach("user_mgr", "user", function(s)
        local namecode = s[".name"]
        local parent_id = uci:get("user_mgr", namecode, "parent")   
        if (parent_id == id) then 
            module_debug.lua_debug(module_debug.INFO, "sectionname %s", namecode)       
            uci:delete("user_mgr", namecode)
        end     
    end
    )
    uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local parent_id = uci:get("user_mgr", namecode, "parent")   
        if (parent_id == id) then        
            -- uci:delete("user_mgr", namecode)
            -- 要根据这个namecode删除他的子节点
            -- uci 不支持递归？
            -- del_uci_config(namecode)
            table.insert(del_section, namecode) 
        end
    end
    )
    module_debug.lua_debug(module_debug.INFO, "end")
    return del_section
end

function get_del_id_by_uuid(uuid)
    local id = "0"
    local stop_flag = false
    uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local conf_uuid = uci:get("user_mgr", namecode, "uuid")
        module_debug.lua_debug(module_debug.INFO, "1111")   
        if (conf_uuid ~= nil and uuid == conf_uuid) then
            module_debug.lua_debug(module_debug.INFO, "222")
            id = namecode
            stop_flag = true
        end
        return not stop_flag   
    end
    )
    stop_flag = false
    uci:foreach("user_mgr", "user", function(s)
        local namecode = s[".name"]
        local conf_uuid = uci:get("user_mgr", namecode, "uuid") 
        if (conf_uuid ~= nil and uuid == conf_uuid) then
            module_debug.lua_debug(module_debug.INFO, "222")
            id = namecode
            stop_flag = true
        end
        return not stop_flag     
    end
    )
    return id
end

--删除
local function del_config_bind(id, uuid, config_tab)
    local count = 1
    while (lib_user.single_uci_writer_check() == false) do
        if count > 5 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
        tool.sleep(1)
        count = count + 1
    end
    if id ~= nil then
        module_debug.lua_debug(module_debug.INFO, "sectionname %s", id)
        ret = del_uci_config(id)
        for k,v in pairs(ret) do
            del_uci_config(v)
        end
    end

    if uuid ~= nil then
        module_debug.lua_debug(module_debug.INFO, "uuid %s", uuid)
        id = get_del_id_by_uuid(uuid)
        module_debug.lua_debug(module_debug.INFO, "sectionname %s", id)
        if (id == "0") then
            return -1
        end
        ret = del_uci_config(id)
        for k,v in pairs(ret) do
            del_uci_config(v)
        end
    end

    uci:commit("user_mgr")
    lib_user.remove_uci_lock_file()
    module_debug.lua_debug(module_debug.INFO, "id %s ", id)
    for k,v in pairs(config_tab["groups"]) do
        if (v["child"] ~= nil) then
            for x,y in pairs (v["child"]) do
                if (y["id"] == id) then
                    module_debug.lua_debug(module_debug.INFO, "-del-id:%s", y["id"])
                    table.remove(v["child"], x)
                    config_flag = 1
                    break
                else
                    if (y["child"] ~= nil) then
                        for m,n in pairs (y["child"]) do
                            if (n["id"] == id) then
                                module_debug.lua_debug(module_debug.INFO, "-del-id:%s", n["id"])
                                table.remove(y["child"], m)
                                config_flag = 1
                                first_flag = 1
                                break
                            else
                                if (n["child"] ~= nil) then
                                    for k,v in pairs (n["child"]) do
                                        if (v["id"] == id) then
                                            module_debug.lua_debug(module_debug.INFO, "-del-id:%s", v["id"])
                                            table.remove(n["child"], k)
                                            config_flag = 1
                                            first_flag = 1
                                            second_flag = 1
                                            break
                                        else
                                            if (v["child"] ~= nil) then
                                                for t,p in pairs (v["child"]) do
                                                    if (p["id"] == id) then
                                                        module_debug.lua_debug(module_debug.INFO, "-del-id:%s", p["id"])
                                                        table.remove(v["child"], t)
                                                        config_flag = 1
                                                        first_flag = 1
                                                        second_flag = 1
                                                        third_flag =1
                                                        break
                                                    end
                                                end
                                            end
                                        end
                                        if (third_flag == 1) then
                                            third_flag = 0
                                            break
                                        end 
                                    end
                                end
                            end
                            if (second_flag == 1) then
                                second_flag = 0
                                break
                            end
                        end
                    end
                end
                if (first_flag == 1) then
                    first_flag = 0
                    break
                end
            end
        end
        if (config_flag == 1) then
            config_flag = 0
            break
        end
    end
    del_id_cmd = USER_MRG_CMD_ELF .. " -D -d " .. id .. " >/dev/null 2>&1"
    module_debug.lua_debug(module_debug.INFO, "del_id_cmd = %s", del_id_cmd)
    os.execute(del_id_cmd)
    return 0
end

function user_group_add(param)
    module_debug.lua_debug(module_debug.INFO, "###############################ADD###############################");
    local id
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);

    param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param_tab is nil")
        return -1
    end

    local config_tab = tool.file_read(USER_GROUP_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return -1
    end
    local config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return -1
    end

    if (param_tab["groups"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param_tab.groups is nil")
        return -1
    end

    if (support_uuid_flag() and multi_level_flag(param_tab["groups"])) then
        -- 根据层数重新拼接参数，按顺序add，每次需要新增id？
        for k,v in pairs(param_tab["groups"]) do
            if (v["id"] == nil or v["child"] == nil) then
                return -1;
            end
            module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(v))
            id = user_group_process(v, v["id"], config_tab)
        end
        if (config_tab ~= nil) then
            ret = json_write_to_file(USER_GROUP_JSON_FILE, config_tab)
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] json_write_to_file is failed param is %s", param)
                return -1
            end
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] %s configraution success", param)
        return id
    else
        for k,v in pairs(param_tab["groups"]) do
            if (v["id"] == nil or v["child"] == nil) then
                return -1;
            end
            id = add_config_bind(v, config_tab)
            if (id == -1) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
                return -1
            elseif (id == 1) then
                module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] add the same vpn account is success")
                return 1
            end
        end
        if (config_tab ~= nil) then
            ret = json_write_to_file(USER_GROUP_JSON_FILE, config_tab)
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] json_write_to_file is failed param is %s", param)
                return -1
            end
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] %s configraution success", param)
        return id
    end
end

function user_group_del(param)
    module_debug.lua_debug(module_debug.INFO, "###############################DELETE###############################");
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return -1;
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return -1
    end

    config_tab = tool.file_read(USER_GROUP_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return -1
    end

    config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return -1
    end

    -- 支持根据uuid 或 id 删除
    if param_tab["id"] ~= nil then
        for k,v in pairs(param_tab["id"]) do
            if (v == nil or v == "") then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] id is null")
                if (support_uuid_flag() and param_tab["uuid"] ~= nil)then
                    break
                end
                return -1
            end
            ret = del_config_bind(v, nil, config_tab)
            if (ret ~= 0) then
                module_debug.lua_debug(module_debug.ERROR, "[module_del] del_config_bind is failed param")
                return -1
            end
        end
    end
    
    if (support_uuid_flag()) then
        if (param_tab["uuid"] ~= nil) then 
            for k,v in pairs(param_tab["uuid"]) do
                if (v == nil or v == "") then
                    module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] uuid is null")
                    return -1
                end
                ret = del_config_bind(nil, v, config_tab)
                if (ret ~= 0) then
                    module_debug.lua_debug(module_debug.ERROR, "[module_del] del_config_bind is failed param")
                    return -1
                end
            end
        end
    end

    if (config_tab ~= nil) then
        ret = json_write_to_file(USER_GROUP_JSON_FILE, config_tab)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] json_write_to_file is failed param is %s", param)
            return -1
        end
    end

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_del] %s configraution success", param)
    return 0
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end
 
------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    module_debug.lua_debug(module_debug.INFO, "module_default_config_get")
    local default_config = nil
    if (tool.file_exist("/tmp/sd_device/sd_device.json") == true) then
        local file_data = tool.file_read("/tmp/sd_device/sd_device.json");
        local sd_device_json = cjson.decode(file_data);
        if (sd_device_json["gateway"]["app_auth"] == "1") then
            default_config = '{"groups":[{"id": "1","name": "root","role": "group","type": "static","child":[]},{"id": "2","name": "auth_root","role": "group","type": "auth","child":[]},{"id": "3","name": "nt_root","role": "group","type": "nt","child":[]},{"id": "4","name": "vpn_root","role": "group","type": "vpn","child":[]}]}'
        else
            default_config = '{"groups":[{"id": "1","name": "root","role": "group","type": "static","child":[]}]}'
        end
    end
    return default_config
end

function module_del(param)
    debug_init();

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return check_result("0001")
    end
    
    if string.match(param, "\\n") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return check_result("0001")
    end
    
    if string.match(param, ">") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return check_result("0001")
    end

     --单实例检测
    if (single_instance_check(param, LOCK_FILE) == false) then
        return check_result("0000")
    end
    
    ret = user_group_del(param);
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] del_config_bind is failed param is %s", param)
        return check_result("0001")
    end
    
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        ret = user_group_del(file_data);
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] user_group_del is failed param is %s", file_data)
            return check_result("0001")
        end
    end
    os.remove(LOCK_FILE);
    module_debug.lua_debug(module_debug.INFO, "[module_del] is OK")
    module_debug.lua_debug(module_debug.INFO, "################################DEL END################################");
    return check_result("0000")
end

function module_add(param)
    local msg = {}
    local data = {}
    local id = {}
    local id_mes
    debug_init()
    
    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param %s", param)
        end
        return check_result("0001")
    end
    
    if string.match(param, "\\n") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param %s", param)
        end
        return check_result("0001")
    end
    
    if string.match(param, ">") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param %s", param)
        end
        return check_result("0001")
    end
    
    --单实例检测
    if (single_instance_check(param, LOCK_FILE) == false) then
        return check_result("0000")
    end
    
    local count = 1
    while (lib_user.single_uci_writer_check() == false) do
        if count > 5 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
            return -1
        end
        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
        tool.sleep(1)
        count = count + 1
    end
    id_mes = user_group_add(param);
    if (id_mes == -1) then
        os.remove(LOCK_FILE)
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
        lib_user.remove_uci_lock_file()
        return check_result("0001")
    elseif (id_mes == 1) then
        os.remove(LOCK_FILE)
        lib_user.remove_uci_lock_file()
        return check_result("0000")
    end
    
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        id_mes = user_group_add(file_data);
        if (id_mes == -1) then
            os.remove(LOCK_FILE)
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", file_data)
            lib_user.remove_uci_lock_file()
            return check_result("0001")
        elseif (id_mes == 1) then
            os.remove(LOCK_FILE)
            lib_user.remove_uci_lock_file()
            return check_result("0000")
        end
    end
    lib_user.remove_uci_lock_file()
    msg["code"] = 0
    msg["id"] = "null"
    msg["error"] = "null"
    msg["rcode"] = "00000000"
    msg["data"] = {}
    data["msg"] = "success"
    data["data"] = {}
    id ["id"] = id_mes
    table.insert(msg["data"],data)
    table.insert(data["data"],id)
    msg_tab = cjson.encode(msg)
    module_debug.lua_debug(module_debug.INFO, "[module_add] msg_tab %s", msg_tab)
    module_debug.lua_debug(module_debug.INFO, "###############################ADD END###############################");
    os.remove(LOCK_FILE)
    return msg_tab
end

function module_apply()
    module_debug.lua_debug(module_debug.INFO, "module_apply");
end

function module_set(param)
    debug_init()
    
    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param %s", param)
        end
        return check_result("0001")
    end
end