#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
package.path = "/usr/lib/lua/ippool/?.lua;" .. package.path;
module("pppoeserver_user", package.seeall);
cjson = require "dkjson"
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
require "public_module"
require("uci")
local reference = require "ippool_reference"

local modul = "pppoe-server"
local module_name = "pppoeserver_user"
local secrets = "/etc/ppp/chap-secrets"
local pap_secrets = "/etc/ppp/pap-secrets"
local conf_file = "/etc/config/pppoeserver_user"
local sd_cfg = "/etc/sd_config/single/pppoeserver_user.json"
local flowctrl = "/tmp/pppoe-server/pppoeserver_status/flowctrl"
local def_cfg = "/etc/pppoe-server/default_pppoeserver_user.json"
local userinfo_path = "/tmp/pppoe-server/userinfo/pppoeserver_userinfo.json"
local ippool_param = '{"ippool_name": "pppoe_pool","module":"pppoe-server"}'
----------枚举初始化---------
function CreatEnumTable(tb, index)  
    local enumtb = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tb) do 
        enumtb[v] = enumindex + i 
    end 
    return enumtb
end 
----------lua通用错误码-----------------
local g_err_code = {"ERR_PARAM", "ERR_FILE_WRITE", "ERR_FILE_NOT_EXIST","ERR_UBUS_CONNECT"}
local g_err_code = CreatEnumTable(g_err_code, 200)
--return output(1, g_err_code["ERR_PARAM"], "rate_limit_set failed:param error")

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_user.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

function module_default_config_get()
    lib_debug.lua_debug(lib_debug.DEBUG, "module_default_config_get\n")
    local default_config = [[
        {
            "count":"0",
            "list":[]
        }
      ]]
    
    return default_config
    
end

function guid()
        local template ="xxxxxxxxxxxxxxxxxxxx"---xxxx-xxxx-xxxxxxxxxxxx"
        local d = io.open("/dev/urandom", "r"):read(4)
		local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)
		--os.time()  + d:byte(1) --+ (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 4294967296)
        math.randomseed(num)
        return string.upper(string.gsub(template, "x", function (c)
                                        local v = (c == "x") and math.random(0, 0xf) or math.random(8, 0xb)
                                                return string.format("%x", v)
                                        end
                        ))
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) 
    then
        return
    end
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

function file_write_a(conf_file, data)
    local file = io.open(conf_file,"a+")
    file:write(data)
    file:close()
end

--ret(uint)表示是否返回结果给web,0表示不返回，0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

function module_get()

end


function user_update(old_json, up_data, old_length) 
    local fp
    local user
    local str = ""
    --flag = 0  修改账户密码
    local flag = 0
    
    local num = static_route_match(old_json, up_data.old, old_length)       
    if (up_data.new.enable == "0" and old_json.list[num].enable == "0") then
        return num
    end
    if (up_data.new.enable == nil and old_json.list[num].enable == "0") then
        return num
    end
    
    --禁用流控
    if (up_data.new.flow_enable == "0" and old_json.list[num].flow_enable == "1") then
        user_flow_update(old_json, num, "down")
    end
    --启用流控
    if (up_data.new.flow_enable == "1" and old_json.list[num].flow_enable == "0") then
        user_flow_update(old_json, num, "up")
    end
    --流控策略变化
    if (up_data.new.flow_name ~= old_json.list[num].flow_name) then
        user_flow_update(old_json, num, "down")
        user_flow_update(old_json, num, "up")
    end
    
    --flag = 1  禁用该账户
    if (up_data.new.enable == "0" and old_json.list[num].enable == "1") then
        flag = 1
        pppd_userinfo_del(old_json, num)
    end
    --flag = 2  启用该账户
    if (up_data.new.enable == "1" and old_json.list[num].enable == "0") then
        flag = 2
    end
    
    if (up_data.new.passwd == old_json.list[num].passwd and up_data.new.enable == old_json.list[num].enable) then
        return num
    end
    
    --更新chap-secrets数据
    local new_passwd
    if (up_data.new.passwd == nil) then
        new_passwd = string.format([['%s' '%s' '%s' *]], old_json.list[num].name, modul, old_json.list[num].passwd)
    else
        new_passwd = string.format([['%s' '%s' '%s' *]], old_json.list[num].name, modul, up_data.new.passwd)
    end
    
    lib_debug.lua_debug(lib_debug.DEBUG, "flag:%d\n", flag)
    
    local old_name = string.format([['%s' '%s' '%s' *]], old_json.list[num].name, modul, old_json.list[num].passwd)
    local fp = io.open(secrets)
    for line in fp:lines() do
        if (line ~= old_name) then
            str = line.."\n"..str
        else
            if (flag == 0) then
                str = new_passwd.."\n"..str
                pppd_userinfo_del(old_json, num)
            end
        end
    end
    fp:close()
    
    if (flag == 2) then
        str = new_passwd.."\n"..str
    end
    
    file_write(secrets, str)
    
    return num
end

function uci_update(up_data, uuid)
    local uci_r = uci.cursor()

    --保存uci配置
    if (up_data.new.ippool_name ~= nil) then
        uci_r:set(module_name, uuid, "ippool_name", up_data.new.ippool_name)
    end
    if (up_data.new.passwd ~= nil) then
        uci_r:set(module_name, uuid, "passwd", up_data.new.passwd)
    end
    if (up_data.new.enable ~= nil) then
        uci_r:set(module_name, uuid, "enable", up_data.new.enable)
    end
    if (up_data.new.note ~= nil) then
        uci_r:set(module_name, uuid, "note", up_data.new.note)
    end
    if (up_data.new.dealline ~= nil) then
        uci_r:set(module_name, uuid, "dealline", up_data.new.dealline)
    end
    if (up_data.new.flow_enable ~= nil) then
        uci_r:set(module_name, uuid, "flow_enable", up_data.new.flow_enable)
    end
    if (up_data.new.flow_name ~= nil) then
        uci_r:set(module_name, uuid, "flow_name", up_data.new.flow_name)
    end
    
    uci_r:commit(module_name)
	uci_r:revert(module_name)
    
end

function json_update(old_json, up_data, old_length, num)
    local uuid = old_json.list[num].uuid
    
    if (up_data.new.passwd ~= nil) then
        old_json.list[num].passwd = up_data.new.passwd
    end
    
    -- 多地址池时，地址池改变需要修改iptables
    if (up_data.new.ippool_name ~= nil) then
        old_json.list[num].ippool_name = up_data.new.ippool_name
    end
    if (up_data.new.enable ~= nil) then
        old_json.list[num].enable = up_data.new.enable
    end
    if (up_data.new.note ~= nil) then
        old_json.list[num].note = up_data.new.note
    end
    if (up_data.new.dealline ~= nil) then
        old_json.list[num].dealline = up_data.new.dealline
    end
    if (up_data.new.flow_enable ~= nil) then
        old_json.list[num].flow_enable = up_data.new.flow_enable
    end
    if (up_data.new.flow_name ~= nil) then
        old_json.list[num].flow_name = up_data.new.flow_name
    end
    
    file_write(sd_cfg, cjson.encode(old_json))
    return uuid
end

function module_update(param)  
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update start\n")
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update:%s\n", param)
    
    local up_data = cjson.decode(param)
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    local old_length = table.maxn(old_json.list)
    local uuid
    local num
    
    num = user_update(old_json, up_data, old_length) 
    
    uuid = json_update(old_json, up_data, old_length, num)
    
    uci_update(up_data, uuid)
    os.execute("cp "..secrets.." "..pap_secrets)
    
    os.execute("ubus -t 3 send \"pppoe_server_flowctrl\" &")
    
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update end\n")

    return 
end

function pppoeserver_user_name_check(json, name)
    local num = 1
    local length = table.maxn(json["list"])     
    while ( num < length + 1 )
    do
		if (json["list"][num]["name"] == name) then
            return -1
        end
        num = num + 1
    end
    return 0
end

function user_add(data)
    if (data.enable == "1") then
        local fp = io.open(secrets, "a+")
        local str = string.format([['%s' '%s' '%s' *]], data.name, modul, data.passwd)
        fp:write(str, "\n")
        fp:close()
    end
end

function uci_add(data) 
    lib_debug.lua_debug(lib_debug.DEBUG, "uci_add\n")
    local file = io.open(conf_file, "r")
    if (file == nil) then
        os.execute("touch "..conf_file)
    else
        file:close()
    end
    local uci_r = uci.cursor()
    local name = guid()
    uci_r:set(module_name, name, module_name)
    uci_r:set(module_name, name, "name", data.name)
    uci_r:set(module_name, name, "enable", data.enable)
    uci_r:set(module_name, name, "passwd", data.passwd)
    uci_r:set(module_name, name, "flow_enable", data.flow_enable)
    uci_r:set(module_name, name, "flow_name", data.flow_name)
    uci_r:set(module_name, name, "dealline", data.dealline)
    uci_r:set(module_name, name, "note", data.note)
    uci_r:set(module_name, name, "ippool_name", data.ippool_name)
    data.uuid=name
    
    lib_debug.lua_debug(lib_debug.DEBUG, "module_name:%s name:%s data.name:%s\n", module_name, name, data.name)
    uci_r:commit(module_name)
	uci_r:revert(module_name)
end

function json_add(data) 
    lib_debug.lua_debug(lib_debug.DEBUG, "json_add\n")
    local file = io.open(sd_cfg, "r")
    if (file == nil) then
        os.execute("echo '{\"list\":[]}' > "..sd_cfg)
    else
        file:close()
    end
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)

    table.insert (old_json["list"],data)
    
    old_json.count = string.format([[%s]], table.maxn(old_json.list))
    file_write(sd_cfg, cjson.encode(old_json))
end

function module_add(param)
    local data = cjson.decode(param)
    
    lib_debug.lua_debug(lib_debug.DEBUG, "module_add start\n")
    lib_debug.lua_debug(lib_debug.DEBUG, "module_add:%s\n", param)
    if (data.name == nil or data.passwd == nil or data.enable == nil) then
        return output(1, g_err_code["ERR_PARAM"], "module_add failed:param error")
    end
    
    --检测  新创建的账号是否已存在
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    if (pppoeserver_user_name_check(old_json, data.name) ~= 0) then
        return output(1, g_err_code["ERR_PARAM"], "module_add failed:param error")
    end
    
    if (data.dealline == nil) then
        data.dealline = ""
    end
    if (data.note == nil) then
        data.note = ""
    end
    if (data.flow_enable == nil) then
        data.flow_enable = ""
    end
    if (data.flow_name == nil) then
        data.flow_name = ""
    end
    
    --保存数据到uci
    uci_add(data)
    
    --保存数据到json
    json_add(data)
    
    --保存数据到chap-secrets
    user_add(data)
    
    --更新地址池使用数据
    reference.ippool_reference_add(ippool_param)
    os.execute("cp "..secrets.." "..pap_secrets)
end

function user_del(old_json, num)
    local str = ""
    local fp = io.open(secrets)
    local write_flag
    local new_line
    local new_data

    
    for line in fp:lines() do
        write_flag = true
        new_line = string.gsub(line, "%s+", "")
        for key,value in pairs(num) do  
            repeat
            new_data = string.format([['%s''%s''%s'*]], old_json.list[value].name, modul, old_json.list[value].passwd)
            if (new_line == new_data) then
                pppd_userinfo_del(old_json, value)
                write_flag = false
                break
            end
            until true
        end
        if (write_flag == true) then
            str = line.."\n"..str
        end
    end
    fp:close()
    
    file_write(secrets, str)

end

function uci_del(uuid)
    lib_debug.lua_debug(lib_debug.DEBUG, "uci_add\n")
    local uci_r = uci.cursor()
    
    for key,value in pairs(uuid) do  
        uci_r:delete(module_name, value)
    end  
    
    uci_r:commit(module_name)
	uci_r:revert(module_name)
end

function json_del(old_json, del_length, num)
    local del_len = del_length
    
    while(del_len > 0)
    do
        table.remove(old_json.list,num[del_len])
        del_len = del_len - 1
    end
    
    old_json.count = string.format([[%s]], table.maxn(old_json.list))
    file_write(sd_cfg, cjson.encode(old_json))
end

--遍历json配置文件，查找删除项位置
function static_route_match(old_json, data, old_length)
    local num = 1
    local length = old_length   
    while ( num < length + 1 )
    do
		if ((old_json["list"][num]["name"] == data))
        then
            break
        end
        num = num + 1
    end
    return num
end

--kill pppd进程，删除userinfo数据
function pppd_userinfo_del(old_json, num)
    local userinfo_data = file_read(userinfo_path)
    if (userinfo_data == nil) 
    then
        return
    end
    local userinfo_json = cjson.decode(userinfo_data)
    local userinfo_length = table.maxn(userinfo_json.list)
    local userinfo_len = 1
    while ( userinfo_len < userinfo_length + 1 )
    do
        if ((userinfo_json["list"][userinfo_len]["peername"] == old_json.list[num].name))
        then
            break
        end
        userinfo_len = userinfo_len + 1
    end
    if (userinfo_len <= userinfo_length) then
        local cmd = string.format([[kill -9 %s]], userinfo_json.list[userinfo_len].pppd_pid)
        --将该ip从流控地址池中删除
            del_user_ip(userinfo_json.list[userinfo_len].peername, userinfo_json.list[userinfo_len].ipremote, old_json.list[num].flow_name, "down")
        os.execute(cmd)
    end
    table.remove(userinfo_json.list,userinfo_len)
    userinfo_json.count = string.format([[%s]], table.maxn(userinfo_json.list))
    file_write(userinfo_path, cjson.encode(userinfo_json))
end

--流控状态更新
function user_flow_update(old_json, num, status)
    lib_debug.lua_debug(lib_debug.DEBUG, "user_flow_update\n")
    
    local userinfo_data = file_read(userinfo_path)
    if (userinfo_data == nil) 
    then
        return
    end
    local userinfo_json = cjson.decode(userinfo_data)
    local userinfo_length = table.maxn(userinfo_json.list)
    local userinfo_len = 1
    while ( userinfo_len < userinfo_length + 1 )
    do
        if ((userinfo_json["list"][userinfo_len]["peername"] == old_json.list[num].name))
        then
            break
        end
        userinfo_len = userinfo_len + 1
    end
    if (userinfo_len <= userinfo_length) then
            del_user_ip(userinfo_json.list[userinfo_len].peername, userinfo_json.list[userinfo_len].ipremote, old_json.list[num].flow_name, status)
    end
end

function del_user_ip(name, ipremote, flow_name, status)
--写数据到临时文件，为后续流控设置做准备
    lib_debug.lua_debug(lib_debug.DEBUG, "del_user_ip name:%s ipremote:%s flow_name:%s status:%s\n", name, ipremote, flow_name, status)
    local elisten_json = {}
    elisten_json["name"] = name
    elisten_json["ipaddr"] = ipremote
    elisten_json["status"] = status
    elisten_json["flow_name"] = flow_name
    file_write_a(flowctrl, cjson.encode(elisten_json).."\n")
end

function module_del(param)
    lib_debug.lua_debug(lib_debug.DEBUG, "module_del start\n")
    lib_debug.lua_debug(lib_debug.DEBUG, "module_del:%s\n", param)
    
    local del_data = cjson.decode(param)
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    local old_length = table.maxn(old_json.list)
    local del_length = table.maxn(del_data.list)
    local uuid={}
    local num={}
    local num_len = 1
    
    while(del_length >= num_len)
    do
        num[num_len] = static_route_match(old_json, del_data.list[num_len].name, old_length) 
        uuid[num_len] = old_json.list[num[num_len]].uuid
        num_len = num_len + 1
    end
    num_len = num_len - 1
   
    table.sort(num)  
    
    --删除user数据
    user_del(old_json, num)
    
    --删除json数据
    json_del(old_json, del_length, num)
    
    --删除uci数据
    uci_del(uuid)
    
    --更新地址池使用数据
    reference.ippool_reference_del(ippool_param)
    os.execute("cp "..secrets.." "..pap_secrets)
    --执行elisten命令
    os.execute("ubus -t 3 send \"pppoe_server_flowctrl\" &")
end

function module_apply(param)

end



