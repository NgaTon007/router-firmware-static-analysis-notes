#!/usr/bin/env lua
-- Lua CJSON Parse For Parent
-- First edition by Enhua Chen
-- Second edition by wyf

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("dhcp_static", package.seeall);
json = require "dkjson"
cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"
uci = require("uci")
tool = require "dev.tools.common"
product = require("product")

config_file = "/etc/sd_config/single/dhcp_static.json"
config_file_backup = "/etc/dhcp_static/dhcp_static.json"
uci_flag = true
excld_addr_flag = false
excld_addr_arry = {}
web_node = product.get_product("capacity.web")

x = uci.cursor()
module_debug.debug_init("/tmp/dhcp/", "dhcp_static.log", 500, module_debug.DEBUG, "1")

local err_code = {
    ["SUCCESS"] = "03030000",
    ["ERR_STATIC_DHCP_ENTRY_ABNORMAL"] = "03030001",
    ["ERR_STATIC_DHCP_MAX_OVER"] = "03030002",
    ["ERR_STATIC_DHCP_IP_ILLEGAL"] = "03030003",
    ["ERR_STATIC_DHCP_MAC_ILLEGAL"] = "03030004",
    ["ERR_STATIC_DHCP_IP_CONFLICT"] = "03030005",
    ["ERR_STATIC_DHCP_DEPLOY_FAIL"] = "03030006"
}

--ret(uint)表示是否返回结果给web,0表示不返回，非0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg, param)
    response = {}
    response["code"] = ret
    response["rcode"] = code
    if (type(param) == "string") then
        response["rdata"] = param
    else
        response["rdata"] = ""
    end
    response["msg"] = msg
    return cjson_safe.encode(response);
end

--判断文件是否存在
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

local function file_copy(src, dst)
    local cmd = "cp " .. src .. " " .. dst .." > /dev/null 2>&1";
    module_debug.lua_debug(module_debug.INFO, "exe cmd [%s]", cmd)
    os.execute(cmd);
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the action success; otherwise return false.
local function file_write(path, content, mode)
    local dir = string.match(path, "^(.*[/\\])[^/\\]+%.[^/.]+$")
    if (tool.file_exist(dir) == false) then
        module_debug.lua_debug(module_debug.INFO, "the dir [%s] not exist, creat it", dir)
        local cmd = "mkdir -p " .. dir .. " > /dev/null 2>&1";
        module_debug.lua_debug(module_debug.INFO, "exe cmd [%s]", cmd)
        os.execute(cmd);
    end

    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)
        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the action success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

function guid()
        local template ="xxxxxxxxxxxxxxxxxxxx"---xxxx-xxxx-xxxxxxxxxxxx"
        local d = io.open("/dev/urandom", "r"):read(4)
        local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)
        --os.time()  + d:byte(1) --+ (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 4294967296)
        math.randomseed(num)
        return string.upper(string.gsub(template, "x", function (c)
                                        local v = (c == "x") and math.random(0, 0xf) or math.random(8, 0xb)
                                                return string.format("%x", v)
                                        end
                        ))
end

--增加（查询，往表尾增加规则）
local function add_config_bind(bind, config_tab)
    local t_bind = {}
    local ret = 0
    local i = 1
    local mac_tab = {}
    local ip_tab = {}

    ------------添加的时候判断已存在mac/ip不允许再进行添加------------
    while (config_tab["dhcp_static"][i]) do
        mac_tab[string.lower(config_tab["dhcp_static"][i]["macaddr"])] = 1
        ip_tab[config_tab["dhcp_static"][i]["ipaddr"]] = 1
        i = i + 1
    end

    local macaddr_lower = string.lower(bind["macaddr"])
    if (mac_tab[macaddr_lower] == 1 or ip_tab[bind["ipaddr"]] == 1) then
        return -1
    end

    name_uuid = guid() --uuid
    t_bind["name_uuid"] = name_uuid
    t_bind["macaddr"] = macaddr_lower
    t_bind["ipaddr"] = bind["ipaddr"]
    table.insert(config_tab["dhcp_static"], t_bind)
    
    --uci 配置文件添加
    if (uci_flag == true) then
        x:set("dhcp", name_uuid, "host")
        x:set("dhcp", name_uuid, "mac", macaddr_lower)
        x:set("dhcp", name_uuid, "ip", bind["ipaddr"])
    end

    return 0
end

--删除（查询，删除表中的一个规则）
local function del_config_bind(macaddr, config_tab)
    local ret = 0
    local flag = 0
    local uuid
    local macaddr_lower = string.lower(macaddr)

    for k,v in pairs(config_tab["dhcp_static"]) do
        if (string.lower(v["macaddr"]) == macaddr_lower) then
            flag = 1
            uuid = v["name_uuid"]
            table.remove(config_tab["dhcp_static"], k)
            break
        end
    end

    --uci 配置文件删除
    if (flag == 1 and uci_flag == true) then
        if (uuid ~= nil) then
            x:delete("dhcp", uuid)
        else
            x:foreach("dhcp", "host",function(s)
                name = s[".name"]
                mac = x:get("dhcp", name, "mac")
                
                if (mac ~= nil) then 
                    local mac = string.lower(mac)
                    if (mac == macaddr_lower) then
                        x:delete("dhcp", name)
                    end
                end
           end
           )
        end
    end

    return 0
end

--修改（查询，修改表中的一个规则）
local function update_config_bind(old, new, config_tab)
    local ret = 0
    local flag = 0
    local uuid
    local old_macaddr_lower = string.lower(old["macaddr"])
    local new_macaddr_lower = string.lower(new["macaddr"])

    for k,v in pairs(config_tab["dhcp_static"]) do
        if (string.lower(v["macaddr"]) == old_macaddr_lower and v["ipaddr"] == old["ipaddr"])
        then
            v["ipaddr"] = new["ipaddr"]
            v["macaddr"] = new_macaddr_lower
            flag = 1
            uuid = v["name_uuid"]
            break
        end
    end

    --uci   配置文件修改
    if (flag == 1 and uci_flag == true) then
        if (uuid ~= nil) then
            x:set("dhcp", uuid, "mac", new_macaddr_lower)
            x:set("dhcp", uuid, "ip", new["ipaddr"])
        else
            x:foreach("dhcp", "host",function(s)
                name = s[".name"]
                local mac = x:get("dhcp", name, "mac")
                mac = string.lower(mac)
                if (mac == old_macaddr_lower) then
                    x:set("dhcp", name, "mac", new_macaddr_lower)
                    x:set("dhcp", name, "ip", new["ipaddr"])
                end
           end
           )
        end

        x:commit("dhcp")
        x:revert("dhcp")
    end

    return 0
end

function check_ip_in_excld_addr(ip)
    local ip1, ip2, ip3, ip4 = string.match(ip, "(%d+)%.(%d+)%.(%d+)%.(%d+)")
    
    local ip_int = 0
    if (ip1 ~= nil and ip2 ~= nil and ip3 ~= nil and ip4 ~= nil) then
        ip_int = ip1 * 16777216 + ip2 * 65536 + ip3 * 256 + ip4
    end

    if (ip_int <= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: the ip addr [%s] is error ", ip)
        return -1
    end
    
    for k,v in ipairs(excld_addr_arry) do
        if (type(v[1]) == "number" and type(v[2]) == "number") then
            if (v[1] <= ip_int and ip_int <= v[2]) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: the ip addr [%s] is confilct ", ip)
                return -1
            end
        end
    end
    
    return 0
end

function creat_intf_excld_addr(excld_addr_list)
    local strlen, ip1, ip2, ip3, ip4, ip_int
    
    for k,v in ipairs(excld_addr_list) do
        if (v["excldstart"] ~= nil and v["excldend"] ~= nil) then
            local excld_addr = {}
            ip_int = 0
            strlen = 0
            
            strlen = string.len(v["excldstart"])
            if (strlen ~= 0) then
                ip1, ip2, ip3, ip4 = string.match(v["excldstart"], "(%d+)%.(%d+)%.(%d+)%.(%d+)")
            end
            
            if (ip1 ~= nil and ip2 ~= nil and ip3 ~= nil and ip4 ~= nil) then
                ip_int = ip1 * 16777216 + ip2 * 65536 + ip3 * 256 + ip4
            end
            
            if (ip_int > 0) then
                excld_addr[1] = ip_int
                
                strlen = 0
                strlen = string.len(v["excldend"])
                if (strlen ~= 0) then
                    ip1, ip2, ip3, ip4 = string.match(v["excldend"], "(%d+)%.(%d+)%.(%d+)%.(%d+)")
                end
                
                -- 如果excldend为空的情况下，ip1, ip2, ip3, ip4为excldstart的数据
                if (ip1 ~= nil and ip2 ~= nil and ip3 ~= nil and ip4 ~= nil) then
                    ip_int = ip1 * 16777216 + ip2 * 65536 + ip3 * 256 + ip4
                end

                -- 确保结束地址是正常的情况下进行数据叠加
                if (ip_int > 0) then
                    excld_addr[2] = ip_int
                    table.insert(excld_addr_arry, excld_addr)
                end
            end

            ip1, ip2, ip3, ip4, ip_int = 0, 0, 0, 0, 0
        end
    end
end

--获取l3的保留地址配置
function get_excld_addr()
    l3_file = "/etc/sd_config/single/l3_interface.json"
    if (file_exist(l3_file) ~= true) then
        return 
    end
    
    l3_str = file_read(l3_file)
    if (l3_str == nil) then
        return
    end
    
    l3_tab = cjson_safe.decode(l3_str)
    if (l3_tab == nil) then
        return
    end

    if (l3_tab["list"] == nil) then
        return
    end
    
    for k,v in pairs(l3_tab["list"]) do
        if (v["excldaddr"] ~= nil) then
            ret = creat_intf_excld_addr(v["excldaddr"])
            if (ret == -1) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: the %s excldaddr is error ", cjson.safe.encode(v))
            end
        end
    end
end


--获取当前表长度
function table_length(t)
  local length = 0

  for k, v in pairs(t) do
    length = length + 1
  end

  return length
end

--ip地址合法性检查
function ip_validity_check(ip)
    local ip1, ip2, ip3, ip4 = string.match(ip, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$");

    if (ip1 == nil or ip2 == nil or ip3 == nil or ip4 == nil) then
        return -1
    end

    if (tonumber(ip1) > 223 or tonumber(ip1) == 127 or tonumber(ip1) < 0) then
        return -1
    end

    return 0
end

--mac地址合法性检查
function mac_validity_check(macaddr)
    local macaddr1, macaddr2, macaddr3, macaddr4, macaddr5, macaddr6 = string.match(macaddr, "^(%x+):(%x+):(%x+):(%x+):(%x+):(%x+)$")
    if (macaddr1 == nil or macaddr2 == nil or macaddr3 == nil or macaddr4 == nil or macaddr5 == nil or macaddr6 == nil) then
        return -1
    end
    
    if (tonumber(macaddr1, 16) == 255) then
        return -1
    end
    
    if (tonumber(macaddr1, 16) % 2 ~= 0) then
        return -1
    end

    return 0
end

--设置是否配置uci文件
function set_uci_flag()
    ablity_file = "/tmp/sd_device/sd_device.json"
    if (file_exist(ablity_file) ~= true) then
        return 
    end
    
    ablity_str = file_read(ablity_file)
    if (ablity_str == nil) then
        return
    end
    
    ablity_table = cjson_safe.decode(ablity_str)
    if (ablity_table == nil) then
        return
    end

    if (ablity_table["dnsmasq"] ~= nil) then
        if (ablity_table["dnsmasq"]["static_file"] ~= nil) then
            uci_flag = false
        end
    end
end

--设置是否支持保留地址
function set_excld_addr_flag()
    ablity_file = "/tmp/sd_device/sd_device.json"
    if (file_exist(ablity_file) ~= true) then
        return 
    end
    
    ablity_str = file_read(ablity_file)
    if (ablity_str == nil) then
        return
    end
    
    ablity_table = cjson_safe.decode(ablity_str)
    if (ablity_table == nil) then
        return
    end

    if (ablity_table[web_node] ~= nil) then
        if (ablity_table[web_node]["support_excldAddr"] ~= nil) then
            if (ablity_table[web_node]["support_excldAddr"] == "1") then
                excld_addr_flag = true
            end
        end
    end
end

--获取静态dhcp的容量,默认为500
function get_max_dhcp_num()
    local max_num, ablity_file, ablity_table

    max_num = 500
    ablity_file = "/tmp/sd_device/sd_device.json"
    if (file_exist(ablity_file) ~= true) then
        return max_num
    end
    
    ablity_str = file_read(ablity_file)
    if (ablity_str == nil) then
        return max_num
    end
    
    ablity_table = cjson_safe.decode(ablity_str)
    if (ablity_table == nil) then
        return max_num
    end

    if (ablity_table["dnsmasq"] ~= nil) then
        if (ablity_table["dnsmasq"]["static_dhcp_num"] ~= nil) then
            max_num = ablity_table["dnsmasq"]["static_dhcp_num"]
        end
    end
    
    if (max_num ~= nil and string.len(max_num) == 0) then 
        max_num = 500
    end
    
    if (max_num == nil) then
        max_num = 500
    end

    return max_num
end

--默认配置
function module_default_config_get()
    local g_def_cfg_json = '{"dhcp_static":[]}';
    module_debug.lua_debug(module_debug.INFO, "INFO: [module_default_config_get] get default success")

    return g_def_cfg_json
end

function module_set(param)
    local i = 1
    local param_tab

    set_uci_flag()
    set_excld_addr_flag()
    param_tab = cjson_safe.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: The entry param is error!");
    end

    i = 1
    while (param_tab["dhcp_static"][i]) do
        local ipaddr = param_tab["dhcp_static"][i]["ipaddr"]
        local macaddr = param_tab["dhcp_static"][i]["macaddr"]
        ret = ip_validity_check(ipaddr)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the ip is illegal!")
            return output("1", err_code["ERR_STATIC_DHCP_IP_ILLEGAL"], "ERROR: the ip is illegal!", ipaddr)
        end
        
        ret = mac_validity_check(macaddr)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the mac is illegal!")
            return output("1", err_code["ERR_STATIC_DHCP_MAC_ILLEGAL"], "ERROR: the mac is illegal!", macaddr)
        end
        
        i = i + 1
    end

    if (excld_addr_flag == true) then
        i = 1
        get_excld_addr()
        while (param_tab["dhcp_static"][i]) do
            ipaddr = param_tab["dhcp_static"][i]["ipaddr"]
            ret = check_ip_in_excld_addr(ipaddr)
            if (ret == -1) then
                errmsg = string.format("ERROR: [%s] address conflicts with reserved address!", ipaddr)
                return output("1", err_code["ERR_STATIC_DHCP_IP_CONFLICT"], errmsg, ipaddr)
            end
            
            i = i + 1
        end
    end

    --删除所有静态dhcp配置

    x:foreach("dhcp", "host",function(s)
        name = s[".name"]
        x:delete("dhcp", name)
    end)

    if (uci_flag == true) then
        i = 1
        while (param_tab["dhcp_static"][i]) do
            if (param_tab["dhcp_static"][i]["name_uuid"] ~= nil) then
                name_uuid = param_tab["dhcp_static"][i]["name_uuid"]
            else
                name_uuid = guid()
            end

            macaddr = param_tab["dhcp_static"][i]["macaddr"]
            ipaddr = param_tab["dhcp_static"][i]["ipaddr"]
            x:set("dhcp", name_uuid, "host")
            x:set("dhcp", name_uuid, "mac", macaddr)
            x:set("dhcp", name_uuid, "ip", ipaddr)
            
            i = i + 1
        end
        
        x:commit("dhcp")
        x:revert("dhcp")
    end

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_set] %s configraution success", param)
    module_apply()
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_add(param)
    local param_tab, max_num, curtab_len

    set_uci_flag()
    set_excld_addr_flag()
    param_tab = cjson_safe.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param_tab is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: The entry param is error!")
    end

    local config_tab = file_read(config_file)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end

    max_num = get_max_dhcp_num()
    if (max_num ~= nil) then
        max_num = tonumber(max_num)
    else
        max_num = 500
    end

    config_tab = cjson_safe.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end
    
    curtab_len = table_length(config_tab["dhcp_static"])
    if (curtab_len ~= nil) then
        curtab_len = tonumber(curtab_len) + 1
    else
        curtab_len = 1
    end

    if (curtab_len > max_num) then
        module_debug.lua_debug(module_debug.ERROR, "INFO: [module_add] maximum capacity")
        return output("1", err_code["ERR_STATIC_DHCP_MAX_OVER"], "ERROR: Maximum capacity!", tostring(max_num))
    end

    for k,v in pairs(param_tab["list"]) do
        ret = ip_validity_check(v["ipaddr"])
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the ip is illegal!")
            return output("1", err_code["ERR_STATIC_DHCP_IP_ILLEGAL"], "ERROR: the ip is illegal!", v["ipaddr"])
        end
        
        ret = mac_validity_check(v["macaddr"])
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the mac is illegal!")
            return output("1", err_code["ERR_STATIC_DHCP_MAC_ILLEGAL"], "ERROR: the mac is illegal!", v["macaddr"])
        end
        
        if (excld_addr_flag == true) then
            get_excld_addr()
            ret = check_ip_in_excld_addr(v["ipaddr"])
            if (ret ~= 0) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] %s Configuration address conflicts with reserved address!", v["ipaddr"])
                errmsg = string.format("ERROR: [%s] address conflicts with reserved address!", v["ipaddr"])
                return output("1", err_code["ERR_STATIC_DHCP_IP_CONFLICT"], errmsg, v["ipaddr"])
            end
        end

        ret = add_config_bind(v, config_tab)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
            return output("1", err_code["ERR_STATIC_DHCP_DEPLOY_FAIL"], "ERROR: add_config_bind is failed!")
        end
    end

    if (uci_flag == true) then
        x:commit("dhcp")
        x:revert("dhcp")
    end

    config_tab = cjson_safe.encode(config_tab)
    if (config_tab ~= nil) then
        file_write(config_file_backup, config_tab)
        file_copy(config_file_backup, config_file)
    end
    module_debug.lua_debug(module_debug.INFO, "INFO: [module_add] %s configraution success", param)
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_del(param)
    local config_tab, param_tab

    set_uci_flag()
    param_tab = cjson_safe.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: The entry param is error!")
    end

    config_tab = file_read(config_file)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end

    config_tab = cjson_safe.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end

    for k,v in pairs(param_tab["macaddr"]) do
        ret = mac_validity_check(v)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the mac is illegal!")
            return output("1", err_code["ERR_STATIC_DHCP_MAC_ILLEGAL"], "ERROR: the mac is illegal!", v)
        end
    
        ret = del_config_bind(v, config_tab)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] del_config_bind is failed param is %s", param)
            return output("1", err_code["ERR_STATIC_DHCP_DEPLOY_FAIL"], "ERROR: del_config_bind is failed!")
        end
    end

    if (uci_flag == true) then
        x:commit( "dhcp" )
        x:revert( "dhcp" )
    end

    config_tab = cjson_safe.encode(config_tab)
    if (config_tab ~= nil) then
        file_write(config_file_backup, config_tab)
        file_copy(config_file_backup, config_file)
    end
    module_debug.lua_debug(module_debug.INFO, "INFO: [module_del] %s configraution success", param)
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_update(param)
    local param_tab, config_tab
    set_uci_flag()
    set_excld_addr_flag()
    param_tab = cjson_safe.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param_tab is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: The entry param is error!")
    end

    config_tab = file_read(config_file)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end

    config_tab = cjson_safe.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return output("1", err_code["ERR_STATIC_DHCP_ENTRY_ABNORMAL"], "ERROR: config is nil!")
    end

    ret = ip_validity_check(param_tab["new"]["ipaddr"])
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the ip is illegal!")
        return output("1", err_code["ERR_STATIC_DHCP_IP_ILLEGAL"], "ERROR: the ip is illegal!", param_tab["new"]["ipaddr"])
    end
    
    ret = mac_validity_check(param_tab["new"]["macaddr"])
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the mac is illegal!")
        return output("1", err_code["ERR_STATIC_DHCP_MAC_ILLEGAL"], "ERROR: the mac is illegal!", param_tab["new"]["macaddr"])
    end

    ret = ip_validity_check(param_tab["old"]["ipaddr"])
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the ip is illegal!")
        return output("1", err_code["ERR_STATIC_DHCP_IP_ILLEGAL"], "ERROR: the ip is illegal!", param_tab["old"]["ipaddr"])
    end
    
    ret = mac_validity_check(param_tab["old"]["macaddr"])
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] the mac is illegal!")
        return output("1", err_code["ERR_STATIC_DHCP_MAC_ILLEGAL"], "ERROR: the mac is illegal!", param_tab["old"]["macaddr"])
    end

    if (excld_addr_flag == true) then
        get_excld_addr()
        ret = check_ip_in_excld_addr(param_tab["new"]["ipaddr"])
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] %s Configuration address conflicts with reserved address!", param_tab["new"]["ipaddr"])
            errmsg = string.format("ERROR: [%s] address conflicts with reserved address!", param_tab["new"]["ipaddr"])
            return output("1", err_code["ERR_STATIC_DHCP_IP_CONFLICT"], errmsg, param_tab["new"]["ipaddr"])
        end
    end

    ret = update_config_bind(param_tab["old"], param_tab["new"], config_tab)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] update_config_bind is failed param is %s", param)
        return output("1", err_code["ERR_STATIC_DHCP_DEPLOY_FAIL"], "ERROR: update_config_bind is failed!")
    end

    config_tab = cjson_safe.encode(config_tab)
    if (config_tab ~= nil) then
        file_write(config_file_backup, config_tab)
        file_copy(config_file_backup, config_file)
    end
    module_debug.lua_debug(module_debug.INFO, "INFO: [module_update] %s configraution success", param)
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_apply()
    local elisten_file = "/etc/init.d/elisten"

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_apply] dnsmasq restart")

    if (file_exist(elisten_file) == true) then
        os.execute("ubus send 'dnsmasq_restart'");
    else
        os.execute("/etc/init.d/dnsmasq restart 2>/dev/null");
    end
end