#! /usr/bin/lua
module("user_list_note",package.seeall)
cjson = require "cjson"
tool = require "dev.tools.common"
module_debug = require "utils.debug"
local libc2lua = require("libc2lua");

child_file = "/etc/sd_config/single/child_guard.json"
conf_file = "/etc/sd_config/single/user_list_note.json"
sd_device = "/tmp/sd_device/sd_device.json"
def_cfg = "{\"list\":[]}"
 
--child_guard_sync为1表示需要同步，为0表示不需要同步
child_sync = 1
----------初始化debug---------------
module_debug.debug_init("/tmp/user_list/", "user_list_note.log", 100, module_debug.DEBUG, "1");

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    if (file == nil) then
        module_debug.lua_debug(module_debug.ERROR, "file_read:%s error", conf_file)
        return nil
    end
    local data = file:read("*a")
    file:close()
	
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

function output(ret)
    result = {}
    result["code"] = ret
    return cjson.encode(result)
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    return def_cfg
end

--遍历儿童守护配置文件 /etc/sd_config/single/child_guard.json
--读取guardUser数组下的数据
local child_list = {}
function child_guard_traverse()
    local file_data = file_read(child_file)
    if (file_data == nil) then
        child_sync = 0
        return
    end
    
    local cfg_data = cjson.decode(file_data)
    if (cfg_data.guardUser == nil) then
        module_debug.lua_debug(module_debug.DEBUG, "/etc/sd_config/single/child_guard.json is nil")
        return
    end
    
    local cfg_list = #cfg_data.guardUser
    --module_debug.lua_debug(module_debug.DEBUG, "guardUser num:%d", cfg_list)

    for i = 1, cfg_list do 
        child_list[cfg_data["guardUser"][i]["mac"]] = cfg_data["guardUser"][i]["name"]
    end
    
    module_debug.lua_debug(module_debug.DEBUG, "child_list:%s", cjson.encode(child_list))
end

--数据打包
local child_data = {}
function child_guard_packaged_data(mac, name) 
    --child_guard_sync为0时，表示改数据是由儿童守护同步到user_list
    if (child_sync == 0) then
        return
    end
    
    local update = {}
    update["mac"] = mac
    update["name"] = name
    update["not_sync"] = "1"
    
    --查看child_list，如果存在相同mac数据，则将数据存入到child_data
    if (child_list[mac] ~= nil) then
        table.insert(child_data, update)
    end
    --module_debug.lua_debug(module_debug.DEBUG, "child_data:%s", cjson.encode(child_data))
end

--数据组装 dev_config add -m child_guard '{"guardUser":[{"mac":"c8:5b:76:93:ec:60","name":"ew1200","not_sync":"1"}]}'
function child_guard_sync()
    --child_guard_sync为0时，表示改数据是由儿童守护同步到user_list
    if (child_sync == 0) then
        return
    end

    local sync_list = {}
    sync_list["guardUser"] = child_data
    --module_debug.lua_debug(module_debug.DEBUG, "bbbbbbbb sync_list:%s", cjson.encode(sync_list))
    
    local cmd = "dev_config add -m child_guard '"..cjson.encode(sync_list).."' -b 1 &"
    os.execute(cmd)
    module_debug.lua_debug(module_debug.DEBUG, "os.execute:%s", cmd)
end

--遍历json配置文件，查找项位置,未查找到返回0
function conf_match(data, cfg)
    local num = 1
    local flag = 0
    local length = table.maxn(cfg["list"])     
    while ( num < length + 1 )
    do
		if (cfg["list"][num]["mac"] == data["mac"]) then
            flag = 1
            break
        end
        num = num + 1
    end
    if (flag == 1) then
        return num
    end
    
    return 0
end

function module_update(param)
	
	--参数安全检测
	if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "input_data is unsafe");
        print("Error: input_data is unsafe")
        return output(1)
    end
	
    module_debug.lua_debug(module_debug.DEBUG, "[module_update]: param: %s", param)
    local user_list_max = 0

    child_guard_traverse()
    
    --参数检测,读取当前配置
    local data = cjson.decode(param)
    if (data.list == nil or #data.list == 0) then
        module_debug.lua_debug(module_debug.ERROR, "module_update failed:param error")
        return output(1)
    end
    local param_len = #data.list
    --如果命令是从儿童守护来的，计算最大值时，容量+32.因为儿童守护接口无法接收配置失败信息。
    if (data.obj == "child_guard") then
        user_list_max = 32
        child_sync = 0
    end
    
    local file_data = file_read(conf_file)
    if (file_data == nil) then
        return output(1)
    end
	--安全保护
	if (libc2lua.lua_param_safety_check(file_data) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "module_update failed:conf_file error")
        return output(1)
    end
    local cfg_data = cjson.decode(file_data)
    
    local device_data = file_read(sd_device)
    if (device_data == nil) then
        return output(1)
    end
    local sd_data = cjson.decode(device_data)
    user_list_max = user_list_max + tonumber(sd_data.user_list_max)
    module_debug.lua_debug(module_debug.DEBUG, "user_list_max:%d", user_list_max)
    
    local cfg_len
    --更新数据
    for i = 1, param_len do 
        local num = conf_match(data["list"][i], cfg_data)
        if (num ~= 0) then
            cfg_len = #cfg_data.list
        else
            cfg_len = #cfg_data.list + 1
        end
         
        if (cfg_len > user_list_max) then
            module_debug.lua_debug(module_debug.ERROR, "[module_update]: user_list_max:%d < cfg list:%d", user_list_max, cfg_len)
            --把前面更新成功的数据写到配置文件
            file_write(conf_file, cjson.encode(cfg_data))
            child_guard_sync()
            return output(2)
        end
        
        --module_debug.lua_debug(module_debug.DEBUG, "[module_update]: conf_match num: %d", num)
        if (num ~= 0) then
            if (data["list"][i]["name"] ~= "") then
                cfg_data["list"][num]["name"] = data["list"][i]["name"]
                child_guard_packaged_data(data["list"][i]["mac"], data["list"][i]["name"])
                module_debug.lua_debug(module_debug.DEBUG, "[module_update]: update  mac:%s, name:%s", data["list"][i]["mac"], data["list"][i]["name"])
            else
                table.remove(cfg_data["list"], num)
                child_guard_packaged_data(data["list"][i]["mac"], "")
                module_debug.lua_debug(module_debug.DEBUG, "[module_update]: update  mac:%s, name:nil;", data["list"][i]["mac"])
            end
        else
            if (data["list"][i]["name"] ~= "") then
                module_debug.lua_debug(module_debug.DEBUG, "[module_update]: add  mac:%s, name:%s", data["list"][i]["mac"], data["list"][i]["name"])
                table.insert(cfg_data["list"], data["list"][i])
                child_guard_packaged_data(data["list"][i]["mac"], data["list"][i]["name"])
            else
                module_debug.lua_debug(module_debug.DEBUG, "[module_update]: update  mac:%s, name:nil;", data["list"][i]["mac"])
            end
        end
    end
    --写json数据到文件
    file_write(conf_file, cjson.encode(cfg_data))
    child_guard_sync()
    return output(0)
end

function module_set(param)
	--参数安全检测
	if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "input_data is unsafe");
        print("Error: input_data is unsafe")
        return output(1)
    end
	
	--参数检测,读取当前配置
    local data = cjson.decode(param)
    if (data.list == nil) then
        module_debug.lua_debug(module_debug.ERROR, "module_update failed:param error")
        return output(1)
    end
	
	file_write(conf_file, param)
    return output(0)
end

function module_del(param)
	--参数安全检测
	if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "input_data is unsafe");
        print("Error: input_data is unsafe")
        return output(1)
    end
	
    module_debug.lua_debug(module_debug.DEBUG, "[module_del]: param: %s", param)

    local update = {}
    
    child_guard_traverse()
    
    --参数检测,读取当前配置
    local data = cjson.decode(param)
    if (data.list == nil) then
        module_debug.lua_debug(module_debug.ERROR, "module_update failed:param error")
        return output(1)
    end
    local file_data = file_read(conf_file)
    if (file_data == nil) then
        return output(1)
    end
	
	--安全保护
	if (libc2lua.lua_param_safety_check(file_data) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "module_update failed:conf_file error")
		return output(1)
    end
    local cfg_data = cjson.decode(file_data)
    
    local count = #data.list
    module_debug.lua_debug(module_debug.DEBUG, "[module_update]: count: %d", count)
    --删除所有备注
    if (count == 0) then
        --遍历儿童守护配置文件
        local child_d = file_read(child_file)
        if (child_d == nil) then
            file_write(conf_file, def_cfg)
            return output(0)
        end
        local child = cjson.decode(child_d)
        local child_count = #child.guardUser
        module_debug.lua_debug(module_debug.DEBUG, "[module_update]: child_count: %d", child_count)
        for i = 1, child_count do 
            update = {}
            update["mac"] = child["guardUser"][i]["mac"]
            update["name"] = ""
            update["not_sync"] = "1"
            table.insert(child_data, update)
            
            module_debug.lua_debug(module_debug.DEBUG, "[module_update]: i: %d mac:%s", i, child["guardUser"][i]["mac"])
            module_debug.lua_debug(module_debug.DEBUG, "[module_update]: i: %d update:%s", i, update["mac"])
        end
        child_guard_sync()
        file_write(conf_file, def_cfg)
        return output(0)
    end
    for i = 1, count do 
        module_debug.lua_debug(module_debug.DEBUG, "[module_update]: count: %d", i)
        --更新数据
        local num = conf_match(data["list"][i], cfg_data)
        module_debug.lua_debug(module_debug.DEBUG, "[module_update]: conf_match num: %d", num)
        if (num ~= 0) then
            child_guard_packaged_data(cfg_data["list"][num]["mac"], "")
            table.remove(cfg_data["list"], num)
        end
    end
    
    --写json数据到文件
    file_write(conf_file, cjson.encode(cfg_data))
    child_guard_sync()
    return output(0)
end

function module_apply()
end

-- dev_config get -m user_list_note|jq .
-- dev_config update -m user_list_note '{"obj":"web","list":[{"mac":"8c:ae:4b:00:23:00","name":"ew1200"}]}'
-- dev_config del -m user_list_note '{"list":[]}'--全部删除
-- dev_config del -m user_list_note '{"list":[{"mac":"20:47:da:d4:3c:77"}]}'
-- 返回：{"code":"0"}，0代表成功，非0代表失败
