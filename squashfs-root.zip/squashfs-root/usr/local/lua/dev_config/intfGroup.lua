#! /usr/bin/env lua

module_name = "intfGroup"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
dkjson = require "dkjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"
intfGroupIpset = require "intfGroupIpset"
local nixio_ok, nixio = pcall(require, "nixio")

config_file_path = "/etc/sd_config/single/intfGroup.json"

cfg_idx_tb = {}
cfg_tb_num = 0
----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")
math.randomseed(os.time())

local err_code = {
    ["SUCCESS"] = "0000000",
    ["ERR_INTFGROUP_PARAM_EXCEPTION"] = "04270001",
    ["ERR_INTFGROUP_CONFIG_EXCEPTION"] = "04270002",
}

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

local function file_sync(path)
    if (not (nixio_ok and nixio and nixio.open)) then
        return
    end

    local fd = nixio.open(path, "r")
    if (fd) then
        if (fd.sync) then
            fd:sync()
        end
        fd:close()
    else
        module_debug.lua_debug(module_debug.ERROR, "file_sync: failed to open [%s]", path)
    end
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"

    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        f:flush()
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- return error message if execution fails
-- @code: error code
-- @msg: error msg
-- @If it fails to return an error, it is considered that the configuration has failed
local function fail_reason(code, msg)
    local err = {}
    local ret = {}

    err["rcode"] = code
    err["message"] = msg
    ret["code"] = "1"
    ret["err"] = cjson_safe.encode(err)

    return cjson_safe.encode(ret)
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil, recovering with default config")
        return cjson_safe.decode('{"list":[]}'), true
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json, recovering with default config")
        return cjson_safe.decode('{"list":[]}'), true
    end
    
    return config_json, false
end

local function json_write_to_file(path, config_json)
    if (config_json == nil) then
        return 0
    end

    local config_str = dkjson.encode(config_json)
    if (config_str == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)

    -- use random suffix to avoid concurrent processes overwriting each other's temp file
    local temp_path = path .. ".tmp." .. tostring(math.random(100000, 999999))
    local res = file_write(temp_path, config_str)
    if (res ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "Failed to write to temp file [%s]", temp_path)
        os.remove(temp_path)
        return -1
    end

    local rename_success = os.rename(temp_path, path)
    if (not rename_success) then
        module_debug.lua_debug(module_debug.ERROR, "Failed to rename temp file [%s] to [%s]", temp_path, path)
        os.remove(temp_path)
        return -1
    end

    -- fsync the target file after rename to persist the directory entry on journaling filesystems
    file_sync(path)

    return 0
end

local function checkparam_for_ref(param)
    if (type(param) ~= "array") then
        module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't string")
        return -1
    end

    for k,v in pairs(param) do
        if (type(v) ~= "table") then
            module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't string")
            return -1
        end
        
        if (v["obj"] ~= nil or v["count"] ~= nil) then
            if (string.match(v["obj"], "[^%w_-]") ~= nil) then
                module_debug.lua_debug(module_debug.ERROR, "The ref obj is unsafe")
                return -1
            end

            if (type(v["count"]) ~= "number") then
                module_debug.lua_debug(module_debug.ERROR, "The count is unsafe")
                return -1
            end
        end
    end
    
    return 0
end

local function checkparam_for_act(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the string %s style isn't string", param)
        return -1
    end

    if (param ~= "ref" and param ~= "deref" ) then
        module_debug.lua_debug(module_debug.ERROR, "the string %s content is error", param)
        return -1
    end
    
    return 0
end

local function checkparam_for_type(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't string")
        return -1
    end

    if (string.lower(param) ~= "system" and string.lower(param) ~= "user" and string.lower(param) ~= "auto") then
        module_debug.lua_debug(module_debug.ERROR, "the type is error")
        return -1
    end
    
    return 0
end


local function checkparam_for_mem(param)
    local count
    
    if (type(param["mem"]) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't array")
        return -1
    end

    for key,value in pairs(param["mem"]) do
        if (string.match(value, "[^%w_-]") ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "the interface member style isn't unsafe" )
            return -1
        end
    end
    
    -- 参数mem中去重
    local intfs = {}
    local intfrepeat = 0
    for key,value in pairs(param["mem"]) do
        if (intfs[value] == nil) then
            intfs[value] = key
            intfrepeat = 1
            
        end
    end
    
    count = 0
    if (intfrepeat == 1) then 
        param["mem"] = {}
        for key,value in pairs(intfs) do
            table.insert(param["mem"], key)
            count = count + 1
        end
    end
    
    return 0
end

local function checkparam_for_string_len(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the string %s style isn't string", param)
        return -1
    end

    if (string.len(param) < 0 or string.len(param) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "the string %s length is error", param)
        return -1
    end
    
    return 0
end

local function checkparam_for_uuid(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the uuid style isn't string")
        return -1
    end

    if (string.len(param) < 0 or string.len(param) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid length is error")
        return -1
    end

    if (string.match(param, "%W") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid isn't illegal")
        
        return -1
    end
    
    return 0
end

local function checkparam_is_json(param)
    if (type(param) ~= "string") then
        return nil
    end

    module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", module_name, param)

    local param_json = cjson_safe.decode(param)
    if (param_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter format is not json")
        return nil
    end

    return param_json
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil
    end
    
    local sh_ret_handle = io.popen(sh_cmd)
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret
end

local function config_index_table(config_json)
    for k,v in pairs(config_json["list"]) do
        cfg_idx_tb[v["uuid"]] = k
        cfg_tb_num = cfg_tb_num + 1
    end
end

local function find_config_exist_index(uuid)
    idx = cfg_idx_tb[uuid]
    
    return idx
end

local function add_node_to_config(node, config_json)
    local new_node = {}
    
    new_node["uuid"] = node["uuid"]
    new_node["name"] = node["name"] 
    new_node["mem"] = node["mem"] 
    new_node["type"] = node["type"]
    new_node["ref"] = {}
    
    table.insert(config_json["list"], new_node)
end

local function update_node_to_config(node, cfg_node)
    if (cfg_node["name"] ~= node["name"]) then
        cfg_node["name"] = node["name"]
    end

    if (cfg_node["mem"] ~= node["mem"]) then
        intfGroupIpset.ipset_update_set(node["uuid"], node["mem"])
        cfg_node["mem"] = node["mem"]
    end
end

local function update_ref_to_config(node, cfg_node)
    local obj = node["obj"]
    
    if (cfg_node["ref"] == nil) then
        cfg_node["ref"]= {}
    end

    local idx = nil
    for k,v in pairs(cfg_node["ref"]) do
        if (v == obj) then
            idx = k
            break
        end
    end
    
    if (node["act"] == "ref") then
        if (idx == nil) then
            table.insert(cfg_node["ref"], obj)
        end
    else
        if (idx ~= nil) then
            table.remove(cfg_node["ref"], idx)
        end
    end
end

local function add_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0
    for k,v in pairs(param_json["list"]) do
        if (v["type"] ~= "system") then
            idx =  find_config_exist_index(v["uuid"])
            if (idx == nil) then
                intfGroupIpset.ipset_create_set(v["uuid"])
                intfGroupIpset.ipset_update_set(v["uuid"], v["mem"])
                
                add_node_to_config(v, config_json)
                cfg_tb_num = cfg_tb_num + 1
                cfg_idx_tb[v["uuid"]] = cfg_tb_num
            else
                update_node_to_config(v, config_json["list"][idx])
            end
            
            change_flag = 1
        end
    end

    config_json["total"] = tostring(cfg_tb_num)
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERR: add json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

local function del_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0
    
    for k,v in pairs(param_json["list"]) do
        for conf_k, conf_v in pairs(config_json["list"]) do
            if (v == conf_v["uuid"]) then
                if (conf_v["type"] ~= "system") then
                    intfGroupIpset.ipset_destroy_set(v)

                    table.remove(config_json["list"], conf_k)
                    cfg_tb_num = cfg_tb_num - 1
                    change_flag = 1
                end
            end
        end
    end

    config_json["total"] = tostring(cfg_tb_num)
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERR: del json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

local function update_param_to_config(param_json, config_json, config_file_path)
    local refcount = 0
    local change_flag = 0

    if (param_json["list"] ~= nil) then
        for k,v in pairs(param_json["list"]) do
            idx =  find_config_exist_index(v["uuid"])
            if (idx ~= nil) then
                update_node_to_config(v, config_json["list"][idx])
                
                change_flag = 1
            end
        end
    else
        idx =  find_config_exist_index(param_json["uuid"])
        if (idx ~= nil) then
            update_ref_to_config(param_json, config_json["list"][idx])
            
            -- system类型的接口组未被模块引用,则删除该接口组
            refcount = 0
            for k,v in pairs(config_json["list"][idx]["ref"]) do
                refcount = refcount + 1
            end
            
            if (refcount == 0 and config_json["list"][idx]["type"] == "system") then
                table.remove(config_json["list"], idx)
                cfg_tb_num = cfg_tb_num - 1
                config_json["total"] = tostring(cfg_tb_num)
            end
            
            change_flag = 1
        end
    end
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERR: update json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

-- default config
function module_default_config_get()
    local def_cfg_str = '{"list":[]}'

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_default_config_get] get default success")

    return def_cfg_str
end

--[[
    param format:
    
    dev_config add -m intfGroup '{"list":[{"uuid":"xxxx","name":"lan","mem":["lan","lan_20","lan_30"],"type":"system"}]}'
]]--
function module_add(param, config_file_path)
    local config_json, _ = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "ERROR: intfGroup config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end
    
    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end

    -- 获取json文件已有的uuid
    config_index_table(config_json)
    
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_uuid(v["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param uuid is error")
        end
    
        ret = checkparam_for_string_len(v["name"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param name is error")
        end

        ret = checkparam_for_mem(v)
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param mem is error")
        end

        ret = checkparam_for_type(v["type"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param type is error")
        end
    end

    ret = add_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "intfGroup add config failed")
    end
    
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

--[[
    param format:
    
    dev_config del -m intfGroup '{"list":["lan"]}'
]]--
function module_del(param, config_file_path)
    local config_json, _ = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "ERROR: intfGroup config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end
    
    -- 获取json文件已有的uuid
    config_index_table(config_json)
    
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_uuid(v)
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param uuid is error")
        end
    end

    ret = del_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "ERROR: intfGroup del config failed")
    end

    return '{"rcode":"00000000", "message":"Configuration success"}'
end

--[[
    param format:
    
    dev_config update -m intfGroup '{"list":[{"uuid":"xxxx","name":"lan","mem":["lan","lan_20","lan_30"]}]}'
    
    dev_config update -m intfGroup '{"uuid":"xxxx","obj":"access_crtl","act":"ref"}'
]]--
function module_update(param, config_file_path)
    local config_json, is_recovered = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "ERROR: intfGroup update config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param is error")
    end

    config_index_table(config_json)
    if (param_json["list"] ~= nil) then
        for k,v in pairs(param_json["list"]) do
            ret = checkparam_for_uuid(v["uuid"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param uuid is error")
            end
            
            ret = checkparam_for_string_len(v["name"])
            if (ret == -1) then
                return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param name is error")
            end
            
            ret = checkparam_for_mem(v)
            if (ret == -1) then
                return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param mem is error")
            end 
        end
    else
        ret = checkparam_for_uuid(param_json["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param uuid is error")
        end

        if (string.match(param_json["obj"], "[^%w_-]") ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "The ref obj is unsafe")
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param obj is error")
        end

        ret = checkparam_for_act(param_json["act"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "param act is error")
        end 
    end
    
    if (is_recovered) then
        if (param_json["list"] ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERR: config recovered from default, falling back to add logic")
            for k,v in pairs(param_json["list"]) do
                v["type"] = v["type"] or "auto"
            end
            ret = add_param_to_config(param_json, config_json, config_file_path)
        else
            module_debug.lua_debug(module_debug.ERROR, "ERR: config recovered from default, ref update skipped (no-op)")
            ret = 0
        end
    else
        ret = update_param_to_config(param_json, config_json, config_file_path)
    end
    if (ret == -1) then
        return fail_reason(err_code["ERR_INTFGROUP_CONFIG_EXCEPTION"], "ERROR: intfGroup update config failed")
    end

    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_set(param)
    return fail_reason(err_code["ERR_INTFGROUP_PARAM_EXCEPTION"], "the operation is not support.")
end

-- Configuration Framework Apply
function module_apply()

end
