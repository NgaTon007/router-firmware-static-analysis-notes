#! /usr/bin/lua
module ("interface",package.seeall)
local cjson = require "cjson";
local tool = require "dev.tools.common"
local net_debug = require "utils.debug"
local ubus = require "ubus".connect();
local libc2lua = require("libc2lua")
local net_uci = require "luci.model.uci".cursor(nil, "/var/run/interface_uci_state")
local console = require "console"
package.cpath = package.cpath .. ";/usr/lib/libnetifapi.so"
local libnetifapi = require"libnetifapi";
local hotplug_dir = "/tmp/interface/hotplug/"
local config_file = "/etc/sd_config/single/interface.json"
local ports_map = "/tmp/sd_device/ports_map.json"
local ports_map_json = {};
local port_json = {};
local rand_base = 0;
local dev_type = nil

--debug��ʼ��
net_debug.debug_init("/tmp/interface/", "interface.log", 100, net_debug.INFO, "1");

local error_code = {
    ["SUCCESS"] = '{"rcode":"00000000","message":""}',
    ["PARAMETER_ILLEGAL"] = '{"rcode":"01070001","message":"Parameter is illegal."}',
    ["INIT_FAILED"] = '{"rcode":"01070002","message":"Initialization failed"}',
    ["FAILED"] = '{"rcode":"01070003","message":"Set configuration failed"}',
}

local netmask_array = {
    ["128.0.0.0"] = 2147483646,
    ["192.0.0.0"] = 1073741822,
    ["224.0.0.0"] = 536870910,
    ["240.0.0.0"] = 268435454,
    ["248.0.0.0"] = 134217726,
    ["252.0.0.0"] = 67108862,
    ["254.0.0.0"] = 33554430,
    ["255.0.0.0"] = 16777214,
    ["255.128.0.0"] = 8388606,
    ["255.192.0.0"] = 4194302,
    ["255.224.0.0"] = 2097150,
    ["255.240.0.0"] = 1048574,
    ["255.248.0.0"] = 524286,
    ["255.252.0.0"] = 262142,
    ["255.254.0.0"] = 131070,
    ["255.255.0.0"] = 65534,
    ["255.255.128.0"] = 32766,
    ["255.255.192.0"] = 16382,
    ["255.255.224.0"] = 8190,
    ["255.255.240.0"] = 4094,
    ["255.255.248.0"] = 2046,
    ["255.255.252.0"] = 1022,
    ["255.255.254.0"] = 510,
    ["255.255.255.0"] = 254,
    ["255.255.255.128"] = 126,
    ["255.255.255.192"] = 62,
    ["255.255.255.224"] = 30,
    ["255.255.255.240"] = 14,
    ["255.255.255.248"] = 6,
    ["255.255.255.252"] = 2,
    ["255.255.255.254"] = 1,
};

local netmask_to_bits = {
    ["128.0.0.0"] = 1,
    ["192.0.0.0"] = 2,
    ["224.0.0.0"] = 3,
    ["240.0.0.0"] = 4,
    ["248.0.0.0"] = 5,
    ["252.0.0.0"] = 6,
    ["254.0.0.0"] = 7,
    ["255.0.0.0"] = 8,
    ["255.128.0.0"] = 9,
    ["255.192.0.0"] = 10,
    ["255.224.0.0"] = 11,
    ["255.240.0.0"] = 12,
    ["255.248.0.0"] = 13,
    ["255.252.0.0"] = 14,
    ["255.254.0.0"] = 15,
    ["255.255.0.0"] = 16,
    ["255.255.128.0"] = 17,
    ["255.255.192.0"] = 18,
    ["255.255.224.0"] = 19,
    ["255.255.240.0"] = 20,
    ["255.255.248.0"] = 21,
    ["255.255.252.0"] = 22,
    ["255.255.254.0"] = 23,
    ["255.255.255.0"] = 24,
    ["255.255.255.128"] = 25,
    ["255.255.255.192"] = 26,
    ["255.255.255.224"] = 27,
    ["255.255.255.240"] = 28,
    ["255.255.255.248"] = 29,
    ["255.255.255.252"] = 30,
    ["255.255.255.254"] = 31,
    ["255.255.255.255"] = 32,
};

--dev_config add -m interface
--'{ "type": "alias", "name": "wan", "data": { "proto": "static", "interface": "wan", --"ipaddr": "1.1.1.1", "netmask": "255.255.255.0", "bcast": "1.1.1.1" } }'
--�������\n\r'`&$;>|/\<�ַ�
function param_safety_check(param)
    if (param == nil) then
        return true
    end

    if (string.match(param, "\\n") ~= nil) then
        return false
    end

    if (string.match(param, "([\n\r'`&$;>|/\<])") == nil) then
        return true
    else
        return false
    end
end

local function format_legality_of_ip(ipaddr)
    local ip_tab = {}

    if (ipaddr == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --��IP��ַ���յ�ţ���ȡ��ip_tab��
    string.gsub(ipaddr,'[^.]+', function (w)
        table.insert(ip_tab, w)
    end)

    if (ip_tab == nil or next(ip_tab) == nil or #ip_tab ~= 4) then
        return false;
    end

    for i, var in ipairs(ip_tab) do
        if (var == nil) then
            return false;
        end

        ip_num = tonumber(var);
        if (ip_num == nil) then
            return false;
        end

        if (ip_num > 255 or ip_num < 0) then
            return false;
        end
    end

    return true
end

function get_alone_intf_mac()
    local sys_mac = net_uci:get_first("sysinfo", "sysinfo", "sys_mac");

    if (sys_mac == nil) then
        local sys_mac_file = "/proc/sd_sys/sys_mac"
        if (tool.file_exist(sys_mac_file) == false) then
            net_debug.lua_debug(net_debug.ERROR, "%s is not exist.", sys_mac_file);
            return nil;
        end
        sys_mac = tool.file_read(sys_mac_file);
    end

    if (sys_mac == nil) then
        net_debug.lua_debug(net_debug.ERROR, "sys_mac is not exist.");
        return nil
    end

    local chunks = {sys_mac:match(("([a-fA-F0-9]*):"):rep(6):gsub(":$","$"))}
    if (chunks == nil or next(chunks) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "match %s failed", sys_mac);
        return nil
    end

    rand_base = rand_base + 100
    math.randomseed(os.time() + rand_base)
    local mac1 = math.random(0, 15);
    local mac2 = math.random(0, 15);
    chunks[4] = string.format("%01X%01X", mac1, mac2);
    mac1 = math.random(0, 15);
    mac2 = math.random(0, 15);
    chunks[5] = string.format("%01X%01X", mac1, mac2);
    mac1 = math.random(0, 15);
    mac2 = math.random(0, 15);
    chunks[6] = string.format("%01X%01X", mac1, mac2);
    local mac = table.concat(chunks, ":")
    if (mac == nil) then
        net_debug.lua_debug(net_debug.ERROR, "mac is nil");
        return nil
    end
    net_debug.lua_debug(net_debug.INFO, "mac: [%s]", mac);

    return mac
end

local function port_enable_get(portId)
    local ret = false;
    local ports_json_file = "/etc/sd_config/single/port.json"
    if (tool.file_exist(ports_json_file) == false) then
        net_debug.lua_debug(net_debug.INFO, "%s is not exist.", ports_json_file);
        return false;
    end
    local file_data = tool.file_read(ports_json_file);
    if (file_data == nil) then
        net_debug.lua_debug(net_debug.INFO, "Read %s failed.", ports_json_file);
        return false;
    end
    port_json = cjson.decode(file_data);
    if (port_json == nil) then
        net_debug.lua_debug(net_debug.INFO, "%s empty.", ports_json_file);
        return false;
    end
    if (port_json["port"] == nil or next(port_json["port"]) == nil) then
        net_debug.lua_debug(net_debug.INFO, "Port of %s empty.", ports_json_file);
        return false;
    end
    for i, var in ipairs(port_json["port"]) do
        if (var["action"] == "add" and var["portId"] == portId) then
            ret = true;
            net_debug.lua_debug(net_debug.INFO, "Port of %s is %s.", var["portId"], var["action"]);
        end
    end
    net_debug.lua_debug(net_debug.INFO, "Get port enable success");

    return ret;
end

local function port_info_get(portId)
    local ret = nil;

    if (portId == nil) then
        net_debug.lua_debug(net_debug.INFO, "Input portId is empty.");
        return ret;
    end

    if (ports_map_json["port"] == nil or next(ports_map_json["port"]) == nil) then
        net_debug.lua_debug(net_debug.INFO, "Port map json json empty.");
        return ret;
    end

    net_debug.lua_debug(net_debug.INFO, "portId: %s", portId);
    for i, var in ipairs(ports_map_json["port"]) do
        if (var["intf_port"] == portId) then
            ret = var;
        end
    end

    net_debug.lua_debug(net_debug.INFO, "Get port info success");
    return ret;
end

function check_param_legality_of_interface(fn_type, fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    if (fn_type == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input type is empty.");
        return false;
    end

    --����Ϊalias��interface����Ϊ��
    if (fn_type == "alias" and fn_json["interface"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Interface of type alias cannot be empty.");
        return false;
    else
        net_debug.lua_debug(net_debug.DEBUG, "interface is empty.");
        return true;
    end
end

function check_param_legality_of_bcast(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --netmask����Ϊ��
    if (fn_json["bcast"] == nil) then
        net_debug.lua_debug(net_debug.DEBUG, "bcast is empty.");
        return true;
    end

    if (format_legality_of_ip(fn_json["bcast"]) == false) then
        net_debug.lua_debug(net_debug.ERROR, "The bcast[%s] is illegal.", fn_json["bcast"]);
        return false;
    end

    return true;
end

function check_param_legality_of_netmask(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --netmask����Ϊ��
    if (fn_json["netmask"] == nil) then
        net_debug.lua_debug(net_debug.DEBUG, "netmask is empty.");
        return true;
    end

    if (netmask_array[fn_json["netmask"]] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "netmask[%s] is illegal.", fn_json["netmask"]);
        return false;
    end

    return true;
end

function check_param_legality_of_ipaddr(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --ipaddr����Ϊ��
    if (fn_json["ipaddr"] == nil) then
        net_debug.lua_debug(net_debug.DEBUG, "ipaddr is empty.");
        return true;
    end

    if (format_legality_of_ip(fn_json["ipaddr"]) == false) then
        net_debug.lua_debug(net_debug.ERROR, "The ipaddr[%s] is illegal.", fn_json["ipaddr"]);
        return false;
    end

    return true;
end

function check_param_legality_of_proto(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --proto����Ϊ��
    if (fn_json["proto"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "proto is empty.");
        return false;
    end

    --proto������dhcp��pppoe��static
    local list = {"dhcp", "pppoe", "static"}
    for i, var in ipairs(list) do
        if (fn_json["proto"] == var) then
            return true;
        end
    end

    net_debug.lua_debug(net_debug.ERROR, "proto[%s] is illegal.", fn_json["proto"]);
    return false;
end

function check_param_legality_of_data(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    if (fn_json["type"] == "alone_intf") then
        net_debug.lua_debug(net_debug.INFO, "Alone intf not need check data.");
        return true;
    end

    --data����Ϊ��
    if (fn_json["data"] == nil or next(fn_json["data"]) == nil) then
        net_debug.lua_debug(net_debug.ERROR, "data is empty.");
        return false;
    end
    --У��interface��
    local res = check_param_legality_of_interface(fn_json["type"], fn_json["data"])
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The netmask is illegal.");
        return false;
    end
    --У��proto��
    local res = check_param_legality_of_proto(fn_json["data"])
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The netmask is illegal.");
        return false;
    end
    --У��netmask
    local res = check_param_legality_of_netmask(fn_json["data"])
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The netmask is illegal.");
        return false;
    end
    --У��ipaddr
    local res = check_param_legality_of_ipaddr(fn_json["data"])
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The ipaddr is illegal.");
        return false;
    end

    return true;
end

function check_param_legality_of_type(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --type����Ϊ��
    if (fn_json["type"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "type is empty.");
        return false;
    end

    --typeĿǰ֧��alias
    local list = {"alias", "alone_intf"}
    for i, var in ipairs(list) do
        if (fn_json["type"] == var) then
            return true;
        end
    end

    net_debug.lua_debug(net_debug.ERROR, "type[%s] is error.", fn_json["type"]);
    return false;
end

function check_param_legality_of_name(fn_json)
    if (fn_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    --type����Ϊ��
    if (fn_json["name"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "name is empty.");
        return false;
    end

    net_debug.lua_debug(net_debug.INFO, "name is [%s].", fn_json["name"]);
    return true;
end

function check_param_legality_of_character(input_data)
    if (input_data == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return false;
    end

    if (param_safety_check(input_data) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters.")
        return false;
    end

    return true;
end

local function check_param_legality(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input table is empty.");
        return false;
    end

    --type�Ĳ���У��
    local res = check_param_legality_of_type(input_json)
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The param of type is illegal.");
        return false;
    end

    --name�Ĳ���У��
    local res = check_param_legality_of_name(input_json)
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The param of name is illegal.");
        return false;
    end

    --data�Ĳ���У��
    local res = check_param_legality_of_data(input_json)
    if (res == false) then
        net_debug.lua_debug(net_debug.ERROR, "The param of data is illegal.");
        return false;
    end

    return true;
end

function sd_config_of_add(input_json, config_tab)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end
    if (config_tab == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input config_tab is empty.");
        return false;
    end

    if (config_tab["list"] == nil or next(config_tab["list"]) == nil) then
        config_tab["list"] = {};
        config_tab["list"][1] = input_json;
        return true;
    end

    for i, var in ipairs(config_tab["list"]) do
        if (var["name"] == input_json["name"]) then
            config_tab["list"][i] = input_json;
            return true;
        end
    end

    local num = #config_tab["list"] + 1
    config_tab["list"][num] = input_json;

    return true;
end

function sd_config_of_del(input_json, config_tab)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end
    if (config_tab == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input config_tab is empty.");
        return false;
    end

    if (config_tab["list"] == nil or next(config_tab["list"]) == nil) then
        net_debug.lua_debug(net_debug.INFO, "Input config_tab is empty.");
        return true;
    end

    for i, var in ipairs(config_tab["list"]) do
        if (var["name"] == input_json["name"]) then
            table.remove(config_tab["list"], i);
            return true;
        end
    end

    return true;
end

function sd_config_of_write(config_tab)
    local file = io.open(config_file, "w+");
    if (file == nil) then
        net_debug.lua_debug(net_debug.INFO, "Open [%s] failed.", config_file);
        return false;
    end
    file:write(cjson.encode(config_tab));
    -- flush�����ڲ�������ļ�����ˢ�µ�0S������
    file:flush();
    file:close(file);
    --sync�ļ�ϵͳ����������ˢ�µ�����
    os.execute("sync");

    return true;
end

function configuration_of_add_of_alone_intf(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    if (input_json["data"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input data is empty.");
        return false;
    end

    local portId = input_json["data"]["portId"];
    if (port_enable_get(portId) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Alone port is not create.");
        return false;
    end

    local port_info = port_info_get(portId)
    if (port_info == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Get port info failed.");
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));

    if (input_json["name"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input name is empty.");
        return false;
    end

    local vid = input_json["data"]["vid"];
    if (vid == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input vid is empty.");
        return false;
    end

    local name = input_json["name"];
    local ifname = port_info["ifname"];
    if (port_info["switch_enable"] == "1") then
        ifname = table.concat({port_info["ifname"], ".", vid});
    end

    local ifname_old = net_uci:get("network", name, "ifname");
    if (ifname_old == ifname) then
        net_debug.lua_debug(net_debug.INFO, "%s is already added.", name);
        return true;
    end

    local macaddr = get_alone_intf_mac();
    if (macaddr == nil) then
        net_debug.lua_debug(net_debug.INFO, "get macaddr failed");
        return false;
    end
    -- net_uci:set("network", name, "interface")
    -- net_uci:set("network", name, "alone_intf", "1")
    -- net_uci:set("network", name, "ifname", ifname)
    -- net_uci:set("network", name, "macaddr", macaddr)
    -- net_uci:commit("network")
    if (libnetifapi.interface_add(name, ifname, macaddr, "alone_intf") ~= true) then
        net_debug.lua_debug(net_debug.INFO, "netifapi_interface_add:'%s' fail", name);
        return false;
    end
    if (ifname ~= nil and string.find(ifname, "bond") ~= nil) then
        local network = net_uci:get("bonding", ifname, "network")
        net_uci:set("bonding", ifname, "bak", network)
        net_uci:set("bonding", ifname, "network", "")
        net_uci:commit("bonding")
    end

    net_debug.lua_debug(net_debug.INFO, "Add %s ifname %s success.", name, ifname);

    return true;
end

-- interface.network_alias_intf_add(input_json["name"], input_json["data"]);
function configuration_of_add_of_alias(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    local netmask_bits = netmask_to_bits[input_json["data"]["netmask"]];
    local ipaddr = input_json["data"]["ipaddr"];
    local name = input_json["data"]["interface"];
    local bcast = input_json["data"]["bcast"];
    local hotplug_file = table.concat({hotplug_dir, input_json["name"]})
    local file = io.open(hotplug_file, "w+");
    if (file == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Open [%s] failed.", hotplug_file);
        return false;
    end

    if (name == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[interface] is empty.", hotplug_file);
        return false;
    end
    if (ipaddr == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[ipaddr] is empty.", hotplug_file);
        return false;
    end
    if (netmask_bits == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[%netmask] is empty.", hotplug_file);
        return false;
    end
    if (bcast == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[bcast] is empty.", hotplug_file);
        return false;
    end

    file:write("#!/bin/bash\n");
    file:write("\n");
    file:write("ip addr add ", ipaddr, "/", netmask_bits, " dev br-", name, " brd ", bcast, " 2>/dev/null\n");
    file:write("ip addr add ", ipaddr, "/", netmask_bits, " dev pppoe-", name, " brd ", bcast, " 2>/dev/null\n");
    -- flush�����ڲ�������ļ�����ˢ�µ�0S������
    file:flush();
    file:close(file);
    --sync�ļ�ϵͳ����������ˢ�µ�����
    os.execute("sync");

    os.execute(table.concat({"chmod +x ", hotplug_file, " 2>/dev/null"}));
    os.execute(table.concat({"sh ", hotplug_file, " 2>/dev/null"}));

    if (dev_type == "msw") then
        local data = {};
        data["type"] = "1";
        data["ip"] = ipaddr;
        data["mask"] = input_json["data"]["netmask"];
        local cmd = table.concat({"ubus -t 3 call swconfig cpp_spec_ip_add '", cjson.encode(data), "' 2>/dev/null &"});
        net_debug.lua_debug(net_debug.INFO, "Execute: %s.", cmd);
        os.execute(cmd);
    end
    net_debug.lua_debug(net_debug.INFO, "Add alias configuration success.");

    return true;
end

function configuration_of_add(input_json)
    ret = true;
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    local ret = true;
    if (input_json["type"] == "alias") then
        ret = configuration_of_add_of_alias(input_json);
    elseif (input_json["type"] == "alone_intf") then
        ret = configuration_of_add_of_alone_intf(input_json);
    end

    return ret;
end

function configuration_of_del_of_alone_intf(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    if (input_json["data"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input data is empty.");
        return false;
    end

    local portId = input_json["data"]["portId"];
    if (port_enable_get(portId) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Alone port is not create.");
        return false;
    end

    local port_info = port_info_get(portId)
    if (port_info == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Get port info failed.");
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "Port info: %s", cjson.encode(port_info));

    if (input_json["name"] == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input name is empty.");
        return false;
    end

    local vid = input_json["data"]["vid"];
    if (vid == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input vid is empty.");
        return false;
    end
    -- net_uci:delete("network", name);
    -- net_uci:commit("network")
    local name = input_json["name"];
    if (libnetifapi.interface_del(name, "alone_intf") ~= true) then
        net_debug.lua_debug(net_debug.INFO, "netifapi_interface_del:'%s' fail", name);
        return false;
    end

    local data = {}
    net_uci:foreach("bonding", "interface", function(s)
        local intf_name = s['.name'];
        if (intf_name ~= nil) then
            data[intf_name] = s;
        end
    end)
    for key, val in pairs(data) do
        if (val["bak"] ~= nil) then
            net_uci:set("bonding", key, "network", val["bak"])
            net_uci:delete("bonding", key, "bak")
        end
    end
    net_uci:commit("bonding")

    net_debug.lua_debug(net_debug.INFO, "Delete %s success.", name);

    return true;
end

-- interface.network_alias_intf_add(input_json["name"], input_json["data"]);
function configuration_of_del_of_alias(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    local netmask_bits = netmask_to_bits[input_json["data"]["netmask"]];
    local ipaddr = input_json["data"]["ipaddr"];
    local name = input_json["data"]["interface"];
    local bcast = input_json["data"]["bcast"];
    local hotplug_file = table.concat({hotplug_dir, input_json["name"]})
    local file = io.open(hotplug_file, "w+");
    if (file == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Open [%s] failed.", hotplug_file);
        return false;
    end

    if (name == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[interface] is empty.", hotplug_file);
        return false;
    end
    if (ipaddr == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[ipaddr] is empty.", hotplug_file);
        return false;
    end
    if (netmask_bits == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[%netmask] is empty.", hotplug_file);
        return false;
    end
    if (bcast == nil) then
        net_debug.lua_debug(net_debug.ERROR, "[bcast] is empty.", hotplug_file);
        return false;
    end

    file:write("#!/bin/bash\n");
    file:write("\n");
    file:write("ip addr del ", ipaddr, "/", netmask_bits, " dev br-", name, " 2>/dev/null\n");
    file:write("ip addr del ", ipaddr, "/", netmask_bits, " dev pppoe-", name, " 2>/dev/null\n");
    -- flush�����ڲ�������ļ�����ˢ�µ�0S������
    file:flush();
    file:close(file);
    --sync�ļ�ϵͳ����������ˢ�µ�����
    os.execute("sync");

    os.execute(table.concat({"chmod +x ", hotplug_file, " 2>/dev/null"}));
    os.execute(table.concat({"sh ", hotplug_file, " 2>/dev/null"}));
    os.remove(hotplug_file);

    if (dev_type == "msw") then
        local data = {};
        data["type"] = "1";
        data["ip"] = ipaddr;
        data["mask"] = input_json["data"]["netmask"];
        local cmd = table.concat({"ubus -t 3 call swconfig cpp_spec_ip_del '", cjson.encode(data), "' 2>/dev/null &"});
        net_debug.lua_debug(net_debug.INFO, "Execute: %s.", cmd);
        os.execute(cmd);
    end
end

function configuration_of_del(input_json)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input input_json is empty.");
        return false;
    end

    local ret = true
    if (input_json["type"] == "alias") then
        ret = configuration_of_del_of_alias(input_json);
    elseif (input_json["type"] == "alone_intf") then
        ret = configuration_of_del_of_alone_intf(input_json);
    end

    return ret;
end

local function basic_info_of_device_get()
    local capacity_file = "/tmp/sd_device/sd_device.json"
    if (tool.file_exist(capacity_file) == false) then
        net_debug.lua_debug(net_debug.ERROR, "%s is not exist.", capacity_file);
        return false;
    end

    local file_data = tool.file_read(capacity_file);
    if (file_data == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Read %s failed.", capacity_file);
        return false;
    end

    local file_data = tool.file_read(capacity_file);
    if (tool.json_check(file_data) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Read %s not json.", capacity_file);
        return false;
    end

    capacity_json = cjson.decode(file_data);
    if (capacity_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "%s empty.", capacity_file);
        return false;
    end

    --��ȡ�豸����
    dev_type = capacity_json["dev_type"];

    --�ж��豸ת��ģʽ�Ƿ�Ϊ�գ�Ϊ�վͱ�����
    if (dev_type == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Get dev_type failed.");
        return false;
    end
    net_debug.lua_debug(net_debug.INFO, "dev_type: %s", dev_type);

    --��ȡport����
    if (tool.file_exist(ports_map) == true) then
        file_data = tool.file_read(ports_map);
        if (file_data ~= nil) then
            net_debug.lua_debug(net_debug.INFO, "Ports map: %s", file_data);
            ports_map_json = cjson.decode(file_data);
        end
    end
    if (ports_map_json == nil) then
        local switch_hl = require "netmng.switch"
        ports_map_json, ret = switch_hl.switch_ports_map_get();
    end
    if (ports_map_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "%s empty.", ports_map);
        return false;
    end

    return true
end

--------------------------------dev_mode--------------------------------
function module_default_config_get()
    net_debug.lua_debug(net_debug.INFO, "################START################");
    local data = {}
    return(cjson.encode(data));
end

function module_update(param)
    --����п�
    if(param == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --param���и�ʽ���
    if (param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    -- ©��ע��У��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    net_debug.lua_debug(net_debug.INFO, "################START################");
    net_debug.lua_debug(net_debug.INFO, "Input: %s", param);

    --�豸������Ϣ��ȡ��
    local res = basic_info_of_device_get()
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Get basic info of device failed.");
        return console.uf_lua_fail(error_code["INIT_FAILED"]);
    end

    --��ȡ�����ļ�
    local config_tab = {};
    if (tool.file_exist(config_file) == true) then
        local config_data = tool.file_read(config_file)
        if (config_data == nil) then
            net_debug.lua_debug(net_debug.ERROR, "file_read failed")
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
        end
        if (tool.json_check(config_data) == false) then
            os.remove(config_file);
            net_debug.lua_debug(net_debug.ERROR, "'%s' not in JSON format", config_data);
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
        end
        config_tab = cjson.decode(config_data)
        if (config_tab == nil) then
            net_debug.lua_debug(net_debug.ERROR, "ERROR: [module_add] config is nil")
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
        end
    end

    --���Ƿ��ַ���
    if (check_param_legality_of_character(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���json��ʽ���
    if (tool.json_check(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Input is not in JSON format.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    local input_json = cjson.decode(param)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input table is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --�����Ϸ���У�飻
    if (check_param_legality(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���ã�
    if (configuration_of_add(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Configuration validation failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�޸������ļ�
    if (sd_config_of_add(input_json, config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Add to sd_config failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�����ļ�
    if (sd_config_of_write(config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Wriet to [%s] failed.", config_file);
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    return error_code["SUCCESS"];
end

function module_add(param)
    --����п�
    if(param == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --param���и�ʽ���
    if (param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    -- ©��ע��У��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    net_debug.lua_debug(net_debug.INFO, "################START################");
    net_debug.lua_debug(net_debug.INFO, "Input: %s", param);

    --�豸������Ϣ��ȡ��
    local res = basic_info_of_device_get()
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Get basic info of device failed.");
        return console.uf_lua_fail(error_code["INIT_FAILED"]);
    end

    --��ȡ�����ļ�
    local config_tab = {};
    if (tool.file_exist(config_file) == true) then
        local config_data = tool.file_read(config_file)
        if (config_data == nil) then
            net_debug.lua_debug(net_debug.ERROR, "file_read failed")
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
        end
        if (tool.json_check(config_data) == false) then
            os.remove(config_file);
            net_debug.lua_debug(net_debug.ERROR, "'%s' not in JSON format", config_data);
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
        end
        config_tab = cjson.decode(config_data)
        if (config_tab == nil) then
            net_debug.lua_debug(net_debug.ERROR, "ERROR: [module_add] config is nil")
            return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
        end
    end

    --���Ƿ��ַ���
    if (check_param_legality_of_character(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���json��ʽ���
    if (tool.json_check(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Input is not in JSON format.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    local input_json = cjson.decode(param)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input table is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --�����Ϸ���У�飻
    if (check_param_legality(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���ã�
    if (configuration_of_add(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Configuration validation failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�޸������ļ�
    if (sd_config_of_add(input_json, config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Add to sd_config failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�����ļ�
    if (sd_config_of_write(config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Wriet to [%s] failed.", config_file);
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    return error_code["SUCCESS"];
end

function module_del(param)
    --����п�
    if(param == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --param���и�ʽ���
    if (param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    -- ©��ע��У��
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    net_debug.lua_debug(net_debug.INFO, "################START################");
    net_debug.lua_debug(net_debug.INFO, "Input: %s", param);

    --�豸������Ϣ��ȡ��
    local res = basic_info_of_device_get()
    if (res == false) then
        net_debug.lua_debug(net_debug.INFO, "Get basic info of device failed.");
        return console.uf_lua_fail(error_code["INIT_FAILED"]);
    end

    --��ȡ�����ļ�
    if (tool.file_exist(config_file) == false) then
        net_debug.lua_debug(net_debug.INFO, "%s is not exist", config_file);
        return error_code["SUCCESS"];
    end
    local config_data = tool.file_read(config_file)
    if (config_data == nil) then
        net_debug.lua_debug(net_debug.ERROR, "ERROR: [module_add] config is nil")
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
    end
    if (tool.json_check(config_data) == false) then
        os.remove(config_file);
        net_debug.lua_debug(net_debug.ERROR, "'%s' not in JSON format", config_data);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    config_tab = cjson.decode(config_data)
    if (config_tab == nil) then
        net_debug.lua_debug(net_debug.ERROR, "ERROR: [module_add] config is nil")
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"])
    end

    --���Ƿ��ַ���
    if (check_param_legality_of_character(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���json��ʽ���
    if (tool.json_check(param) == false) then
        net_debug.lua_debug(net_debug.ERROR, "Input is not in JSON format.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    local input_json = cjson.decode(param)
    if (input_json == nil) then
        net_debug.lua_debug(net_debug.ERROR, "Input table is empty.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --�����Ϸ���У�飻
    if (check_param_legality(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Parameter is illegal.");
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end

    --���ã�
    if (configuration_of_del(input_json) == false) then
        net_debug.lua_debug(net_debug.INFO, "Configuration del failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�޸������ļ�
    if (sd_config_of_del(input_json, config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Add to sd_config failed.");
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    --�����ļ�
    if (sd_config_of_write(config_tab) == false) then
        net_debug.lua_debug(net_debug.INFO, "Wriet to [%s] failed.", config_file);
        return console.uf_lua_fail(error_code["FAILED"]);
    end

    return error_code["SUCCESS"];
end

--δ����
function module_set(param)
    -- ©��ע��У��
    if (param ~= nil and param ~= "" and libc2lua.lua_param_safety_check(param) ~= true) then
        net_debug.lua_debug(net_debug.ERROR, "The input parameter contains illegal characters, Input: %s", param);
        return console.uf_lua_fail(error_code["PARAMETER_ILLEGAL"]);
    end
    return error_code["SUCCESS"];
end

function module_apply()
    net_debug.lua_debug(net_debug.INFO, "INFO: [module_apply]")
    console.forkExec(table.concat({"sh /usr/sbin/manager_ip.sh 2>/dev/null &"}));
end
