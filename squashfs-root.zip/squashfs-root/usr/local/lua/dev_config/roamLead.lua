#!/usr/bin/lua
module("roamLead",package.seeall)
local console = require "console"
local cjson = require("cjson")
local libc2lua = require("libc2lua")
local table = {rcode= "04100500", rmsg= "parameter kickprotect:param is invalid"}

local function debug(msg)
    console.debug("roamLead", msg);
end

local function lock()
    os.execute("lock /tmp/sd_config/roamLead.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/roamLead.lock")
end

local function execute_cmd(method, json_data)
    local cmd = "ubus -t 5 call roam_lead " .. method .. " '" .. cjson.encode(json_data) .. "'"
    debug("exec:" .. cmd)
    os.execute(cmd);
end

function module_default_config_get()
    local default_config = '{"set_cfg": [{"leadInter": "35", "mode": "2", "rssi": "0", "radio":"1"}, {"leadInter": "60", "mode": "2", "rssi": "0", "radio":"2"}]}'
    return default_config
end

function module_set(param)
    debug(param);
    if (param == nil) then
        msg = "input is nil"
        debug(msg)
        return console.uf_lua_fail(table)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        debug(string.format("param is invalid!  param is %s\n", param))
        return console.uf_lua_fail(table)
    end

    local info = cjson.decode(param)
    execute_cmd("set", info)

    return console.uf_lua_success()
end

function module_apply()
end

debug("************" .. os.date("%Y-%m-%d %H:%M:%S") .. "************")

