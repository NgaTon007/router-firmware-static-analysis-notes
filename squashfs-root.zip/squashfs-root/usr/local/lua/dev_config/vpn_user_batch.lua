#! /usr/bin/lua
package.path = "/usr/lib/lua/?.lua;" .. package.path
module("vpn_user_batch",package.seeall)
local libc2lua = require "libc2lua"
local lfs = require "lfs"
local cjson = require "cjson";
local vpn = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/vpn_user/"
local LOCK_FILE = "/tmp/vpn_user/vpn_user_batch.lock"
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "vpn_user_batch.json"});

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
local function debug_init()
    vpn.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "vpn_user_batch.log", 500, vpn.INFO, "1")
end

local function vpn_add_batch(param)
    vpn.lua_debug(vpn.INFO, "###############################ADD###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        vpn.lua_debug(vpn.INFO, "Input data is not json mode.");
        return -1
    end

    param_tab = cjson.decode(param)
    if (param_tab == nil) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_add] param_tab is nil")
        return -1
    end

    for k,v in pairs(param_tab["list"]) do
        local info = {"provider", "password", "username", "netmode", "enable"}
        for i, var in ipairs(info) do
            if (v[var] == nil) then
                vpn.lua_debug(vpn.ERROR, "%s is empty.", var);
                return -1
            end
        end
        local config_tab = cjson.encode(v)
        local cmd = "dev_config add -m vpn_user '"..config_tab.."' >/dev/null 2>&1 &"
        os.execute(cmd)
    end
    vpn.lua_debug(vpn.INFO, "###############################ADD END###############################")
    return 0
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        vpn.lua_debug(vpn.INFO, "Error: There is instance process running")
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        vpn.lua_debug(vpn.INFO, "ok: There no instance process running")
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--------------------------------dev_mode--------------------------------
function module_default_config_get()
    local default_config = '{}'
    return default_config
end

function module_add(input_data, conf_file)
    debug_init();
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        vpn.lua_debug(vpn.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            vpn.lua_debug(vpn.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end
    
    vpn_add_batch(input_data)
    
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        vpn_add_batch(file_data);
    end
    os.remove(LOCK_FILE)
end

function module_apply()
    vpn.lua_debug(vpn.INFO, "module_apply");
    vpn.lua_debug(vpn.INFO, "################################END################################")
end
