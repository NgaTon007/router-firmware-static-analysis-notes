#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("l2tp_client",package.seeall)

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson";
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local ipsec = require "ipsec_cfg_pub"
local sd_crypto = require "sd_crypto"
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local LOCK_FILE = "/tmp/l2tp/client_lock"
local SNOSVPN_DIR = "/var/log/snosvpn/l2tp/"
local SNOSVPN_PPP_CLIENT_LOG = table.concat({SNOSVPN_DIR, "l2tp_pppd_client_log"})
local SNOSVPN_ROUTE = "/tmp/snosvpn/route"
local L2TP_CONTROL_DIR = "/tmp/run/xl2tpd/"
local START_DIR = table.concat({DEBUG_LOG_DIR, "start/"})
local LCP_ECHO_FILE = "/etc/sd_config/single/l2tp_lcp_client_interval.json"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IP_ROUTE_DIR = table.concat({DEBUG_LOG_DIR, "iproute/"})
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "l2tp_client.json"});
local IPTABLES_RULES_FILE = nil;
local IP_ROUTE_FILE = nil;
local lcpechointerval = "30"
local l2tphellointerval = "60"
local LCP_ECHO_FAILURE = "5"
local CLIENT_DIR = nil;
local l2tp_tunnelname = nil;
local tunnelname = nil;

if (tool.file_exist(START_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", START_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(SNOSVPN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SNOSVPN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IP_ROUTE_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IP_ROUTE_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IPTABLES_RULES_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IPTABLES_RULES_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--BugID=808924
if (tool.file_exist(L2TP_CONTROL_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", L2TP_CONTROL_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end
--END

--debug初始化
function debug_init()
    l2tp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "l2tp_client.log", 500, l2tp.INFO, "1");
end

--获取L2TP链路维护时间间隔
local function lcp_echo_interval_get(fn_json)
    if (tool.file_exist(LCP_ECHO_FILE) == true) then
        local file_data = tool.file_read(LCP_ECHO_FILE)
        if (file_data == nil or tool.json_check(file_data) == false) then
            return;
        end
        local json = cjson.decode(file_data)
        if (json["l2tphellointerval"] ~= nil) then
            l2tphellointerval = fn_json["l2tphellointerval"];
        end
        if (json["lcpechointerval"] ~= nil) then
            lcpechointerval = fn_json["lcpechointerval"];
        end
    end

    --L2TP链路维护时间间隔获取
    if (fn_json["l2tphellointerval"] ~= nil) then
        local num = tonumber(fn_json["l2tphellointerval"]);
        if (num ~= nil and num > 10) then
            l2tphellointerval = fn_json["l2tphellointerval"];
        end
    end

    --PPP链路维护时间间隔获取
    if (fn_json["lcpechointerval"] ~= nil) then
        local num = tonumber(fn_json["lcpechointerval"]);
        if (num ~= nil and num > 0) then
            lcpechointerval = fn_json["lcpechointerval"];
        end
    end
end

local function ipsec_set_cfg(op, status, input)
    local ipsec_cfg = {};
    ipsec_cfg["func"] = "ipsec_set_cfg";
    ipsec_cfg["mode"] = "l2tp";
    ipsec_cfg["type"] = "cli";
    ipsec_cfg["op"] = op;
    ipsec_cfg["data"]={};

    ipsec_cfg["data"]["status"] = status;
    ipsec_cfg["data"]["server_ip"] = input["lns"];
    ipsec_cfg["data"]["name"] = input["tunnelname"];
    ipsec_cfg["data"]["secret"] = input["presharekey"];

    if (input["intf_binding"] ~= nil) then
        ipsec_cfg["data"]["intf_binding"] = string.upper(input["intf_binding"]);
    end

    local list = {"ike_proposal", "ph2_proposal", "remote_id_type", "remote_id_value", "exchange_mode", "local_id_type", "local_id_value"}
    for i, var in ipairs(list) do
        if (input[var] ~= nil) then
            ipsec_cfg["data"][var] = input[var];
        end
    end

    local config_tab = cjson.encode(ipsec_cfg)
    if (config_tab ~= nil) then
        --l2tp.lua_debug(l2tp.INFO, "Ipsec set config: %s", config_tab)
    end

    local cmd = "dev_config set -m ipsec '"..config_tab.."'"
    --l2tp.lua_debug(l2tp.INFO, "cmd: %s", cmd)
    --bugid=1261033
    local t = io.popen(cmd)
    t:close()
    --ipsec.ipsec_set(cjson.encode(ipsec_cfg));
    return
end

local function tunnelname_get(tunnel)
    l2tp_tunnelname = tunnel
    if (l2tp_tunnelname == nil) then
        l2tp.lua_debug(l2tp.INFO, "Tunnelname is not exist.");
        return false;
    end
    tunnelname = tool.split(l2tp_tunnelname, "l2tp-")[2];
    if (tunnelname == nil) then
        tunnelname = l2tp_tunnelname;
        l2tp_tunnelname = table.concat({"l2tp-", tunnelname});
    end
    l2tp.lua_debug(l2tp.DEBUG, "tunnelname: %s", tunnelname);
    l2tp.lua_debug(l2tp.DEBUG, "l2tp_tunnelname: %s", l2tp_tunnelname);

    CLIENT_DIR = table.concat({DEBUG_LOG_DIR, tunnelname, "/"});
    if (tool.file_exist(CLIENT_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", CLIENT_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "l2tp_client_", tunnelname});
    IP_ROUTE_FILE = table.concat({IP_ROUTE_DIR, "l2tp_client_", tunnelname});
    return true;
end

local function check_link_status()
    --检查PPP是否断链，如果没有断链，不会触发/etc/ppp/ip-down.d/目录下脚本的执行
    local lock_file = table.concat({CLIENT_DIR, tunnelname, ".lock"});
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    for i = 1, 2, 1 do
        if (tool.file_exist(lock_file) == false and tool.file_exist(up_file) == true) then
            tool.sleep(1);
        end
    end
    os.execute(table.concat({"rm -rf ", lock_file}));
end

local function get_gateway_ipaddr(interface)
    local gateway = nil;

    if (interface == nil) then
        return gateway;
    end
    if (tool.file_exist(SNOSVPN_ROUTE) == false) then
        return gateway;
    end

    local file = io.open(SNOSVPN_ROUTE)
    for line in file:lines() do
        if (line ~= nil and tool.json_check(line) == true) then
            json = cjson.decode(line);
            if (string.lower(json["interface"]) == string.lower(interface)) then
                gateway = json["gateway"];
            end
        end
    end
    io.close(file);

    return gateway;
end

local function client_start_pppd(fn_json)
    local optfile = table.concat({CLIENT_DIR, "options.", tunnelname})
    local startfile = table.concat({START_DIR, "start_", tunnelname})
    local file = assert(io.open(optfile, "w+"));
    if (fn_json["local_ip"] ~= nil and fn_json["local_ip"] ~= "") then
        file:write(fn_json["local_ip"], ":\n");
    end
    file:write("debug\n");
    file:write("maxfail 0\n");
    file:write("persist\n");
    file:write("usepeerdns\n");
    file:write("noccp\n");
    file:write("novj\n");
    file:write("novjccomp\n");
    file:write("nopcomp\n");
    file:write("noaccomp\n");
    file:write("noipdefault\n");
    file:write("mtu 1360\n");
    file:write("mru 1360\n");
    file:write("nodefaultroute\n");
    file:write("ip-up-script /lib/netifd/ppp-up\n");
    file:write("ipv6-up-script /lib/netifd/ppp-up\n");
    file:write("ip-down-script /lib/netifd/ppp-down\n");
    file:write("ipv6-down-script /lib/netifd/ppp-down\n");
    file:write("logfile ", SNOSVPN_PPP_CLIENT_LOG, "\n");
    file:write("lcp-echo-failure ", LCP_ECHO_FAILURE, "\n");
    file:write("lcp-echo-interval ", lcpechointerval, "\n");
    file:write("user '", fn_json["username"], "'\n");
    file:write("password '", fn_json["password"], "'\n");
    file:write("ifname '", l2tp_tunnelname, "'\n");
    file:close(file);
    --删除pppd客户端日志
    if (tool.file_exist(SNOSVPN_PPP_CLIENT_LOG) == true) then
        os.execute("rm -rf /tmp/log/snosvpn/l2tp/l2tp_pppd_client_log*");
    end

    if (fn_json["challenge"] ==  nil) then
        fn_json["challenge"] = "no"
    end

    if (fn_json["enable"] == "1") then
        file = assert(io.open(startfile, "w+"));
        file:write("touch /tmp/l2tp/l2tp/l2tp_lock 2>/dev/null\n");
        file:write("ipset del zone_vpn_1701_reject ", fn_json["lns"], " 2>/dev/null\n");
        file:write("xl2tpd-control disconnect ", l2tp_tunnelname, " && xl2tpd-control remove ", l2tp_tunnelname, " 2>/dev/null\n");
        file:write("sleep 5\n");
        file:write("xl2tpd-control add ", l2tp_tunnelname, " pppoptfile=", optfile, " lns=", fn_json["lns"], " redial=yes redial timeout=", l2tphellointerval," challenge=", fn_json["challenge"], " outiface=", string.lower(fn_json["intf_binding"]), " tunnelname=", tunnelname, " 2>/dev/null\n");
        file:write("xl2tpd-control connect ", l2tp_tunnelname, " 2>/dev/null\n");
        file:write("ubus -t 3 send l2tp_client_monitor\n");
        file:write("rm -rf /tmp/l2tp/l2tp/l2tp_lock\n");
        file:close(file);
        os.execute(table.concat({"chmod +x ", startfile}));
        os.execute("ubus -t 3 send l2tp_client_connect");
    else
        os.remove(startfile);
    end
    if (fn_json["challenge"] == "yes" and fn_json["tunnelkey"]~= "") then
        --/etc目录下的xl2tpd隧道认证密码作为降级备份恢复为未加密隧道,不加密版本是使用etc目录
        local authfile = io.open("/etc/xl2tpd/xl2tp-secrets", "w+");
        if (authfile ~= nil) then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(fn_json["tunnelkey"],#fn_json["tunnelkey"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
            else
                authfile:write("# Secrets for authenticating l2tp tunnels\n");
                authfile:write("# us\tthem\tsecret\n");
                authfile:write("*\t*\t", ciphertext, "\n");
                authfile:close(authfile);
            end
        end
        local tmpfile = io.open("/tmp/xl2tpd/xl2tp-secrets", "w+");
        if (tmpfile ~= nil) then
            tmpfile:write("# Secrets for authenticating l2tp tunnels\n");
            tmpfile:write("# us\tthem\tsecret\n");
            tmpfile:write("*\t*\t", fn_json["tunnelkey"], "\n");
            tmpfile:close(tmpfile);
        end
    else
        os.execute(table.concat({"echo > ", "/etc/xl2tpd/xl2tp-secrets"}));
        os.execute(table.concat({"echo > ", "/tmp/xl2tpd/xl2tp-secrets"}));
    end
end

local function client_stop_pppd(fn_json)
    local cmd = nil;
    local startfile = table.concat({START_DIR, "start_", tunnelname})
    os.remove(startfile);

    l2tp.lua_debug(l2tp.INFO, "Disconnect tunnel: %s", l2tp_tunnelname);
    cmd = table.concat({"xl2tpd-control disconnect ", l2tp_tunnelname, " && xl2tpd-control remove ", l2tp_tunnelname});
    l2tp.lua_debug(l2tp.INFO, "%s", cmd);
    os.execute(cmd);

    --检查链接是否断开
    check_link_status()
end

local function l2tp_client_encrypt_config(config_json)
    local recode;
    local ciphertext;
    if config_json["encType"] == nil or config_json["encType"] == 0 then
        if config_json["password"] ~= nil then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(config_json["password"],#config_json["password"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
                return
            else
                config_json["password"] = tostring(ciphertext)
            end
        end
        if config_json["tunnelkey"] ~= "nil" and config_json["tunnelkey"] ~= "" then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(config_json["tunnelkey"],#config_json["tunnelkey"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
                return
            else
                config_json["tunnelkey"] = tostring(ciphertext)
            end
        end
        if config_json["presharekey"] ~= "nil" and config_json["presharekey"] ~= "" then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(config_json["presharekey"],#config_json["presharekey"],'C')
            if (recode ~= 0) then
                l2tp.lua_debug(l2tp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
                return
            else
                config_json["presharekey"] = tostring(ciphertext)
            end
        end
        config_json["encType"] = 1;
    end
end

local function save_sd_config(fn_json, file)
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end

    if (json["list"] == nil or json["list"][1]["tunnelname"] == nil) then
        json["list"] = {}
    end
    local check = -1;
    local length = table.maxn(json.list);
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == tunnelname) then
            check = i;
        end
    end
    if (check ~= -1) then
        table.remove(json.list, check)
    end

    local length = table.maxn(json["list"]);
    json["total"] = tostring(length + 1);
    l2tp_client_encrypt_config(fn_json);
    table.insert(json.list, fn_json);
    --l2tp.lua_debug(l2tp.INFO, "Save config: %s", cjson.encode(json));
    tool.file_write(file, cjson.encode(json));
end

local function delete_from_sd_config(file)
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end

    if (json["list"] == nil or next(json["list"]) == nil or json["list"][1]["tunnelname"] == nil) then
        json["list"] = {}
    end
    local check = -1;
    local length = table.maxn(json.list);
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == tunnelname) then
            check = i;
        end
    end
    if (check ~= -1) then
        table.remove(json.list, check)
    end

    local length = table.maxn(json["list"]);
    json["total"] = tostring(length);
    --l2tp.lua_debug(l2tp.INFO, "Save config: %s", cjson.encode(json));
    tool.file_write(file, cjson.encode(json));
end

function update_ipsec_set_cfg(fn_json)
    if (fn_json["enable"] == "0") then
        if (fn_json["ipsecenc"] == "yes") then
            ipsec_set_cfg("delete", nil, fn_json);
            ipsec_set_cfg( "add", "disable", fn_json);
        else
            ipsec_set_cfg("delete", nil, fn_json);
        end
    else
        if (fn_json["ipsecenc"] == "yes") then
            ipsec_set_cfg("delete", nil, fn_json);
            ipsec_set_cfg( "add", "enable", fn_json);
        else
            ipsec_set_cfg("delete", nil, fn_json);
        end
    end
end

----------------------------------------------------------------------------------------------------
function l2tp_update(input_data, conf_file)
    l2tp.lua_debug(l2tp.INFO, "###############################UPDATE###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Input data is not json mode.");
        return;
    end

    --l2tp.lua_debug(l2tp.INFO, "Input data: %s", input_data);
    local input_json = cjson.decode(input_data);
    local list = {"enable", "remotesubnet", "tunnelname", "lns", "ipsecenc", "workmode"}
    for i, var in ipairs(list) do
        if (input_json[var] == nil) then
            l2tp.lua_debug(l2tp.ERROR, "%s is empty.", var);
            return;
        end
    end

    --隧道名称获取
    ret = tunnelname_get(input_json["tunnelname"]);
    if (ret == false) then
        return;
    end

    --PPP链路维护时间间隔获取
    lcp_echo_interval_get(input_json);

    --获取就配置
    local old_data = nil;
    local INPUT_SAVE = table.concat({CLIENT_DIR, "input_save"});
    if (tool.file_exist(INPUT_SAVE) == true) then
        old_data = tool.file_read(INPUT_SAVE);
    end

    --输入保存,用于路由规则设置
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        l2tp.lua_debug(l2tp.INFO, "Input save fail.");
        return;
    end

    --删除旧配置
    if (old_data ~= nil and tool.json_check(old_data) == true) then
        --l2tp.lua_debug(l2tp.INFO, "Old data: %s", old_data);
        old_json = cjson.decode(old_data);
        client_stop_pppd(old_json);
    end

    --更新
    update_ipsec_set_cfg(input_json);
    if (input_json["enable"] == "1") then
        uci:set("xl2tpd", "client", "enable", "1");
    else
        uci:set("xl2tpd", "client", "enable", "0");
    end
    uci:commit("xl2tpd");

    --启动xl2tp
    client_start_pppd(input_json);

    --写入json配置文件
    save_sd_config(input_json, conf_file)

    l2tp.lua_debug(l2tp.INFO, "################################END################################");
end

--@module_add
function l2tp_add(input_data, conf_file)
    l2tp.lua_debug(l2tp.INFO, "###############################UPDATE###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Input data is not json mode.");
        return;
    end
    --l2tp.lua_debug(l2tp.INFO, "Input data: %s", input_data);
    local input_json = cjson.decode(input_data);
    local list = {"enable", "remotesubnet", "tunnelname", "lns", "ipsecenc", "workmode"}
    for i, var in ipairs(list) do
        if (input_json[var] == nil) then
            l2tp.lua_debug(l2tp.ERROR, "%s is empty.", var);
            return;
        end
    end

    --隧道名称获取
    ret = tunnelname_get(input_json["tunnelname"]);
    if (ret == false) then
        return;
    end

    --PPP链路维护时间间隔获取
    lcp_echo_interval_get(input_json);

    --输入保存,用于路由规则设置
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        l2tp.lua_debug(l2tp.INFO, "Input save fail.");
        return;
    end

    --如果隧道名称相同直接返回
    local file_data = tool.file_read(conf_file)
    if (file_data == nil or tool.json_check(file_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Old config is not json mode.");
        return;
    end
    local json = cjson.decode(file_data)
    if (json["list"] == nil) then
        json["list"] = {}
    end
    local length = table.maxn(json.list)
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == data["tunnelname"]) then
            l2tp.lua_debug(l2tp.INFO, "%s is exist.", json["list"][i]["tunnelname"]);
            return
        end
    end

    --更新
    update_ipsec_set_cfg(input_json);

    --启动xl2tp
    client_start_pppd(input_json);

    --写入json配置文件
    save_sd_config(input_json, conf_file)
    l2tp.lua_debug(l2tp.INFO, "################################END################################");
end

--@module_del
function l2tp_del(input_data, conf_file)
    l2tp.lua_debug(l2tp.INFO, "###############################DELETE###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.INFO, "Input data is not json mode.");
        return;
    end
    --l2tp.lua_debug(l2tp.INFO, "Input data: %s", input_data);
    local data = cjson.decode(input_data);
    for i, tunnelname in ipairs(data["tunnelname"]) do
        --隧道名称获取
        ret = tunnelname_get(tunnelname);
        if (ret == false) then
            return;
        end

        --获取就配置
        local old_data = nil;
        local INPUT_SAVE = table.concat({CLIENT_DIR, "input_save"});
        if (tool.file_exist(INPUT_SAVE) == true) then
            old_data = tool.file_read(INPUT_SAVE);
        end

        --删除旧配置
        if (old_data ~= nil and tool.json_check(old_data) == true) then
            l2tp.lua_debug(l2tp.INFO, "Old data: %s", old_data);
            old_json = cjson.decode(old_data);
            client_stop_pppd(old_json);
            if (old_json["ipsecenc"] == "yes") then
                ipsec_set_cfg("delete", nil, old_json);
            end
        end
        local OPTION_FILE = table.concat({CLIENT_DIR, "options.", tunnelname});
        os.execute(table.concat({"rm -rf ", CLIENT_DIR}));
        delete_from_sd_config(conf_file)
    end
    l2tp.lua_debug(l2tp.INFO, "################################END################################");
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local lfs = require "lfs"
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        l2tp.lua_debug(l2tp.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        l2tp.lua_debug(l2tp.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    local default_config = '{"list":[{"enable":"0"}]}'
    return default_config
end

function module_update(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_update] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_update] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
     if string.match(input_data, "\\n") then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, ">") then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end

    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    l2tp_update(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        l2tp_update(file_data, conf_file);
    end

    --启动监控
    os.remove(LOCK_FILE);
end

--@module_add
function module_add(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    l2tp_add(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        l2tp_add(file_data, conf_file);
    end

    --启动监控
    os.remove(LOCK_FILE);
end

--@module_del
function module_del(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    l2tp_del(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        l2tp_del(file_data, conf_file);
    end
    os.remove(LOCK_FILE);
end

function module_apply()
    l2tp.lua_debug(l2tp.DEBUG, "module_apply");
end

function module_set()
    l2tp.lua_debug(l2tp.DEBUG, "module_set");
end
