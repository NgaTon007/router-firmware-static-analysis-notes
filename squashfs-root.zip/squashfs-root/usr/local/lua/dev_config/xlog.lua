#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("xlog", package.seeall)

local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua");
local ip = require "luci.ip"
local DEBUG_DIR_LOGFILE = "/tmp/xlog/web/"
local console = require "console"
local LOCK_FILE = "/tmp/xlog/web/xlog.lock"
local XLOG_JSON_FILE = "/etc/sd_config/single/xlog.json"
local SD_CONFIG_FILE = table.concat({DEBUG_DIR_LOGFILE, "xlog.json"})
local UBUS_ADD_SERVER = "ubus call xlog.server set"
local NAT_LOG_DISABLE = "dev_config set -m nat_log '{\"xlog_enable\": \"0\"}' >/dev/null 2>&1 &"
local NAT_LOG_ENABLE = "dev_config set -m nat_log '{\"xlog_enable\": \"1\"}' >/dev/null 2>&1 &"
local URL_LOG_DISABLE = "/usr/bin/lua /usr/sbin/web/ca_set_url_log_enable.lua '{\"enable\": \"0\", \"log_type\": \"xlog\"}' >/dev/null 2>&1 &"
local URL_LOG_ENABLE = "/usr/bin/lua /usr/sbin/web/ca_set_url_log_enable.lua '{\"enable\": \"1\", \"log_type\": \"xlog\"}' >/dev/null 2>&1 &"
local AUTH_USER_LOG_DISABLE = "/usr/bin/lua /usr/sbin/web/app_auth_set_user_log.lua '{\"xlog_enable\": \"0\"}' >/dev/null 2>&1 &"
local AUTH_USER_LOG_ENABLE = "/usr/bin/lua /usr/sbin/web/app_auth_set_user_log.lua '{\"xlog_enable\": \"1\"}' >/dev/null 2>&1 &"
local XLOG_SQL_JSON_FILE = "/etc/sd_config/single/storageManage.json"
local table_input_err = {rcode = "05540001", rmsg = "input_data is error"}
local table_server_num_err = {rcode = "05540002", rmsg = "number of servers has reached its maximum"}
local table_domain_err = {rcode = "05540003", rmsg = "Failed domain resolution"}

if (tool.file_exist(DEBUG_DIR_LOGFILE) == false) then
    local path = "mkdir -p " .. DEBUG_DIR_LOGFILE .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
local function debug_init()
    module_debug.debug_init(DEBUG_DIR_LOGFILE, "xlog_dev_config.log", 500, module_debug.INFO, "1");
end

function lua_string_split(str, split_char)
    local sub_str_tab = {}
    while (true) do
        local pos = string.find(str, split_char)
        if (not pos) then
            sub_str_tab[#sub_str_tab+1] = str
            break
        end
        local sub_str = string.sub(str, 1, pos - 1)
        sub_str_tab[#sub_str_tab + 1] = sub_str
        str = string.sub(str, pos + 1, #str)
    end
    return sub_str_tab
end

local function domain_name_transfer_to_ip(domain_name)
    if domain_name == nil then
        return nil
    end

    local t = io.popen("nslookup "..domain_name.." | grep 'Address' | awk '{print $3}'")
    local dns_ret = t:read("*all")
    local ipaddr = lua_string_split(dns_ret, "\n")

    for i=2,#ipaddr do
        if nil ~= ip.IPv4(ipaddr[i]) and ipaddr[i] ~= '0.0.0.0' and ipaddr[i] ~= '127.0.0.1' then
            return ipaddr[i]
        end
    end

    return nil
end

local function server_cfg_save(sectionname, cfg, t_bind, op)
    local log_info_list = {}

    if (cfg["intf_binding"] == "WAN0") then
        cfg["intf_binding"] = "WAN"
    elseif (cfg["intf_binding"] == "LAN0") then
        cfg["intf_binding"] = "LAN"
    end

    local intf =string.lower(cfg["intf_binding"])
    if (intf ~= "auto") then
        intf = "br-"..intf
    end
    module_debug.lua_debug(module_debug.INFO, "intf: %s", intf)

    if (op == "update") then
        uci:delete("xlog", sectionname)
    end

    if nil == ip.IPv4(cfg.server_address) then
        module_debug.lua_debug(module_debug.INFO, "server_address: %s", cfg.server_address)
        cfg["server_address"] = domain_name_transfer_to_ip(cfg.server_address)
        if cfg["server_address"] == nil or cfg["server_address"] == "" then
            module_debug.lua_debug(module_debug.INFO, "cfg[server_address] is nil")
            return -3
        end
        module_debug.lua_debug(module_debug.INFO, "transform server_address: %s", cfg.server_address)
    else
        module_debug.lua_debug(module_debug.INFO, "server_address: %s", cfg.server_address)
    end

    t_bind["server_id"] = tonumber(cfg["server_id"])
    t_bind["server_switch"] = cfg["server_switch"]
    t_bind["server_address"] = cfg["server_address"]
    t_bind["server_port"] = tonumber(cfg["server_port"])
    t_bind["intf_binding"] = intf
    t_bind["export_rate"] = tonumber(cfg["export_rate"])
    t_bind["server_type"] = cfg["server_type"]
    t_bind["log_info"] = cfg["log_info"]
    uci:set("xlog", sectionname, "server")
    uci:set("xlog", sectionname, "server_switch", cfg["server_switch"])
    uci:set("xlog", sectionname, "server_address", cfg["server_address"])
    uci:set("xlog", sectionname, "server_port", cfg["server_port"])
    uci:set("xlog", sectionname, "server_type", cfg["server_type"])
    uci:set("xlog", sectionname, "iface", intf)
    uci:set("xlog", sectionname, "export_rate", cfg["export_rate"])
    for m, log_msg in pairs(cfg["log_info"]) do
        log_info_list[m] = log_msg["log_name_prio"]
        uci:set("xlog", sectionname, "log_type", log_info_list)
    end
    uci:commit("xlog")
    return 0
end

local function save_sd_config(fn_json, file)
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end

    if (json["list"][1] == nil or json["list"][1]["server_id"] == nil) then
        json["list"] = {}
    end
    local check = -1;
    local length = table.maxn(json.list);
    for i = 1, length, 1 do
        if (json["list"][i]["server_id"] == fn_json["server_id"]) then
            check = i;
        end
    end
    if (check ~= -1) then
        table.remove(json.list, check)
    end

    local length = table.maxn(json["list"])
    json["total"] = tostring(length + 1)
    table.insert(json.list, fn_json)
    module_debug.lua_debug(module_debug.INFO, "Save config: %s", cjson.encode(json))
    tool.file_write(file, cjson.encode(json))
end

local function add_server_config(bind)
    local ubus_server_bind = {}
    local nat_log_enable = 0
    local url_log_enable = 0
    local auth_user_log_enable = 0
    local ret = -1
    local sql_auth_user_log_enable = 0
    local sql_nat_log_enable = 0
    local sql_dhcp_log_enable = 0
    local server_id = nil
    local uci_server_id = nil
    local is_new_server = false

    server_id = bind["server_id"] or ""

    module_debug.lua_debug(module_debug.INFO, "server_id = %s", server_id)

    -- 如果没有传入server_id，则从uci中获取
    if server_id == "" then
        uci_server_id = uci:get_first("xlog", "server")
        if uci_server_id == nil then
            is_new_server = true
        else
            module_debug.lua_debug(module_debug.INFO, "uci server_id = %s", uci_server_id)
            bind["server_id"] = uci_server_id
        end
    end

    if (is_new_server) then   --新增服务器
        module_debug.lua_debug(module_debug.INFO, "[module_add]add server")
        section_name = uci:get("xlog", "main", "server_cap")
        server_id = tonumber(section_name)
        if (server_id > 20) then
            module_debug.lua_debug(module_debug.ERROR, "The automatic ID[%d] assigned has exceeded 20", server_id)
            return -2
        else
            uci:set("xlog", "main", "server_cap", tostring(server_id+1))
        end
        bind["server_id"] = section_name
        ret = server_cfg_save(section_name, bind, ubus_server_bind, "add")
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "server_cfg_save is err.")
            return ret
        end
        save_sd_config(bind, XLOG_JSON_FILE)
        config_bind = cjson.encode(ubus_server_bind)
        if (config_bind ~= nil) then
            add_ubus_server = UBUS_ADD_SERVER .." '"..config_bind.."' >/dev/null 2>&1"
            module_debug.lua_debug(module_debug.INFO, "add_ubus_server = %s", add_ubus_server)
            os.execute(add_ubus_server)
        end
    else    --更新服务器参数
        module_debug.lua_debug(module_debug.INFO, "[module_add]update server")
        ret = server_cfg_save(bind["server_id"], bind, ubus_server_bind, "update")
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "server_cfg_save is err.")
            return ret
        end
        save_sd_config(bind, XLOG_JSON_FILE)
        config_bind = cjson.encode(ubus_server_bind)
        if (config_bind ~= nil) then
            add_ubus_server = UBUS_ADD_SERVER.." '"..config_bind.."' >/dev/null 2>&1"
            module_debug.lua_debug(module_debug.INFO, "add_ubus_server = %s", add_ubus_server)
            os.execute(add_ubus_server)
        end
    end

    for n, log_table in pairs(bind["log_info"]) do
        local tab = tool.split(log_table["log_name_prio"], ":")
        module_debug.lua_debug(module_debug.INFO, "tab[1]:%s, tab[2]:%s", tab[1], tab[2])
        if (tonumber(bind["server_switch"]) == 1) then
            if (tab[1] == "nat") then
                nat_log_enable = 1
            elseif (tab[1] == "url") then
                url_log_enable = 1
            elseif (tab[1] == "auth_user") then
                auth_user_log_enable = 1
            end
        end
    end

    --加有关xlog_sql的功能
    if (tool.file_exist(XLOG_SQL_JSON_FILE) ~= false) then
        local xlog_sql_cfg = tool.file_read(XLOG_SQL_JSON_FILE)
        if (xlog_sql_cfg ~= nil) then
            local xlog_sql_cfg_tab = cjson.decode(xlog_sql_cfg)
            for id, tbl in pairs(xlog_sql_cfg_tab["componetList"]) do
                if (tbl["type"] == "nat" and tbl["enable"] == "on") then
                    sql_nat_log_enable = 1
                    module_debug.lua_debug(module_debug.INFO, "sql_nat_log_enable == 1");
                elseif (tbl["type"] == "auth" and tbl["enable"] == "on") then
                    sql_auth_user_log_enable = 1
                    module_debug.lua_debug(module_debug.INFO, "sql_auth_user_log_enable == 1");
                elseif (tbl["type"] == "dhcp" and tbl["enable"] == "on") then
                    sql_dhcp_log_enable = 1
                    module_debug.lua_debug(module_debug.INFO, "sql_dhcp_log_enable == 1");
                elseif (tbl["type"] == "url" and tbl["enable"] == "on") then
                    url_log_enable = 1
                    module_debug.lua_debug(module_debug.INFO, "sql_url_log_enable == 1");
                end
            end
        end
    end

    if (nat_log_enable == 1) then
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(NAT_LOG_ENABLE)
    elseif (nat_log_enable == 0 and sql_nat_log_enable == 0) then
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(NAT_LOG_DISABLE)
    end

    if (url_log_enable == 1) then
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(URL_LOG_ENABLE)
    else
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(URL_LOG_DISABLE)
    end

    if (auth_user_log_enable == 1) then
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(AUTH_USER_LOG_ENABLE)
    elseif (auth_user_log_enable == 0 and sql_auth_user_log_enable == 0) then
        os.execute("exec 1>/tmp/null 2>&1")
        os.execute(AUTH_USER_LOG_DISABLE)
    end

    if (tonumber(bind["server_switch"]) == 0 and sql_nat_log_enable == 0 and sql_auth_user_log_enable == 0 and sql_dhcp_log_enable == 0) then
        module_debug.lua_debug(module_debug.INFO, "/etc/init.d/xlog stop");
        uci:set("xlog", "main", "enable", 0)
        uci:commit("xlog")
        os.execute("/etc/init.d/xlog stop 2>/dev/null")
    end
    return 0
end

local function xlog_add(param)
    module_debug.lua_debug(module_debug.INFO, "###############################ADD###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "input data:%s", param)

    param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param_tab is nil")
        return -1
    end

    for k,v in pairs(param_tab["list"]) do
        local info = {"server_id", "server_switch", "server_address", "server_port", "intf_binding", "server_type", "log_info"}
        for i, var in ipairs(info) do
            if (v[var] == nil) then
                module_debug.lua_debug(module_debug.ERROR, "%s is empty.", var);
                return -1
            end
        end
        if v.server_switch == "1" then
            module_debug.lua_debug(module_debug.INFO, "/etc/init.d/xlog start");
            uci:set("xlog", "main", "enable", 1)
            uci:commit("xlog")
            os.execute("/etc/init.d/xlog start 2>/dev/null")
        end
        ret = add_server_config(v)
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] add_config_bind is failed param is %s", param)
            return ret
        end
    end
    module_debug.lua_debug(module_debug.INFO, "###############################ADD END###############################");
    return 0
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    module_debug.lua_debug(module_debug.INFO, "module_default_config_get")
    local default_config = '{"list":[{"server_switch":"0"}]}'
    return default_config
end

function check_result(ret)
    if ret == "0000" or ret == 0 then
        return console.uf_lua_success()
    elseif ret == "0001" or ret == -1 then
        return console.uf_lua_fail(table_input_err)
    elseif ret == "0002" or ret == -2 then
        return console.uf_lua_fail(table_server_num_err)
    elseif ret == "0003" or ret == -3 then
        return console.uf_lua_fail(table_domain_err)
    else
        -- 添加一个默认情况来处理未定义的返回值
        return console.uf_lua_fail({rcode = "05549999", rmsg = "unknown error"})
    end
end

--@dev_mode_add
function module_add(input_data)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        --return "{\"code\":\"1\",\"msg\":\"input_data is unsafe!\"}"
        return check_result("0001")
    end

    if string.match(input_data, "\\n") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        --return "{\"code\":\"1\",\"msg\":\"input_data is unsafe!\"}"
        return check_result("0001")
    end

    if string.match(input_data, ">") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        --return "{\"code\":\"1\",\"msg\":\"input_data is unsafe!\"}"
        return check_result("0001")
    end

    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return check_result("0000")
    end

    ret = xlog_add(input_data)
    if (ret ~= 0) then
        os.remove(LOCK_FILE)
        --return "{\"code\":\"1\",\"msg\":\"input_data is error!\"}"
        return check_result(ret)
    end

    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE)
        ret = xlog_add(file_data)
        if (ret ~= 0) then
            os.remove(LOCK_FILE)
            --return "{\"code\":\"1\",\"msg\":\"input_data is error!\"}"
            return check_result(ret)
        end
    end
    --启动监控
    os.remove(LOCK_FILE);
    return check_result("0000")
end

function module_set(input_data)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] input_data is unsafe")
        if (input_data ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] input_data %s", input_data)
        end
        --return "{\"code\":\"1\",\"msg\":\"input_data is unsafe!\"}"
        return check_result("0001")
    end
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end
