#! /usr/bin/lua

module("mesh", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local sys = require "luci.sys"
local libc2lua = require("libc2lua")
local sd_product = require("product")
local repeater_cfg = 'repeater'

local web_cap_key = sd_product.get_product("capacity.web");

--debug
local function debug(msg)
    console.debug("mesh", msg)
end

local function lock()
    os.execute("lock /tmp/sd_config/mesh.lock")
end

local function unlock()
    os.execute("lock -u /tmp/sd_config/mesh.lock")
end

function module_default_config_get()
    local data = {}
    data.rlink_enable = "true"
    return dkjson.encode(data)
end

function repeater_ssid_set(switch_enable)
    local cmd
    debug("Set Repeater in wireless module")
    local data = {repeater = tostring(switch_enable)}
    cmd = string.format("dev_sta update -m wireless \'%s\'", dkjson.encode(data))
    debug(cmd)
    console.forkExec(cmd)
end

local function is_apmesh_relay()
    local lib_mesh = require "utils.mesh_com"
    local radiolist_cache = lib_mesh.get_radio_info()
    uci:load(repeater_cfg)
    for i, device in ipairs(radiolist_cache) do
        local apcli_cfg = uci:get_all(repeater_cfg, device.name) or {}
        local apcli_ssid = apcli_cfg.ApCliSsid
        local is_mesh = apcli_cfg.isMesh
        local apcli_enable = apcli_cfg.ApCliEnable
        if apcli_enable and apcli_enable == '1' then
            if lib_mesh.is_apmesh_ssid(apcli_ssid, is_mesh) == true then
                lib_mesh.mesh_com_close_wireless_repeater()
                return true
            end
        end
    end
    return false
end

function do_mesh_action(param)
    -- 入参检查，防止shell注入安全漏洞  
    if (param ~= nil) then
        if (libc2lua.lua_param_safety_check(param) ~= true) then
            debug(string.format("param is invalid!  param is %s\n", param))
            return false
        end
    end
    local paramTable = dkjson.decode(param)
    local PROC="/sbin/apmgr"
    local proc_exit = sys.exec(string.format("ps -w |grep %s|grep -v grep", PROC))
    local sd_device_file = string.format("/tmp/sd_device/sd_device.json")
    local cmd
    local is_apmesh
    local is_sup_wifi
    local data
    local autoJoin = uci:get_first("sysinfo", "sysinfo", "autoJoin")
    local relayMode = uci:get_first("sysinfo", "sysinfo", "relayMode")

    debug("autoJoin: "..autoJoin)
    if console.is_file_exist(sd_device_file) then
        data = dkjson.decode(console.read_file(sd_device_file))
        if not data then
            debug("sd_device json decode is not exist")
        else
            is_apmesh = data[web_cap_key].ap_mesh
            is_sup_wifi = data.ap_mesh.mesh_support_wifi
        end
    end
    debug("is_apmesh: "..is_apmesh)
    debug("is_sup_wifi: "..is_sup_wifi)
    if paramTable and paramTable.rlink_enable and paramTable.rlink_enable == "true" then
        --add this to judge autoJoin, fix bugid 832627
        if (autoJoin ~= "true") then
            return false
        end
        if (autoJoin == "true" and is_apmesh == "1") then 
            uci:set("apmgr", "global", "rlink_enable", "1")
            uci:commit("apmgr")
            os.execute("sync")
            debug("(apmesh)/etc/init.d/apmgr start")
            console.forkExec("/etc/init.d/apmgr start")
            debug("(apmesh)end set true apmgr")
        elseif (is_apmesh ~= "1") then
            uci:set("apmgr", "global", "rlink_enable", "1")
            uci:commit("apmgr")
            os.execute("sync")
            debug("(apmgr)/etc/init.d/apmgr start")
            console.forkExec("/etc/init.d/apmgr start")
            debug("(apmgr)end set true apmgr")
        end
    elseif paramTable and paramTable.rlink_enable and paramTable.rlink_enable == "false" then
        uci:set("apmgr", "global", "rlink_enable", "0")
        uci:commit("apmgr")
        os.execute("sync")
        debug("/etc/init.d/apmgr stop")
        os.execute("sleep 2")
        console.forkExec("/etc/init.d/apmgr stop")
        if (is_apmesh ~= "1") then 
            return true
        end
        if (is_sup_wifi ~= "1") then
            return true
        end
        --clr repeater cfg and change relaymode to none
        if is_apmesh_relay() == true  then
            debug("close mesh relay")
            if relayMode == "wirelessBridge" then
                local lib_mesh = require "utils.mesh_com"
                lib_mesh.mesh_com_close_wireless_repeater()
                debug(string.format("current mode is %s, need recovery sysinfo!", relayMode))
                cmd = string.format("dev_config set --module \"dev_mode\" '{\"user\":\"apmesh\",\"version\":\"1.5.0\",\"forwardMode\":\"AP\",\"relayMode\":\"none\",\"autoJoin\":\"true\",\"acEnable\":\"false\"}'")
                debug("cmd6: "..cmd)
                console.forkExec(cmd)
            end
        end

        local alone_intf_enable = uci:get_first("apmgr", "global", "alone_intf_enable") or "0"
        if alone_intf_enable and alone_intf_enable == '1' then
            debug("###cmd7: lua /usr/lib/lua/smb/apmesh_create_alone_intf.lua disable")
            os.execute("lua /usr/lib/lua/smb/apmesh_create_alone_intf.lua disable")
        end

        repeater_ssid_set(false)
        debug("end set false apmgr")
    else
        return false
    end
    return true
end

function module_set(param)
    local table = {rcode= "04090014", rmsg= "parameter mesh:rlink_enable is invalid, require <true|false>"}
    lock()
    if do_mesh_action(param) == false then
        unlock()
        return console.uf_lua_fail(table)
    end
    unlock()
    return console.uf_lua_success()
end

function module_get(param)
    local data = {}
    local rlink_enable = uci:get("apmgr",'global','rlink_enable') or '0'
    data.rlink_enable = rlink_enable == "1" and "true" or "false"
    return dkjson.encode(data)
end

