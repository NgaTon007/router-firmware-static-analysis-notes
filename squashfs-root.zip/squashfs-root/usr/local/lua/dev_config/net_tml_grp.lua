#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml_grp",package.seeall)
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua");
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml_grp.lock"
local NT_GRP_JSON_FILE = "/etc/sd_config/single/net_tml_grp.json"
local NT_GRP_UCI_CFG = "/etc/config/net_tml_grp"
local console = require "console"

if (tool.file_exist(NT_GRP_UCI_CFG) == false) then
    tool.exec("touch /etc/config/net_tml_grp")
end

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

local table1 = {rcode= "05510001", rmsg= "The command execute failed"}
local table2 = {rcode= "05510002", rmsg= "The number of terminal groups has reached the upper limit"}
local table3 = {rcode= "05510003", rmsg= "The group name is exist"}
local table4 = {rcode= "05510004", rmsg= "The group rule is exist"}

--debug初始化
function debug_init()
module_debug.debug_init(DEBUG_LOG_DIR, "net_tml_grp.log", 100, module_debug.DEBUG, "1")
end

function check_result(ret)
    if ret == "0000" then
            return console.uf_lua_success()
    elseif ret == "0001" then
            return console.uf_lua_fail(table1)
    elseif ret == "0002" then
            return console.uf_lua_fail(table2)
    elseif ret == "0003" then
            return console.uf_lua_fail(table3)
    elseif ret == "0004" then
            return console.uf_lua_fail(table4)
    end
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- ubus执行，及返回值并判断
local function ubus_cmd_exe(ubus_cmd)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd %s", ubus_cmd)

    if (string.match(ubus_cmd, "([&|;])") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [ubus_cmd] is dangrous")
        return -1
    end

    sh_ret = {}
    sh_ret = cjson.decode(tool.exec(ubus_cmd))

    if (sh_ret["code"] == nil or sh_ret["code"] ~= "0") then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: ubus execute fail")
        return -1
    end

    return 0
end

--混合网下发的数据是写到uci 由进程读取，所以必须先 uci:commit 一旦进程执行失败 uci文件必须还原成先前的配置
local function office_mesh_uci_config_handle(param_tab)
    uci_config = tool.file_read(NT_GRP_UCI_CFG)
    --module_debug.lua_debug(module_debug.ERROR, "%s old", tool.file_read(NT_GRP_UCI_CFG))
    uci:commit("net_tml_grp")
    --module_debug.lua_debug(module_debug.ERROR, "%s new",tool.file_read(NT_GRP_UCI_CFG))
    for k,v in pairs(param_tab["nt_grp"]) do
        if (k == 1) then
            grp_name = v["grp_name"]
        elseif (k ~= #param_tab) then
            grp_name = grp_name..","..v["grp_name"]
        end
    end
    ubus_cmd = "ubus call nt_mgr.grp_update set '{\"grp_name\":\""..grp_name.."\"}'"
    if (ubus_cmd_exe(ubus_cmd) < 0) then
        tool.file_write(NT_GRP_UCI_CFG, uci_config)
        return -1
    end
    return 0
end

-- 判断两个 cluster_rule 是否内容一致
local function is_cluster_rule_equal(rule1, rule2)
    if #rule1 ~= #rule2 then
        return false
    end
    local hash = {}
    for _, v in ipairs(rule1) do
        local key = tostring(v["type"]) .. "|" .. tostring(v["val"])
        hash[key] = (hash[key] or 0) + 1
    end
    for _, v in ipairs(rule2) do
        local key = tostring(v["type"]) .. "|" .. tostring(v["val"])
        if not hash[key] then
            return false
        end
        hash[key] = hash[key] - 1
        if hash[key] < 0 then
            return false
        end
    end
    return true
end

--增加（往表尾增加终端组）
local function add_config_bind_office_mesh(bind, config_tab)
    local grp_name_tab = {}
    local nt_grp = config_tab["nt_grp"] or {}

    -- 判断已存在name不允许再进行添加，并整体判断 cluster_rule 是否重复
    for _, grp in ipairs(nt_grp) do
        grp_name_tab[grp["grp_name"]] = true
        if is_cluster_rule_equal(grp["cluster_rule"], bind["cluster_rule"]) then
            module_debug.lua_debug(module_debug.ERROR, "grounp rule is exist")
            return -4
        end
    end

    -- 判断nt_grp总数>=50
    if #nt_grp >= 50 then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] nt_grp number is max!")
        return -2
    end

    if (grp_name_tab[bind["grp_name"]]) then
        module_debug.lua_debug(module_debug.ERROR, "grounp name is exist")
        return -3
    end

    -- cluster_rule字段校验并分类
    local oui_list, hostname_list, type_list = {}, {}, {}
    for _, v in ipairs(bind["cluster_rule"] or {}) do
        if not v["type"] or not v["val"] then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] type or val is nil!")
            return -1
        end
        if v["type"] == "oui" then
            table.insert(oui_list, v["val"])
        elseif v["type"] == "hostname" then
            table.insert(hostname_list, v["val"])
        elseif v["type"] == "type" then
            table.insert(type_list, v["val"])
        end
    end

    -- json数据添加  
    table.insert(config_tab["nt_grp"], bind)
    module_debug.lua_debug(module_debug.INFO, "add grp_name is %s", bind["grp_name"])
    --uci 配置文件添加
    local sectionname = uci:add("net_tml_grp", "nt_grp")
    module_debug.lua_debug(module_debug.ERROR, "sectionname %s", sectionname)
    uci:set("net_tml_grp", sectionname, "grp_name", bind["grp_name"])
    uci:set("net_tml_grp", sectionname, "cluster",  bind["cluster"])
    if #oui_list > 0 then 
        uci:set("net_tml_grp", sectionname, "oui", oui_list)
    end
    if #hostname_list > 0 then 
        uci:set("net_tml_grp", sectionname, "hostname", hostname_list)
    end
    if #type_list > 0 then 
        uci:set("net_tml_grp", sectionname, "type", type_list)
    end

    uci_config = tool.file_read(NT_GRP_UCI_CFG)
    uci:commit("net_tml_grp")
    ubus_cmd = "ubus call nt_mgr.grp_update set '{\"grp_name\":\""..bind["grp_name"].."\"}'"
    module_debug.lua_debug(module_debug.INFO, "%s ",ubus_cmd)
    if ubus_cmd_exe(ubus_cmd) < 0 then
        tool.file_write(NT_GRP_UCI_CFG, uci_config)
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "uci %s had been add", bind["grp_name"])
    
    return 0
end

--删除（查询，删除表中的一个终端组）
local function  del_config_bind_office_mesh(grp_name, config_tab)
    local flag = 0
    local config_grp_num
    local mac_list

    for k, v in pairs(config_tab["nt_grp"]) do
        if (v["grp_name"] == grp_name) then
            flag = 1
            config_grp_num = k
            break
        end
    end

    if (flag == 1) then
        -- json数据删除   
        table.remove(config_tab["nt_grp"], config_grp_num)
        module_debug.lua_debug(module_debug.INFO, "del grp_name is %s", grp_name)
        --uci 配置文件删除
        uci:foreach("net_tml_grp", "nt_grp", function(s)
            local tab = {}
            local sectionname = s[".name"]
            local username = uci:get("net_tml_grp", sectionname, "grp_name")
            if (username == grp_name) then
                uci:delete("net_tml_grp", sectionname)
            end
        end
        )
        --uci net_tml中的配置文件删除
        uci:foreach("net_tml", "nt_info", function(s)
            local tab = {}
            local sectionname = s[".name"]
            local username = uci:get("net_tml", sectionname, "grp_name")
            if (username == grp_name) then
                uci:delete("net_tml", sectionname,"grp_name")
                uci:delete("net_tml", sectionname,"hand_grp")
                uci:delete("net_tml", sectionname,"cluster")
            end
        end
        )
        uci:commit("net_tml")
    else
        module_debug.lua_debug(module_debug.ERROR, "del_config_bind is failed")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "uci %s had been del", grp_name)
    return 0
end

--修改（查询，修改表中的一个终端组）
local function update_config_bind_office_mesh(bind, config_tab)
    local grp_name_tab = {}
    local nt_grp = config_tab["nt_grp"] or {}

    -- 排除自身，整体判断 cluster_rule 是否重复
    for _, grp in ipairs(nt_grp) do
        grp_name_tab[grp["grp_name"]] = true
        if grp["grp_name"] ~= bind["grp_name"] and is_cluster_rule_equal(grp["cluster_rule"], bind["cluster_rule"]) then
            module_debug.lua_debug(module_debug.ERROR, "grounp rule is exist")
            return -4
        end
    end

    if (grp_name_tab[bind["grp_name"]]) then
        for _, v in ipairs(nt_grp) do
            if v["grp_name"] == bind["grp_name"] then
                v["cluster"] = bind["cluster"]
                v["cluster_rule"] = bind["cluster_rule"]
                module_debug.lua_debug(module_debug.INFO, "update grp_name is %s", bind["grp_name"])
                break
            end
        end
        -- cluster_rule字段校验并分类
        local oui_list, hostname_list, type_list = {}, {}, {}
        for _, v in ipairs(bind["cluster_rule"] or {}) do
            if not v["type"] or not v["val"] then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] type or val is nil!")
                return -1
            end
            if v["type"] == "oui" then
                table.insert(oui_list, v["val"])
            elseif v["type"] == "hostname" then
                table.insert(hostname_list, v["val"])
            elseif v["type"] == "type" then
                table.insert(type_list, v["val"])
            end
        end

        --uci 配置文件修改
        uci:foreach("net_tml_grp", "nt_grp", function(s)
            local sectionname = s[".name"]
            local username = uci:get("net_tml_grp", sectionname, "grp_name")
            if (username == bind["grp_name"]) then
                uci:delete("net_tml_grp", sectionname)
            end
        end)
        local sectionname = uci:add("net_tml_grp", "nt_grp")
        uci:set("net_tml_grp", sectionname, "grp_name", bind["grp_name"])
        uci:set("net_tml_grp", sectionname, "cluster",  bind["cluster"])
        if #oui_list > 0 then 
            uci:set("net_tml_grp", sectionname, "oui", oui_list)
        end
        if #hostname_list > 0 then 
            uci:set("net_tml_grp", sectionname, "hostname", hostname_list)
        end
        if #type_list > 0 then 
            uci:set("net_tml_grp", sectionname, "type", type_list)
        end
    
        uci_config = tool.file_read(NT_GRP_UCI_CFG)
        uci:commit("net_tml_grp")
        ubus_cmd = "ubus call nt_mgr.grp_update set '{\"grp_name\":\""..bind["grp_name"].."\"}'"
        module_debug.lua_debug(module_debug.INFO, "%s ", ubus_cmd)
        if ubus_cmd_exe(ubus_cmd) < 0 then
            tool.file_write(NT_GRP_UCI_CFG, uci_config)
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] grp_name is no exist!")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "uci %s had been update", bind["grp_name"])

    return 0
end

--@net_tml_grp_add
function net_tml_grp_add(param)
    module_debug.lua_debug(module_debug.INFO, "###############################ADD###############################")

    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return  -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)

    param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param_tab is nil")
        return  -1
    end

    local config_tab = tool.file_read(NT_GRP_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return  -1
    end
    local config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return  -1
    end
    --更新配置文件
    for k,v in pairs(param_tab["nt_grp"]) do
        if (v["grp_name"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] grp_name is nil")
            return  -1
        end

        ret = add_config_bind_office_mesh(v, config_tab)
   
        if (ret ~= 0) then
            return  ret
        end
    end

    config_tab = cjson.encode(config_tab)
    if (config_tab ~= nil) then
        tool.file_write(NT_GRP_JSON_FILE, config_tab)
    end

    module_debug.lua_debug(module_debug.INFO, "###############################SET END###############################")
    return  0

end

--@net_tml_grp_update
function net_tml_grp_update(param)
    module_debug.lua_debug(module_debug.INFO, "###############################UPDATE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return  -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)

    param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param_tab is nil")
        return  -1
    end
    config_tab = tool.file_read(NT_GRP_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return  -1
    end
    config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return  -1
    end

    for k,v in pairs(param_tab["nt_grp"]) do
        if (v["grp_name"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] grp_name is nil")
            return  -1
        end

        ret = update_config_bind_office_mesh(v, config_tab)

        if (ret ~= 0) then
            return  ret
        end
    end


    config_tab = cjson.encode(config_tab)
    if (config_tab ~= nil) then
        tool.file_write(NT_GRP_JSON_FILE, config_tab)
    end

    module_debug.lua_debug(module_debug.INFO, "################################UPDATE END################################")
    return  0
end

--@net_tml_grp_del
function net_tml_grp_del(param)
    module_debug.lua_debug(module_debug.INFO, "###############################DELETE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return  -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return  -1
    end

    config_tab = tool.file_read(NT_GRP_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return  -1
    end

    config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return  -1
    end

    for k,v in pairs(param_tab["nt_grp"]) do
        ret = del_config_bind_office_mesh(v["grp_name"], config_tab)          
        if (ret ~= 0) then
            return  ret
        end
    end

    if (office_mesh_uci_config_handle(param_tab) < 0) then
        return -1
    end

    config_tab = cjson.encode(config_tab)
    if (config_tab ~= nil) then
        tool.file_write(NT_GRP_JSON_FILE, config_tab)
    end

    module_debug.lua_debug(module_debug.INFO, "################################DEL END################################")
    return  0
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"nt_grp":[]}'
    return default_config
end

--@dev_mode_add
function module_add(param)
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")

    end
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end
    ret = net_tml_grp_add(param)
    os.remove(LOCK_FILE)
    if (ret == -1) then
        return check_result("0001")
    elseif (ret == -2) then
        return check_result("0002")
    elseif (ret == -3) then
        return check_result("0003")
    elseif (ret == -4) then
        return check_result("0004")
    end
    return check_result("0000")
end

--@dev_mode_del
function module_del(param)
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end

    ret = net_tml_grp_del(param)
    os.remove(LOCK_FILE)
    if (ret == -1) then
        return check_result("0001")
    end
    return check_result("0000")
end

--@dev_mode_update
function module_update(param)
    debug_init()
    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end
    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param %s", param)
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end

    ret = net_tml_grp_update(param)
    os.remove(LOCK_FILE)
    if (ret == -1) then
        return check_result("0001")
    elseif (ret == -4) then
        return check_result("0004")
    end
    return check_result("0000")
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end

    os.remove(LOCK_FILE)
    return check_result("0000")
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end