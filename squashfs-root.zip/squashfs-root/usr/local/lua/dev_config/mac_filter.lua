#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("mac_filter", package.seeall);

dkjson = require "dkjson"
mac_set = "mac_set"
CONFIG_FILE="/etc/sd_config/single/mac_filter.json"
local ubus = require("ubus");

----------日志-----------
function debug_print(func,msg)
    DEBUG_LOG_DIR = "/tmp/mac_filter/"
    DEBUG_LOG_FILE = "mac_filter.log"
    local cmd="mkdir -p "..DEBUG_LOG_DIR.." 2>/dev/null"
    os.execute(cmd)
    
    local file = io.open(DEBUG_LOG_DIR..DEBUG_LOG_FILE, "a")
    if ( file ~= nil )
    then
        local cmd="ls -l "..DEBUG_LOG_DIR..DEBUG_LOG_FILE.." | awk \'{print $5}\' 2>/dev/null"
        local content = io.popen(cmd)
        local size = content:read("*a")
        local maxSize = 10 * 1024
        
        -----判断文件是否达到最大容量------
        if ( tonumber(size) > maxSize )
        then
            file:close()
            os.rename(DEBUG_LOG_DIR..DEBUG_LOG_FILE,DEBUG_LOG_DIR..DEBUG_LOG_FILE..".old")
            os.execute("touch "..DEBUG_LOG_DIR..DEBUG_LOG_FILE.." 2>/dev/null")
            file = io.open(DEBUG_LOG_DIR..DEBUG_LOG_FILE, "a")
        end
        
        ---------向文件中写入日志---------
        local debug_date = os.date("%Y-%m-%d %H:%M:%S")
        local line = debug.getinfo(2).currentline
        file:write(string.format("[%s] %-6s %-4d %s\n",debug_date,func,line,msg))
        file:close()
    else
        os.execute("touch "..DEBUG_LOG_DIR..DEBUG_LOG_FILE.." 2>/dev/null")
        debug_print(func,msg)
    end
end

function file_read(conf_file)
    local file = io.open(conf_file,"r")
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file,data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

--查询mac地址是否存在--
function for_json(json,data)
    local num = 1
    local length = table.maxn(json["list"])
    
    --对比mac地址是否已存在，存在返回存在数组中的编号；不存在返回0。--
    while ( num < length + 1 )
    do
        --统一为字母大写--
        if ( string.upper(json["list"][num]["mac"]) == string.upper(data) )
        then
            return num
        end
        num = num + 1
    end

    return 0
end

function fail_reason(msg, code)
    local rcode = table.concat({"0502", code});
    local err = {}
    local ret = {}

    err["rcode"] = rcode
    err["message"] = msg
    ret["code"] = "1"  
    ret["err"] = dkjson.encode(err)
  
    return dkjson.encode(ret)
end

function invalid_mac_check(macaddr)
    --检查mac
    if (macaddr == nil) then
        debug_print("invalid_mac_check","Error: MAC is null!")
        return -1
    end
 
    local macaddr1, macaddr2, macaddr3, macaddr4, macaddr5, macaddr6 = string.match(macaddr, "^(%x+):(%x+):(%x+):(%x+):(%x+):(%x+)$")
    if (macaddr1 == nil or macaddr2 == nil or macaddr3 == nil or macaddr4 == nil or macaddr5 == nil or macaddr6 == nil) then
        debug_print("invalid_mac_check","Error: MAC is error!")
        return -1
    end
    
    if (tonumber(macaddr1, 16) == 255) then
        debug_print("invalid_mac_check","Error: MAC is Multicast MAC!")
        return -1
    end
    
    if (tonumber(macaddr1, 16) % 2 ~= 0) then
        debug_print("invalid_mac_check","Error: MAC is illegal MAC!")
        return -1
    end
    
    return 0
end

--增加mac地址--
function conf_add(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local add = dkjson.decode(data)
    local length = table.maxn(json["list"])
    local add_length = table.maxn(add["macList"])
    local flag = 0
    

    --------增加mac地址-----
    while ( add_length > 0 )
    do
        local num = for_json(json,add["macList"][add_length]["mac"])
        if ( num == 0 )
        then
        
            if (invalid_mac_check(add["macList"][add_length]["mac"]) == -1) then
                debug_print("add","invalid_mac_check failed")
                return fail_reason("Error: The MAC is illegal MAC!","0001")
            end
        
            table.insert(json["list"],add["macList"][add_length])
            flag = 1
            debug_print("add","mac = "..add["macList"][add_length]["mac"])
            if ( json["enable"] == "1" )
            then
                os.execute("ipset add "..mac_set.." "..add["macList"][add_length]["mac"].." ".."2>/dev/null")
                debug_print("add","ipset add success!")
            end
        else
            debug_print("add","Error: Data already exists!")
        end
        add_length = add_length - 1
    end
    
    if (flag == 1) then
        file_write(conf_file,dkjson.encode(json))
    end
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

--删除mac地址--
function conf_del(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local del = dkjson.decode(data)
    local length = table.maxn(json["list"])
    local del_length = table.maxn(del["macList"])
    local del_num = 1
    local flag = 0
    
    --------删除mac地址-----
    while ( del_length > 0 )
    do
        local num = for_json(json,del["macList"][del_length]["mac"])
        if ( num ~= 0 )
        then
        
            if (invalid_mac_check(del["macList"][del_length]["mac"]) == -1) then
                debug_print("add","invalid_mac_check failed")
                return fail_reason("Error: The MAC is illegal MAC!","0001")
            end
        
            table.remove(json["list"],num)
            flag = 1
            debug_print("del","mac = "..del["macList"][del_length]["mac"])
            if ( json["enable"] == "1" )
            then
                os.execute("ipset del "..mac_set.." "..del["macList"][del_length]["mac"].." ".."2>/dev/null")
                debug_print("del","ipset del success!")
            end
        else
            debug_print("del","Error: Data doesn't exist!")
        end
        del_length = del_length - 1
    end
    
    if (flag == 1) then
        file_write(conf_file,dkjson.encode(json))
    end
    return '{"message":"Configuration success","rcode":"00000000"}'
end

--修改mac地址--
function conf_update(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local updata = dkjson.decode(data)
    local length = table.maxn(json["list"])
    local enable = updata["enable"]
    local model = updata["model"]
    local antiRubNet = updata["antiRubNet"]
    
    if (antiRubNet ~= nil) then
        if (type(antiRubNet) ~= "string") then
            return fail_reason("Error: param is error!","0002")
        end
        json["antiRubNet"] = antiRubNet
        debug_print("update","antiRubNet = "..antiRubNet)
    end
    
    --判断是否对当前黑白名单模式进行转换--
    if (model ~= nil) then
        if (type(model) ~= "string" or (model ~= "black" and model ~= "white")) then
            return fail_reason("Error: param is error!","0002")
        end
        json["model"] = model
        debug_print("update","model = "..model)
    end
    
    --判断是否变更mac黑白名单的开关状态--
    if ( enable ~= nil )then
        if (type(enable) ~= "string" or (enable ~= "0" and enable ~= "1")) then
            return fail_reason("Error: param is error!","0002")
        end
    
        json["enable"] = enable
        file_write(conf_file,dkjson.encode(json))
        debug_print("update","enable = "..enable)
        os.execute("/usr/sbin/mac_filter_exec.lua")
        debug_print("update","update model success!")
        return '{"message":"Configuration success","rcode":"00000000"}'
    end
    
    -------修改mac地址---------
    local num = for_json(json,updata["oldmac"])
    if ( num ~= 0 )
    then
    
        if (invalid_mac_check(updata["oldmac"]) == -1) then
            return fail_reason("Error: The MAC is illegal MAC!","0001")
        end
    
        if (invalid_mac_check(updata["mac"]) == -1) then
            return fail_reason("Error: The MAC is illegal MAC!","0001")
        end
    
        json["list"][num]["mac"] = updata["mac"]
        json["list"][num]["comment"] = updata["comment"]
        file_write(conf_file,dkjson.encode(json))
        debug_print("update","oldmac = "..updata["oldmac"].." mac = "..updata["mac"].." ,comment = "..updata["comment"])
        if( json["enable"] == "1" )
        then
            os.execute("ipset del "..mac_set.." "..updata["oldmac"].." ".."2>/dev/null")
            os.execute("ipset add "..mac_set.." "..updata["mac"].." ".."2>/dev/null")
            debug_print("update","ipset update success!")
        end
    else
        debug_print("update","Error: Data doesn't exist!")
    end
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_default_config_get()
    local def_cfg = '{"enable":"0","model":"black","list":[]}'

    return def_cfg
end

function module_add(param, conf)
    return conf_add(param, conf)
end

function module_del(param, conf)

    return conf_del(param, conf)
end

function module_update(param, conf)
    return conf_update(param, conf)
end

function module_set(param)
    local data = dkjson.decode(param)
    local enable = data["enable"]
    local model = data["model"]
    local antiRubNet = data["antiRubNet"]

    if (data["list"] == nil) then
        return fail_reason("Error: param is error","0002")
    end

    if (antiRubNet ~= nil) then
        if (type(antiRubNet) ~= "string") then
            return fail_reason("Error: param is error!","0002")
        end
    end

    if (type(model) ~= "string" or (model ~= "black" and model ~= "white")) then
        return fail_reason("Error: param is error!","0002")
    end

    if (type(enable) ~= "string" or (enable ~= "0" and enable ~= "1")) then
        return fail_reason("Error: param is error!","0002")
    end

    local length = table.maxn(data["list"])
    
    while (length > 0) do
        if (invalid_mac_check(data["list"][length]["mac"]) == -1) then
            debug_print("set","invalid_mac_check failed")
            return fail_reason("Error: The MAC is illegal MAC!","0001")
        end

        length = length - 1
    end
    
    os.execute("ubus send mac_filter_reload")
end

local function ubus_send()
    local conn = ubus.connect()

    if not conn then
        debug_print("ubus_send","ubus connect failed")
        return
    end

    conn:send("mac_filter_change", {})
    
    conn:close()
end


function module_apply()
    if (file_exists("/proc/shortcut_flush") == true) then
        os.execute("echo 'f' > /proc/shortcut_flush") 
    end

    if (file_exists("/usr/lib/lua/hnat/hwnat_clean_entry.lua") == true) then
        os.execute("/usr/bin/lua /usr/lib/lua/hnat/hwnat_clean_entry.lua");
    end
    
    ubus_send()
end
