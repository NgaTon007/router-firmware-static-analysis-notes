#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("pppoeserver_exceptip", package.seeall);
cjson = require "dkjson"
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
require "public_module"
require("uci")
lib_param = require("libc2lua")
local console = require "console"

local modul = "pppoe-server"
local module_name = "pppoeserver_exceptip"
local conf_file = "/etc/config/pppoeserver_exceptip"
local sd_cfg = "/etc/sd_config/single/pppoeserver_exceptip.json"

local table_input_err = {rcode = "05600001", rmsg = "param error"}

----------枚举初始化---------
function CreatEnumTable(tb, index)  
    local enumtb = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tb) do 
        enumtb[v] = enumindex + i 
    end 
    return enumtb
end 
----------lua通用错误码-----------------
local g_err_code = {"ERR_PARAM", "ERR_FILE_WRITE", "ERR_FILE_NOT_EXIST","ERR_UBUS_CONNECT"}
local g_err_code = CreatEnumTable(g_err_code, 200)
--return output(1, g_err_code["ERR_PARAM"], "rate_limit_set failed:param error")

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_exceptip.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")
local uci_r = uci.cursor()

function module_default_config_get()
    local def_cfg = '{"list":[]}' 
    return def_cfg
end

function guid()
        local template ="xxxxxxxxxxxxxxxxxxxx"---xxxx-xxxx-xxxxxxxxxxxx"
        local d = io.open("/dev/urandom", "r"):read(4)
		local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)
		--os.time()  + d:byte(1) --+ (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 4294967296)
        math.randomseed(num)
        return string.upper(string.gsub(template, "x", function (c)
                                        local v = (c == "x") and math.random(0, 0xf) or math.random(8, 0xb)
                                                return string.format("%x", v)
                                        end
                        ))
end

local function ip_str_to_int(ipaddr)
    lib_debug.lua_debug(lib_debug.INFO, "ip_str_to_int() ipaddr:%s", ipaddr);
    local ip = require("utils.string").string_split_to_table(ipaddr, ".")

    if (#ip ~= 4) then
        return false
    end
    
    for i = 1, #ip do
        if (tonumber(ip[i]) < 0 or tonumber(ip[i]) > 255) then
            return false
        end
    end
    
    local ip_int = ip[1] * 16777216 + ip[2] * 65536 + ip[3] * 256 + ip[4];
    lib_debug.lua_debug(lib_debug.INFO, "ip_str_to_int() ip_int:%s", ip_int)

    return true, ip_int
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

--ret(uint)表示是否返回结果给web,0表示不返回，1表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

function module_get()

end

split = function(s, p)

    local rt= {}
    string.gsub(s, '[^'..p..']+', function(w) table.insert(rt, w) end )
    return rt

end

-- ip 比较
local function ip_compare(ip1, ip2, flag)
	local entry1
	local entry2
	if flag == true then
		entry1 = split(ip1, '.')
		entry2 = split(ip2, '.')
	else
		entry1 = ip1
		entry2 = ip2
	end
	
	local ip11 = tonumber(entry1[1])
	local ip21 = tonumber(entry2[1])
	if ip11 > ip21 then
		return 1
	elseif ip11 < ip21 then
		return -1
	end
	local ip12 = tonumber(entry1[2])
	local ip22 = tonumber(entry2[2])
	if ip12 > ip22 then
		return 1
	elseif ip12 < ip22 then
		return -1
	end
	local ip13 = tonumber(entry1[3])
	local ip23 = tonumber(entry2[3])
	if ip13 > ip23 then
		return 1
	elseif ip13 < ip23 then
		return -1
	end
	local ip14 = tonumber(entry1[4])
	local ip24 = tonumber(entry2[4])
	if ip14 > ip24 then
		return 1
	elseif ip14 < ip24 then
		return -1
	else 
		return 0
	end
end

-- lan ip 检测
function ip_compare_lan(start_ip, end_ip)

	local lanip = uci_r:get("network", "lan", "ipaddr")
	local flag1 = ip_compare(lanip, start_ip, true)
	if flag1 == -1 then
		return 0
	elseif flag1 == 0 then
		return 1
	else
		local flag2 = ip_compare(lanip, end_ip, true)
		if flag2 == 1 then
			return 0
		else
			return 1
		end
	end
end

-- 新创建的例外ip是否已存在
function ip_compare_file(start_ip, end_ip, old_start_ip, old_end_ip)
	local flag = 0
	uci_r:foreach("pppoeserver_exceptip", "pppoeserver_exceptip",
		function(section)
            repeat
			if flag == 0 then
                if(old_start_ip == section["start_ip"] and old_end_ip == section["end_ip"]) then
                    break
                end
				local flag1 = ip_compare(start_ip, section["start_ip"], true)
				local flag2 = ip_compare(end_ip, section["start_ip"], true)
				if flag1 ~= -1 or flag2 ~= -1 then
					if (flag1 == 1 and flag2 == 1) then
						local flag3 = ip_compare(start_ip, section["end_ip"], true)
						local flag4 = ip_compare(end_ip, section["end_ip"], true)
						if flag3 ~= 1 or flag4 ~= 1 then
							flag = 1
						end
					else
						flag = 1
					end
				end
			end
            until true
		end
	)	
	return flag
end

function uci_update(up_data, uuid)
     

    --保存uci配置
   
    if (up_data.new.start_ip ~= nil) then
        uci_r:set(module_name, uuid, "start_ip", up_data.new.start_ip)
    end
    if (up_data.new.end_ip ~= nil) then
        uci_r:set(module_name, uuid, "end_ip", up_data.new.end_ip)
    end
    if (up_data.new.note ~= nil) then
        uci_r:set(module_name, uuid, "note", up_data.new.note)
    end
    if (up_data.new.state ~= nil) then
        uci_r:set(module_name, uuid, "state", up_data.new.state)
    end
    
    uci_r:commit(module_name)
	uci_r:revert(module_name)
    
end

function json_update(old_json, up_data, old_length, num)
    --local num = static_route_match(old_json, up_data.old, old_length)  
 
    --uuid = old_json.list[num].uuid
    if (up_data.new.start_ip ~= nil) then
        old_json.list[num].start_ip = up_data.new.start_ip
    end
    if (up_data.new.end_ip ~= nil) then
        old_json.list[num].end_ip = up_data.new.end_ip
    end
    if (up_data.new.note ~= nil) then
        old_json.list[num].note = up_data.new.note
    end
    if (up_data.new.state ~= nil) then
        old_json.list[num].state = up_data.new.state
    end
    
    file_write(sd_cfg, cjson.encode(old_json))
end

function ipset_update(old_json, up_data, old_length, num)
    local state = uci_r:get("pppoeserver_global", "global", "state")
	local force_state = uci_r:get("pppoeserver_global", "global", "force_state")
	local cmd

    local ret
    local ipstart_int
    local boundary
    local ipend_int

    ret, boundary = ip_str_to_int("129.0.0.0")
    if (ret ~= true) then
        return check_result("0001")
    end

    if (state == "1" and force_state == "1") then
        if (old_json.list[num].state == "1") then
            ret, ipstart_int = ip_str_to_int(old_json.list[num].start_ip)
            if (ret ~= true) then
                return check_result("0001")
            end
            ret, ipend_int = ip_str_to_int(old_json.list[num].end_ip)
            if (ret ~= true) then
                return check_result("0001")
            end

            if (ipstart_int < boundary and ipend_int > boundary) then
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], cmd, old_json.list[num].start_ip)
                else
                    cmd = string.format([[ipset del pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], old_json.list[num].start_ip)
                end
                cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  129.0.0.0-%s -exist]], cmd, old_json.list[num].end_ip)
            else
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  %s-%s -exist]], cmd, old_json.list[num].start_ip, old_json.list[num].end_ip)
                else
                    cmd = string.format([[ipset del pppoeserver_user_exceptip  %s-%s -exist]], old_json.list[num].start_ip, old_json.list[num].end_ip)
                end
            end

        end
        
        if (up_data.new.state == "1") then
            ret, ipstart_int = ip_str_to_int(up_data.new.start_ip)
            if (ret ~= true) then
                return check_result("0001")
            end
            ret, ipend_int = ip_str_to_int(up_data.new.end_ip)
            if (ret ~= true) then
                return check_result("0001")
            end
            if (ipstart_int < boundary and ipend_int > boundary) then
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset add pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], cmd, up_data.new.start_ip)
                else
                    cmd = string.format([[ipset add pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], up_data.new.start_ip)
                end
                cmd = string.format([[%s;ipset add pppoeserver_user_exceptip  129.0.0.0-%s -exist]], cmd, up_data.new.end_ip)
            else
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset add pppoeserver_user_exceptip  %s-%s -exist]], cmd, up_data.new.start_ip, up_data.new.end_ip)
                else
                    cmd = string.format([[ipset add pppoeserver_user_exceptip  %s-%s -exist]], up_data.new.start_ip, up_data.new.end_ip)
                end
            end

        end
        
        os.execute(cmd)
	end
    return
end

function module_update(param)  
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update start\n")

    lib_debug.lua_debug(lib_debug.DEBUG, "module_update:%s\n", param)
    
    local up_data = cjson.decode(param)
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    local old_length = table.maxn(old_json.list)    
    local num = static_route_match(old_json, up_data.old, old_length)  
    local uuid = old_json.list[num].uuid

	if (up_data.old.start_ip ~= nil) then
		--参数安全检测
		tmp = up_data.old.start_ip
		if (lib_param.lua_param_safety_check(tmp) ~= true) 
		then
			return check_result("0001")
		end
    end
	if (up_data.old.end_ip ~= nil) then
		--参数安全检测
		tmp = up_data.old.end_ip
		if (lib_param.lua_param_safety_check(tmp) ~= true) 
		then
			return check_result("0001")
		end
    end
    if (up_data.new.start_ip == nil) then
        up_data.new.start_ip = old_json.list[num].start_ip
	else
		--参数安全检测
		tmp = up_data.new.start_ip
		if (lib_param.lua_param_safety_check(tmp) ~= true) 
		then
			return check_result("0001")
		end
    end
    if (up_data.new.end_ip == nil) then
        up_data.new.end_ip = old_json.list[num].end_ip
	else
		--参数安全检测
		tmp = up_data.new.end_ip
		if (lib_param.lua_param_safety_check(tmp) ~= true) 
		then
			return check_result("0001")
		end
    end
    if (up_data.new.note == nil) then
        up_data.new.note = old_json.list[num].note
    end
    if (up_data.new.state == nil) then
        up_data.new.state = old_json.list[num].state
	else
		--参数安全检测
		tmp = up_data.new.state
		if (lib_param.lua_param_safety_check(tmp) ~= true) 
		then
			return check_result("0001")
		end
    end
    
    --检测  参数是否符合要求
    -- ip 检测
    local ret = ip_compare(up_data.new.start_ip, up_data.new.end_ip, true)
	if ret ==  1 then
        lib_debug.lua_debug(lib_debug.DEBUG, "ip_compare error\n")
		return check_result("0001")
	end
    -- lan ip 检测
	ret = ip_compare_lan(up_data.new.start_ip, up_data.new.end_ip)
	if ret ==  1 then
        lib_debug.lua_debug(lib_debug.DEBUG, "ip_compare_lan error\n")
		return check_result("0001")
	end
    -- 新创建的例外ip是否已存在    
	ret = ip_compare_file(up_data.new.start_ip, up_data.new.end_ip, up_data.old.start_ip, up_data.old.end_ip)
	if ret ==  1 then
        lib_debug.lua_debug(lib_debug.DEBUG, "ip_compare_file error\n")
		return check_result("0001")
	end
 
    local result = ipset_update(old_json, up_data, old_length, num)
    if result ~= nil then
        lib_debug.lua_debug(lib_debug.DEBUG, "ipset_update err\n")
    end
    lib_debug.lua_debug(lib_debug.DEBUG, "json_update start\n")
    json_update(old_json, up_data, old_length, num)
    lib_debug.lua_debug(lib_debug.DEBUG, "uci_update start\n")
    uci_update(up_data, uuid)
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update end\n")

    return check_result("0000")
end

function pppoeserver_exceptip_name_check(json, data)
    local num = 1
    local length = table.maxn(json.list)     
    while ( num < length + 1 )
    do
		if (json.list[num].start_ip == data.start_ip and json.list[num].end_ip == data.end_ip) then
            return -1
        end
        num = num + 1
    end
    return 0
end

function uci_add(data) 
    lib_debug.lua_debug(lib_debug.DEBUG, "uci_add\n")
     
    local name = guid()
    uci_r:set(module_name, name, module_name)
    uci_r:set(module_name, name, "start_ip", data.start_ip)
    uci_r:set(module_name, name, "end_ip", data.end_ip)
    uci_r:set(module_name, name, "note", data.note)
    uci_r:set(module_name, name, "state", data.state)
    data.uuid=name
    
    uci_r:commit(module_name)
	uci_r:revert(module_name)
end

function json_add(data) 
    lib_debug.lua_debug(lib_debug.DEBUG, "json_add\n")
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)

    table.insert (old_json["list"],data)
    
    file_write(sd_cfg, cjson.encode(old_json))
end

function ipset_add(data)
    local ret
    local ipstart_int
    local boundary
    local ipend_int
    local cmd = ""
    ret, ipstart_int = ip_str_to_int(data.start_ip)
    if (ret ~= true) then
        return check_result("0001")
    end
    ret, ipend_int = ip_str_to_int(data.end_ip)
    if (ret ~= true) then
        return check_result("0001")
    end
    ret, boundary = ip_str_to_int("129.0.0.0")
    if (ret ~= true) then
        return check_result("0001")
    end

    if (ipstart_int < boundary and ipend_int > boundary) then
        cmd = string.format([[ipset create pppoeserver_user_exceptip hash:net;ipset add pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], data.start_ip)
        cmd = string.format([[%s;ipset add pppoeserver_user_exceptip  129.0.0.0-%s -exist]], cmd, data.end_ip)
    else
        cmd = string.format([[ipset create pppoeserver_user_exceptip hash:net;ipset add pppoeserver_user_exceptip  %s-%s -exist]], data.start_ip, data.end_ip)
    end
    os.execute(cmd)
    return
end

--dev_config add -m pppoeserver_exceptip '{"start_ip":"192.168.50.1","end_ip":"192.168.50.5","note":"444","state":"1"}'
function module_add(param)
	local data = cjson.decode(param)

    lib_debug.lua_debug(lib_debug.DEBUG, "module_add start\n")
    lib_debug.lua_debug(lib_debug.DEBUG, "module_add:%s\n", param)
    if (data.start_ip == nil or data.end_ip == nil or data.state == nil) then
        return check_result("0001")
    end  
	--参数安全检测
	tmp = data.start_ip
	if (lib_param.lua_param_safety_check(tmp) ~= true) 
	then
        return check_result("0001")
	end
	tmp = data.end_ip
	if (lib_param.lua_param_safety_check(tmp) ~= true) 
	then
        return check_result("0001")
	end
	tmp = data.state
	if (lib_param.lua_param_safety_check(tmp) ~= true) 
	then
        return check_result("0001")
	end
    if (data.note == nil) then
        data.note = NULL
    end 
    
    --检测  参数是否符合要求
    -- ip 检测
    local ret = ip_compare(data.start_ip, data.end_ip, true)
	if ret ==  1 then
        return check_result("0001")
	end
    -- lan ip 检测
	ret = ip_compare_lan(data.start_ip, data.end_ip)
	if ret ==  1 then
        return check_result("0001")
	end
    -- 新创建的例外ip是否已存在
	ret = ip_compare_file(data.start_ip, data.end_ip, nil, nil)
	if ret ==  1 then
        return check_result("0001")
	end
    
    --保存数据到uci
    uci_add(data)
    
    --保存数据到json
    json_add(data)
    local state = uci_r:get("pppoeserver_global", "global", "state")
	local force_state = uci_r:get("pppoeserver_global", "global", "force_state")
    if state == "1" and force_state == "1" then
		if data.state == "1" then
 			--ipset添加
            local result = ipset_add(data)
            if result ~= nil then
                lib_debug.lua_debug(lib_debug.DEBUG, "ipset_add err\n")
            end
		end
	end
    return check_result("0000")
end

function ipset_del(del_data, old_json, del_length, old_length)
    local num = 1
    local cmd
    local length = 1
    
    local ret
    local ipstart_int
    local boundary
    local ipend_int

    ret, boundary = ip_str_to_int("129.0.0.0")
    if (ret ~= true) then
        return check_result("0001")
    end
    while ( length < del_length + 1 )
    do
        num = static_route_match(old_json, del_data["list"][length], old_length)  
        if ( num ~= old_length + 1 and old_json.list[num].state == "1")
        then
            ret, ipstart_int = ip_str_to_int(old_json.list[num].start_ip)
            if (ret ~= true) then
                return check_result("0001")
            end
            ret, ipend_int = ip_str_to_int(old_json.list[num].end_ip)
            if (ret ~= true) then
                return check_result("0001")
            end

            if (ipstart_int < boundary and ipend_int > boundary) then
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], cmd, old_json.list[num].start_ip)
                else
                    cmd = string.format([[ipset del pppoeserver_user_exceptip  %s-129.0.0.0 -exist]], old_json.list[num].start_ip)
                end
                cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  129.0.0.0-%s -exist]], cmd, old_json.list[num].end_ip)
            else
                if (cmd ~= nil) then
                    cmd = string.format([[%s;ipset del pppoeserver_user_exceptip  %s-%s -exist]], cmd, old_json.list[num].start_ip, old_json.list[num].end_ip)
                else
                    cmd = string.format([[ipset del pppoeserver_user_exceptip  %s-%s -exist]], old_json.list[num].start_ip, old_json.list[num].end_ip)
                end
            end
        end
        length = length + 1
    end

    os.execute(cmd)
    return
end

function uci_del(uci_r, uuid, del_length)
    lib_debug.lua_debug(lib_debug.DEBUG, "uci_add\n")
    local num = 1
    uci_r:delete(module_name, uuid[num])
end

function json_del(del_data, old_json, del_length, old_length)
    local del_json_num = 1
    local num 
     

    while ( del_json_num < del_length + 1 )
    do
        num = static_route_match(old_json, del_data["list"][del_json_num], old_length)  
        
        
        if ( num ~= old_length + 1 )
        then
            uci_r:delete(module_name, old_json["list"][num]["uuid"])
            table.remove(old_json.list,num)
			del_json_num = del_json_num + 1	
        end
    end
    
    uci_r:commit(module_name)
	uci_r:revert(module_name)
	file_write(sd_cfg, cjson.encode(old_json))
end

--遍历json配置文件，查找删除项位置
function static_route_match(old_json, data, old_length)
    local num = 1
    local length = old_length   
    while ( num < length + 1 )
    do
		if (old_json.list[num].start_ip == data.start_ip and old_json.list[num].end_ip == data.end_ip) then
            return num
        end
        num = num + 1
    end
    return -1
end

function module_del(param)
    lib_debug.lua_debug(lib_debug.DEBUG, "module_del start\n")
	--参数安全检测
	if (lib_param.lua_param_safety_check(param) ~= true) 
	then
		if (param ~= nil)
		then
			lib_debug.lua_debug(lib_debug.DEBUG, "param error.  param is %s\n", param)
		else
			lib_debug.lua_debug(lib_debug.DEBUG, "param error.\n")
		end
        -- return output(1, g_err_code["ERR_PARAM"], "module_add failed:param error")
        return check_result("0001")
	end

    lib_debug.lua_debug(lib_debug.DEBUG, "module_del:%s\n", param)
     
    local del_data = cjson.decode(param)
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
	local old_length = table.maxn(old_json.list)
	local del_length = table.maxn(del_data.list)
   
    --删除ipset数据
    local state = uci_r:get("pppoeserver_global", "global", "state")
	local force_state = uci_r:get("pppoeserver_global", "global", "force_state")
    if state == "1" and force_state == "1" then
		local result = ipset_del(del_data, old_json, del_length, old_length)
        if result ~= nil then
            lib_debug.lua_debug(lib_debug.DEBUG, "ipset_del err\n")
        end
	end
    --删除json、uci数据
    json_del(del_data, old_json, del_length, old_length)

    --uci_del(uuid, del_length)
    
    
    return check_result("0000")
end

function module_apply(param)

end

