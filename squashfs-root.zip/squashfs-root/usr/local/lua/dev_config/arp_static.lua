#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("arp_static", package.seeall);

module_name = "arp_static"
dkjson = require "dkjson"
cjson_safe = require "cjson.safe"
local lib_param = require("libc2lua")
moduleId = require "dev_module_id";
CONFIG_FILE = "/etc/sd_config/single/arp_static.json"
module_debug = require "utils.debug"

device = "/tmp/sd_device/sd_device.json"
module_debug.debug_init("/tmp/arp_static/", module_name..".log", 50, module_debug.DEBUG, "1")

function file_read(conf_file)
    local file = io.open(conf_file,"r")
    local data = nil
    if (file) then
        data = file:read("*a")
        file:close()
    end
    return data
end

function file_write(conf_file,data)
    local file = io.open(conf_file,"w")
    if (file) then
        file:write(data)
        file:close()
    end
    return -1
end

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

--lua根据字符分割字符串
function split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

function fail_reason(msg, code, data)
    local result = {}
    local rcode = table.concat({moduleId.get_module_id("arp_static"), code});
    result["rcode"] = rcode
    result["data"] = data
    result["msg"] = msg
    result["err"] = rcode..";"..msg
    result["code"] = "1"

    return dkjson.encode(result)
end

function invalid_address_check(input)
    --检查ip
    if (input.ipaddr == nil) then
        module_debug.lua_debug(module_debug.ERROR, "IP is null!")
        return -1
    end 
    
    local ipaddr1, ipaddr2, ipaddr3, ipaddr4 = string.match(input.ipaddr, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")

    if (ipaddr1 == nil or ipaddr2 == nil or ipaddr3 == nil or ipaddr4 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "IP is error!")
        return -1
    end

    if (tonumber(ipaddr1) > 239) then
        module_debug.lua_debug(module_debug.ERROR, "IP is Multicast IP!")
        return -1
    end
    
    if(tonumber(ipaddr1) > 223) then
        module_debug.lua_debug(module_debug.ERROR, "IP is Reserved IP!")
        return -1
    end

    if(tonumber(ipaddr1) == 0 or tonumber(ipaddr1) == 127) then
        module_debug.lua_debug(module_debug.ERROR, "IP is 0 or 127!")
        return -1
    end

    --检查mac
    if (input.macaddr == nil) then
        module_debug.lua_debug(module_debug.ERROR, "MAC is null!")
        return -2
    end
 
    local macaddr1, macaddr2, macaddr3, macaddr4, macaddr5, macaddr6 = string.match(input.macaddr, "^(%x+):(%x+):(%x+):(%x+):(%x+):(%x+)$")
    if (macaddr1 == nil or macaddr2 == nil or macaddr3 == nil or macaddr4 == nil or macaddr5 == nil or macaddr6 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "MAC is error!")
        return -2
    end
    
    if (tonumber(macaddr1, 16) == 255) then
        module_debug.lua_debug(module_debug.ERROR, "MAC is Multicast MAC!")
        return -2
    end
    
    if (tonumber(macaddr1, 16) % 2 ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "MAC is illegal MAC!")
        return -2
    end

    if (input.interface ~= nil) then
        if (lib_param.lua_param_safety_check(input.interface) ~= true) then
            module_debug.lua_debug(module_debug.ERROR, "interface is illegal interface!")
            return -3
        end
    end

    return 0
end

local function enable_check(enable)
    if (type(enable) ~= "string") then
        return -1
    end
    
    if (enable ~= "1" and enable ~= "0") then
        return -1
    end
    
    return 0
end

local function checkparam_for_array(intf)
    if (type(intf) ~= "table") then
        return -1
    end

    for key,value in pairs(intf) do
        if (string.match(value, "[^%w_-]") ~= nil) then
            return -1
        end
    end

    return 0
end

--查询记录是否存在
function for_json(json,data)
    local num = 1
    local length = table.maxn(json["arp_static"])
    
    --对比ip地址是否已存在，存在返回存在数组中的编号。不存在返回0
    while ( num < length + 1 )
    do
        if ( json["arp_static"][num]["ipaddr"] == data["ipaddr"] )
        then
            return num
        end  
        
        --[[if (capacity["dev_type"] ~= "msw") then
            if ( string.upper(json["arp_static"][num]["macaddr"]) == string.upper(data["macaddr"]) ) then
                return num
            end
        end]]--
        
        num = num + 1
    end
    
    return 0
end

function trim(str)
   return (string.gsub(str, "^%s*(.-)%s*$", "%1"))
end

--执行增加命令
function cmd_add(ipaddr,macaddr,interface)
    --[[if (#interface ~= 0) then 
        op = "/sbin/arp -i "..interface.." -s "..ipaddr.." "..macaddr.." ".."2>/dev/null;echo $?"
    else
        op = "/sbin/arp -s "..ipaddr.." "..macaddr.." ".."2>/dev/null;echo $?"
    end]]--

    op = "/sbin/arp -s "..ipaddr.." "..macaddr.." ".."2>/dev/null;echo $?"
    local result = io.popen(op)
    ret = trim(result:read("*a"))
    result:close()

    if (ret == "0") then
        module_debug.lua_debug(module_debug.INFO, "add arp_static [%s] [%s] bind success!", ipaddr, macaddr)
        return 0
    else
        module_debug.lua_debug(module_debug.WARNING, "add arp_static [%s] [%s] bind failed!", ipaddr, macaddr)
        return -1
    end
end

--执行删除命令
function cmd_del(ipaddr,interface)
    --[[if (#interface ~= 0) then 
        op = "/sbin/arp -i "..interface.." -d "..ipaddr.." 2>/dev/null;echo $?"
    else
        op = "/sbin/arp -d "..ipaddr.." 2>/dev/null;echo $?"
    end]]--

    op = "/sbin/arp -d "..ipaddr.." 2>/dev/null;echo $?"
    local result = io.popen(op)
    ret = trim(result:read("*a"))
    result:close()

    if (ret == "0") then
        module_debug.lua_debug(module_debug.INFO, "del arp_static [%s] unbind success!", ipaddr)
        return 0
    else
        module_debug.lua_debug(module_debug.WARNING, "del arp_static [%s] unbind failed!", ipaddr)
        return -1
    end
end

--检查arp记录是否存在
function check_arp(ip, mac)
    local arp_file = "/proc/net/arp"
    if (file_exists(arp_file) == nil) then
        return 0
    end

    local tmp = file_read(arp_file)
    if (#tmp == nil) then
        return 0
    end

    --从ARP表中查询是否存在该ARP表项
    local arplist = split(tmp, "\n")
    for k, v in ipairs(arplist) do
        if (v ~= nil and mac ~= nil and ip ~= nil) then
            v = string.lower(v)
            mac = string.lower(mac)
            if string.find(v, ip) ~= nil and string.find(v, mac) ~= nil and string.find(v, "0x6") ~= nil then
                return 1
            end
        end
    end
    return 0
end

function create_def_json()
    local cap_cfg = "/tmp/sd_device/sd_device.json"
    local def_str = '{"arp_static": [], "bind_enable": "0", "maxLen": "256", "intf_list":[]}'
    local def_cfg = nil

    if (file_exists(cap_cfg)) then
        local cap_con = file_read(cap_cfg)
        cap_con = dkjson.decode(cap_con)
        def_cfg = dkjson.decode(def_str)
        if (cap_con["ip_mac_bind_num"] ~= nil and cap_con["ip_mac_bind_num"] ~= "0") then
            def_cfg["maxLen"] = cap_con["ip_mac_bind_num"]
        end
    end

    os.execute("/usr/sbin/ip_mac_bind.sh stop")
    module_debug.lua_debug(module_debug.WARNING, "Json file is error! try to recover file!")

    return def_cfg
end

-- 获取配置文件内容,配置不存在则使用默认配置
function read_file_data(conf_file)
    if (file_exists(conf_file) == false) then
        return create_def_json()
    end

    local file_data = file_read(conf_file)
    local json = cjson_safe.decode(file_data)

    if (json == nil) then
        json = create_def_json()
    end

    return json
end

--增加arp静态绑定
function conf_add(data, conf_file)
    local json = read_file_data(conf_file)
    local add = dkjson.decode(data)
    local enable = json["bind_enable"]
    local length = table.maxn(json["arp_static"])
    local add_length = table.maxn(add["arp_list"])
    local check_param_len = table.maxn(add["arp_list"])
    local flag = 0
    local failed_tab = {}

    if (capacity["ip_mac_bind_num"] ~= nil) then
        max_num = capacity["ip_mac_bind_num"]
    end
    
    if (max_num == nil or #max_num == 0) then
        max_num = "256"
    end

    --判断记录大小是否已满
    if ( length >= tonumber(max_num) ) then
        module_debug.lua_debug(module_debug.WARNING, "Data already full! the max is %s", max_num)
        return fail_reason("Error: Data already full!","0001", failed_tab)
    end

    while (check_param_len > 0) do
        local ret = invalid_address_check(add["arp_list"][check_param_len])
        if (ret == -1) then
            table.insert(failed_tab, add["arp_list"][check_param_len])
            return fail_reason("Error: The IP address in the parameter is illegal!","0005", failed_tab)
        elseif (ret == -2) then
            table.insert(failed_tab, add["arp_list"][check_param_len])
            return fail_reason("Error: The MAC address in the parameter is illegal!","0006", failed_tab)
        elseif (ret == -3) then
            table.insert(failed_tab, add["arp_list"][check_param_len])
            return fail_reason("Error: The interface in the parameter is illegal!","0007", failed_tab)
        end
        check_param_len = check_param_len - 1
    end

    while ( add_length > 0 ) do
        local num = for_json(json,add["arp_list"][add_length])
        if ( num == 0 ) then

            --网关没有下发interface的信息,所以用""来填充
            if (add["arp_list"][add_length]["interface"] == nil) then
                add["arp_list"][add_length]["interface"] = ""
            end
            
            ret = cmd_add(add["arp_list"][add_length]["ipaddr"],add["arp_list"][add_length]["macaddr"],add["arp_list"][add_length]["interface"])
            add["arp_list"][add_length]["macaddr"] =  string.lower(add["arp_list"][add_length]["macaddr"])
            
            table.insert(json["arp_static"],add["arp_list"][add_length])
            flag = 1
            
            --判断是否需要加入到ip-mac绑定
            if ( enable == "1" )
            then
                os.execute("/usr/sbin/ip_mac_bind.sh add".." "..dkjson.encode(add["arp_list"][add_length]["ipaddr"]).." "..dkjson.encode(add["arp_list"][add_length]["macaddr"]))
            end
        else
            module_debug.lua_debug(module_debug.WARNING, "Data [%s] [%s] already exists!", add["arp_list"][add_length]["ipaddr"], add["arp_list"][add_length]["macaddr"])
            local data = {}
            data["ipaddr"] = add["arp_list"][add_length]["ipaddr"]
            data["macaddr"] = add["arp_list"][add_length]["macaddr"]
            table.insert(failed_tab, data)
        end
        
        add_length = add_length - 1
    end
    
    if (flag == 1) then
        file_write(conf_file,dkjson.encode(json))
    end

    if (#failed_tab ~= 0) then
        return fail_reason("Error: add arp static failed","0002", failed_tab)
    end
    
    return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
end

--删除arp静态绑定
function conf_del(data, conf_file)
    local json = read_file_data(conf_file)
    local del = dkjson.decode(data)
    local enable = json["bind_enable"]
    local length = table.maxn(json["arp_static"])
    local del_length = table.maxn(del["arp_list"])
    local check_param_len = table.maxn(del["arp_list"])
    local flag = 0
    local failed_tab = {}

    while (check_param_len > 0) do
        local ret = invalid_address_check(del["arp_list"][check_param_len])
        if (ret == -1) then
            table.insert(failed_tab, del["arp_list"][check_param_len])
            return fail_reason("Error: The IP address in the parameter is illegal!","0005", failed_tab)
        elseif (ret == -2) then
            table.insert(failed_tab, del["arp_list"][check_param_len])
            return fail_reason("Error: The MAC address in the parameter is illegal!","0006", failed_tab)
        elseif (ret == -3) then
            table.insert(failed_tab, del["arp_list"][check_param_len])
            return fail_reason("Error: The interface in the parameter is illegal!","0007", failed_tab)
        end
        check_param_len = check_param_len - 1
    end

    --从后往前删除
    while ( 0 < del_length ) do
        local num = for_json(json,del["arp_list"][del_length])

        if ( num ~= 0 ) then
            
            --网关没有下发interface的信息,所以用""来填充
            if (del["arp_list"][del_length]["interface"] == nil) then
                del["arp_list"][del_length]["interface"] = ""
            end
            
            local ret = cmd_del(del["arp_list"][del_length]["ipaddr"], del["arp_list"][del_length]["interface"])

            ret = check_arp(del["arp_list"][del_length]["ipaddr"], del["arp_list"][del_length]["macaddr"])
            if (ret == 0) then
                table.remove(json["arp_static"],num)
                flag = 1
                    
                --判断是否需要从ip-mac绑定中删除
                if ( enable == "1" )
                then
                    os.execute("/usr/sbin/ip_mac_bind.sh del".." "..dkjson.encode(del["arp_list"][del_length]["ipaddr"]).." "..dkjson.encode(del["arp_list"][del_length]["macaddr"]))
                end
            end
        else
            module_debug.lua_debug(module_debug.WARNING, "Data doesn't exist! clear the non-exist data %s", del["arp_list"][del_length]["ipaddr"])

            cmd_del(del["arp_list"][del_length]["ipaddr"], del["arp_list"][del_length]["interface"])
            os.execute("/usr/sbin/ip_mac_bind.sh del".." "..dkjson.encode(del["arp_list"][del_length]["ipaddr"]).." "..dkjson.encode(del["arp_list"][del_length]["macaddr"]))
        end
        del_length = del_length - 1
    end

    if (flag == 1) then
        file_write(conf_file, dkjson.encode(json))
    end

    if (#failed_tab ~= 0) then
        return fail_reason("Error: del arp static failed","0003", failed_tab)
    end
    
    return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
end

--修改arp静态绑定
function conf_update(data, conf_file)
    local json = read_file_data(conf_file)
    local updata = dkjson.decode(data)
    local bind_enable = json["bind_enable"]
    local enable = updata["bind_enable"]
    local intf_list = updata["intf_list"]
    local length = table.maxn(json["arp_static"])
    local failed_tab = {}
    local add_tab = {}
    
    --是否开启ip-mac绑定
    if ( enable ~= nil ) then
        if (enable_check(enable) ~= 0) then
            return fail_reason("Error: set arp static failed","0002", failed_tab)
        end
        
        json["bind_enable"] = enable
        if (type(intf_list) == "table") then
            if (checkparam_for_array(intf_list) ~= 0) then
                return fail_reason("Error: set arp static failed","0002", failed_tab)
            end

            --   "intf_list": ["lan","lan_22"]
            for k, v in ipairs(intf_list) do
                if (v ~= "lan") then
                    intf, vlan = string.match(v, "^(%a+)_(%d+)$")

                    if (intf ~= "lan" or (vlan == nil or tonumber(vlan) < 1 or tonumber(vlan) > 4096)) then
                        return fail_reason("Error: set arp static failed","0002", failed_tab)
                    end
                end
            end

            json["intf_list"] = intf_list
        end
        
        file_write(conf_file,dkjson.encode(json))
        if ( enable == "0" )
        then
            os.execute("/usr/sbin/ip_mac_bind.sh stop")
            module_debug.lua_debug(module_debug.INFO, "ip_mac_bind closed!")
        else
            os.execute("/usr/sbin/arp_static_exec.lua open &")
            module_debug.lua_debug(module_debug.INFO, "ip_mac_bind opened!")
        end
        
        return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
    end
    
    local ret = invalid_address_check(updata["arp_new"])
    if (ret == -1) then
        table.insert(failed_tab, updata["arp_new"])
        return fail_reason("Error: The IP address in the parameter is illegal!","0005", failed_tab)
    elseif (ret == -2) then
        table.insert(failed_tab, updata["arp_new"])
        return fail_reason("Error: The MAC address in the parameter is illegal!","0006", failed_tab)
    elseif (ret == -3) then
        table.insert(failed_tab, updata["arp_new"])
        return fail_reason("Error: The interface in the parameter is illegal!","0007", failed_tab)
    end
    
    local ret = invalid_address_check(updata["arp_old"])
    if (ret == -1) then
        table.insert(failed_tab, updata["arp_old"])

        return fail_reason("Error: The IP address in the parameter is illegal!","0005", failed_tab)
    elseif (ret == -2) then
        table.insert(failed_tab, updata["arp_old"])

        return fail_reason("Error: The MAC address in the parameter is illegal!","0006", failed_tab)
    elseif (ret == -3) then
        table.insert(failed_tab, updata["arp_old"])

        return fail_reason("Error: The interface in the parameter is illegal!","0007", failed_tab)
    end

    if (updata["arp_old"]["ipaddr"] == updata["arp_new"]["ipaddr"] 
    and string.lower(updata["arp_old"]["macaddr"]) == string.lower(updata["arp_new"]["macaddr"])) then

        module_debug.lua_debug(module_debug.INFO, "the config is no change!")
        return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
    end

    local num = for_json(json,updata["arp_new"])
    if ( num ~= 0 ) then
        if (updata["arp_old"]["ipaddr"] ~= json["arp_static"][num]["ipaddr"]
    or string.lower(updata["arp_old"]["macaddr"]) ~= string.lower(json["arp_static"][num]["macaddr"])) then
            module_debug.lua_debug(module_debug.WARNING, " %s conflict with config entry", updata["arp_new"]["ipaddr"])
        return fail_reason("Error: update arp static failed","0004", failed_tab)
        end
    end
    
    --网关没有下发interface的信息,所以用""来填充
    if (updata["arp_new"]["interface"] == nil) then
        updata["arp_new"]["interface"] = ""
    end    

    if (updata["arp_old"]["interface"] == nil) then
        updata["arp_old"]["interface"] = ""
    end

    cmd_del(updata["arp_old"]["ipaddr"], updata["arp_old"]["interface"])

    cmd_add(updata["arp_new"]["ipaddr"], updata["arp_new"]["macaddr"], updata["arp_new"]["interface"])
    local num = for_json(json,updata["arp_old"])
    if ( num ~= 0 ) then
        json["arp_static"][num]["ipaddr"] = updata["arp_new"]["ipaddr"]
        json["arp_static"][num]["macaddr"] = string.lower(updata["arp_new"]["macaddr"])
        json["arp_static"][num]["interface"] = updata["arp_new"]["interface"]
    else
        -- 配置不存在则直接添加
        add_tab["ipaddr"] = updata["arp_new"]["ipaddr"]
        add_tab["macaddr"] = string.lower(updata["arp_new"]["macaddr"])
        
        table.insert(json["arp_static"], add_tab)
    end
    file_write(conf_file,dkjson.encode(json))
    --判断是否需要在ip-mac绑定中修改
    if ( bind_enable == "1" ) then
        os.execute("/usr/sbin/ip_mac_bind.sh update".." "..dkjson.encode(updata["arp_old"]["ipaddr"]).." "..dkjson.encode(updata["arp_old"]["macaddr"]).." "..dkjson.encode(updata["arp_new"]["ipaddr"]).." "..dkjson.encode(updata["arp_new"]["macaddr"]))
    end


    if (#failed_tab ~= 0) then
        return fail_reason("Error: update arp static failed","0004", failed_tab)
    end
    
    return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
end

--get the capacity
if (file_exists(device) == true) then
    capacity = dkjson.decode(file_read(device))
end

function module_default_config_get()
    local cap_cfg = "/tmp/sd_device/sd_device.json"
    local def_cfg = '{"arp_static": [], "bind_enable": "0", "maxLen": "256", "intf_list":[]}'

    if (file_exists(cap_cfg)) then
        local cap_con = file_read(cap_cfg)
        cap_con = dkjson.decode(cap_con)
        def_cfg = dkjson.decode(def_cfg)
        if (cap_con["ip_mac_bind_num"] ~= nil and cap_con["ip_mac_bind_num"] ~= "0") then
            def_cfg["maxLen"] = cap_con["ip_mac_bind_num"]
        end
        def_cfg = dkjson.encode(def_cfg)
    end

    return def_cfg
end

function module_add(param)
    return conf_add(param, CONFIG_FILE)
end

function module_del(param)

    return conf_del(param, CONFIG_FILE)
end

function module_update(param)
    return conf_update(param, CONFIG_FILE)
end

function module_set(param)
    local failed_tab = {}
    local data = dkjson.decode(param)
    
    if (data["arp_static"] == nil) then
        return fail_reason("Error: set arp static failed","0002", failed_tab)
    end
    
    local check_param_len = table.maxn(data["arp_static"])
    
    while (check_param_len > 0) do
        local ret = invalid_address_check(data["arp_static"][check_param_len])
        if (ret == -1) then
            table.insert(failed_tab, data["arp_static"][check_param_len])
            return fail_reason("Error: The IP address in the parameter is illegal!","0005", failed_tab)
        elseif (ret == -2) then
            table.insert(failed_tab, data["arp_static"][check_param_len])
            return fail_reason("Error: The MAC address in the parameter is illegal!","0006", failed_tab)
        end
        check_param_len = check_param_len - 1
    end
    
    if (data["bind_enable"] ~= nil) then
        if (enable_check(data["bind_enable"]) ~= 0) then
            return fail_reason("Error: set arp static failed","0002", failed_tab)
        end
    end

    if (data["intf_list"] ~= nil and type(data["intf_list"]) == "table") then
        if (checkparam_for_array(data["intf_list"]) ~= 0) then
            return fail_reason("Error: set arp static failed","0002", failed_tab)
        end

        --   "intf_list": ["lan","lan_22"]
        for k, v in ipairs(data["intf_list"]) do
            if (v ~= "lan") then
                intf, vlan = string.match(v, "^(%a+)_(%d+)$")

                if (intf ~= "lan" or (vlan == nil or tonumber(vlan) < 1 or tonumber(vlan) > 4096)) then
                    return fail_reason("Error: set arp static failed","0002", failed_tab)
                end
            end
        end

    end

    local elisten ="/lib/functions/elisten_function.sh"
    if (file_exists(elisten)) then
        os.execute("ubus -t 3 send arp_static_restart")
    else
        os.execute("/etc/init.d/arp_static restart")
    end
    
    return '{"message":"Configuration success","data":[],"rcode":"00000000"}'
end

function module_apply()
    if (file_exists("/proc/shortcut_flush") == true) then
        os.execute("echo 'f' > /proc/shortcut_flush") 
    end

    if (file_exists("/usr/lib/lua/hnat/hwnat_clean_entry.lua") == true) then
        os.execute("/usr/bin/lua /usr/lib/lua/hnat/hwnat_clean_entry.lua");
    end
end
