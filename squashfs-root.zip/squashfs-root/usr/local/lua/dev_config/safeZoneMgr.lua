#! /usr/bin/env lua

module_name = "safeZoneMgr"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

dkjson = require "dkjson"
cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"

cfg_uuid_tb = {}
cfg_ip_tb = {}
cfg_intf_tb = {}
cfg_tb_num = 0
def_loacl_safe_num = "32"
config_file = "/etc/sd_config/single/safeZoneMgr.json"
----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")

local err_code = {
    ["SUCCESS"] = "00000000",
    ["ERR_SAFEZONEMGR_PARAM_EXCEPTION"] = "04300001",
    ["ERR_SAFEZONEMGR_CONFIG_EXCEPTION"] = "04300002",
    ["ERR_SAFEZONEMGR_DUP_CONFIG"] = "04300003",
    ["ERR_SAFEZONEMGR_NOEXIST_CONFIG"] = "04300004",
    ["ERR_SAFEZONEMGR_EXCEEED_CONFIG"] = "04300005",
}

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- return error message if execution fails
-- @code: error code
-- @msg: error msg
-- @If it fails to return an error, it is considered that the configuration has failed
local function fail_reason(code, msg)
    local err = {}
    local ret = {}

    err["rcode"] = code
    err["message"] = msg
    ret["code"] = "1"
    ret["err"] = cjson_safe.encode(err)

    return cjson_safe.encode(ret)
end


local function checkparam_for_intf(intf)
    if (intf == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The intf is null")
        return -1
    end

    if (type(intf) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The intf is abnormal")
        return -1
    end
    
    str = string.match(intf, "[^%w_-]")
    if (str ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "The intf is abnormal")
        return -1
    end

    return 0
end

local function checkparam_for_rulename(rulename)
    if (rulename == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The rulename is null")
        return -1
    end
    
    if (type(rulename) ~= "string" or string.len(rulename) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "The rulename is abnormal")
        return -1
    end

    return 0
end

-- check the ip range is normal or not.
-- @return 0, if the check success; otherwise return -1.
local function ip_range_check(ipnum)
    if (type(ipnum) ~= "string" or #ipnum == 0) then
        module_debug.lua_debug(module_debug.ERROR, "ipnum is error")
        return -1
    end

    ipnum = tonumber(ipnum)
    if (ipnum == nil or ipnum > 255 or ipnum < 0) then
        module_debug.lua_debug(module_debug.ERROR, "ipnum[%d] is out of range", ipnum)
        return -1
    end

    return 0
end

-- check the ip is available or not.
-- @return 0, if the check success; otherwise return -1.
local function ip_validity_check(ipaddr)
    local ipmin_len = 7
    local ipmax_len = 15
    local s_pos, d_pos, i
    local ip1, ip2, ip3, ip4

    ---------------7 <= ip length <= 15-------------
    local length = string.len(ipaddr);
    if (length < ipmin_len or length > ipmax_len) then
        module_debug.lua_debug(module_debug.ERROR, "ip length[%d] is error", length)
        return -1
    end

    -----------------check illegal character--------
    i = 0
    s_pos = 0
    while (s_pos ~= nil) do
        s_pos, d_pos, value = string.find(ipaddr, "([^%d])", s_pos)
        if s_pos ~= nil then
            s_pos = s_pos + 1
            i = i + 1
        end
    end

    if (i ~= 3) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr [%s] pattern is error", ipaddr)
        return -1
    end

    -----------------check ip style----------------
    ip1, ip2, ip3, ip4 = string.match(ipaddr, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if (ip1 == nil or ip2 == nil or ip3 == nil or ip4 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr style is error")
        return -1
    end

    if (ip_range_check(ip1) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] first place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip2) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] second place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip3) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] third place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip4) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] fourth place is error", ipaddr)
        return -1
    end

    ---------------check special address--------------
    if (type(ip1) == "string") then
        ip1 = tonumber(ip1)
        if (ip1 == nil or ip1 == 0 or ip1 == 127) then
            module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] is unusable", ipaddr)
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] first place is error", ipaddr)
        return -1
    end

    return 0
end

local function ip_str_to_int(ipaddr)
    module_debug.lua_debug(module_debug.INFO, "ip_str_to_int() ipaddr:%s", ipaddr);
    local ip = require("utils.string").string_split_to_table(ipaddr, ".")

    if (#ip ~= 4) then
        return false
    end
    
    for i = 1, #ip do
        if (tonumber(ip[i]) < 0 or tonumber(ip[i]) > 255) then
            return false
        end
    end
    
    local ip_int = ip[1] * 16777216 + ip[2] * 65536 + ip[3] * 256 + ip[4];
    module_debug.lua_debug(module_debug.INFO, "ip_str_to_int() ip_int:%s", ip_int)

    return true, ip_int
end

local function checkparam_for_iprange(iprange)
    if (iprange == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The iprange is null")
        return -1
    end
    
    if (type(iprange) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The iprange is abnormal")
        return -1
    end      

    if (string.len(iprange) == 0) then
        return 0
    end
    
    if (string.find(iprange, "-") == nil) then
        if (ip_validity_check(iprange) == -1) then
            return -1
        end
    else
        ipstart, ipend = string.match(iprange, "^(%S+)-(%S+)$")
        if (ipstart == nil or ipend == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ipange style is error")
            return -1
        end
        
        if (ip_validity_check(ipstart) == -1 or ip_validity_check(ipend) == -1) then
            return -1
        end
        
        ret, ipstart_int = ip_str_to_int(ipstart)
        if (ret ~= true) then
            module_debug.lua_debug(module_debug.ERROR, "ip addr start [%s] pattern is error, cannot be converted to type int", ipstart)
            return -1
        end
        
        ret, ipend_int = ip_str_to_int(ipend)
        if (ret ~= true) then
            module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", ipend)
            return -1
        end
        
        if (ipstart_int > ipend_int) then
            module_debug.lua_debug(module_debug.ERROR, "ipange style is error, start address is greater than end address")
            return -1
        end
    end

    return 0
end

local function checkparam_is_json(param)
    if (type(param) == "string") then
        module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", module_name, param)
    else
        return nil
    end

    local param_json = cjson_safe.decode(param)
    if (param_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter format is not json")
        return nil
    end

    return param_json
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

local function checkparam_for_uuid(param)
    if (type(param) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "the uuid style isn't string")
        return -1
    end

    if (string.len(param) < 0 or string.len(param) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid length is error")
        return -1
    end

    if (string.match(param, "%W") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "the uuid isn't illegal")
        return -1
    end
    
    return 0
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = dkjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)
            local temp_path = path .. ".tmp"
            res = file_write(temp_path, config_str)
            if (res == 0) then
                -- Attempt to rename temp file to target path
                local rename_success = os.rename(temp_path, path)
                if (rename_success) then
                    return 0
                else
                    module_debug.lua_debug(module_debug.ERROR, "Failed to rename temp file [%s] to [%s]", temp_path, path)
                    os.remove(temp_path)  -- Clean up temp file on failure
                    return -1
                end
            else
                module_debug.lua_debug(module_debug.ERROR, "Failed to write to temp file [%s]", temp_path)
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end
    
    return 0
end

local function config_index_table(config_json)
    for k,v in pairs(config_json["list"]) do
        cfg_uuid_tb[v["uuid"]] = k
        
        cfg_tb_num = cfg_tb_num + 1
        
        if (string.len(v["iprange"]) ~= 0) then
            cfg_ip_tb[v["iprange"]] = k
        end
        
        if (string.len(v["intf"]) ~= 0) then
            cfg_intf_tb[v["intf"]] = k
        end
    end
end

local function find_exist_node_by_uuid(uuid)
    local idx = nil
    
    if (uuid ~= nil) then
        idx = cfg_uuid_tb[uuid]
    end
    
    return idx
end

local function find_exist_node_by_iprange(ip)
    local idx = nil
    
    if (ip ~= nil) then
        idx = cfg_ip_tb[ip]
    end
    
    return idx
end


local function find_exist_node_by_intf(intf)
    local idx = nil
    
    if (intf ~= nil) then
        idx = cfg_intf_tb[intf]
    end
    
    return idx
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil
    end
    
    local sh_ret_handle = io.popen(sh_cmd)
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret
end

local function add_mem_for_set(param)
    if (string.len(param["iprange"]) ~= 0) then
        if (string.find(param["iprange"], "-") ~= nil) then
            ipstart, ipend = string.match(param["iprange"], "^(%S+)-(%S+)$")
            if (ipstart == nil or ipend == nil) then
                module_debug.lua_debug(module_debug.ERROR, "ipange style is error")
                return -1
            end
            
            ret, ipstart_int = ip_str_to_int(ipstart)
            if (ret ~= true) then
                module_debug.lua_debug(module_debug.ERROR, "ip addr start [%s] pattern is error, cannot be converted to type int", ipstart)
                return -1
            end
            
            ret, ipend_int = ip_str_to_int(ipend)
            if (ret ~= true) then
                module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", ipend)
                return -1
            end
            
            ret, boundary = ip_str_to_int("129.0.0.0")
            if (ret ~= true) then
                module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", "129.0.0.0")
                return -1
            end
            
            if (ipstart_int < boundary and ipend_int > boundary) then
                cmd = string.format("ipset add safeZoneMgr_inet4 %s-129.0.0.0 -exist & >/dev/null 2>&1", ipstart)
                exec(cmd)
                
                cmd = string.format("ipset add safeZoneMgr_inet4 129.0.0.0-%s -exist & >/dev/null 2>&1", ipend)
                exec(cmd)
            else
                cmd = string.format("ipset add safeZoneMgr_inet4 %s -exist & >/dev/null 2>&1", param["iprange"])
                exec(cmd)
            end
        else
            cmd = string.format("ipset add safeZoneMgr_inet4 %s -exist & >/dev/null 2>&1", param["iprange"])
            exec(cmd)
        end
    end
    
    if (string.len(param["intf"]) ~= 0) then
        cmd = string.format("ipset add safeZoneMgr_intf4 0.0.0.0/0,br-%s -exist & >/dev/null 2>&1", param["intf"])
        exec(cmd)
        
        cmd = string.format("ipset add safeZoneMgr_intf6 ::/0,br-%s -exist & >/dev/null 2>&1", param["intf"])
        exec(cmd)
        
        if (string.find(param["intf"], "wan") ~= nil) then
            cmd = string.format("ipset add safeZoneMgr_intf4 0.0.0.0/0,pppoe-%s -exist & >/dev/null 2>&1", param["intf"])
            exec(cmd)
            
            cmd = string.format("ipset add safeZoneMgr_intf6 ::/0,pppoe-%s -exist & >/dev/null 2>&1", param["intf"])
            exec(cmd)   
        end
    end

    return 0
end

local function add_node_to_config(node, config_json)
    local new_node = {}
    
    new_node["uuid"] = node["uuid"]
    new_node["name"] = node["name"]
    new_node["intf"] = node["intf"]
    new_node["iprange"] = node["iprange"]
    
    cfg_uuid_tb[node["uuid"]] = cfg_tb_num + 1
    
    if (string.len(node["iprange"]) ~= 0) then
        cfg_ip_tb[node["iprange"]] = cfg_tb_num + 1
    end
    
    if (string.len(node["intf"]) ~= 0) then
        cfg_intf_tb[node["intf"]] = cfg_tb_num + 1
    end
    
    table.insert(config_json["list"], new_node)
end

local function update_node_to_config(node, cfg_node)
    if (cfg_node["intf"] ~= node["intf"]) then
        cfg_node["intf"] = node["intf"]
    end

    if (cfg_node["iprange"] ~= node["iprange"]) then
        cfg_node["iprange"] = node["iprange"]
    end

    if (cfg_node["name"] ~= node["name"]) then
        cfg_node["name"] = node["name"]
    end
end

local function add_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0
    
    for k,v in pairs(param_json["list"]) do
        uuid = find_exist_node_by_uuid(v["uuid"])
        intf_id = find_exist_node_by_intf(v["intf"])
        iprange_id = find_exist_node_by_iprange(v["iprange"])
        
        if (uuid == nil and intf_id == nil and iprange_id == nil) then
             add_node_to_config(v, config_json)
             cfg_tb_num = cfg_tb_num + 1
             change_flag = 1
        end
    end

    config_json["total"] = tostring(cfg_tb_num)
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "add json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

local function del_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0
    
    for k,v in pairs(param_json["list"]) do
        for conf_k, conf_v in pairs(config_json["list"]) do
            if (v == conf_v["uuid"]) then
                table.remove(config_json["list"], conf_k)
                cfg_tb_num = cfg_tb_num - 1
                change_flag = 1
            end
        end
    end

    config_json["total"] = tostring(cfg_tb_num)
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "del json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

local function update_param_to_config(param_json, config_json, config_file_path)
    local change_flag = 0

    if (param_json["list"] ~= nil) then
        for k,v in pairs(param_json["list"]) do
            uuid = find_exist_node_by_uuid(v["uuid"])
            intf_id = find_exist_node_by_intf(v["intf"])
            iprange_id = find_exist_node_by_iprange(v["iprange"])

            if (uuid ~= nil) then
                if ((intf_id == nil or intf_id == uuid) and (iprange_id == nil or iprange_id == uuid)) then
                    update_node_to_config(v, config_json["list"][uuid])
                    change_flag = 1
                end
            end
        end
    end
    
    if (change_flag == 1) then
        ret = json_write_to_file(config_file_path, config_json)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "update json_write_to_file failed")
            return -1
        end
    end
    
    return 0
end

-- default config
function module_default_config_get()
    local def_cfg_str = '{"list":[]}'

    module_debug.lua_debug(module_debug.INFO, "INFO: [module_default_config_get] get default success")

    return def_cfg_str
end

function module_add(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "ERROR: safeZoneMgr config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end
    
    config_index_table(config_json)
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_iprange(v["iprange"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end

        ret = checkparam_for_intf(v["intf"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end
        
        ret = checkparam_for_uuid(v["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end
    end
     
    ret = add_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_CONFIG_EXCEPTION"], "safezone add config failed")
    end
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

--[[
    dev_config del -m safeZoneMgr '{"list":["xxx"]}'
]]--
function module_del(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "ERROR: safeZoneMgr config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end
    
    config_index_table(config_json)
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_rulename(v)
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end
    end
    
    ret = del_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_CONFIG_EXCEPTION"], "safezone add config failed")
    end
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_update(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "ERROR: safeZoneMgr config is null")
    end

    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end

    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end
    
    config_index_table(config_json)
    for k,v in pairs(param_json["list"]) do
        ret = checkparam_for_iprange(v["iprange"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end

        ret = checkparam_for_intf(v["intf"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end
        
        ret = checkparam_for_uuid(v["uuid"])
        if (ret == -1) then
            return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
        end
    end
    
    ret = update_param_to_config(param_json, config_json, config_file_path)
    if (ret == -1) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_CONFIG_EXCEPTION"], "safezone add config failed")
    end
    
    return '{"message":"Configuration success","rcode":"00000000"}'
end

function module_set(param)
    return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "ERROR: the operation is not support")
end

-- Configuration Framework Apply
function module_apply(param, config_file_path)
    local config_json = file_to_json(config_file_path)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGRMGR_EXCEPTION"], "ERROR: safeZoneMgr config is null")
    end
    
    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end
    
    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The list is null")
        return fail_reason(err_code["ERR_SAFEZONEMGR_PARAM_EXCEPTION"], "param is error")
    end
    
    cmd = string.format("ipset flush safeZoneMgr_inet4 -exist & >/dev/null 2>&1")
    exec(cmd)
    
    cmd = string.format("ipset flush safeZoneMgr_intf4 -exist & >/dev/null 2>&1")
    exec(cmd)

    cmd = string.format("ipset flush safeZoneMgr_intf6 -exist & >/dev/null 2>&1")
    exec(cmd)
    
    for k,v in pairs(config_json["list"]) do
        add_mem_for_set(v)
    end

    if (file_exist("/proc/shortcut_flush") == true) then
        os.execute("echo 'f' > /proc/shortcut_flush") 
    end

    if (file_exist("/usr/lib/lua/hnat/hwnat_clean_entry.lua") == true) then
        os.execute("/usr/bin/lua /usr/lib/lua/hnat/hwnat_clean_entry.lua");
    end
end
