#!/usr/bin/env lua
-- dev_config get -m globalAuthConf
-- dev_config set -m globalAuthConf {
--       "proto":"http",
--       "remind_days":"1",
--       "remind_interval":"5",
--       "remind_content":"",
--       "user_state_url":"",
--       "charge_url":"",
--       "remind_url":"",
--       "flow_detect_time":"15"
-- }
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("globalAuthConf",package.seeall)

require "public_module"
local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local product = require("product")
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local default_user_state_url = product.get_product("capacity.portal.user_state_url")
local default_user_state_ip = product.get_product("capacity.auth_ip")
local table_input_err = {rcode = "05630001", rmsg = "param error"}
local table_input_err_2 = {rcode = "05630002", rmsg = "config file error"}
local dns_policy_uuid = "auth_B369940F5FFE78ENXVU1BIW3T7"
local dns_update_cmd = "dev_config update -m dnsPolicy '%s'"
local dns_del_cmd = "dev_config del -m dnsPolicy '%s'"
local dns_conf_file = "/etc/sd_config/single/dnsPolicy.json"
local dns_pram_format =[[
    {
        "confSrc": "auth",
        "domain": "",
        "addresV4":[],
        "addresV6":[],
        "enable":"1",
        "desc":"webauth dns policy",
        "uuid": "",
        "type":"ip",
        "intf":""
    }
]]

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug��ʼ��
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "globalAuthConf.log", 200, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    elseif ret == "0002" then
        return console.uf_lua_fail(table_input_err_2)
    end
end

-- # % & ���� ��Ҫ���⴦��,����URLת�壬jsת��,htmlת��
local function encode_char(str)
    local encode_table = {
        [1] = '%%',
        [2] = '#',
        [3] = '<',
        [4] = '>',
        [5] = '&',
        [6] = '\n',
        [7] = '\\',
        [8] = nil,
        ['%%'] = "%%25",
        ['#'] = "%%23",
        ['&'] = "%%26",
        ['\n'] = "<br/>",
        ['\\'] = "\\\\",
        ['<'] = "&lt;",
        ['>'] = "&gt;",
    }

    for i = 1, #encode_table do
        if (string.find(str, encode_table[i]) ~= nil) then
                str = string.gsub(str, encode_table[i], encode_table[encode_table[i]])
        end
    end
    return str
end

local function dns_update(param_domain, param_ip)
    local dns_tab = {}
    local dns_second_tab = cjson.decode(dns_pram_format)
    dns_tab["list"] = {}
    dns_second_tab["uuid"] = dns_policy_uuid
    dns_second_tab["domain"] = param_domain
    table.insert(dns_second_tab["addresV4"], param_ip)

    table.insert(dns_tab["list"], dns_second_tab)
    local cmd = string.format(dns_update_cmd, cjson.encode(dns_tab))
    module_debug.lua_debug(module_debug.INFO, "cmd: %s", cmd);
    os.execute(cmd)
end

local function dns_del(param)
    local dns_tab = {}
    dns_tab["list"] = {}
    table.insert(dns_tab["list"], param)
    local cmd = string.format(dns_del_cmd, cjson.encode(dns_tab))
    module_debug.lua_debug(module_debug.INFO, "cmd: %s", cmd);
    os.execute(cmd)
end

--@globalAuthConf_set
function globalAuthConfSet(param_tab)
    local dns_domain = nil
    
    -- app_auth uci
    if param_tab["remind_days"] ~= nil and param_tab["remind_days"] ~= "" then
        remind_days_old = uci:get("app_auth", "app_auth", "remind_days")
        if (remind_days_old ~= param_tab["remind_days"]) then
            uci:set("app_auth", "app_auth", "remind_days", param_tab["remind_days"])
            os.execute("account_mgr_cmd.elf -O 2>/dev/null > /dev/null &")
        end
    end
    if param_tab["remind_interval"] ~= nil and param_tab["remind_interval"] ~= "" then
        uci:set("app_auth", "app_auth", "remind_interval", param_tab["remind_interval"])
    end
    if param_tab["flow_detect_time"] ~= nil and param_tab["flow_detect_time"] ~= "" then
        uci:set("app_auth", "app_auth", "offline_detect", param_tab["flow_detect_time"])
    end
    if param_tab["proto"] == "https" then
        uci:set("app_auth", "app_auth", "proto_https", "1")
    elseif param_tab["proto"] == "http" then
        uci:set("app_auth", "app_auth", "proto_https", "0")
    end
    -- ��ҪЭ�� 
    if param_tab["user_state_url"] == "" then
        dns_domain = ""
        local ret = dns_del(dns_policy_uuid)
        if ret == -1 then
            module_debug.lua_debug(module_debug.ERROR, "dns_update error");
            return -1
        end
    else
        local domain = string.match(param_tab["user_state_url"],'https?://([^/]*)')
        if (domain == nil) then
            dns_domain = param_tab["user_state_url"]
        else
            dns_domain = domain
        end
        -- ����dnsmsq�ӿ� 
        local ret = dns_update(dns_domain, default_user_state_ip)
        if ret == -1 then
            module_debug.lua_debug(module_debug.ERROR, "dns_update error");
            return -1
        end
    end

    if (dns_domain ~= nil) then
        uci:set("app_auth", "app_auth", "user_state_url", dns_domain)
        uci:set("webservice", "webservice", "user_state_url", dns_domain)
    end
    if param_tab["http_host_check"] ~= nil and param_tab["http_host_check"] ~= "" then
        uci:set("app_auth", "app_auth", "http_host_check", param_tab["http_host_check"])
    else
        uci:set("app_auth", "app_auth", "http_host_check", "0")
    end
    uci:commit("app_auth")

    if param_tab["charge_url"] ~= nil and param_tab["charge_url"] ~= "" then
        uci:set("webservice", "webservice", "charge_url", param_tab["charge_url"])
    end
    if param_tab["remind_url"] ~= nil and param_tab["remind_url"] ~= "" then
        uci:set("webservice", "webservice", "remind_url", param_tab["remind_url"])
    end

    if (param_tab["remind_content"] == nil or param_tab["remind_content"] == "") then
        param_tab["remind_content"] = " "
    end
    local tmp = encode_char(param_tab["remind_content"])
    uci:set("webservice", "webservice", "remind_content", tmp)
    if param_tab["proto"] == "https" then
        uci:set("webservice", "webservice", "proto_https","1")
    elseif param_tab["proto"] == "http" then
        uci:set("webservice", "webservice", "proto_https","0")
    end
    
    uci:commit("webservice")

    return 0
end
--------------------------------------------------------------------------------------------
function module_default_config_get()
    local offline_detect = uci:get("app_auth", "app_auth", "offline_detect")
    local default_config = [[
        {
            "proto":"http",
            "remind_days":"1",
            "remind_interval":"24",
            "remind_content":"",
            "user_state_url":"",
            "charge_url":"",
            "remind_url":"",
            "flow_detect_time":"15",
            "http_host_check": "0"
        }
      ]]
    if (offline_detect ~= nil) then
        local default_config_tab = cjson.decode(default_config);
        if (default_config_tab == nil) then
            return default_config
        end
        default_config_tab["flow_detect_time"] = offline_detect
        default_config_tab["user_state_url"] = default_user_state_url
        return cjson.encode(default_config_tab)
    end
    return default_config
end

--------------------------------------------------------------------------------------------
function module_set(param)
    debug_init();

    --����У��
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end
    if (lib_param.lua_param_safety_check(param_tab["user_state_url"]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end
    if (param_tab["version"] ~= nil and param_tab["version"] ~= "" and lib_param.lua_param_safety_check(param_tab["version"]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end

    ret = globalAuthConfSet(param_tab)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] globalAuthConfSet is failed param is %s", param)
        return check_result("0001")
    end

    module_debug.lua_debug(module_debug.INFO, "[module_set] is OK")

    return check_result("0000")
end
-----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end