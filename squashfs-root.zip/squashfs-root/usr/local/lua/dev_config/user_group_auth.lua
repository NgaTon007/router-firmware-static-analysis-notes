#!/usr/bin/env lua
--dev_config set --module "user_group_auth" '{"data":[{"groupName":"222_ACCOUNT","maxDownlinkSpeed":2048,"maxUplinkSpeed":1024,"type":"ACCOUNT","uuid":"38562134521427812172759063620586"},{"groupName":"333_ACCOUNT","maxDownlinkSpeed":0,"maxUplinkSpeed":0,"type":"ACCOUNT","uuid":"38562134521427812172759063620587"}]}'
--dev_config set --module "user_group_auth" '{"data":[]}'
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("user_group_auth",package.seeall)

local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local console = require "console"
local guest_auth = require "guest_auth.guest_auth_common"
local DEBUG_LOG_DIR = "/tmp/user_group/auth/"
local USER_MRG_CMD_ELF = "/usr/sbin/user_mgr_cmd.elf"
local LOCK_FILE = "/tmp/user_group/user_group_auth.lock"
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "user_group_auth.json"})
local table_input_err = {rcode = "05650001", rmsg = "param error"}
local lib_user = require "user_mgr.user_mgr_common"
local product = require("product")
local web_node = product.get_product("capacity.web")
local server_node = product.get_product("capacity.portal.server_name")

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "user_group_auth.log", 500, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function sync_portal_flag()
    local cmd = string.format("cat /tmp/sd_device/sd_device.json | jq .%s.%sPortalSync | sed 's/\"//g'| xargs echo -n", web_node, server_node)
    local t = io.popen(cmd)
    local str = t:read("*all")
    t:close()
    module_debug.lua_debug(module_debug.INFO, "cmd is:%s; str is :%s type of str is %s \n", cmd, str, type(str));
    if (str == "1") then
        module_debug.lua_debug(module_debug.INFO, "sync_portal_flag is %s \n", str);
        return true
    else
        return false
    end
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end
    if (tool.file_exist(lockfile) == true) then
 --已有实例在跑，将配置写入临时文件
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
 --无实例在跑，加锁开始处理
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

function user_group_config(msg)
    local fc_root_grp = {}
    local fc_second_grp = {}
    local fc_first_grp = {}
    local flag = 0
    local asign_id = 0
    fc_root_grp["groups"] = {}
    fc_first_grp["id"] = "2"
    fc_first_grp["child"] = {}
    fc_second_grp["name"] = msg["groupName"]
    fc_second_grp["role"] = "group"
    fc_second_grp["auto"] = "true"
    fc_second_grp["type"] = "auth"
    fc_second_grp["uuid"] = msg["uuid"]
    fc_second_grp["maxUsers"] = msg["maxUsers"]
    table.insert(fc_first_grp["child"], fc_second_grp)
    table.insert(fc_root_grp["groups"], fc_first_grp)
    local config_tab = cjson.encode(fc_root_grp)
    local cmd = "dev_config add -m user_group '"..config_tab.."'"
    module_debug.lua_debug(module_debug.INFO, "cmd = %s", cmd);
    os.execute(cmd)
end

--@user_group_auth_set
function user_group_auth_set(param)
    local total_id_nums = {}
    local exsit_id_nums = {}
    local groupName_nums = {}
    local del_id_table = {}
    local namecode = nil
    local policy_name = nil
    local uuid = nil
    local flag = false

    module_debug.lua_debug(module_debug.INFO, "###############################SET###############################");
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end
    --bugid ==857284||先处理流控策略逻辑
    uci:foreach("user_mgr", "user_grp", function(s)
        namecode = s[".name"]
        uuid = uci:get("user_mgr", namecode, "uuid")
        policy_name = uci:get("user_mgr", namecode, "name")
        if (uuid ~= nil) then		    
            table.insert(total_id_nums, namecode)
       end		
    end
    )
    --bugid ==857284||再处理用户管理行为逻辑:云端用户配置是全量下发，用户管理认证组需要增量实现
    --避免已经经过认证的认证组被删除
    local flag_exsit = 0
    del_id_table["id"] = {}
    for k,var in pairs(param_tab["data"]) do
        uci:foreach("user_mgr", "user_grp", function(s)
            namecode = s[".name"]
            uuid = uci:get("user_mgr", namecode, "uuid")
            policy_name = uci:get("user_mgr", namecode, "name")
            if (uuid ~= nil and policy_name == var["groupName"]) then
                table.insert(exsit_id_nums, namecode)
                table.insert(groupName_nums, var["groupName"])
            end		
        end
        )
    end
    
    for m,n in pairs(exsit_id_nums) do
        for i=#total_id_nums,1,-1 do
            if total_id_nums[i] == n then
                table.remove(total_id_nums, i)
                break
            end
        end
    end
 
    for x,y in pairs(total_id_nums) do
        table.insert(del_id_table["id"], y)
    end
    
    if (del_id_table["id"] ~= nil) then
        local del_tab = cjson.encode(del_id_table)
        local del_cmd = "dev_config del -m user_group '"..del_tab.."'"
        module_debug.lua_debug(module_debug.INFO, "del_cmd[%s]", del_cmd)
        os.execute(del_cmd)
    else
        module_debug.lua_debug(module_debug.INFO, "have no nt_group named")
        return -1
    end
    
    -- 有同步云端portal功能，才需要在maxUsers发生变化时调用guest_auth的update_max_users接口
    flag = sync_portal_flag() 
    for t,var in pairs(param_tab["data"]) do
        local section_name = ""
        for k,grp_name in pairs(groupName_nums) do
            if (grp_name == var["groupName"]) then
                flag_exsit = 1
                section_name = exsit_id_nums[k]
                break
            end
        end
        if (flag_exsit == 1) then
            module_debug.lua_debug(module_debug.INFO, "This configuration already exists. To check should maxUsers update\n")
            if (flag == true) then
                -- 如果maxUsers发生变化，修改uci并调用接口
                local max_users = uci:get("user_mgr", section_name, "maxUsers")
                if (var["maxUsers"] ~= max_users) then 
                    local count = 1
                    while (lib_user.single_uci_writer_check() == false) do
                        if count > 5 then
                            module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
                            return -1
                        end
                        module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
                        tool.sleep(1)
                        count = count + 1
                    end
                    uci:set("user_mgr", section_name, "maxUsers", var["maxUsers"])
                    uci:commit("user_mgr")
                    lib_user.remove_uci_lock_file()
                    module_debug.lua_debug(module_debug.INFO, "enter, call guest_auth.update_max_users(var[\"groupName\"])\n")
                    guest_auth.update_max_users(var["uuid"])
                    module_debug.lua_debug(module_debug.INFO, "out, call guest_auth.update_max_users(var[\"groupName\"])\n")
                end
            end
            flag_exsit = 0
        else
            user_group_config(var)
        end
    end
   
    module_debug.lua_debug(module_debug.INFO, "################################END################################");
    return 0
end
--------------------------------------------------------------------------------------------
function module_set(param)
    debug_init();

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end
    
     --单实例检测
    if (single_instance_check(param, LOCK_FILE) == false) then
        return check_result("0000")
    end
    
    ret = user_group_auth_set(param)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] user_group_auth_set is failed param is %s", param)
        return check_result("0001")
    end
    
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        ret = user_group_auth_set(file_data);
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] user_group_auth_setis failed param is %s", file_data)
            return check_result("0001")
        end
    end
    os.remove(LOCK_FILE);
    module_debug.lua_debug(module_debug.INFO, "[module_set] is OK")
    return check_result("0000")
end
----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end
