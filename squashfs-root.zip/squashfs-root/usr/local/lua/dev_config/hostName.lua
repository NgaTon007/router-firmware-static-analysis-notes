#! /usr/bin/lua

package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("hostName", package.seeall); -- 第一个参数是本模块的文件名

libdbg = require("utils.debug")
cjson = require("cjson")
cjson_safe = require "cjson.safe"
x = require("uci").cursor()
ubus = require("ubus");
moduleId = require "dev_module_id"
moduleName = "hostName"
dbgDir = "/tmp/debug/hostName/"
dbgFile = "hostName.log"
DEVS_CAP = "/tmp/sd_device/sd_device.json"
SYS_HOSTNAME = "/proc/sys/kernel/hostname"
EASYSON_ELF = "/usr/sbin/easyson.elf"
local dev_sta = require "dev_sta"
local libc2lua = require("libc2lua");
local console = require "console"
local product = require("product");

-- 调试模块初始
libdbg.debug_init(dbgDir, dbgFile, 100, libdbg.DEBUG, libdbg.OPEN)

local ERR_NULL_PARAM = {rcode = "02360001", rmsg = "param is null"}
local ERR_UNSAFE_PARAM = {rcode = "02360002", rmsg = "param is unsafe"}
local ERR_SET_FAIL = {rcode = "02360003", rmsg = "set hostName failed"}

local function file_exist(path)
    local f = io.open(path, "rb");
    if (f) then
        f:close()
        return 0
    end

    return -1
end

local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            libdbg.lua_debug(libdbg.ERROR, "the file [%s] write failed", path)
            return -1
        end

        io.close(f)
        return 0
    else
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] can't open.", path)
        return -1
    end
end

local function read_file_for_json(path)
    local content, content_json

    if (type(path) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "the file path is error.")
        return -1
    end

    if (file_exist(path) == -1) then
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] doesn't exist.", path)
        return -1
    end

    content = file_read(path)
    if (content == nil) then
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] read failed.", path)
        return -1
    end

    content_json = cjson_safe.decode(content)
    if (content_json == nil or type(content_json) ~= "table") then
        libdbg.lua_debug(libdbg.ERROR, "parse the file [%s] read failed.", path)
        return -1
    end

    return 0, content_json
end

--------------调用ubus call-------------------------
local function ubus_call(ubus_module, method, data)
    local result = {}
    local conn = ubus.connect(nil, 8)

    if not conn then
        libdbg.lua_debug(libdbg.ERROR, "ubus.connect failed")
        return -1
    end

    result = conn:call(ubus_module, method, data)

    conn:close()
    return 0, result
end

local function set_hostname_for_system(path, name)
    if (type(path) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "the file path is error.")
        return -1
    end

    if (file_exist(path) == -1) then
        libdbg.lua_debug(libdbg.ERROR, "the file [%s] doesn't exist.", path)
        return -1
    end

    ret = file_write(path, name, "w")
    if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "%s write failed", path)

        return -1
    end

    libdbg.lua_debug(libdbg.INFO, "%s write success", path)
    return 0
end

local function uci_set_hostname(name)
    x:foreach("system", "system", function(s)
        local op = s[".name"]
        x:set("system", op, "hostname", name)
    end
    )

    x:commit("system")
    x:revert("system")

    return 0
end

local function hostname_notify_for_easyson()
    -- 自组网整改将不再支持内部旧接口，统一要改成框架接口，bugid[1055961]
    local result_str = dev_sta.fetch("set", "informNotify", '{\"caller\":\"hostName\"}').data
    if (result_str == nil) then
        libdbg.lua_debug(libdbg.ERROR, "set easyson inform_notify failed")
        return -1
    end

    local result_tab = cjson_safe.decode(result_str)
    if (result_tab == nil) then
        libdbg.lua_debug(libdbg.ERROR, "result_str decode failed")
        return -1
    end

    if (result_tab["rcode"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "result_tab[rcode] is nil")
        return -1
    end

    if (result_tab["rcode"] ~= "00000000") then
        libdbg.lua_debug(libdbg.ERROR, "result_tab[rcode] ~= 00000000")
        return -1
    end

    libdbg.lua_debug(libdbg.INFO, "set easyson inform_notify success")
    return 0
end

local function hostname_notify_for_switch(data)
    local ret, result, res_json, tmp

    ret, content_json = read_file_for_json(DEVS_CAP)
    if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "read device capacity failed.")
        return 0
    end

    if (content_json["dev_type"] == nil) then
        libdbg.lua_debug(libdbg.WARNING, "device capacity config does't have dev_type")
        return 0
    end

    if (type(content_json["dev_type"]) ~= "string") then
        libdbg.lua_debug(libdbg.WARNING, "device capacity dev_type isn't string")
        return 0
    end

    if (content_json["dev_type"] ~= "msw") then
        libdbg.lua_debug(libdbg.INFO, "device capacity config dev_type isn't msw")
        return 0
    end

    tmp = {}
    tmp["hostname"] = data["name"]
    ret, result = ubus_call("swconfig", "host_name_set", tmp)
    if (ret ~= 0 or result == nil) then
        libdbg.lua_debug(libdbg.ERROR, "ubus call swconfig host_name_set  failed", tmp)
        return -1
    end

    if (result["code"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "ubus call swconfig host_name_set %s failed", cjson_safe.encode(tmp))
        return -1
    end

    if (result["code"] ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "ubus call swconfig host_name_set %s failed", cjson_safe.encode(tmp))
        return -1
    end

    libdbg.lua_debug(libdbg.INFO, "ubus call swconfig host_name_set %s success", cjson_safe.encode(tmp))
    return 0
end

local function hostname_param_check(data)
    if (data["name"] == nil) then
        libdbg.lua_debug(libdbg.ERROR, "hostName name is null")
        return -1
    end

    if (type(data["name"]) ~= "string") then
        libdbg.lua_debug(libdbg.ERROR, "hostName name isn't string")
        return -1
    end

    if (string.len(data["name"]) < 1 or string.len(data["name"]) > 64) then
        libdbg.lua_debug(libdbg.ERROR, "invalid hostname length")
        return -1
    end

    return 0
end

local function set_hostname(param)
    local ret

    data = cjson_safe.decode(param)
    if (data == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parse hostName param failed.")
        return -1
    end

    ret = hostname_param_check(data)
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "hostname_param_check failed")
        return -1
    end

    ret = uci_set_hostname(data["name"])
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "uci_set_hostname failed")
        return -1
    end

    -- bugid：1134391；解决网桥R280未导入自组网的bug
    -- 判断自组网可执行文件是否存在：存在则通告自组网
    if (file_exist(EASYSON_ELF) == 0) then
        ret = hostname_notify_for_easyson()
        if (ret ~= 0) then
            libdbg.lua_debug(libdbg.ERROR, "hostname_notify_for_easyson failed")
            return -1
        end
    end

    ret = hostname_notify_for_switch(data)
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "hostname_notify_for_switch failed")
        return -1
    end

    ret = set_hostname_for_system(SYS_HOSTNAME, data["name"])
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "set_hostname_for_system failed")
        return -1
    end

    return 0
end

function hostname_write_syslog(log)
    if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
        local std_syslog = require("std_syslog_lua");
        local ret_code
        local ret_msg

        ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_ERROR,
            std_syslog.SSG_UNRELIABLE or std_syslog.SSG_LOW_RATE, 0, "HOSTNAME", "CHANGE_FAILED", log);
        if (ret_code > std_syslog.NORMALLY_RET_CODE) then
            -- 返回值大于NORMALLY_RET_CODE属于调用出错, 要把错误信息打印到自己业务的日志
            libdbg.lua_debug(libdbg.ERROR, "std_syslog_lua failed ret_msg:" .. ret_msg)
            -- 不要return掉 !!!!发日志只是顺带的, 发送失败也不要修改业务本身的执行逻辑!!!!
        end
    end

    return 0
end

function module_default_config_get()
    
    local company = product.get_product("manufacturer.company");
    
    local def_cfg = string.format('{"name":"%s"}', company);

    def_cfg_json = cjson_safe.decode(def_cfg)
    if (def_cfg_json == nil) then
        libdbg.lua_debug(libdbg.ERROR, "parse default dhcpRelay config failed.")
        return def_cfg
    end

    ret, content_json = read_file_for_json(DEVS_CAP)
    if (ret == -1) then
        libdbg.lua_debug(libdbg.ERROR, "read device capacity failed.")
        return def_cfg
    end

    if (content_json["def_hostname"] == nil) then
        libdbg.lua_debug(libdbg.INFO, "device capacity config does't have def_hostname")
        return def_cfg
    end

    if (type(content_json["def_hostname"]) ~= "string") then
        libdbg.lua_debug(libdbg.INFO, "device capacity def_hostname isn't string")
        return def_cfg
    end

    if (string.len(content_json["def_hostname"]) == 0) then
        libdbg.lua_debug(libdbg.INFO, "device capacity config def_hostname is null")
        return def_cfg
    end

    def_cfg_json["name"] = content_json["def_hostname"]
    def_cfg_encode = cjson_safe.encode(def_cfg_json)
    if (def_cfg_encode == nil) then
        libdbg.lua_debug(libdbg.WARNING, "def_cfg_json isn't json")
        return def_cfg
    end

    ret = set_hostname(def_cfg_encode)
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.INFO, "set def_hostname failed")
        return def_cfg
    end

    return def_cfg_encode
end

function module_get(param)

end

function module_set(param)
    if (param == nil) then
        libdbg.lua_debug(libdbg.ERROR, "param is null")
        hostname_write_syslog("set hostName failed: param is null")
        return console.uf_lua_fail(ERR_NULL_PARAM)
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        libdbg.lua_debug(libdbg.ERROR, "param is unsafe")
        if (param ~= nil) then
            libdbg.lua_debug(libdbg.ERROR, "param is unsafe")
        end
        hostname_write_syslog("set hostName failed: param is unsafe")
        return console.uf_lua_fail(ERR_UNSAFE_PARAM)
    end

    ret = set_hostname(param)
    if (ret ~= 0) then
        libdbg.lua_debug(libdbg.ERROR, "set hostName failed")
        hostname_write_syslog("set hostName failed")
        return console.uf_lua_fail(ERR_SET_FAIL)
    end

    if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
        local std_syslog = require("std_syslog_lua");
        local ret_code
        local ret_msg

        ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_INFO,
            std_syslog.SSG_UNRELIABLE or std_syslog.SSG_LOW_RATE, 0, "HOSTNAME", "CHANGE_SUCCESS",
            "hostname set success")
        if (ret_code > std_syslog.NORMALLY_RET_CODE) then
            -- 返回值大于NORMALLY_RET_CODE属于调用出错, 要把错误信息打印到自己业务的日志
            libdbg.lua_debug(libdbg.ERROR, "std_syslog_lua failed ret_msg:" .. ret_msg)
            -- 不要return掉 !!!!发日志只是顺带的, 发送失败也不要修改业务本身的执行逻辑!!!!
        end
    end

    return console.uf_lua_success()
end
