#! /usr/bin/env lua

module_name = "ttl_setting"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson.safe"
cjson = require "cjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"

def_ttl_num = "10"
config_file = "/etc/sd_config/single/ttl_setting.json"
----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 500, module_debug.DEBUG, "1")

local err_code = {
    ["SUCCESS"] = "00000000",
    ["ERR_TTL_SETTING_PARAM_EXCEPTION"] = "03040001",
    ["ERR_TTL_SETTING_CONFIG_EXCEPTION"] = "03040002",
    ["ERR_TTL_SETTING_DUP_CONFIG"] = "03040003",
    ["ERR_TTL_SETTING_NOEXIST_CONFIG"] = "03040004",
    ["ERR_TTL_SETTING_EXCEEED_CONFIG"] = "03040005",
}

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- return error message if execution fails
-- @code: error code
-- @msg: error msg
-- @If it fails to return an error, it is considered that the configuration has failed
local function fail_reason(code, msg)
    local err = {}
    local ret = {}

    err["rcode"] = code
    err["message"] = msg
    ret["code"] = "1"
    ret["err"] = cjson_safe.encode(err)

    return cjson_safe.encode(ret)
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the action success; otherwise return false.
local function checkparam_for_ttl(ttl)
    if (ttl == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The ttl is null")
        return -1
    end
    
    if (type(ttl) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The ttl is abnormal")
        return -1
    end
    
    ttl_v = tonumber(ttl)
    if (ttl_v == nil or type(ttl_v) ~= "number" or ttl_v > 255 or ttl_v < 1) then
        module_debug.lua_debug(module_debug.ERROR, "The ttl is abnormal")
        return -1
    end

end

local function checkparam_for_position(position)
    if (position == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The position is null")
        return -1
    end
    
    if (type(position) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The position is abnormal")
        return -1
    else
        if (string.len(position) ~= 0 and (string.find(position, "up") == nil and string.find(position, "down") == nil)) then
            module_debug.lua_debug(module_debug.ERROR, "The position is abnormal, not belong to up or down")
            return -1
        end
    end

end

local function checkparam_for_intf(intf)
    if (intf == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The intf is null")
        return -1
    end
    
    if (type(intf) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The intf is abnormal")
        return -1
    end

    if (string.match(intf, "[^%w_-]") ~= nil) then
        module_debug.lua_debug(module_debug.ERROR, "the intf style isn't unsafe" )
        return -1
    end

    return 0
end

local function checkparam_for_action(action)
    if (action == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The action is null")
        return -1
    end
    
    if (type(action) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The action is abnormal")
        return -1
    else
        if (string.len(action) == 0) then
            return -1
        else
            if (string.match(action, "[^%w]") ~= nil) then
                return -1
            end
            
            if (string.find(action, "change") == nil and string.find(action, "increment") == nil 
                and string.find(action, "decrement") == nil) then
                module_debug.lua_debug(module_debug.ERROR, "The action is abnormal, not belong to change, increment or decrement")
                return -1
            end
        end
    end

    return 0
end

-- check the ip range is normal or not.
-- @ipnum: Number in IP address. ex:192.168.1.1, num is 192.168 or 1
-- @return 0, if the check success; otherwise return -1.
local function ip_range_check(ipnum)
    if (type(ipnum) ~= "string" or #ipnum == 0) then
        module_debug.lua_debug(module_debug.ERROR, "ipnum is error")
        return -1
    end

    ipnum = tonumber(ipnum)
    if (ipnum == nil or ipnum > 255 or ipnum < 0) then
        module_debug.lua_debug(module_debug.ERROR, "ipnum[%d] is out of range", ipnum)
        return -1
    end

    return 0
end

-- check the ip is available or not.
-- @ipaddr: IP address. ex:192.168.1.1
-- @return 0, if the check success; otherwise return -1.
local function ip_validity_check(ipaddr)
    local ipmin_len = 7
    local ipmax_len = 15
    local s_pos, d_pos, i
    local ip1, ip2, ip3, ip4

    ---------------7 <= ip length <= 15-------------
    local length = string.len(ipaddr);
    if (length < ipmin_len or length > ipmax_len) then
        module_debug.lua_debug(module_debug.ERROR, "ip length[%d] is error", length)
        return -1
    end

    -----------------check illegal character--------
    i = 0
    s_pos = 0
    while (s_pos ~= nil) do
        s_pos, d_pos, value = string.find(ipaddr, "([^%d])", s_pos)
        if s_pos ~= nil then
            s_pos = s_pos + 1
            i = i + 1
        end
    end

    if (i ~= 3) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr [%s] pattern is error", ipaddr)
        return -1
    end

    -----------------check ip style----------------
    ip1, ip2, ip3, ip4 = string.match(ipaddr, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if (ip1 == nil or ip2 == nil or ip3 == nil or ip4 == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr style is error")
        return -1
    end

    if (ip_range_check(ip1) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] first place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip2) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] second place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip3) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] third place is error", ipaddr)
        return -1
    end

    if (ip_range_check(ip4) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] fourth place is error", ipaddr)
        return -1
    end

    ---------------check special address--------------
    if (type(ip1) == "string") then
        ip1 = tonumber(ip1)
        if (ip1 == nil or ip1 == 0 or ip1 == 127) then
            module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] is unusable", ipaddr)
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "ip addr[%s] first place is error", ipaddr)
        return -1
    end

    return 0
end

local function ip_str_to_int(ipaddr)
    module_debug.lua_debug(module_debug.INFO, "ip_str_to_int() ipaddr:%s", ipaddr);
    local ip = require("utils.string").string_split_to_table(ipaddr, ".")

    if (#ip ~= 4) then
        return false
    end
    
    for i = 1, #ip do
        if (tonumber(ip[i]) < 0 or tonumber(ip[i]) > 255) then
            return false
        end
    end
    
    local ip_int = ip[1] * 16777216 + ip[2] * 65536 + ip[3] * 256 + ip[4];
    module_debug.lua_debug(module_debug.INFO, "ip_str_to_int() ip_int:%s", ip_int)

    return true, ip_int
end

local function checkparam_is_json(param)
    if (type(param) == "string") then
        module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", module_name, param)
    else
        return nil
    end

    local param_json = cjson_safe.decode(param)
    if (param_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter format is not json")
        return nil
    end

    return param_json
end

local function checkparam_for_iprange(iprange)
    if (iprange == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The iprange is null")
        return -1
    end
    
    if (type(iprange) ~= "string") then
        module_debug.lua_debug(module_debug.ERROR, "The intf is abnormal")
        return -1
    else
        if (string.len(iprange) == 0) then
            return 0
        end
        
        if (string.find(iprange, "-") == nil) then
            if (ip_validity_check(iprange) == -1) then
                return -1
            end
        else
            ipstart, ipend = string.match(iprange, "^(%S+)-(%S+)$")
            if (ipstart == nil or ipend == nil) then
                module_debug.lua_debug(module_debug.ERROR, "ipange style is error")
                return -1
            end
            
            if (ip_validity_check(ipstart) == -1 or ip_validity_check(ipend) == -1) then
                return -1
            end
            
            ret, ipstart_int = ip_str_to_int(ipstart)
            if (ret ~= true) then
                module_debug.lua_debug(module_debug.ERROR, "ip addr start [%s] pattern is error, cannot be converted to type int", ipstart)
                return -1
            end
            
            ret, ipend_int = ip_str_to_int(ipend)
            if (ret ~= true) then
                module_debug.lua_debug(module_debug.ERROR, "ip addr end [%s] pattern is error, cannot be converted to type int", ipend)
                return -1
            end
            
            if (ipstart_int > ipend_int) then
                module_debug.lua_debug(module_debug.ERROR, "ipange style is error, start address is greater than end address")
                return -1
            end
        end
    end

    return 0
end

local function checkparam_for_rulename(rulename)
    if (rulename == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The rulename is null")
        return -1
    end
    
    if (type(rulename) ~= "string" or string.len(rulename) > 32) then
        module_debug.lua_debug(module_debug.ERROR, "The rulename is abnormal")
        return -1
    end

    return 0
end

local function checkparam_for_add_node(param)
    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return nil
    end
    
    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter list is null")
        return nil
    end
    
    for k,v in pairs(param_json["list"]) do
        if (checkparam_for_ttl(v["ttl"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s ttl is error", k)
            return nil
        end
        
        if (checkparam_for_intf(v["intf"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s intf is error", k)
            return nil
        end
        
        if (checkparam_for_iprange(v["iprange"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s iprange is error", k)
            return nil
        end
        
        if (checkparam_for_rulename(v["rulename"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s rulename is error", k)
            return nil
        end
        
        if (checkparam_for_action(v["action"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s action is error", k)
            return nil
        end
    end
    
    return param_json
end

local function checkparam_for_del_node(param)
    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return nil
    end
    
    if (param_json["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The parameter list is null")
        return nil
    end
    
    for k,v in pairs(param_json["list"]) do
        if (checkparam_for_rulename(v["rulename"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s rulename is error", k)
            return nil
        end
    end
    
    return param_json
end

local function checkparam_for_update_node(param)
    local position_flag = false
    param_json = checkparam_is_json(param)
    if (param_json == nil) then
        return nil
    end
    
    if (param_json["list"] ~= nil) then
        for k,v in pairs(param_json["list"]) do
            if (checkparam_for_rulename(v["rulename"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s rulename is error", k)
                return nil
            end

            if (v["ttl"] == nil and v["action"] == nil) then
                return nil
            end
            
            if (checkparam_for_ttl(v["ttl"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s ttl is error", k)
                return nil
            end

            
            if (checkparam_for_action(v["action"]) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "The list[%d]'s action is error", k)
                return nil
            end
        end
    else    
        if (checkparam_for_rulename(param_json["rulename"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The adjust order rulename is error")
            return nil
        end

        position_flag = true
        if (checkparam_for_position(param_json["position"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "The adjust order positon is error")
            return nil
        end
    end
    
    return param_json, position_flag
end

function add_new_node_to_file(config_json, node)
    if (config_json["list"] ~= nil) then
        for k,v in pairs(config_json["list"]) do
            if (v["rulename"] == node["rulename"] or (node["intf"] ~= "" and v["intf"] == node["intf"]) 
                or (node["iprange"] ~= "" and v["iprange"] == node["iprange"])) then
                node_str = cjson_safe.encode(node)
                if (node_str ~= nil) then
                    module_debug.lua_debug(module_debug.ERROR, "The new config[%s] node duplicates the existing configuration", node_str)
                else
                    module_debug.lua_debug(module_debug.ERROR, "The new config node duplicates the existing configuration")
                end
                
                return -1
            end
        end
    end

    maxnum = get_max_ttl_num()
    ttl_rules_num = tonumber(config_json["ttl_rules_num"])
    maxnum = tonumber(maxnum)
    if (ttl_rules_num + 1 > maxnum) then
        return -2
    end

    config_json["ttl_rules_num"] = tostring(ttl_rules_num + 1)
    table.insert(config_json["list"], node)
    
    return 0
end

local function del_node_to_file(config_json, node)
    local del_flag = false

    for k,v in pairs(config_json["list"]) do
        if (v["rulename"] == node) then
            del_flag = true
            table.remove(config_json["list"], k)
            config_json["ttl_rules_num"] = config_json["ttl_rules_num"] - 1
        end
    end
    
    -- The node to be deleted does not exist
    if (del_flag == false) then
        return -1
    end
    
    return 0
end

local function update_node_position_to_file(config_json, node)
    local update_flag = false

    for k,v in pairs(config_json["list"]) do
        if (v["rulename"] == node["rulename"]) then
            update_flag = true
            if (node["position"] == "up") then
                if (k == 1) then
                    break
                end

                table.remove(config_json["list"], k)
                table.insert(config_json["list"], k - 1, v)
            else
                if (k == #config_json["list"]) then 
                    break
                end

                table.remove(config_json["list"], k)
                table.insert(config_json["list"], k + 1, v)
            end
            
            break
        end
    end
    
    -- The node to be updated does not exist
    if (update_flag == false) then
        return -1
    end
    
    return 0
end

local function update_node_to_file(config_json, node)
    local update_flag = false

    for k,v in pairs(config_json["list"]) do
        if (v["rulename"] == node["rulename"]) then
            update_flag = true
            v["ttl"] = node["ttl"]
            v["action"] = node["action"]
        end
    end
    
    -- The node to be deleted does not exist
    if (update_flag == false) then
        return -1
    end
    
    return 0
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

local function json_write_to_file(config_json)
    if (config_json ~= nil) then
        config_str = cjson_safe.encode(config_json)
        if (config_str ~= nil) then
            local temp_path = config_file .. ".tmp"
            res = file_write(temp_path, config_str)
            if (res == 0) then
                -- Attempt to rename temp file to target path
                local rename_success = os.rename(temp_path, config_file)
                if (rename_success) then
                    return 0
                else
                    module_debug.lua_debug(module_debug.ERROR, "Failed to rename temp file [%s] to [%s]", temp_path, config_file)
                    os.remove(temp_path)  -- Clean up temp file on failure
                    return -1
                end
            else
                module_debug.lua_debug(module_debug.ERROR, "Failed to write to temp file [%s]", temp_path)
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end
    
    return 0
end

-- gain the ttl num
function get_max_ttl_num()
    local max_num, ablity_file, ablity_table

    max_num = def_ttl_num
    ablity_file = "/tmp/sd_device/sd_device.json"
    if (file_exist(ablity_file) ~= true) then
        return max_num
    end
    
    ablity_table = file_to_json(ablity_file)
    if (ablity_table == nil) then
        return max_num
    end

    if (ablity_table["gateway"] ~= nil) then
        if (ablity_table["gateway"]["max_ttl_rules"] ~= nil) then
            max_num = ablity_table["gateway"]["max_ttl_rules"]
        end
    end
    
    if (max_num ~= nil and string.len(max_num) == 0) then 
        max_num = def_ttl_num
    end
    
    if (max_num == nil) then
        max_num = def_ttl_num
    end

    return max_num
end

-- default config
function module_default_config_get()
    local def_cfg = '{"list":[], "max_ttl_rules":"10", "ttl_rules_num":"0"}'
    
    local def_cfg_json = cjson_safe.decode(def_cfg)
    if (def_cfg_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The def_cfg param to json failed")
        return def_cfg
    end
    
    def_cfg_json["max_ttl_rules"] = get_max_ttl_num()
    local def_cfg_str = cjson_safe.encode(def_cfg_json)
    if (def_cfg_str == nil) then
        module_debug.lua_debug(module_debug.ERROR, "The def_cfg json encode to json failed")
        return def_cfg
    end
    
    module_debug.lua_debug(module_debug.INFO, "INFO: [module_default_config_get] get default success")

    return def_cfg_str
end

function module_add(param)
    param_json = checkparam_for_add_node(param) 
    if (param_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_PARAM_EXCEPTION"], "param is error")
    end

    config_json = file_to_json(config_file)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config is null")
    end

    for k,v in pairs(param_json["list"]) do
        res = add_new_node_to_file(config_json, v)
        if (res == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: duplicate addition")
            return fail_reason(err_code["ERR_TTL_SETTING_DUP_CONFIG"], "ERROR: duplicate addition")
        elseif (res == -2) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: Total allowed configuration exceeded")
            return fail_reason(err_code["ERR_TTL_SETTING_EXCEEED_CONFIG"], "ERROR: Total allowed configuration exceeded")
        end
    end
    
    if (json_write_to_file(config_json) == -1) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config cannot write")
    end
    
    module_debug.lua_debug(module_debug.INFO, "MSG: ttl setting add SUCCESSS")
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_del(param)
    param_json = checkparam_for_del_node(param) 
    if (param_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_PARAM_EXCEPTION"], "param is error")
    end

    config_json = file_to_json(config_file)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config is null")
    end
    
    for k,v in pairs(param_json["list"]) do
        if (del_node_to_file(config_json, v["rulename"]) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: The node to be deleted does not exist")
            return fail_reason(err_code["ERR_TTL_SETTING_NOEXIST_CONFIG"], "ERROR: The node to be deleted does not exist")
        end
    end
    
    if (json_write_to_file(config_json) == -1) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config cannot write")
    end
    
    module_debug.lua_debug(module_debug.INFO, "MSG: ttl setting del SUCCESSS")
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_update(param, config_file_path)
    local position_flag = false
    param_json, position_flag = checkparam_for_update_node(param, position_flag) 
    if (param_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_PARAM_EXCEPTION"], "param is error")
    end

    config_json = file_to_json(config_file)
    if (config_json == nil) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config is null")
    end
    
    if (position_flag == false) then
        for k,v in pairs(param_json["list"]) do
            if (update_node_to_file(config_json, v) == -1) then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: The node to be updated does not exist")
                return fail_reason(err_code["ERR_TTL_SETTING_NOEXIST_CONFIG"], "ERROR: The node to be updated does not exist")
            end
        end
    else
   
        if (update_node_position_to_file(config_json, param_json) == -1) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: The node to be updated does not exist")
            return fail_reason(err_code["ERR_TTL_SETTING_NOEXIST_CONFIG"], "ERROR: The node to be updated does not exist")
        end
    end
    
    if (json_write_to_file(config_json) == -1) then
        return fail_reason(err_code["ERR_TTL_SETTING_CONFIG_EXCEPTION"], "ERROR: ttl setting config cannot write")
    end
    
    module_debug.lua_debug(module_debug.INFO, "MSG: ttl setting update SUCCESSS")
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_set(param)
    return fail_reason(err_code["ERR_TTL_SETTING_PARAM_EXCEPTION"], "the operation is not support.")
end

-- Configuration Framework Apply
function module_apply()
    local apply_file = "/usr/sbin/ttl_setting_apply.sh"

    if (file_exist(apply_file) == true) then
        os.execute(apply_file)
    end
end
