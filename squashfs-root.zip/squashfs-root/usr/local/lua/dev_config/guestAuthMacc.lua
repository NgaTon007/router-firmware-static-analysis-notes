#!/usr/bin/env lua
-- dev_config get -m guestAuthMacc
-- dev_config set -m guestAuthMacc '{"enable":1}'
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("guestAuthMacc",package.seeall)

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local LOCK_FILE = "/tmp/guest_auth/guestAuthMacc.lock"
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "guestAuthMacc.json"})
local table_input_err = {rcode = "05630001", rmsg = "param error"}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guestAuthMacc.log", 500, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then
        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end
    if (tool.file_exist(lockfile) == true) then
 --已有实例在跑，将配置写入临时文件
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
 --无实例在跑，加锁开始处理
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

--@guestAuthMacc_set
function guestAuthMaccSet(param)
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.");
        return "{\"code\":\"1\",\"msg\":\"param is not json mode!\"}"
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param);
    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end
       
    --webservice uci
    uci:set("webservice", "webservice", "rlog_enable", param_tab["enable"])
    uci:commit("webservice")

    return 0
end
--------------------------------------------------------------------------------------------
function module_default_config_get()
    local default_config = [[
        {
            "enable":0
        }
      ]]

    return default_config
end

function module_set(param)
    debug_init();

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param %s", param)
        end
        return check_result("0001")
    end
    
    --单实例检测
    if (single_instance_check(param, LOCK_FILE) == false) then
        return check_result("0000")
    end

    ret = guestAuthMaccSet(param)
    if (ret ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] guestAuthMaccSet is failed param is %s", file_data)
        return check_result("0001")
    end
    
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        ret = guestAuthMaccSet(file_data);
        if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] guestAuthMaccSet is failed param is %s", file_data)
            return check_result("0001")
        end
    end
    os.remove(LOCK_FILE);
    module_debug.lua_debug(module_debug.INFO, "[module_set] is OK")

    return check_result("0000")
end
-----------------------------------------------------------------------------------------------
function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply");
end