#!/usr/bin/env lua

module_name = "nat_dmz"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

dkjson = require "dkjson"

--lua调试debug配置
DEBUG_STATUS = "0";
if (DEBUG_STATUS == "1") then
    PROGRAM_NAME = "NAT_DMZ";
    DEBUG_LOG_DIR = "/tmp/nat/";
    DEBUG_LOG_FILE = DEBUG_LOG_DIR .. "nat_dmz_lua.log";
    DEBUG_LOG_FILE_SIZE = 200;--line number
end

--lua判断文件或则文件夹是否存在
function lua_is_file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

--lua获取文件行数
function lua_get_file_line_number(file)
    local BUFSIZE = 65536;
    local lc = 0;
    local f = io.input(file);
    while (true) do
        local lines,rest = f:read(BUFSIZE,"*line");
        if not lines then
            break;
        end
        _,t = string.gsub(lines,"\n","\n");
        lc = lc + t;
    end
    return lc;
end

--lua调试debug
function lua_debug(msg)
    if (DEBUG_STATUS == "1") then
        if (lua_is_file_exist(DEBUG_LOG_FILE) == true) then
            local log_line = lua_get_file_line_number(DEBUG_LOG_FILE);
            if (log_line > DEBUG_LOG_FILE_SIZE) then
                os.rename(DEBUG_LOG_FILE, DEBUG_LOG_FILE .. ".old");
            end
        else
            if (lua_is_file_exist(DEBUG_LOG_DIR) == false) then
                local char = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1";
                os.execute(char);
            end
        end

        local cur_time = os.date("%Y-%m-%d %H:%M:%S");

        local f = assert(io.open(DEBUG_LOG_FILE,"a"));
        f:write("[",cur_time,"] ",PROGRAM_NAME,"[",string.format("%3s",debug.getinfo(2).currentline),"] ",msg,"\n");
        f:close();
    end
end

function fail_reason(msg, code)
    local rcode = table.concat({"0503", code});
    local err = {}
    local ret = {}

    err["rcode"] = rcode
    err["message"] = msg
    ret["code"] = "1"  
    ret["err"] = dkjson.encode(err)
  
    return dkjson.encode(ret)
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file, "w")
    file:write(data)
    file:close()
end


local function checkparam_for_intf(param)
    if (type(param) ~= "string") then
        return -1
    end

    if (string.match(param, "[^%w_-]") ~= nil) then
        return -1
    end

    return 0
end

function invalid_address_check(param)
    --检查ip
    if (type(param) ~= "string") then
        return -1
    end 
    
    local ipaddr1, ipaddr2, ipaddr3, ipaddr4 = string.match(param, "^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if (ipaddr1 == nil or ipaddr2 == nil or ipaddr3 == nil or ipaddr4 == nil) then
        return -1
    end

    if (tonumber(ipaddr1) > 239) then
        return -1
    end
    
    if(tonumber(ipaddr1) > 223) then
        return -1
    end

    if(tonumber(ipaddr1) == 0 or tonumber(ipaddr1) == 127) then
        return -1
    end
    
    return 0
end

local function enable_check(enable)
    if (type(enable) ~= "string") then
        return -1
    end
    
    if (enable ~= "1" and enable ~= "0") then
        return -1
    end
    
    return 0
end

function param_check_safe(param)
    if (param["interface"] ~= nil and checkparam_for_intf(param["interface"]) == -1) then
        return -1
    end

    if (param["dest_ip"] ~= nil and invalid_address_check(param["dest_ip"]) == -1) then
        return -1
    end

    if (param["enable"] ~= nil and enable_check(param["enable"]) == -1) then
        return -1
    end

    return 0
end

--json表中查找规则名rule_name所在的索引值，如果查找的规则名rule_name不存在，返回已存在配置记录总数目+1（即待插入的位置）
function nat_dmz_get_json_idx(json, data)
    local index = 1
    local length = table.maxn(json["list"])

    while ( index < length + 1 ) do
        if ( json["list"][index]["rule_name"] == data ) then
            break
        end
        index = index + 1
    end

    return index
end

--增加单个规则配置
function nat_dmz_add_config(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local add = dkjson.decode(data)
    
    if (param_check_safe(add) == -1) then
        return fail_reason("param is error", "0001")
    end
    
    --如果在json表中查找的规则名rule_name不存在，返回已存在配置记录总数目+1（即待插入的位置）
    local index = nat_dmz_get_json_idx(json, add["rule_name"])
    local length = table.maxn(json.list)

    lua_debug("Enter nat_dmz_add_config()")

    if ( index == length + 1 ) then
        table.insert(json.list, add)
        file_write(conf_file, dkjson.encode(json))
    else
        lua_debug("Error: Data already exists!")
    end
    
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

--删除多个规则配置
function nat_dmz_del_config(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local del = dkjson.decode(data)
    local length = table.maxn(json.list)
    local del_length = table.maxn(del.rule_list)
    local del_index = 1
    lua_debug("Enter nat_dmz_del_config()")

    while ( del_length > 0 ) do
        local index = nat_dmz_get_json_idx(json, del["rule_list"][del_length])
        if ( index ~= length + 1 ) then
            table.remove(json.list, index)
            file_write(conf_file, dkjson.encode(json))
        else
            lua_debug("Error: Data doesn't exist!")
        end
        del_length = del_length - 1
    end
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

--更新单个规则配置
function nat_dmz_update_config(data, conf_file)
    local file_data = file_read(conf_file)
    local json = dkjson.decode(file_data)
    local updata = dkjson.decode(data)
    
    if (param_check_safe(updata) == -1) then
        return fail_reason("param is error", "0001")
    end
    
    local index = nat_dmz_get_json_idx(json, updata["rule_name"])
    local length = table.maxn(json.list)
    lua_debug("Enter nat_dmz_update_config()")

    if ( index ~= length + 1 ) then
        if ( updata["interface"] ~= nil and json["list"][index]["interface"] ~= updata["interface"] ) then
            lua_debug("update [interface] old=" .. json["list"][index]["interface"] .. " new=" .. updata["interface"])
            json["list"][index]["interface"] = updata["interface"]
        end
        if ( updata["srcIp"] ~= nil and json["list"][index]["srcIp"] ~= updata["srcIp"] ) then
            lua_debug("update [srcIp] old=" .. json["list"][index]["srcIp"] .. " new=" .. updata["srcIp"])
            json["list"][index]["srcIp"] = updata["srcIp"]
        end
        if ( updata["dest_ip"] ~= nil and json["list"][index]["dest_ip"] ~= updata["dest_ip"] ) then
            lua_debug("update [dest_ip] old=" .. json["list"][index]["dest_ip"] .. " new=" .. updata["dest_ip"])
            json["list"][index]["dest_ip"] = updata["dest_ip"]
        end
        if ( updata["enable"] ~= nil and json["list"][index]["enable"] ~= updata["enable"] ) then
            lua_debug("update [enable] old=" .. json["list"][index]["enable"] .. " new=" .. updata["enable"])
            json["list"][index]["enable"] = updata["enable"]
        end
        file_write(conf_file, dkjson.encode(json))
    else
        lua_debug("Error: Data doesn't exist!")
    end
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

---------主函数--------
function module_default_config_get()
    local def_cfg = '{"list":[]}'

    return def_cfg
end

function module_add(param, conf)
    return nat_dmz_add_config(param, conf)
end

function module_del(param, conf)
    return nat_dmz_del_config(param, conf)
end

function module_update(param, conf)
    return nat_dmz_update_config(param, conf)
end

function module_set(param)
    local data = dkjson.decode(param)
    
    if (data["list"] == nil or type(data["list"]) ~= "table") then
        return fail_reason("param is error", "0001")
    end
    
    local length = table.maxn(data["list"])
    
    while (length > 0) do
        if (param_check_safe(data["list"][length]) == -1) then
            return fail_reason("param is error", "0001")
        end
        
        length = length - 1
    end
    
    os.execute("/usr/sbin/nat_dmz.sh") 
    return '{"rcode":"00000000", "message":"Configuration success"}'
end

function module_apply()
    os.execute("/usr/sbin/nat_dmz.sh") 
end
