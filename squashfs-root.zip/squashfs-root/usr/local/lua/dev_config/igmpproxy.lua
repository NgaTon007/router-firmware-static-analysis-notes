#! /usr/bin/lua
module("igmpproxy", package.seeall)

local louci = require "luci.model.uci".cursor()
local cjson = require "cjson";
local ldebug = require "utils.debug"
local console = require "console"
local DEBUG_LOG_DIR = "/tmp/igmpproxy/"

ldebug.debug_init(DEBUG_LOG_DIR, "igmpproxy.log", 500, ldebug.INFO, "1");

local table1 = {rcode = "03650001", rmsg = "The device not route mode"}
local table2 = {rcode = "03650002", rmsg = "The input parameter is not in JSON format"}
local table3 = {rcode = "03650003", rmsg = "Incomplete input parameters"}
local table4 = {rcode = "03650004", rmsg = "The input parameters do not meet the specification"}

local function str_is_json(param)
    if
        pcall(
            function(param)
                require("cjson").decode(param)
            end,
            param
        )
    then
        return true;
    else
        return false;
    end
end

local function input_parameter_verification(fn_json)
    local lret = {};

    -- enable参数是必要参数，如果不存在，直接退出
    if (fn_json["enable"] == nil) then
        lret = table3
        return false, lret;
    end

    -- enable参数必须是0或1，如果不符合，直接退出
    if (fn_json["enable"] ~= "0" and fn_json["enable"] ~= "1" ) then
        lret = table4
        return false, lret;
    end

    return true, lret;
end

local function igmpproxy_start()
    louci:set("igmpproxy", "igmpproxy", "enable", "1")
    louci:commit("igmpproxy")

    proto = louci:get("network", "wan", "proto")
    if (proto == "pppoe") then
        os.execute("ip addr del 172.16.20.1/24 dev br-wan 2>/dev/nul");
        os.execute("ip addr add 172.16.20.1/24 dev br-wan 2>/dev/nul");
        ldebug.lua_debug(ldebug.INFO, "ip addr add 172.16.20.1/24 dev br-wan 2>/dev/nul");
    end

    os.execute("sh /usr/sbin/igmpproxy_iptables.sh");
    os.execute("ubus -t 3 send igmpproxy_restart");
    ldebug.lua_debug(ldebug.INFO, "ubus -t 3 send igmpproxy_restart");
end

local function igmpproxy_stop()
    louci:set("igmpproxy", "igmpproxy", "enable", "0")
    louci:commit("igmpproxy")

    proto = louci:get("network", "wan", "proto")
    if (proto == "pppoe") then
        os.execute("ip addr del 172.16.20.1/24 dev br-wan 2>/dev/nul");
        ldebug.lua_debug(ldebug.INFO, "ip addr del 172.16.20.1/24 dev br-wan 2>/dev/nul");
    end

    os.execute("sh /usr/sbin/igmpproxy_iptables.sh");
    os.execute("ubus -t 3 send igmpproxy_restart");
    ldebug.lua_debug(ldebug.INFO, "ubus -t 3 send igmpproxy_restart");
end

------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    ldebug.lua_debug(ldebug.INFO, "----------------START default_config_get----------------");
    return('{"enable":"0"}');
end

function module_apply()
    ldebug.lua_debug(ldebug.INFO, "module_apply");
end

function module_set(input_data, conf_file)
    ldebug.lua_debug(ldebug.INFO, "----------------START----------------");
    local ret = {};
    local input_json = {};
    -- 判断是否为route模式
    local forwardMode = louci:get_first("sysinfo", "sysinfo", "forwardMode")
    if (forwardMode ~= "ROUTER") then
        ldebug.lua_debug(ldebug.INFO, "Result: %s", cjson.encode(table1));
        return console.uf_lua_fail(table1)
    end

    -- 判断输入字符是否为json格式，不为json格式直接退出
    if (str_is_json(input_data) == false) then
        ldebug.lua_debug(ldebug.INFO, "Result: %s", cjson.encode(table2));
        return console.uf_lua_fail(table2)
    end

    -- 入参校验
    ldebug.lua_debug(ldebug.INFO, "Input: %s", input_data);
    input_json = cjson.decode(input_data)
    res, ret = input_parameter_verification(input_json)
    if ( res == false) then
        ldebug.lua_debug(ldebug.INFO, "Result: %s", cjson.encode(ret));
        return console.uf_lua_fail(ret)
    end

    -- 开启或关闭igmpproxy
    if (input_json["enable"] == "1") then
        igmpproxy_start()
    else
        igmpproxy_stop()
    end

    -- 返回成功
    return console.uf_lua_success()
end
