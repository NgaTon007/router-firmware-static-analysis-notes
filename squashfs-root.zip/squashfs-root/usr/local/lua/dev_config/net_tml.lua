#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("net_tml",package.seeall)
local lfs = require "lfs"
local ubus = require "ubus"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require("libc2lua")
require "public_module"
local DEBUG_LOG_DIR = "/tmp/nt_info/"
local LOCK_FILE = "/tmp/nt_info/net_tml.lock"
local GRP_LOCK_FILE = "/tmp/nt_info/net_tml_grp.lock"
local NT_GRP_JSON_FILE = "/etc/sd_config/single/net_tml_grp.json"
local NT_TML_JSON_FILE = "/etc/sd_config/single/net_tml.json"
local NT_TML_UCI_CFG = "/etc/config/net_tml"
local console = require "console"
local UBUS_WAIT_TIME = 3

if (tool.file_exist(NT_TML_UCI_CFG) == false) then
    tool.exec("touch /etc/config/net_tml")
end

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

local table1 = {rcode= "05520001", rmsg= "The command execute failed"}

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "net_tml.log", 100, module_debug.DEBUG, "1")
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table1)
    end
end

local function single_instance_check(lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            module_debug.lua_debug(module_debug.INFO, "Error: overtime and remove lockfile!");
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        module_debug.lua_debug(module_debug.INFO, "Error: There is instance process running");
        return false;
    else
        module_debug.lua_debug(module_debug.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

-- 检查用于执行ubus的指令是否有单引号、双引号，nil_flag用于说明此参数是否可以为空,nil_flag:1 可以为空 0：不可为空
local function ubus_cmd_param_check(param, nil_flag)
    if (nil_flag ~= 1) then
        if (param == "") then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is nil")
            return -1
        end
    end
    if ((string.match(param , "\"") ~= nil) or (string.match(param , "'") ~= nil)) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [param ] is dangrous")
        return -1
    end
    return 0
end

-- ubus执行
local function ubus_cmd_exe(object, method, param, conn_obj)
    module_debug.lua_debug(module_debug.INFO, "ubus_cmd ubus call %s %s '%s'", object, method, cjson.encode(param))

    local conn = conn_obj
    local need_close = false
    if not conn then
        conn = ubus.connect(nil, UBUS_WAIT_TIME)
        need_close = true
    end
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: connect to ubus fail!")
        return nil
    end

    local ret = conn:call(object, method, param or {})
    if need_close and conn then
        conn:close()
    end

    return ret
end

-- 对终端服务器的处理
local function net_server_tml_act(bind, action)
    local net_tml_grp_config = tool.file_read(NT_GRP_JSON_FILE)
    net_tml_grp_config = cjson.decode(net_tml_grp_config)

    local flag = 0
    -- 修改终端服务器的同时更新终端组中服务器的数据
    local tml_grp_cfg = {}
    local server_config_tab = {}
    for k,v in pairs(net_tml_grp_config["nt_grp"]) do
        if (v["server"] ~= nil) then
            for key, val in ipairs(v["server"]) do
                if (val["ip"] == bind["ip"]) then
                    flag = 1
                    --  如果要删除的终端是终端服务器 需要把终端组内的终端服务器除IP以外的信息去除
                    if(action == "del") then
                        server_config_tab["ip"] = bind["ip"]
                        table.remove(v["server"], key)
                        table.insert(v["server"], server_config_tab)
                        break
                    end
                    if (action == "update") then
                        server_config_tab["ip"] = bind["ip"]
                        server_config_tab["mac"] = bind["mac"]
                        server_config_tab["port"] = bind["port"]
                        server_config_tab["switch"] = bind["switch"]
                        table.remove(v["server"], key)
                        table.insert(v["server"], server_config_tab)
                        break
                    end
                end
            end
        end
    end
    -- 更新终端组内的server信息
    if (flag == 1) then
        net_tml_grp_config = cjson.encode(net_tml_grp_config)
        --单实例检测
        if (single_instance_check(GRP_LOCK_FILE) == false) then
            return 0
        end
        tool.file_write(NT_GRP_JSON_FILE, net_tml_grp_config, "w")
        os.remove(GRP_LOCK_FILE)
    end
    return flag
end

local function net_tml_json_del_office_mesh(config_tab, mac)
    local flag = 0
    local del_num = nil
    mac = string.upper(mac)
    for k, v in pairs(config_tab["nt_info"]) do
        if v["mac"] == mac then
            flag = 1
            del_num = k
            break
        end
    end

    if flag == 1 and del_num ~= nil then
        -- json数据删除
        table.remove(config_tab["nt_info"], del_num)
    end
end

local function del_uci_nt_info(mac)
    module_debug.lua_debug(module_debug.INFO, "update mac is %s", mac)
    local sectionname = string.gsub(mac, ":", "_")
    if (sectionname == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [sectionname] == null")
        return -1
    end
    --uci 配置文件删除
    uci:delete("net_tml", sectionname)
    module_debug.lua_debug(module_debug.INFO, "uci %s had been update", sectionname)
    return 0
end

--删除（查询，删除表中的一个终端）
local function del_config_bind_office_mesh(bind, mac_list)
    local flag = 0
    local del_num = 0
    bind["mac"] = string.upper(bind["mac"])

    if (ubus_cmd_param_check(bind["mac"], 0) < 0) then
        return -1
    end

    if mac_list ~= nil then
        table.insert(mac_list, bind["mac"])
    end
    return 0
end

-- 通告进程reload uci配置文件
local function usr_cfg_reload_exe(conn_obj)
    local param = { filename = "/tmp/nt_info/nt_tml_file.txt" }
    local ret = ubus_cmd_exe("nt_mgr.usr_reload", "get", param, conn_obj)
    if not ret or ret.code == nil or tostring(ret.code) ~= "0" then
        return -1
    end
    return 0
end

-- 统计table的键值对数量
local function table_key_count(tbl)
    local count = 0
    for _ in pairs(tbl) do
        count = count + 1
    end
    return count
end

-- 混合网终端信息写入json文件
local function net_tml_json_update_office_mesh(config_tab, bind)
    local mac_exsit_flag = 0
    local update_key = { "ip", "name", "product", "type", "mfr", "cluster", "switch", "port" }
    bind["mac"] = string.upper(bind["mac"])
    for k,v in pairs(config_tab["nt_info"]) do
        -- 已存在此终端，修改json数据
        if (v["mac"] == bind["mac"]) then
            mac_exsit_flag = 1
            for _, key in ipairs(update_key) do
                if bind[key] ~= nil then
                    v[key] = bind[key]
                end
            end
            break
        end
    end

    if (mac_exsit_flag ~= 1) then
        -- 不存在就添加json数据
        table.insert(config_tab["nt_info"], bind)
    end
end

local function update_uci_nt_info(bind)
    module_debug.lua_debug(module_debug.INFO, "update mac is %s", bind["mac"])
    local sectionname = string.gsub(bind["mac"], ":", "_")
    if (sectionname == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] sectionname is nil")
        return -1
    end
    --uci 配置文件修改（没有就是添加）
    uci:set("net_tml", sectionname, "nt_info")
    uci:set("net_tml", sectionname, "mac",  bind["mac"])
    if (bind["name"] ~= nil) then
        uci:set("net_tml", sectionname, "name",  bind["name"])
    end
    if bind["product"] ~= nil then
        uci:set("net_tml", sectionname, "product",  bind["product"])
    end
    if (bind["type"] ~= nil) then
        uci:set("net_tml", sectionname, "type",  bind["type"])
    end
    if bind["mfr"] ~= nil then
        uci:set("net_tml", sectionname, "mfr",  bind["mfr"])
    end
    if (bind["cluster"] ~= nil) then
        uci:set("net_tml", sectionname, "cluster",  bind["cluster"])
    end

    module_debug.lua_debug(module_debug.INFO, "uci %s had been update", sectionname)
    return 0
end

-- 修改（没有就追加）（查询，修改表中的一个终端）
local function update_config_bind_office_mesh(bind, update_list, notify_list)
    local update_fields = {}
    local notify_fields = {}
    local mac = bind["mac"]
    if mac == nil or ubus_cmd_param_check(mac, 0) < 0 then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] mac is invalid")
        return -1
    end
    mac = string.upper(mac)
    update_fields["mac"] = mac
    notify_fields["mac"] = mac

    if bind["name"] ~= nil then
        if ubus_cmd_param_check(bind["name"], 1) < 0 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] name is invalid")
            return -1
        end
        update_fields["name"] = bind["name"]
        notify_fields["name"] = bind["name"]
    end
    if bind["ip"] ~= nil then
        update_fields["ip"] = bind["ip"]
    end
    if bind["product"] ~= nil then
        update_fields["product"] = bind["product"]
    end
    if bind["type"] ~= nil then
        update_fields["type"] = bind["type"]
        notify_fields["type"] = bind["type"]
    end
    if bind["mfr"] ~= nil then
        update_fields["mfr"] = bind["mfr"]
        notify_fields["mfr"] = bind["mfr"]
    end
    if bind["cluster"] ~= nil then
        update_fields["cluster"] = bind["cluster"]
    end

    if table_key_count(update_fields) == 1 and update_fields["mac"] ~= nil then -- 只有mac
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] only mac is valid")
        return -1
    end

    table.insert(update_list, update_fields)

    if table_key_count(notify_fields) ~= 1 then
        if notify_list ~= nil then
            table.insert(notify_list, notify_fields)
        end
    end

    return 0
end

--@net_tml_update
function net_tml_update(param)
    module_debug.lua_debug(module_debug.INFO, "###############################UPDATE###############################")

    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return -1
    end

    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param_tab is nil")
        return -1
    end

    local config_tab = tool.file_read(NT_TML_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return -1
    end

    config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] config is nil")
        return -1
    end

    local ret
    local update_flag = 0
    local file_config = 0
    local update_list = {}
    local notify_list = {}

    -- 创建ubus连接对象
    local conn = ubus.connect(nil, UBUS_WAIT_TIME)
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [net_tml_update] connect to ubus fail!")
        return -1
    else
        module_debug.lua_debug(module_debug.INFO, "connect to ubus success")
    end

    for k,v in pairs(param_tab["nt_info"]) do
        if (v["mac"] == nil ) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] mac is null")
            conn:close()
            return -1
        end
        ret = update_config_bind_office_mesh(v, update_list, notify_list)
        if (ret ~= 0) then
            update_flag = update_flag - 1
        end
    end

    module_debug.lua_debug(module_debug.INFO, "all update update_list: %s", cjson.encode(update_list))
    if #update_list > 0 then
        -- 通知nt_mgr.usr_update更新终端
        local update_param = { nt_info = update_list }
        local ret = ubus_cmd_exe("nt_mgr.usr_update", "set", update_param, conn)
        if not ret or ret.code == nil or tostring(ret.code) ~= "0" then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] ubus call nt_mgr.usr_update is failed")
            conn:close()
            return -1
        end
    end

    for k,v in pairs(update_list) do
        net_tml_json_update_office_mesh(config_tab, v)
        if update_uci_nt_info(v) ~= 0 then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] update_uci_nt_info is failed")
            conn:close()
            return -1
        end
    end

    if param_tab["from"] == nil or param_tab["from"] ~= "cloud" then
        module_debug.lua_debug(module_debug.INFO, "all update notify_list: %s", cjson.encode(notify_list))
        if #notify_list > 0 then
            local notify_param = {
                name = "nt_mgr",
                bizid = "nt_mgr_01",
                ack = "true",
                val = {
                    op = "fix_upd",
                    list = notify_list,
                    num = #notify_list
                }
            }
            if ubus_cmd_exe("mqlink", "status_notify", notify_param, conn) == nil then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] ubus call mqlink status_notify is failed")
                conn:close()
                return -1
            end
        end
    end

    if (file_config == 1) then
        if (usr_cfg_reload_exe(conn) < 0) then
            conn:close()
            return -1
        end
    end

    conn:close()

    if (update_flag < 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] update_config_bind is failed param is %s", param)
        return -1
    end

    config_tab = cjson.encode(config_tab)
    if (config_tab ~= nil) then
        tool.file_write(NT_TML_JSON_FILE, config_tab)
    end

    uci:commit("net_tml")

    module_debug.lua_debug(module_debug.INFO, "################################UPDATE END################################")
    return 0
end

--@net_tml_del
function net_tml_del(param)
    module_debug.lua_debug(module_debug.INFO, "###############################DELETE###############################")
    --参数校验
    if (param == nil or tool.json_check(param) == false) then
        module_debug.lua_debug(module_debug.INFO, "Input data is not json mode.")
        return -1
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return -1
    end

    local config_tab = tool.file_read(NT_TML_JSON_FILE)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return -1
    end

    config_tab = cjson.decode(config_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return -1
    end

    local ret
    local del_flag = 0
    local mac_list = {}

    -- 创建ubus连接对象
    local conn = ubus.connect(nil, UBUS_WAIT_TIME)
    if not conn then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [net_tml_del] connect to ubus fail!")
        return -1
    else
        module_debug.lua_debug(module_debug.INFO, "connect to ubus success")
    end

    for k,v in pairs(param_tab["nt_info"]) do
        if (v["mac"] == nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] mac is nil")
            conn:close()
            return -1
        end
        ret = del_config_bind_office_mesh(v, mac_list)
        if (ret ~= 0) then
            del_flag = del_flag - 1
        end
    end

    module_debug.lua_debug(module_debug.INFO, "all del mac_list: %s", cjson.encode(mac_list))
    if #mac_list > 0 then
        -- 通知nt_mgr.usr_del删除终端
        local usr_del_param = { nt_info = mac_list }
        local ret = ubus_cmd_exe("nt_mgr.usr_del", "set", usr_del_param, conn)
        if not ret or ret.code == nil or tostring(ret.code) ~= "0" then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] ubus call nt_mgr.usr_del is failed")
            conn:close()
            return -1
        end
        for k,v in pairs(mac_list) do
            net_tml_json_del_office_mesh(config_tab, v)
            if del_uci_nt_info(v) ~= 0 then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] update_uci_nt_info is failed")
                conn:close()
                return -1
            end
        end
        if param_tab["from"] == nil or param_tab["from"] ~= "cloud" then
            -- 通知mqlink进程
            local mqlink_param = {
                name = "nt_mgr",
                bizid = "nt_mgr_01",
                ack = "true",
                val = {
                    op = "fix_del",
                    list = mac_list,
                    num = #mac_list
                }
            }
            if ubus_cmd_exe("mqlink", "status_notify", mqlink_param, conn) == nil then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] ubus call mqlink status_notify is failed")
                conn:close()
                return -1
            end
        end
    end

    conn:close()

    if (del_flag < 0) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] del_config_bind is failed param is %s", param)
        return -1
    end
    config_tab = cjson.encode(config_tab)
    if (config_tab ~= nil) then
        tool.file_write(NT_TML_JSON_FILE, config_tab)
    end
    uci:commit("net_tml")

    module_debug.lua_debug(module_debug.INFO, "################################DEL END################################")
    return 0
end

function module_default_config_get()
    module_debug.lua_debug(module_debug.DEBUG, "module_default_config_get")
    local default_config = '{"nt_info":[]}'
    return default_config
end

--@dev_mode_del
function module_del(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end
    local ret = net_tml_del(param)
    os.remove(LOCK_FILE)
    if (ret == -1) then
        module_debug.lua_debug(module_debug.INFO, "INFO: ret -1")
        return check_result("0001")
    end
    return check_result("0000")
end

--@dev_mode_update
function module_update(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end
    local ret = net_tml_update(param)
    os.remove(LOCK_FILE)
    if (ret == -1) then
        module_debug.lua_debug(module_debug.INFO, "INFO: ret -1")
        return check_result("0001")
    end
    return check_result("0000")
end

function module_apply()
    module_debug.lua_debug(module_debug.DEBUG, "module_apply")
end

--@module_set
function module_set(param)
    debug_init()

    --单实例检测
    if (single_instance_check(LOCK_FILE) == false) then
        return check_result("0001")
    end

    if (libc2lua.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param is nil")
        end
        os.remove(LOCK_FILE)
        return check_result("0001")
    end

    os.remove(LOCK_FILE)
    return check_result("0000")
end