#! /usr/bin/env lua

module_name = "appAuthParamFmt"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

cjson_safe = require "cjson"
module_debug = require "utils.debug"
moduleId = require "dev_module_id"
local product = require("product")

local def_cfg_str = '\
{\
    "supportParam":[\
        "nas_ip","nas_mac","client_ip","client_mac","orig_url","login_url",\
        "logout_url","ssid","sn","identity","chap_id","chap_challenge",\
        "interface_name","login_host","other"\
    ],\
    "paramFmt":[\
        {\
            "request": {\
                "method":"get",\
                "params":[\
                    {"type":"nas_mac","key":"nas_mac","val":"NULL"},\
                    {"type":"client_mac","key":"client_mac","val":"NULL"},\
                    {"type":"orig_url","key":"url","val":"NULL"},\
                    {"type":"nas_ip","key":"nas_ip","val":"NULL"},\
                    {"type":"login_url","key":"login_url","val":"NULL"},\
                    {"type":"logout_url","key":"logout_url","val":"NULL"},\
                    {"type":"ssid","key":"ssid","val":"NULL"}\
                ]\
            },\
            "respone": {\
                "username": "username",\
                "password": "password",\
                "next_url": "next_url"\
            }\
        },\
        {\
            "request": {\
                "method":"get",\
                "params":[\
                    {"type":"nas_mac","key":"nas_mac","val":"NULL"},\
                    {"type":"client_mac","key":"client_mac","val":"NULL"},\
                    {"type":"orig_url","key":"url","val":"NULL"},\
                    {"type":"nas_ip","key":"nas_ip","val":"NULL"},\
                    {"type":"login_url","key":"login_url","val":"NULL"},\
                    {"type":"logout_url","key":"logout_url","val":"NULL"},\
                    {"type":"ssid","key":"ssid","val":"NULL"},\
                    {"type":"chap_id","key":"chap_id","val":"NULL"},\
                    {"type":"chap_challenge","key":"chap_challenge","val":"NULL"},\
                    {"type":"identity","key":"identity","val":"NULL"}\
                ]\
            },\
            "respone": {\
                "username": "username",\
                "password": "password",\
                "next_url": "next_url",\
            }\
        }\
    ]\
}'

-- default config
function module_default_config_get()
    local cfg_tbl = cjson.decode(def_cfg_str)
    local fmtType = product.get_product("capacity.portal.param_fmt");

    cfg_tbl.paramFmt[1].request.paramFmtType = fmtType
    cfg_tbl.paramFmt[2].request.paramFmtType = fmtType .. "-CHAP"

    return cjson.encode(cfg_tbl)
end

--[[

]]--
function module_add(param, config_file_path)
    return '{"rcode":"00000000","message":""}'
end

--[[

]]--
function module_set(param)
    return '{"rcode":"00000000","message":""}'
end
--[[

]]--
function module_del(param)
    return '{"rcode":"00000000","message":""}'
end

--[[
    param format:
    
        dev_config -m update safeZoneGlobal '{"logEnable":"0"}'
]]--
function module_update(param, config_file_path)
    return '{"rcode":"00000000","message":""}'
end

-- Configuration Framework Apply
function module_apply()
    return '{"rcode":"00000000","message":""}'
end
