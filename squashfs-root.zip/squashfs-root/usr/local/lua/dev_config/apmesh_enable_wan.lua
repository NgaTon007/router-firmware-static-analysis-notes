#! /usr/bin/lua

module("apmesh_enable_wan", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local sys = require "luci.sys"

--debug
local function debug(msg)
    console.debug("apmesh_enable_wan", msg)
end

function module_default_config_get()
    local data = {}
    data.enable = "false"
    return dkjson.encode(data)
end

function module_set(param)
    debug("param: " .. dkjson.encode(param))
    local table = {rcode= "04090014", rmsg= "parameter apmesh_enable_wan:enable is invalid, require <true|false>"}
    local relayMode = uci:get_first("sysinfo", "sysinfo", "relayMode") or ""
    if relayMode ~= "wirelessBridge" then
        debug("relayMode is not wirelessBridge, stop " .. relayMode)
        return console.uf_lua_fail(table)
    end
    local paramTable = dkjson.decode(param)
    if paramTable and paramTable.enable and paramTable.enable == "true" then
        debug("ubus call apmgr apmesh_make_alone_intf '{\"action\":\"del\"}'")
        os.execute("ubus call apmgr apmesh_make_alone_intf '{\"action\":\"del\"}'")
        -- 若无线桥接模式下启用WAN口，则需关闭基于WAN口隔离的环路检测机制
        uci:set("apmgr", "global", "loop_detection_enable", "0")
        uci:commit("apmgr")
        os.execute("sync")
    elseif paramTable and paramTable.enable and paramTable.enable == "false" then
        debug("ubus call apmgr apmesh_make_alone_intf '{\"action\":\"add\"}'")
        os.execute("ubus call apmgr apmesh_make_alone_intf '{\"action\":\"add\"}'")
        -- 若无线桥接模式下停用WAN口，则需开启基于WAN口隔离的环路检测机制
        uci:set("apmgr", "global", "loop_detection_enable", "1")
        uci:commit("apmgr")
        os.execute("sync")
    else
        return console.uf_lua_fail(table)
    end
    return console.uf_lua_success()
end
