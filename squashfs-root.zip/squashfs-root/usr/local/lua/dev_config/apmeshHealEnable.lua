#! /usr/bin/lua

module("apmeshHealEnable", package.seeall); 

local console = require "console"
local dkjson = require "dkjson"
local uci = require "luci.model.uci".cursor()
local sys = require "luci.sys"

--debug
local function debug(msg)
    console.debug("apmeshHealEnable", msg)
end

function module_default_config_get()
    local data = {}
    data.enable = "false"
    return dkjson.encode(data)
end

function module_set(param)
    debug("param: " .. dkjson.encode(param))
    local paramTable = dkjson.decode(param)
    local table = {rcode= "04090014", rmsg= "parameter apmeshHealEnable:enable is invalid, require <true|false>"}
    -- 1 open heal, 0 close heal
    if paramTable and paramTable.enable and paramTable.enable == "true" then
        debug("ubus call apmgr apmesh_heal_enable '{\"enable\": 1}'")
        os.execute("ubus call apmgr apmesh_heal_enable '{\"enable\": 1}'")
    elseif paramTable and paramTable.enable and paramTable.enable == "false" then
        debug("ubus call apmgr apmesh_heal_enable '{\"enable\": 0}'")
        os.execute("ubus call apmgr apmesh_heal_enable '{\"enable\": 0}'")
    else
        return console.uf_lua_fail(table)
    end
    return console.uf_lua_success()
end
