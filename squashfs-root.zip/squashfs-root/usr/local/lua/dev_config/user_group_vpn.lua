#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("user_group_vpn", package.seeall)

local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local console = require "console"
local DEBUG_DIR_LOGFILE = "/tmp/user_group/vpn/"
local LOCK_FILE = "/tmp/user_group/web/user_group.lock"
local USER_GROUP_JSON_FILE = "/etc/sd_config/single/user_group.json"
local USER_MRG_CMD_ELF = "/usr/sbin/user_mgr_cmd.elf"
local table_input_err = {rcode = "05660001", rmsg = "param error"}
local table_input_err1 = {rcode = "05660002", rmsg = "config file error"}
local lib_user = require "user_mgr.user_mgr_common"

if (tool.file_exist(DEBUG_DIR_LOGFILE) == false) then
    local path = "mkdir -p " .. DEBUG_DIR_LOGFILE .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_DIR_LOGFILE, "user_group_vpn.log", 500, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    elseif ret == "0002" then
        return console.uf_lua_fail(table_input_err1)
    end
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local temp_path = path .. ".tmp"

    local f = io.open(temp_path, mode)
    if (f) then
        if f:write(content) ~= nil then
            io.close(f)

            -- 原子重命名：将临时文件移动到目标路径
            local success, err = os.rename(temp_path, path)
            if success then
                return 0
            else
                module_debug.lua_debug(module_debug.ERROR, "failed to rename [%s] to [%s]: %s", temp_path, path, err)
                os.remove(temp_path)
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "write failed for [%s]", temp_path)
            io.close(f)
            os.remove(temp_path)
            return -1
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "open failed for [%s]", temp_path)
        return -1
    end
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = cjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "file :[%s]", path)
            res = file_write(path, config_str)
            if (res == -1) then
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end

    return 0
end

--删除
local function del_config_bind(var, config_tab)
    module_debug.lua_debug(module_debug.INFO, "name %s, vpn type %s", var.name, var.type)
    local config_flag = 0
    local section_id = nil
    uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local vpn_grp_name = uci:get("user_mgr", namecode, "name")
        local grp_type = uci:get("user_mgr", namecode, "type")
        if (grp_type == "vpn" and vpn_grp_name == var.name) then		    
            section_id = namecode
        end		
    end
    )
    if section_id ~= nil then
        local ori_owner_type = uci:get_list("user_mgr", section_id, "owner_type")
        if (ori_owner_type[1] ~= nil) then
            for i = #ori_owner_type, 1, -1 do
                if ori_owner_type[i] == var.type then
                    table.remove(ori_owner_type, i)
                end
            end
        end
        
        local count = 1
        while (lib_user.single_uci_writer_check() == false) do
            if count > 5 then
                module_debug.lua_debug(module_debug.ERROR, "ERROR: grab lock failed")
                return -1
            end
            module_debug.lua_debug(module_debug.INFO, "INFO: waiting 1 second")
            tool.sleep(1)
            count = count + 1
        end
        if (ori_owner_type[1] ~= nil) then
            uci:set("user_mgr", section_id, "owner_type", ori_owner_type)
        else
            uci:delete("user_mgr", section_id)
            uci:foreach("user_mgr", "user", function(s)
                local namecode = s[".name"]
                local parent_id = uci:get("user_mgr", namecode, "parent")   
                if (parent_id == section_id) then        
                    uci:delete("user_mgr", namecode)
                end     
            end
            )
        end
        uci:commit("user_mgr")
        lib_user.remove_uci_lock_file()
        if (ori_owner_type[1] == nil) then
            for k,v in pairs(config_tab["groups"]) do
                if (v["id"] == "4" and v["type"] == "vpn") then
                    if (v["child"] ~= nil) then
                        for x,y in pairs (v["child"]) do
                            if (y["id"] == section_id) then
                                module_debug.lua_debug(module_debug.INFO, "del_id:%s", y["id"])
                                table.remove(v["child"], x)
                                config_flag = 1
                                break
                            end   
                        end
                    end
                end
                if (config_flag == 1) then
                    config_flag = 0
                    break
                end
            end
            del_id_cmd = USER_MRG_CMD_ELF .. " -D -d " .. section_id .. " >/dev/null 2>&1"
            module_debug.lua_debug(module_debug.INFO, "del_id_cmd = %s", del_id_cmd)
            os.execute(del_id_cmd)
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "section_id is nil")
    end
end
------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    module_debug.lua_debug(module_debug.INFO, "module_default_config_get")
    local default_config = '{"id":[]}'
    return default_config
end

function module_del(param)
    debug_init();

    if (lib_param.lua_param_safety_check(param) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param is unsafe")
        if (param ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param %s", param)
        end
        return check_result("0001")
    end

    module_debug.lua_debug(module_debug.INFO, "Input data: %s", param)
    local param_tab = cjson.decode(param)
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] param_tab is nil")
        return check_result("0001")
    end

    json_tab = tool.file_read(USER_GROUP_JSON_FILE)
    if (json_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return check_result("0002")
    end

    config_tab = cjson.decode(json_tab)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_del] config is nil")
        return check_result("0002")
    end
    local ret = del_config_bind(param_tab, config_tab)
    if ret == -1 then
        return check_result("0002")
    end
    
    json_tab = cjson.encode(config_tab)
    if (json_tab ~= nil) then
        ret = json_write_to_file(USER_GROUP_JSON_FILE, config_tab)
        if ret == -1 then
            return check_result("0002")
        end
    end
    module_debug.lua_debug(module_debug.INFO, "################################DEL END################################");
    return check_result("0000")
end

function module_apply()
    module_debug.lua_debug(module_debug.INFO, "module_apply");
end
