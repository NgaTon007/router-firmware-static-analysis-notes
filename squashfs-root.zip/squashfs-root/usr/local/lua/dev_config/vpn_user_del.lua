#! /usr/bin/lua
module("vpn_user_del",package.seeall)
package.path = string.format("%s;%s;", package.path, "/usr/lib/snosvpn/?.lua;")
local lfs = require "lfs"
local cjson = require "cjson";
local vpn = require "utils.debug"
local tool = require "dev.tools.common"
local snosvpn = require "common"
local openvpn = require "openvpn"
local uci = require "luci.model.uci".cursor()
local libc2lua = require "libc2lua"
local OPENVPN_CONFIG_FILE = "/etc/config/openvpn"
local openvpn_exist = tool.file_exist(OPENVPN_CONFIG_FILE)
local DEBUG_LOG_DIR = "/tmp/vpn_user/"
local SERVER_UPDOWN_CMD = "lua /usr/lib/snosvpn/l2tp_server_updown.lua"
local VPN_USER_JSON_FILE = "/etc/sd_config/single/vpn_user.json"
local UPDOWN_DIR = {
    ["l2tpserver"] = "/tmp/l2tp/updown/",
    ["pptpserver"] = "/tmp/pptp/updown/"
}

local SERVER_DIR = {
    ["l2tpserver"] = "/tmp/l2tp/server/",
    ["pptpserver"] = "/tmp/pptp/server/"
}

local sd_device = "/tmp/sd_device/sd_device.json"
local sd_device_json = nil
local support_vpn_account_fc = nil
if (tool.file_exist(sd_device) == true) then
    local file_data = tool.file_read(sd_device);
    sd_device_json = cjson.decode(file_data);
    support_vpn_account_fc = sd_device_json["gateway"]["vpn_account_fc"]
end

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
local function debug_init()
    vpn.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "vpn_user_del.log", 500, vpn.INFO, "1")
end

local function openvpn_user_del(fn_json)
    for key, val in pairs(fn_json.list) do
        if (val.provider == "all" or val.provider == "openvpnserver") then
            if (openvpn_exist == true) then
                local user_name_input = val.username
                os.execute("echo -e 'kill "..user_name_input.." \r\n' |nc 127.0.0.1 5572 &");
                os.execute("killall -9 nc 2>/dev/null");
            end
        end 
    end
    local file = io.open("/etc/openvpn/psw-file", "w")
    if file then
        file:write("") --清空文件
        file:close()
    end
end

local function delete_user_to_link_record_file()
    list = {"l2tpserver","pptpserver"}
    for i, var in ipairs(list) do
        local file_json = {}
        local name = nil
        local del_node = {}
        local LINK_RECORD_FILE = table.concat({SERVER_DIR[var], "link_record"})
        if (tool.file_exist(LINK_RECORD_FILE) == true) then
            local cmd = "rm -rf "..LINK_RECORD_FILE.." 2>/dev/null"
            vpn.lua_debug(vpn.INFO, "cmd: %s", cmd)
            os.execute(cmd)
        end
    end
end

local function delete_username_and_password()
    list = {"l2tpserver","pptpserver"}
    for i, var in ipairs(list) do
        local name = var:match("(%w+)server")
        local chap_file_cmd = table.concat({"rm -rf /tmp/", name, "/chap-secrets 2>/dev/null"});
        local pap_file_cmd = table.concat({"rm -rf /tmp/", name, "/pap-secrets 2>/dev/null"});
        vpn.lua_debug(vpn.INFO, "chap_file_cmd: %s", chap_file_cmd)
        vpn.lua_debug(vpn.INFO, "pap_file_cmd: %s", pap_file_cmd)
        os.execute(chap_file_cmd)
        os.execute(pap_file_cmd)
    end
end

local function stop_client_connect(fn_json, fn_dir)
    local kill_cmd = "kill -TERM";
    local rm_file_cmd = "rm -rf";
    local provider = fn_json["provider"];
    local username = fn_json["username"];

    if (tool.file_exist(fn_dir) == false) then
        return;
    end

    for file in lfs.dir(fn_dir) do
        if (string.match(file, "limit") ~= nil) then
            local pid_file = table.concat({fn_dir, file});
            local pid = tool.file_read(pid_file);
            kill_cmd = table.concat({kill_cmd, " ", pid});
            rm_file_cmd = table.concat({rm_file_cmd, " ", pid_file});
            local tunnelname = tool.split(file, "_")[1];
            local save_file = table.concat({SERVER_DIR[provider], tunnelname, "_client_save"});
            local down_file = table.concat({UPDOWN_DIR[provider], tunnelname, "_client_save"});
            if (tool.file_exist(save_file) == true) then
                os.rename(save_file, down_file);
                os.execute(SERVER_UPDOWN_CMD);
            end
        end
    end

    if (kill_cmd ~= "kill -TERM") then
        os.execute(table.concat({kill_cmd, " 2>/dev/null"}));
    end
    if (rm_file_cmd ~= "rm -rf") then
        os.execute(rm_file_cmd);
    end
end

local function vpn_user_delete(fn_json)
    local list = {fn_json.provider}
    if (fn_json.provider == "all") then
        list = {"l2tpserver","pptpserver"}
    end
    for i, var in ipairs(list) do
        local data_json = fn_json;
        if (data_json ~= nil and next(data_json) ~= nil) then
            data_json.provider = var;
            local userdir = table.concat({DEBUG_LOG_DIR, data_json.provider, "_", data_json.username, "/"});
            vpn.lua_debug(vpn.INFO, "userdir: %s", userdir)
            stop_client_connect(data_json, userdir);
            os.execute(table.concat({"rm -rf ", userdir}))
        end
    end
end

local function del_vpn_account_group()
    local del_id_table = {}
    del_id_table["id"] = {}
    uci:foreach("user_mgr", "user_grp", function(s)
        local namecode = s[".name"]
        local grp_type = uci:get("user_mgr", namecode, "type")
        if (grp_type == "vpn") then		    
            table.insert(del_id_table["id"], namecode)
        end		
    end
    )
    if (del_id_table["id"] ~= nil) then
        local del_tab = cjson.encode(del_id_table)
        local del_cmd = "dev_config del -m user_group '"..del_tab.."' >/dev/null 2>&1 &"
        vpn.lua_debug(vpn.INFO, "del_cmd[%s]", del_cmd)
        tool.exec("exec 1>/tmp/null 2>&1")
        tool.exec(del_cmd)
    end
end
--------------------------------dev_mode--------------------------------
function module_default_config_get()
    local default_config = '{}'
    return default_config
end

function module_del(input_data)
    debug_init();
    local json = {};
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if (tool.file_exist(VPN_USER_JSON_FILE) == true) then
        local file_data = tool.file_read(VPN_USER_JSON_FILE)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end
 
    if (json.list == nil) then
        return;
    end
    
    if (openvpn_exist == true) then
        openvpn_user_del(json)
    end
    
    delete_user_to_link_record_file()
    delete_username_and_password()
    for key, val in pairs(json.list) do
        local role = val.provider;
        if (role ~= "openvpnserver") then
            vpn_user_delete(val)
        end
    end
    if (support_vpn_account_fc ~= nil) then
        del_vpn_account_group()
    end
    for j=#json.list,1,-1 do
        table.remove(json.list, j)
    end
    tool.file_write(VPN_USER_JSON_FILE, cjson.encode(json), "w+")
    --更新vpn账号配置文件，同步给云端
    local cmd = "dev_config update -m vpn_user '{}' >/dev/null 2>&1 &"
    os.execute(cmd)
    if (require("utils.file").file_is_exist("/usr/lib/lua/std_syslog_lua.so") == true) then
        local std_syslog= require("std_syslog_lua");
        local ret_code;
        local ret_msg;
        ret_code, ret_msg = std_syslog.std_syslog_lua(std_syslog.SSG_USER_MSG, std_syslog.SSG_INFO, std_syslog.SSG_UNRELIABLE or std_syslog.SSG_LOW_RATE, 0, "VPN_USER", "VPN_USER_ALL_DEL", "delete all vpn account");
        if (ret_code > std_syslog.NORMALLY_RET_CODE) then
            print("std_syslog_lua failed ret_msg:" .. ret_msg);
        end
    end
end

function module_apply()
    vpn.lua_debug(vpn.INFO, "module_apply");
    vpn.lua_debug(vpn.INFO, "################################END################################")
end