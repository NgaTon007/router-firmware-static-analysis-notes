#! /usr/bin/lua
module("l2tp_lcp_client_interval",package.seeall)
local libc2lua = require "libc2lua";
local cjson = require "cjson";
local l2tp = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/l2tp/"
local L2TP_CLIENT_SAVE_FILE = "/etc/sd_config/single/l2tp_client.json";

--debug初始化
function debug_init()
    l2tp.debug_init(DEBUG_LOG_DIR, "l2tp_lcp_client_interval.log", 500, l2tp.INFO, "1");
end

--@module_default_config
function module_default_config_get()
    local default_config = '{"l2tphellointerval":"60"}'
    return default_config
end

--@module_set
function module_set(input_data, conf_file)
    debug_init();
    
    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_set] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_set] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, "\\n") then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, ">") then
        l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            l2tp.lua_debug(l2tp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end

    if (conf_file ~= nil) then
        if (libc2lua.lua_param_safety_check(conf_file) ~= true) then
            l2tp.lua_debug(l2tp.DEBUG, "conf_file error.  conf_file is %s\n", conf_file)
            return
        end
    end
    if (input_data == nil) then
        l2tp.lua_debug(l2tp.ERROR, "Input data empty.");
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "Input data: %s", input_data);

    --获取参数
    if (tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.ERROR, "Input data is not json.");
        return;
    end
    data = cjson.decode(input_data);
    l2tphellointerval = data["l2tphellointerval"]

    --获取l2tp的客户端
    if (tool.file_exist(L2TP_CLIENT_SAVE_FILE) == false) then
        return;
    end
    local file_data = tool.file_read(L2TP_CLIENT_SAVE_FILE)
    if (file_data == nil) then
        l2tp.lua_debug(l2tp.ERROR, "File data is empty.");
        return;
    end
    l2tp.lua_debug(l2tp.INFO, "File data: %s", file_data);
    if (tool.json_check(file_data) == false) then
        l2tp.lua_debug(l2tp.ERROR, "File data is not json.");
        return;
    end
    local file_json = cjson.decode(file_data);
    if (file_json["list"] ~= nil and next(file_json["list"]) ~= nil) then
        for i = 1, #file_json["list"], 1 do
            local tunnelname = file_json["list"][i]["tunnelname"];
            if (tunnelname ~= nil and l2tphellointerval ~= nil) then
                local cmd = table.concat({"xl2tpd-control add l2tp-", tunnelname , " redial timeout=", l2tphellointerval});
                os.execute(cmd);
            end
        end
    end
end
