#! /usr/bin/lua
module("pptp_lcp_client_interval",package.seeall)
package.path = string.format("%s;%s;", package.path, "/usr/local/lua/dev_config/?.lua")

local cjson = require "cjson";
local pptp = require "utils.debug"
local pptp_client = require "pptp_client"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/pptp/"
local STATUS = "close"
local PPTP_CLIENT_SAVE_FILE = "/etc/sd_config/single/pptp_client.json";

--debug初始化
function debug_init()
    pptp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "pptp_lcp_client_interval.log", 500, pptp.INFO, "1");
end

--@module_default_config
function module_default_config_get()
    local default_config = '{"lcpechointerval":"60"}'
    return default_config
end

--@module_set
function module_set(input_data, conf_file)
    if (STATUS == "close") then
        return;
    end

    debug_init();
    if (input_data == nil) then
        pptp.lua_debug(pptp.ERROR, "Input data is not json.");
        return;
    end
    pptp.lua_debug(pptp.INFO, "input data: %s", input_data);

    --获取参数
    if (tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.ERROR, "Input data is not json.");
        return;
    end

    --获取参数
    if (tool.json_check(input_data) == false) then
        l2tp.lua_debug(l2tp.ERROR, "Input data is not json.");
        return;
    end
    data = cjson.decode(input_data);

    --获取PPP链路维护时间间隔
    local is_num = tonumber(data["lcpechointerval"]);
    if (is_num ~= nil and is_num > 10) then
    lcpechointerval = data["lcpechointerval"];
    end

    if (tool.file_exist(PPTP_CLIENT_SAVE_FILE) == false) then
        return;
    end
    local file_data = tool.file_read(PPTP_CLIENT_SAVE_FILE)
    pptp.lua_debug(pptp.INFO, "File data: %s", file_data);
    
    if (tool.json_check(file_data) == false) then
        pptp.lua_debug(pptp.ERROR, "File data is not json.");
        return;
    end
    local file_json = cjson.decode(file_data);
    if (file_json["list"] ~= nil and next(file_json["list"]) ~= nil) then
        for i = 1, #file_json["list"], 1 do
            file_json["list"][i]["lcpechointerval"] = lcpechointerval;
            local output = cjson.encode(file_json["list"][i]);
            if (output ~= nil) then
                pptp.lua_debug(pptp.INFO, "%s", output);
                pptp_client.module_update(output, PPTP_CLIENT_SAVE_FILE)
            end
        end
    end
    pptp.lua_debug(pptp.INFO, "##############END##############");
end
