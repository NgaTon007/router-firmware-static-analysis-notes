#!/usr/bin/env lua
module("pptp_client", package.seeall)

local lfs = require "lfs"
local cjson = require "cjson";
local pptp = require "utils.debug"
local tool = require "dev.tools.common"
local libc2lua = require "libc2lua"
local sd_crypto = require "sd_crypto"
local pptp_uci = require "luci.model.uci".cursor(nil, "/var/run/pptp_client_state")
local DEBUG_LOG_DIR = "/tmp/pptp/"
local PPTP_DIR = "/tmp/pptp/"
local TUNNEL_DIR = nil;
local SNOSVPN_DIR = "/var/log/snosvpn/pptp/"
local SNOSVPN_PPP_CLIENT_LOG = table.concat({SNOSVPN_DIR, "pptp_pppd_client_log"})
local SNOSVPN_ROUTE = "/tmp/snosvpn/route"
local LOCK_FILE = "/tmp/pptp/clien_lock"
local START_DIR = table.concat({DEBUG_LOG_DIR, "start/"})
local LCP_ECHO_FILE = "/etc/sd_config/single/pptp_lcp_client_interval.json"
local IPTABLES_RULES_DIR = table.concat({DEBUG_LOG_DIR, "iptables/"})
local IP_ROUTE_DIR = table.concat({DEBUG_LOG_DIR, "iproute/"})
local SD_CONFIG_FILE = table.concat({DEBUG_LOG_DIR, "pptp_client.json"});
local IPTABLES_RULES_FILE = nil;
local IP_ROUTE_FILE = nil;
local IPTABLES_COMMENT = "vpn"
local pppd_cmd = "/usr/sbin/pppd "
local pppd_option = " nodetach nodefaultroute usepeerdns persist maxfail 0 plugin pptp.so file "
local lcpechointerval = "60"
local pptphellointerval = "60"
local LCP_ECHO_FAILURE = "5"
local CLIENT_DIR = nil;
local pptp_tunnelname = nil;
local tunnelname = nil;

if (tool.file_exist(START_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", START_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(SNOSVPN_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", SNOSVPN_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(IP_ROUTE_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", IP_ROUTE_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

if (tool.file_exist(PPTP_DIR) == false) then
    local mkdir = table.concat({"mkdir -p ", PPTP_DIR, " >/dev/null 2>&1"});
    os.execute(mkdir);
end

--debug初始化
function debug_init()
    pptp.debug_init(table.concat({DEBUG_LOG_DIR, "log/"}), "pptp_client.log", 500, pptp.INFO, "1");
end

--获取pptp链路维护时间间隔
local function lcp_echo_interval_get(fn_json)
    if (tool.file_exist(LCP_ECHO_FILE) == true) then
        local file_data = tool.file_read(LCP_ECHO_FILE)
        if (file_data == nil or tool.json_check(file_data) == false) then
            return;
        end
        local json = cjson.decode(file_data)
        if (json["pptphellointerval"] ~= nil) then
            pptphellointerval = json["pptphellointerval"];
        end
        if (json["lcpechointerval"] ~= nil) then
            lcpechointerval = json["lcpechointerval"];
        end
    end

    if (fn_json["lcpechointerval"] ~= nil) then
        local num = tonumber(fn_json["lcpechointerval"]);
        if (num ~= nil and num > 0) then
            lcpechointerval = fn_json["lcpechointerval"];
        end
    end
end

local function tunnelname_get(tunnel)
    pptp_tunnelname = tunnel
    if (pptp_tunnelname == nil) then
        pptp.lua_debug(pptp.INFO, "Tunnelname is not exist.");
        return false;
    end
    tunnelname = tool.split(pptp_tunnelname, "pptp-")[2];
    if (tunnelname == nil) then
        tunnelname = pptp_tunnelname;
        pptp_tunnelname = table.concat({"pptp-", tunnelname});
    end
    pptp.lua_debug(pptp.INFO, "tunnelname: %s", tunnelname);
    pptp.lua_debug(pptp.INFO, "pptp_tunnelname: %s", pptp_tunnelname);

    CLIENT_DIR = table.concat({DEBUG_LOG_DIR, tunnelname, "/"});
    if (tool.file_exist(CLIENT_DIR) == false) then
        local mkdir = table.concat({"mkdir -p ", CLIENT_DIR, " >/dev/null 2>&1"});
        os.execute(mkdir);
    end

    IPTABLES_RULES_FILE = table.concat({IPTABLES_RULES_DIR, "pptp_client_", tunnelname})
    IP_ROUTE_FILE = table.concat({IP_ROUTE_DIR, "pptp_client_", tunnelname});
    TUNNEL_DIR = table.concat({PPTP_DIR, tunnelname, "/"});

    return true;
end

local function get_gateway_ipaddr(interface)
    local gateway = nil;

    if (interface == nil) then
        return gateway;
    end
    if (tool.file_exist(SNOSVPN_ROUTE) == false) then
        return gateway;
    end

    local file = io.open(SNOSVPN_ROUTE)
    for line in file:lines() do
        if (line ~= nil and tool.json_check(line) == true) then
            json = cjson.decode(line);
            if (string.lower(json["interface"]) == string.lower(interface)) then
                gateway = json["gateway"];
            end
        end
    end
    io.close(file);

    return gateway;
end

local function iptables_del()
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
    os.remove(IPTABLES_RULES_FILE);
end

local function iptables_add()
    local file = assert(io.open(IPTABLES_RULES_FILE, "w+"));
    file:write("iptables -w -D INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:write("iptables -w -I INPUT -p gre -j ACCEPT -m comment --comment ", IPTABLES_COMMENT, " 2>/dev/null\n");
    file:close(file);

    os.execute(table.concat({"chmod +x ", IPTABLES_RULES_FILE}));
    os.execute(table.concat({"sh ", IPTABLES_RULES_FILE}));
end

-- 设置iptable规则
function ipset_and_route_del(name)
    local json = {};
    if (name == nil) then
        return;
    end
    if (tool.file_exist(TUNNEL_DIR) == false) then
        return;
    end

    for pid_file in lfs.dir(TUNNEL_DIR) do
        if (string.find(pid_file, "pid_") ~= nil) then
            local info_file = table.concat({TUNNEL_DIR, pid_file, "/info"});
            local ipset_route_file = table.concat({TUNNEL_DIR, pid_file, "/ipset_route"});
            if (tool.file_exist(info_file) == true) then
                local file_data = tool.file_read(info_file)
                if (file_data ~= nil and tool.json_check(file_data) == true) then
                    json = cjson.decode(file_data)
                end
            end
            local lns = json["ins"];
            local gateway = json["gateway"];
            local file = assert(io.open(ipset_route_file, "w+"));
            if (lns ~= nil) then
                file:write("ipset del zone_vpn_1723_accept ", lns, " 2>/dev/null\n");
            end
            if (lns ~= nil and gateway ~= nil) then
                file:write("ip route del ", lns, " via ", gateway," table 350 2>/dev/null\n");
            end
            file:close(file);
            os.execute(table.concat({"chmod +x ", ipset_route_file}));
            os.execute(table.concat({"sh ", ipset_route_file}));
            os.execute(table.concat({"rm -rf ", TUNNEL_DIR, pid_file})); 
        end
    end
end

function check_link_status()
    --检查PPP是否断链，如果没有断链，不会触发/etc/ppp/ip-down.d/目录下脚本的执行
    local lock_file = table.concat({CLIENT_DIR, tunnelname, ".lock"});
    local up_file = table.concat({CLIENT_DIR, tunnelname, "_up"});
    for i = 1, 2, 1 do
        if (tool.file_exist(lock_file) == false and tool.file_exist(up_file) == true) then
            tool.sleep(1);
        end
    end
    os.execute(table.concat({"rm -rf ", lock_file}));
end

function client_start_pppd(fn_json)
    local optfile = table.concat({CLIENT_DIR, "options.", tunnelname})
    local startfile = table.concat({START_DIR, "start_", tunnelname})
    local file = assert(io.open(optfile,"w+"));
    if (fn_json["local_ip"] ~= nil and fn_json["local_ip"] ~= "") then
        file:write(fn_json["local_ip"], ":\n");
    end
    file:write("debug\n");
    file:write("mtu 1360\n");
    file:write("mru 1360\n");
    file:write("persist\n");
    file:write("maxfail 0\n");
    file:write("usepeerdns\n");
    if (fn_json["mppe"] == "1") then
        file:write("mppe required,no40,no56,stateless\n");  
    else
        file:write("noccp\n");
    end
    file:write("noaccomp\n");
    file:write("nopcomp\n");
    file:write("novj\n");
    file:write("novjccomp\n");
    file:write("noipdefault\n");
    file:write("nodefaultroute\n");
    file:write("lcp-echo-interval ", lcpechointerval, "\n");
    file:write("lcp-echo-failure ", LCP_ECHO_FAILURE, "\n");
    file:write("user '", fn_json["username"], "'\n");
    file:write("password '", fn_json["password"], "'\n");
    file:write("pptp_server ", fn_json["lns"], "\n");
    file:write("bind_iface ", string.lower(fn_json["intf_binding"]), "\n");
    file:write("tunnelname ", tunnelname, "\n");
    file:write("ip-up-script /lib/netifd/ppp-up\n");
    file:write("ipv6-up-script /lib/netifd/ppp-up\n");
    file:write("ip-down-script /lib/netifd/ppp-down\n");
    file:write("ipv6-down-script /lib/netifd/ppp-down\n");
    file:write("logfile ", SNOSVPN_PPP_CLIENT_LOG, "\n");
    file:close(file)
    --删除pptp客户端日志
    if (tool.file_exist(SNOSVPN_PPP_CLIENT_LOG) == true) then
        os.execute("rm -rf /tmp/log/snosvpn/pptp/pptp_pppd_client_log*");
    end
    iptables_add()
    if (fn_json["enable"] == "1") then
        file = assert(io.open(startfile, "w+"));
        file:write("lua /usr/lib/snosvpn/pptp_client_stop_pppd.lua ", pptp_tunnelname, "\n");
        file:write(pppd_cmd, "ifname ", pptp_tunnelname, pppd_option ,optfile, ">/dev/null 2>&1 &", "\n");
        file:close(file);
        os.execute(table.concat({"chmod +x ", startfile}));
        os.execute("ubus -t 3 send pptp_client_connect");
    else
        os.remove(startfile);
    end
end

function client_stop_pppd(fn_json)
    local startfile = table.concat({START_DIR, "start_", tunnelname})
    os.remove(startfile);

    if (tool.file_exist(TUNNEL_DIR) == true) then
        for file in lfs.dir(TUNNEL_DIR) do
            if (string.find(file, "pid_") ~= nil) then
                local pid_file = table.concat({TUNNEL_DIR, file, "/run"});
                pptp.lua_debug(pptp.INFO, "Remove run file: %s", pid_file);
                os.remove(table.concat({TUNNEL_DIR, pid_file}));
            end
        end
    end

    local cmd = table.concat({"lua /usr/lib/snosvpn/pptp_client_stop_pppd.lua ", pptp_tunnelname});
    os.execute(cmd);

    --删除iptables规则
    iptables_del()
end

function delete_old_config(conf_file)
    local file_data = tool.file_read(conf_file)
    if (file_data == nil or tool.json_check(file_data) == false) then
        pptp.lua_debug(pptp.INFO, "Old config is not json mode.");
        return;
    end
    --pptp.lua_debug(pptp.INFO, "Old config: %s", file_data);
    local json = cjson.decode(file_data);
    if (json["list"] == nil) then
        json["list"] = {};
    end
    local check = -1;
    local length = table.maxn(json.list);
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == tunnelname) then
            check = i;
            pptp.lua_debug(pptp.INFO, "Disconnect tunnel: %s", tunnelname);
            client_stop_pppd(json["list"][i]);
            ipset_and_route_del(tunnelname);
            check_link_status(tunnelname);
        end
    end
    if (check ~= -1) then
        table.remove(json.list, check)
    end
    return json;
end

local function pptp_client_encrypt_config(config_json)
    local recode;
    local ciphertext;
    if config_json["encType"] == nil or config_json["encType"] == 0 then
        if config_json["password"] ~= nil then
            recode, ciphertext = sd_crypto.lua_sd_crypto_buf_encrypt(config_json["password"],#config_json["password"],'C')
            if (recode ~= 0) then
                pptp.lua_debug(pptp.INFO, "sd_crypto.lua_sd_crypto_buf_encrypt failed recode:" .. recode);
                return
            else
                config_json["password"] = tostring(ciphertext)
            end
        end
        config_json["encType"] = 1;
    end
end

local function save_sd_config(fn_json, file)
    local json = {};
    if (tool.file_exist(file) == true) then
        local file_data = tool.file_read(file)
        if (file_data ~= nil and tool.json_check(file_data) == true) then
            json = cjson.decode(file_data)
        end
    end

    if (json["list"] == nil or json["list"][1]["tunnelname"] == nil) then
        json["list"] = {}
    end
    local check = -1;
    local length = table.maxn(json.list);
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == tunnelname) then
            check = i;
        end
    end
    if (check ~= -1) then
        table.remove(json.list, check)
    end

    local length = table.maxn(json["list"]);
    json["total"] = tostring(length + 1);
    pptp_client_encrypt_config(fn_json);
    table.insert(json.list, fn_json);
    --pptp.lua_debug(pptp.INFO, "Save config: %s", cjson.encode(json));
    tool.file_write(file, cjson.encode(json));
end

function pptp_update(input_data, conf_file)
    local ret;
    pptp.lua_debug(pptp.INFO, "###############################UPDATE###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.INFO, "Input data is not json mode.");
        return;
    end
    --pptp.lua_debug(pptp.INFO, "Input data: %s", input_data);
    local input_json = cjson.decode(input_data);
    local list = {"enable", "remotesubnet", "tunnelname", "lns", "workmode"}
    for i, var in ipairs(list) do
        if (input_json[var] == nil) then
            pptp.lua_debug(pptp.ERROR, "%s is empty.", var);
            return;
        end
    end

    --隧道名称获取
    ret = tunnelname_get(input_json["tunnelname"]);
    if (ret == false) then
        return;
    end

    --PPP链路维护时间间隔获取
    lcp_echo_interval_get(input_json);

    --输入保存,用于路由规则设置
    local INPUT_SAVE = table.concat({CLIENT_DIR, "input_save"});
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        pptp.lua_debug(pptp.INFO, "Input save fail.");
        return;
    end

    --删除旧配置,检查PPP是否断链
    if (tool.file_exist(conf_file) == true) then
        delete_old_config(conf_file);
    end

    --启动pptp客户端
    if (input_json["enable"] == "1") then
        client_start_pppd(input_json);
        pptp_uci:set("pptpd", "client", "pptpd")
        pptp_uci:set("pptpd", "client", "enable", "1");
    else
        pptp_uci:set("pptpd", "client", "pptpd")
        pptp_uci:set("pptpd", "client", "enable", "0");
    end
    pptp_uci:commit("pptpd");

    --写入json配置文件
    save_sd_config(input_json, conf_file)

    pptp.lua_debug(pptp.INFO, "###############################UPDATE END###############################");
end

function pptp_del(input_data, conf_file)
    pptp.lua_debug(pptp.INFO, "###############################DELETE###############################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.INFO, "Input data is not json mode.");
        return;
    end
    --pptp.lua_debug(pptp.INFO, "Input data: %s", input_data);

    --获取参数
    local num = 0;
    local data = cjson.decode(input_data);
    if (data["tunnelname"] ~= nil) then
        num = #data["tunnelname"];
    end
    local file_data = tool.file_read(conf_file)
    local json = cjson.decode(file_data);
    local length = table.maxn(json.list);
    local del_num = {};
    --pptp.lua_debug(pptp.INFO, "file_data: %s", file_data);

    for j = 1, num, 1 do
        --隧道名称获取
        ret = tunnelname_get(data["tunnelname"][j]);
        if (ret == true) then
            del_num[j] = nil
            for i = 1, length, 1 do
                if (json["list"][i]["tunnelname"] == tunnelname) then
                    --删除连接
                    del_num[j] = i;
                    client_stop_pppd(json["list"][i]);
                    ipset_and_route_del(tunnelname);
                    pptp.lua_debug(pptp.INFO, "Disconnect tunnel: %s",  tunnelname);
                    break;
                end
            end

            --删除输入保存
            local cmd = table.concat({"rm -rf ", CLIENT_DIR, " ", log_file});
            pptp.lua_debug(pptp.INFO, "%s", cmd);
            os.execute(cmd);
        end
    end

    --删除json配置文件
    for j = 1, num, 1 do
        if (del_num[j] ~= nil) then
            table.remove(json.list, del_num[j])
        end
    end
    pptp.lua_debug(pptp.INFO, "Save config: %s", cjson.encode(json));
    tool.file_write(conf_file, cjson.encode(json))
    pptp.lua_debug(pptp.INFO, "###############################DELETE END###############################");
end

function pptp_add(input_data, conf_file)
    lcp_echo_interval_get();
    pptp.lua_debug(pptp.INFO, "################################ADD################################");

    --参数校验
    if (input_data == nil or tool.json_check(input_data) == false) then
        pptp.lua_debug(pptp.INFO, "Input data is not json mode.");
        return;
    end
    --pptp.lua_debug(pptp.INFO, "Input data: %s", input_data);
    local input_json = cjson.decode(input_data);
    local list = {"enable", "remotesubnet", "tunnelname", "lns", "workmode"}
    for i, var in ipairs(list) do
        if (input_json[var] == nil) then
            pptp.lua_debug(pptp.ERROR, "%s is empty.", var);
            return;
        end
    end
    --隧道名称获取
    ret = tunnelname_get(input_json["tunnelname"])
    if (ret == false) then
        return;
    end

    --输入保存,用于路由规则设置
    local INPUT_SAVE = table.concat({CLIENT_DIR, "/input_save"});
    ret = tool.file_write(INPUT_SAVE, input_data, "w+")
    if (ret == false) then
        pptp.lua_debug(pptp.INFO, "Input save fail.");
        return;
    end

    --如果隧道名称相同直接返回
    local file_data = tool.file_read(conf_file)
    if (file_data == nil or tool.json_check(file_data) == false) then
        pptp.lua_debug(pptp.INFO, "Old config is not json mode.");
        return;
    end
    local json = cjson.decode(file_data)
    if (json["list"] == nil) then
        json["list"] = {}
    end
    local length = table.maxn(json.list)
    for i = 1, length, 1 do
        if (json["list"][i]["tunnelname"] == tunnelname) then
            pptp.lua_debug(pptp.INFO, "%s is exist.", tunnelname);
            return
        end
    end

    --建立连接
    if (input_json["enable"] == "1") then
        client_start_pppd(input_json);
    end

    --写入json配置文件
    save_sd_config(input_json, conf_file)

    pptp.lua_debug(pptp.INFO, "################################ADD END################################");
end

local function single_instance_check(input_data, lockfile)
    if (tool.file_exist(lockfile) == true) then

        local attr = lfs.attributes(lockfile)
        assert (type(attr) == "table")
        local change_time = tonumber(attr.change);
        local current_time = tonumber(os.time());
        local lifetime = current_time - change_time
        if (lifetime > 30) then
            os.remove(lockfile);
        end
    end

    if (tool.file_exist(lockfile) == true) then
        pptp.lua_debug(pptp.INFO, "Error: There is instance process running");
        tool.file_write(SD_CONFIG_FILE, input_data, "w");
        return false;
    else
        pptp.lua_debug(pptp.INFO, "ok: There no instance process running");
        tool.file_write(lockfile, "running", "w");
        return true;
    end
end

------------------------------------------dev_mode----------------------------------------------------------
function module_default_config_get()
    local default_config = '{"list":[{"enable":"0"}]}'
    return default_config
end

function module_update(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, "\\n") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, ">") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_update] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end

    
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    pptp_update(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        pptp_update(file_data, conf_file);
    end
    os.remove(LOCK_FILE);
end

function module_add(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, "\\n") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, ">") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_add] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    pptp_add(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        pptp_add(file_data, conf_file);
    end
    os.remove(LOCK_FILE);
end

function module_del(input_data, conf_file)
    debug_init();

    if (libc2lua.lua_param_safety_check(input_data) ~= true) then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, "\\n") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    if string.match(input_data, ">") then
        pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data is unsafe")
        if (input_data ~= nil) then
            pptp.lua_debug(pptp.ERROR, "ERROR: [module_del] input_data %s", input_data)
        end
        return "{\"code\":\"-1\",\"msg\":\"input_data is unsafe!\"}"
    end
    
    --单实例检测
    if (single_instance_check(input_data, LOCK_FILE) == false) then
        return;
    end

    pptp_del(input_data, conf_file);
    while(tool.file_exist(SD_CONFIG_FILE) == true) do
        local file_data = tool.file_read(SD_CONFIG_FILE)
        os.remove(SD_CONFIG_FILE);
        pptp_del(file_data, conf_file);
    end
    os.remove(LOCK_FILE);
end

function module_apply()
    pptp.lua_debug(pptp.INFO, "module_apply");
end

function module_set()
    pptp.lua_debug(pptp.INFO, "module_set");
end
