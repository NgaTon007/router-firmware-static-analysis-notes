#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
module("authCertUpload",package.seeall)

local console = require "console"
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"

local libstr = require("utils.string");
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local table_input_err = {rcode = "05500001", rmsg = "param error"}
local table_input_err_2= {rcode = "05500002", rmsg = "certificate or key format error"}
local table_input_err_3= {rcode = "05500003", rmsg = "certificate and key not match"}
local CERT_FILE_DIR = "/etc/cert/auth/"
local CERT_DEFAULT_FILE_DIR = "/etc/cert/auth/default_cert/"
local CERT_JSON_FILE = "/etc/sd_config/single/authCertUpload.json"
local cert_file = "cert.pem"
local key_file= "key.pem"
local cert_md5 = "openssl x509 -noout -modulus -in %s  | openssl md5"
local key_md5 = "openssl %s -noout -modulus -in %s  | openssl md5"
-- ECʹ�������������ƥ����֤
local ecc_cert_md5 = "openssl x509 -noout -pubkey -in %s | openssl pkey -pubin -outform DER | openssl md5"
local ecc_key_md5 = "openssl ec -pubout -in %s | openssl pkey -pubin -outform DER | openssl md5"
local webauth_spt_https_cgi_cmd = "cat /tmp/sd_device/sd_device.json | jq .gateway.webauth_spt_https_cgi | sed 's/\"//g' | xargs echo -n"
local default_config = [[
        {
            "list":[]
        }
      ]]

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "authCertUpload.log", 500, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    elseif ret == "0002" then
        return console.uf_lua_fail(table_input_err_2)
    elseif ret == "0003" then
        return console.uf_lua_fail(table_input_err_3)
    end
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

local function is_use_default_cert(param)
    local cmd = ""
    if (param["list"] ~= nil and #param["list"] == 0) then
        cmd = string.format("cp %s %s >/dev/null 2>&1; cp %s %s >/dev/null 2>&1",
            CERT_DEFAULT_FILE_DIR .. cert_file, CERT_FILE_DIR .. cert_file,
            CERT_DEFAULT_FILE_DIR .. key_file, CERT_FILE_DIR .. key_file)

        os.execute(cmd);
        cmd = string.format("curl --connect-timeout 2 127.0.0.1:2060/ga_reload_https_cert 2>/dev/null > /dev/null")
        os.execute(cmd);
        return true
    else
        return false
    end
end

local function auth_read_para(pem_type, alg_type, file_path)
    local cmd = ""
    if (pem_type == "cert") then
        cmd = string.format(cert_md5, file_path)
    elseif (pem_type == "key") then
        if (alg_type ~= nil) then
            cmd = string.format(key_md5, alg_type, file_path)
        else
            return nil
        end
    end

    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close() 
    return res
end

local function auth_read_para_for_ecc(pem_type, file_path)
    local cmd = ""
    if (pem_type == "cert") then
        cmd = string.format(ecc_cert_md5, file_path)
    elseif (pem_type == "key") then
        cmd = string.format(ecc_key_md5, file_path)
    end

    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close() 
    return res
end

local function checkcomment_safety(param)
    if (type(param) ~= "string" or #param > 64) then
        return false
    end
    if (string.match(param, "\\'`\"$") == nil) then
        return true
    end
    return false
end

local function checkparam_for_string(param)
    if (type(param) ~= "string") then
        return false
    end

    if (string.match(param, "[^%w_]") ~= nil) then
        return false
    end

    return true
end

local function param_check_vaild(param, method)
    if method == "set" then
        if (type(param) ~= "table") then
            return false
        end
        for k, v in pairs(param["list"]) do
            if (v["comment"] ~= nil and v["comment"] ~="" and checkcomment_safety(v["comment"]) == false) then
                return false
            end
            if (v["uuid"] ~= nil and v["uuid"] ~="" and checkparam_for_string(v["uuid"]) == false) then
                return false
            end
            if (v["src"] ~= nil and v["src"] ~="" and checkparam_for_string(v["src"]) == false) then
                return false
            end
            if (v["role"] ~= nil and v["role"] ~="" and checkparam_for_string(v["role"]) == false) then
                return false
            end
        end
        return true
    else 
        if (param["comment"] ~= nil and param["comment"] ~="" and checkcomment_safety(param["comment"]) == false) then
            return false
        end
        if (param["uuid"] ~= nil and param["uuid"] ~="" and checkparam_for_string(param["uuid"]) == false) then
            return false
        end
        if (param["src"] ~= nil and param["src"] ~="" and checkparam_for_string(param["src"]) == false) then
            return false
        end
        if (param["role"] ~= nil and param["role"] ~="" and checkparam_for_string(param["role"]) == false) then
            return false
        end
        return true
    end
end

local function is_x509_private_key(content)
    local start_tag = "-----BEGIN"
    local end_tag = "-----END"

    if (content == nil or content == "") then
        return false
    end
    local start_pos = content:find(start_tag)
    local end_pos = content:find(end_tag, start_pos)

    if start_pos and end_pos then
        local start_tag_end = content:find("\n", start_pos) + 1
        local key_content = content:sub(start_tag_end, end_pos - 1)
        module_debug.lua_debug(module_debug.INFO, "key_content:%s", key_content);
        local key_body = key_content:gsub("[\r\n]", "")
        if (libstr.is_base64(key_body) == true) then
            return true
        else
            return false
        end
    else
        module_debug.lua_debug(module_debug.ERROR, "key tags not found.");
        return false
    end

    return true
end

local function is_x509_certificate(str)
    if (str == nil or string.len(str) == 0) then
        return false
    end

    -- ����X.509֤����������ʽģʽ
    local x509_pattern = [[-----BEGIN CERTIFICATE-----%s(.-)%s-----END CERTIFICATE-----]]

    local is_valid = false
    for certificate_body in string.gmatch(str, x509_pattern) do
        -- ȥ�����з�
        certificate_body = certificate_body:gsub("[\r\n]", "")
        -- ����Ƿ�ΪBase64����
        if libstr.is_base64(certificate_body) then
            is_valid = true
        else
            is_valid = false
            break
        end
    end

    return is_valid
end

local function check_pem_format(param)
    if (type(param) ~= "table") then
        return false
    end

    for k, v in pairs(param["list"]) do
        if (v["role"] == "server" and is_x509_private_key(v["pri"]) == false) then
            return false
        end
        if (not is_x509_certificate(v["cert"])) then
            return false
        end
    end
    return true
end

local function is_cert_key_match(key, cert)
    module_debug.lua_debug(module_debug.INFO, "cert%s", cert);
    file_write(DEBUG_LOG_DIR .. cert_file, cert)
    file_write(DEBUG_LOG_DIR .. key_file, key)
    module_debug.lua_debug(module_debug.INFO, "file_write end");
    local pattern = "-----BEGIN (%u+) PRIVATE KEY-----"
    local algorithm = string.match(key, pattern)
    local cert_md5 = auth_read_para("cert", "", DEBUG_LOG_DIR .. cert_file)
    local key_md5
    if (algorithm == "RSA") then
        key_md5 = auth_read_para("key", "rsa", DEBUG_LOG_DIR .. key_file)
    elseif (algorithm == "EC") then
        cert_md5 = auth_read_para_for_ecc("cert", DEBUG_LOG_DIR .. cert_file)
        key_md5 = auth_read_para_for_ecc("key", DEBUG_LOG_DIR .. key_file)
    elseif (algorithm == "DSA") then
        key_md5 = auth_read_para("key", "dsa", DEBUG_LOG_DIR .. key_file)
    else
        return false
    end
    
    module_debug.lua_debug(module_debug.INFO, "cert_md5:%s, key_md5:%s", cert_md5, key_md5);
    if (cert_md5 ~= key_md5) then
        return false
    end
    return true
end

local function mv_file()
    local cmd = ""
    if (tool.file_exist(CERT_FILE_DIR) == false) then
        local path = "mkdir -p " .. CERT_FILE_DIR .. " >/dev/null 2>&1"
        os.execute(path);
    end

    cmd = string.format("mv -f %s %s >/dev/null 2>&1; mv -f %s %s >/dev/null 2>&1",
        DEBUG_LOG_DIR .. cert_file, CERT_FILE_DIR .. cert_file,
        DEBUG_LOG_DIR .. key_file, CERT_FILE_DIR .. key_file)

    os.execute(cmd);
end

local function update_config(param_tab, conf_tab)
    local found = false
    local conf_pri = ""
    local conf_cert = ""
    for k, v in pairs(conf_tab["list"]) do
        if (v["uuid"] == param_tab["uuid"]) then
            found = true
            conf_pri = v["pri"]
            conf_cert = v["cert"]
            v["comment"] = param_tab["comment"]
            v["src"] = param_tab["src"]
            v["role"] = param_tab["role"]
            if (param_tab["pri"] ~= nil and param_tab["pri"] ~= "") then
                v["pri"] = param_tab["pri"]
            end
            if (param_tab["cert"] ~= nil and param_tab["cert"] ~= "") then
                v["cert"] = param_tab["cert"]
            end
        end
    end
    if (found == true) then
        if (param_tab["src"] == "auth" and param_tab["role"] == "server") then
            if (param_tab["cert"] == nil or param_tab["pri"] == nil) then
                module_debug.lua_debug(module_debug.ERROR, "param error");
                return "0001";
            end
            if (param_tab["cert"] == "" and param_tab["pri"] == "") then
                module_debug.lua_debug(module_debug.INFO, "cert and pri is no change");
                return "0000";
            elseif (param_tab["cert"] ~= "" and param_tab["pri"] ~= "") then
                if (is_x509_private_key(param_tab["pri"]) == false) then
                    module_debug.lua_debug(module_debug.ERROR, "key format error");
                    return "0002";
                end
                if (not is_x509_certificate(param_tab["cert"])) then
                    module_debug.lua_debug(module_debug.ERROR, "certificate format error");
                    return "0002";
                end
                if is_cert_key_match(param_tab["pri"], param_tab["cert"]) == false then
                    module_debug.lua_debug(module_debug.ERROR, "certificate and key not match");
                    return "0003";
                end
            elseif param_tab["pri"] ~= "" and param_tab["cert"] == ""then
                if (is_x509_private_key(param_tab["pri"]) == false) then
                    module_debug.lua_debug(module_debug.ERROR, "key format error");
                    return "0002";
                end
                if is_cert_key_match(param_tab["pri"], conf_cert) == false then
                    module_debug.lua_debug(module_debug.ERROR, "certificate and key not match");
                    return "0003";
                end
            elseif param_tab["pri"] == "" and param_tab["cert"] ~= ""then
                if (not is_x509_certificate(param_tab["cert"]) == false) then
                    module_debug.lua_debug(module_debug.ERROR, "certificate format error");
                    return "0002";
                end
                if is_cert_key_match(conf_pri, param_tab["cert"]) == false then
                    module_debug.lua_debug(module_debug.ERROR, "certificate and key not match");
                    return "0003";
                end
            end
        end
    else
        if (param_tab["src"] == "auth" and param_tab["role"] == "server") then
            if (is_x509_private_key(param_tab["pri"]) == false) then
                module_debug.lua_debug(module_debug.ERROR, "key format error");
                return "0002";
            end
            if (not is_x509_certificate(param_tab["cert"])) then
                module_debug.lua_debug(module_debug.ERROR, "certificate format error");
                return "0002";
            end
            if is_cert_key_match(param_tab["pri"], param_tab["cert"]) == false then
                module_debug.lua_debug(module_debug.ERROR, "certificate and key not match");
                return "0003";
            end
            table.insert(conf_tab["list"], param_tab)
        end
    end

    local config = cjson.encode(conf_tab)
    if (config ~= nil) then
        tool.file_write(CERT_JSON_FILE, config)
    end
    return "0000"
end
----------------------------------------------------------------------------------------------------------------------
function module_default_config_get()

    return default_config
end

function module_set(param)
    debug_init();
    module_debug.lua_debug(module_debug.INFO, "********************Enter authCertUpload_set()********************");
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "authCertUpload_set parameter is nil");
        return check_result("0001");
    end

    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] decode err")
        return check_result("0001");
    end
    if (is_use_default_cert(param_tab) == true) then
        return check_result("0000");
    end
    if (param_check_vaild(param_tab, "set") == false) then
        module_debug.lua_debug(module_debug.ERROR, "authCertUpload_set parameter is unsafe");
        return check_result("0001");
    end
    if (check_pem_format(param_tab) == false) then
        module_debug.lua_debug(module_debug.ERROR, "certificate or key format error");
        return check_result("0002");
    end

    for k, v in pairs(param_tab["list"]) do
        if (v["src"] == "auth" and v["role"] == "server") then
            if (is_cert_key_match(v["pri"], v["cert"]) == false) then
                module_debug.lua_debug(module_debug.ERROR, "certificate and key not match");
                return check_result("0003");
            end
        end
    end

    for k, v in pairs(param_tab["list"]) do
        if (v["src"] == "auth") then
            mv_file()
        end
    end

    local cmd = string.format("curl --connect-timeout 2 127.0.0.1:2060/ga_reload_https_cert 2>/dev/null > /dev/null")
    os.execute(cmd);

    return check_result("0000");
end

function module_update(param)
    debug_init();
    module_debug.lua_debug(module_debug.INFO, "********************Enter authCertUpload_update()********************");
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "authCertUpload_update parameter is nil");
        return check_result("0001");
    end

    local param_tab = cjson.decode(param);
    if (param_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_update] decode err")
        return check_result("0001");
    end

    if (param_check_vaild(param_tab, "update") == false) then
        module_debug.lua_debug(module_debug.ERROR, "authCertUpload_update parameter is unsafe");
        return check_result("0001");
    end

    if (is_use_default_cert(param_tab) == true) then
        file_write(CERT_JSON_FILE, default_config)
        return check_result("0000");
    end

    local config = tool.file_read(CERT_JSON_FILE)
    if (config == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:[module_update] config is nil")
        return check_result("0001");
    end
    local config_tab = cjson.decode(config)
    if (config_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_add] config is nil")
        return check_result("0001");
    end
    local ret = update_config(param_tab, config_tab)
    if ret == "0001" then
        return check_result("0001");
    elseif ret == "0002" then
        return check_result("0002");
    elseif ret == "0003" then
        return check_result("0003");
    end
    
    mv_file()
    
    local cmd = string.format("curl --connect-timeout 2 127.0.0.1:2060/ga_reload_https_cert 2>/dev/null > /dev/null")
    os.execute(cmd);

    return check_result("0000");
end