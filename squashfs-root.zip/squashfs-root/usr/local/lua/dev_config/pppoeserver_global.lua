#!/usr/bin/env lua
--项目名
package.path = "/usr/lib/lua/?.lua;" .. package.path;
package.path = "/usr/lib/lua/ippool/?.lua;" .. package.path;
module("pppoeserver_global", package.seeall);
cjson = require "cjson"
ubus = require "ubus"
tool = require "dev.tools.common"
lib_debug = require "utils.debug"
require "public_module"
require("uci")
dev_config = require "dev_config"
local console = require "console"
local reference = require "ippool_reference"

local modul = "pppoe-server"
local module_name = "pppoeserver_global"
local conf_file = "/etc/config/pppoeserver_global"
local sd_cfg = "/etc/sd_config/single/pppoeserver_global.json"
local def_cfg = "/etc/pppoe-server/default_pppoeserver_global.json"
local product = require("product")
local web_node = product.get_product("capacity.web")
local spt_expire_remind = string.format("cat /tmp/sd_device/sd_device.json|jq .%s.spt_expire_remind | sed 's/\"//g'", web_node)
local spt_pppoe_radius = string.format("cat /tmp/sd_device/sd_device.json|jq .%s.pppoeRadius | sed 's/\"//g'", web_node)
local table_input_err = {rcode = "05590001", rmsg = "param error"}
--参数安全校验 23-04-12：jzh
local lib_param = require("libc2lua")

local DEFAULT_MAX_NOREPLY_LCP = "10"
local vlan_ref_add_cmd = "dev_config add -m vlanRef '{\"vlanid\":\"%s\",\"app\":\"pppoeserver\"}' &"
local vlan_ref_del_cmd = "dev_config del -m vlanRef '{\"vlanid\":\"%s\",\"app\":\"pppoeserver\"}' &"
local ippool_param = '{"ippool_name": "pppoe_pool","module":"pppoe-server"}'
local ppp_radius_add_cmd = "dev_config add -m pppRadius '{\"client\": [\"PPPOE\"]}' >/dev/null 2>&1"
local ppp_radius_del_cmd = "dev_config del -m pppRadius '{\"client\": [\"PPPOE\"]}' >/dev/null 2>&1"

lib_debug.debug_init("/tmp/pppoe-server/debug/", "pppoeserver_global.log", 300, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

local double_tag = require("utils.device_capability")
local spt_intf_hl = double_tag.check_dev_bridge_vlan_ability()
if spt_intf_hl ~= 1 then
    intf_hl = require "netmng.interface"
end

----------枚举初始化---------
function CreatEnumTable(tb, index)  
    local enumtb = {} 
    local enumindex = index or 0 
    for i, v in ipairs(tb) do 
        enumtb[v] = enumindex + i 
    end 
    return enumtb
end 
----------lua通用错误码-----------------
local g_err_code = {"ERR_PARAM", "ERR_FILE_WRITE", "ERR_FILE_NOT_EXIST"}
local g_err_code = CreatEnumTable(g_err_code, 200)
--return output(1, g_err_code["ERR_PARAM"], "rate_limit_set failed:param error")

function module_default_config_get()
    os.execute("cp "..def_cfg.." "..sd_cfg);
    return file_read(sd_cfg)
end
function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w")
    file:write(data)
    file:close()
end

--参数检查
function param_check(data)
    --[[for i,w in ipairs(data.data) do
        if (w.lpid == nil or w.enable == nil) then
            return -1
        end
    end]]--
    return 0
end

function conf_del(data, json)
    local length = 0
    if (json.data ~= nil) then
        length = #json.data
    end
    while ( 0 < length ) do    
        if (json.data[length].lpid == data) then
            break
        end
        length = length - 1
    end
    table.remove(json.data, length)
    return 0
end

function conf_add(data, json)
    table.insert (json.data, data)
    return 0
end

--ret(uint)表示是否返回结果给web,0表示不返回，0表示返回给web。
--code(uint):表示你返回给web的错误码；msg(string)：错误信息
function output(ret, code, msg)
    result = {}
    result["code"] = ret
    result["err"] = code..";"..msg
    return cjson.encode(result)
end

-- 2024.1.19 zyh 统一配置框架统一要求返回值 
function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function is_spt_capacity(cmd)
    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close()
    res = string.gsub(res, "\n", "")
    if res == "1" then
        return true
    else
        return false
    end
end

function module_get()

end

function uci_update(data)  
    local uci_r = uci.cursor()
    
	if (uci_r:get(module_name, "global", "state") == "1") then		
		-- stop pppoeserver 
		--os.execute("/etc/init.d/zpppoe-server stop")
	end

    --保存uci配置
    if (data.state ~= nil) then
        uci_r:set(module_name, "global", "state", data.state)
        lib_debug.lua_debug(lib_debug.DEBUG, "state:%s\n", data.state)
    end
    if (data.monitor_port ~= nil) then
        uci_r:set(module_name, "global", "monitor_port", data.monitor_port)
        lib_debug.lua_debug(lib_debug.DEBUG, "monitor_port:%s\n", data.monitor_port)
    end
    if (data.force_state ~= nil) then
        uci_r:set(module_name, "global", "force_state", data.force_state)
        lib_debug.lua_debug(lib_debug.DEBUG, "force_state:%s\n", data.force_state)
    end
    if (data.first_dns_server ~= nil) then
        uci_r:set(module_name, "global", "first_dns_server", data.first_dns_server)
        lib_debug.lua_debug(lib_debug.DEBUG, "first_dns_server:%s\n", data.first_dns_server)
    end
    if (data.second_dns_server ~= nil) then
        uci_r:set(module_name, "global", "second_dns_server", data.second_dns_server)
        lib_debug.lua_debug(lib_debug.DEBUG, "second_dns_server:%s\n", data.second_dns_server)
    end
    if (data.max_sessions ~= nil) then
        uci_r:set(module_name, "global", "max_sessions", data.max_sessions)
        lib_debug.lua_debug(lib_debug.DEBUG, "max_sessions:%s\n", data.max_sessions)
    end
    if (data.max_noreply_lcp ~= nil) then
        uci_r:set(module_name, "global", "max_noreply_lcp", data.max_noreply_lcp)
        lib_debug.lua_debug(lib_debug.DEBUG, "max_noreply_lcp:%s\n", data.max_noreply_lcp)
    end
    if (data.idle_time ~= nil) then
        uci_r:set(module_name, "global", "idle_time", data.idle_time)
        lib_debug.lua_debug(lib_debug.DEBUG, "idle_time:%s\n", data.idle_time)
    end
    if (data.pap ~= nil) then
        uci_r:set(module_name, "global", "pap", data.pap)
        lib_debug.lua_debug(lib_debug.DEBUG, "pap:%s\n", data.pap)
    end
    if (data.chap ~= nil) then
        uci_r:set(module_name, "global", "chap", data.chap)
        lib_debug.lua_debug(lib_debug.DEBUG, "chap:%s\n", data.chap)
    end
    if (data.mschap ~= nil) then
        uci_r:set(module_name, "global", "mschap", data.mschap)
        lib_debug.lua_debug(lib_debug.DEBUG, "mschap:%s\n", data.mschap)
    end
    if (data.mschapv2 ~= nil) then
        uci_r:set(module_name, "global", "mschapv2", data.mschapv2)
        lib_debug.lua_debug(lib_debug.DEBUG, "mschapv2:%s\n", data.mschapv2)
    end
    if (data.localip ~= nil) then
        uci_r:set(module_name, "global", "localip", data.localip)
        lib_debug.lua_debug(lib_debug.DEBUG, "localip:%s\n", data.localip)
    end
    if (data.remind_enable ~= nil) then
        uci_r:set(module_name, "global", "remind_enable", data.remind_enable)
        lib_debug.lua_debug(lib_debug.DEBUG, "remind_enable:%s\n", data.remind_enable)
    end
    if (data.expired_user_enable ~= nil) then
        uci_r:set(module_name, "global", "expired_user_enable", data.expired_user_enable)
        lib_debug.lua_debug(lib_debug.DEBUG, "expired_user_enable:%s\n", data.expired_user_enable)
    end
    if (is_spt_capacity(spt_pppoe_radius) == true) then
        if (data.radius_check ~= nil) then
            uci_r:set(module_name, "global", "radius_check", data.radius_check)
            lib_debug.lua_debug(lib_debug.DEBUG, "radius_check:%s\n", data.radius_check)
        end
        if (data.secret_check ~= nil) then
            uci_r:set(module_name, "global", "secret_check", data.secret_check)
            lib_debug.lua_debug(lib_debug.DEBUG, "secret_check:%s\n", data.secret_check)
        end
    end
    uci_r:commit(module_name)
	uci_r:revert(module_name)
    
    if (uci_r:get(module_name, "global", "state") == "1")then
		--os.execute("/etc/init.d/zpppoe-server start")
	end
end

function json_update(data, old_json)
    if (data.state ~= nil) then
        old_json.state = data.state
    end
    if (data.monitor_port ~= nil) then
        old_json.monitor_port = data.monitor_port
    end
    if (data.force_state ~= nil) then
        old_json.force_state = data.force_state
    end
    if (data.first_dns_server ~= nil) then
        old_json.first_dns_server = data.first_dns_server
    end
    if (data.second_dns_server ~= nil) then
        old_json.second_dns_server = data.second_dns_server
    end
    if (data.max_sessions ~= nil) then
        old_json.max_sessions = data.max_sessions
    end
    if (data.max_noreply_lcp ~= nil) then
        old_json.max_noreply_lcp = data.max_noreply_lcp
    end
    if (data.idle_time ~= nil) then
        old_json.idle_time = data.idle_time
    end
    if (data.pap ~= nil) then
        old_json.pap = data.pap
    end
    if (data.chap ~= nil) then
        old_json.chap = data.chap
    end
    if (data.mschap ~= nil) then
        old_json.mschap = data.mschap
    end
    if (data.mschapv2 ~= nil) then
        old_json.mschapv2 = data.mschapv2
    end
    if (data.localip ~= nil) then
        old_json.localip = data.localip
    end
    if (data.remind_enable ~= nil) then
        old_json.remind_enable = data.remind_enable
    end
    if (data.expired_user_enable ~= nil) then
        old_json.expired_user_enable = data.expired_user_enable
    end

    if (is_spt_capacity(spt_pppoe_radius) == true) then
        if (data.radius_check ~= nil) then
            old_json.radius_check = data.radius_check
        end
        if (data.secret_check ~= nil) then
            old_json.secret_check = data.secret_check
        end
    end
    file_write(sd_cfg, cjson.encode(old_json))
    
end

local function update_ippool_reference(old_state, state)
    lib_debug.lua_debug(lib_debug.INFO, "old_state:%s, state:%s\n", old_state, state)
    if (old_state == "1" and state == "0") then
        reference.ippool_reference_del(ippool_param)
    elseif (old_state == "0" and state == "1") then
        reference.ippool_reference_add(ippool_param)
    end
end

function module_update(param)  
    local data = cjson.decode(param)
    local uci_r = uci.cursor()
    local old_data = file_read(sd_cfg)
    local old_json = cjson.decode(old_data)
    local monitor_old = old_json.monitor_port
    local state_old = old_json.state
    local monitor_new = data.monitor_port
    local cmd
    local remind_enable = "0"
    
    --参数安全校验 23-04-12：jzh
    if (param ~= nil and lib_param.lua_param_safety_check(param) ~= true) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param is nil")
        end
        return check_result("0001")
    end

    if string.match(param, "\\n") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param %s", param)
        end
        return check_result("0001")
    end

    if string.match(param, "\\t") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param %s", param)
        end
        return check_result("0001")
    end

    if string.match(param, ">") then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param1 is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param %s", param)
        end
        return check_result("0001")
    end

    -- 参数空格校验
    if (data.first_dns_server ~= nil and string.match(data.first_dns_server, "%s")) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] first_dns_server contains space")
        return check_result("0001")
    end
    
    if (data.second_dns_server ~= nil and string.match(data.second_dns_server, "%s")) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] second_dns_server contains space")
        return check_result("0001")
    end
    
    if (data.localip ~= nil and string.match(data.localip, "%s")) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] localip contains space")
        return check_result("0001")
    end
    
    if (data.max_noreply_lcp ~= nil and string.match(data.max_noreply_lcp, "%s")) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] max_noreply_lcp contains space")
        return check_result("0001")
    end

    --vlan 检测
    if (monitor_old == nil or monitor_old == "233"  or monitor_old == "") then
        if (monitor_new ~= nil and monitor_new ~= "233"  and monitor_new ~= "") then
            lib_debug.lua_debug(lib_debug.DEBUG, "vlan_ref need add :%s \n", monitor_new)
            if spt_intf_hl == 1 then
                dev_config.fetch("add", "vlanRef", cjson.encode({vlanid=monitor_new, app="pppoeserver"}), "1")
            else
                intf_hl.vlan_reference_save(monitor_new, "pppoeserver", "add")
            end
        end
    else
        if (monitor_new == nil or monitor_new == "233"  or monitor_new == "") then
            lib_debug.lua_debug(lib_debug.DEBUG, "vlan_ref need del :%s\n", monitor_old)
            if spt_intf_hl == 1 then
                dev_config.fetch("del", "vlanRef", cjson.encode({vlanid=monitor_old, app="pppoeserver"}), "1")
            else
                intf_hl.vlan_reference_save(monitor_old, "pppoeserver", "del")
            end
        elseif (monitor_new ~= nil and monitor_new ~= "233" and monitor_old ~= monitor_new) then
            lib_debug.lua_debug(lib_debug.DEBUG, "vlan_ref need del :%s\n", monitor_old)
            if spt_intf_hl == 1 then
                dev_config.fetch("del", "vlanRef", cjson.encode({vlanid=monitor_old, app="pppoeserver"}), "1")
            else
                intf_hl.vlan_reference_save(monitor_old, "pppoeserver", "del")
            end
            lib_debug.lua_debug(lib_debug.DEBUG, "vlan_ref need add :%s\n", monitor_new)
            if spt_intf_hl == 1 then
                dev_config.fetch("add", "vlanRef", cjson.encode({vlanid=monitor_new, app="pppoeserver"}), "1")
            else
                intf_hl.vlan_reference_save(monitor_new, "pppoeserver", "add")
            end
        end
    end
    
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update start\n")
    lib_debug.lua_debug(lib_debug.DEBUG, "module_update:%s\n", param)
 
    -- WEB可以不填max_noreply_lcp 就下发，这边做兼容
    if (data.max_noreply_lcp == nil or data.max_noreply_lcp == "") then
        data.max_noreply_lcp = DEFAULT_MAX_NOREPLY_LCP
    end

    if data.remind_enable == "1" then
        remind_enable = "1"
    end
    if (data.state == "1") then
		os.execute("/etc/init.d/zpppoe-server stop")
        uci_update(data)
        json_update(data, old_json)
        if (is_spt_capacity(spt_expire_remind) == true) then
            cmd = string.format("/usr/bin/lua /usr/sbin/web/guest_auth_set_pppoe_remind.lua \"1\" %s", remind_enable)
            os.execute(cmd)
        end
		os.execute("/etc/init.d/zpppoe-server start")
        -- 2025 R380 pppoe-server关联ippool_reference 
        update_ippool_reference(state_old, data.state)
    else
		os.execute("/etc/init.d/zpppoe-server stop")
        uci_update(data)
        json_update(data, old_json)
        if (is_spt_capacity(spt_expire_remind) == true) then
            cmd = string.format("/usr/bin/lua /usr/sbin/web/guest_auth_set_pppoe_remind.lua \"0\" %s", remind_enable)
            os.execute(cmd)
        end
        update_ippool_reference(state_old, data.state)
	end

    if (is_spt_capacity(spt_pppoe_radius) == true) then
        if (data.radius_check ~= nil) then
            if (data.state == "1" and data.radius_check == "1" ) then
                os.execute(ppp_radius_add_cmd)
            else
                os.execute(ppp_radius_del_cmd)
            end
        end
    end

    lib_debug.lua_debug(lib_debug.DEBUG, "module_update end\n")
    
    
    
    return check_result("0000")
end

function module_apply(param, cmd)

end

function module_set(param)
    if (param ~= nil and lib_param.lua_param_safety_check(param) ~= true) then
        lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param is unsafe")
        if (param ~= nil) then
            lib_debug.lua_debug(lib_debug.ERROR, "ERROR: [module_update] param %s", param)
        end
        return check_result("0001")
    end
end