#!/bin/sh

ubus call apmgr lnid

