#!/bin/sh

LOCK_DIR="/tmp/del_enter"
# 确保目录存在
mkdir -p "$LOCK_DIR"
del_enter_lock="$LOCK_DIR/del_enter.lock"
log_file="$LOCK_DIR/del_enter.log"
# 指定要遍历的文件夹路径
global_file="/etc/sd_config/global"
single_file="/etc/sd_config/single"

del_carriage_enter() {
    local config_file="$1"
    # 遍历文件夹下的所有文件
    for file in "$config_file"/*.json;
    do
        # 检查文件是否存在
        (
            flock -x 90
            if [ -f "$file" ]; then
                # bugid：1189648，加日志查问题
                file_size=$(ls -l $file | awk '{print $5}')
                if [ $file_size -eq 0 ]; then
                    echo "=====del before $file is 0=====" >> $log_file
                fi

                data=$(cat "$file")
                echo -n "$data" > $file
                local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
                echo -e "${cur_time} $file" >> $log_file

                file_size=$(ls -l $file | awk '{print $5}')
                if [ $file_size -eq 0 ]; then
                    echo "=====del after $file is 0=====" >> $log_file
                fi
            fi
            flock -u 90
        )90>"$del_enter_lock"
    done
}

del_carriage_enter "$global_file"
del_carriage_enter "$single_file"
