#!/bin/sh
. /usr/share/libubox/jshn.sh
. /lib/functions.sh

start_instance () {
	local cfg="$1"
	config_get _name "$cfg" name
    #字符替换，"c8_5b_76_93_ec_60" ==> "c8:5b:76:93:ec:60"
    user=${cfg//_/:}
	#echo " 2 $user:$_name"
    
    json_add_object
    json_add_string 'mac' $user
    json_add_string 'name' $_name
    json_close_object
    
    uci delete user_list.$cfg
}

#echo "******** start********"

json_init
json_add_array 'list';

config_load  user_list
config_foreach start_instance user 

json_close_array;
#将uci数据转化成json数据后，写入到/etc/sd_config/single/user_list_note.json配置文件
json_dump > /etc/sd_config/single/user_list_note.json

uci commit user_list
#echo "******** end********"
