#! /usr/bin/env lua

package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"

-- 模块加载保护
local function safe_require(module_name)
    local ok, mod = pcall(require, module_name)
    if not ok then
        return nil
    end
    return mod
end

local lib_flowctrl = safe_require("flowctrl.flowctrl_app")
local lib_app_route = safe_require("app_route.app_route_pub")
local lib_policy_route = safe_require("policy_route.policy_route_pub")
local lib_policy_routev6 = safe_require("policy_route.policy_routev6_pub")

local DEBUG_LOG_DIR = "/tmp/intf_group/"
local INTFGROUP_CONFIG_FILE = "/etc/sd_config/single/intfGroupMgr.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    tool.exec(path)
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "intf_group_compat.log", 100, module_debug.DEBUG, "1")
end

-- 更新接口组
function update_intf_groups()
    debug_init()

    local fp = io.open(INTFGROUP_CONFIG_FILE, "r")
    if not fp then
        module_debug.lua_debug(module_debug.ERROR, "open " .. INTFGROUP_CONFIG_FILE .. " failed")
        return
    end
    local content = fp:read("*a")
    fp:close()

    local ok, config = pcall(cjson.decode, content)
    if not ok or not config or type(config.list) ~= "table" then
        module_debug.lua_debug(module_debug.ERROR, "decode json failed or invalid structure")
        return
    end

    local uuids = {}
    for _, item in ipairs(config.list) do
        if item.uuid then
            table.insert(uuids, item.uuid)
        end
    end

    if #uuids == 0 then
        return
    end

    -- 调用校验函数，获取引用状态 (检查函数是否存在)
    -- 返回格式示例: {"uuid1":"0", "uuid2":"1", ...}
    local fc_udp_res = {}
    if lib_flowctrl and lib_flowctrl.fc_check_intf_grp_uuids then
        fc_udp_res = lib_flowctrl.fc_check_intf_grp_uuids(uuids) or {}
    end

    local fc_dscp_res = {}
    if lib_flowctrl and lib_flowctrl.fc_dscp_check_intf_grp_uuids then
        fc_dscp_res = lib_flowctrl.fc_dscp_check_intf_grp_uuids(uuids) or {}
    end

    local app_route_res = {}
    if lib_app_route and lib_app_route.check_del_uuids then
        app_route_res = lib_app_route.check_del_uuids(uuids) or {}
    end

    local policy_route_res = {}
    if lib_policy_route and lib_policy_route.pbr_check_intf_grp_uuids then
        policy_route_res = lib_policy_route.pbr_check_intf_grp_uuids(uuids) or {}
    end

    local policy_routev6_res = {}
    if lib_policy_routev6 and lib_policy_routev6.pbr6_check_intf_grp_uuids then
        policy_routev6_res = lib_policy_routev6.pbr6_check_intf_grp_uuids(uuids) or {}
    end

    local new_list = {}
    local deleted_uuids = {}
    local has_deleted_groups = false
    local current_ts = tostring(os.time())

    for _, item in ipairs(config.list) do
        local uuid = item.uuid
        -- 只要有一个模块返回"1"（有引用），或者类型为 user (用户手动创建)，就保留
        local is_referenced = (app_route_res[uuid] == "1") or
                              (fc_udp_res[uuid] == "1") or
                              (fc_dscp_res[uuid] == "1") or
                              (policy_route_res[uuid] == "1") or
                              (policy_routev6_res[uuid] == "1")

        if is_referenced or item.type == "user" then
            table.insert(new_list, item)
        else
            table.insert(deleted_uuids, tostring(uuid))
            has_deleted_groups = true
        end
    end

    if has_deleted_groups then
        module_debug.lua_debug(module_debug.INFO, "delete unused intf_groups: " .. table.concat(deleted_uuids, ", "))

        config.list = new_list
        -- 更新时间戳
        config.configId = current_ts
        config.configTime = current_ts
        config.currentTime = current_ts

        local new_content = cjson.encode(config)
        local out = io.open(INTFGROUP_CONFIG_FILE, "w")
        if out then
            out:write(new_content)
            out:close()
            module_debug.lua_debug(module_debug.INFO, INTFGROUP_CONFIG_FILE .. " updated at " .. current_ts)
        else
            module_debug.lua_debug(module_debug.ERROR, "write " .. INTFGROUP_CONFIG_FILE .. " failed at " .. current_ts)
        end
    end
end

update_intf_groups()
