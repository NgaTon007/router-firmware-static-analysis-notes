#! /usr/bin/env lua

module_name = "nfpp"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

uci = require("luci.model.uci")
cjson_safe = require "cjson.safe"
dkjson = require "dkjson"
module_debug = require "utils.debug"
dev_config = require "dev_config"
x = uci.cursor()

nfpp_config="/etc/sd_config/single/nfpp.json"
firewall_extern_config="/etc/sd_config/single/firewall_extern.json"
defValueCfg = "/usr/lib/app_auth/app_auth.cfg"

----------debug init---------------
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")

-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end


local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = dkjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)
            res = file_write(path, config_str)
            if (res == -1) then
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end
    
    return 0
end

function update_config_by_firewall(content)
    local nfpp_content = file_to_json(nfpp_config)
    if (nfpp_content == nil) then
        dev_config.fetch("get", "nfpp", "", 1)
        nfpp_content = file_to_json(nfpp_config)
        if (nfpp_content == nil) then
            return 
        end
    end
    
    local idx
    for config_k,config_v in pairs(nfpp_content["list"]) do
        if (config_v["zone_name"] == "lan") then
            idx = config_k
            break
        end 
    end
    
    if (idx == nil) then
        return
    end
    
    local firewall_change = 0
    if (content["ipProtCheck"] == "true") then
        nfpp_content["list"][idx]["malformed_pkt"]["icmp_check"]["enable"] = "1"
        nfpp_content["list"][idx]["malformed_pkt"]["ip_check"]["enable"] = "1"
        nfpp_content["list"][idx]["defend_ddos"]["icmp_flood"]["enable"] = "1"
        nfpp_content["list"][idx]["defend_ddos"]["udp_flood"]["enable"] = "1"
        content["ipProtCheck"] = "false"
        firewall_change = 1
    end
    
    local icmpv6_forbit = {}
    local msg_type = nfpp_content["list"][idx]["local_pkt_send"]["icmpv6_forbit"]["msg_type"]
    local nfpp_icmpv6_forbit = nfpp_content["list"][idx]["local_pkt_send"]["icmpv6_forbit"]
    for ipv6_k,ipv6_v in pairs(msg_type) do
        icmpv6_forbit[ipv6_v["type"]] = ipv6_k
    end
    
    for firewall_k,firewall_v in pairs(content["icmpv6Forbit"]) do
        if (icmpv6_forbit[firewall_v] ~= nil) then
            id = icmpv6_forbit[firewall_v]
            msg_type[id]["enable"] = "1"
            nfpp_icmpv6_forbit["enable"] = "1"
            firewall_change = 1
        end
    end
    
    if (firewall_change == 1 ) then
        content["icmpv6Forbit"] = {}
    
        ret = json_write_to_file(nfpp_config, nfpp_content)
        if (ret == -1) then
            return
        end

        ret = json_write_to_file(firewall_extern_config, content)
        if (ret == -1) then
            return
        end
        os.execute("cp -r /rom/etc/config/firewall /etc/config/firewall")
    end
end

local function syn_flood(node, defValue)
    local value = 500

    if (defValue ~= nil) then
        if (defValue * 5 > 500) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "25") then
            node["limit_rate"] = tostring(value)
        end
    end
end

local function udp_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 5 > 2000) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "2000") then
            node["limit_rate"] = tostring(value)
        end
    end
end

local function arp_flood(node, defValue)
    local value = 300

    if (defValue ~= nil) then
        if (defValue * 2 > 300) then
            value = defValue * 2
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "50") then
            node["limit_rate"] = tostring(value)
        end
    end
end

local function icmp_flood(node, defValue)
    local value = 300

    if (defValue ~= nil) then
        if (defValue * 2 > 300) then
            value = defValue * 2
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "250") then
            node["limit_rate"] = tostring(value)
        end
    end
end

local function tcp_other_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 10 > 2000) then
            value = defValue * 10
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "2000") then
            node["limit_rate"] = tostring(value)
        end
    end
end

local function other_flood(node, defValue)
    local value = 2000

    if (defValue ~= nil) then
        if (defValue * 5 > 2000) then
            value = defValue * 5
        end
    end

    if (node["limit_rate"] ~= nil) then
        if (node["limit_rate"] == "2000") then
            node["limit_rate"] = tostring(value)
        end
    end
end

function update_def_config(content)
    local idx, defValue
    
    if (content["flag"] ~= nil and content["flag"] == "1") then
        return
    end
    
    for config_k,config_v in pairs(content["list"]) do
        if (config_v["zone_name"] == "lan") then
            idx = config_k
            break
        end 
    end
    
    if (idx == nil) then
        return
    end
    
    if (content["list"][idx]["defend_ddos"] == nil) then
        return 
    end
    
    ret = file_exist(defValueCfg)
    if (ret ~= nil) then
        str = file_read(defValueCfg)
        if (str ~= nil) then
            defValue = tonumber(str)
        end
    end

    if (defValue ~= nil) then
        if (content["list"][idx]["defend_ddos"]["syn_flood"] ~= nil) then
            syn_flood(content["list"][idx]["defend_ddos"]["syn_flood"], defValue)
        end 
    
        if (content["list"][idx]["defend_ddos"]["udp_flood"] ~= nil) then
            udp_flood(content["list"][idx]["defend_ddos"]["udp_flood"], defValue)
        end 
    
        if (content["list"][idx]["defend_ddos"]["arp_flood"] ~= nil) then
            arp_flood(content["list"][idx]["defend_ddos"]["arp_flood"], defValue)
        end 
 
        if (content["list"][idx]["defend_ddos"]["icmp_flood"] ~= nil) then
            icmp_flood(content["list"][idx]["defend_ddos"]["icmp_flood"], defValue)
        end  

        if (content["list"][idx]["defend_ddos"]["tcp_other_flood"] ~= nil) then
            tcp_other_flood(content["list"][idx]["defend_ddos"]["tcp_other_flood"], defValue)
        end 
 
        if (content["list"][idx]["defend_ddos"]["other_flood"] ~= nil) then
            other_flood(content["list"][idx]["defend_ddos"]["other_flood"], defValue)
        end 
    end

    if (content["list"][idx]["defend_ddos"]["tcp_other_flood"] == nil) then
        content["list"][idx]["defend_ddos"]["tcp_other_flood"] = {}
        content["list"][idx]["defend_ddos"]["tcp_other_flood"]["enable"] = "0"
        content["list"][idx]["defend_ddos"]["tcp_other_flood"]["limit_rate"] = "2000"
    end 

    if (content["list"][idx]["defend_ddos"]["other_flood"] == nil) then
        content["list"][idx]["defend_ddos"]["other_flood"] = {}
        content["list"][idx]["defend_ddos"]["other_flood"]["enable"] = "0"
        content["list"][idx]["defend_ddos"]["other_flood"]["limit_rate"] = "2000"
    end

    content["flag"] = "1"
    ret = json_write_to_file(nfpp_config, content)
    if (ret == -1) then
        return
    end
    
    content["configId"] = nil
    content["currentTime"] = nil
    content["configTime"] = nil
    
    cmdstr = cjson_safe.encode(content)
    if (cmdstr ~= nil) then
        dev_config.fetch("update","nfpp", cmdstr, 1)
        return 0
    end
end

function main()
    local ret = file_exist(nfpp_config)
    if (ret == false) then
        enable = x:get("nfpp", "nfpp_bridge", "enable")
        if (enable == "1") then
            os.execute("cp /rom/etc/config/nfpp /etc/config/nfpp 2>/dev/null")
            os.execute("/etc/init.d/nfpp restart")
        end
        
        dev_config.fetch("get","nfpp", "", 1)
    end

    ret = file_exist(firewall_extern_config)
    if (ret ~= nil) then
        content = file_to_json(firewall_extern_config)
        if (content ~= nil) then
            update_config_by_firewall(content)
        end
    end
    
    local nfpp_content = file_to_json(nfpp_config)
    if (nfpp_content ~= nil) then
        update_def_config(nfpp_content)
    end
    
end

main()
