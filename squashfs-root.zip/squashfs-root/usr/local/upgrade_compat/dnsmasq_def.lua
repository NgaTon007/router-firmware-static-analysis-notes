#! /usr/bin/env lua

package.path = "/usr/lib/lua/?.lua;" .. package.path
uci = require("luci.model.uci")
cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"
DHCP_CAP = "/tmp/sd_device/dhcpcap.json"
DEV_CAP = "/tmp/sd_device/sd_device.json"
NETWORK_JSON = "/etc/sd_config/single/network.json"
bit_hl = require "bit"

flag = 0
x = uci.cursor()

module_debug.debug_init("/tmp/dhcp/", "def_dhcp.log", 100, module_debug.DEBUG, "1")

-- read the exist file
-- @path: File path
-- @return file content, if the action success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- check file exist
-- @path: File path
-- @return 0, if the file exist; otherwise return -1.
local function file_exist(path)
    local f = io.open(path, "rb");
    if (f) then
        f:close()
        return 0
    end

    return -1
end

-- read the exist file
-- @path: File path
-- @return 0,content_json if the action success; otherwise return -1.
local function read_file_for_json(path)
    local content, content_json

    if (type(path) ~= "string") then
        return -1
    end

    if (file_exist(path) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] isn't exist.", path)
        return -1
    end

    content = file_read(path)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] doesn't read.", path)
        return -1
    end

    content_json = cjson_safe.decode(content)
    if (content_json == nil or type(content_json) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] isn't json.", path)
        return -1
    end

    return 0, content_json
end

-- the dhcp interface which receive dhcp message check param
local function dhcp_enable_check_param(section)
    local content_json
    local interface = section["interface"]
    local leasetime = section["leasetime"]
    local start = section["start"]
    local limit = section["limit"]
    local force = section["force"]
    local ignore = section["ignore"]
    
    if (interface == nil  or leasetime == nil or start == nil or limit == nil or force == nil or ignore == nil) then
        content_json = cjson_safe.encode(section)
        if (content_json ~= nil and type(content_json) == "string") then
            module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
        end
        return -1
    end

    if (type(interface) ~= "string" or type(leasetime) ~= "string" or type(start) ~= "string" 
        or type(limit) ~= "string" or type(force) ~= "string" or type(ignore) ~= "string") then
        content_json = cjson_safe.encode(section)
        if (content_json ~= nil and type(content_json) == "string") then
            module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
        end
        return -1
    end

    return 0
end

-- the dhcp interface which reject dhcp message check param
local function dhcp_disable_check_param(section)
    local interface = section["interface"]
    local ignore = section["ignore"]

    if (interface == nil or ignore == nil) then
        content_json = cjson_safe.encode(section)
        if (content_json ~= nil and type(content_json) == "string") then
            module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
        end
        return -1
    end

    if (type(interface) ~= "string" or type(ignore) ~= "string") then
        content_json = cjson_safe.encode(section)
        if (content_json ~= nil and type(content_json) == "string") then
            module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
        end
        return -1
    end

    return 0
end

-- the dhcp interface which force enable check param
local function dhcp_force_enable_check_param(section)
    local content_json
    local interface = section["interface"]
    local leasetime = section["leasetime"]
    local start = section["start"]
    local limit = section["limit"]
    local force = section["force"]
    local ignore = section["ignore"]
    local dhcpv6 = section["dhcpv6"]
    local ra = section["ra"]
    local ra_management = section["ra_management"]
    local leasetime6 = section["leasetime6"]

    if (interface == nil or type(interface) ~= "string" or ignore == nil or type(ignore) ~= "string") then
        content_json = cjson_safe.encode(section)
        if (content_json ~= nil and type(content_json) == "string") then
            module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
        end
        return -1
    end

    if (ignore == "0") then
        if (leasetime == nil or start == nil or limit == nil or force == nil or 
            dhcpv6 == nil or ra == nil or ra_management == nil or leasetime6 == nil) then
            content_json = cjson_safe.encode(section)
            if (content_json ~= nil and type(content_json) == "string") then
                module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
            end
            return -1
        end

        if (type(leasetime) ~= "string" or type(start) ~= "string" 
            or type(limit) ~= "string" or type(force) ~= "string" or 
            type(dhcpv6) ~= "string" or type(ra) ~= "string" or type(ra_management) ~= "string" or 
            type(leasetime6) ~= "string") then
            content_json = cjson_safe.encode(section)
            if (content_json ~= nil and type(content_json) == "string") then
                module_debug.lua_debug(module_debug.ERROR, "the section [%s] is error.", content_json)
            end
            return -1
        end
    end

    return 0
end

-- set the dhcp interface receive the dhcp message
local function uci_set_dhcp_enable(section)
    local interface = section["interface"]
    local leasetime = section["leasetime"]
    local start = section["start"]
    local limit = section["limit"]
    local force = section["force"]
    local ignore = section["ignore"]
    
    if (dhcp_enable_check_param(section) == 0) then
        flag = 1
        x:set("dhcp", interface, "dhcp")
        x:set("dhcp", interface, "interface", interface)
        x:set("dhcp", interface, "start", start)
        x:set("dhcp", interface, "limit", limit)
        x:set("dhcp", interface, "leasetime", leasetime)
        x:set("dhcp", interface, "force", force)
        x:set("dhcp", interface, "ignore", ignore)
    end
end

-- set the dhcp interface reject the dhcp message
local function uci_set_dhcp_disable(section)
    local interface = section["interface"]
    local ignore = section["ignore"]
    
    if (dhcp_disable_check_param(section) == 0) then
        flag = 1
        x:set("dhcp", interface, "dhcp")
        x:set("dhcp", interface, "interface", interface)
        x:set("dhcp", interface, "ignore", ignore)
    end
end

local function uci_set_dhcp_enable_force(section)
    local interface = section["interface"]
    local leasetime = section["leasetime"]
    local start = section["start"]
    local limit = section["limit"]
    local force = section["force"]
    local ignore = section["ignore"]
    local dhcpv6 = section["dhcpv6"]
    local ra = section["ra"]
    local ra_management = section["ra_management"]
    local leasetime6 = section["leasetime6"]
    
    if (dhcp_force_enable_check_param(section) == 0) then
        module_debug.lua_debug(module_debug.INFO, "dhcp interface[%s] ", interface)
        flag = 1
        x:set("dhcp", interface, "dhcp")
        if interface then x:set("dhcp", interface, "interface", interface) end 
        if start then x:set("dhcp", interface, "start", start) end
        if limit then x:set("dhcp", interface, "limit", limit) end
        if leasetime then x:set("dhcp", interface, "leasetime", leasetime) end
        if force then x:set("dhcp", interface, "force", force) end
        if ignore then x:set("dhcp", interface, "ignore", ignore) end
        if dhcpv6 then x:set("dhcp", interface, "dhcpv6", dhcpv6) end
        if ra then x:set("dhcp", interface, "ra", ra) end
        if ra_management then x:set("dhcp", interface, "ra_management", ra_management) end
        if leasetime6 then x:set("dhcp", interface, "leasetime6", leasetime6) end
    end
end

-- delete the old dhcp interface configraution
local function uci_del_dhcp()
    x:foreach("dhcp", "dhcp", function(s)
        local name = s[".name"]
        intf = x:get("dhcp", name, "interface")
        if (intf ~= nil) then
            ret = x:get("network", intf)
            if (ret == nil) then
                x:delete("dhcp", name)
                module_debug.lua_debug(module_debug.INFO, "dhcp interface[%s] is surplus", intf)
            end
        end
    end
    )
end

-- save dhcp interface default configraution
local function intf_dhcp_def_set()
    local ret, cap, forwardMode, relayMode, dev_cap, network, dft_ipv6

    ret, cap = read_file_for_json(DHCP_CAP)
    if (ret == -1) then
        return -1
    end

    forwardMode = x:get_first("sysinfo", "sysinfo", "forwardMode")
    relayMode = x:get_first("sysinfo", "sysinfo", "relayMode")

    if (type(forwardMode) ~= "string") then
        forwardMode = "ROUTER"

        ret, dev_cap = read_file_for_json(DEV_CAP)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "sd_device is error")
        else
            if (dev_cap["forwardMode"] ~= nil) then
                forwardMode = dev_cap["forwardMode"]
            end
        end
    end
    
    if (type(relayMode) ~= "string") then
        relayMode = "none"
    end

    -- get dft_ipv6 value from sd_device.json in ROUTER Mode
    if (forwardMode == "ROUTER") then
        ret, dev_cap = read_file_for_json(DEV_CAP)
        if (ret == -1) then
            module_debug.lua_debug(module_debug.ERROR, "sd_device is error")
        else
            if (dev_cap["network"] ~= nil) then
                network = dev_cap["network"]
                if (network["dft_ipv6"] ~= nil) then
                    dft_ipv6 = network["dft_ipv6"]
                    module_debug.lua_debug(module_debug.INFO, "dft_ipv6 is %s", dft_ipv6)
                end
            end
        end
    end

    module_debug.lua_debug(module_debug.INFO, "forwardMode is %s, relayMode is %s", forwardMode, relayMode)
    if (cap[forwardMode] ~= nil and cap[forwardMode][relayMode] ~= nil and #cap[forwardMode][relayMode] ~= 0) then
        uci_del_dhcp()
        if (dft_ipv6 == nil or dft_ipv6 ~= "1") then 
            for k,v in ipairs(cap[forwardMode][relayMode]) do 
                if (v["ignore"] == "0") then
                    uci_set_dhcp_enable(v)
                elseif (v["ignore"] == "1") then
                    uci_set_dhcp_disable(v)
                end
            end
        else
            for k,v in ipairs(cap[forwardMode][relayMode]) do 
                uci_set_dhcp_enable_force(v)
            end
        end
        module_debug.lua_debug(module_debug.INFO, "default configuration generated success")
    else
        module_debug.lua_debug(module_debug.INFO, "default configuration don't need to change")
    end 

end

-- save dnsmasq option default configraution
local function dnsmasq_op_def_set()
    local nonegcache, dhcpscript, nodnsra
    local dhcp_bind = "/usr/bin/dhcp_bind"

    nonegcache = x:get_first("dhcp", "dnsmasq", "nonegcache")
    dhcpscript = x:get_first("dhcp", "dnsmasq", "dhcpscript")
    nodnsra = x:get_first("dhcp", "dnsmasq", "nodnsra")
    ignorenx = x:get_first("dhcp", "dnsmasq", "ignorenx")

    if (nonegcache == nil or nonegcache ~= "1") then
        x:foreach("dhcp", "dnsmasq", function(s)
            local name = s[".name"]
            x:set("dhcp", name, "nonegcache", "1")
        end
        )
        flag = 1
    end

    if (nodnsra == nil or nodnsra ~= "1") then
        x:foreach("dhcp", "dnsmasq", function(s)
            local name = s[".name"]
            x:set("dhcp", name, "nodnsra", "1")
        end
        )
        flag = 1
    end

    if (dhcpscript ~= nil or dhcpscript == dhcp_bind) then
        x:foreach("dhcp", "dnsmasq", function(s)
            local name = s[".name"]
            x:delete("dhcp", name, "dhcpscript")
        end
        )
        flag = 1
    end

    if (ignorenx == nil or ignorenx ~= "1") then
        x:foreach("dhcp", "dnsmasq", function(s)
            local name = s[".name"]
            x:set("dhcp", name, "ignorenx", "1")
        end
        )
        flag = 1
    end

end

local function ip_to_int(str)
    local num = 0
    if str and type(str)=="string" then
        local o1,o2,o3,o4 = str:match("(%d+)%.(%d+)%.(%d+)%.(%d+)" )
        num = 2^24*o1 + 2^16*o2 + 2^8*o3 + o4
    end
    return num
end

local function ipstart_num_get(ip_start, lan_ip, netmask)
    if(ip_start == "" or lan_ip == "" or netmask == "") then
        return nil;
    end

    ip_start = ip_to_int(ip_start);
    lan_ip = ip_to_int(lan_ip);
    netmask = ip_to_int(netmask);

    local lan_netmask = bit_hl.band(lan_ip, netmask);
    local start_num = ip_start - lan_netmask;

    return start_num;
end

local function intf_dhcp_set_by_network(network, intf)
    local vid = x:get("network", intf, "vlanid")
    local ignore = x:get("dhcp", intf, "ignore")

    if (vid == nil or ignore == nil) then
        return
    end

    if (ignore == "0") then
        start = x:get("dhcp", intf, "start")
        limit = x:get("dhcp", intf, "limit")
        leasetime = x:get("dhcp", intf, "leasetime")
    else
        start = nil
        limit = nil
        leasetime = nil
    end
    
    if (network["lan"] == nil) then
        return
    end
    
    for k,v in ipairs(network["lan"]) do
        if (v["vlanid"] ~= nil and v["vlanid"] == vid) then
            if (v["ignore"] == "1") then
                if (v["ignore"] ~= ignore) then
                    flag = 1
                    x:set("dhcp", intf, "ignore", v["ignore"])
                end
            else
                start_num = ipstart_num_get(v["ipstart"], v["ipaddr"], v["netmask"])
                if (start_num ~= nil and start_num ~= start) then
                    flag = 1
                    x:set("dhcp", intf, "start", start_num)
                end
                
                if (v["limit"] ~= nil and v["limit"] ~= limit) then
                    flag = 1
                    x:set("dhcp", intf, "limit", v["limit"])
                end
                
                if (v["leasetime"] ~= nil) then
                    leasetime_json = table.concat({v["leasetime"], "m"});
                    if (leasetime_json ~= leasetime) then
                        flag = 1
                        x:set("dhcp", intf, "leasetime", leasetime_json)
                    end
                end
            end
            
            break
        end
    end
end

local function intf_dhcp_recov_by_network(network)
    x:foreach("dhcp", "dhcp", function(s)
        local name = s[".name"]
        intf = x:get("dhcp", name, "interface")
        if (intf ~= nil) then
            ret = x:get("network", intf)
            if (ret ~= nil) then
                intf_dhcp_set_by_network(network, intf)
            end
        end
    end
    )
end

-- save dhcp interface default configraution
local function static_dhcp_uci_clear()
    local ret, cap

    ret, cap = read_file_for_json(DEV_CAP)
    if (ret == -1) then
        return -1
    end

    if (cap["dnsmasq"] ~= nil and cap["dnsmasq"]["static_file"] ~= nil) then
        x:foreach("dhcp", "host", function(s)
            local name = s[".name"]
            x:delete("dhcp", name)
        end
        )
        flag = 1
    end

end

-- save dnsmasq
local function dnsmasq_commit()
    if (flag == 1) then
        x:commit("dhcp")
        x:revert("dhcp")
    end

end

function main(mode)
    local ret, network
    
    -- device mode change, the mode isn't null
    if (mode ~= nil) then
        intf_dhcp_def_set()
    else
        -- network.json doesn't exist or network.json isn't configured.
        ret, network = read_file_for_json(NETWORK_JSON)
        if (ret ~= -1) then
            if (network["configId"] == "0") then
                intf_dhcp_def_set()
            else
                intf_dhcp_recov_by_network(network)
            end
        else
            intf_dhcp_def_set()
        end
    end
    
    dnsmasq_op_def_set()
    static_dhcp_uci_clear()
    
    dnsmasq_commit()
end

local mode = arg[1]
main(mode)
