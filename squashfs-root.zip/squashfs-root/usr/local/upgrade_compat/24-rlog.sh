#!/bin/sh

# ��־ģ�飬�������������޸�
LOG_DIR="/tmp/dev_mode/recov_script"
LOG_NAME="$(basename $0.log)"
LOG_FILE="$LOG_DIR/$LOG_NAME"
LOG_LINE_NUM_MAX=50
log()
{
    if [ -f ${LOG_FILE} ]; then
        log_line=$(cat ${LOG_FILE} | wc -l)
        [ ${log_line} -ge $LOG_LINE_NUM_MAX ] && { mv -f $LOG_FILE ${LOG_FILE}.old; }
    else
        if [ ! -d ${LOG_DIR} ]; then
            mkdir "$LOG_DIR"
        fi
    fi
    if [ -n "$1" ]; then
        local cur_pid="[$$]"
        local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
        echo -e "${cur_pid}${cur_time} ${1}" >> $LOG_FILE
    else
        echo -e "" >> $LOG_FILE
    fi
}

log "Enter $0"

change_flag=0

enable=$(uci get rlog.@rlog[0].enable 2>/dev/null)
# 1169297 ������������ʱ��rlog��server��Ϊurl
server=$(uci get rlog.@rlog[0].server 2>/dev/null)
# 1379577 ���������rlog�Ѿ�������������server
if [ "$enable" = "0" -a "$server" != "url" ]; then
    uci -q set rlog.@rlog[0].server="url"
    change_flag=1
fi

# �����������ݵ�/etc/config/rlog
uploadTimeout=$(uci get rlog.@rlog[0].uploadTimeout 2>/dev/null)
if [ -z "$uploadTimeout" ]; then  # ���� $ ����
    uci -q set rlog.@rlog[0].uploadTimeout="10"
    change_flag=1
fi

retransStreamEnable=$(uci get rlog.@rlog[0].retransStreamEnable 2>/dev/null)
if [ -z "$retransStreamEnable" ]; then
    uci -q set rlog.@rlog[0].retransStreamEnable="1"
    change_flag=1
fi

retransStep=$(uci get rlog.@rlog[0].retransStep 2>/dev/null)
if [ -z "$retransStep" ]; then
    uci -q set rlog.@rlog[0].retransStep="30"
    change_flag=1
fi

retransMaxPeriod=$(uci get rlog.@rlog[0].retransMaxPeriod 2>/dev/null)
if [ -z "$retransMaxPeriod" ]; then
    uci -q set rlog.@rlog[0].retransMaxPeriod="300"
    change_flag=1
fi

tlscafil=$(uci get rlog.@rlog[0].tlscafil 2>/dev/null)
sd_pem="/etc/mqlink/ca/$(product capacity.business_tlscafil | sed 's/\.pem$//')"
echo "lysoratech.com.pem" | sed 's/\.pem$//'
if [ -z "$tlscafil" ]; then
    uci -q set rlog.@rlog[0].tlscafil="/etc/rlog/ca/$sd_pem.pem"
    change_flag=1
fi

domainSuffix=$(uci get rlog.@rlog[0].domainSuffix 2>/dev/null)
if [ -z "$domainSuffix" ]; then
    uci -q set rlog.@rlog[0].domainSuffix="$sd_pem"
    change_flag=1
fi

# ���������ֵ�����ı䣬�򱣴����
if [ $change_flag -eq 1 ]; then
    uci commit rlog
fi

# 1169297 ��ȡ����server������޸�Ϊx
for config in $(uci show syslog | grep '\.server=' | cut -d= -f1); do
    uci -q set ${config}='url'
done

# �������
uci commit syslog