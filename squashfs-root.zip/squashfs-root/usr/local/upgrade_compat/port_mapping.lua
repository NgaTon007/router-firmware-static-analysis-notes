#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;

cjson_safe = require "cjson.safe"
CONFIG_FILE = "/etc/sd_config/single/port_mapping.json"

function file_read(conf_file)
    local file = io.open(conf_file,"r")
    local data = nil
    if (file) then
        data = file:read("*a")
        file:close()
    end
    return data
end

function file_write(conf_file,data)
    local file = io.open(conf_file,"w")
    if (file) then
        file:write(data)
        file:close()
    end
    return -1
end

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

function main()
    local content, content_json
    
    if (file_exists(CONFIG_FILE) == false) then
        return
    end
    
    content = file_read(CONFIG_FILE)
    if (content == nil) then
        return
    end
    
    content_json = cjson_safe.decode(content)
    if (content_json == nil) then
        return
    end
    
    if (content_json["portMapping"] == nil or next(content_json["portMapping"]) == nil) then
        return
    end
    
    for k,v in pairs(content_json["portMapping"]) do  
        if (v["list"] == nil) then
            v["list"] = ""
        end
    end
    
    file_write(CONFIG_FILE, cjson_safe.encode(content_json))
end

main()
