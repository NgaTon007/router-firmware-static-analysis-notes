#!/bin/sh
# Copyright (C) 2008 OpenWrt.org

STATIC_IP="10.10.10.10"
STATIC_BROADCAST="10.10.10.10"
STATIC_NETMASK="255.255.255.0"
STATIC_GATEWAY="10.10.10.1"
LOG_FILE="/tmp/debug/upgrade_compat/network_update.log"

debug()
{
    [ -e /tmp/debug/upgrade_compat/ ] || mkdir -p /tmp/debug/upgrade_compat/
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    echo -e "[$cur_time] $@" >> $LOG_FILE
}

dns_check()
{
    local gw=""
    local wan_dns=""

    wan_dns=$(uci -q get network.wan.dns)
    if [ -n "$wan_dns" ]; then
        debug "dns config exist!"
        return
    fi
    debug "dns server setting."
    gw=$(uci -q get network.wan.gateway)
    uci -q add_list network.wan.dns="$gw"
    uci -q add_list network.wan.dns="8.8.8.8"
    uci commit network
    debug "[est]dns network reload."
    /etc/init.d/network reload &
}

dev_type=$(dev_cap get -m dev_type)
if [ "$dev_type" == "est" ]; then
    cur_version=$(cat "/etc/openwrt_version" | awk -F "," '{print $1}')
    debug "[est]cur_version:$cur_version."
    if [ "$cur_version" != "AP_3.0(1)B2P18" ]; then
        debug "[est]dev version err."
        return
    fi

    wan_proto=$(uci -q get network.wan.proto)
    if [ "$wan_proto" != "static" ]; then
        debug "[est]dhcp mode."
        return
    fi
    
    wan_ipaddr=$(uci -q get network.wan.ipaddr)
    if [ "$wan_ipaddr" != "$STATIC_IP" ]; then
        debug "[est]no default ipaddr."
        # �����ù���̬ip��ַ, ��Ҫ���dns�ֶ��Ƿ�ȱʧ��
        dns_check "$wan_ipaddr"
        return
    fi

    userConfig=$(ls /etc/sd_config/single/network*.json 2>/dev/null)
    if [ -z "$userConfig" ]; then
        debug "[est]no userConfig, directly recovery."
    else
        configTime=$(cat $userConfig | jq -r '.configTime')
        debug "configTime:$configTime"
        if [ "$configTime" != "0" ]; then
            # �����ù���̬ip��ַ, ��Ҫ���dns�ֶ��Ƿ�ȱʧ��
            dns_check "$wan_ipaddr"
            debug "User Behavior, not to update."
            return
        fi
    fi

    debug "[est]remove static ip and config."
    uci -q set network.wan.proto=dhcp
    uci -q delete network.wan.ipaddr
    uci -q delete network.wan.broadcast
    uci -q delete network.wan.netmask
    uci -q delete network.wan.gateway
    uci -q delete network.wan.dns
    uci -q commit network
    rm -rf /etc/sd_config/single/network*.json
    debug "[est]network reload."
    /etc/init.d/network reload &
fi
