#!/bin/sh

#本脚本用于配置兼容，确保1.X版本的设备升级到2.X版本，配置能兼容

#判断是否为早期配置
check=$(uci -q get mqtt.@mqtt[0].periodInformInterval)

#若为早期配，则用rom下的配置替换
if [ -n "$check" ];then
    local networkId=$(uci -q get mqtt.@mqtt[0].networkId)
    local networkName=$(uci -q get mqtt.@mqtt[0].networkName)
    local groupId=$(uci -q get mqtt.@mqtt[0].groupId)
    local groupName=$(uci -q get mqtt.@mqtt[0].groupName)

    cp -f /rom/etc/config/mqtt /etc/config/mqtt

    [ -z "$networkId" ] && networkId=0
    [ -z "$groupId" ] && groupId=0

    uci -q set mqtt.@mqtt[0].networkId="$networkId"
    uci -q set mqtt.@mqtt[0].networkName="$networkName"
    uci -q set mqtt.@mqtt[0].groupId="$groupId"
    uci -q set mqtt.@mqtt[0].groupName="$groupName"
    uci commit mqtt
fi
