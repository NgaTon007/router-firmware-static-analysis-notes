#!/bin/sh
# Copyright (C) 2008 OpenWrt.org
access_ctrl_config="/etc/sd_config/single/access_ctrl.json"
[ -f "$access_ctrl_config" ] && { lua /usr/bin/access_ctrl_merge.lua ; }

