#! /usr/bin/env lua

package.path = "/usr/local/lua/ac_config/?.lua;" .. package.path;
local cjson = require "cjson";
local tool = require "dev.tools.common"
local libjsn  = require("utils.json");
local lua_debug = require "utils.debug"
local net_uci = require "luci.model.uci".cursor(nil, "/var/run/net_uci_state")
local forwardMode = nil;
local capacity_json = nil
local network_file = "/etc/sd_config/single/network.json"
local network_bak_file = "/etc/sd_config/single/network_compat_bak.json"

--debug��ʼ��
function debug_init()
    lua_debug.debug_init("/tmp/network/", "network_compat.log", 150, lua_debug.DEBUG, "1")
end

debug_init()

-- �� /tmp/sd_device/product.json �л�ȡ .capacity.web ��ֵ��Ϊweb_key
function network_web_key_get()
    local product_file = "/tmp/sd_device/product.json"
    if (tool.file_exist(product_file) == false) then
        lua_debug.lua_debug(lua_debug.INFO, "product.json not exist");
        return
    end

    local product_data = tool.file_read(product_file);
    if (tool.json_check(product_data) == false) then
        lua_debug.lua_debug(lua_debug.WARN, "product.json format error");
        return
    end

    local product_json = cjson.decode(product_data);
    if (product_json.capacity == nil or product_json.capacity.web == nil) then
        lua_debug.lua_debug(lua_debug.INFO, ".capacity.web not found in product.json");
        return
    end

    local web_key = product_json.capacity.web;
    if (web_key == nil or web_key == "") then
        lua_debug.lua_debug(lua_debug.INFO, "web_key is empty");
        return
    end
    lua_debug.lua_debug(lua_debug.INFO, "get web_key from product.json: %s", web_key);

    return web_key
end

local function is_device_support_nat_ena()
    local capacity_file = "/tmp/sd_device/sd_device.json"
    if (tool.file_exist(capacity_file) == false) then
        lua_debug.lua_debug(lua_debug.ERROR, "%s is not exist.", capacity_file);
        return false;
    end

    local capacity_json = libjsn.get_json_table_from_file(capacity_file)
    if (capacity_json == nil) then
        lua_debug.lua_debug(lua_debug.ERROR, "%s empty.", capacity_file);
        return false;
    end

    --��ȡ�豸ת��ģʽ
    forwardMode = net_uci:get_first("sysinfo", "sysinfo", "forwardMode")
    if (forwardMode == nil) then
        if (capacity_json["forwardMode"] ~= nil) then
            forwardMode = capacity_json["forwardMode"];
        else
            lua_debug.lua_debug(lua_debug.ERROR, "Get forwardMode failed in device.json.");
            return false;
        end
    end

    local web_key = network_web_key_get()
    if (web_key == nil) then
        lua_debug.lua_debug(lua_debug.ERROR, "Get web_key failed.");
        return false
    end

    -- ��ȡwan���Ƿ�֧��nat�������ã�����·��ģʽ����Ч
    if (capacity_json[web_key] ~= nil and capacity_json[web_key]["nat_ena"] ~= nil and capacity_json[web_key]["nat_ena"] == "1" and forwardMode == "ROUTER") then
        return true
    end

    return false
end

local function update_network_json_for_nat_ena(network_json)
    local change_flag = 0

    if (network_json["wan"] == nil) then
        lua_debug.lua_debug(lua_debug.ERROR, "The json wan is null");
        return false
    end

    -- Ĭ�Ͻ�wan������ΪNATģʽ
    for key, val in pairs(network_json["wan"]) do
        if (val ~= nil and next(val) ~= nil and val["nat_ena"] == nil) then
           val["nat_ena"] = "1"
           change_flag = 1
        end
    end

    if (change_flag == 1) then
        str = cjson.encode(network_json)
        if (str ~= nil) then
            tool.file_mv_write(network_file, network_bak_file, str, "w+");
            lua_debug.lua_debug(lua_debug.INFO, "Update the network json config compat nat_ena success.");
        else
            lua_debug.lua_debug(lua_debug.ERROR, "Update the network json config compat nat_ena failed.");
            return false;
        end
    else
        lua_debug.lua_debug(lua_debug.INFO, "The network json config don't need to change.");
    end

    return true
end

-- bugid:[1143539] /etc/config/network�����peerdns�ֶε������ֵ�û��dns�ֶε��������������ᵼ��dnsȱʧ��
local function update_network_uci_for_dns()
    --ֻ��wan�ڻ����
    local peerdns = net_uci:get("network", "wan", "peerdns")
    if (peerdns == nil) then
        return true
    end

    local dns = net_uci:get("network", "wan", "dns")
    if (dns == nil) then
        net_uci:delete("network", "wan", "peerdns")
        net_uci:commit("network")
        lua_debug.lua_debug(lua_debug.INFO, "remote wan peerdns.");
    end

    return true
end

function main()
    -- bugid:[1143539] /etc/config/network�����peerdns�ֶε������ֵ�û��dns�ֶε��������������ᵼ��dnsȱʧ��
    update_network_uci_for_dns()

    -- ����豸֧������nat_ena�������Ĭ�ϲ�����nat_ena��wan���ֶν������
    if (is_device_support_nat_ena() == true) then
        if (tool.file_exist(network_file) == false) then
            lua_debug.lua_debug(lua_debug.ERROR, "%s is not exist.", network_file);
            return false;
        end

        local network_json = libjsn.get_json_table_from_file(network_file)
        if (network_json == nil) then
            lua_debug.lua_debug(lua_debug.ERROR, "%s empty.", network_file);
            return false;
        end

        ret = update_network_json_for_nat_ena(network_json)
        if (res == false) then
            lua_debug.lua_debug(lua_debug.ERROR, "Update the network json config failed.");
            return false;
        end
    else
        lua_debug.lua_debug(lua_debug.INFO, "The device doesn't support to configrate wan nat_ena in the current forwardMode.");
    end
end

main()