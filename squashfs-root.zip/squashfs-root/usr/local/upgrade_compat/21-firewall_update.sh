#!/bin/sh
# Copyright (C) 2008 OpenWrt.org

status=false

firewall_apply(){
    for loop in 0 1 2
    do
        case $(uci -q get firewall.@zone[$loop].name) in
            'lan')
                flan=$(uci get firewall.@zone[$loop].network)
            ;;
            'wan')
                fwan=$(uci get firewall.@zone[$loop].network)
            ;;
            'mngnet')
                fzone=$(uci get firewall.mngnet)
                fname=$(uci get firewall.mngnet.name)
                finput=$(uci get firewall.mngnet.input)
                foutput=$(uci get firewall.mngnet.output)
                fforward=$(uci get firewall.mngnet.forward)
                fnetwork=$(uci get firewall.mngnet.network)
                
                fwdmngnet=$(uci get firewall.fwdmngnet)
                fwdmngnet_src=$(uci get firewall.fwdmngnet.src)
                fwdmngnet_dest=$(uci get firewall.fwdmngnet.dest)
            ;;
            *)
            ;;
        esac
    done

    if [ $(uci -q get sysinfo.@sysinfo[0].forwardMode) = "ROUTER" ]; then
        if [ "$(uci -q get firewall.dhcp)" != "rule" -o "$(uci -q get firewall.app)" = "rule" ]; then
            #逻辑一:当设备为p17之前的版本或模式切换时，firewall要重新配置
            rm /etc/config/firewall
            cp /rom/etc/config/firewall /etc/config
            uci -q delete firewall.app
            uci -q delete firewall.discovery
            uci -q delete firewall.ssh
            uci -q delete firewall.http
            uci -q delete firewall.mqtt
            uci -q delete firewall.dns_tcp
            uci -q delete firewall.sw_disc
            uci -q delete firewall.dns_udp
            uci -q delete firewall.tftpd
            uci -q delete firewall.https
            
            for loop in 0 1 2
            do
                case $(uci -q get firewall.@zone[$loop].name) in
                    'lan')
                        if [ -n "$flan" ]; then
                            uci -q set firewall.@zone[$loop].network="$flan"
                        fi
                    ;;
                    'wan')
                        if [ -n "$fwan" ]; then
                            uci -q set firewall.@zone[$loop].network="$fwan"
                        fi
                    ;;
                esac
            done
            
            status=true
        fi
    else
        if [ "$(uci -q get firewall.dhcp)" != "rule" ]; then
        #逻辑一:当设备为p17之前的版本时，firewall要重新配置
            rm /etc/config/firewall
            cp /rom/etc/config/firewall /etc/config
            
            for loop in 0 1 2
            do
                case $(uci -q get firewall.@zone[$loop].name) in
                    'lan')
                        if [ -n "$flan" ]; then
                            uci -q set firewall.@zone[$loop].network="$flan"
                        fi
                    ;;
                    'wan')
                        if [ -n "$fwan" ]; then
                            uci -q set firewall.@zone[$loop].network="$fwan"
                        fi
                    ;;
                esac
            done
            
            if [ -n "$fname" ]; then
                uci -q set firewall.mngnet="$fzone"
                uci -q set firewall.mngnet.name="$fname"
                uci -q set firewall.mngnet.input="$finput"
                uci -q set firewall.mngnet.output="$foutput"
                uci -q set firewall.mngnet.forward="$fforward"
                uci -q set firewall.mngnet.network="$fnetwork"
                
                uci -q set firewall.fwdmngnet="$fwdmngnet"
                uci -q set firewall.fwdmngnet.src="$fwdmngnet_src"
                uci -q set firewall.fwdmngnet.dest="$fwdmngnet_dest"

            fi
            status=true
        fi
        
        #逻辑二:当设备为AP\AC模式时，firewall.wan.forward 要设置为ACCEPT
        for loop in 0 1 2
        do
            case $(uci -q get firewall.@zone[$loop].name) in
                'wan')
                    uci -q set firewall.@zone[$loop].forward="ACCEPT"
                ;;
            esac
            status=true
        done
        
        #P17升P20时，增加https配置节
        if [ "$(uci -q get firewall.https)" != "rule" ]; then
            uci -q set firewall.https=rule
            uci -q set firewall.https.src=wan
            uci -q set firewall.https.proto=tcp
            uci -q set firewall.https.dest_port=443
            uci -q set firewall.https.target=ACCEPT
            
            status=true
        fi
        
        #P17升P20时，增加apcwy配置节点(兼容P17的AC模式)
        if [ "$(uci -q get firewall.apcwy)" != "rule" ]; then
            uci -q set firewall.apcwy=rule
            uci -q set firewall.apcwy.src=wan
            uci -q set firewall.apcwy.proto=udp
            uci -q set firewall.apcwy.dest_port=5248
            uci -q set firewall.apcwy.target=ACCEPT
            
            status=true
        fi
        
    fi

    if [ $status = true ]; then
        uci -q commit firewall
    fi
}

#不需要以下的配置；
uci -q delete firewall.app
uci -q delete firewall.discovery
uci -q delete firewall.ssh
uci -q delete firewall.http
uci -q delete firewall.mqtt
uci -q delete firewall.dns_tcp
uci -q delete firewall.sw_disc
uci -q delete firewall.dns_udp
uci -q delete firewall.tftpd
uci -q delete firewall.https
uci -q delete firewall.mngnet
uci -q delete firewall.apcwy
uci -q delete firewall.fwdmngnet
uci -q delete firewall.roam_ap_tun
uci -q delete firewall.dhcp6.src_port
uci -q delete firewall.dhcp6.src_ip

uci -q commit firewall
#配置兼容问题处理
#4.18以前版本配置
#firewall.@redirect[0]=redirect
#firewall.@redirect[0].target=DNAT
#4.18以后版本配置
#firewall.port_map1=redirect
#为了兼容内网访问http服务器，在LAN上增加了DNAT和MASQUERADE
pm_num=$(uci show firewall  | grep 'firewall.@redirect' | grep -c '=redirect')
while [ $pm_num -ge 0 ]; do
    target_mapping=$(uci -q get firewall.@redirect[$pm_num].target)
    [ "$target_mapping" = "DNAT" ] && { uci -q del firewall.@redirect[$pm_num]; }
    pm_num=$((pm_num - 1))
    status=true
done
for line in $(uci show firewall | grep redirect | sed 's/=redirect//g')
do
    uci -q del $line
    status=true
done


if [ $status = true ]; then
    uci -q commit firewall
fi

#配置兼容
[ -f /etc/firewall.user ] && {
    is_diff=$(diff /rom/etc/firewall.user /etc/firewall.user 2>/dev/null| wc -l)
    if [ $is_diff -ne 0 ]; then
        cp /rom/etc/firewall.user /etc/
        if [ -f /lib/functions/elisten_function.sh ]; then
            . /lib/functions/elisten_function.sh
            firewall_restart
        else
            /etc/init.d/firewall restart
        fi 
    fi
}
