#! /usr/bin/env lua
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local lib_mesh = require "utils.mesh_com"
local radiolist_cache = lib_mesh.get_radio_info()
local apmgr_cfg = 'apmgr'
local repeater_cfg = 'repeater'

module_debug.debug_init("/tmp/", "apMeshV2Compat.log", 100, module_debug.DEBUG, "1")

function main()
    local network_id = uci:get("mqtt", "mqtt", "networkId")
    uci:load(apmgr_cfg)
    if (network_id and network_id ~= "0") then
        uci:set(apmgr_cfg, "global", "factory_mode", "0")
        module_debug.lua_debug(module_debug.INFO, "factory_mode set 0")
    else
        uci:set(apmgr_cfg, "global", "factory_mode", "1")
        module_debug.lua_debug(module_debug.INFO, "factory_mode set 1")
    end
    uci:commit(apmgr_cfg)

    uci:load(repeater_cfg)
    for i, device in ipairs(radiolist_cache) do
        local apcli_cfg = uci:get_all(repeater_cfg, device.name) or {}
        local apcli_ssid = apcli_cfg.ApCliSsid or ''
        local is_mesh = apcli_cfg.isMesh
        if is_mesh == nil then
            module_debug.lua_debug(module_debug.INFO, "is_mesh is nil, need set")
            local product = require("product");
            local wifi_prefix = product.get_product("capacity.wireless.default_wifi_prefix")
            local mesh_ssid = wifi_prefix..'-Repeater'
            if apcli_ssid == mesh_ssid then
                uci:set(repeater_cfg, device.name, "isMesh", "1")
                module_debug.lua_debug(module_debug.INFO, "isMesh set 1")
            else
                uci:set(repeater_cfg, device.name, "isMesh", "0")
                module_debug.lua_debug(module_debug.INFO, "isMesh set 0")
            end
        else
            module_debug.lua_debug(module_debug.INFO, "is_mesh exist, not set")
        end
    end
    uci:commit(repeater_cfg)
    os.execute("sync")
end

main()