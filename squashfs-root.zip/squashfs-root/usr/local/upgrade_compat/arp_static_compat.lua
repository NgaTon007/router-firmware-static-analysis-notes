#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("arp_static", package.seeall);

dkjson = require "dkjson"
CONFIG_FILE = "/etc/sd_config/single/arp_static.json"

function file_read(conf_file)
    local file = io.open(conf_file,"r")
    local data = nil
    if (file) then
        data = file:read("*a")
        file:close()
    end
    return data
end

function file_write(conf_file,data)
    local file = io.open(conf_file,"w")
    if (file) then
        file:write(data)
        file:close()
    end
    return -1
end

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

function main()
    local content, content_json
    
    if (file_exists(CONFIG_FILE) == true) then
        content = file_read(CONFIG_FILE)
    end
    
    if (content ~= nil) then
        content_json = dkjson.decode(content)
    end
     
    if (content_json ~= nil) then
        if (content_json["intf_list"] == nil) then
            content_json["intf_list"] = {}
            file_write(CONFIG_FILE, dkjson.encode(content_json))
        end
    end
end

main()