#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;
module("arp_static", package.seeall);

dkjson = require "dkjson"
uci = require "luci.model.uci".cursor()
product = require("product")
CONFIG_FILE = "/etc/sd_config/single/dhcp_option.json"
DEVICE_JSON = "/tmp/sd_device/sd_device.json"
web_node = product.get_product("capacity.web")

function file_read(conf_file)
    local file = io.open(conf_file,"r")
    local data = nil
    if (file) then
        data = file:read("*a")
        file:close()
    end
    return data
end

function file_write(conf_file,data)
    local file = io.open(conf_file,"w")
    if (file) then
        file:write(data)
        file:close()
    end
    return -1
end

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

function copy_dhcp_opts_conf()
    local content, content_json, dhcp_opts_conf
    local is_changed = false
    local dhcp_option_cache = {}
    local dhcp_option_list = {}
    local dhcp_section_name = nil
    local uci_modified = false

    if (file_exists(DEVICE_JSON) == true) then
        content = file_read(DEVICE_JSON)
    end

    if (content ~= nil) then
        content_json = dkjson.decode(content)
    end

    if (content_json == nil) then
        return
    end

    -- 判断是否支持dhcp_option按vlan生效
    if (content_json[web_node] == nil) or (content_json[web_node]["dhcpOption"] ~= "1") then
        return
    end

    if (content_json["dnsmasq"] == nil) or (content_json["dnsmasq"]["dhcpOptsConf"] == nil) then
        return
    end

    dhcp_opts_conf = content_json["dnsmasq"]["dhcpOptsConf"]
    if (file_exists(dhcp_opts_conf) ~= true) then
        return
    end

    content = file_read(dhcp_opts_conf)

    if (content ~= nil) then
        content_json = dkjson.decode(content)
    end

    if (content_json == nil) then
        return
    end

    uci:load("dhcp")
    uci:foreach("dhcp", "dnsmasq", function(s)
        if dhcp_section_name == nil then
            dhcp_section_name = s[".name"]
            dhcp_option_list = uci:get_list("dhcp", dhcp_section_name, "dhcp_option") or {}
            for _, opt in ipairs(dhcp_option_list) do
                dhcp_option_cache[opt] = true
            end
        end
    end)

    if (content_json["option"] ~= nil) then
        for _, v in pairs(content_json["option"]) do
            if (v["id"] ~= nil and  v["value"] ~= nil and v["value"] ~= "") then
                local value_str = v["value"]:gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s+", ",")
                local entry = string.format("%s,%s", v["id"], value_str or "")
                if dhcp_option_cache[entry] ~= true then
                    table.insert(dhcp_option_list, entry)
                    dhcp_option_cache[entry] = true
                    uci_modified = true
                end

                local normalized = v["value"]:gsub("^%s+", ""):gsub("%s+$", ""):gsub("[%s,]+", " ")
                if (normalized ~= v["value"]) then
                    v["value"] = normalized
                    is_changed = true
                end
            end
        end
    end

    if (content_json["domain"] ~= nil) then
        local domain_entry = string.format("15,lan")
        if content_json["domain"] ~= "" then
            domain_entry = string.format("15,%s", content_json["domain"] or "")
        end
        if dhcp_option_cache[domain_entry] ~= true then
            table.insert(dhcp_option_list, domain_entry)
            dhcp_option_cache[domain_entry] = true
            uci_modified = true
        end
    end

    if uci_modified == true and #dhcp_option_list > 0 and dhcp_section_name ~= nil then
        uci:set_list("dhcp", dhcp_section_name, "dhcp_option", dhcp_option_list)
        uci:commit("dhcp")
    end

    if (content_json["custom_option"] ~= nil) then
        for _, v in pairs(content_json["custom_option"]) do
            if (v["id"] ~= nil and v["value"] ~= nil and v["type"] == "3") then
                local normalized = v["value"]:gsub("^%s+", ""):gsub("%s+$", ""):gsub("[%s,]+", " ")
                if (normalized ~= v["value"]) then
                    v["value"] = normalized
                    is_changed = true
                end
            end
        end
    end

    if (content_json["single"] ~= nil) then
        for _, s in pairs(content_json["single"]) do
            if (s["option"] ~= nil) then
                for _, v in pairs(s["option"]) do
                    if (v["id"] ~= nil and v["value"] ~= nil and v["value"] ~= "") then
                        local normalized = v["value"]:gsub("^%s+", ""):gsub("%s+$", ""):gsub("[%s,]+", " ")
                        if (normalized ~= v["value"]) then
                            v["value"] = normalized
                            is_changed = true
                        end
                    end
                end
            end
            if (s["custom_option"] ~= nil) then
                for _, v in pairs(s["custom_option"]) do
                    if (v["id"] ~= nil and v["value"] ~= nil and v["type"] == "3") then
                        local normalized = v["value"]:gsub("^%s+", ""):gsub("%s+$", ""):gsub("[%s,]+", " ")
                        if (normalized ~= v["value"]) then
                            v["value"] = normalized
                            is_changed = true
                        end
                    end
                end
            end
        end
    end

    if content_json["single"] == nil then
        content_json["single"] = {}
        is_changed = true
    end

    if (is_changed == true) then
        for _, key in ipairs({"configId", "configTime", "currentTime"}) do
            local value = content_json[key]
            local num = tonumber(value)
            if num ~= nil then
                num = num + 1
                if type(value) == "number" then
                    content_json[key] = num
                else
                    content_json[key] = tostring(num)
                end
            end
        end
        file_write(dhcp_opts_conf, dkjson.encode(content_json))
    end
end

function main()
    local flag = 0
    local content, content_json
    
    if (file_exists(CONFIG_FILE) == true) then
        content = file_read(CONFIG_FILE)
    end
    
    if (content ~= nil) then
        content_json = dkjson.decode(content)
    end
     
    if (content_json == nil) then
        return
    end
    
    def_conf = '{"option":[{"id":"3","value":""},{"id":"6","value":""},{"id":"43","value":""},{"id":"138","value":""},{"id":"150","value":""}]}'
    optionlist = dkjson.decode(def_conf)
    
    if (content_json["dnslist"] ~= nil) then
        for k,v in pairs(optionlist["option"]) do
            if (v["id"] == "6") then
                v["value"] = content_json["dnslist"]
                flag = 1
                break
            end
        end
    end

    if (content_json["option138"] ~= nil) then
        for k,v in pairs(optionlist["option"]) do
            if (v["id"] == "138") then
                v["value"] = content_json["option138"]
                flag = 1
                break
            end
        end
    end
    
    if (flag == 0) then
        curoptionlist = {}
        if (content_json["option"] ~= nil) then
            for k,v in pairs(content_json["option"]) do
                if (v["id"] ~= nil) then
                    curoptionlist[v["id"]] = v["value"]
                end
            end
            
            if (curoptionlist["43"] == nil) then
                flag = 2
                option = {}
                option["id"] = "43"
                option["value"] = ""
                table.insert(content_json["option"], option)
            end
            
            if (curoptionlist["150"] == nil) then
                flag = 2
                option = {}
                option["id"] = "150"
                option["value"] = ""
                table.insert(content_json["option"], option)
            end
            
            if (curoptionlist["3"] == nil) then
                flag = 2
                option = {}
                option["id"] = "3"
                option["value"] = ""
                table.insert(content_json["option"], option)
            end
        end
    end

    if (flag == 1) then
        optionlist["version"] = content_json["version"]
        optionlist["configId"] = content_json["configId"]
        optionlist["configTime"] = content_json["configTime"]
        optionlist["currentTime"] = content_json["currentTime"]
        
        file_write(CONFIG_FILE, dkjson.encode(optionlist))
    elseif (flag == 2) then
        file_write(CONFIG_FILE, dkjson.encode(content_json))
    end

    copy_dhcp_opts_conf()

end

main()