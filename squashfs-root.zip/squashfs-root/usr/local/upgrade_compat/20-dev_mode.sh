#!/bin/sh

##本脚本的功能：
##由于P17版本及之后版本新引入设备模式功能，
##当老版本的EAP设备升级P17及之后版本时，需要根据wan协议设置模式，
##若设备原先WAN口为PPPOE拨号时，则将设备模式设置为ROUTER模式，否则使用默认模式
##非EAP设备不用管

#判断设备是否为EAP设备，非EAP设备直接返回
check=$(cat /proc/cpuinfo | grep EAP | wc -l)
[ $check -eq 0 ] && return

#判断设备是否为PPPOE拨号
wanProto=$(uci -q get network.wan.proto)
[ "$wanProto" != "pppoe" ] && return

#判断设备转发模式是否为ROUTER模式
forwardMode=$(uci -q get sysinfo.@sysinfo[0].forwardMode)
[ "$forwardMode" = "ROUTER" ] && return

#设置设备模式为ROUTER模式
if [ -f "/etc/config/sysinfo" ];then
    uci set sysinfo.@sysinfo[0].forwardMode=ROUTER
    uci commit sysinfo
else
    touch /etc/config/sysinfo
    uci add sysinfo sysinfo
    uci set sysinfo.@sysinfo[0].forwardMode=ROUTER
    uci commit sysinfo
fi
