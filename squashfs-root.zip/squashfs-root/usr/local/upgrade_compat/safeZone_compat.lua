#! /usr/bin/env lua

module_name = "safeZoneCompat"
package.path = "/usr/lib/lua/?.lua;" .. package.path
module(module_name, package.seeall)

uci = require("luci.model.uci")
cjson_safe = require "cjson.safe"
dkjson = require "dkjson"
module_debug = require "utils.debug"
dev_config = require "dev_config"

local_safe_file = "/etc/sd_config/single/local_safe.json"
local_safe_iptables = "/tmp/iptables.rules/local_safe"
config_file_path = "/etc/sd_config/single/safeZone.json"
cap_file_path = "/tmp/sd_device/sd_device.json"
module_debug.debug_init("/tmp/fwmng/", module_name..".log", 30, module_debug.DEBUG, "1")

local web = require("product").get_product("capacity.web")
-- check the file exist or not
-- @path: File path
-- @return true, if the file exist; otherwise return false.
function file_exist(path)
    local file = io.open(path, "rb");
    if (file) then
        file:close();
    end
    return file ~= nil;
end

-- write the exist file
-- @path: File path
-- @content: it will be written to write file
-- @mode: the write file mode. ex:w, w+, a, a+
-- @return true, if the write file success; otherwise return false.
local function file_write(path, content, mode)
    mode = mode or "w+b"
    local f = io.open(path, mode)

    if (f) then
        if f:write(content) == nil then
            module_debug.lua_debug(module_debug.ERROR, "the file [%s] write failed", path)

            return -1
        end
        io.close(f)

        return 0
    else
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] can't open.", path)

        return -1
    end
end

-- read the exist file
-- @path: File path
-- @return file content, if the read file success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

local function json_write_to_file(path, config_json)
    if (config_json ~= nil) then
        config_str = dkjson.encode(config_json)
        if (config_str ~= nil) then
            module_debug.lua_debug(module_debug.INFO, "[%s] param (%s)", path, config_str)
            local temp_path = path .. ".tmp"
            res = file_write(temp_path, config_str)
            if (res == 0) then
                -- Attempt to rename temp file to target path
                local rename_success = os.rename(temp_path, path)
                if (rename_success) then
                    return 0
                else
                    module_debug.lua_debug(module_debug.ERROR, "Failed to rename temp file [%s] to [%s]", temp_path, path)
                    os.remove(temp_path)  -- Clean up temp file on failure
                    return -1
                end
            else
                module_debug.lua_debug(module_debug.ERROR, "Failed to write to temp file [%s]", temp_path)
                return -1
            end
        else
            module_debug.lua_debug(module_debug.ERROR, "ERROR: config_json isn't json")
            return -1
        end
    end

    return 0
end

local function exec(sh_cmd)
    if (sh_cmd == nil) then
        return nil;
    end
    
    local sh_ret_handle = io.popen(sh_cmd);
    if (sh_ret_handle ~= nil) then
        sh_ret = sh_ret_handle:read("*all")
        sh_ret_handle:close()
    end
    
    return sh_ret;
end

local function file_to_json(file)
    if (file == nil) then
        return nil
    end

    local content = file_read(file)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content is nil")
        return nil
    end
    
    local config_json = cjson_safe.decode(content)
    if (config_json == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:the file content isn't json")
        return nil
    end
    
    return config_json
end

--生成随机值
local function guid()
        local template ="xxxxxxxxxxxxxxxxxxxx"---xxxx-xxxx-xxxxxxxxxxxx"
        local d = io.open("/dev/urandom", "r"):read(4)
  local num = (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 42941)
  --os.time()  + d:byte(1) --+ (d:byte(2) * 256) + (d:byte(3) * 65536) + (d:byte(4) * 4294967296)
        math.randomseed(num)
        return string.upper(string.gsub(template, "x", function (c)
                                        local v = (c == "x") and math.random(0, 0xf) or math.random(8, 0xb)
                                                return string.format("%x", v)
                                        end
                        ))
end

local function safeZoneMgr_compat(content)
    local safeZoneMgr = {}
    
    safeZoneMgr["list"] = {}

    if (content["list"] ~= nil) then
        for k,v in pairs(content["list"]) do
            local node = {}
            node["uuid"] = guid()
            node["name"] = v["rulename"]
            node["iprange"] = v["iprange"]
            node["intf"] = v["intf"]
            
            table.insert(safeZoneMgr["list"], node)
        end
    end

    safeZoneMgr["configId"] = nil
    safeZoneMgr["currentTime"] = nil
    safeZoneMgr["configTime"] = nil

    cmdstr = cjson_safe.encode(safeZoneMgr)
    if (cmdstr ~= nil) then
        dev_config.fetch("add","safeZoneMgr", cmdstr, 1)
        module_debug.lua_debug(module_debug.INFO, "INFO: safeZoneMgr compate finish")
    end
end

local function safeZone_compat(content, safeZone)
    local ping_flag, web_flag

    for k,v in pairs(safeZone["list"]) do
        if (v["uuid"] ~= nil and safeZone["list"][k] ~= nil and safeZone["list"][k]["disbaleList"] ~= nil) then
            if (v["uuid"] == "ZoneLan") then
                ping_flag = 0
                web_flag = 0
                
                for serv_k, serv_v in pairs(safeZone["list"][k]["disbaleList"]) do
                    if (serv_v == "ping") then
                        ping_flag = 1
                    end
                    
                    if (serv_v == "web") then
                        web_flag = 1
                    end
                end
                
                if (ping_flag == 0 and content["safetypes"]["deny_lan_ping"] == "1") then
                    table.insert(safeZone["list"][k]["disbaleList"], "ping")
                end

                if (web_flag == 0 and content["safetypes"]["deny_lan_web"] == "1") then
                    table.insert(safeZone["list"][k]["disbaleList"], "web")
                end
            end
        
            if (v["uuid"] == "ZoneWan") then
                ping_flag = 0
                for serv_k, serv_v in pairs(safeZone["list"][k]["disbaleList"]) do
                    if (serv_v == "ping") then
                        ping_flag = 1
                        break
                    end
                end
                
                if (ping_flag == 0 and content["safetypes"]["deny_wan_ping"] == "1") then
                    table.insert(safeZone["list"][k]["disbaleList"], "ping")
                end
            end
        end
    end

    safeZone["configId"] = nil
    safeZone["currentTime"] = nil
    safeZone["configTime"] = nil

    cmdstr = cjson_safe.encode(safeZone)
    if (cmdstr ~= nil) then
        dev_config.fetch("update","safeZone", cmdstr, 1)
        module_debug.lua_debug(module_debug.INFO, "INFO: safeZone compate finish")
    end
end

local function update_config(content)
    safeZoneMgr_compat(content)
    
    local serv_flag = 0
    local data = dev_config.fetch("get","safeZone", "", 1)
    if (data ~= nil and data["data"] ~= nil) then
        safeZone = cjson_safe.decode(data["data"])
        if (safeZone ~= nil) then
            safeZone_compat(content, safeZone)
        end
    end
    
    cmd = string.format("iptables -w -t filter -F deny_wan_ping >/dev/null 2>&1")
    exec(cmd)
    
    cmd = string.format("iptables -w -t filter -F deny_lan_ping >/dev/null 2>&1")
    exec(cmd)
    
    cmd = string.format("iptables -w -t filter -F deny_lan_web >/dev/null 2>&1")
    exec(cmd)
    
    cmd = string.format("ipset flush localsafe_allow_list >/dev/null 2>&1")
    exec(cmd)
    
    cmd = string.format("ipset destroy localsafe_allow_list >/dev/null 2>&1")
    exec(cmd)
end

local function add_ZoneRoute_config()
    local serv_flag = 0
    local safeZone = nil
    local ZoneRoute_flag = 0

    local data = dev_config.fetch("get","safeZone", "", 1)
    if (data == nil or data["data"] == nil) then
        return
    end

    safeZone = cjson_safe.decode(data["data"])
    if (safeZone == nil) then
        return
    end

    ZoneRoute_flag = 0
    for k,v in pairs(safeZone["list"]) do
        if (v["uuid"] == "ZoneRoute") then
            ZoneRoute_flag = 1
        end
    end

    if (ZoneRoute_flag == 0) then
        local ZoneRoute = {}
        local cmd = {}
        cmd["list"] = {}

        ZoneRoute["uuid"] = "ZoneRoute"
        ZoneRoute["name"] = "DefRoute"
        ZoneRoute["setname"] = "ZoneRoute"
        ZoneRoute["type"] = "wan"
        ZoneRoute["mem"] = {}
        ZoneRoute["zoneAccess"] = {"ZoneLan"}
        ZoneRoute["accessedZone"] = {"ZoneLan"}
        ZoneRoute["disbaleList"] = {}

        table.insert(cmd["list"], ZoneRoute)

        cmdstr = dkjson.encode(cmd)
        if (cmdstr ~= nil) then
            dev_config.fetch("add","safeZone", cmdstr, 1)
            module_debug.lua_debug(module_debug.INFO, "INFO: safeZone update ZoneRoute finish")
        end
    end
end


local function add_default_wan_web()
    local wan_web_flag = 0
    local dev_sup_web = 0

    local data = dev_config.fetch("get","safeZone", "", 1)
    if (data == nil or data["data"] == nil) then
        return
    end
    
    local safeZone = nil
    safeZone = cjson_safe.decode(data["data"])
    if (safeZone == nil) then
        return
    end
    
    local ver = 0
    if (safeZone["ver"] ~= "nil") then
        ver = tonumber(safeZone["ver"])
    end
    
    if (ver >= 1.1) then
        return
    end

    if (file_exist(cap_file_path) == true and web ~= nil) then
        cap_json = file_to_json(cap_file_path)
        if (cap_json ~= nil) then
            if (cap_json[web] ~= nil and cap_json[web]["denyWanWeb"] ~= nil and cap_json[web]["denyWanWeb"] == "1") then
                dev_sup_web = 1
            end
        end
    end

    if (dev_sup_web == 1) then
        for k,v in pairs(safeZone["list"]) do
            if (v["type"] == "wan") then
                for k1,v1 in pairs(v["disbaleList"]) do
                    if (v1 == "web") then
                        wan_web_flag = 1
                    end
                end
                
                if (wan_web_flag == 0) then
                    table.insert(v["disbaleList"], string.lower("web"))
                end
            end
        end
    end
    
    safeZone["ver"] = "1.1"

    ret = json_write_to_file(config_file_path, safeZone)
    if (ret == -1) then
        module_debug.lua_debug(module_debug.ERROR, "update json_write_to_file failed")
        return -1
    end

end

local function add_default_wan_snmp()
    local wan_snmp_flag = 0
    local dev_sup_snmp = 0

    local data = dev_config.fetch("get","safeZone", "", 1)
    if (data == nil or data["data"] == nil) then
        return
    end
    
    local safeZone = nil
    safeZone = cjson_safe.decode(data["data"])
    if (safeZone == nil) then
        return
    end
    
    if (safeZone["ver"] ~= nil) then
        return
    end
    
    if (file_exist(cap_file_path) == true and web ~= nil) then
        cap_json = file_to_json(cap_file_path)
        if (cap_json ~= nil) then
            if (cap_json[web] ~= nil and cap_json[web]["snmp"] ~= nil and cap_json[web]["snmp"] == "1") then
                dev_sup_snmp = 1
            end
        end
    end

    if (dev_sup_snmp == 1) then
        for k,v in pairs(safeZone["list"]) do
            if (v["type"] == "wan") then
                for k1,v1 in pairs(v["disbaleList"]) do
                    if (v1 == "snmp") then
                        wan_snmp_flag = 1
                    end
                end
                
                if (wan_snmp_flag == 0) then
                    table.insert(v["disbaleList"], string.lower("snmp"))
                end
            end
        end
    end

    safeZone["ver"] = "1.0"

    ret = json_write_to_file(config_file_path, safeZone)
    if (ret == -1) then
        module_debug.lua_debug(module_debug.ERROR, "update json_write_to_file failed")
        return -1
    end

end

function main()
    add_ZoneRoute_config()

    add_default_wan_snmp()
    add_default_wan_web()

    ret = file_exist(local_safe_file)
    if (ret ~= nil) then
        content = file_to_json(local_safe_file)
        if (content == nil) then
            return
        end
        
        update_config(content)
        
        os.remove(local_safe_file)
    end
    
    ret = file_exist(local_safe_iptables)
    if (ret ~= nil) then
        os.remove(local_safe_iptables)
    end
end

main()