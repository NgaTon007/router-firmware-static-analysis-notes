# 快速信道切换模块fastAutoChan

SD_CONFIG_TMP_DIR="/tmp/sd_config/"
="/tmp/sd_config/"
FASTAUTOCHAN_LOG="${SD_CONFIG_TMP_DIR="/tmp/sd_config/"
}fastAutoChan.log"

debug_fau() {
    local time=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$time][$$]:$1" >> ${FASTAUTOCHAN_LOG}
}


if [ -e ${FASTAUTOCHAN_LOG} ]; then
    log_byte=$(ls -l $FASTAUTOCHAN_LOG | awk '{print $5}')
    [ ${log_byte} -gt 512 ] && { rm -rf ${FASTAUTOCHAN_LOG}; }
fi

# 根据随机数产生随机值
rand() {
    local min=$1
    local max=$(($2-$min+1))
    local num

    num=$(tr -cd 0-9 </dev/urandom | head -c 8) 2> /dev/null
    num=$(printf "%.f\n" $num)
    echo $(($num%$max+$min))
}

#高通自动信道调整
qca_set_auto_channel() {
    local ifname=$1
    local sub_ifname

    for sub_ifname in `ls /sys/class/net/ | grep "${ifname}"`
    do
        iwconfig $sub_ifname channel 0 &
    done
}

#MTK自动信道调整
mtk_set_auto_channel() {
    local ifname=$1

    debug_fau "ifname: ${ifname}"
    iwpriv $ifname set AutoChannelSel=3 &
}

# set入口
fastAutoChan_set() {
    local param=$1
    local randNum
    local type
    local delay
    local set_auto="false"
    local type
    local channel
    local ifname2g
    local ifname5g
    local sdk
    
    randNum=$(echo "${param}" | jq  -r '.randNum')
    if [ "$randNum" = "null" -o "$randNum" = "" ]; then
        randNum=30
    fi

    # 随机数检查
    expr $randNum + 10 &> /dev/null
    if [ $? -ne 0 ];then
        debug_fau "randNum:$randNum is not number!"
        return
    fi
    # 最大值300
    if [ $randNum -gt 300 ]; then
        randNum=300
    fi

    delay=$(rand 0 $randNum)
    debug_fau "sleep ${delay}s"
    # 延迟生效
    sleep $delay
    # 获取当前设备芯片厂家
    sdk=`dev_cap get -m wireless | jq -r '.sdk'`
    if [ "$sdk" = "mtk" ]; then
        debug_fau "sdk is mtk"
        # 当前信道判断 auto才执行
        ifname2g=`uci -q get wifiinfo.band_2g.ext_ifname`
        ifname5g=`uci -q get wifiinfo.band_5g.ext_ifname`
        ifname2g=$ifname2g"0"
        ifname5g=$ifname5g"0"
        local i=0
        while true
        do
            type=$(dev_config get -m radio | jq -r .radioList[$i].type)
            channel=$(dev_config get -m radio | jq -r .radioList[$i].channel)
            if [ "$type" = "null" -o "$type" = "" ]; then
                debug_fau "radioNum=$i end"
                break
            fi
            if [ "$channel" = "auto" ];then
                if [ "$type" = "2.4G" ]; then
                    debug_fau "iwpriv $ifname2g set AutoChannelSel=3"
                    mtk_set_auto_channel $ifname2g
                    set_auto="true"
                elif [ "$type" = "5G" ]; then
                    debug_fau "iwpriv $ifname5g set AutoChannelSel=3"
                    mtk_set_auto_channel $ifname5g
                    set_auto="true"
                fi
            fi
            i=`expr $i + 1`
        done
    elif [ "$sdk" = "qca" ]; then
        debug_fau "sdk is qca"
        # 当前信道判断 auto才执行
        if [ "$(uci -q get wireless.wifi0.channel)" = "auto" ];then
            debug_fau "iwconfig ath0 channel 0"
            qca_set_auto_channel "ath0"
            set_auto="true"
        fi

        if [ "$(uci -q get wireless.wifi1.channel)" = "auto" ];then
            debug_fau "iwconfig ath1 channel 0"
            qca_set_auto_channel "ath1"
            set_auto="true"
        fi
    else
        debug_fau "sdk unknown"
    fi

    if [ "$set_auto" = "true" ]; then
        sleep 5
        mqtt_inform_notify &> /dev/null
    fi
}

fastAutoChan_set "$1"
