#!/usr/bin/lua
require "public_module"
lib_debug = require "utils.debug"
cjson = require "cjson"
require("uci")
ubus = require "ubus"

local x = uci.cursor()
local wan_list = {};
local wan_num = 0
local modul = "network.interface."
local method = "status"

lib_debug.debug_init("/tmp/debug/rp-pppoe/", "default_route.log", 100, lib_debug.DEBUG, "1")
lib_debug.lua_debug(lib_debug.DEBUG, "start\n")

local network_cfg = "/etc/config/network"

--[[1、遍neiwork配置文件，遍历interface类型配置节，记录协议为pppoe的配置节名称（wan、wan1）
2、通过ifstatus wan（wan1），获取"l3_device": "pppoe-wan"参数
3、根据参数检测ip route，如果没有该规则，则ifup wan（wan1）
]]

function ubus_call(modul, method, data)
    local result = {}
    
    local conn = ubus.connect()
    if not conn then
        return 1
    end

    result = conn:call(modul, method, data)
    if (result == nil) then
        return 1

    end
    
    return cjson.encode(result)
end

function ip_route_handle(intf, server_ip, local_ip)
    lib_debug.lua_debug(lib_debug.DEBUG, "---------- ip_route_handle start -----------\n")

    local def_route = "defaultvia"..local_ip.."dev"..intf.."protostatic"
    local port_route = local_ip.."dev"..intf.."protokernelscopelinksrc"..server_ip
    
    lib_debug.lua_debug(lib_debug.DEBUG, "def_route:%s\n", def_route)
    lib_debug.lua_debug(lib_debug.DEBUG, "port_route:%s\n", port_route)

    --system("ip route | grep "..def_route.." >&- && echo up || echo down")
    local do_def = io.popen("ip route | sed s/[[:space:]]//g | grep \""..def_route.."\" >&- && echo on || echo off")
    local def_ret = do_def:read("*all")
    local do_port = io.popen("ip route | sed s/[[:space:]]//g | grep \""..port_route.."\" >&- && echo on || echo off")
    local port_ret = do_port:read("*all")
    
    def_ret = string.sub(def_ret, 0, 2)
    port_ret = string.sub(port_ret, 0, 2)
    lib_debug.lua_debug(lib_debug.DEBUG, "def_ret:%s   port_ret:%s\n", def_ret, port_ret)
    
    if (def_ret ~= "on" or port_ret ~= "on") then
        --pppoe-wan
        local first_sub = string.sub(intf, 7)
        os.execute("ifup "..first_sub.." &")
        lib_debug.lua_debug(lib_debug.DEBUG, "ifup :%s !!!\n", first_sub)
        return
    end
        lib_debug.lua_debug(lib_debug.DEBUG, "%s is normal !!!\n", intf)
    
end

function ip_load(intf_wan)
    lib_debug.lua_debug(lib_debug.DEBUG, "---------- ip_load start -----------\n")
    local ip_get = io.popen("ip addr show pppoe-"..intf_wan.." 2>/dev/null|grep \"inet \"")
    local intf_exist = ip_get:read("*all")
    
    if (string.len(intf_exist) == 0) then
        lib_debug.lua_debug(lib_debug.DEBUG, "%s is down !!!\n", intf_wan)
        return
    end
        
    local list = string.gsub(intf_exist, "%s+", "")
    lib_debug.lua_debug(lib_debug.DEBUG, "list:%s\n", list)
    
    local num = string.find(list, "inet", 1) 
    local addr_start = num + 4
    num = string.find(list, "peer", 1) 
    local addr_end = num - 1
    local server_ip = string.sub(list, addr_start, addr_end)
    lib_debug.lua_debug(lib_debug.DEBUG, "server_ipcat:%s\n", server_ip)
    
    num = string.find(list, "peer", 1) 
    addr_start = num + 4
    num = string.find(list, "/", 1) 
    addr_end = num - 1
    local local_ip = string.sub(list, addr_start, addr_end)
    lib_debug.lua_debug(lib_debug.DEBUG, "local_ip:%s\n", local_ip)
    intf = "pppoe-"..intf_wan
    
    
    ip_route_handle(intf, server_ip, local_ip)
end

function ipaddr_load()
    lib_debug.lua_debug(lib_debug.DEBUG, "---------- ipaddr_load start -----------\n")
    local result
    
    for i = 1, #wan_list do 
        result = {}
        lib_debug.lua_debug(lib_debug.DEBUG, "wan_list[i]:%s\n", wan_list[i])

        ip_load(wan_list[i])
    end 
end

function network_load()
    lib_debug.lua_debug(lib_debug.DEBUG, "---------- network_load start -----------\n")
    x:foreach("network", "interface", function(s)
    repeat    
        if (s['proto'] ~= "pppoe") then
            break;
        end
        lib_debug.lua_debug(lib_debug.DEBUG, "s['.name']:%s\n", s['.name'])
        wan_num = wan_num + 1
        wan_list[wan_num] = s['.name']
    until true
    end)
end

function port_status_load()
    network_load()
    ipaddr_load()
end

port_status_load()
