local x = require("luci.model.uci").cursor()
local cjson = require "cjson" 
local lib_app = require "flowctrl.flowctrl_app"
require "public_module"

local name_is_exist=0
local cfg_index=0
local old_section
local default_tc_pri=lib_app.default_tc_pri
local update_policy_id
local update_tr_group
local DEBUG_LOG_DIR="/tmp/flowctrl/"
local module_debug = require "utils.debug"
local fc_wan_grp={}
local intf_grp_cap = 0

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "opteration.log", 500, module_debug.DEBUG, "1");
end

local function is_spt_pppoe_user_group()
	local cmd = "cat /tmp/sd_device/sd_device.json | jq .gateway.spt_pppoe_user_group | sed 's/\"//g' | xargs echo -n"
	local t = io.popen(cmd)
    local spt_pppoe_user_group = t:read("*all")
    t:close()
    spt_pppoe_user_group = string.gsub(spt_pppoe_user_group, "\n", "")

    if (spt_pppoe_user_group ~= "1") then
        return false
    end
	return true
end

-- 添加关联用户组
local function add_auth_grp(name, uuid)
    local addr_root_grp = {}
    local addr_second_grp = {}
    local addr_first_grp = {}
    addr_root_grp["groups"] = {}
    addr_first_grp["id"] = "2"
    addr_first_grp["child"] = {}
    addr_second_grp["name"] = name
    if uuid ~= nil and uuid ~= "" then
        addr_second_grp["uuid"] = uuid
    end
    addr_second_grp["role"] = "group"
    addr_second_grp["auto"] = "false"
    addr_second_grp["type"] = "auth"
    table.insert(addr_first_grp["child"], addr_second_grp)
    table.insert(addr_root_grp["groups"], addr_first_grp)
    local config_tab = cjson.encode(addr_root_grp)
    local cmd = "dev_config add -m user_group '"..config_tab.."' >> /tmp/flowctrl/opteration.log 2>&1"
    os.execute(cmd)
	return 0
end

-- 删除关联用户组
local function del_auth_grp(name)
    local del_root_grp = {}
    del_root_grp["id"] = {}

	x:foreach("user_mgr", "user_grp", function(s)
        namecode = s[".name"]
        policy_name = x:get("user_mgr", namecode, "name")
		policy_type = x:get("user_mgr", namecode, "type")
        if (policy_name ~= nil and policy_name == name and policy_type == "auth") then
            table.insert(del_root_grp["id"], namecode)
			return
        end		
    end
    )

    local cmd = "dev_config del -m user_group '"..cjson.encode(del_root_grp).."' >> /tmp/flowctrl/opteration.log 2>&1"
    os.execute(cmd)
end

local function delete_for_update_json_config_rule(rule_name, config_table)
    local ret = 0
    for k,v in pairs(config_table["list"]) do
		if (v["comment"] == rule_name) then
            table.remove(config_table["list"], k)
			break
        end
    end
    return 0
end

local function check_policy(enable_s, intf, intf_type, intf_uuid, intf_list)
    local version=x:get("app_identify","signature","version")
    local ret = false

    ret = lib_app.check_intf(intf, intf_type, intf_uuid, intf_list, fc_wan_grp, intf_grp_cap)
    if (ret == false) then
        return 0
    end

	if (enable_s == "off") then
		return 0
	end

    return 1
end

local function check_name_is_exist(rule_name)
	x:foreach("flowctrl", "pppoe_policy", function(s)
		local name = s[".name"]
		if (x:get("flowctrl", name, "comment") == rule_name) then
			name_is_exist = 1
			cfg_index = s[".index"]
			old_section = name
			update_policy_id = x:get("flowctrl", name, "policy_id")
			update_tr_group = x:get("flowctrl", name, "tr_group")
			return
		end
    end)
	return
end

--如果没配置过自定义策略，则插入位置放最后；否则插入到第一条的位置。(150足够)
local first_index=150
local function find_first_rule_index()
	x:foreach("flowctrl", "pppoe_policy", function(s)
		--return没用，会一直赋值
		if (first_index == 150) then
			first_index = s[".index"]
		end
		return
    end)
end

local last_index=0
local function find_last_rule_index()
	x:foreach("flowctrl", "pppoe_policy", function(s)
		last_index = s[".index"]
    end)
end

--删除框架配置文件中的规则
local function delete_json_config_rule(rule_name, config_table)
    local ret = 0
	local del_pri
    for k,v in pairs(config_table["list"]) do
		if (v["comment"] == rule_name) then
            table.remove(config_table["list"], k)
			break
        end
    end
    return 0
end

local function del_uci_config_by_rule_name(rule_name)
	local policy_id
	local del_tr_group

	x:foreach("flowctrl", "pppoe_policy", function(s)
		local name = s[".name"]
		if (x:get("flowctrl", name, "comment") == rule_name) then
			--策略删除后也要删除对应ipset 不然策略一多 ipset组就多
			policy_id = tonumber(x:get("flowctrl", name, "policy_id"))
			local ipset=policy_id-1
			del_tr_group=x:get("flowctrl", name, "tr_group")
			--时间组解引用，auto组计数为0会自动删除
			if(del_tr_group ~= nil) then
				lib_app.deref_time_config(del_tr_group)
			end
			os.execute("ipset destroy fc_pppoe_"..ipset.." 2>/dev/null")
			x:delete("flowctrl", name)
		end
    end)
end

local function fill_new_section_and_rule(new_section, new_rule, input_param, policy_id, tr_group_name, tr_type)
	local enable_s = input_param["enable"]
	x:set("flowctrl", new_section, "enable", enable_s)
	new_rule["enable"] = enable_s
	--非遍历处理，增量导致这个fc_rule_x的下标不好生成，规则删除会导致重复。(放实现内部来生成)。
	local group_name="fc_pppoe_"..policy_id-1
	x:set("flowctrl", new_section, "pppoe_group", group_name)
	new_rule["pppoeGroup"] = group_name
	--流控重启不会创建ipset了，因此放这里创建
	os.execute("ipset create "..group_name.." ".."hash:net -exist 2>/dev/null")
	local intf=input_param["intf"]
	x:set("flowctrl", new_section, "intf", intf)
	new_rule["intf"] = intf
	x:set("flowctrl", new_section, "comment", input_param["comment"])
	new_rule["comment"] = input_param["comment"]
	x:set("flowctrl", new_section, "policy_id", policy_id)
	new_rule["policyId"] = tostring(policy_id)
	x:set("flowctrl", new_section, "pri", lib_app.pppoe_pri)
	new_rule["pri"] = tostring(lib_app.pppoe_pri)
	if (input_param["tcPri"] ~= nil) then
		x:set("flowctrl", new_section, "tc_pri", input_param["tcPri"])
		new_rule["tcPri"] = tostring(input_param["tcPri"])
	else
		x:set("flowctrl", new_section, "tc_pri", tostring(default_tc_pri))
	end

	--新增时间管理
	local tr_effective
	local tr_slots = input_param["tr_slots"]
	local tr_range = input_param["tr_range"]
	if (tr_type ~= nil and #tr_type > 0) then
		if(tr_group_name ~= nil and tr_group_name:sub(1, 3) == "fc_") then
			if (tr_type == lib_app.tr_week_type) then
				new_rule["tr_type"] = tr_type
				x:set("flowctrl", new_section, "tr_type", tr_type)
				x:set("flowctrl", new_section, "tr_slots", cjson.encode(tr_slots))
				x:set("flowctrl", new_section, "tr_group", tr_group_name)
				new_rule["tr_slots"] = tr_slots
				new_rule["tr_group"] = ""
				new_rule["tr_range"] = {}
				lib_app.ref_time_config(tr_group_name)
				tr_effective=lib_app.check_policy_tr(tr_group_name)
				--云端不关心tr_effective
				-- new_rule["tr_effective"] = tostring(tr_effective)
			--入参有检验，不是week就是date
			else
				new_rule["tr_type"] = tr_type
				x:set("flowctrl", new_section, "tr_type", tr_type)
				x:set("flowctrl", new_section, "tr_range", cjson.encode(tr_range))
				x:set("flowctrl", new_section, "tr_group", tr_group_name)
				new_rule["tr_range"] = tr_range
				new_rule["tr_group"] = ""
				new_rule["tr_slots"] = {}
				lib_app.ref_time_config(tr_group_name)
				tr_effective=lib_app.check_policy_tr(tr_group_name)
				--云端不关心tr_effective
				-- new_rule["tr_effective"] = tostring(tr_effective)
			end
		else
			module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_group_name[%s] error", input_param["comment"], tr_group_name);
			new_rule["tr_group"] = ""
			new_rule["tr_slots"] = {}
			new_rule["tr_range"] = {}
			new_rule["tr_type"] = ""
			tr_effective = 1
			--云端不关心tr_effective
			-- new_rule["tr_effective"] = "1"
		end
	elseif (tr_group_name ~= nil and #tr_group_name > 0) then
		x:set("flowctrl", new_section, "tr_group", tr_group_name)
		new_rule["tr_group"] = tr_group_name
		new_rule["tr_slots"] = {}
		new_rule["tr_range"] = {}
		new_rule["tr_type"] = ""
		lib_app.ref_time_config(tr_group_name)
		tr_effective=lib_app.check_policy_tr(tr_group_name)
		-- new_rule["tr_effective"] = tostring(tr_effective)
	else
		new_rule["tr_group"] = ""
		new_rule["tr_slots"] = {}
		new_rule["tr_range"] = {}
		new_rule["tr_type"] = ""
		tr_effective = 1
		-- new_rule["tr_effective"] = "1"
	end

	if (tr_effective ~= nil) then
		x:set("flowctrl", new_section, "tr_effective", tr_effective)
	else
		x:set("flowctrl", new_section, "tr_effective", 1)
	end

	local mode = nil
	mode = input_param["mode"]
	if (mode == nil) then
		x:set("flowctrl", new_section, "mode", "per_ip")
		new_rule["mode"] = "per_ip"
	else
		x:set("flowctrl", new_section, "mode", mode)
		new_rule["mode"] = mode
	end

	--为了兼容老版本下发配置所以做了个非空判断
	--"allUpRate":""时 input_param["allUpRate"]非空，但是tonumber(input_param["allUpRate"]为空，认为是不限速模式
	if (tonumber(input_param["allUpRateG"]) ~= nil) then
		x:set("flowctrl", new_section, "all_up_rate", input_param["allUpRate"])
		x:set("flowctrl", new_section, "all_down_rate", input_param["allDownRate"])
		x:set("flowctrl", new_section, "all_up_rate_g", input_param["allUpRateG"])
		x:set("flowctrl", new_section, "all_down_rate_g", input_param["allDownRateG"])
		new_rule["allUpRate"] = input_param["allUpRate"]
		new_rule["allDownRate"] = input_param["allDownRate"]
		new_rule["allUpRateG"] = input_param["allUpRateG"]
		new_rule["allDownRateG"] = input_param["allDownRateG"]
		if (mode=="share") then
			x:set("flowctrl", new_section, "down_rate_g", input_param["allDownRateG"])
			x:set("flowctrl", new_section, "up_rate_g", input_param["allUpRateG"])
			x:set("flowctrl", new_section, "down_rate", input_param["allDownRate"])
			x:set("flowctrl", new_section, "up_rate", input_param["allUpRate"])
			new_rule["downRateG"] = input_param["allDownRateG"]
			new_rule["upRateG"] = input_param["allUpRateG"]
			new_rule["downRate"] = input_param["allDownRate"]
			new_rule["upRate"] = input_param["allUpRate"]
		else
			local down_rate=tonumber(input_param["downRate"])
			local up_rate=tonumber(input_param["upRate"])
			--为nil就认为不限速
			if (down_rate ~= nil) then
				x:set("flowctrl", new_section, "down_rate", down_rate)
				new_rule["downRate"] = tostring(down_rate)
			else
				x:set("flowctrl", new_section, "down_rate", lib_app.rate_tag)
				new_rule["downRate"] = ""
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", new_section, "up_rate", up_rate)
				new_rule["upRate"] = tostring(up_rate)
			else
				x:set("flowctrl", new_section, "up_rate", lib_app.rate_tag)
				new_rule["upRate"] = ""
			end
			
			local down_rate_g=math.floor(tonumber(input_param["allDownRateG"])/lib_app.pppoe_cnt)
			local up_rate_g=math.floor(tonumber(input_param["allUpRateG"])/lib_app.pppoe_cnt)
			--有可能每用户保障大于每用户最大
			if (down_rate ~= nil and down_rate_g > down_rate) then
				down_rate_g = down_rate
			end
			if (down_rate_g >= 1) then
				x:set("flowctrl", new_section, "down_rate_g", down_rate_g)
				new_rule["downRateG"] = tostring(down_rate_g)
			else
				x:set("flowctrl", new_section, "down_rate_g", 1)
				new_rule["downRateG"] = "1"
			end
			if (up_rate ~= nil and up_rate_g > up_rate) then
				up_rate_g = up_rate
			end

			if (up_rate_g >= 1) then
				x:set("flowctrl", new_section, "up_rate_g", up_rate_g)
				new_rule["upRateG"] = tostring(up_rate_g)
			else
				x:set("flowctrl", new_section, "up_rate_g", 1)
				new_rule["upRateG"] = "1"
			end
		end
	else	--不限速模式
		if (tonumber(input_param["upRateG"]) == nil) then
			x:set("flowctrl", new_section, "all_up_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_down_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "down_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "up_rate", lib_app.rate_tag)
			new_rule["allUpRate"] = ""
			new_rule["allDownRate"] = ""
			new_rule["allUpRateG"] = ""
			new_rule["allDownRateG"] = ""
			new_rule["downRateG"] = ""
			new_rule["upRateG"] = ""
			new_rule["downRate"] = ""
			new_rule["upRate"] = ""
		else --此状态为老流控的web下发
			if (mode=="share") then--share模式下配置uprate就为用户组带宽
				x:set("flowctrl", new_section, "all_up_rate", input_param["upRate"])
				x:set("flowctrl", new_section, "all_down_rate", input_param["downRate"])
				x:set("flowctrl", new_section, "all_up_rate_g", input_param["upRateG"])
				x:set("flowctrl", new_section, "all_down_rate_g", input_param["downRateG"])
				new_rule["allUpRate"] = input_param["upRate"]
				new_rule["allDownRate"] = input_param["downRate"]
				new_rule["allUpRateG"] = input_param["upRateG"]
				new_rule["allDownRateG"] = input_param["downRateG"]
			else--per_ip模式下，uprate为每用户带宽，用户组带宽要后面处理为接口带宽，这里打标记
				--all_up_rate_g可能会大于all_up_rate，放在flowctrl_tc_cfg中考虑，这边接口带宽未知，所以不做处理
				local all_up_rate_g=tonumber(input_param["upRateG"])*lib_app.pppoe_cnt
				local all_down_rate_g=tonumber(input_param["downRateG"])*lib_app.pppoe_cnt
				local all_up_rate=lib_app.max_rate_tag
				local all_down_rate=lib_app.max_rate_tag
				if (all_up_rate_g > tonumber(all_up_rate)) then
					all_up_rate_g=all_up_rate
				end

				if (all_down_rate_g > tonumber(all_down_rate))then
					all_down_rate_g=all_down_rate
				end

				--直接给个默认最大值，保证除不限速模式下all_up_rate，all_down_rate都有值
				x:set("flowctrl", new_section, "all_up_rate", all_up_rate)
				x:set("flowctrl", new_section, "all_down_rate", all_down_rate)
				x:set("flowctrl", new_section, "all_up_rate_g", all_up_rate_g)
				x:set("flowctrl", new_section, "all_down_rate_g", all_down_rate_g)
				new_rule["allUpRate"] = all_up_rate
				new_rule["allDownRate"] = all_down_rate
				new_rule["allUpRateG"] = tostring(all_up_rate_g)
				new_rule["allDownRateG"] = tostring(all_down_rate_g)
			end
			x:set("flowctrl", new_section, "down_rate", input_param["downRate"])
			x:set("flowctrl", new_section, "up_rate", input_param["upRate"])
			x:set("flowctrl", new_section, "down_rate_g", input_param["downRateG"])
			x:set("flowctrl", new_section, "up_rate_g", input_param["upRateG"])
			new_rule["downRate"] = input_param["downRate"]
			new_rule["upRate"] = input_param["upRate"]
			new_rule["downRateG"] = input_param["downRateG"]
			new_rule["upRateG"] = input_param["upRateG"]
		end
	end

	local whole_wan = input_param["wholeWan"]
	if (whole_wan ~= nil) then
		new_rule["wholeWan"] = tostring(input_param["wholeWan"])
		x:set("flowctrl", new_section, "wholeWan", input_param["wholeWan"])
	else
		new_rule["wholeWan"] = "0"
		x:set("flowctrl", new_section, "wholeWan", "0")
	end

	--直接检测生效性，便于能够快速get
    local intf_list = input_param["intfGrpList"]
    local intf_type = input_param["intfGrpType"]
    local intf_uuid = input_param["intfGrpUuid"]
	local effective=check_policy(enable_s, intf, intf_type, intf_uuid, intf_list)
	x:set("flowctrl", new_section, "effective", effective) ---默认-1，用以WEB区分是否内部判断完生效性。
	-- new_rule["effective"] = tostring(effective)
end

local function update_config_policy(jsonStr, config_table)
	local tr_type
	local tr_group_name

	--list为空以及超过1个元素
	if (#jsonStr["list"] == 0 or #jsonStr["list"] > 1) then
        module_debug.lua_debug(module_debug.ERROR, "param list is empty or too big");
		return -1
	end

	local rule_name = jsonStr["list"][1]["comment"]
	check_name_is_exist(rule_name)
	if (name_is_exist == 0) then
        module_debug.lua_debug(module_debug.ERROR, "the policy not exist");
		return -1
	end

	if (update_policy_id == nil) then --旧配置可能会出现这种情况
        module_debug.lua_debug(module_debug.ERROR, "the policy have no policy id");
		return -1
	end

	--新增时间管理参数检查
    if (lib_app.fc_tmngt_grp_check(jsonStr["list"][1]) < 0) then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tmnt group check failed", jsonStr["list"][1]["comment"]);
        return -1;
    end

	if (name_is_exist ~= 0) then --检查名字不重，这样名字可改
		--新增时间管理,先解引用时间组
		if(update_tr_group ~= nil) then
			lib_app.deref_time_config(update_tr_group)
		end

		--新增时间管理
        local tr_type = jsonStr["list"][1]["tr_type"]
        local tr_slots = jsonStr["list"][1]["tr_slots"]
        local tr_range = jsonStr["list"][1]["tr_range"]
        local tr_group_name = jsonStr["list"][1]["tr_group"]
		if (tr_type ~= nil and #tr_type ~= 0) then
			tr_group_name="fc_pppoe_"..update_policy_id
			if (tr_type == lib_app.tr_week_type) then
				lib_app.update_time_config(tr_group_name, cjson.encode(tr_slots), "auto", lib_app.tr_week_type)
			else
				lib_app.update_time_config(tr_group_name, cjson.encode(tr_range), "auto", lib_app.tr_date_type)
			end
		end

		--无table.update操作，只能删除旧的节点，重新添加。
		x:delete("flowctrl", old_section)
		delete_for_update_json_config_rule(rule_name, config_table)
		local uci_section = x:add("flowctrl", "pppoe_policy")
		local new_rule = {}
		fill_new_section_and_rule(uci_section, new_rule, jsonStr["list"][1], update_policy_id, tr_group_name, tr_type)
		-- 移到原始的位置
		x:reorder("flowctrl", uci_section, cfg_index)
		table.insert(config_table["list"], new_rule)
		return 0
	end
	
	return -1
end

local moved=0
local function move_config_policy(policy_id, opt, config_table, total_rule)
	moved = 0
	x:foreach("flowctrl", "pppoe_policy", function(s)
		if (moved ~= 0) then
			return
		end
		local name = s[".name"]
		if (x:get("flowctrl", name, "policy_id") == policy_id) then
			-- !!! 注意up要把配置往下移动，down要把配置往上移动，方向是反的。
			if (opt == "up") then
				find_last_rule_index()
				if (last_index ~= 0) then
					if (last_index ~= s[".index"]) then
						x:reorder("flowctrl", name, s[".index"] + 1)
						moved = 1
					end
				end
			else
				find_first_rule_index()
				if (first_index ~= 150) then
					--只有一条不移动，避免直接操作dev_config导致uci文件顺序错乱。
					--正好是第一条要上移，此时索引相等，条数大于1条，则可上移。
					if (first_index ~= s[".index"]) then
						x:reorder("flowctrl", name, s[".index"] - 1)
						moved = 1
					end
				end
			end
			return
		end
    end)
	--json配置文件不移动，内部实现都是用uci配置文件，给web展示也用uci配置文件。
end

local function del_config_policy(rulename,config_table)
	for i, value in pairs(rulename) do
		del_uci_config_by_rule_name(value)
		delete_json_config_rule(value, config_table)
		-- 删除用户组
		if is_spt_pppoe_user_group() == true then
			del_auth_grp("pppoe_"..value)
		end
	end
end

local function add_config_policy(jsonStr,config_table)
	--list为空以及超过1个元素
	if (#jsonStr["list"] == 0 or #jsonStr["list"] > 1) then
        module_debug.lua_debug(module_debug.ERROR, "param list is empty or too big");
		return -1
	end

	check_name_is_exist(jsonStr["list"][1]["comment"])
	if (name_is_exist ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "rule is exist");
		return -1
	end

	--新增时间管理参数检查
    if (lib_app.fc_tmngt_grp_check(jsonStr["list"][1]) < 0) then
        module_debug.lua_debug(module_debug.ERROR, "policy[%s] tmnt group check failed", jsonStr["list"][1]["comment"]);
        return -1;
    end

	--先确定位置，再新增节点
	find_last_rule_index()
	local uci_section = x:add("flowctrl", "pppoe_policy")
	--计算policy_id
	local policy_id = lib_app.clc_policy_id(lib_app.pppoe_tag)
	local new_rule = {}

	--新增时间管理
	local tr_type = jsonStr["list"][1]["tr_type"]
	local tr_slots = jsonStr["list"][1]["tr_slots"]
	local tr_range = jsonStr["list"][1]["tr_range"]
	local tr_group_name = jsonStr["list"][1]["tr_group"]

	if (tr_type ~= nil and #tr_type ~= 0) then
		tr_group_name="fc_pppoe_"..policy_id
		if (tr_type == lib_app.tr_week_type) then
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_slots), "auto", lib_app.tr_week_type)
		else
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_range), "auto", lib_app.tr_date_type)
		end
	end

	fill_new_section_and_rule(uci_section, new_rule, jsonStr["list"][1],policy_id, tr_group_name, tr_type)
	-- 没有自定义策略则放最后，有则放最后那条自定义策略的位置+1。需要先找位置，避免直接放最后，导致配置文件很乱。
	if (last_index ~= 0) then
		x:reorder("flowctrl", uci_section, last_index + 1)
	else
		--150个配置项足够，能够确保在最后。
		x:reorder("flowctrl", uci_section, 150)
	end
	table.insert(config_table["list"], new_rule)
	-- 生成用户组
	if is_spt_pppoe_user_group() == true then
		if add_auth_grp("pppoe_"..jsonStr["list"][1]["comment"], nil) == -1 then
			return -1
		end
	end

	return 0
end

local function main()
    debug_init()
	if (arg[1] == nil or arg[2] == nil or arg[3] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "parameter is null");
		os.exit(1)
	end

	local ret = 0
	local jsonStr = cjson.decode(arg[2]);
	config_file = arg[3] --增量配置需要写框架配置文件
	config_table = public_module.read_file(config_file)
	if (config_table == nil) then
        module_debug.lua_debug(module_debug.ERROR, "parameter is null");
		os.exit(1)
	end

    --获取接口组能力值
    intf_grp_cap = lib_app.get_intf_grp_capability()

    x:foreach("flowctrl","bandwidth",function(s)
        if (x:get("flowctrl",s[".name"],"itfs_exist") ~= "0") then
            fc_wan_grp[s[".name"]]=1
        end
    end)

	if (arg[1] == "add") then
		--新增policy_id
		ret = add_config_policy(jsonStr,config_table)
		if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "[PPPOE]add_config_policy fail");
			os.exit(1)
		end
	elseif (arg[1] == "del") then
		del_config_policy(jsonStr["rulename"],config_table)
	else
		--处理更新
		--更新单个规则
		ret = update_config_policy(jsonStr,config_table)
		if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "[PPPOE]update_config_policy fail");
			os.exit(1)
		end
	end
	
	x:commit("flowctrl")
	public_module.write_file(config_table, config_file)
    module_debug.lua_debug(module_debug.INFO, "[PPPOE] policy config success");
end

main()
