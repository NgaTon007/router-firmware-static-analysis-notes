package.path = string.format("%s;%s;/www/guest_auth/?.lua", package.path, "./?.lua")
lib_param = require("libc2lua")
local x = require("luci.model.uci").cursor()

--  dev_sta set -m app_auth '{"func": "app_auth_set_user_down", "list":[{"name":"xxxxxx", "user_type":"pppoe_charge|wifidog"}]}'

local function param_safety_check_local(param)
    if (param == nil) then
        return true
    end

    if (string.match(param, "([ ><])") == nil) then
        return true
    else
        return false
    end
end

if (lib_param.lua_param_safety_check(arg[1]) ~= true) then
    print("{\"code\":\"-1\", \"msg\":\"parameter unsafe\"}")
    return
end

local cjson = require "luci.json"  
local jsonStr = cjson.decode(arg[1]);
if jsonStr["list"] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter error\"}")
    return
end

for _, value in ipairs(jsonStr["list"]) do
    if (value["name"] ~= nil and value["user_type"] ~= nil
        and param_safety_check_local(value["name"]) == true
        and param_safety_check_local(value["user_type"]) == true) 
    then
        if (value["user_type"] == "pppoe_charge" or value["user_type"] == "wifidog") then
            local cmd = string.format("/usr/sbin/app_auth_hook.elf -u %s -T %s -k", value["name"], value["user_type"])
            os.execute(cmd)
        end 
    end
end
