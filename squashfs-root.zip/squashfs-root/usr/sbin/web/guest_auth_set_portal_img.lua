package.path = string.format("%s;%s;/www/guest_auth/?.lua", package.path, "./?.lua")
local module_debug = require "utils.debug"
lib_param = require("libc2lua")
local tool = require "dev.tools.common"
local cjson = require "luci.json" 
local fs = require "nixio.fs"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local x = require "luci.model.uci".cursor()
require "pub"

local DEFAULT_IMG_MAX_SIZE = (50 * 1024)
local TMP_GUEST_AUTH_DIR = "/tmp/guest_auth/"

local param = nil
local support_img = {
    ["png"] = true,
    ["jpg"] = true,
    ["jpeg"] = true
}

local support_target = {
    ["logo"] = true,
    ["bg"] = true
}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
local function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_set_portal_img.log", 500, module_debug.INFO, "1");
end

local function param_safety_check_local(param)
    if (param == nil) then
        return true
    end

    if (string.match(param, "([ ><])") == nil) then
        return true
    else
        return false
    end
end


local function traceback(msg)
    module_debug.lua_debug(module_debug.ERROR, debug.traceback());
    print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
end

local function get_file_size(file)
    local content = tool.file_read(file)

    local size = string.len(content)

    return size
end

local function arg_check()

    param = cjson.decode(arg[1])
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "arg[1] isn't a json object");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end

    if (param["target"] == nil or param["portalId"] == nil or param["path"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "param too many");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end

    if (param["target"] == "" or param["portalId"] == "" or param["path"] == "") then
        module_debug.lua_debug(module_debug.ERROR, "param error");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end

    if (lib_param.lua_param_safety_check(param["target"]) ~= true 
            or lib_param.lua_param_safety_check(param["portalId"]) ~= true
            or lib_param.lua_param_safety_check(param["path"]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "arg isn't a safe string");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end
    if (param_safety_check_local(param["target"]) ~= true 
            or param_safety_check_local(param["portalId"]) ~= true
            or param_safety_check_local(param["path"]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "arg isn't a safe string");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end

    if (string.match(param["portalId"], "^[0-9]+$") == nil) then
        module_debug.lua_debug(module_debug.ERROR, "portalId isn't valid");
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end

    if (support_target[param["target"]] ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "target isn't valid---->" .. param["target"]);
        print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
        os.exit()
    end
end

local function shell_quote(str)
    return "'" .. string.gsub(str, "'", "'\\''") .. "'"
end

local function img_type_check()
    local path = param["path"]

    if (string.match(path, "^/tmp/guest_auth/[A-Za-z0-9_./%-]+$") == nil
            or string.sub(path, 1, #TMP_GUEST_AUTH_DIR) ~= TMP_GUEST_AUTH_DIR
            or string.find(path, "%.%.") ~= nil
            or string.find(path, "//") ~= nil
            or string.sub(path, -1) == "/") then
        module_debug.lua_debug(module_debug.ERROR, "Unsafe path---->" .. path);
        print("{\"code\":\"1\", \"msg\":\"Unknow Image Type!\"}") 
        os.exit()
    end

    local file_name = string.match(path, "([^/]+)$")
    local type = nil
    if (file_name ~= nil) then
        type = string.match(file_name, "%.([A-Za-z0-9]+)$")
    end

    if (fs.stat(path, "type") ~= "reg") then
        module_debug.lua_debug(module_debug.ERROR, "Img file type isn't regular file---->" .. path);
        print("{\"code\":\"1\", \"msg\":\"Unknow Image Type!\"}") 
        os.remove(path)
        os.exit()
    end

    if (type == nil) then
        module_debug.lua_debug(module_debug.ERROR, "Unknow Image Type---->" .. path);
        print("{\"code\":\"1\", \"msg\":\"Unknow Image Type!\"}") 
        os.remove(path)
        os.exit()
    end

    type = string.lower(type)
    if (support_img[type] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "Not support this img type---->" .. path);
        print("{\"code\":\"1\", \"msg\":\"Not support this img type!\"}")
        os.remove(path)
        os.exit()
    end

end

local function img_size_check()
    local max = nil
    local cap = cjson.decode(tool.file_read("/tmp/sd_device/sd_device.json"))
    if (cap["gateway"]["localPortalImgMaxSize"] == nil or cap["gateway"]["localPortalImgMaxSize"] == "") then
        -- 给一个默认的图片最大值
        max = DEFAULT_IMG_MAX_SIZE
    else
        max = tonumber(cap["gateway"]["localPortalImgMaxSize"]) * 1024
        if (max == nil or max == 0) then
            -- 给一个默认的图片最大值
            max = DEFAULT_IMG_MAX_SIZE
        end
    end

    if (tool.file_exist(param["path"]) == false) then
        module_debug.lua_debug(module_debug.ERROR, "Img not exist---->" .. param["path"]);
        print("{\"code\":\"1\", \"msg\":\"Img not exist!\"}") 
        os.exit()
    end
    local size = get_file_size(param["path"])
    if (size >= max) then
        module_debug.lua_debug(module_debug.ERROR, "Img too large---->" .. param["path"]);
        print("{\"code\":\"2\", \"msg\":\"Img too large!\"}") 
        os.remove(param["path"])
        os.exit()
    end

end

local function img_move()
    local cmd = ""

    cmd = string.format("/www/guest_auth/portal/portal_%s", param["portalId"])
    if (tool.file_exist(cmd) == false) then
        print("{\"code\":\"2\", \"msg\":\"portalId error!\"}") 
        os.remove(param["path"])
        os.exit()
    end

    local dst_dir = string.format("/www/guest_auth/portal/portal_%s/res/%s", param["portalId"], param["target"])
    if (fs.stat(dst_dir, "type") ~= "dir") then
        module_debug.lua_debug(module_debug.ERROR, "target dir invalid---->" .. dst_dir);
        print("{\"code\":\"2\", \"msg\":\"portalId error!\"}") 
        os.remove(param["path"])
        os.exit()
    end

    cmd = string.format("rm %s/*", shell_quote(dst_dir))
    os.execute(cmd)
    cmd = string.format("mv %s %s/", shell_quote(param["path"]), shell_quote(dst_dir))
    os.execute(cmd)
end

function main()
    module_debug.lua_debug(module_debug.DEBUG, "Start check image");
    arg_check()
    img_type_check()
    img_size_check()
    img_move()
    module_debug.lua_debug(module_debug.DEBUG, "End check image");
    print("{\"code\":\"0\", \"msg\":\"Success!\"}") 
end

debug_init()
xpcall(main, traceback)
