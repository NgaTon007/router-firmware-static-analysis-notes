--v1.2: 2022-08-23
--新增自定义应用组：jiangzehao
local x = require("luci.model.uci").cursor()
local cjson = require "cjson"
local lib_app = require "flowctrl.flowctrl_app"
local jsonStr = cjson.decode(arg[1]);
local max_udf_num = cjson.decode(arg[2]);
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR="/tmp/flowctrl/"
local default_tc_pri=lib_app.default_tc_pri
local fc_wan_grp = {}
local pppoe_grp={}
local user_grp_id_list={ id = {} }
local policy_id_grp={}
local policy_comment_grp={}
local intf_grp_cap = 0

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "opteration.log", 500, module_debug.INFO, "1");
end

local function policy_param_check()
    if (jsonStr["list"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "invalid json arg")
        return -1
    end

    if (#jsonStr["list"] > max_udf_num) then
        module_debug.lua_debug(module_debug.ERROR, "policy cnt excced %d, cnt %d", max_udf_num, #jsonStr["list"])
        return -1
    end

    for i=1, #jsonStr["list"] do
        --校验名字校验
        local comment=jsonStr["list"][i]["comment"]
        if (comment == nil or #comment == 0) then
            module_debug.lua_debug(module_debug.ERROR, "the comment of policy [%d] is missing", i);
            return -1
        end
        if (policy_comment_grp[comment] ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "the comment [%s] is repeated", comment);
            return -1
        end
        policy_comment_grp[comment] = 1

        --校验策略id校验
        if (jsonStr["list"][i]["policyId"] == nil or #jsonStr["list"][i]["policyId"] == 0) then
            module_debug.lua_debug(module_debug.ERROR, "the policyId of policy [%s] is missing", comment);
            return -1
        end

        if (policy_id_grp[jsonStr["list"][i]["policyId"]] ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "the policyId [%s] is repeated", jsonStr["list"][i]["policyId"]);
            return -1
        end

        local policy_id=tonumber(jsonStr["list"][i]["policyId"])
        if (policy_id == nil or policy_id < 1) then
            module_debug.lua_debug(module_debug.ERROR, "the policyId [%s] is invalid", jsonStr["list"][i]["policyId"]);
            return -1
        end
        policy_id_grp[jsonStr["list"][i]["policyId"]] = 1

        --校验接口/接口组
        if (lib_app.fc_intf_grp_check(jsonStr["list"][i]) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] interface group check failed", jsonStr["list"][i]["comment"]);
            return -1;
        end

        --校验时间组
        if (lib_app.fc_tmngt_grp_check(jsonStr["list"][i]) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] tmnt group check failed", jsonStr["list"][i]["comment"]);
            return -1;
        end
    end

    return 0;
end

--策略生效性检查
local function check_policy(enable_s, intf, intf_type, intf_uuid, intf_list)
    local ret = false

	if (enable_s == "off") then
		return 0
	end

    ret = lib_app.check_intf(intf, intf_type, intf_uuid, intf_list, fc_wan_grp, intf_grp_cap)
    if (ret == false) then
        return 0
    end

    return 1
end

local function is_spt_pppoe_user_group()
	local cmd = "cat /tmp/sd_device/sd_device.json | jq .gateway.spt_pppoe_user_group | sed 's/\"//g' | xargs echo -n"
	local t = io.popen(cmd)
    local spt_pppoe_user_group = t:read("*all")
    t:close()
    spt_pppoe_user_group = string.gsub(spt_pppoe_user_group, "\n", "")

    if (spt_pppoe_user_group ~= "1") then
        return false
    end
	return true
end

-- 添加关联用户组
local function add_auth_grp(name, uuid)
    local addr_root_grp = {}
    local addr_second_grp = {}
    local addr_first_grp = {}
    addr_root_grp["groups"] = {}
    addr_first_grp["id"] = "2"
    addr_first_grp["child"] = {}
    addr_second_grp["name"] = name
    if uuid ~= nil and uuid ~= "" then
        addr_second_grp["uuid"] = uuid
    end
    addr_second_grp["role"] = "group"
    addr_second_grp["auto"] = "false"
    addr_second_grp["type"] = "auth"
    table.insert(addr_first_grp["child"], addr_second_grp)
    table.insert(addr_root_grp["groups"], addr_first_grp)
    local config_tab = cjson.encode(addr_root_grp)
    local cmd = "dev_config add -m user_group '"..config_tab.."' >> /tmp/flowctrl/opteration.log 2>&1"
    os.execute(cmd)
	return 0
end

debug_init()

--获取接口组能力值
intf_grp_cap = lib_app.get_intf_grp_capability()

--新增参数校验
if (policy_param_check() < 0) then
    module_debug.lua_debug(module_debug.ERROR, "pppoe policy param check failed");
    os.exit(1);
end

x:foreach("user_mgr","user_grp",function(s)
    local type = x:get("user_mgr",s[".name"],"type")
    local name = x:get("user_mgr",s[".name"],"name")
    if (type == nil or name == nil) then
        return
    end

    if (type == "auth" and string.sub(name, 1, 5) == "pppoe") then
        pppoe_grp[name]=s[".name"]
    end
end)

--删除原有配置
x:foreach("flowctrl", "pppoe_policy", function(s)
    local comment = x:get("flowctrl", s[".name"], "comment")
    local pppoe_name = "pppoe_"..comment
    if (pppoe_grp[pppoe_name] ~= nil) then
        table.insert(user_grp_id_list.id, pppoe_grp[pppoe_name])
    end

    x:delete("flowctrl", s[".name"])
end)

if (#user_grp_id_list.id > 0) then
    module_debug.lua_debug(module_debug.ERROR, "user_grp_id_list.id: %s", cjson.encode(user_grp_id_list) );
    lib_app.fc_user_group_del(user_grp_id_list)
end

--json为空直接返回
if #jsonStr["list"] == 0 then
	x:commit("flowctrl")
	return
end

--获取wan口的map
x:foreach("flowctrl","bandwidth",function(s)
    if (x:get("flowctrl",s[".name"],"itfs_exist") ~= "0") then
        fc_wan_grp[s[".name"]]=1
    end
end)

for i=1, #jsonStr["list"] do
	local comment=jsonStr["list"][i]["comment"]
	-- 生成用户组,pppoe套餐用户在user_mgr中生成用户组，zyh
	if is_spt_pppoe_user_group() == true then
        add_auth_grp("pppoe_"..jsonStr["list"][i]["comment"], nil) 
	end

	local policy_id = jsonStr["list"][i]["policyId"]
	local pppoe_group = "fc_pppoe_"..policy_id-1
	local enable_s = jsonStr["list"][i]["enable"]
	local intf=jsonStr["list"][i]["intf"]

	local name = x:add("flowctrl", "pppoe_policy")
	--新增wholeWan
	local whole_wan = jsonStr["list"][i]["wholeWan"]
	if (whole_wan ~= nil) then
		x:set("flowctrl", name, "wholeWan", whole_wan)
	else
		x:set("flowctrl", name, "wholeWan", "0")
	end

	mode = jsonStr["list"][i]["mode"]
	if (mode == nil) then
		x:set("flowctrl", name, "mode", "per_ip")
	else
		x:set("flowctrl", name, "mode", mode)
	end
	x:set("flowctrl", name, "comment", comment)
	x:set("flowctrl", name, "enable", enable_s)
	x:set("flowctrl", name, "intf", intf)
	x:set("flowctrl", name, "policy_id", policy_id)
	x:set("flowctrl", name, "pppoe_group", pppoe_group)
	os.execute("ipset create "..pppoe_group.." ".."hash:net -exist 2>/dev/null")
    --重新添加所有策略了，因此policy_id可以重新添加,用户组和应用组也重新添加
	x:set("flowctrl", name, "pri", lib_app.pppoe_pri)

	if (jsonStr["list"][i]["tcPri"] ~= nil and #jsonStr["list"][i]["tcPri"] > 0) then
		x:set("flowctrl", name, "tc_pri", jsonStr["list"][i]["tcPri"])
	else
		x:set("flowctrl", name, "tc_pri", default_tc_pri)
	end

	--为了兼容老版本下发配置所以做了个非空判断，不能根据能力值判断新老流控下发，因为可能设备升级但是app未升级
	--"allUpRate":""时 input_param["allUpRate"]非空，但是tonumber(input_param["allUpRate"]为空，认为是不限速模式
	local all_up_rate_g=jsonStr["list"][i]["allUpRateG"]
	local all_down_rate_g=jsonStr["list"][i]["allDownRateG"]
	local all_up_rate=jsonStr["list"][i]["allUpRate"]
	local all_down_rate=jsonStr["list"][i]["allDownRate"]
	local down_rate=jsonStr["list"][i]["downRate"]
	local up_rate=jsonStr["list"][i]["upRate"]
	local down_rate_g=jsonStr["list"][i]["downRateG"]
	local up_rate_g=jsonStr["list"][i]["upRateG"]
	if (tonumber(all_up_rate_g) ~= nil) then
		--旧版本升级上来，可能有all_up_rate_g，但是all_up_rate为空(json为空，标识取接口带宽)
		if (tonumber(all_up_rate) ~= nil) then
			x:set("flowctrl", name, "all_up_rate", all_up_rate)
		else --此情况只会出现在老版本per_ip策略升级上来，没有用户组最大
			x:set("flowctrl", name, "all_up_rate", lib_app.rate_tag)
		end

		if (tonumber(all_down_rate) ~= nil) then
			x:set("flowctrl", name, "all_down_rate", all_down_rate)
		else
			x:set("flowctrl", name, "all_down_rate", lib_app.rate_tag)
		end

		x:set("flowctrl", name, "all_up_rate_g", all_up_rate_g)
		x:set("flowctrl", name, "all_down_rate_g", all_down_rate_g)
		if (mode=="share") then
			--share 模式下必须有all_down_rate和all_up_rate，per_ip下可能没有
			if (tonumber(all_down_rate) == nil) then
				module_debug.lua_debug(module_debug.INFO, "policy comment[%s], mode [share], have no [all_down_rate],is error",comment);
				x:delete("flowctrl", name)
				break
			end

			if (tonumber(all_up_rate) == nil) then
				module_debug.lua_debug(module_debug.INFO, "policy comment[%s], mode [share], have no [all_up_rate],is error",comment);
				x:delete("flowctrl", name)
				break
			end
			--share模式下tonumber(all_down_rate) == nil情况下，回退老版本策略会失效
			x:set("flowctrl", name, "down_rate_g", all_down_rate_g)
			x:set("flowctrl", name, "up_rate_g", all_up_rate_g)
			x:set("flowctrl", name, "down_rate", all_down_rate)
			x:set("flowctrl", name, "up_rate", all_up_rate)
		else --为nil就认为不限速
			local down_rate=tonumber(down_rate)
			local up_rate=tonumber(up_rate)
			if (down_rate ~= nil) then
				x:set("flowctrl", name, "down_rate", down_rate)
			else
				x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", name, "up_rate", up_rate)
			else
				x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
			end

			--每用户的保障带宽取用户组带宽/5，默认5个用户使用
			local down_rate_g=math.floor(tonumber(all_down_rate_g)/lib_app.pppoe_cnt)
			local up_rate_g=math.floor(tonumber(all_up_rate_g)/lib_app.pppoe_cnt)
			if (down_rate ~= nil and down_rate_g > down_rate) then
				down_rate_g = down_rate
			end

			if (down_rate_g >= 1) then
				x:set("flowctrl", name, "down_rate_g", down_rate_g)
			else
				x:set("flowctrl", name, "down_rate_g", 1)
			end

			if (up_rate ~= nil and up_rate_g > up_rate) then
				up_rate_g = up_rate
			end

			if (up_rate_g >= 1) then
				x:set("flowctrl", name, "up_rate_g", up_rate_g)
			else
				x:set("flowctrl", name, "up_rate_g", 1)
			end
		end
	else	--不限速模式
		if (tonumber(up_rate_g) == nil) then
			x:set("flowctrl", name, "all_up_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "all_down_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "all_up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "all_down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
		else --此状态为旧流控的web或旧app下发
			if (mode=="share") then--share模式下配置uprate就为用户组带宽
				x:set("flowctrl", name, "all_up_rate", up_rate)
				x:set("flowctrl", name, "all_down_rate", down_rate)
				x:set("flowctrl", name, "all_up_rate_g", up_rate_g)
				x:set("flowctrl", name, "all_down_rate_g", down_rate_g)
			else--per_ip模式下，uprate为每用户带宽，用户组带宽要后面处理为接口带宽，这里打标记
				--all_up_rate_g可能会大于all_up_rate，放在flowctrl_tc_cfg中考虑，这边接口带宽未知
				local all_up_rate_g=tonumber(up_rate_g)*lib_app.pppoe_cnt
				local all_down_rate_g=tonumber(down_rate_g)*lib_app.pppoe_cnt
				local all_up_rate=lib_app.max_rate_tag
				local all_down_rate=lib_app.max_rate_tag
				if (all_up_rate_g > tonumber(all_up_rate)) then
					all_up_rate_g=all_up_rate
				end

				if (all_down_rate_g > tonumber(all_down_rate))then
					all_down_rate_g=all_down_rate
				end

				x:set("flowctrl", name, "all_up_rate", all_up_rate)
				x:set("flowctrl", name, "all_down_rate", all_down_rate)
				x:set("flowctrl", name, "all_up_rate_g", all_up_rate_g)
				x:set("flowctrl", name, "all_down_rate_g", all_down_rate_g)
			end

			--新流控per_ip每用户不限速上传后带down_rate:"",云端识别到这个不会下发
			if (down_rate ~= nil) then
				x:set("flowctrl", name, "down_rate", down_rate)
			else
				x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", name, "up_rate", up_rate)
			else
				x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
			end
			x:set("flowctrl", name, "down_rate_g", down_rate_g)
			x:set("flowctrl", name, "up_rate_g", up_rate_g)
		end
	end

    local intf_list = jsonStr["list"][i]["intfGrpList"]
    local intf_type = jsonStr["list"][i]["intfGrpType"]
    local intf_uuid = jsonStr["list"][i]["intfGrpUuid"]
	local effective=check_policy(enable_s, intf, intf_type, intf_uuid, intf_list)
	x:set("flowctrl", name, "effective", effective)
end
x:commit("flowctrl")
