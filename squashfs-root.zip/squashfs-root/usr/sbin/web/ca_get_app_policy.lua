package.path = "/usr/sbin/web/?.lua;/usr/lib/lua/?.lua"

local ctmngt = require("ca_time_manager")

--[根据关键字分割文本--]
function split(str, reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

function get_app_list(app_group)
    local tab = {}
    local t = io.popen("/usr/sbin/idyc -a " .. app_group)
	local data = t:read("*all")	
    local a = split(data, '\n')
	for i=1, #a	do
	    local pos = string.find(a[i], " ")
		if(pos) then
		    local app_name = string.sub(a[i], 1, pos -1)
			table.insert(tab, app_name)
		end
	end
	return tab
end
function split_time_range(value)
    local tab = {}
	local mon_time_cnt = 1
	local tue_time_cnt = 1
	local wed_time_cnt = 1
	local thu_time_cnt = 1
	local fri_time_cnt = 1
	local sat_time_cnt = 1
	local sun_time_cnt = 1
	
	for i=1, #value do
	    local str = value[i]
		local pos1 = string.find(str, "%-")
		if(pos1) then
			local weekdays = string.sub(str, 1, pos1-1)
			local sub_str = string.sub(str, pos1+1)
			local pos2 = string.find(sub_str, "%-")
			if(pos2) then
				local time_start = string.sub(sub_str, 1, pos2-1)
				local time_stop = string.sub(sub_str, pos2+1)
				local time_node = {}
				table.insert(time_node, time_start)
				table.insert(time_node, time_stop)
				if(weekdays == "mon" or weekdays == "1") then
				    if(tab["mon"] == nil) then
					    tab["mon"] = {}
					end
					tab["mon"][mon_time_cnt] = time_node
					mon_time_cnt = mon_time_cnt + 1
				elseif(weekdays == "tue" or weekdays == "2") then
				    if(tab["tue"] == nil) then
					    tab["tue"] = {}
					end
					tab["tue"][tue_time_cnt] = time_node
					tue_time_cnt = tue_time_cnt + 1
				elseif(weekdays == "wed" or weekdays == "3") then
				    if(tab["wed"] == nil) then
					    tab["wed"] = {}
					end
					tab["wed"][wed_time_cnt] = time_node
					wed_time_cnt = wed_time_cnt + 1
				elseif(weekdays == "thu" or weekdays == "4") then
				    if(tab["thu"] == nil) then
					    tab["thu"] = {}
					end
					tab["thu"][thu_time_cnt] = time_node
					thu_time_cnt = thu_time_cnt + 1
				elseif(weekdays == "fri" or weekdays == "5") then
				    if(tab["fri"] == nil) then
					    tab["fri"] = {}
					end
					tab["fri"][fri_time_cnt] = time_node
					fri_time_cnt = fri_time_cnt + 1
				elseif(weekdays == "sat" or weekdays == "6") then
				    if(tab["sat"] == nil) then
					    tab["sat"] = {}
					end
					tab["sat"][sat_time_cnt] = time_node
					sat_time_cnt = sat_time_cnt + 1
				elseif(weekdays == "sun" or weekdays == "7") then
				    if(tab["sun"] == nil) then
					    tab["sun"] = {}
					end
					tab["sun"][sun_time_cnt] = time_node
					sun_time_cnt = sun_time_cnt + 1
				end
			end
		end
	end

	return tab
end
function main()
	local x = require("uci").cursor()
	local json_info = {}

	local section_num = 1
	local app_policy_list = {}
	x:foreach("content_audit","app_rule",function(s)
		local section_name = s[".name"]
		local policy_name = x:get("content_audit", section_name, "policy_name")
        local is_extern = x:get("content_audit", policy_name, "is_extern")
        if (is_extern ~= "1") then
            app_policy_list[section_num] = {}
		app_policy_list[section_num]["policy"] = policy_name
		-- user_group的能力值判断，get显示选择
		if (user_grp_cap == "1") then
			local content_usr = x:get("content_audit", policy_name, "usr_name")
			if (content_usr == nil) then
				return 0;
			end
			if (string.find(content_usr, "self_usr") ~= nil) then
				app_policy_list[section_num]["ip_group"] = ""
				app_policy_list[section_num]["ip_name"] = ""
				app_policy_list[section_num]["ip_slots"] = x:get("content_audit", content_usr, "ip_range")
				app_policy_list[section_num]["user_group_list"] = {}
			else
				local content_usr_grp = x:get("content_audit", policy_name, "usr_group")
				if (content_usr_grp ~= nil) then
					app_policy_list[section_num]["ip_group"] = ""
					app_policy_list[section_num]["ip_name"] = ""
					app_policy_list[section_num]["ip_slots"] = {}
					app_policy_list[section_num]["user_group_list"] = x:get("content_audit", content_usr_grp, "user_list")
				end
			end
		else
			local content_usr = x:get("content_audit", policy_name, "usr_name")
			local pos1 = string.find(content_usr, "self_usr")
			if (pos1) then
				app_policy_list[section_num]["ip_group"] = ""
				app_policy_list[section_num]["ip_name"] = ""
				app_policy_list[section_num]["ip_slots"] = x:get("content_audit", content_usr, "ip_range")
			else
				app_policy_list[section_num]["ip_group"] = content_usr
				app_policy_list[section_num]["ip_name"] = x:get("content_audit", content_usr, "name")
				app_policy_list[section_num]["ip_slots"] = {}
			end
		end

		local time_range = x:get("content_audit", section_name, "time_range")
		local pos2 = string.find(time_range, "self_tr")
		if (pos2) then
		    app_policy_list[section_num]["tr_group"] = ""
	--		app_policy_list[section_num]["tr_name"] = ""
	--[[
			local value = x:get("content_audit", time_range, "time")
			if (value) then
				app_policy_list[section_num]["tr_slots"] = split_time_range(value)
			else
			    app_policy_list[section_num]["tr_slots"] = {}
			end
	--]]
	        local tab = ctmngt.get_time_range(time_range)
			if (tab) then
	            app_policy_list[section_num]["tr_slots"] = tab
			else
			    app_policy_list[section_num]["tr_slots"] = {}
			end
		else
		    app_policy_list[section_num]["tr_group"] = time_range
    --			app_policy_list[section_num]["tr_name"] = x:get("content_audit", time_range, "name")
			app_policy_list[section_num]["tr_slots"] = {}
		end
		--[获取time_mode--]
    --		local time_mode = x:get("content_audit", time_range, "mode")
		app_policy_list[section_num]["time_mode"] = "calendar"
		--[获取策略已配置的应用组下的应用--]
		local app_group = x:get("content_audit", section_name, "app_group")
        app_policy_list[section_num]["app_group"] = app_group 
		local pos3 = string.find(app_group, "csm_")
		if (pos3) then
			tab = x:get("app_identify", app_group, "app")
		else
			tab = x:get("content_audit", app_group, "app")
		end
		-- 兼容app，必須要有applist字段，否咋app会出现可以配“所有地址”时间段的问题
		if (tab == nil) then
			tab = {}
		end
		--	app_policy_list[section_num]["applist"] = get_app_list(app_group)
		app_policy_list[section_num]["applist"] = tab	
	
		local enable = x:get("content_audit", section_name, "enable")
		app_policy_list[section_num]["enable"] = enable
		local app_available = x:get("content_audit", section_name, "app_available")
		app_policy_list[section_num]["app_available"] = app_available
		local comment = x:get("content_audit", section_name, "comment")
		app_policy_list[section_num]["comment"] = comment 
		section_num = section_num + 1
        end
	end
	)
	
	json_info = app_policy_list
	local cjson = require "luci.json" 
	local jsonStr = cjson.encode(json_info);
	print(jsonStr)
end

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
    return
end
user_grp_cap = arg[1]
main()