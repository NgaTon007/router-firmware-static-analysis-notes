#!/bin/bash
. /usr/share/libubox/jshn.sh

cdr2mask ()
{
   # Number of args to shift, 255..255, first non-255 byte, zeroes
   set -- $(( 5 - ($1 / 8) )) 255 255 255 255 $(( (255 << (8 - ($1 % 8))) & 255 )) 0 0 0
   [ $1 -gt 1 ] && shift $1 || shift
   echo ${1-0}.${2-0}.${3-0}.${4-0}
}

OVPN_SERV_LOG="/tmp/log/openvpn"

if [ ! -f "/etc/config/openvpn" ]; then
    touch /etc/config/openvpn
    chmod 755 /etc/config/openvpn
fi

if [ ! -d "$OVPN_SERV_LOG" ] || [ ! -f "$OVPN_SERV_LOG/openvpn-password.log" ];then
    mkdir -p $OVPN_SERV_LOG
    chmod -R 755 $OVPN_SERV_LOG
    touch $OVPN_SERV_LOG/openvpn.log
    touch $OVPN_SERV_LOG/openvpn-status.log
    touch $OVPN_SERV_LOG/openvpn-print.log
fi

if [ ! -f /etc/openvpn/psw-file ];then
    touch /etc/openvpn/psw-file
    chmod 755 /etc/openvpn/psw-file
fi

if [ -f /usr/sbin/web/openvpn_server_down.sh ];then
    chmod 777 /usr/sbin/web/openvpn_server_down.sh
fi

openvpn_print()
{
    echo "`date "+%Y-%m-%d %H:%M:%S"`:$1">>$OVPN_SERV_LOG/openvpn-print.log
}

openvpn_print "openvpn server start" 
uci -q delete openvpn.sample_client
uci -q delete openvpn.sample_server
uci set openvpn.sample_server="openvpn"
json_load "$1" 2>/dev/null >/dev/null
json_get_var role role 2>/dev/null >/dev/null
json_get_var enable enable 2>/dev/null >/dev/null
json_get_var service_mode service_mode 2>/dev/null >/dev/null
json_get_var hostname hostname 2>/dev/null >/dev/null
json_get_var port port 2>/dev/null >/dev/null
#VPN Reticulum
json_get_var ippool iprange 2>/dev/null >/dev/null
iprange=`echo "$ippool" | awk -F '/' '{print $1}'`
netmask=`echo "$ippool" | awk -F '/' '{print $2}'`
netmask=$(cdr2mask $netmask)
#proto(TCP/UDP)
json_get_var proto proto 2>/dev/null >/dev/null
uci del openvpn.sample_server.push
uci set openvpn.sample_server.enabled=1
uci set openvpn.sample_server.dev=tun0
uci set openvpn.sample_server.dev_type=tun
uci set openvpn.sample_server.port=$port
uci set openvpn.sample_server.proto="$proto"4""
uci set openvpn.sample_server.ippool=$ippool
uci set openvpn.sample_server.server="$iprange $netmask"
uci set openvpn.sample_server.hostname=$hostname
uci set openvpn.sample_server.service_mode=$service_mode
#write server_down.sh msg
echo "port=$port" >/etc/openvpn/down.msg
echo "proto=$proto" >>/etc/openvpn/down.msg
echo "ippool=$ippool">>/etc/openvpn/down.msg

if [ "$service_mode" == "0" ];then
    openvpn_print "openvpn-server:user_auth"
    uci set openvpn.sample_server.verify_client_cert="none" # ps：2.3-version:client-cert-not-required
    uci set openvpn.sample_server.auth_user_pass_verify="/usr/sbin/web/openvpn_checkpsw.sh via-env"
    uci set openvpn.sample_server.username_as_common_name=1
elif [ "$service_mode" == "1" ];then
    openvpn_print "openvpn-server:cert-auth"
    uci delete openvpn.sample_server.verify_client_cert 
    uci delete openvpn.sample_server.auth_user_pass_verify
    uci delete openvpn.sample_server.username_as_common_name
else
    openvpn_print "openvpn-server:user_auth+cert-auth"
    uci delete openvpn.sample_server.verify_client_cert
    uci set openvpn.sample_server.auth_user_pass_verify="/usr/sbin/web/openvpn_checkpsw.sh via-env"
    uci set openvpn.sample_server.username_as_common_name=1
fi 

links_limit=$(jq -r .gateway.openvpn_links_limit "/tmp/sd_device/sd_device.json" 2>/dev/null)
if [ -n "$links_limit" -a "$links_limit" != "null" -a "$links_limit" != "0" ]; then
	uci set openvpn.sample_server.max_clients=$links_limit
else
	uci set openvpn.sample_server.max_clients=16
fi

#Abnormal clients go offline automatically in one minute
uci set openvpn.sample_server.keepalive="10 30"
uci set openvpn.sample_server.topology="subnet"
uci set openvpn.sample_server.persist_key=1
uci set openvpn.sample_server.persist_tun=1
uci set openvpn.sample_server.mute=6
uci set openvpn.sample_server.script_security=3
uci set openvpn.sample_server.up="/usr/sbin/web/openvpn_server_up.sh"     
uci set openvpn.sample_server.down="/usr/sbin/web/openvpn_server_down.sh"
uci set openvpn.sample_server.status="$OVPN_SERV_LOG/openvpn-status.log 2"
uci set openvpn.sample_server.log="$OVPN_SERV_LOG/openvpn.log"
uci set openvpn.sample_server.duplicate_cn=1
uci set openvpn.sample_server.verb=1
uci set openvpn.sample_server.reneg_sec=0
uci set openvpn.sample_server.management="127.0.0.1 5572"
uci set openvpn.sample_server.multihome=1
uci set openvpn.sample_server.client_connect="/usr/sbin/web/openvpn_client_connect.sh"
uci set openvpn.sample_server.client_disconnect="/usr/sbin/web/openvpn_client_disconnect.sh"

if [ "$proto" == "udp" ];then
    uci set openvpn.sample_server.explicit_exit_notify=1
else
    uci delete openvpn.sample_server.explicit_exit_notify
fi

json_get_var comp_lzo comp_lzo 2>/dev/null >/dev/null
json_get_var cipher cipher 2>/dev/null >/dev/null
json_get_var redirect_gateway redirect_gateway 2>/dev/null >/dev/null
json_get_var tls_crypt tls_crypt 2>/dev/null >/dev/null

if [ "$comp_lzo" == "1" ];then                            
    uci set openvpn.sample_server.comp_lzo="yes"
else
    uci delete openvpn.sample_server.comp_lzo
fi

if [ "$redirect_gateway" == "1" ];then  
    uci add_list openvpn.sample_server.push="redirect-gateway def1"
else
    uci del_list openvpn.sample_server.push="redirect-gateway def1"
fi  

if [ "$tls_crypt" == "1" ];then  #TLS identity was switched on and TLS crypt was employed
    uci set openvpn.sample_server.tls_crypt="/etc/easy-rsa/pki/tls.key"
else
    uci delete openvpn.sample_server.tls_crypt
fi 

if [ "$cipher" == "auto" ];then
    uci delete openvpn.sample_server.ncp_disable
    uci set openvpn.sample_server.data_ciphers_fallback="AES-128-CBC"
else
    uci set openvpn.sample_server.data_ciphers_fallback=$cipher
    uci set openvpn.sample_server.ncp_disable=1
fi 

#Server down routing configuration
    json_select route_range
    index=1
    while json_get_type status $index && [ "$status" = object ]; do
        json_select $index
        json_get_var network network 2>/dev/null >/dev/null
        json_get_var mask mask 2>/dev/null >/dev/null
        json_select ..
        uci add_list openvpn.sample_server.push="route $network $mask"
        index=$((index+1))
    done
    json_select ..
#Server downrelease DNS server list
    json_select dns_range
    has_custom_dns=0
    for j in $(seq 1 4)  
    do   
        json_get_var dns $j 
        if [ "$dns"x != ""x ] 
        then
            has_custom_dns=1
            uci add_list openvpn.sample_server.push="dhcp-option DNS $dns" 
        fi
    done 
    json_select ..
    # Configuration parameters
    OVPN_DIR="/etc/openvpn"
    OVPN_PKI="/etc/easy-rsa/pki"
    OVPN_PORT=$port
    OVPN_PROTO=$proto
    OVPN_POOL="$iprange $netmask"
    OVPN_DNS="${OVPN_POOL%.* *}.1"
    if [ "$has_custom_dns" != "1" ]; then
        uci add_list openvpn.sample_server.push="dhcp-option DNS ${OVPN_DNS}"
    fi
    uci set openvpn.sample_server.dh=${OVPN_DIR}/dh.pem
    uci set openvpn.sample_server.ca=${OVPN_PKI}/ca.crt
    uci set openvpn.sample_server.cert=${OVPN_PKI}/issued/server.crt
    uci set openvpn.sample_server.key=${OVPN_PKI}/private/server.key
    uci commit openvpn
    # Configuration client parameters
    OVPN_SERV="${hostname}"
    OVPN_DH="$(cat ${OVPN_DIR}/dh.pem)"
    OVPN_TC="$(sed -e "/^#/d;/^\w/N;s/\n//" ${OVPN_PKI}/tls.key)"
    OVPN_CA="$(openssl x509 -in ${OVPN_PKI}/ca.crt)"
    NL=$'\n'
    # Configure VPN service and generate client profiles
    umask go=
    ls ${OVPN_PKI}/issued \
    | sed -e "s/\.\w*$//" \
    | while read -r OVPN_ID
    do
        OVPN_KEY="$(cat ${OVPN_PKI}/private/${OVPN_ID}.key)"
        OVPN_CERT="$(openssl x509 -in ${OVPN_PKI}/issued/${OVPN_ID}.crt)"
        OVPN_EKU="$(openssl x509 -in ${OVPN_PKI}/issued/${OVPN_ID}.crt -purpose)"
        OVPN_CONF_CLIENT="\
dev tun
nobind
proto ${OVPN_PROTO}
float
client
remote ${OVPN_SERV} ${OVPN_PORT}
auth SHA1
reneg-sec 0
remote-cert-tls server"
OVPN_CONF_USER="\
auth-user-pass
<ca>${NL}${OVPN_CA}${NL}</ca>"
OVPN_CONF_CERT="\
<key>${NL}${OVPN_KEY}${NL}</key>
<cert>${NL}${OVPN_CERT}${NL}</cert>
<ca>${NL}${OVPN_CA}${NL}</ca>"
OVPN_CONF_USER_CERT="\
auth-user-pass
<key>${NL}${OVPN_KEY}${NL}</key>
<cert>${NL}${OVPN_CERT}${NL}</cert>
<ca>${NL}${OVPN_CA}${NL}</ca>"
if [ "$service_mode" == "0" ];then
cat << EOF > ${OVPN_DIR}/${OVPN_ID}.ovpn
${OVPN_CONF_CLIENT}
${OVPN_CONF_USER}
EOF
elif [ "$service_mode" == "1" ];then
cat << EOF > ${OVPN_DIR}/${OVPN_ID}.ovpn
${OVPN_CONF_CLIENT}
${OVPN_CONF_CERT}
EOF
else
cat << EOF > ${OVPN_DIR}/${OVPN_ID}.ovpn
${OVPN_CONF_CLIENT}
${OVPN_CONF_USER_CERT}
EOF
fi
done
rm -rf ${OVPN_DIR}/server.ovpn
chmod -R 777 ${OVPN_DIR}/

if [ "$tls_crypt" == "1" ];then
    echo "<tls-crypt>${NL}${OVPN_TC}${NL}</tls-crypt>" >> ${OVPN_DIR}/client.ovpn
fi 

if [ "$comp_lzo" == "1" ];then
    echo "comp-lzo" >> ${OVPN_DIR}/client.ovpn
fi

if [ "$cipher" == "auto" ];then
    echo "cipher AES-128-CBC" >> ${OVPN_DIR}/client.ovpn
else
    echo "cipher $cipher" >> ${OVPN_DIR}/client.ovpn
fi

[ -f "/etc/openvpn/openvpn-client-cfg.tar" ] && rm -rf /etc/openvpn/openvpn-client-cfg.tar

if [ "$service_mode" == "0" ] && [ "$tls_crypt" == "1" ];then
    cp ${OVPN_PKI}/ca.crt  ${OVPN_DIR}/ca.crt
    cp ${OVPN_PKI}/private/ca.key ${OVPN_DIR}/ca.key
    cp ${OVPN_PKI}/tls.key ${OVPN_DIR}/tls.key
    /bin/tar cvf ${OVPN_DIR}/openvpn-client-cfg.tar ${OVPN_DIR}/client.ovpn ${OVPN_DIR}/ca.crt ${OVPN_DIR}/ca.key ${OVPN_DIR}/tls.key &>/dev/null
    chmod 777 ${OVPN_DIR}/openvpn-client-cfg.tar
    rm -rf ${OVPN_DIR}/ca.crt ${OVPN_DIR}/tls.key ${OVPN_DIR}/ca.key
elif [ "$service_mode" == "0" ] && [ "$tls_crypt" == "0" ];then
    cp ${OVPN_PKI}/ca.crt  ${OVPN_DIR}/ca.crt
    cp ${OVPN_PKI}/private/ca.key ${OVPN_DIR}/ca.key
    /bin/tar cvf ${OVPN_DIR}/openvpn-client-cfg.tar ${OVPN_DIR}/client.ovpn ${OVPN_DIR}/ca.crt ${OVPN_DIR}/ca.key &>/dev/null
    chmod 777 ${OVPN_DIR}/openvpn-client-cfg.tar
    rm -rf ${OVPN_DIR}/ca.crt ${OVPN_DIR}/ca.key
elif [ "$service_mode" != "0" ] && [ "$tls_crypt" == "1" ];then
    cp ${OVPN_PKI}/ca.crt  ${OVPN_DIR}/ca.crt
    cp ${OVPN_PKI}/private/ca.key ${OVPN_DIR}/ca.key
    cp ${OVPN_PKI}/tls.key ${OVPN_DIR}/tls.key
    cp ${OVPN_PKI}/private/client.key ${OVPN_DIR}/client.key
    cp ${OVPN_PKI}/issued/client.crt ${OVPN_DIR}/client.crt
    /bin/tar cvf ${OVPN_DIR}/openvpn-client-cfg.tar ${OVPN_DIR}/client.ovpn ${OVPN_DIR}/ca.crt ${OVPN_DIR}/ca.key ${OVPN_DIR}/tls.key ${OVPN_DIR}/client.key ${OVPN_DIR}/client.crt &>/dev/null
    chmod 777 ${OVPN_DIR}/openvpn-client-cfg.tar
    rm -rf ${OVPN_DIR}/ca.crt ${OVPN_DIR}/tls.key ${OVPN_DIR}/client.key ${OVPN_DIR}/client.crt ${OVPN_DIR}/ca.key
elif [ "$service_mode" != "0" ] && [ "$tls_crypt" == "0" ];then
    cp ${OVPN_PKI}/ca.crt  ${OVPN_DIR}/ca.crt
    cp ${OVPN_PKI}/private/ca.key ${OVPN_DIR}/ca.key
    cp ${OVPN_PKI}/private/client.key ${OVPN_DIR}/client.key
    cp ${OVPN_PKI}/issued/client.crt ${OVPN_DIR}/client.crt
    /bin/tar cvf ${OVPN_DIR}/openvpn-client-cfg.tar ${OVPN_DIR}/client.ovpn ${OVPN_DIR}/ca.crt ${OVPN_DIR}/ca.key ${OVPN_DIR}/client.key ${OVPN_DIR}/client.crt &>/dev/null
    chmod 777 ${OVPN_DIR}/openvpn-client-cfg.tar
    rm -rf ${OVPN_DIR}/ca.crt ${OVPN_DIR}/client.key ${OVPN_DIR}/client.crt ${OVPN_DIR}/ca.key
else
    rm -rf ${OVPN_DIR}/client.ovpn
fi

[ -f "/tmp/etc/openvpn-sample_client.conf" ] && rm /tmp/etc/openvpn-sample_client.conf
[ -f "/tmp/etc/openvpn-sample_server.conf" ] && rm /tmp/etc/openvpn-sample_server.conf
/etc/init.d/openvpn restart
openvpn_print "openvpn-server:{\"code\":\"0\", \"msg\":\"\"}"
