package.path = "/usr/sbin/web/?.lua;/usr/lib/lua/?.lua"
require "public_module"

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
    return
end

-- uci配置 兼容自定义组名称变更为id
require("uci")
local lib_app_idy = require "app_identify.app_idy_pub"
x=uci.cursor()
x:foreach("content_audit", "app_rule", function(s)
    local section_name = s[".name"]
    local app_group = x:get("content_audit", section_name, "app_group")
    local pos = string.find(app_group, "csm_")
    if (pos ~= nil) then
        local pos1= string.find(app_group, "csm_applist_")
        if (pos1 == nil) then
            local map_name = lib_app_idy.get_custom_group_map_name(app_group)
            if (map_name ~= nil) then
                x:set("content_audit", section_name, "app_group", map_name)
            end
        end
    end
end
)
x:commit("content_audit")

user_grp_cap = arg[1]

config_file = "/etc/sd_config/single/ca_app_policy.json"
config_table = public_module.read_file(config_file)

if (config_table["list"] == nil) then
    config_table["list"] = {}
else
    -- json配置 兼容自定义组名称变更为id
    for k,v in pairs(config_table["list"]) do
        local app_group = v["app_group"]
        local pos = string.find(app_group, "csm_")
        if (pos ~= nil) then
            local pos1= string.find(app_group, "csm_applist_")
            if (pos1 == nil) then
                local map_name = lib_app_idy.get_custom_group_map_name(app_group)
                if (map_name ~= nil) then
                    v["app_group"] = map_name
                    v["custom_group"] = map_name
                end
            end
        end
    end
end

local x = require("uci").cursor()
local ctmngt = require("ca_time_manager")

x:foreach("content_audit","app_rule",function(s)
    local section_name = s[".name"]
    local policy_name = x:get("content_audit", section_name, "policy_name")
    local name_repeat = ""
    local app_policy_list = {}
    for k,v in pairs(config_table["list"]) do
        if (v["policy"] == policy_name) then
            -- 兼容dev_config get加字段"app_version"号,用于特征库切换,生效转态显示,替换app_available功能
            local app_version = x:get("content_audit", section_name, "version")
            v["app_version"] = app_version
            name_repeat = "1"
            break
        end
    end
    if (name_repeat ~= "1") then
        local is_extern = x:get("content_audit", policy_name, "is_extern")
        if (is_extern ~= "1") then
            app_policy_list["policy"] = policy_name
            -- user_group的能力值判断，get显示选择
            if (user_grp_cap == "1") then
                local content_usr = x:get("content_audit", policy_name, "usr_name")
                if (content_usr == nil) then
                    return 0;
                end
                if (string.find(content_usr, "self_usr") ~= nil) then
                    app_policy_list["ip_group"] = ""
                    app_policy_list["ip_name"] = ""
                    app_policy_list["ip_slots"] = x:get("content_audit", content_usr, "ip_range")
                    app_policy_list["user_group_list"] = {}
                else
                    local content_usr_grp = x:get("content_audit", policy_name, "usr_group")
                    if (content_usr_grp ~= nil) then
                        app_policy_list["ip_group"] = ""
                        app_policy_list["ip_name"] = ""
                        app_policy_list["ip_slots"] = {}
                        app_policy_list["user_group_list"] = x:get("content_audit", content_usr_grp, "user_list")
                    end
                end
            else
                local content_usr = x:get("content_audit", policy_name, "usr_name")
                local pos1 = string.find(content_usr, "self_usr")
                if (pos1) then
                    app_policy_list["ip_group"] = ""
                    app_policy_list["ip_name"] = ""
                    app_policy_list["ip_slots"] = x:get("content_audit", content_usr, "ip_range")
                else
                    app_policy_list["ip_group"] = content_usr
                    app_policy_list["ip_name"] = x:get("content_audit", content_usr, "name")
                    app_policy_list["ip_slots"] = {}
                end
            end

            local time_range = x:get("content_audit", section_name, "time_range")
            local pos2 = string.find(time_range, "self_tr")
            if (pos2) then
                app_policy_list["tr_group"] = ""
                local tab = ctmngt.get_time_range(time_range)
                if (tab) then
                    app_policy_list["tr_slots"] = tab
                else
                    app_policy_list["tr_slots"] = {}
                end
            else
                app_policy_list["tr_group"] = time_range
                app_policy_list["tr_slots"] = {}
            end
            app_policy_list["time_mode"] = "calendar"
            --[获取策略已配置的应用组下的应用--]
            local app_group = x:get("content_audit", section_name, "app_group")
            app_policy_list["app_group"] = app_group 
            if (string.find(app_group, "csm_")) then
                app_policy_list["custom_group"] = app_group
            end
            local tab = x:get("content_audit", app_group, "app")
            app_policy_list["applist"] = tab		
            local enable = x:get("content_audit", section_name, "enable")
            app_policy_list["enable"] = enable
            local app_available = x:get("content_audit", section_name, "app_available")
            app_policy_list["app_available"] = app_available
            local app_version = x:get("content_audit", section_name, "version")
            app_policy_list["app_version"] = app_version
            local comment = x:get("content_audit", section_name, "comment")
            app_policy_list["comment"] = comment 
            table.insert(config_table["list"], app_policy_list)
        end
    end
end
)

config_table["count"] = #config_table["list"];
--保存dev_config的模块json配置文件
public_module.write_file(config_table, config_file)
