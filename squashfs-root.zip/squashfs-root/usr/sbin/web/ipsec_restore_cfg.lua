#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/ipsec/log/"
local IPSEC_JSON_FILE = "/etc/sd_config/single/ipsec.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "ipsec_restore_cfg.log", 100, module_debug.INFO, "1");
end

function main()
    module_debug.lua_debug(module_debug.INFO, "################################MAIN START################################")
    if (tool.file_exist(IPSEC_JSON_FILE) == true) then
        conf_data = tool.file_read(IPSEC_JSON_FILE);
        if (tool.json_check(conf_data) == true) then
            module_debug.lua_debug(module_debug.INFO, "conf_data:%s", conf_data)
            ipsec_cfg_json = cjson.decode(conf_data)
            if ipsec_cfg_json["configId"] == nil and next(ipsec_cfg_json["list"]) == nil then
                module_debug.lua_debug(module_debug.INFO, "restore cfg...")
                local cmd = "dev_config update -m ipsec '{}' >/dev/null 2>&1 &"
                os.execute(cmd)
                module_debug.lua_debug(module_debug.INFO, "###############################END###############################");
            end
        end
    end
end
---------------------------------------------main--------------------------------------------------
debug_init()
main()
