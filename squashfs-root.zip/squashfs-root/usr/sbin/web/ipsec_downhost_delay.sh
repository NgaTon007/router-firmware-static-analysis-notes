#!/bin/sh

host=$(cat /tmp/log/ipsec_down_host)
echo "down host $host " >> /tmp/log/ipsec_monitor_log
:>/tmp/log/ipsec_down_host
if [ -z "$host" ]; then
    exit
fi
for var in $host
do
    remote=$(echo $var | awk -F '+' '{print $1}')
    data=$(echo $var | awk -F '+' '{print $2}')
    echo "del route $remote " >> /tmp/log/ipsec_monitor_log
    ip route delete $remote table 350 >/dev/null 2>&1
    if [ -f "/usr/lib/snosvpn/ipsec_updown.lua" ]; then
        echo "lua /usr/lib/snosvpn/ipsec_updown.lua $data" >> /tmp/log/ipsec_monitor_log
        lua /usr/lib/snosvpn/ipsec_updown.lua "$data"
    fi
done

