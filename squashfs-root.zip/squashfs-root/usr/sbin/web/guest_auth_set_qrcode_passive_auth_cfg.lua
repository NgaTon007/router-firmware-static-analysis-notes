package.path = string.format("%s;%s;/www/guest_auth/?.lua", package.path, "./?.lua")
require "pub"
local auth_ip = require("product").get_product("capacity.auth_ip")

function split(str, reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end
function string_ip_conver_int(iptab)
    if iptab == nil then
        return ""
    end
    local iprang_int = ""
    for i=1, #iptab do
        iprange = iptab[i]
        local ipstr = split(iprange, "-")
        if (#ipstr == 1) then
            ipstr[2] = ipstr[1]
        end
        for i=1, #ipstr do
            local ip = split(ipstr[i], ".")
            if #ip ~= 4 then
                return false
            end
            for i = 1, #ip do
                if tonumber(ip[i]) < 0 or tonumber(ip[i]) > 255 then
                    return false
                end
            end
            local ip_int = ip[1] * 16777216 + ip[2] * 65536 + ip[3] * 256 + ip[4]
            if (iprang_int == "") then
                iprang_int = tostring(ip_int) 
            else
                iprang_int = string.format("%s,%s", iprang_int, tostring(ip_int))
            end
        end
    end
    
    return iprang_int
end 

-- # % & 换行 需要特殊处理,兼容URL转义，js转义,html转义 
function encode_char(str)
    local encode_table = {
        [1] = '%%',
        [2] = '#',
        [3] = '<',
        [4] = '>',
        [5] = '&',
        [6] = '\n',
        [7] = '\\',
        [8] = nil,
        ['%%'] = "%%25",
        ['#'] = "%%23",
        ['&'] = "%%26",
        ['\n'] = "<br/>",
        ['\\'] = "\\\\",
        ['<'] = "&lt;",
        ['>'] = "&gt;",
    }

    for i = 1, #encode_table do
        if (string.find(str, encode_table[i]) ~= nil) then
                str = string.gsub(str, encode_table[i], encode_table[encode_table[i]])
        end
    end
    return str
end

function main()
    
    if (arg[1] == nil) then
        print("{\"code\":\"-1\", \"msg\":\"param err\"}")
        return
    end
    local x = require("luci.model.uci").cursor()
    local cjson = require "cjson"  
    local jsonStr = cjson.decode(arg[1]);
    local proxy_https = jsonStr["proxy_https"]

    if proxy_https == nil or proxy_https == "" then
        proxy_https = "1"
    end
        
    x:foreach("app_auth", "auth_rule", function(s)
        local name = s[".name"]
        local ser_name = x:get("app_auth", name, "ser_name")
        if (ser_name == jsonStr["name"]) then
            if (jsonStr["en"] == "1") then
                x:delete("app_auth", name)
            else
                x:set("app_auth", name, "enable", "0")
                x:set("app_auth", name, "proxy_https", proxy_https)
            end
        end
    end
    )

    if (jsonStr["displaypastext"] == nil or jsonStr["displaypastext"] == "") then
        jsonStr["displaypastext"] = " "
    end
    local tmp = encode_char(jsonStr["displaypastext"])
    x:set("guest_auth", "guest_auth", "displaypastext", tmp)
    x:set("guest_auth", "guest_auth", "passive_allow_time", tonumber(jsonStr["time"]) * 60) 
    x:set("guest_auth", "guest_auth", "active_auth_ip_range", string_ip_conver_int(jsonStr["activeAuthIpRange"]))
    x:set_list("guest_auth", "guest_auth", "activeAuthIpRange", jsonStr["activeAuthIpRange"])
    x:set_list("guest_auth", "guest_auth", "passive_auth_ip", jsonStr["authList"])
    x:commit("guest_auth")

    if (jsonStr["en"] == "1") then
        local name = x:add("app_auth", "auth_rule")
        x:set("app_auth", name, "name", jsonStr["name"])
        x:set("app_auth", name, "ser_name", jsonStr["name"])
        x:set("app_auth", name, "enable", "1")
        x:set("app_auth", name, "ad_url", "http://" .. auth_ip .. ":2060/ga_qrcode_passive_auth")
        x:set("app_auth", name, "rdt_style", "wifidog")
        x:set("app_auth", name, "proxy_https", proxy_https)
        x:set_list("app_auth", name, "ip", jsonStr["authList"])
        x:set("app_auth", "app_auth", "mac_inq", "1")
        x:commit("app_auth")

        os.execute('/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "qrcode_passive_auth" "on"')
        os.execute('/bin/sh /usr/sbin/web/app_idy_set_module.sh qr_passive_auth on')
        os.execute('curl 127.0.0.1:2060/ga_reloadcfg 2>/dev/null > /dev/null')
    else
        x:commit("app_auth")
        os.execute('/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "qrcode_passive_auth" "off"')
        os.execute('/bin/sh /usr/sbin/web/app_idy_set_module.sh qr_passive_auth off')
    end

    guest_auth_uci_set_cfg()
    print("{\"code\":\"0\", \"msg\":\"\"}") 
end

function traceback(msg)
    print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
end  
  
xpcall(main, traceback)  
