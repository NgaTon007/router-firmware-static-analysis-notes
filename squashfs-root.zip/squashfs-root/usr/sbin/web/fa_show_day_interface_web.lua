package.path = "/usr/lib/lua/?.lua;"
local libc2lua = require("libc2lua");

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"type parameter error\"}")
    return
end

if (libc2lua.lua_param_safety_check(arg[1]) ~= true) then
	print("{\"code\":\"-1\", \"msg\":\"[day_intf]param is no safety \"}")
	return
end

if string.match(arg[1], "\\n") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end
if string.match(arg[1], ">") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end

function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

local in_cjson = require "cjson" 
local jsonStr = in_cjson.decode(arg[1]);
local sub_info = {}
local time, session, half_connection
local passUp
local passDown
local cjson = require "dkjson"
local ary_data = {}
local cnt = 1
local t
local cmd = "/usr/sbin/flow_audit_cmd.elf  -S -h -l -p"

if (jsonStr["interface"] == "allWan" or jsonStr["interface"] == nil) then
	if (jsonStr["time"] == nil) then
		cmd = cmd.." -g"
	else
		if (jsonStr["pos"] == nil) then
			cmd = cmd.." -g".." -t "..jsonStr["time"]
		else
			if (jsonStr["limit"] == nil) then
				cmd = cmd.." -g".." -t "..jsonStr["time"].." --start "..jsonStr["pos"]
			else
				cmd = cmd.." -g".." -t "..jsonStr["time"].." --start "..jsonStr["pos"].." --limit "..jsonStr["limit"]
			end
		end
	end
else
	if (jsonStr["time"] == nil) then
		cmd = cmd.." -i "..jsonStr["interface"]
	else
		if (jsonStr["pos"] == nil) then
			cmd = cmd.." -i "..jsonStr["interface"].." -t "..jsonStr["time"]
		else
			if (jsonStr["limit"] == nil) then
				cmd = cmd.." -i "..jsonStr["interface"].." -t "..jsonStr["time"].." --start "..jsonStr["pos"]
			else
				cmd = cmd.." -i "..jsonStr["interface"].." -t "..jsonStr["time"].." --start "..jsonStr["pos"].." --limit "..jsonStr["limit"]
			end
		end
	end
end
t = io.popen(cmd)
for line in t:lines() do
	if (string.sub(line, -1) == "\r") then
		line = string.sub(line, 1, string.len(line) - 1)
	end
	table.insert(sub_info, line)
end
ary_data["list"] = {}
for i=4,#sub_info, 1 do
	local info = lua_string_split_space(sub_info[i])
	passUp = info[1]
	passDown = info[2]
	time = info[3]
	session = info[4]
	half_connection = info[5]
	ary_data["list"][cnt] = {}
	ary_data["list"][cnt]["up"] = passUp
	ary_data["list"][cnt]["down"] = passDown
	ary_data["list"][cnt]["time"] = time
	ary_data["list"][cnt]["session"] = session
	ary_data["list"][cnt]["half_connection"] = half_connection
	cnt = cnt + 1
end

ary_data["count"] = cnt - 1
local jsonStr = cjson.encode(ary_data);
print(jsonStr);
