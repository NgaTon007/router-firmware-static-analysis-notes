package.path = "/usr/lib/lua/?.lua;" .. package.path;
require("uci")
require "public_module"
local ubus = require("ubus");
x =uci.cursor()
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local cjson = require "cjson"  

local version = x:get("content_audit", "signature", "version")

CFG_BAD_WEBSITE = "/etc/config/ca_url_bad_website"
if (version == "3") then
    CFG_FILE_NAME = "ca_url_list_en"
else
    CFG_FILE_NAME = "ca_url_list"
end

local function get_max_url_limit()
    local url_limit_default = 2000
    local device_cap = "/tmp/sd_device/sd_device.json"
    local device_cap_json = nil
    if (tool.file_exist(device_cap) == true) then
        local file_data = tool.file_read(device_cap);
        device_cap_json = cjson.decode(file_data);
        return tonumber(device_cap_json["gateway"]["ca_url_max"])
    else
        return url_limit_default
    end
end

CA_URL_LIST_MAX_GROUP = 20
CA_URL_LIST_MAX_URL = get_max_url_limit()
local url_group_name = nil
local DEBUG_LOG_DIR = "/tmp/content_audit/"
if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

module_debug.debug_init(DEBUG_LOG_DIR, "ca_update_url_list.log", 500, module_debug.INFO, "1")

system_url_groups = {
    "games",
    "finance",
    "communication",
    "shopping",
    "live",
    "music",
    "entertainment",
    "forum",
    "mailbox",
    "story",
    "sports",
    "news",
    "video"
}

local function is_system_group(name)
    for _, sys_name in ipairs(system_url_groups) do
        if name == sys_name then
            return true
        end
    end
    return false
end

function url_route_ubus_call(name)
    local conn = ubus.connect()

    if not conn then
        print("failed to create ubus connect.")
        return
    end

    local status = conn:call("url_route", "config_change", {type = 2, cmd = 1, param = name})
    conn:close()
end

local function ca_url_validate(url)
    if type(url) ~= "string" or url == "" then
        return false
    end
    url = url:lower()
    local has_star = false
    if url:sub(1,1) == "*" then
        has_star = true
        if #url < 3 then
            return false
        end
        local rest = url:sub(2)
        if not rest:sub(1,2):match("^[A-Za-z0-9][A-Za-z0-9]$") then
            return false
        end
        url = rest
    end

    if url:find("%*") then
        return false
    end

    if url:sub(1,1) == "." or url:sub(-1) == "." then
        return false
    end

    if not url:find("%.") then
        return false
    end

    if url:find("%.%.") then
        return false
    end

    for label in url:gmatch("[^%.]+") do
        if not label:match("^[a-z0-9%-]+$") then
            return false
        end
        if label:sub(1,1) == "-" or label:sub(-1) == "-" then
            return false
        end
        if #label > 63 then
            return false
        end
    end

    return true
end

local function ca_parse_url_file(file, exist_group, total_url_count, group_count, used_alias_map)
    local groups = exist_group or {}
    local group_lookup = {}
    local update = 0
    if exist_group then
        for i, group in ipairs(exist_group) do
            group_lookup[group.name] = i
        end
    end
    
    local used_alias_lookup = {}
    if used_alias_map then
        for _, alias in pairs(used_alias_map) do
            used_alias_lookup[alias] = true
        end
    end
    
    local line_num = 0
    for line in io.lines(file) do
        line_num = line_num + 1
        if line_num > 1 then  -- Skip header
            line = line:gsub("[\n\r]", ""):gsub("^%s+", ""):gsub("%s+$", "")
            if line ~= "" and not (line:sub(1, 1) == "#" or line:sub(1, 2) == "//") then
                local group_name, urls_str = line:match("^([^,]+),(.*)$")
                if group_name and urls_str then
                    if urls_str:sub(1,1) == '"' and urls_str:sub(-1) == '"' then
                        urls_str = urls_str:sub(2, -2)
                    end
                    group_name = group_name:gsub("^%s+", ""):gsub("%s+$", "")
                    if used_alias_lookup[group_name] then
                        -- Skip existing used group
                        module_debug.lua_debug(module_debug.INFO, "Skipping existing used group: %s", group_name)
                    elseif group_name ~= "" and not group_name:find("[\n\r'`$;|&]") and group_count < CA_URL_LIST_MAX_GROUP then
                        if not group_lookup[group_name] then
                            group_count = group_count + 1
                            groups[group_count] = { name = group_name, urls = {}, entry_name = nil }
                            group_lookup[group_name] = group_count
                        end
                        local current_group_index = group_lookup[group_name]
                        local urls = groups[current_group_index].urls
                        
                        -- Build url_set for fast lookup
                        local url_set = {}
                        for _, existing_url in ipairs(urls) do
                            url_set[existing_url] = true
                        end
                        module_debug.lua_debug(module_debug.INFO, "Processing group: %s", group_name)
                        -- Parse URLs (space-separated)
                        for url in urls_str:gmatch("[^ ]+") do
                            url = url:gsub("^%s+", ""):gsub("%s+$", "")
                            if current_group_index and total_url_count < CA_URL_LIST_MAX_URL then
                                local valid = true
                                if url:sub(1, 1) == "*" then
                                    if #url < 3 or not url:sub(2, 3):match("^[A-Za-z0-9][A-Za-z0-9]$") then
                                        valid = false
                                    end
                                end
                                if url:find("[\n\r'`$;|&]") then
                                    valid = false
                                end
                                if valid and ca_url_validate(url) then
                                    if not url_set[url] then
                                        table.insert(urls, url)
                                        url_set[url] = true
                                        total_url_count = total_url_count + 1
                                    end
                                end
                            end
                        end
                        update = update + 1
                    end
                end
            end
        end
    end
    return groups, group_count, total_url_count, update
end

local function file_exists(path)
    local f = io.open(path, "r")
    if f then
        f:close()
        return true
    else
        return false
    end
end

local function clear_url_class_cfg(used_url_classes_map)
    local sections = {}
    x:foreach(CFG_FILE_NAME, "url_class", function(s)
        local name = s[".name"]
        if name and not (used_url_classes_map and used_url_classes_map[name]) then
            sections[#sections + 1] = name
        end
    end)
    for _, section in ipairs(sections) do
        x:delete(CFG_FILE_NAME, section)
    end
end

local function get_used_url_classes()
    local used_map = {}
    x:foreach("content_audit", "url_object", function(s)
        local classes = s.url_class
        if type(classes) == "string" then
            classes = { classes }
        elseif type(classes) ~= "table" then
            classes = {}
        end
        for _, cls in ipairs(classes) do
            if cls and cls ~= "" then
                used_map[cls] = true
            end
        end
    end)
    local used_list = {}
    for cls in pairs(used_map) do
        table.insert(used_list, cls)
    end
    return used_list, used_map
end

local function get_used_url_class_alias(used_list)
    local alias_map = {}
    for _, cls in ipairs(used_list or {}) do
        local alias = x:get(CFG_FILE_NAME, cls, "name")
        if alias and alias ~= "" then
            alias_map[cls] = alias
        else
            alias_map[cls] = cls
        end
    end
    module_debug.lua_debug(module_debug.INFO, "Used Alias Map: %s", cjson.encode(alias_map))
    return alias_map
end

local function ca_url_import(config_file)
    local total_url_count = 0
    local group_count = 0

    local file = "/tmp/content_audit/url_group_cfg.csv"
    if not file_exists(file) then
        return "{\"code\":\"-2\", \"msg\":\"import file not exist\"}"
    end
    local used_url_classes, used_url_classes_map = get_used_url_classes()
    local used_alias_map = get_used_url_class_alias(used_url_classes)

    local groups = {}
    for _, cls in ipairs(used_url_classes) do
        group_count = group_count + 1
        local alias = used_alias_map[cls] or cls
        local existing_urls = x:get(CFG_FILE_NAME, cls, "url")
        local urls = {}
        if existing_urls then
            if type(existing_urls) == "string" then
                existing_urls = { existing_urls }
            end
            if type(existing_urls) == "table" then
                urls = existing_urls
            end
        end
        groups[group_count] = {
            name = alias,
            urls = urls,
            entry_name = cls  -- save original entry_name
        }
        
        total_url_count = total_url_count + #urls
    end

    if group_count >= CA_URL_LIST_MAX_GROUP or #groups >= CA_URL_LIST_MAX_GROUP then
        return "{\"code\":\"-3\", \"msg\":\"exceed max group limit\"}"
    end

    local all_groups, updated_group_count, updated_total_count, update = ca_parse_url_file(file, groups, total_url_count, group_count, used_alias_map)
    group_count = updated_group_count
    total_url_count = updated_total_count
    module_debug.lua_debug(module_debug.INFO, "Group Update: %d", update)
    if not all_groups or #all_groups == 0 or update <= 0 then
        return "{\"code\":\"-4\", \"msg\":\"url groups are not updated\"}"
    end
    clear_url_class_cfg(used_url_classes_map)
    -- groups[group_name] = {url1, url2, ...}
    local config_table = {url_group = {}}
    local class_count = 0

    for _, group in ipairs(all_groups) do
        local group_name = group.name
        local urls = group.urls or {}
        local group_entry = {
            entry_name = group.entry_name,
            alias_name = group_name,
            url_list = urls
        }
        if is_system_group(group_name) then
            group_entry.entry_name = group_name
        elseif group_entry.entry_name == nil then
            class_count = class_count + 1
            group_entry.entry_name = "url_cls_" .. tostring(class_count)
            while used_url_classes_map and used_url_classes_map[group_entry.entry_name] do
                class_count = class_count + 1
                group_entry.entry_name = "url_cls_" .. tostring(class_count)
            end
        else
            class_count = class_count + 1
        end

        if #urls > 0 then
            table.insert(config_table.url_group, group_entry)
            x:set(CFG_FILE_NAME, group_entry.entry_name, "url_class")
            x:set(CFG_FILE_NAME, group_entry.entry_name, "name", group_name)
            x:set(CFG_FILE_NAME, group_entry.entry_name, "url", urls)
        end
    end

    x:foreach(CFG_BAD_WEBSITE, "url_class", function(s)
        local bad_entry = {}
        bad_entry.no_modify = "1"
        bad_entry.url_list = {}
        local entry_name = s[".name"]
        bad_entry.entry_name = entry_name
        if (version == "3") then
            bad_entry.alias_name = "Inappropriate websites"
        else
            bad_entry.alias_name = "不良网站"
        end
        table.insert(config_table.url_group, bad_entry)
    end)

    x:set("content_audit", "count", "url_class", class_count)
    public_module.write_file(config_table, config_file)
    x:commit("content_audit")
    x:commit(CFG_FILE_NAME)

    for i, group_entry in ipairs(config_table.url_group) do
        url_group_name = group_entry.entry_name
        url_route_ubus_call(url_group_name)
    end
    os.remove(file)
    -- os.execute("rm -f " .. file)
    return "{\"code\":\"0\", \"msg\":\"import success\"}"
end

local function ca_url_del(input_str, config_file)
    if (input_str == nil or input_str == "" or config_file == nil) then
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end

    local jsonStr = cjson.decode(input_str)
    if not jsonStr or not jsonStr.entry_name or not jsonStr.urls or type(jsonStr.urls) ~= "table" then
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end

    local config_table = public_module.read_file(config_file)
    if not config_table or not config_table.url_group or type(config_table.url_group) ~= "table" then
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end

    local entry_name = jsonStr.entry_name
    local urls_to_del = {}
    for _, url in ipairs(jsonStr.urls) do
        urls_to_del[url] = true
    end
    local found = false
    local new_url_group = {}
    for _, entry in ipairs(config_table.url_group) do
        if entry.entry_name == entry_name then
            found = true
            local new_urls = {}
            for _, url in ipairs(entry.url_list or {}) do
                if not urls_to_del[url] then
                    table.insert(new_urls, url)
                end
            end
            if #new_urls > 0 then
                entry.url_list = new_urls
                entry.url_num = #new_urls
                table.insert(new_url_group, entry)
            end
            url_group_name = entry_name
            -- If URL list is empty, delete the entire group
        else
            table.insert(new_url_group, entry)
        end
    end
    if not found then
        return "{\"code\":\"-2\", \"msg\":\"group does not exist\"}"
    end
    config_table.url_group = new_url_group
    local group_count = #new_url_group
    x:set("content_audit", "count", "url_class", group_count)
    public_module.write_file(config_table, config_file)
    x:commit("content_audit")
    
    -- Notify url_route module
    if url_group_name ~= nil then
        url_route_ubus_call(url_group_name)
    end

    return "{\"code\":\"0\", \"msg\":\"success\"}"
end

local function ca_url_update(input_str, config_file)
    if (input_str == nil or input_str == "" or config_file == nil) then
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end
    
    local jsonStr = cjson.decode(input_str)
    if not jsonStr or not jsonStr.entry_name or not jsonStr.urls or not jsonStr.urls.old or not jsonStr.urls.new then
        return "{\"code\":\"-1\", \"msg\":\"invalid input format\"}"
    end
    
    local config_table = public_module.read_file(config_file)
    if not config_table or not config_table.url_group or type(config_table.url_group) ~= "table" then
        return "{\"code\":\"-1\", \"msg\":\"config file is invalid\"}"
    end
    
    local entry_name = jsonStr.entry_name
    local old_url = jsonStr.urls.old
    local new_url = jsonStr.urls.new
    
    -- Verify url
    if not ca_url_validate(new_url) then
        return "{\"code\":\"-1\", \"msg\":\"new url is invalid\"}"
    end
    
    local found = false
    for _, entry in ipairs(config_table.url_group) do
        if entry.entry_name == entry_name then
            found = true
            local url_list = entry.url_list or {}
            local updated = false
            for i, url in ipairs(url_list) do
                if url == old_url then
                    url_list[i] = new_url
                    updated = true
                    break
                end
            end
            if not updated then
                return "{\"code\":\"-2\", \"msg\":\"old url does not exist\"}"
            end
            url_group_name = entry_name
            break
        end
    end
    
    if not found then
        return "{\"code\":\"-2\", \"msg\":\"group does not exist\"}"
    end
    
    public_module.write_file(config_table, config_file)
    x:commit("content_audit")
    
    -- Notify url_route module
    if url_group_name ~= nil then
        url_route_ubus_call(url_group_name)
    end
    
    return "{\"code\":\"0\", \"msg\":\"success\"}"
end

local function url_cfg_process(input_str, config_file)
    if (input_str == nil or config_file == nil) then
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end

    local jsonStr = cjson.decode(input_str);
    local operate = nil
    local ret = nil

    operate = jsonStr["op"]

    if (operate == nil) then
        return "{\"code\":\"0\", \"msg\":\"update trigger\"}"
    end

    if (operate == "import") then
        ret = ca_url_import(config_file) -- import config from file
    elseif (operate == "del") then -- delete specified urls
        ret = ca_url_del(input_str, config_file)
    elseif (operate == "update") then -- update one url to another url
        ret = ca_url_update(input_str, config_file)
    else
        return "{\"code\":\"-1\", \"msg\":\"parameter is invalid\"}"
    end

    return ret
end

result = url_cfg_process(arg[1], arg[2])
print(result)
