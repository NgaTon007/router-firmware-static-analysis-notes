#! /usr/bin/lua
package.path = "/usr/sbin/web/?.lua"
package.path = "/usr/lib/lua/?.lua;" .. package.path;

require("uci")
local ctmngt = require("ca_time_manager")
local cjson = require "cjson"

--本接口支持一个policy下有多个rule，支持外部组件定义策略，因此生成的policy只能通过ca_del_policy.lua删除
--本接口内部使用：与统一配置接口的区别是，timerange对象不支持自定义，不需要ref或deref，由外部组件统一控制

-- local app_comparison_table = {
-- 	["社交软件"] = "communication",
-- 	["视频|音乐|直播"] = "video",
-- 	["网络购物"] = "shopping",
-- 	["网络游戏"] = "games",
-- 	["网络硬盘|云存储"] = "databank",
-- 	["P2P软件"] = "p2p_software",
-- 	["应用商店"] = "app_store",
-- 	["金融软件"] = "financial",
-- 	["新闻阅读"] = "news",
--     ["游戏"] = "games",
--     ["视频"] = "video",
--     ["支付"] = "payment",
--     ["社交"] = "communication",
--     ["应用安装"] = "app_store",
-- 	["学习"] = "study",
-- 	["Communication"] = "communication_En",
-- 	["Video"] = "video_En",
-- 	["Shopping"] = "shopping_En",
-- 	["Play"] = "games_En",
-- 	["Databank"] = "databank_En",
-- 	["P2PSoftware"] = "p2p_software_En",
-- 	["AppStore"] = "app_store_En",
--     ["Payment"] = "payment_En",
-- 	["Study"] = "study_En"
-- }

local need_open_module=false
local version = "2"

--与其他内容审计脚本共同操作一个配置文件，x需要是全局的
x = uci.cursor()
local lib_app_idy = require "app_identify.app_idy_pub"

local function ca_set_usr(policy, ip_group, ip_slots, mac_list)
    local old_user
    local usr_name
    local user_obj
    
    --policy有旧自定义user，则先清空
    if (policy ~= nil and policy ~= "") then
        old_user = x:get("content_audit", policy, "usr_name")
        if (old_user ~= nil and old_user ~= "") then
            local pos = string.find(old_user, "self_usr")
            if (pos) then
                x:delete("content_audit", old_user, "ip_range")
                x:delete("content_audit", old_user, "mac")
            end
        end
    end
    
    --指定用户名称的，直接使用
    if (ip_group ~= nil and ip_group ~= "") then
        return ip_group
    else 
        --有则复用，无则新建
        if (old_user == nil or old_user == "") then
            local self_usr_cnt = x:get("content_audit", "count", "self_usr")
            local increase = tonumber(self_usr_cnt) + 1
            usr_name = "self_usr_" .. increase
            x:set("content_audit", "count", "self_usr", increase)
        else
            usr_name = old_user
        end

        user_obj = x:get("content_audit", usr_name)
        if (user_obj == nil) then
            x:set("content_audit", usr_name, "content_usr")
            x:set("content_audit", usr_name, "name", usr_name)
            x:set("content_audit", usr_name, "flag", "usr")
        end
        
        if (ip_slots ~= nil and #ip_slots ~= 0) then
            x:set("content_audit", usr_name, "ip_range", ip_slots)
        end
        if (mac_list ~= nil and #mac_list ~= 0) then
            x:set("content_audit", usr_name, "mac", mac_list)
        end
        
        return usr_name
    end
end

local function ca_set_app_idy_grp(version, obj_name, grp_list)
    if (version == "2" or version == "4") then
        x:set("app_identify", obj_name, "Custom_Group")
    elseif(version == "3") then
        x:set("app_identify", obj_name, "Custom_Group_En")
    end
    x:set("app_identify", obj_name, "name", obj_name)
    
    if (#grp_list ~= 0) then
        local app_list = {}
        for i = 1, #grp_list do
            local app_name = lib_app_idy.app_comparison_table[grp_list[i]]
            if (app_name) then
                local app_tab = x:get("app_identify", app_name, "app")
                for j = 1, #app_tab do
                    table.insert(app_list, app_tab[j])
                end
            else
                table.insert(app_list, grp_list[i])
            end
        end
        x:set("app_identify", obj_name, "app", app_list)
    end
end

local function ca_del_app_idy_grp(version, obj_name)
    x:delete("app_identify", obj_name)
end

local function ca_set_app_rule(policy, app_group, app_list, tr_group)
    local rule_name
    local obj_name
    local increase
    local rule_obj
    local app_obj
    
    rule_name = x:get("content_audit", policy, "app_rule")

    --对象设置
    if (app_list ~= nil and #app_list ~= 0) then
        --rule处理：有则复用，无则生成
        if (rule_name ~= nil and rule_name ~= "") then
            rule_obj = x:get("content_audit", rule_name)
        end
        if (rule_obj == nil) then
            local rule_cnt = x:get("content_audit", "count", "app_rule")
            increase = tonumber(rule_cnt) + 1
            x:set("content_audit", "count", "app_rule", increase)
            rule_name = "app_rule_" .. increase
            x:set("content_audit", rule_name, "app_rule")
            x:set("content_audit", rule_name, "policy_name", policy)
            x:set("content_audit", rule_name, "rule_id", increase)
            x:set("content_audit", rule_name, "app_available", 1)
            x:set("content_audit", rule_name, "action", "deny")
            x:set("content_audit", rule_name, "enable", "1")
        end
        
        x:set("content_audit", rule_name, "version", version)
        x:set("content_audit", rule_name, "time_range", tr_group)
        
        --app_group对象处理：有则复用，无则自动生成
        local old_obj_name = x:get("content_audit", rule_name, "app_group")
        if (old_obj_name == nil or old_obj_name == "") then
            local app_group_cnt = x:get("content_audit", "count", "app_group")
            increase = tonumber(app_group_cnt) + 1
            x:set("content_audit", "count", "app_group", increase)
            obj_name = "applist_" .. increase
        else
            obj_name = old_obj_name
        end
        
        app_obj = x:get("content_audit", obj_name)
        --对象复用时，先清空已有内容
        if (app_obj ~= nil) then
            x:delete("content_audit", obj_name, "app")
            ca_del_app_idy_grp(version, obj_name)
        else 
            x:set("content_audit", obj_name, "app_group")
        end
        x:set("content_audit", rule_name, "app_group", obj_name)

        --app_group成员：applist设置
        x:set("content_audit", obj_name, "app", app_list)

        --应用识别设置
        ca_set_app_idy_grp(version, obj_name, app_list)
        
        return rule_name
    elseif (rule_name ~= nil) then
        --policy-->app_rule-->app_group-->app_idy.app_group
        obj_name = x:get("content_audit", rule_name, "app_group")
        --删除策略下的app_rule和对应的应用识别对象，timerange由外部处理
        x:delete("content_audit", policy, "app_rule")
        x:delete("content_audit", rule_name)
        if (obj_name ~= nil) then
            x:delete("content_audit", obj_name)
            ca_del_app_idy_grp(version, obj_name)
        end
    end

    return nil
end

local function ca_set_url_rule(policy, url_obj, url_class, tr_group)
    local rule_name
    local obj_name
    local increase
    local rule_obj
    local url_obj
    
    rule_name = x:get("content_audit", policy, "url_rule")

    --有配置对象的，开始处理
    if (url_class ~= nil and #url_class ~= 0) then
        --rule创建
        if (rule_name ~= nil and rule_name ~= "") then
            rule_obj = x:get("content_audit", rule_name)
        end
        if (rule_obj == nil) then
            local rule_cnt = x:get("content_audit", "count", "url_rule")
            increase = tonumber(rule_cnt) + 1
            x:set("content_audit", "count", "url_rule", increase)
            rule_name = "url_rule_" .. increase
            x:set("content_audit", rule_name, "url_rule")
            x:set("content_audit", rule_name, "policy_name", policy)
            x:set("content_audit", rule_name, "rule_id", increase)
            x:set("content_audit", rule_name, "url_available", 1)
            x:set("content_audit", rule_name, "action", "deny")
            x:set("content_audit", rule_name, "enable", "1")
        end
        x:set("content_audit", rule_name, "version", version)
        x:set("content_audit", rule_name, "time_range", tr_group)
        
        --url_obj创建
        local old_obj_name = x:get("content_audit", rule_name, "url_object")
        if (old_obj_name == nil or old_obj_name == "") then
            local obj_cnt = x:get("content_audit", "count", "url_obj")
            increase = tonumber(obj_cnt) + 1
            x:set("content_audit", "count", "url_obj", increase)
            obj_name = "url_obj_" .. increase
        else
            obj_name = old_obj_name
        end
        
        url_obj = x:get("content_audit", obj_name)
        if (url_obj ~= nil) then
            x:delete("content_audit", obj_name, "url_class")
        else
            x:set("content_audit", obj_name, "url_object")
        end
        x:set("content_audit", rule_name, "url_object", obj_name)
        
        --url_obj成员：url_class设置
        if (#url_class ~= 0) then
            x:set("content_audit", obj_name, "url_class", url_class)
        end
        
        return rule_name
    elseif (rule_name ~= nil) then
        --policy-->url_rule-->url_object-->app_idy.app_group
        obj_name = x:get("content_audit", rule_name, "url_object")
        --删除策略下的app_rule和对应的应用识别对象，timerange由外部处理
        x:delete("content_audit", policy, "url_rule")
        x:delete("content_audit", rule_name)
        if (obj_name ~= nil) then
            x:delete("content_audit", obj_name)
            --ca_url_list中的对象由外部控制
        end
    end
    
    return nil
end

local function ca_set_im_rule(policy, im_obj, account, tr_group)
    local rule_name
    local obj_name
    local increase
    local rule_obj
    local im_obj
    
    rule_name = x:get("content_audit", policy, "im_rule")
    
    --有配置对象的，开始处理
    if (account ~= nil and #account ~= 0) then
        --rule创建
        if (rule_name ~= nil and rule_name ~= "") then
            rule_obj = x:get("content_audit", rule_name)
        end
        if (rule_obj == nil) then
            local rule_cnt = x:get("content_audit", "count", "im_rule")
            increase = tonumber(rule_cnt) + 1
            x:set("content_audit", "count", "im_rule", increase)
            rule_name = "im_rule_" .. increase
            x:set("content_audit", rule_name, "im_rule")
            x:set("content_audit", rule_name, "policy_name", policy)
            x:set("content_audit", rule_name, "rule_id", increase)
            x:set("content_audit", rule_name, "action", "deny")
            x:set("content_audit", rule_name, "enable", "1")
            x:set("content_audit", rule_name, "im_type", "qq")
            x:set("content_audit", rule_name, "relation", "or")
        end
        x:set("content_audit", rule_name, "time_range", tr_group)
        
        --im_obj创建
        local old_obj_name = x:get("content_audit", rule_name, "account")
        if (old_obj_name == nil or old_obj_name == "") then
            local obj_cnt = x:get("content_audit", "count", "im_obj")
            increase = tonumber(obj_cnt) + 1
            x:set("content_audit", "count", "im_obj", increase)
            obj_name = "im_obj_" .. increase
        else 
            obj_name = old_obj_name
        end
        
        im_obj = x:get("content_audit", obj_name)
        if (im_obj ~= nil) then
            x:delete("content_audit", obj_name, "key")
        else
            x:set("content_audit", obj_name, "content_object")
        end
        x:set("content_audit", rule_name, "account", obj_name)
        
        --url_obj成员：url_class设置
        x:set("content_audit", obj_name, "key", account)
        
        return rule_name
    elseif (rule_name ~= nil) then
        --policy-->im_rule-->account-->..
        obj_name = x:get("content_audit", rule_name, "account")
        --删除策略下的app_rule和对应的应用识别对象，timerange由外部处理
        x:delete("content_audit", policy, "im_rule")
        x:delete("content_audit", rule_name)
        if (obj_name ~= nil) then
            x:delete("content_audit", obj_name)
        end
    end
    
    return nil
end

local function ca_set_rules(policy, rules)
    local rule_name
    local rule_list = {}
    
    rule_name = ca_set_app_rule(policy, rules["app_group"], rules["applist"], rules["tr_group"])
    rule_list["app_rule"] = rule_name
    
    rule_name = ca_set_url_rule(policy, rules["url_obj"], rules["url_class"], rules["tr_group"])
    rule_list["url_rule"] = rule_name
    
    rule_name = ca_set_im_rule(policy, rules["im_obj"], rules["account"], rules["tr_group"])
    rule_list["im_rule"] = rule_name
    
    return rule_list
end

--创建policy段及设置相关参数
local function ca_add_policy()
    --创建policy段
    local policy_cnt = x:get("content_audit", "count", "policy")
    local increase = tonumber(policy_cnt) + 1
    local policy = "policy_" .. increase
    x:set("content_audit", policy, "policy")
    x:set("content_audit", "count", "policy", increase)
    
    --计数控制
    local policy_total = x:get("content_audit", "count", "policy_total")
    local policy_total_num = tonumber(policy_total) + 1
    x:set("content_audit", "count", "policy_total", policy_total_num)
    
    --组件开关控制
    local enable = x:get("content_audit", "content_audit", "enable")
    if (policy_total_num > 0 and enable == "0") then
        x:set("content_audit", "content_audit", "enable", "1")
        need_open_module=true
    end
    
    return policy
end

local function ca_set_policy(is_ext_policy, policy, usr_name, rule_list)
    --关联rule和usr，删除的时候有用
    local rule_types = {"app_rule", "url_rule", "im_rule"}
    for i, val in ipairs(rule_types) do
        if (rule_list[val] ~= nil and rule_list[val] ~= "") then
            x:set("content_audit", policy, val, rule_list[val])
        end
    end
    x:set("content_audit", policy, "usr_name", usr_name)
    if (is_ext_policy) then
        x:set("content_audit", policy, "is_extern", "1")
    else
        x:set("content_audit", policy, "is_extern", "0")
    end
    
end

local function ca_add_ext_policy(ext_policy, policy, source)
    x:set("content_audit", ext_policy, "ext_policy")
    x:set("content_audit", ext_policy, "name", policy)
    x:set("content_audit", ext_policy, "source", source)
end

local _CA_POLICY_ADD = {}

function _CA_POLICY_ADD.exec(inStr)
    if (inStr == nil) then
        return "{\"code\":\"-1\", \"msg\":\"parameter is null\"}"
    end

    local jsonStr = cjson.decode(inStr)

    local new_ext_policy=nil
    local is_ext_policy=false
    local source = jsonStr["source"] 

    if (jsonStr["ext_policy"] ~= nil and jsonStr["ext_policy"] ~= "") then
        if (x:get("content_audit", jsonStr["ext_policy"]) ~= nil) then
            jsonStr["policy"] = x:get("content_audit", jsonStr["ext_policy"], "name")
        else
            new_ext_policy = jsonStr["ext_policy"]
        end
        is_ext_policy=true
        if (source == nil) then
            source = ""
        end
    end

    local policy = jsonStr["policy"]
    version = x:get("app_identify", "signature", "version")
    if (policy == "") then
        policy = ca_add_policy()
    elseif (policy == nil) then
        return
    end

    --同时支持多种类型的rule，多个rule共用一个timerange
    --内部接口，有需要修改的，直接修改整个json格式，不用考虑前向兼容
    local rules={}
    rules["app_group"]  = jsonStr["app_group"]
    rules["applist"]    = jsonStr["applist"]    --应用组对象
    rules["im_obj"]     =  jsonStr["im_obj"] 
    rules["account"]    = jsonStr["account"]    --IM对象
    rules["url_obj"]    = jsonStr["url_obj"] 
    rules["url_class"]  = jsonStr["url_class"]  --URL对象
    rules["tr_group"]    = jsonStr["tr_group"]  --时间对象

    local user_name = ca_set_usr(policy, jsonStr["ip_group"], jsonStr["ip_slots"], jsonStr["mac_list"])
    local rule_list = ca_set_rules(policy, rules)
    ca_set_policy(is_ext_policy, policy, user_name, rule_list)

    if (new_ext_policy ~= nil) then
        ca_add_ext_policy(new_ext_policy, policy, source)
    end

    return "{\"code\":\"0\", \"msg\":\"\",\"policy\":\"" .. policy .."\"}"
end

function _CA_POLICY_ADD.commit()
    x:commit("app_identify")
    x:commit("content_audit")
    
    if (need_open_module) then
        need_open_module = false
        os.execute("/bin/sh /usr/sbin/web/app_idy_set_module.sh content_audit on")
        os.execute("insmod /lib/modules/$(uname -r)/content_audit.ko")
        os.execute("/etc/init.d/content_audit start 1>/dev/null > /dev/null")
    end
end

--直接执行lua的情况
if (arg[1] ~= nil and string.sub(arg[0], -string.len("ca_set_policy.lua")) == "ca_set_policy.lua") then
    ret=_CA_POLICY_ADD.exec(arg[1])
    _CA_POLICY_ADD.commit()
    print(ret)
end

return _CA_POLICY_ADD
