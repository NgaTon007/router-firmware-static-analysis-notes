package.path = "/usr/sbin/web/?.lua;/usr/lib/lua/?.lua"

local ctmngt = require("ca_time_manager")
local x = require("uci").cursor()
local version = x:get("content_audit", "signature", "version")
function split_time_range(value)
    local tab = {}
	local mon_time_cnt = 1
	local tue_time_cnt = 1
	local wed_time_cnt = 1
	local thu_time_cnt = 1
	local fri_time_cnt = 1
	local sat_time_cnt = 1
	local sun_time_cnt = 1
	
	for i=1, #value do
	    local str = value[i]
		local pos1 = string.find(str, "%-")
		if(pos1) then
			local weekdays = string.sub(str, 1, pos1-1)
			local sub_str = string.sub(str, pos1+1)
			local pos2 = string.find(sub_str, "%-")
			if(pos2) then
				local time_start = string.sub(sub_str, 1, pos2-1)
				local time_stop = string.sub(sub_str, pos2+1)
				local time_node = {}
				table.insert(time_node, time_start)
				table.insert(time_node, time_stop)
				if(weekdays == "mon" or weekdays == "1") then
				    if(tab["mon"] == nil) then
					    tab["mon"] = {}
					end
					tab["mon"][mon_time_cnt] = time_node
					mon_time_cnt = mon_time_cnt + 1
				elseif(weekdays == "tue" or weekdays == "2") then
				    if(tab["tue"] == nil) then
					    tab["tue"] = {}
					end
					tab["tue"][tue_time_cnt] = time_node
					tue_time_cnt = tue_time_cnt + 1
				elseif(weekdays == "wed" or weekdays == "3") then
				    if(tab["wed"] == nil) then
					    tab["wed"] = {}
					end
					tab["wed"][wed_time_cnt] = time_node
					wed_time_cnt = wed_time_cnt + 1
				elseif(weekdays == "thu" or weekdays == "4") then
				    if(tab["thu"] == nil) then
					    tab["thu"] = {}
					end
					tab["thu"][thu_time_cnt] = time_node
					thu_time_cnt = thu_time_cnt + 1
				elseif(weekdays == "fri" or weekdays == "5") then
				    if(tab["fri"] == nil) then
					    tab["fri"] = {}
					end
					tab["fri"][fri_time_cnt] = time_node
					fri_time_cnt = fri_time_cnt + 1
				elseif(weekdays == "sat" or weekdays == "6") then
				    if(tab["sat"] == nil) then
					    tab["sat"] = {}
					end
					tab["sat"][sat_time_cnt] = time_node
					sat_time_cnt = sat_time_cnt + 1
				elseif(weekdays == "sun" or weekdays == "7") then
				    if(tab["sun"] == nil) then
					    tab["sun"] = {}
					end
					tab["sun"][sun_time_cnt] = time_node
					sun_time_cnt = sun_time_cnt + 1
				end
			end
		end
	end

	return tab
end

function get_cls_name(section_num, url_policy_list)
	local cfg_name = ""

	if (version == "3") then
		if (url_policy_list[section_num]["url_available"] == "1") then
			cfg_name = "ca_url_list_en"
		else
			cfg_name = "ca_url_list"
		end
	else
		if (url_policy_list[section_num]["url_available"] == "1") then
			cfg_name = "ca_url_list"
		else
			cfg_name = "ca_url_list_en"
		end
	end

	url_policy_list[section_num]["class_name"] = {}
	for i, v in ipairs(url_policy_list[section_num]["url_class"]) do
		local name = x:get(cfg_name, v, "name")
		url_policy_list[section_num]["class_name"][i] = name
	end
end

function main()

	local json_info = {}

	local section_num = 1
	local url_policy_list = {}

	x:foreach("content_audit","url_rule",function(s)
		local section_name = s[".name"]
		local policy_name = x:get("content_audit", section_name, "policy_name")
        local is_extern = x:get("content_audit", policy_name, "is_extern")
        if (is_extern ~= "1") then
            url_policy_list[section_num] = {}
		url_policy_list[section_num]["policy"] = policy_name

		-- user_group的能力值判断，get显示选择
		if (user_grp_cap == "1") then
			local content_usr = x:get("content_audit", policy_name, "usr_name")
			if (content_usr == nil) then
				return 0;
			end
			if (string.find(content_usr, "self_usr") ~= nil) then
				url_policy_list[section_num]["ip_group"] = ""
				url_policy_list[section_num]["ip_name"] = ""
				url_policy_list[section_num]["ip_slots"] = x:get("content_audit", content_usr, "ip_range")
				url_policy_list[section_num]["user_group_list"] = {}
			else
				local content_usr_grp = x:get("content_audit", policy_name, "usr_group")
				if (content_usr_grp ~= nil) then
					url_policy_list[section_num]["ip_group"] = ""
					url_policy_list[section_num]["ip_name"] = ""
					url_policy_list[section_num]["ip_slots"] = {}
					url_policy_list[section_num]["user_group_list"] = x:get("content_audit", content_usr_grp, "user_list")
				end
			end
		else
			local content_usr = x:get("content_audit", policy_name, "usr_name")
			local pos1 = string.find(content_usr, "self_usr")
			if (pos1) then
				url_policy_list[section_num]["ip_group"] = ""
				url_policy_list[section_num]["ip_name"] = ""
				url_policy_list[section_num]["ip_slots"] = x:get("content_audit", content_usr, "ip_range")			
			else
				url_policy_list[section_num]["ip_group"] = content_usr
				url_policy_list[section_num]["ip_name"] = x:get("content_audit", content_usr, "name")
				url_policy_list[section_num]["ip_slots"] = {}
			end
		end

		local time_range = x:get("content_audit", section_name, "time_range")
		local pos2 = string.find(time_range, "self_tr")
		if (pos2) then
		    url_policy_list[section_num]["tr_group"] = ""
	--[[		url_policy_list[section_num]["tr_name"] = ""
			local value = x:get("content_audit", time_range, "time")
			if (value) then
				url_policy_list[section_num]["tr_slots"] = split_time_range(value)
			else
			    url_policy_list[section_num]["tr_slots"] = {}
			end
	--]]
	        local tab = ctmngt.get_time_range(time_range)
			if (tab) then
	            url_policy_list[section_num]["tr_slots"] = tab
			else
			    url_policy_list[section_num]["tr_slots"] = {}
			end
		else
		    url_policy_list[section_num]["tr_group"] = time_range
	--		url_policy_list[section_num]["tr_name"] = x:get("content_audit", time_range, "name")
			url_policy_list[section_num]["tr_slots"] = {}
		end
		--[获取time_mode--]
	--	local time_mode = x:get("content_audit", time_range, "mode")
		url_policy_list[section_num]["time_mode"] = "calendar"
		--[获取action--]
		local action = x:get("content_audit", section_name, "action")
		url_policy_list[section_num]["action"] = action
		--[获取策略已配置的url_class--]
    --		local tab = {}
	    local url_obj = x:get("content_audit", section_name, "url_object")
		local url_cls_tab = x:get("content_audit", url_obj, "url_class")
    --[[
		for index, value in pairs(url_cls_tab) do
		    local url_alias_name = x:get("ca_url_list", value, "name")
			table.insert(tab, url_alias_name)
		end
    --]]
		url_policy_list[section_num]["url_class"] = url_cls_tab
		local enable = x:get("content_audit", section_name, "enable")
		url_policy_list[section_num]["enable"] = enable
		local url_available = x:get("content_audit", section_name, "url_available")
		url_policy_list[section_num]["url_available"] = url_available
		get_cls_name(section_num, url_policy_list)
		local comment = x:get("content_audit", section_name, "comment")
		url_policy_list[section_num]["comment"] = comment 
		section_num = section_num + 1
        end
	end
	)
	
	json_info = url_policy_list
	local cjson = require "luci.json" 
	local jsonStr = cjson.encode(json_info);
	print(jsonStr)
end

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
    return
end
user_grp_cap = arg[1]
main()