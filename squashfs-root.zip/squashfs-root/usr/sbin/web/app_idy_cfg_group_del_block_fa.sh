opt=$1
rst="fail"
msg="config fail!"
opt2=$2

####����Block_Group
if [ $opt = "-b" ]; then
  /usr/sbin/idyc -G -b -n -a$opt2
  if [ $? = "1" ]; then
    uci del_list app_identify.@Block_Group[0].app=$opt2
    rst="succ"
    msg="config success!"
  fi
fi

uci commit app_identify

if [ $rst = "succ" ]; then
  return 0
else
  return 1
fi
