package.path = "/usr/lib/lua/?.lua;" .. package.path;

local function split(str, reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

--[计算左边空格的数目--]
local function calc_space_count(str)
    local count = 0
	for i=1, 5 do
	    local pos = string.find(str, "    ", count)
		if(pos) then
		    count = count + 4
		else
		    return count
		end
	end
end

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
    return
end

local lib_param = require("libc2lua")
local cjson = require "cjson"  
local jsonStr = cjson.decode(arg[1]);
local json_info = {}

local function main()
	if (lib_param.lua_param_safety_check(jsonStr["app_index"]) ~= true) then
		return
	end
    local pos1 = string.find(jsonStr["app_index"], "-")
	local part1 = string.sub(jsonStr["app_index"], 1, pos1-1) .. "-0-0-0"
	local pos2 = string.find(jsonStr["app_index"], "-", pos1+1) 
	local part2 = string.sub(jsonStr["app_index"], 1, pos2-1) .. "-0-0"
	local pos3 = string.find(jsonStr["app_index"], "-", pos2+1)
	local part3 = string.sub(jsonStr["app_index"], 1, pos3-1) .. "-0"
	local part4 = jsonStr["app_index"]
	
    local t = io.popen("idyc -t | grep -E ' "..part1.."| "..part2.."| "..part3.."| "..part4.."'")
	local str = t:read("*all")
	if (str ~= "") then
	    local a = split(str, '\n')
	    for i=1, #a do
			local space_count = calc_space_count(a[i])
			local data = string.sub(a[i], space_count+1, -1)
			local pos = string.find(data, " ")
			local app_name = string.sub(data, 1, pos-1)
			json_info[i] = app_name
		end	
	else
	    json_info[1] = "未知应用"
	end
	local cjson = require "luci.json" 
	local json_result = cjson.encode(json_info);
	print(json_result)
end

main()