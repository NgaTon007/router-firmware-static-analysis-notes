#!/bin/sh
OVPN_PKI="/etc/easy-rsa/pki"
export EASYRSA_PKI="${OVPN_PKI}"
export EASYRSA_REQ_CN="ovpnca"
export EASYRSA_BATCH="1"
# Create a new CA
if [ ! -f "${OVPN_PKI}/ca.crt" ]; then
    # Remove and re-initialize the PKI directory
    easyrsa init-pki
    easyrsa build-ca nopass
fi

# Generate a key pair and sign locally for a server
if [ ! -f "${OVPN_PKI}/issued/server.crt" ]; then
    easyrsa build-server-full server nopass
fi

# Generate a key pair and sign locally for a client
if [ ! -f "${OVPN_PKI}/issued/client.crt" ]; then
    easyrsa build-client-full client nopass
fi

# Generate TLS PSK
if [ ! -f "${OVPN_PKI}/tls.key" ]; then
    /usr/sbin/openvpn --genkey --secret ${OVPN_PKI}/tls.key
fi
