#!/usr/bin/env lua
--[[
    pbr_del_stale_intf.lua
    删除不存在接口（含子接口）关联的策略路由规则。
    调用方式：
        lua /usr/sbin/web/pbr_del_stale_intf.lua policy_route
        lua /usr/sbin/web/pbr_del_stale_intf.lua policy_routev6
--]]
local x = require("luci.model.uci").cursor()
local cjson = require "cjson"
local libc2lua = require "libc2lua"
local dev_config = require "dev_config"
require "public_module"

local JSON_PATH = {
    policy_route   = "/etc/sd_config/single/policy_route.json",
    policy_routev6 = "/etc/sd_config/single/policy_routev6.json",
}

local function file_read(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local content = f:read("*a")
    f:close()
    return content
end

local function main()
    local module = arg[1]
    if module ~= "policy_route" and module ~= "policy_routev6" then
        return
    end

    local content = file_read(JSON_PATH[module])
    if content == nil then return end

    local config = cjson.decode(content)
    if config == nil or config.list == nil then return end

    -- 检查接口是否存在于 UCI network 配置
    local function intf_exists(intf)
        return x:get("network", intf) ~= nil
    end

    -- 判断某条规则是否需要删除，返回 true 表示需要删除
    local function should_delete(rule)
        if rule.name == nil then
            return false
        end

        local intfGrpType = rule.intfGrpType

        -- user 接口组由外部系统管理，策略不能删除
        if intfGrpType == "user" then
            return false
        end

        if intfGrpType == "auto" then
            -- auto 接口组：只要有一个 wan* 成员仍存在，就保留策略
            -- 只有全部 wan* 成员都不存在时才删除策略
            local grpList = rule.intfGrpList
            if type(grpList) ~= "table" or #grpList == 0 then
                return false
            end

            local any_wan = false
            local all_gone = true
            for _, member in ipairs(grpList) do
                if type(member) == "string" and member:match("^wan") then
                    any_wan = true
                    if intf_exists(member) then
                        all_gone = false
                        break
                    end
                end
            end

            -- 仅在有 wan* 成员且全部消失时删除策略
            return any_wan and all_gone
        else
            -- single 接口（intfGrpType 为空或不存在）：原有逻辑，仅检查 wan* 接口
            local intf = rule.intf
            if type(intf) ~= "string" or intf == "" then
                return false
            end
            if not intf:match("^wan") then
                return false
            end
            return not intf_exists(intf)
        end
    end

    local rule_names = {}
    for _, rule in ipairs(config.list) do
        if should_delete(rule) then
            table.insert(rule_names, rule.name)
        end
    end

    if #rule_names == 0 then return end

    local del_tab = { rulename = rule_names }
    if module == "policy_route" then
        del_tab.vpn_cfg = "0"
    end
    local del_str = cjson.encode(del_tab)
    -- 注意：del_str 中策略名称允许含特殊字符，开启安全检查会导致含特殊字符的策略无法被删除
    -- if libc2lua.lua_param_safety_check(del_str) ~= true then
    --     return
    -- end
    dev_config.fetch("del", module, del_str, 1)
end

main()