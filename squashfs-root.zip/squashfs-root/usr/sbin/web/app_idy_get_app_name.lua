require("uci")
x = uci.cursor()

function split(str, reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

--[计算左边空格的数目--]
function calc_space_count(str)
    local count = 0
	for i=1, 5 do
	    local pos = string.find(str, "    ", count)
		if(pos) then
		    count = count + 4
		else
		    return count
		end
	end
end

function main()
    local name_list = {}
    local json_info = {}
    local t = io.popen("/usr/sbin/idyc -t")
    local str = t:read("*all")
    local a = split(str, "\n")
    for i = 2, #a do
        local pos = calc_space_count(a[i])
        local s = string.sub(a[i], pos + 1, -3)
        local s1 = string.reverse(s)
        local pos1 = string.find(s1, "%s", 1)
        local name = string.sub(s, 1, #s - pos1)
        name_list[i] = name
    end
    
    x:foreach("app_identify", "Custom_Group", function(s)
        local section_name = s[".name"]
        local pos = string.find(section_name, "fc_")
        local pos1 = string.find(section_name, "csm_")
        local name
        if (pos ~= nil and pos1 == nil) then
            name = string.sub(x:get("app_identify", section_name, "name"), 4)
            name_list[#name_list + 1] = name
        elseif (pos1 ~= nil and pos == nil) then
            name = string.sub(x:get("app_identify", section_name, "name"), 5)
            name_list[#name_list + 1] = name
        else
            name = x:get("app_identify", section_name, "name")
            name_list[#name_list + 1] = name
        end

    end
    )

    x:foreach("app_identify", "Custom_Group_En", function(s)
        local section_name = s[".name"]
        local pos = string.find(section_name, "fc_")
        local pos1 = string.find(section_name, "csm_")
        local name

        if (pos ~= nil and pos1 == nil) then
            name = string.sub(x:get("app_identify", section_name, "name"), 4)
            name_list[#name_list + 1] = name
        elseif (pos1 ~= nil and pos == nil) then
            name = string.sub(x:get("app_identify", section_name, "name"), 5)
            name_list[#name_list + 1] = name
        else
            name = x:get("app_identify", section_name, "name")
            name_list[#name_list + 1] = name
        end
    end
    )
    name_list[1] = "null"
    name_list[#name_list + 1] = "自定义应用"
    name_list[#name_list + 1] = "Custom_App"
    json_info["list"] = name_list
    local cjson = require "luci.json"
    local jsonStr = cjson.encode(json_info)
    print(jsonStr)
end

main()
