#! /usr/bin/lua
package.path = "/usr/sbin/web/?.lua"
package.path = "/usr/lib/lua/?.lua;" .. package.path;

require("uci")
uci_cursor = uci.cursor()
cjson = require "luci.json"

local function interface_exists(itf)
    if type(itf) ~= "string" or itf == "" then
        return false
    end

    -- 使用 UCI 库直接检查 network 下对应 section 是否存在
    if not uci_cursor then
        return false
    end

    return uci_cursor:get("network", itf) ~= nil
end

local function main()
    -- 获取url_route配置文件
    local param = {}
    local policy = {}
    local idx_arr = {}

    -- 获取dev_config get -m urlRoute配置文件信息
    local t2 = io.popen("dev_config get -m urlRoute")
    local a2 = t2:read("*all")
    t2:close()
    local url_route_config = cjson.decode(a2)

    -- 配置异常时直接退出，避免后续遍历报错
    if type(url_route_config) ~= "table" or type(url_route_config["policy"]) ~= "table" then
        return
    end

    -- 遍历所有策略：仅当 itf_list 中所有接口都不存在时，删除该策略
    for _, value in ipairs(url_route_config["policy"]) do
        local itf_list = value["itf_list"]
        if type(itf_list) == "table" and #itf_list ~= 0 then
            local any_interface_exists = false
            for _, v in ipairs(itf_list) do
                -- 只要命中一个存在接口，就保留该策略，排除虚拟接口，不删除策略
                if (type(v) ~= "string" or string.sub(v, 1, 3) ~= "wan") or interface_exists(v) then
                    any_interface_exists = true
                    break
                end
            end

            if not any_interface_exists then
                table.insert(idx_arr, value["idx"])
            end
        end
    end

    -- 如果数组idx_array长度为0，则不执行删除命令
    if #idx_arr == 0 then
        return
    end

    -- 调用配置框架命令删除策略
    policy["idx_array"] = idx_arr
    param["policy"] = policy
    local cmd = "dev_config del -m urlRoute '"..cjson.encode(param).."'"
    os.execute(cmd)

end

main()