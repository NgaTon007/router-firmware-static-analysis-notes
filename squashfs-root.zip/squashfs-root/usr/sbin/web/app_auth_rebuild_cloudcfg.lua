package.path = "/usr/sbin/web/?.lua;/usr/lib/lua/?.lua"
require "public_module"
local product = require("product");

paramFmtType=product.get_product("capacity.portal.param_fmt")
local app_auth_cloud = product.get_product("capacity.portal.app_auth_cloud")
config_file = "/etc/sd_config/single/" .. app_auth_cloud .. ".json"
config_table = public_module.read_file(config_file)

if (config_table["paramFmt"] == nil) then
    config_table["paramFmt"] = {}
    config_table["paramFmt"]["request"] = {
        ["paramFmtType"] = paramFmtType,
        ["method"] = "get",
        ["params"] = {}
    }
    config_table["paramFmt"]["request"]["params"] = {
        [1] = {["type"] = "nas_mac",    ["key"] = "nas_mac",     ["val"] = "NULL"},
        [2] = {["type"] = "client_mac", ["key"] = "client_mac",  ["val"] = "NULL"},
        [3] = {["type"] = "orig_url",   ["key"] = "url",         ["val"] = "NULL"},
        [4] = {["type"] = "nas_ip",     ["key"] = "nas_ip",      ["val"] = "NULL"},
        [5] = {["type"] = "login_url",  ["key"] = "login_url",   ["val"] = "NULL"},
        [6] = {["type"] = "logout_url", ["key"] = "logout_url",  ["val"] = "NULL"},
        [7] = {["type"] = "ssid",       ["key"] = "ssid",        ["val"] = "NULL"}
    }

    config_table["paramFmt"]["respone"] = {
        ["username"] = "username",
        ["password"] = "password",
        ["next_url"] = "next_url"
    }

    config_table["authenMlist"] = "4"
    config_table["acctMlist"]   = "5"
    config_table["authorMlist"] = "6"

else
    if (config_table["paramFmt"]["request"]["paramFmtType"] == "DrayTek") then
        config_table["paramFmt"]["request"]["paramFmtType"] = "Custom"
    end
end

--����dev_config��ģ��json�����ļ�
public_module.write_file(config_table, config_file)
