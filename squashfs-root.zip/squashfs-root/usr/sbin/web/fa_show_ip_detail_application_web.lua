package.path = "/usr/lib/lua/?.lua;"
local libc2lua = require("libc2lua");

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"type parameter error\"}")
    return
end
if (libc2lua.lua_param_safety_check(arg[1]) ~= true) then
    print("{\"code\":\"-1\", \"msg\":\"[app_detail]param is no safety \"}")
	return
end

if string.match(arg[1], "\\n") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end
if string.match(arg[1], ">") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end

function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

local in_cjson = require "cjson" 
local jsonStr = in_cjson.decode(arg[1]);
local sub_info = {}
local sub_info1 = {}
local ip_info = {}
local name_info = {}
local ip, app, group
local passUp
local passDown
local cjson = require "dkjson"
local ary_data = {}
local ary_data1 = {}
local cnt = 1
local count = 1
local t
local cmd1 = "/usr/sbin/flow_audit_cmd.elf -S -r -s -g"
local cmdhead = "/usr/sbin/flow_audit_cmd.elf -S -r -d -g --ip "
local cmdTail = ""
local cmd

function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

if (jsonStr["ip"] == nil or #jsonStr["ip"] == 0) then
    t = io.popen(cmd1)
    for line in t:lines() do
        if (string.sub(line, -1) == "\r") then
            line = string.sub(line, 1, string.len(line) - 1)
        end
        table.insert(sub_info1, line)
    end
    for i=5,#sub_info1, 3 do
        local info = lua_string_split_space(sub_info1[i])
        ip = info[2]
        table.insert(ip_info, ip)
        table.insert(name_info, info[1]);
    end
else
    for i=1,#jsonStr["ip"], 1 do
        -- table.insert(ip_info, jsonStr["ip"][i])
        t = io.popen(cmd1.." --ip "..jsonStr["ip"][i])
        for line in t:lines() do
            if (string.sub(line, -1) == "\r") then
                line = string.sub(line, 1, string.len(line) - 1)
            end
            table.insert(sub_info1, line)
        end
        for i=5,#sub_info1, 3 do
            local info = lua_string_split_space(sub_info1[i])
            ip = info[2]
            table.insert(ip_info, ip)
            table.insert(name_info, info[1]);
        end
    end
end

if (jsonStr["dir"] == nil or jsonStr["order"] == nil) then
    cmdTail = ""
else
	if (jsonStr["order_type"] == "top") then
        cmdTail = " --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"].." --top "..jsonStr["top"]
    elseif (jsonStr["order_type"] == "page") then
        cmdTail = " --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"].." --start "..jsonStr["pos"].." --limit "..jsonStr["limit"]
	else
		cmdTail = " --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"]
	end
end

ary_data["ipOnlineInfo"] = {}
for i=1,#ip_info, 1 do
    ary_data["ipOnlineInfo"][count] = {}
    ary_data["ipOnlineInfo"][count]["ip"] = ip_info[i]
    ary_data["ipOnlineInfo"][count]["userName"] = name_info[i]
    ary_data["ipOnlineInfo"][count]["appInfo"] = {}
    if (ip_info[i] == name_info[i]) then
        cmd = cmdhead..ip_info[i].." --subs-name ".."\"\""..cmdTail
    else
        cmd = cmdhead..ip_info[i].." --subs-name "..name_info[i]..cmdTail
    end
    t = io.popen(cmd)
    sub_info = {}
    for line in t:lines() do
        if (string.sub(line, -1) == "\r") then
            line = string.sub(line, 1, string.len(line) - 1)
        end
        table.insert(sub_info, line)
    end
    cnt = 1
    for i=5,#sub_info, 3 do
        local info = lua_string_split_space(sub_info[i+1])
        app = info[1]
        info = lua_string_split_space(sub_info[i+2])
        passUp = info[1]
        passDown = info[2]
        ary_data["ipOnlineInfo"][count]["appInfo"][cnt] = {}
        ary_data["ipOnlineInfo"][count]["appInfo"][cnt]["appName"] = app
        ary_data["ipOnlineInfo"][count]["appInfo"][cnt]["up"] = passUp
        ary_data["ipOnlineInfo"][count]["appInfo"][cnt]["down"] = passDown
        cnt = cnt + 1
    end
    count = count + 1
end


local jsonStr = cjson.encode(ary_data);
print(jsonStr);
