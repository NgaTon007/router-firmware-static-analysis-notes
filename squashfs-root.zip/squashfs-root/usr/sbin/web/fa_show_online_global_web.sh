/usr/sbin/flow_audit_cmd.elf -S -o -g | /usr/sbin/web/fa_show_online_global.sh
