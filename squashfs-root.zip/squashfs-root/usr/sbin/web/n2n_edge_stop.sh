#!/bin/sh
natRule_cap=$(cat /tmp/sd_device/sd_device.json|jq .eweb.natRule 2&>1|xargs)
echo " " > /tmp/iptables.rules/n2n_edge_policy
/usr/sbin/iptables -w -t filter -D FORWARD_sd_chain -i sdw0 -j ACCEPT 2>/dev/null
/usr/sbin/iptables -w -t filter -D FORWARD_sd_chain -i sdwtun0 -j ACCEPT 2>/dev/null
/usr/sbin/iptables -w -t filter -D INPUT_sd_chain -p udp -m udp -m set --match-set INPUT_zone_sdwan dst,dst -j ACCEPT 2>/dev/null
/usr/sbin/ip6tables -w -t filter -D INPUT_sd_chain -p udp -m udp -m set --match-set INPUT_zone_sdwan6 dst,dst -j ACCEPT 2>/dev/null
if [ "$natRule_cap"x == "1"x ]; then
    /usr/sbin/iptables -w -t nat -D POSTROUTING_nat_rule_sdwan -o sdw0 -j sdwan_postrouting 2>/dev/null
    /usr/sbin/iptables -w -t nat -D POSTROUTING_nat_rule_sdwan -o sdwtun0 -j sdwan_postrouting 2>/dev/null
else
    /usr/sbin/iptables -w -t nat -D POSTROUTING_sd_chain -o sdw0 -j sdwan_postrouting 2>/dev/null
    /usr/sbin/iptables -w -t nat -D POSTROUTING_sd_chain -o sdwtun0 -j sdwan_postrouting 2>/dev/null
fi
/usr/sbin/iptables -w -t nat -F sdwan_postrouting 2>/dev/null
/usr/sbin/iptables -w -t nat -X sdwan_postrouting 2>/dev/null
if [ "$natRule_cap"x == "1"x ]; then
    /usr/sbin/iptables -w -t nat -D PREROUTING_nat_rule_sdwan -i sdw0 -j sdwan_prerouting 2>/dev/null
    /usr/sbin/iptables -w -t nat -D PREROUTING_nat_rule_sdwan -i sdwtun0 -j sdwan_prerouting 2>/dev/null
else
    /usr/sbin/iptables -w -t nat -D PREROUTING_sd_chain -i sdw0 -j sdwan_prerouting 2>/dev/null
    /usr/sbin/iptables -w -t nat -D PREROUTING_sd_chain -i sdwtun0 -j sdwan_prerouting 2>/dev/null
fi
/usr/sbin/iptables -w -t nat -F sdwan_prerouting 2>/dev/null
/usr/sbin/iptables -w -t nat -X sdwan_prerouting 2>/dev/null
ipset flush INPUT_zone_sdwan 2>/dev/null
ipset flush INPUT_zone_sdwan6 2>/dev/null
