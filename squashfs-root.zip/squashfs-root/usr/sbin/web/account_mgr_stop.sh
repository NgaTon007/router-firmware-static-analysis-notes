#!/bin/sh
. /lib/functions.sh

should_stop_service() {
    local enable api_service_enable CONFIG
    
    enable=$(uci -q get app_auth.app_auth.enable | xargs echo)
    CONFIG=$(dev_config get -m apiServiceCfg 2>/dev/null)
    
    if echo "$CONFIG" | jq -e '.services | length == 0' >/dev/null 2>&1; then
        api_service_enable=0
    else
        api_service_enable=1
    fi

    # ֻ������enable��Ϊ0ʱ��ֹͣ
    if [ "$enable"x == "0"x ] && [ "$api_service_enable"x == "0"x ]; then
        return 0
    else
        return 1
    fi
}

if should_stop_service; then
    /etc/init.d/account_mgr stop 2&>1 > /dev/null
    echo "stop account_mgr service"
else
    echo "not stop account_mgr service"
fi