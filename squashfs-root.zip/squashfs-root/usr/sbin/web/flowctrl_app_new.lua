local x = require("luci.model.uci").cursor()
local cjson = require "cjson"
local lib_app = require "flowctrl.flowctrl_app"
require "public_module"

local id_is_exist=0
local cfg_index=0
local old_section
local app_section
local del_section = {}

local function update_template(template,app_version,config_table)
	--删除json
	config_table["list"]={}
	local template_section
	if (app_version == "2" or app_version == "4") then
		template_section = "template"
	elseif (app_version == "3") then
		template_section = "template_En"
	end

	local tab_key={}
	tab_key["appGrp"]="key"
	local tab_block={}
	tab_block["appGrp"]="block"

	local flag = 0
	x:foreach("flowctrl_template",template_section,function(s)
		local section = s[".name"]
		if (section == template) then
			x:foreach("flowctrl","default_policy",function(s)
				local tmp_section = s[".name"]
				x:delete("flowctrl", tmp_section)
			end
			)

			local new_section=x:add("flowctrl","default_policy")
			local appgroup_key = x:get("flowctrl_template", section, "app_group_key")
			if (appgroup_key~=nil) then
				x:set("flowctrl", new_section, "app_group_key", appgroup_key)
				tab_key["appList"]=appgroup_key
			else
				tab_key["appList"] = {}
			end

			local appgroup_block = x:get("flowctrl_template", section, "app_group_block")
			if (appgroup_block~=nil) then
				x:set("flowctrl", new_section, "app_group_block", appgroup_block)
				tab_block["appList"] = appgroup_block
			else
				tab_block["appList"] = {}
			end
			x:set("flowctrl", new_section, "version", app_version)
			flag = 1
		end
	end
	)

	--国际特征库下下发home，home与国际特征库不对应，应该为home_En，因此退出不做接下来的操作
	if (flag == 0) then
		print("{\"code\":\"-1\", \"msg\":\"template no match app_version\"}")
		return
	end

	--写到应用识别配置当中
	x:foreach("app_identify",app_section,function(s)
		local section = s[".name"]
		local pos_key = string.find(section,"fc_applist_key")
		if (pos_key) then
			lib_app.app_idy_del_config_app_group(nil, section)
		end

		local pos_block = string.find(section,"fc_applist_block")
		if (pos_block) then
			lib_app.app_idy_del_config_app_group(nil, section)
		end
	end
	)

	x:foreach("flowctrl_template", template_section, function(s)
		local section = s[".name"]
		if (section == template) then
			local applist_key = x:get("flowctrl_template", section, "app_group_key")
			local applist_block = x:get("flowctrl_template", section, "app_group_block")

			if (applist_key == nil) then
				applist_key = {}
			end

			if (applist_block == nil) then
				applist_block = {}
			end

			lib_app.app_idy_add_app_config_policy(applist_key, "key", app_version)
			lib_app.app_idy_add_app_config_policy(applist_block, "block", app_version)
			return
		end
	end)

	x:foreach("flowctrl", "global", function(s)
		x:set("flowctrl", s[".name"], "template", template)
	end)

	x:commit("flowctrl")
	config_table["template"]=template
	table.insert(config_table["list"],tab_key)
	table.insert(config_table["list"],tab_block)
end

local group_key
local group_block
local function check_group_is_exist(uci_section,app_version)
	x:foreach("app_identify", app_section, function(s)
		local section = s[".name"]
		if (section == uci_section) then
			id_is_exist = 1
			cfg_index = s[".index"]
			old_section = section
			return
		end
    end)

	x:foreach("flowctrl", "default_policy", function(s)
		local section = s[".name"]
		group_key=x:get("flowctrl", section,"app_group_key")
		group_block=x:get("flowctrl", section,"app_group_block")
    end)
	return
end

local function update_config_policy(jsonStr,app_version,config_table)
	--list为空以及超过1个元素
	if (#jsonStr["list"] == 0 or #jsonStr["list"] > 1) then
		print("{\"code\":\"-1\", \"msg\":\"param list is empty or too big\"}")
		return -1
	end

	if (jsonStr["list"][1]["appGrp"] == nil) then
		print("{\"code\":\"-1\", \"msg\":\"appGrp is empty\"}")
		return -1
	end

	local app_group = jsonStr["list"][1]["appGrp"]
	uci_section="fc_applist_"..app_group
	check_group_is_exist(uci_section,app_version)
	if (id_is_exist ~= 0) then --名字相同且section相同，起始判断section就行。
		--无table.update操作，只能删除旧的节点，重新添加。
		x:foreach("flowctrl","default_policy",function(s)
			local section = s[".name"]
			x:delete("flowctrl", section)
		end)

		--删除json
		config_table["list"]={}
		local new_section=x:add("flowctrl", "default_policy")
		local tab_key={}
		tab_key["appGrp"]="key"
		local tab_block={}
		tab_block["appGrp"]="block"

		--添加特征库版本号
		x:set("flowctrl", new_section, "version", app_version)
		if (jsonStr["list"][1]["appGrp"]=="key") then
			if (jsonStr["list"][1]["appList"][1]~=nil) then
				x:set("flowctrl", new_section, "app_group_key", jsonStr["list"][1]["appList"])
				tab_key["appList"]=jsonStr["list"][1]["appList"]
			else
				tab_key["appList"] = {}
			end

			if (group_block~=nil) then
				x:set("flowctrl", new_section, "app_group_block", group_block)
				tab_block["appList"] = group_block
			else
				tab_block["appList"] = {}
			end
		end

		if (jsonStr["list"][1]["appGrp"]=="block") then
			if (jsonStr["list"][1]["appList"][1]~=nil) then
				x:set("flowctrl", new_section, "app_group_block", jsonStr["list"][1]["appList"])
				tab_block["appList"]=jsonStr["list"][1]["appList"]
			else
				tab_block["appList"] = {}
			end

			if (group_key~=nil) then
				x:set("flowctrl", new_section, "app_group_key", group_key)
				tab_key["appList"]=group_key
			else
				tab_key["appList"] = {}
			end
		end

		table.insert(config_table["list"],tab_key)
		table.insert(config_table["list"],tab_block)
		--04-23，去除app_idy.lock的修订，删掉重建，因为传入app_list长度为0时，若app_list原来存在，则不会清空app_list，因此要先删除，再增加
		lib_app.app_idy_del_config_app_group(nil, uci_section)
		lib_app.app_idy_add_app_config_policy(jsonStr["list"][1]["appList"], app_group, app_version)
		x:commit("flowctrl")
		return 0
	else
		print("{\"code\":\"-1\", \"msg\":\"policy has no exist\"}")
	end
	
	return -1
end

local function main()
	if (arg[1] == nil or arg[2] == nil or arg[3] == nil or arg[4] == nil) then
		print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
		return
	end

	local ret = 0
	local jsonStr = cjson.decode(arg[2]);
	local app_version=arg[3]
	local template
	local config_file = arg[4]

	config_table = public_module.read_file(config_file)
	if (config_table == nil) then
		print("{\"code\":\"-1\", \"msg\":\"config file is not exist\"}")
		return
	end

	if (app_version=="2" or app_version=="4") then
		app_section="Custom_Group"
	elseif (app_version=="3") then
		app_section="Custom_Group_En"
	else
		print("{\"code\":\"-1\", \"msg\":\"app_version  is not exist\"}")
	end

	--处理更新
	if (arg[1] == "update") then
		if (jsonStr["template"] == nil) then
			--更新单个规则
			ret = update_config_policy(jsonStr,app_version,config_table)
			if (ret ~= 0) then
				return
			end
		else
			update_template(jsonStr["template"],app_version,config_table)
		end
	end

	public_module.write_file(config_table, config_file)
end

main()
