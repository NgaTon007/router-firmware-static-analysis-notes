package.path = string.format("%s;%s;/www/guest_auth/?.lua;/tmp/?.lua", package.path, "./?.lua")
local module_debug = require "utils.debug"
local cjson = require "luci.json" 
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local VOUCHER_PUB_DIR = "/etc/guest_auth/voucher/"
local EMMC_LOCAL_PORTAL_DTR = "/mnt/mmcblk0p1/config/guest_auth/"
local SPI_FLASH_PORTAL_DIR = "/etc/guest_auth/"
local lfs = require "lfs"
require "pub"
local server_name = require("product").get_product("capacity.portal.server_name")

local user_mac_list = {}
local user_list = {}
local max_user_sta_by_groupuuid = {}
local groupname_by_groupuuid = {}

local voucher_group_list = {}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
local function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_get_cloud_voucher.log", 500, module_debug.INFO, "1");
end

local function traceback(msg)
    module_debug.lua_debug(module_debug.ERROR, debug.traceback());
end

local function mac_format(param)
    local format_mac = ""
    local i = 1
    while (i <= 11) 
    do
        local sub_str = string.sub(param, i, i + 3)
        format_mac = format_mac.."."..sub_str
        i = i + 4
    end
    format_mac = string.sub(format_mac, 2, 15)
    return format_mac
end

local function is_spt_emmc()
    local cmd = "cat /tmp/sd_device/sd_device.json | jq .gateway.spt_emmc | sed 's/\"//g' | xargs echo -n"
    local t = io.popen(cmd)
    local res = t:read("*all")
    t:close()
    res = string.gsub(res, "\n", "")
    if res == "1" then
        return true
    else
        return false
    end
end

local function mac_get()
    local uci = require "luci.model.uci".cursor()
    local user_type = server_name .. "_voucher_user"
    if is_spt_emmc() == true then
        uci:set_confdir(EMMC_LOCAL_PORTAL_DTR)
    end
    uci:foreach("guest_auth_user", user_type,function(s)
        local mac = {}
        local name_section = s[".name"]
        local username = uci:get("guest_auth_user", name_section, "username")
        local enc_type =  uci:get("guest_auth_user", name_section, "enc_type")
        mac = uci:get_list("guest_auth_user", name_section, "mac")
        local format_mac_list = {}
        local format_mac = ""
        for k, v in pairs (mac) do
            format_mac = mac_format(v)
            module_debug.lua_debug(module_debug.DEBUG, "mac is %s\n", format_mac)
            table.insert(format_mac_list, format_mac)
        end
        if enc_type == nil or enc_type == "0"then
            if not user_list[username] then
                user_list[username] = {}
                user_list[username]["mac"] = format_mac_list
            else
                local user_tmp =cjson.encode(user_list[username])
                for m, n in pairs(format_mac_list) do
                    local startPos = string.find(user_tmp, n)
                    if (startPos == nil) then
                        table.insert(user_list[username]["mac"], n)
                    end
                end
            end  
        else
            local username_clear = aes256_decode(username)
            if not user_list[username_clear] then
                user_list[username_clear] = {}
                user_list[username_clear]["mac"] = format_mac_list
            else
                local user_tmp =cjson.encode(user_list[username_clear])
                for m, n in pairs(format_mac_list) do
                    local startPos = string.find(user_tmp, n)
                    if (startPos == nil) then
                        table.insert(user_list[username_clear]["mac"], n)
                    end
                end
            end  
        end
    end
    )

    module_debug.lua_debug(module_debug.DEBUG, "user_list is %s\n", cjson.encode(user_list))
    if is_spt_emmc() == true then
        uci:set_confdir(SPI_FLASH_PORTAL_DIR)
    end
end

local function voucher_file_get()
    for file in lfs.dir(VOUCHER_PUB_DIR) do
        if (file ~= "." and file ~= "..") then
            local file_name = VOUCHER_PUB_DIR.."/"..file
            local attr = lfs.attributes(file_name)
            assert(type(attr)=="table")
            if (attr.mode == "file") then
                table.insert(voucher_group_list, file)
            end
        end
    end
    table.sort(voucher_group_list)
end

function string.split(str, delimiter)
    if str==nil or str=='' or delimiter==nil then
        return nil
    end
    
    local result = {}
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end

local function max_users_get()
    local uci = require "luci.model.uci".cursor()
    uci:foreach("user_mgr", "user_grp", function(s)
        local name = s[".name"]
        local groupname = uci:get("user_mgr", name, "name")
        local max_users = uci:get("user_mgr", name, "maxUsers")
        if (max_users ~= nil) then
            local groupuuid = uci:get("user_mgr", name, "uuid")
            if (groupuuid ~= nil) then
                max_user_sta_by_groupuuid[groupuuid] = tonumber(max_users)
                groupname_by_groupuuid[groupuuid] = groupname
                module_debug.lua_debug(module_debug.DEBUG, "groupname_by_groupuuid[groupuuid]: %s \n", groupname_by_groupuuid[groupuuid]);
                module_debug.lua_debug(module_debug.DEBUG, "max_user_sta_by_groupuuid[groupuuid]: %d \n", max_user_sta_by_groupuuid[groupuuid]);
            else
                print("{\"code\":\"-1\", \"msg\":\"uuid is nil!\"}") 
                os.exit()
            end
        end
    end
    )
end

local function get_voucher_by_group(param)
    local index = tonumber(param["index"])
    local read_page = tonumber(param["readPage"])
    local page_size = 2000
    local result = {}
    result["total"] = #voucher_group_list
    result["groupName"] = groupname_by_groupuuid[voucher_group_list[index]]
    result["conCurrentNum"] = max_user_sta_by_groupuuid[voucher_group_list[index]]
    result["currentPage"] = param["readPage"]
    result["keepRead"] = "0"
    result["voucher"] = {}
    module_debug.lua_debug(module_debug.DEBUG, "index is %d  it's file path is %s \n", index, VOUCHER_PUB_DIR..voucher_group_list[index])
    local file = io.open(VOUCHER_PUB_DIR..voucher_group_list[index], "r")
    if io.type(file) == nil then
        module_debug.lua_debug(module_debug.DEBUG, "filepath is %s open err\n", VOUCHER_PUB_DIR..v)
        return 
    end

    local line_num = 0
    local valid_line_num = 0
    local start_line = read_page * page_size + 1
    local end_line = (read_page + 1) * page_size
    for line in file:lines() do
        if (string.sub(line, -1) == "\r") then
            line = string.sub(line, 1, string.len(line) - 1)
        end
            
        if (line_num == 0) then
            -- result["conCurrentNum"] = tonumber(string.sub(line, 1))
        else
            if line_num >= start_line and line_num <= end_line then -- 是否在当前页
                local voucher_obj = {}
                -- 加判断是否是空行
                if (line ~= "\n") then
                    -- 最后一行有可能是空行？
                    local line_str_tab = string.split(line, ',')

                    -- 第 5 列为enc_type
                    if (#line_str_tab < 5) then
                        line_str_tab[5] = "0"
                    else
                        local dec_code = aes256_decode(line_str_tab[1])
                        if (dec_code ~= nil) then
                            line_str_tab[1] = dec_code
                        end
                    end
                    -- vouche明文显示，enc_type固定固定 0
                    voucher_obj["enc_type"] = "0"
                    voucher_obj["code"] = line_str_tab[1]
                    voucher_obj["validity"] = line_str_tab[3]
                    voucher_obj["mac"] = {}
                    if (user_list[voucher_obj["code"]] == nil) then
                        voucher_obj["mac"] = {}
                    else
                        voucher_obj["mac"] = user_list[voucher_obj["code"]]["mac"]
                    end
                    table.insert(result["voucher"], voucher_obj)    
                end 
            end
            if (line_num > end_line and (line ~= "\n" and line:gsub("^%s*$", "") ~= "")) then
                result["keepRead"] = "1"
                break
            end
        end
        line_num = line_num + 1
    end
    table.insert(result["voucher"], voucher_list_obj)
    return result
end

-- 根据/etc/guest_auth/voucher/下文件名得到
-- 按行读文件，只读第一个逗号前的voucher账号 
-- uci查询maclist 
function main()
    if (arg[1] == nil) then
        print("{\"code\":\"-1\", \"msg\":\"param err\"}")
        return
    end

    module_debug.lua_debug(module_debug.DEBUG, "################################MAIN START################################")
    local param = cjson.decode(arg[1])
    if (param == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: param is nil")
        return "{\"code\":\"-1\",\"msg\":\"param is nil!\"}"
    end
    module_debug.lua_debug(module_debug.DEBUG, "Start get cloud voucher")

    -- 没有数据时直接返回
    if (tool.file_exist(VOUCHER_PUB_DIR) == false) then
        module_debug.lua_debug(module_debug.INFO, "INFO:/etc/guest_auth/voucher/ not exist\n")
        os.exit()
    end
    voucher_file_get()
    if (next(voucher_group_list) == nil) then
        module_debug.lua_debug(module_debug.INFO, "INFO:voucher files not exist\n")
        os.exit()
    end
    -- debug
    for k,v in pairs(voucher_group_list) do
        module_debug.lua_debug(module_debug.DEBUG, "voucher group:%s\n", v)
    end
    local uci = require "luci.model.uci".cursor()
    local mac_flag = uci:get("guest_auth", "guest_auth", "senseFreeValidity")
    if (mac_flag ~= nil and mac_flag ~= "0") then 
        -- 无感知时显示曾经上线过的所有mac
        mac_get()
    end

    max_users_get()
    
    local result = get_voucher_by_group(param)
    
    print(cjson.encode(result))
end

debug_init()
xpcall(main, traceback)