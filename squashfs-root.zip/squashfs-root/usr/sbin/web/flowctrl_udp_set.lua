--v1.2: 2022-08-23
--新增自定义应用组：jiangzehao
local x = require("luci.model.uci").cursor()
local cjson = require "cjson"
local lib_app = require "flowctrl.flowctrl_app"
local jsonStr = cjson.decode(arg[1]);
local max_udf_num = cjson.decode(arg[2]);
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR="/tmp/flowctrl/"
local lib_user = require "user_mgr.user_mgr_common"
local lib_app_idy = require "app_identify.app_idy_pub"
local default_tc_pri="4"
local max_normal_policy=30

local cus_del_json='{"csm_group":{"operation":"del_count","grpNameArr":[]}}'
local cus_add_json='{"csm_group":{"operation":"add_count","grpNameArr":[]}}'
local tr_del_json='{"moduleName":"flowctrl","opt":"deref","tmngtName":""}'
local tr_add_json='{"moduleName":"flowctrl","opt":"ref","tmngtName":""}'
local tr_batch_del_json='{"mode":"batch","list":[], "opt":"deref"}'
local tr_batch_add_json='{"mode":"batch","list":[], "opt":"ref"}'
local product_json_file="/tmp/sd_device/product.json"
local user_json='{"list":[]}'
local del_intf_grp = { list = {} }
local batch_intf_grp = { list = {} }
local pri_grp_list = {}
local fc_wan_grp = {}
local policy_comment_grp={}
local intf_grp_cap = 0

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "opteration.log", 500, module_debug.INFO, "1");
end

local function check_policy(enable_s, intf, intf_type, intf_uuid, intf_list, idyc_version, app_group_name, ip_start, ip_end)
    local ret = false

	--老版本app有下发null的bug
	if (ip_start == "null" or ip_end== "null") then
		return 0
	end

    local version=x:get("app_identify","signature","version")
	--有自定义应用组才检查
	if (app_group_name ~= nil and idyc_version ~= version) then
		return 0
	end

    ret = lib_app.check_intf(intf, intf_type, intf_uuid, intf_list, fc_wan_grp, intf_grp_cap)
    if (ret == false) then
        return 0
    end

	--时序问题，有0必须返回0，没0才能返回-1 0代表接口、特征库不对，-1代表关闭开关
	if (enable_s == "off") then
		return -1
	end

    return 1
end

local function policy_param_check()
    local total_cnt=0
    local cloud_cnt=0
    local product_table=public_module.read_file(product_json_file)

    if (product_table == nil) then
        module_debug.lua_debug(module_debug.ERROR, "have no product_table");
        return -1
    end

    if (product_table["capacity"]["cloud"] == nil or #product_table["capacity"]["cloud"] == 0) then
        module_debug.lua_debug(module_debug.ERROR, "have no cloud capacity");
        return -1
    end

    local cloud_key=product_table["capacity"]["cloud"]
    for i=1, #jsonStr["list"] do
        if (jsonStr["list"][i]["comment"] == nil or #jsonStr["list"][i]["comment"] == 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy comment is nil");
            return -1
        end
        if (policy_comment_grp[jsonStr["list"][i]["comment"]] ~= nil) then
            module_debug.lua_debug(module_debug.ERROR, "policy comment %s already exists, idx %d, current idx %d", jsonStr["list"][i]["comment"], policy_comment_grp[jsonStr["list"][i]["comment"]], i);
            return -1
        end
        policy_comment_grp[jsonStr["list"][i]["comment"]]=1

        if (jsonStr["list"][i]["ipPri"] ~= nil and #jsonStr["list"][i]["ipPri"] > 0) then
            ip_pri = tonumber(jsonStr["list"][i]["ipPri"])
            if (ip_pri == nil or ip_pri > lib_app.max_ip_pri) then
                module_debug.lua_debug(module_debug.ERROR, "set udp policy[%s] ip_pri[%s] is error!!!", jsonStr["list"][i]["comment"], jsonStr["list"][i]["ipPri"]);
                return -1
            end
        end

        total_cnt=total_cnt+1
        if (jsonStr["list"][i]["type"] ~= nil and #jsonStr["list"][i]["type"] > 0) then
            if (jsonStr["list"][i]["type"] == cloud_key) then
                cloud_cnt=cloud_cnt+1
            end
        end

        if (jsonStr["list"][i]["pri"] ~= nil and #jsonStr["list"][i]["pri"] > 0) then
            local pri_key=jsonStr["list"][i]["pri"]
            if (pri_grp_list[pri_key] ~= nil) then
                module_debug.lua_debug(module_debug.ERROR, "normal policy pri %s already exists, idx %d, current idx %d", pri_key, pri_grp_list[pri_key], i);
                return -1
            else
                pri_grp_list[pri_key]=i
            end
        end

        --新增ip_pri检查
        if (jsonStr["list"][i]["ipPri"] ~= nil and #jsonStr["list"][i]["ipPri"] > 0) then
            local ip_pri = tonumber(jsonStr["list"][i]["ipPri"])
            if (ip_pri == nil or ip_pri > lib_app.max_ip_pri) then
                module_debug.lua_debug(module_debug.ERROR, "set udp policy[%s] ip_pri[%s] is error", jsonStr["list"][i]["comment"], jsonStr["list"][i]["ipPri"]);
                return -1;
            end
        end

        --新增dscp检查
        if (jsonStr["list"][i]["dscp"] ~= nil and #jsonStr["list"][i]["dscp"] > 0) then
            local dscp = tonumber(jsonStr["list"][i]["dscp"])
            if (dscp == nil or dscp > lib_app.max_dscp) then
                module_debug.lua_debug(module_debug.ERROR, "set udp policy[%s] dscp[%s] is error", jsonStr["list"][i]["comment"], jsonStr["list"][i]["dscp"]);
                return -1;
            end
        end

        --新增时间管理检查
        if (lib_app.fc_tmngt_grp_check(jsonStr["list"][i]) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] tmnt group check failed", jsonStr["list"][i]["comment"]);
            return -1;
        end

        --新增接口组检查
        if (lib_app.fc_intf_grp_check(jsonStr["list"][i]) < 0) then
            module_debug.lua_debug(module_debug.ERROR, "policy[%s] interface group check failed", jsonStr["list"][i]["comment"]);
            return -1;
        end
    end

    local normal_cnt = total_cnt-cloud_cnt
    if (normal_cnt > max_normal_policy) then
        module_debug.lua_debug(module_debug.ERROR, "normal policy cnt excced %d, normal_cnt %d cloud_cnt %d", max_normal_policy, normal_cnt, cloud_cnt);
        return -1
    end

    return 0;
end

--main流程
debug_init()

--获取接口组能力值
intf_grp_cap = lib_app.get_intf_grp_capability()

if (policy_param_check() < 0) then
    module_debug.lua_debug(module_debug.ERROR, "udp policy param check failed");
    os.exit(1);
end

--删除内部配置
local cus_flag=0
local app_flag=0
local user_flag=0
local tr_flag=0
local intf_flag=0
local cus_json=cjson.decode(cus_del_json)
local user_del_json=cjson.decode(user_json)
local del_app_grp = {}
del_app_grp["appGrp"]={}
local tr_deref_set_table=cjson.decode(tr_batch_del_json)
x:foreach("flowctrl", "user_def_policy", function(s)
    local app_grp = x:get("flowctrl", s[".name"], "app_group")
    local app_list = x:get("flowctrl", s[".name"], "app")
    local tr_group = x:get("flowctrl", s[".name"], "tr_group")
    local user_grp = x:get("flowctrl", s[".name"], "user_group_name")
    local intf_grp = x:get("flowctrl", s[".name"], "intf_group")
    if (app_grp ~= nil and app_grp:sub(1,4) == "csm_") then
        table.insert(cus_json["csm_group"]["grpNameArr"], app_grp)
        cus_flag=1
    elseif (app_grp ~= nil and #app_grp > 0) then
        local policy_id = x:get("flowctrl", s[".name"], "policy_id")
        if (policy_id ~= nil) then
            table.insert(del_app_grp["appGrp"], "fc_applist_"..policy_id)
            app_flag=1
        else
            module_debug.lua_debug(module_debug.INFO, "policy_id is null");
        end
    end

    if (user_grp ~= nil and #user_grp > 0) then
        table.insert(user_del_json["list"], user_grp)
        user_flag=1
    end

    if (tr_group ~= nil and #tr_group > 0) then
        local del_json=cjson.decode(tr_del_json)
        del_json["tmngtName"]=tr_group
        table.insert(tr_deref_set_table["list"], del_json)
        tr_flag=1
        -- local config_tab = cjson.encode(del_json)
        -- local cmd = "dev_sta set -m tmngt_notify '"..config_tab.."'"
        -- os.execute(cmd)
        -- module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(del_json));
    end

    if (intf_grp ~= nil and string.sub(intf_grp, 1, 3) == "fc_") then
        table.insert(del_intf_grp.list, intf_grp)
        intf_flag=1
    end
    x:delete("flowctrl", s[".name"])
end)
-- module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(tr_deref_set_table));
x:commit("flowctrl")

if (tr_flag==1) then
    local tr_table=cjson.encode(tr_deref_set_table)
    local cmd = "dev_sta set -m tmngt_notify '"..tr_table.."'"
    os.execute(cmd)
    -- module_debug.lua_debug(module_debug.INFO, "%s", cmd);
end

if (cus_flag==1) then
    local config_tab = cjson.encode(cus_json)
    local cmd = "dev_config del -m custom_group '"..config_tab.."'"
    os.execute(cmd)
    -- module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(del_app_grp));
end

if (app_flag==1) then
    lib_app.app_idy_del_config_app_group(del_app_grp["appGrp"], nil)
end

if (user_flag==1) then
    local config_tab = cjson.encode(user_del_json)
    local cmd = "lua /usr/sbin/user_mgr_virtual_grp.lua del_list '"..config_tab.."'"
    os.execute(cmd)
    module_debug.lua_debug(module_debug.INFO, "%s", cmd);
end

if (intf_flag==1) then
    -- module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(del_intf_grp));
    lib_app.fc_intf_grp_del(del_intf_grp)
end
-- module_debug.lua_debug(module_debug.INFO, "%s", cjson.encode(config_cus_tab));

--添加策略
if #jsonStr["list"] == 0 then
	x:commit("flowctrl")
	return
end

local is_reset_pri=0
for i=1, #jsonStr["list"] do
	if (jsonStr["list"][i]["pri"] == nil) then
		is_reset_pri=1
		module_debug.lua_debug(module_debug.INFO, "the app version is old,reset pri");
		break
	end
end

--获取wan口的map
x:foreach("flowctrl","bandwidth",function(s)
    if (x:get("flowctrl",s[".name"],"itfs_exist") ~= "0") then
        fc_wan_grp[s[".name"]]=1
    end
end)

local cus_table=cjson.decode(cus_add_json)
local cus_add_flag=0
local user_grp_add_json=cjson.decode(user_json)
local user_grp_add_flag=0
local tr_ref_set_table=cjson.decode(tr_batch_add_json)
local tr_add_flag=0
local intf_add_flag=0
for i=1, #jsonStr["list"] do
repeat
	local reset_vip = 0
	--vip参数下发错误重新赋值
	if (jsonStr["list"][i]["type"] == "vip") then
		module_debug.lua_debug(module_debug.INFO, "type %s",jsonStr["list"][i]["type"]);
		if (jsonStr["list"][i]["allUpRateG"] == nil or jsonStr["list"][i]["allUpRateG"]=="") then
			module_debug.lua_debug(module_debug.INFO, "vip policy allUpRateG is nil");
			reset_vip = 1
		end

		if (jsonStr["list"][i]["allDownRateG"] == nil or jsonStr["list"][i]["allDownRateG"]=="") then
			module_debug.lua_debug(module_debug.INFO, "vip policy allDownRateG is nil");
			reset_vip = 1
		end

		if (jsonStr["list"][i]["ipRange"] == nil or jsonStr["list"][i]["ipRange"] ~= "") then
			module_debug.lua_debug(module_debug.INFO, "ipRange is error");
			jsonStr["list"][i]["ipRange"] = ""
		end

		if (jsonStr["list"][i]["user_group_list"] ~= nil and #jsonStr["list"][i]["user_group_list"] > 0) then
			module_debug.lua_debug(module_debug.INFO, "user_group_list is error");
			jsonStr["list"][i]["user_group_list"] = {}
		end

		if (jsonStr["list"][i]["appList"] ~= nil and #jsonStr["list"][i]["appList"] > 0) then
			module_debug.lua_debug(module_debug.INFO, "appList is error");
			jsonStr["list"][i]["appList"] = {}
		end

		if (jsonStr["list"][i]["vlanList"] == nil or #jsonStr["list"][i]["vlanList"] == 0) then
			module_debug.lua_debug(module_debug.INFO, "vlanList is error");
			local tab = "234"
			jsonStr["list"][i]["vlanList"]={}
			table.insert(jsonStr["list"][i]["vlanList"], tab)
		end

		if (reset_vip == 1) then
			jsonStr["list"][i]["allUpRateG"] = lib_app.vip_def_up_rate
			jsonStr["list"][i]["allDownRateG"] = lib_app.vip_def_down_rate
			jsonStr["list"][i]["allUpRate"] = lib_app.max_rate_tag
			jsonStr["list"][i]["allDownRate"] = lib_app.max_rate_tag
			jsonStr["list"][i]["downRate"] = lib_app.max_rate_tag
			jsonStr["list"][i]["upRate"] = lib_app.max_rate_tag
			jsonStr["list"][i]["downRateG"] = lib_app.vip_def_down_rate
			jsonStr["list"][i]["upRateG"] = lib_app.vip_def_up_rate
		end
	end

	local comment=jsonStr["list"][i]["comment"]
	local enable_s = jsonStr["list"][i]["enable"]
	--新版本app会下发pri字段，老版本不会
	local pri
	if (is_reset_pri==1) then
		--因为web交换策略顺序后，json上策顺序不改变，云端根据json全量下发，因此先考虑pri重新分配
		pri=tostring(150-i)
	else
		--新版云端根据pri排序json后下发
		pri=jsonStr["list"][i]["pri"]
	end

	local intf=jsonStr["list"][i]["intf"]
	local policy_id=i

	local name = x:add("flowctrl", "user_def_policy")
	--新增wholeWan
	local whole_wan = jsonStr["list"][i]["wholeWan"]
	if (whole_wan ~= nil) then
		x:set("flowctrl", name, "wholeWan", whole_wan)
	else
		x:set("flowctrl", name, "wholeWan", "0")
	end

	mode = jsonStr["list"][i]["mode"]
	if (mode == nil) then
		x:set("flowctrl", name, "mode", "share")
	else
		x:set("flowctrl", name, "mode", mode)
	end
	x:set("flowctrl", name, "enable", enable_s)
	x:set("flowctrl", name, "intf", intf)
	x:set("flowctrl", name, "ip_group", "fc_rule_"..i-1)
    --重新添加所有策略了，因此policy_id可以重新添加,用户组和应用组也重新添加
	x:set("flowctrl", name, "policy_id", policy_id)
	x:set("flowctrl", name, "pri", pri)
	local ip_start
	local ip_end
    if (jsonStr["list"][i]["ipRange"] ~= nil and #jsonStr["list"][i]["ipRange"] ~= 0) then
        local iprange = jsonStr["list"][i]["ipRange"]
		-- module_debug.lua_debug(module_debug.INFO, "ipRANGE[%s]",iprange);
        if (string.find(iprange, "-"))  then
            local m = string.find(iprange, "-")
			ip_start=string.sub(iprange, 1, m-1)
			ip_end=string.sub(iprange, m+1, string.len(iprange))
            x:set("flowctrl", name, "ip_start", ip_start)
            x:set("flowctrl", name, "ip_end", ip_end)
        else
			ip_start=jsonStr["list"][i]["ipRange"]
			ip_end=jsonStr["list"][i]["ipRange"]
            x:set("flowctrl", name, "ip_start", ip_start)
            x:set("flowctrl", name, "ip_end", ip_end)
        end
    else
		ip_start=lib_app.ip_tag
		ip_end=lib_app.ip_tag
        x:set("flowctrl", name, "ip_start", ip_start)
        x:set("flowctrl", name, "ip_end", ip_end)
    end
    --新增接口组
    local intf_type = jsonStr["list"][i]["intfGrpType"]
    local intf_grp = jsonStr["list"][i]["intfGrpUuid"]
    local intf_mem = jsonStr["list"][i]["intfGrpList"]
    if (intf_type ~= nil) then
        if (intf_type == "auto") then
            intf_group_name="fc_"..policy_id
            lib_app.fc_intf_grp_add_list(intf_group_name, intf_mem, batch_intf_grp.list)

            x:set("flowctrl", name, "intf_group", intf_group_name)
            x:set("flowctrl", name, "intf_type", intf_type)
            x:set("flowctrl", name, "intf_mem", intf_mem)

            intf_add_flag=1
        elseif (intf_type == "user") then
            x:set("flowctrl", name, "intf_group", intf_grp)
            x:set("flowctrl", name, "intf_type", intf_type)
        end
    end
	--新增vlanList
	if (jsonStr["list"][i]["vlanList"] ~= nil and #jsonStr["list"][i]["vlanList"] > 0) then
		x:set("flowctrl", name, "vlan", jsonStr["list"][i]["vlanList"])
	end

	x:set("flowctrl", name, "comment", jsonStr["list"][i]["comment"])

    --云端得下发idyc_version
    local idyc_version
    if (jsonStr["list"][i]["idyc_version"] ~= nil and #jsonStr["list"][i]["idyc_version"] > 0)then
        idyc_version=jsonStr["list"][i]["idyc_version"]
    else
        idyc_version=x:get("app_identify","signature","version")
    end
	x:set("flowctrl", name, "idyc_version", idyc_version)

    local app_group_name
    --老流控web不下发appList这个字段不能判断长度，因此要先判断是否为nil
	if (jsonStr["list"][i]["appList"] ~= nil and #jsonStr["list"][i]["appList"] > 0) then
        --重新添加应用组,会根据policy_id变化覆盖相应应用组
		lib_app.app_idy_add_app_config_policy(jsonStr["list"][i]["appList"], policy_id, idyc_version)
        app_group_name = "fc_"..policy_id
        x:set("flowctrl", name, "app_group", app_group_name)
        x:set("flowctrl", name, "app", jsonStr["list"][i]["appList"])
	--8-23新增自定义应用组
	elseif (jsonStr["list"][i]["customApp"] ~= nil and #jsonStr["list"][i]["customApp"] > 0) then
		x:set("flowctrl", name, "app_group", jsonStr["list"][i]["customApp"])
        table.insert(cus_table["csm_group"]["grpNameArr"], jsonStr["list"][i]["customApp"])
        cus_add_flag=1
		--2023-04-23修复set时不会计算引用计数bug
		-- lib_app_idy.custom_group_count_handle("add",jsonStr["list"][i]["customApp"],nil)
	end

    if (jsonStr["list"][i]["user_group_list"] ~= nil and #jsonStr["list"][i]["user_group_list"] > 0) then
        local user_arry={}
        user_group_name="fc_"..policy_id
        user_list=jsonStr["list"][i]["user_group_list"]
        user_arry["name"]=user_group_name
        user_arry["user_group_list"]=user_list
        table.insert(user_grp_add_json["list"], user_arry)
        user_grp_add_flag=1
        --重新添加用户组,会根据policy_id变化覆盖相应用户组,R86添加用户组没有覆盖原先用户组的逻辑，因此这边要先尝试删除
        -- lib_user.user_mgr_add_vgrp(user_group_name, user_list)
		debug_init()
        x:set("flowctrl", name, "user_group_name", user_group_name)
        x:set("flowctrl", name, "user_group", jsonStr["list"][i]["user_group_list"])
    end

	--新增时间管理
	local tr_type = jsonStr["list"][i]["tr_type"]
	local tr_slots = jsonStr["list"][i]["tr_slots"]
	local tr_range = jsonStr["list"][i]["tr_range"]
	local tr_group_name = jsonStr["list"][i]["tr_group"]
	if (tr_type ~= nil and #tr_type > 0) then
		if (tr_type == lib_app.tr_week_type) then
			tr_group_name="fc_"..policy_id
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_slots), "auto", lib_app.tr_week_type)
            local add_json=cjson.decode(tr_add_json)
            add_json["tmngtName"]=tr_group_name
            table.insert(tr_ref_set_table["list"], add_json)
            tr_add_flag=1
			-- lib_app.ref_time_config(tr_group_name)
			x:set("flowctrl", name, "tr_type", tr_type)
			x:set("flowctrl", name, "tr_slots", cjson.encode(tr_slots))
			x:set("flowctrl", name, "tr_group", tr_group_name)
		elseif (tr_type == lib_app.tr_date_type) then
			tr_group_name="fc_"..policy_id
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_range), "auto", lib_app.tr_date_type)
            local add_json=cjson.decode(tr_add_json)
            add_json["tmngtName"]=tr_group_name
            table.insert(tr_ref_set_table["list"], add_json)
            tr_add_flag=1
			-- lib_app.ref_time_config(tr_group_name)
			x:set("flowctrl", name, "tr_type", tr_type)
			x:set("flowctrl", name, "tr_range", cjson.encode(tr_range))
			x:set("flowctrl", name, "tr_group", tr_group_name)
		end

		local tr_effective=lib_app.check_policy_tr(tr_group_name)
		if (tr_effective ~= nil) then
			x:set("flowctrl", name, "tr_effective", tr_effective)
		else
			x:set("flowctrl", name, "tr_effective", 1)
		end
	elseif (tr_group_name ~= nil and #tr_group_name > 0) then
		x:set("flowctrl", name, "tr_group", tr_group_name)
        local add_json=cjson.decode(tr_add_json)
        add_json["tmngtName"]=tr_group_name
        table.insert(tr_ref_set_table["list"], add_json)
        tr_add_flag=1
		-- lib_app.ref_time_config(tr_group_name)
		local tr_effective=lib_app.check_policy_tr(tr_group_name)
		if (tr_effective ~= nil) then
			x:set("flowctrl", name, "tr_effective", tr_effective)
		else
			x:set("flowctrl", name, "tr_effective", 1)
		end
	else
		x:set("flowctrl", name, "tr_effective", 1)
	end

    local dscp = tonumber(jsonStr["list"][i]["dscp"])
	if (dscp ~= nil) then
		x:set("flowctrl", name, "dscp", dscp)
	end

    local ip_pri = tonumber(jsonStr["list"][i]["ipPri"])
	if (ip_pri ~= nil) then
		x:set("flowctrl", name, "ip_pri", ip_pri)
	end

    --能上云端的策略都是web下发的自定义策略
    local type = jsonStr["list"][i]["type"]
	if (type ~= nil) then
		x:set("flowctrl", name, "type", type)
    else
        x:set("flowctrl", name, "type", "web")
	end

	if (jsonStr["list"][i]["tcPri"] ~= nil and #jsonStr["list"][i]["tcPri"] > 0) then
		x:set("flowctrl", name, "tc_pri", jsonStr["list"][i]["tcPri"])
	else
		x:set("flowctrl", name, "tc_pri", default_tc_pri)
	end

	--为了兼容老版本下发配置所以做了个非空判断，不能根据能力值判断新老流控下发，因为可能设备升级但是app未升级
	--"allUpRate":""时 input_param["allUpRate"]非空，但是tonumber(input_param["allUpRate"]为空，认为是不限速模式
	local all_up_rate_g=jsonStr["list"][i]["allUpRateG"]
	local all_down_rate_g=jsonStr["list"][i]["allDownRateG"]
	local all_up_rate=jsonStr["list"][i]["allUpRate"]
	local all_down_rate=jsonStr["list"][i]["allDownRate"]
	local down_rate=jsonStr["list"][i]["downRate"]
	local up_rate=jsonStr["list"][i]["upRate"]
	local down_rate_g=jsonStr["list"][i]["downRateG"]
	local up_rate_g=jsonStr["list"][i]["upRateG"]
	if (tonumber(all_up_rate_g) ~= nil) then
		--旧版本升级上来，可能有all_up_rate_g，但是all_up_rate为空(json为空，标识取接口带宽)
		if (tonumber(all_up_rate) ~= nil) then
			x:set("flowctrl", name, "all_up_rate", all_up_rate)
		else --此情况只会出现在老版本per_ip策略升级上来，没有用户组最大
			x:set("flowctrl", name, "all_up_rate", lib_app.rate_tag)
		end

		if (tonumber(all_down_rate) ~= nil) then
			x:set("flowctrl", name, "all_down_rate", all_down_rate)
		else
			x:set("flowctrl", name, "all_down_rate", lib_app.rate_tag)
		end

		x:set("flowctrl", name, "all_up_rate_g", all_up_rate_g)
		x:set("flowctrl", name, "all_down_rate_g", all_down_rate_g)
		if (mode=="share") then
			--share 模式下必须有all_down_rate和all_up_rate，per_ip下可能没有
			if (tonumber(all_down_rate) == nil) then
				module_debug.lua_debug(module_debug.INFO, "policy comment[%s], mode [share], have no [all_down_rate],is error",comment);
				x:delete("flowctrl", name)
				break
			end

			if (tonumber(all_up_rate) == nil) then
				module_debug.lua_debug(module_debug.INFO, "policy comment[%s], mode [share], have no [all_up_rate],is error",comment);
				x:delete("flowctrl", name)
				break
			end
			--share模式下tonumber(all_down_rate) == nil情况下，回退老版本策略会失效
			x:set("flowctrl", name, "down_rate_g", all_down_rate_g)
			x:set("flowctrl", name, "up_rate_g", all_up_rate_g)
			x:set("flowctrl", name, "down_rate", all_down_rate)
			x:set("flowctrl", name, "up_rate", all_up_rate)
		else --为nil就认为不限速
			local down_rate=tonumber(down_rate)
			local up_rate=tonumber(up_rate)
			if (down_rate ~= nil) then
				x:set("flowctrl", name, "down_rate", down_rate)
			else
				x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", name, "up_rate", up_rate)
			else
				x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
			end

			--每用户的保障带宽取用户组带宽/5，默认5个用户使用
			local down_rate_g=math.floor(tonumber(all_down_rate_g)/lib_app.udp_cnt)
			local up_rate_g=math.floor(tonumber(all_up_rate_g)/lib_app.udp_cnt)
			if (down_rate ~= nil and down_rate_g > down_rate) then
				down_rate_g = down_rate
			end

			if (down_rate_g >= 1) then
				x:set("flowctrl", name, "down_rate_g", down_rate_g)
			else
				x:set("flowctrl", name, "down_rate_g", 1)
			end

			if (up_rate ~= nil and up_rate_g > up_rate) then
				up_rate_g = up_rate
			end

			if (up_rate_g >= 1) then
				x:set("flowctrl", name, "up_rate_g", up_rate_g)
			else
				x:set("flowctrl", name, "up_rate_g", 1)
			end
		end
	else	--不限速模式
		if (tonumber(up_rate_g) == nil) then
			x:set("flowctrl", name, "all_up_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "all_down_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "all_up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "all_down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			x:set("flowctrl", name, "up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
		else --此状态为旧流控的web或旧app下发
			if (mode=="share") then--share模式下配置uprate就为用户组带宽
				x:set("flowctrl", name, "all_up_rate", up_rate)
				x:set("flowctrl", name, "all_down_rate", down_rate)
				x:set("flowctrl", name, "all_up_rate_g", up_rate_g)
				x:set("flowctrl", name, "all_down_rate_g", down_rate_g)
			else--per_ip模式下，uprate为每用户带宽，用户组带宽要后面处理为接口带宽，这里打标记
				--all_up_rate_g可能会大于all_up_rate，放在flowctrl_tc_cfg中考虑，这边接口带宽未知
				local all_up_rate_g=tonumber(up_rate_g)*lib_app.udp_cnt
				local all_down_rate_g=tonumber(down_rate_g)*lib_app.udp_cnt
				local all_up_rate=lib_app.max_rate_tag
				local all_down_rate=lib_app.max_rate_tag
				if (all_up_rate_g > tonumber(all_up_rate)) then
					all_up_rate_g=all_up_rate
				end

				if (all_down_rate_g > tonumber(all_down_rate))then
					all_down_rate_g=all_down_rate
				end

				x:set("flowctrl", name, "all_up_rate", all_up_rate)
				x:set("flowctrl", name, "all_down_rate", all_down_rate)
				x:set("flowctrl", name, "all_up_rate_g", all_up_rate_g)
				x:set("flowctrl", name, "all_down_rate_g", all_down_rate_g)
			end

			--新流控per_ip每用户不限速上传后带down_rate:"",云端识别到这个不会下发
			if (down_rate ~= nil) then
				x:set("flowctrl", name, "down_rate", down_rate)
			else
				x:set("flowctrl", name, "down_rate", lib_app.rate_tag)
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", name, "up_rate", up_rate)
			else
				x:set("flowctrl", name, "up_rate", lib_app.rate_tag)
			end
			x:set("flowctrl", name, "down_rate_g", down_rate_g)
			x:set("flowctrl", name, "up_rate_g", up_rate_g)
		end
	end

	local effective=check_policy(enable_s, intf, intf_type, intf_grp, intf_mem, idyc_version, app_group_name,ip_start,ip_end)
	x:set("flowctrl", name, "effective", effective)
until true
end
x:commit("flowctrl")

if (tr_add_flag==1) then
    local tr_table=cjson.encode(tr_ref_set_table)
    local cmd = "dev_sta set -m tmngt_notify '"..tr_table.."'"
    os.execute(cmd)
    -- module_debug.lua_debug(module_debug.INFO, "%s", cmd);
end

if (cus_add_flag==1) then
    lib_app_idy.custom_group_count_handle("add",nil, cus_table["csm_group"]["grpNameArr"])
end

if (user_grp_add_flag==1) then
    local config_tab = cjson.encode(user_grp_add_json)
    local cmd = "lua /usr/sbin/user_mgr_virtual_grp.lua add_list '"..config_tab.."'"
    os.execute(cmd)
end

if (intf_add_flag==1) then
    lib_app.fc_intf_grp_batch(batch_intf_grp)
end
