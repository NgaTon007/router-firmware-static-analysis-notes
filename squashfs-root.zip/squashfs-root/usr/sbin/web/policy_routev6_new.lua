#!/usr/bin/env lua

local x = require("luci.model.uci").cursor()
local cjson = require "cjson" 
local libc2lua = require "libc2lua"
local dev_config = require "dev_config"
local module_debug = require "utils.debug"
require "public_module"

local PBR_PARAM_LOG_DIR = "/tmp/policy_route/"
os.execute("mkdir -p " .. PBR_PARAM_LOG_DIR .. " >/dev/null 2>&1")

local function is_sub_intf(name)
	return name and name:match("^wan%d*_%d+$") ~= nil
end

-- 根据接口类型确定 UCI section 类型
-- 子接口或接口组规则 → new_rule (旧版本不遍历此类型，实现兼容回退)
-- 单个主接口/虚拟口规则 → rule    (旧版本正常处理)
local function get_rule_section_type(intf_val, intfGrpType)
	if intfGrpType and intfGrpType ~= "" then
		return "new_rule"
	elseif intf_val and is_sub_intf(intf_val) then
		return "new_rule"
	else
		return "rule"
	end
end

-- 为auto接口组分配新UUID
-- 计数器持久化存储在 /etc/config/policy_routev6 的 pbr_globals section 中
-- counter_key: "pbr6_uuid_next" (v6)
local function alloc_auto_uuid(prefix, counter_key)
	if x:get("policy_routev6", "pbr_globals") == nil then
		x:set("policy_routev6", "pbr_globals", "globals")
	end
	local n = tonumber(x:get("policy_routev6", "pbr_globals", counter_key)) or 1
	x:set("policy_routev6", "pbr_globals", counter_key, tostring(n + 1))
	x:commit("policy_routev6")
	return prefix .. n
end

local is_exist=0
local cfg_index=0
local old_section
local json_repeat=0
local function check_name_is_exist(rule_name)
	is_exist = 0
	cfg_index = 0
	old_section = nil
	for _, sec_type in ipairs({"rule", "new_rule"}) do
		if is_exist == 1 then
			break
		end
		x:foreach("policy_routev6", sec_type, function(s)
			local name = s[".name"]
			if (x:get("policy_routev6", name, "name") == rule_name) then
				is_exist = 1
				cfg_index = s[".index"]
				old_section = name
				return
			end
	    end)
	end
	return
end

--多个添加时，检查json内部是否重复
local function check_json_name_is_repeat(jsonStr)
	--保证加入的策略名称都不重复
	for i,v in pairs(jsonStr["list"]) do
		for j=i+1,#jsonStr["list"] do
			if (v["name"] == jsonStr["list"][j]["name"]) then
				json_repeat=1
				return
			end
		end
	end
	return
end

--删除框架配置文件中的规则
local function delete_json_config_rule(rule_name, config_table)
    local ret = 0
    for k,v in pairs(config_table["list"]) do
        if (v["name"] == rule_name) then
            table.remove(config_table["list"], k)
			break
        end
    end
    return 0
end

--删除uci配置文件中的策略配置
local function del_uci_config_by_name(rule_name)
	for _, sec_type in ipairs({"rule", "new_rule"}) do
		x:foreach("policy_routev6", sec_type, function(s)
			local name = s[".name"]
			if (x:get("policy_routev6", name, "name") == rule_name) then
				x:delete("policy_routev6", name)
				return
			end
	    end)
	end
end

-- 同步auto接口组配置到dev_config
-- 同步auto接口组配置到dev_config
-- op: "add" / "update" / "del"
-- uuid: 接口组完整UUID（如 "pbr6_intf_group_123"），del时可为字符串或string table
-- mem_list: 成员接口名table（add/update时有效，del时传nil）
local function sync_auto_intfgroup(op, uuid, mem_list)
	local sync_tab = { list = {} }
	if op == "del" then
		-- uuid 可传单个字符串或 string table
		if type(uuid) == "table" then
			for _, u in ipairs(uuid) do
				table.insert(sync_tab.list, u)
			end
		else
			table.insert(sync_tab.list, uuid)
		end
	else
		local mem_arr = {}
		if type(mem_list) == "table" then
			for _, m in ipairs(mem_list) do
				table.insert(mem_arr, m)
			end
		end
		table.insert(sync_tab.list, {
			uuid = uuid,
			name = uuid,
			type = "auto",
			mem  = mem_arr,
		})
	end
	local json_str = cjson.encode(sync_tab)
	if libc2lua.lua_param_safety_check(json_str) ~= true then
		return
	end
	dev_config.fetch(op, "intfGroupMgr", json_str, 1)
end

-- 删除路径优化：先按 name 构建 auto UUID 索引，再批量删除，避免每个规则都重复扫描 UCI
local function build_auto_intfgrp_uuid_map()
	local uuid_by_name = {}
	for _, sec_type in ipairs({"rule", "new_rule"}) do
		x:foreach("policy_routev6", sec_type, function(s)
			local name = s[".name"]
			local rule_name = x:get("policy_routev6", name, "name")
			if rule_name ~= nil and rule_name ~= "" then
				local grp_type = x:get("policy_routev6", name, "intfGrpType")
				if grp_type == "auto" then
					local uuid = x:get("policy_routev6", name, "intfGrpUuid")
					if uuid ~= nil and uuid ~= "" then
						uuid_by_name[rule_name] = uuid
					end
				end
			end
		end)
	end
	return uuid_by_name
end

local function fill_new_section_and_rule(new_section, new_rule, input_param)
	x:set("policy_routev6", new_section, "enable", input_param["enable"])
	x:set("policy_routev6", new_section, "intf_switch", input_param["intf_switch"])
	x:set("policy_routev6", new_section, "name", input_param["name"])
	new_rule["enable"] = input_param["enable"]
	new_rule["intf_switch"] = input_param["intf_switch"]
	new_rule["name"] = input_param["name"]
	
	local protocol = input_param["proto"]
	x:set("policy_routev6", new_section, "proto", protocol)
	new_rule["proto"] = protocol
	if (protocol == "udef_proto") then
		x:set("policy_routev6", new_section, "udef_proto", input_param["udef_proto"])
		new_rule["udef_proto"] = input_param["udef_proto"]
	elseif (protocol == "tcp" or protocol == "udp") then
		x:set("policy_routev6", new_section, "sport", input_param["sport"])
		x:set("policy_routev6", new_section, "dport", input_param["dport"])
		new_rule["sport"] = input_param["sport"]
		new_rule["dport"] = input_param["dport"]
	end
	
	local srcip = input_param["sip"]
	x:set("policy_routev6", new_section, "sip", srcip)
	new_rule["sip"] = input_param["sip"]
	if (srcip == "udef_src") then
		x:set("policy_routev6", new_section, "sipRange", input_param["sipRange"])
		new_rule["sipRange"] = input_param["sipRange"]
	end
	
	local dstip = input_param["dip"]
	x:set("policy_routev6", new_section, "dip", dstip)
	new_rule["dip"] = input_param["dip"]
	if (dstip == "udef_dst") then
		x:set("policy_routev6", new_section, "dipRange", input_param["dipRange"])
		new_rule["dipRange"] = input_param["dipRange"]		
	end
	
	x:set("policy_routev6", new_section, "intf", input_param["intf"] or "")
	new_rule["intf"] = input_param["intf"] or ""

	-- 子接口兼容处理：子接口使用 sub_intf 字段，不设 intf，version1 自然跳过
	local intf_val = input_param["intf"] or ""
	if is_sub_intf(intf_val) then
		x:delete("policy_routev6", new_section, "intf")
		x:set("policy_routev6", new_section, "sub_intf", intf_val)
	end

	-- 接口组字段
	local intfGrpType = input_param["intfGrpType"]
	if (intfGrpType ~= nil and intfGrpType ~= "") then
		x:set("policy_routev6", new_section, "intfGrpType", intfGrpType)
		new_rule["intfGrpType"] = intfGrpType
	else
		new_rule["intfGrpType"] = ""
	end
	local intfGrpUuid = input_param["intfGrpUuid"]
	if (intfGrpUuid ~= nil and intfGrpUuid ~= "") then
		x:set("policy_routev6", new_section, "intfGrpUuid", intfGrpUuid)
		if (intfGrpType == "auto") then
			new_rule["intfGrpUuid"] = ""
		else
			new_rule["intfGrpUuid"] = intfGrpUuid
		end
	else
		new_rule["intfGrpUuid"] = ""
	end
	local intfGrpList = input_param["intfGrpList"]
	if (type(intfGrpList) == "table" and #intfGrpList > 0) then
		x:set("policy_routev6", new_section, "intfGrpList", intfGrpList)
		new_rule["intfGrpList"] = intfGrpList
	else
		new_rule["intfGrpList"] = {}
	end
end

local function update_config_policy(jsonStr, config_table)
	--list为空以及超过最大数量（最大值需计算）
	-- if (#jsonStr["list"] == 0 or #jsonStr["list"] > 30) then --更新策略应该不会超过最大数量
	if (#jsonStr["list"] == 0) then
		local msg = "param list is empty or too big"
		module_debug.lua_debug(module_debug.INFO, "update_config_policy error: %s", msg)
		print("{\"code\":\"-1\", \"msg\":\"param list is empty or too big\"}")
		return -1
	end

	check_json_name_is_repeat(jsonStr)
	if (json_repeat ~= 0) then
		local msg = "json name is repeat"
		module_debug.lua_debug(module_debug.INFO, "update_config_policy error: %s", msg)
		print("{\"code\":\"-1\", \"msg\":\"json name is repeat\"}")
		return -1
	end

	for i,v in pairs(jsonStr["list"]) do
		check_name_is_exist(v["name"])
		if (is_exist == 0) then
			local msg = "rule name is not exist"
			module_debug.lua_debug(module_debug.INFO, "update_config_policy error: %s", msg)
			print("{\"code\":\"-1\", \"msg\":\"rule name is not exist\"}")
			return -1
		end
	end

	for j=#jsonStr["list"],1,-1 do
		check_name_is_exist(jsonStr["list"][j]["name"])
		local vv = jsonStr["list"][j]

		-- 记录规则在 JSON 中的实际位置（按名字查找）
		local json_pos = nil
		for k, cv in ipairs(config_table["list"]) do
			if cv["name"] == vv["name"] then
				json_pos = k
				break
			end
		end

		-- 读取旧节点接口组信息，判断切换方向
		local old_intfGrpType = x:get("policy_routev6", old_section, "intfGrpType")
		local old_intfGrpUuid = x:get("policy_routev6", old_section, "intfGrpUuid")
		local new_intfGrpType = vv["intfGrpType"]

		if old_intfGrpType == "auto" and new_intfGrpType ~= "auto" then
			-- auto → 非auto: 删除旧接口组
			if old_intfGrpUuid ~= nil and old_intfGrpUuid ~= "" then
				sync_auto_intfgroup("del", old_intfGrpUuid, nil)
			end
		elseif old_intfGrpType == "auto" and new_intfGrpType == "auto" then
			-- auto → auto: 若请求未携带UUID则继承旧UUID
			if vv["intfGrpUuid"] == nil or vv["intfGrpUuid"] == "" then
				vv["intfGrpUuid"] = old_intfGrpUuid
			end
		elseif old_intfGrpType ~= "auto" and new_intfGrpType == "auto" then
			-- 非auto → auto: 分配新UUID
			if vv["intfGrpUuid"] == nil or vv["intfGrpUuid"] == "" then
				vv["intfGrpUuid"] = alloc_auto_uuid("pbr6_intf_group_", "pbr6_uuid_next")
			end
		end

		--删除旧的节点，重新添加，有的字段可能变化，无法直接更新。
		x:delete("policy_routev6", old_section)
		delete_json_config_rule(jsonStr["list"][j]["name"], config_table)

		local new_rule = {} --有没有好的办法，直接转一手？？
		local vv_update = jsonStr["list"][j]
		local uci_section = x:add("policy_routev6",
				get_rule_section_type(vv_update["intf"], vv_update["intfGrpType"]))
		fill_new_section_and_rule(uci_section, new_rule, jsonStr["list"][j])

		-- 同步接口组到dev_config
		if new_intfGrpType == "auto" and vv["intfGrpUuid"] ~= nil and vv["intfGrpUuid"] ~= "" then
			if old_intfGrpType == "auto" then
				-- auto → auto: 更新成员列表
				sync_auto_intfgroup("update", vv["intfGrpUuid"], vv["intfGrpList"])
			else
				-- 非auto → auto: 新建接口组
				sync_auto_intfgroup("add", vv["intfGrpUuid"], vv["intfGrpList"])
			end
		end

		-- 移到原始的位置
		x:reorder("policy_routev6", uci_section, cfg_index)
		-- JSON 插回原位置（不改变优先级）
		if json_pos then
			table.insert(config_table["list"], json_pos, new_rule)
		end
		--保存配置文件(外部统一保存)
		--public_module.write_file(config_table, config_file)
	end
	
	return 0
end

local moved=0
local function move_config_policy(jsonStr, opt, config_table)
	moved = 0
	--json配置文件移动(云端需dev_config)
	for k,v in pairs(config_table["list"]) do
        if (v["name"] == jsonStr["rulename"])
        then
            if (jsonStr["opt"] == "up")
            then
                if (k == 1) --如果是第一个，不能上移
                then 
                    break
                end
                table.remove(config_table["list"], k)
                table.insert(config_table["list"], k - 1, v)
            else  --下移
                --TODO 判断k是不是最后一个？
                if (k == #config_table["list"])
                then 
                    break
                end
                table.remove(config_table["list"], k)
                table.insert(config_table["list"], k + 1, v)
            end
            break
        end
    end

	-- 两种 section 类型均需遍历: rule(主接口/虚拟口), new_rule(接口组)
	for _, sec_type in ipairs({"rule", "new_rule"}) do
		if (moved ~= 0) then
			break
		end
		x:foreach("policy_routev6", sec_type, function(s)
			if (moved ~= 0) then
				return
			end
			local name = s[".name"]
			if (x:get("policy_routev6", name, "name") == jsonStr["rulename"]) then
				if (opt == "up") then
					--非第一个才上移(正常web也不会让第一个有上移选项)
					if (s[".index"] ~= 0) then
						x:reorder("policy_routev6", name, s[".index"] - 1)
						moved = 1
					end
				else
					--下移不用管序号
					x:reorder("policy_routev6", name, s[".index"] + 1)
					moved = 1
				end
				return
			end
	    end)
	end

end

local function del_config_policy(rule_name, config_table)
	-- 第一步：先构建 name -> auto UUID 索引，避免对每个 rule 再做一次双层遍历
	local auto_uuid_map = build_auto_intfgrp_uuid_map()
	-- 第二步：收集所有需删除的auto接口组UUID（去重）
	local auto_uuids = {}
	local auto_uuid_seen = {}
	for i, value in pairs(rule_name) do
		local auto_uuid = auto_uuid_map[value]
		if auto_uuid ~= nil and auto_uuid ~= "" and not auto_uuid_seen[auto_uuid] then
			auto_uuid_seen[auto_uuid] = true
			table.insert(auto_uuids, auto_uuid)
		end
	end
	-- 第三步：执行UCI和JSON删除
	for i, value in pairs(rule_name) do
		del_uci_config_by_name(value)
		delete_json_config_rule(value, config_table)
	end
	-- 第四步：集中发一次del到dev_config
	if #auto_uuids > 0 then
		sync_auto_intfgroup("del", auto_uuids, nil)
	end
	config_table["count"] = #config_table["list"];
end

local function add_config_policy(jsonStr, config_table, pbr_max)
	--list为空以及超过最大数量（最大值需计算）
	if (#jsonStr["list"] == 0 or #jsonStr["list"]+#config_table["list"] > pbr_max) then
		local msg = "param list is empty or too big"
		module_debug.lua_debug(module_debug.INFO, "add_config_policy error: %s", msg)
		print("{\"code\":\"-1\", \"msg\":\"param list is empty or too big\"}")
		return -1
	end

	check_json_name_is_repeat(jsonStr)
	if (json_repeat ~= 0) then
		local msg = "json name is repeat"
		module_debug.lua_debug(module_debug.INFO, "add_config_policy error: %s", msg)
		print("{\"code\":\"-1\", \"msg\":\"json name is repeat\"}")
		return -1
	end
	
	for i,v in pairs(jsonStr["list"]) do
		check_name_is_exist(v["name"])
		if (is_exist ~= 0) then
			local msg = "rule name is exist"
			module_debug.lua_debug(module_debug.INFO, "add_config_policy error: %s", msg)
			print("{\"code\":\"-1\", \"msg\":\"rule name is exist\"}")
			return -1
		end
	end
	
	for j=#jsonStr["list"],1,-1 do
		local v = jsonStr["list"][j]
		-- auto类型: 若未携带UUID则自动生成（前缀 pbr6_intf_group_ + 递增ID）
		if v["intfGrpType"] == "auto" and (v["intfGrpUuid"] == nil or v["intfGrpUuid"] == "") then
			v["intfGrpUuid"] = alloc_auto_uuid("pbr6_intf_group_", "pbr6_uuid_next")
		end
		local new_rule = {} --有没有好的办法，直接转一手？？
		local uci_section = x:add("policy_routev6",
			get_rule_section_type(v["intf"], v["intfGrpType"]))
		
		fill_new_section_and_rule(uci_section, new_rule, v)
		-- 同步auto接口组配置到dev_config
		if v["intfGrpType"] == "auto" and v["intfGrpUuid"] ~= nil and v["intfGrpUuid"] ~= "" then
			sync_auto_intfgroup("add", v["intfGrpUuid"], v["intfGrpList"])
		end
		-- 移到最开始的位置，后配先生效
		x:reorder("policy_routev6", uci_section, 0)
		--json配置文件插入到末尾，不需要考虑顺序
		table.insert(config_table["list"], 1, new_rule)
	end
	config_table["count"] = #config_table["list"];

	return 0
end

local function pbr_param_log_init()
	module_debug.debug_init(PBR_PARAM_LOG_DIR, "param_check.log", 50, module_debug.INFO, "1")
end

-- 对 JSON 做安全校验，name/rulename 字段跳过（允许任意字符），其余字段均经 lua_param_safety_check 检验
-- 校验内容同步输出到 /tmp/policy_route/param_check.log
-- 返回：true=通过，false=拒绝
local function check_json_safety(jsonStr_table)
	local safe_tab = {}
	for k, v in pairs(jsonStr_table) do
		safe_tab[k] = v
	end
	if type(jsonStr_table["list"]) == "table" then
		safe_tab["list"] = {}
		for i, rule in ipairs(jsonStr_table["list"]) do
			local safe_rule = {}
			for fk, fv in pairs(rule) do
				if fk == "name" then
					safe_rule[fk] = "safename"
				else
					safe_rule[fk] = fv
				end
			end
			safe_tab["list"][i] = safe_rule
		end
	end
	if type(jsonStr_table["rulename"]) == "string" then
		safe_tab["rulename"] = "safename"
	elseif type(jsonStr_table["rulename"]) == "table" then
		safe_tab["rulename"] = {"safename"}
	end
	local safe_str = cjson.encode(safe_tab)
	module_debug.lua_debug(module_debug.INFO, "param safety check: %s", safe_str)
	local result = libc2lua.lua_param_safety_check(safe_str) == true
	if not result then
		module_debug.lua_debug(module_debug.INFO, "param safety check FAILED: %s", safe_str)
	end
	return result
end

local function main()
	if (arg[1] == nil or arg[2] == nil or arg[3] == nil) then
		local msg = "parameter is null"
		module_debug.lua_debug(module_debug.INFO, "main error: %s", msg)
        print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
        return
    end
	
	config_file = arg[3] --增量配合需要写框架配置文件
	config_table = public_module.read_file(config_file)
	if (config_table == nil) then
		local msg = "config file is not exist"
		module_debug.lua_debug(module_debug.INFO, "main error: %s", msg)
		print("{\"code\":\"-1\", \"msg\":\"config file is not exist\"}")
		return
	end
	
	local ret = 0
	local jsonStr = cjson.decode(arg[2])
	-- 安全校验（name/rulename 字段除外）
	if not check_json_safety(jsonStr) then
		print("{\"code\":\"-1\", \"msg\":\"param safety check failed\"}")
		return
	end

	if (arg[1] == "add") then
		pbr_max = tonumber(arg[4])
		ret = add_config_policy(jsonStr, config_table, pbr_max)
		if (ret ~= 0) then
			return
		end
	elseif (arg[1] == "del") then
		del_config_policy(jsonStr["rulename"], config_table)
	else
		--处理更新
		if (jsonStr["opt"] == nil) then
			--更新单个规则
			ret = update_config_policy(jsonStr, config_table)
			if (ret ~= 0) then
				return
			end
		elseif (jsonStr["opt"] == "up" or jsonStr["opt"] == "down") then
			--处理优先级移动
			move_config_policy(jsonStr, jsonStr["opt"], config_table)
		end
	end
	
	x:commit("policy_routev6")
	--保存dev_config的模块json配置文件
	public_module.write_file(config_table, config_file)
end

pbr_param_log_init()
main()
