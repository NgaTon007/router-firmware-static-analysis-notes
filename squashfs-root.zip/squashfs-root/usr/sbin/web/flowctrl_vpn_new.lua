local x = require("luci.model.uci").cursor()
local y = require("luci.model.uci").cursor("/tmp/flowctrl",nil)             --更改配置目录，/etc/config -> /tmp/flowctrl
local cjson = require "cjson"
local lib_app = require "flowctrl.flowctrl_app"
local DEBUG_LOG_DIR="/tmp/flowctrl/"
local module_debug = require "utils.debug"
local lib_app_idy = require "app_identify.app_idy_pub"
require "public_module"

local name_is_exist=0
local cfg_index=0
local old_section
local del_app_grp = {}
local del_app_grp_for_appidy={}
local del_idyc_version
local default_pri=49
local default_tc_pri=4
local update_pri
local update_policy_id
local update_app_grp
local update_app_grp_for_appidy
local update_idyc_version
local update_user_group
local update_tr_group
local user_group_flag
local policy_cnt
local lib_user
local idyc_version

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "opteration.log", 500, module_debug.INFO, "1");
end

local function check_policy(enable_s, intf, idyc_version, app_group_name, comment)
	--vpn策略只校验特征库和开关状态
    local version=x:get("app_identify","signature","version")
	--有自定义应用组才检查
	if (app_group_name ~= nil and idyc_version ~= version) then
		module_debug.lua_debug(module_debug.INFO, "comment [%s] ideyc_version is mismatch", comment);
		return 0
	end

	--时序问题，有0必须返回0，没0才能返回-1 0代表接口、特征库不对，-1代表关闭开关
	if (enable_s == "off") then
		return -1
	end

    return 1
end

--交换json的优先级
local function swap_pri_json(current_rule_name, swap_comment, config_table)
	local current_pri
	local swap_pri
	local current_k
	local swap_k
    for k,v in pairs(config_table["list"]) do
		if (v["comment"] == current_rule_name) then
			current_k=k
			current_pri=v["pri"]
        end

		if (v["comment"] == swap_comment) then
			swap_k=k
			swap_pri=v["pri"]
        end
    end

	if (current_pri ~= nil and swap_pri ~= nil) then
		config_table["list"][current_k]["pri"]=swap_pri
		config_table["list"][swap_k]["pri"]=current_pri
	else
        module_debug.lua_debug(module_debug.ERROR, "current_pri or swap_pri error");
	end
end

--交换下移操作时两策略优先级
local function swap_pri_down(rulename, pri, name, index)
	local new_pri
	local swap_comment
	--交换配置中的pri
	x:foreach("flowctrl", "vpn_policy", function(s)
		local up_name = s[".name"]
		if (s[".index"] == index-1) then
			new_pri=x:get("flowctrl", up_name, "pri")
			swap_comment=x:get("flowctrl", up_name, "comment")
			x:set("flowctrl", name, "pri", new_pri)
			x:set("flowctrl", up_name, "pri", pri)
		end
    end)

	return swap_comment
end

--交换上移操作时两策略优先级
local function swap_pri_up(rulename, pri, name, index)
	local new_pri
	local swap_comment
	x:foreach("flowctrl", "vpn_policy", function(s)
		local up_name = s[".name"]
		if (s[".index"] == index+1) then
			new_pri=x:get("flowctrl", up_name, "pri")
			swap_comment=x:get("flowctrl", up_name, "comment")
			x:set("flowctrl", name, "pri", new_pri)
			x:set("flowctrl", up_name, "pri", pri)
		end
    end)

	return swap_comment
end

local function check_name_is_exist(rule_name)
	local app_list
	x:foreach("flowctrl", "vpn_policy", function(s)
		local name = s[".name"]
		if (x:get("flowctrl", name, "comment") == rule_name) then
			name_is_exist = 1
			cfg_index = s[".index"]
			old_section = name
			update_pri = x:get("flowctrl", name, "pri")
			update_policy_id = x:get("flowctrl", name, "policy_id")
			app_list=x:get("flowctrl", name, "app")
			--8-23自定义应用组
			if (app_list ~= nil) then
				update_app_grp = x:get("flowctrl", name, "app_group")
			else
				update_app_grp_for_appidy = x:get("flowctrl", name, "app_group")
			end

			update_user_group = x:get("flowctrl", name, "user_group_name")
			update_idyc_version = x:get("flowctrl", name, "idyc_version")
			--新增时间管理
			update_tr_group = x:get("flowctrl", name, "tr_group")
			return
		end
    end)
	return
end

--如果没配置过自定义策略，则插入位置放最后；否则插入到第一条的位置。(150足够)
local first_index=150
local function find_first_rule_index()
	x:foreach("flowctrl", "vpn_policy", function(s)
		if (first_index == 150) then
			first_index = s[".index"]
		end
		return
    end)
end

local last_index=0
local function find_last_rule_index()
	x:foreach("flowctrl", "vpn_policy", function(s)
		last_index = s[".index"]
    end)
end

local function delete_for_update_json_config_rule(rule_name, config_table)
    local ret = 0
    for k,v in pairs(config_table["list"]) do
		if (v["comment"] == rule_name) then
            table.remove(config_table["list"], k)
			break
        end
    end
    return 0
end

--删除框架配置文件中的规则
local function delete_json_config_rule(rule_name, config_table)
    local ret = 0
	local del_pri
    for k,v in pairs(config_table["list"]) do
		if (v["comment"] == rule_name) then
			if (v["pri"] ~= nil) then
				del_pri=tonumber(v["pri"])
			end

            table.remove(config_table["list"], k)
			break
        end
    end

	if (del_pri ~= nil and tonumber(del_pri) == default_pri+1) then
		return
	end

	for k,v in pairs(config_table["list"]) do
		if (del_pri ~= nil and v["pri"] ~= nil and tonumber(v["pri"]) < del_pri) then
			v["pri"]= tostring (tonumber(v["pri"]) + 1)
        end
    end
    return 0
end

--删除uci配置文件中的策略配置  jzh新增pri的调整逻辑，每删除一个策略，之后比他大的优先级都得-1
local function del_uci_config_by_rule_name(rule_name)
	local del_pri
	local del_user_group
	local app_list
	local policy_id
	local del_tr_group

	x:foreach("flowctrl", "vpn_policy", function(s)
		local name = s[".name"]
		if (x:get("flowctrl", name, "comment") == rule_name) then
			del_pri = x:get("flowctrl", name, "pri")
			--创建一个数组，数组包括要删除的app_group，用于一次性删除app_group
			local idex = #del_app_grp["appGrp"] + 1
			local idex_name = #del_app_grp_for_appidy["grpName"] + 1
			--8-23自定义应用组有app_goup但是不一定要删除，app_list不为空则为创建的虚拟应用组需要删除
			app_list = x:get("flowctrl", name, "app")
			app_grp = x:get("flowctrl", name, "app_group")
			policy_id = x:get("flowctrl", name, "policy_id")
			if (app_list ~= nil) then
				if (policy_id ~= nil) then
					del_app_grp["appGrp"][idex] = "fc_applist_"..policy_id
				end
			elseif (app_grp ~= nil) then
				--2023-4-23 app_grp名用app_identify的section名代替
				-- del_app_grp_for_appidy["grpName"][idex_name]=string.gsub(app_grp, "csm_", "")
				del_app_grp_for_appidy["grpName"][idex_name]=app_grp
			end

			del_user_group=x:get("flowctrl", name, "user_group_name")
			del_idyc_version=x:get("flowctrl", name, "idyc_version")
			del_tr_group=x:get("flowctrl", name, "tr_group")

			--删除user_group组
			if (user_group_flag == "1" and del_user_group ~= nil) then
				lib_user.user_mgr_del_vgrp(del_user_group)
			end
			--时间组解引用，auto组计数为0会自动删除
			if(del_tr_group ~= nil) then
				lib_app.deref_time_config(del_tr_group)
			end
			--为兼容老流控，配置降级时ipset还是需要加入用户，因此新流控保留这个功能
			local policy_id = tonumber(x:get("flowctrl", name, "policy_id"))
			--删除策略对应的ipset组
			local ipset=policy_id-1
			os.execute("ipset destroy fc_rule_"..ipset.." 2>/dev/null")
			x:delete("flowctrl", name)
		end

		--服务器策略删除，不需要调整优先级
		if (tonumber(del_pri) == default_pri + 1) then
			return
		end
		--调整pri，比pri大的都减1
		local current_pri = x:get("flowctrl", name, "pri")
		if (current_pri ~= nil and del_pri ~= nil) then
			if (current_pri < del_pri) then
				--删除一个策略，其他策略优先级比他小的优先级全+1
				local adjust_pri = current_pri + 1
				x:set("flowctrl", name, "pri", adjust_pri)
			end
		end
    end)
end

local function fill_new_section_and_rule(new_section, input_param, pri, policy_id, app_group_name, user_group_name, idyc_version, new_rule, tr_group_name, tr_type)
	local enable_s = input_param["enable"]
	x:set("flowctrl", new_section, "enable", enable_s)
	new_rule["enable"] = input_param["enable"]
	local intf=input_param["intf"]
	x:set("flowctrl", new_section, "intf", intf)
	new_rule["intf"] = intf
	--非遍历处理，增量导致这个fc_rule_x的下标不好生成，规则删除会导致重复。(放实现内部来生成)。
	x:set("flowctrl", new_section, "ip_group", "fc_rule_"..policy_id-1)
	x:set("flowctrl", new_section, "idyc_version", idyc_version)
	new_rule["idyc_version"] = tostring(idyc_version)

    local ip_type=input_param["ipType"]
    if (ip_type ~= nil) then
        x:set("flowctrl", new_section, "ip_type", ip_type)
		new_rule["ipType"] = ip_type
    else
        x:set("flowctrl", new_section, "ip_type", "in_ip")
		new_rule["ipType"] = "in_ip"
    end

	--添加用户组
	if (input_param["user_group_list"] ~= nil) then
		if (user_group_name ~= nil) then
			x:set("flowctrl", new_section, "user_group_name", user_group_name)
			x:set("flowctrl", new_section, "user_group", input_param["user_group_list"])
		end
		new_rule["user_group_list"] = input_param["user_group_list"]
	end

	local policy_type = input_param["type"]
	if (policy_type ~= nil) then
		x:set("flowctrl", new_section, "type", policy_type)
		new_rule["type"]=policy_type
	else
		policy_type="vpn_web"
		x:set("flowctrl", new_section, "type", policy_type)
		new_rule["type"]=policy_type
	end

	--新增用户组后ipRange可能为nil需要判断
	local ip_start
	local ip_end
	if (#input_param["ipRange"] ~= 0) then
		local iprange = input_param["ipRange"]
		if (string.find(iprange, "-"))  then
			local m = string.find(iprange, "-")
			ip_start=string.sub(iprange, 1, m-1)
			ip_end=string.sub(iprange, m+1, string.len(iprange))
			x:set("flowctrl", new_section, "ip_start", ip_start)
			x:set("flowctrl", new_section, "ip_end", ip_end )
		else
			ip_start=input_param["ipRange"]
			ip_end=input_param["ipRange"]
			x:set("flowctrl", new_section, "ip_start", input_param["ipRange"])
			x:set("flowctrl", new_section, "ip_end", input_param["ipRange"])
		end
		new_rule["ipRange"] = ip_start.."-"..ip_end
	else
		new_rule["ipRange"] = input_param["ipRange"]
		x:set("flowctrl", new_section, "ip_start",lib_app.ip_tag)
		x:set("flowctrl", new_section, "ip_end",lib_app.ip_tag)
	end

	--新增vlanList
	if (input_param["vlanList"] ~= nil and #input_param["vlanList"] > 0 ) then
		x:set("flowctrl", new_section, "vlan", input_param["vlanList"])
		new_rule["vlanList"] = input_param["vlanList"]
	else
		new_rule["vlanList"] = {}
	end

	x:set("flowctrl", new_section, "comment", input_param["comment"])
	new_rule["comment"] = input_param["comment"]

	--新增jzh
	x:set("flowctrl", new_section, "policy_id", policy_id)
	x:set("flowctrl", new_section, "pri", pri)
	new_rule["pri"] = tostring(pri)
	if (input_param["tcPri"] ~= nil) then 
		x:set("flowctrl", new_section, "tc_pri", input_param["tcPri"])
		new_rule["tcPri"] = tostring(input_param["tcPri"])
	else
		x:set("flowctrl", new_section, "tc_pri", tostring(default_tc_pri))
		new_rule["tcPri"] = tostring(default_tc_pri)
	end

	if (input_param["appList"] ~= nil) then
		if (app_group_name ~= nil) then
			x:set("flowctrl", new_section, "app_group", app_group_name)
			x:set("flowctrl", new_section, "app", input_param["appList"])
		--8-23新增自定义应用组,自定义应用组需要加csm_前缀/ 2023-04-23 customApp使用app_identify的section名下发
		elseif (input_param["customApp"] ~= nil and #input_param["customApp"] > 0) then
			-- x:set("flowctrl", new_section, "app_group", "csm_"..input_param["customApp"])
			x:set("flowctrl", new_section, "app_group", input_param["customApp"])
			new_rule["customApp"] = input_param["customApp"]
		end
		new_rule["appList"] = input_param["appList"]
	end

	local mode = nil
	mode = input_param["mode"]
	if (mode == nil) then
		x:set("flowctrl", new_section, "mode", "share")
		new_rule["mode"] = share
	else
		x:set("flowctrl", new_section, "mode", mode)
		new_rule["mode"] = input_param["mode"]
	end

	--为了兼容老版本下发配置所以做了个非空判断，不能根据能力值判断新老流控下发，因为可能设备升级但是app未升级
	--"allUpRate":""时 input_param["allUpRate"]非空，但是tonumber(input_param["allUpRate"]为空，认为是不限速模式
	if (tonumber(input_param["allUpRateG"]) ~= nil) then
		x:set("flowctrl", new_section, "all_up_rate", input_param["allUpRate"])
		x:set("flowctrl", new_section, "all_down_rate", input_param["allDownRate"])
		x:set("flowctrl", new_section, "all_up_rate_g", input_param["allUpRateG"])
		x:set("flowctrl", new_section, "all_down_rate_g", input_param["allDownRateG"])
		new_rule["allUpRate"] = input_param["allUpRate"]
		new_rule["allDownRate"] = input_param["allDownRate"]
		new_rule["allUpRateG"] = input_param["allUpRateG"]
		new_rule["allDownRateG"] = input_param["allDownRateG"]
		if (mode=="share") then
			x:set("flowctrl", new_section, "down_rate_g", input_param["allDownRateG"])
			x:set("flowctrl", new_section, "up_rate_g", input_param["allUpRateG"])
			x:set("flowctrl", new_section, "down_rate", input_param["allDownRate"])
			x:set("flowctrl", new_section, "up_rate", input_param["allUpRate"])
			new_rule["downRateG"] = input_param["allDownRateG"]
			new_rule["upRateG"] = input_param["allUpRateG"]
			new_rule["downRate"] = input_param["allDownRate"]
			new_rule["upRate"] = input_param["allUpRate"]
		else --为nil就认为不限速
			local down_rate=tonumber(input_param["downRate"])
			local up_rate=tonumber(input_param["upRate"])
			if (down_rate ~= nil) then
				x:set("flowctrl", new_section, "down_rate", down_rate)
				new_rule["downRate"] = tostring(down_rate)
			else
				x:set("flowctrl", new_section, "down_rate", lib_app.rate_tag)
				new_rule["downRate"] = ""
			end

			if (up_rate ~= nil) then
				x:set("flowctrl", new_section, "up_rate", up_rate)
				new_rule["upRate"] = tostring(up_rate)
			else
				x:set("flowctrl", new_section, "up_rate", lib_app.rate_tag)
				new_rule["upRate"] = ""
			end

			--每用户的保障带宽取用户组带宽/5，默认5个用户使用
			local down_rate_g=math.floor(tonumber(input_param["allDownRateG"])/lib_app.udp_cnt)
			local up_rate_g=math.floor(tonumber(input_param["allUpRateG"])/lib_app.udp_cnt)
			if (down_rate ~= nil and down_rate_g > down_rate) then
				down_rate_g = down_rate
			end

			if (down_rate_g >= 1) then
				x:set("flowctrl", new_section, "down_rate_g", down_rate_g)
				new_rule["downRateG"] = tostring(down_rate_g)
			else
				x:set("flowctrl", new_section, "down_rate_g", 1)
				new_rule["downRateG"] = "1"
			end

			if (up_rate ~= nil and up_rate_g > up_rate) then
				up_rate_g = up_rate
			end

			if (up_rate_g >= 1) then
				x:set("flowctrl", new_section, "up_rate_g", up_rate_g)
				new_rule["upRateG"] = tostring(up_rate_g)
			else
				x:set("flowctrl", new_section, "up_rate_g", 1)
				new_rule["upRateG"] = "1"
			end
		end
	else	--不限速模式
		if (tonumber(input_param["upRateG"]) == nil) then
			x:set("flowctrl", new_section, "all_up_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_down_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "all_down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "down_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "down_rate", lib_app.rate_tag)
			x:set("flowctrl", new_section, "up_rate_g", lib_app.rate_tag)
			x:set("flowctrl", new_section, "up_rate", lib_app.rate_tag)
			new_rule["allUpRate"] = ""
			new_rule["allDownRate"] = ""
			new_rule["allUpRateG"] = ""
			new_rule["allDownRateG"] = ""
			new_rule["downRateG"] = ""
			new_rule["upRateG"] = ""
			new_rule["downRate"] = ""
			new_rule["upRate"] = ""
		else --此状态为旧流控的web或旧app下发
			if (mode=="share") then--share模式下配置uprate就为用户组带宽
				x:set("flowctrl", new_section, "all_up_rate", input_param["upRate"])
				x:set("flowctrl", new_section, "all_down_rate", input_param["downRate"])
				x:set("flowctrl", new_section, "all_up_rate_g", input_param["upRateG"])
				x:set("flowctrl", new_section, "all_down_rate_g", input_param["downRateG"])
				new_rule["allUpRate"] = input_param["upRate"]
				new_rule["allDownRate"] = input_param["downRate"]
				new_rule["allUpRateG"] = input_param["upRateG"]
				new_rule["allDownRateG"] = input_param["downRateG"]
			else--per_ip模式下，uprate为每用户带宽，用户组带宽要后面处理为接口带宽，这里打标记
				--all_up_rate_g可能会大于all_up_rate，放在flowctrl_tc_cfg中考虑，这边接口带宽未知
				local all_up_rate_g=tonumber(input_param["upRateG"])*lib_app.udp_cnt
				local all_down_rate_g=tonumber(input_param["downRateG"])*lib_app.udp_cnt
				local all_up_rate=lib_app.max_rate_tag
				local all_down_rate=lib_app.max_rate_tag
				if (all_up_rate_g > tonumber(all_up_rate)) then
					all_up_rate_g=all_up_rate
				end

				if (all_down_rate_g > tonumber(all_down_rate))then
					all_down_rate_g=all_down_rate
				end

				--直接给个默认最大值，保证除不限速模式下all_up_rate，all_down_rate都有值
				x:set("flowctrl", new_section, "all_up_rate", all_up_rate)
				x:set("flowctrl", new_section, "all_down_rate", all_down_rate)
				x:set("flowctrl", new_section, "all_up_rate_g", all_up_rate_g)
				x:set("flowctrl", new_section, "all_down_rate_g", all_down_rate_g)
				new_rule["allUpRate"] = all_up_rate
				new_rule["allDownRate"] = all_down_rate
				new_rule["allUpRateG"] = tostring(all_up_rate_g)
				new_rule["allDownRateG"] = tostring(all_down_rate_g)
			end
			x:set("flowctrl", new_section, "down_rate", input_param["downRate"])
			x:set("flowctrl", new_section, "up_rate", input_param["upRate"])
			x:set("flowctrl", new_section, "down_rate_g", input_param["downRateG"])
			x:set("flowctrl", new_section, "up_rate_g", input_param["upRateG"])
			new_rule["downRate"] = input_param["downRate"]
			new_rule["upRate"] = input_param["upRate"]
			new_rule["downRateG"] = input_param["downRateG"]
			new_rule["upRateG"] = input_param["upRateG"]
		end
	end

	--新增时间管理
	local tr_effective
	local tr_slots = input_param["tr_slots"]
	local tr_range = input_param["tr_range"]
	if (tr_type ~= nil and #tr_type > 0) then
		if(tr_group_name ~= nil and tr_group_name:sub(1, 3) == "fc_") then
			if (tr_type == lib_app.tr_week_type) then
				new_rule["tr_type"] = tr_type
				x:set("flowctrl", new_section, "tr_type", tr_type)
				x:set("flowctrl", new_section, "tr_slots", cjson.encode(tr_slots))
				x:set("flowctrl", new_section, "tr_group", tr_group_name)
				new_rule["tr_slots"] = tr_slots
				new_rule["tr_group"] = ""
				new_rule["tr_range"] = {}
				lib_app.ref_time_config(tr_group_name)
				tr_effective=lib_app.check_policy_tr(tr_group_name)
				--云端不关心tr_effective
				-- new_rule["tr_effective"] = tostring(tr_effective)
			--入参有检验，不是week就是date
			else
				new_rule["tr_type"] = tr_type
				x:set("flowctrl", new_section, "tr_type", tr_type)
				x:set("flowctrl", new_section, "tr_range", cjson.encode(tr_range))
				x:set("flowctrl", new_section, "tr_group", tr_group_name)
				new_rule["tr_range"] = tr_range
				new_rule["tr_group"] = ""
				new_rule["tr_slots"] = {}
				lib_app.ref_time_config(tr_group_name)
				tr_effective=lib_app.check_policy_tr(tr_group_name)
				--云端不关心tr_effective
				-- new_rule["tr_effective"] = tostring(tr_effective)
			end
		else
			module_debug.lua_debug(module_debug.ERROR, "policy[%s] tr_group_name[%s] error", input_param["comment"], tr_group_name);
			new_rule["tr_group"] = ""
			new_rule["tr_slots"] = {}
			new_rule["tr_range"] = {}
			new_rule["tr_type"] = ""
			tr_effective = 1
			--云端不关心tr_effective
			-- new_rule["tr_effective"] = "1"
		end
	elseif (tr_group_name ~= nil and #tr_group_name > 0) then
		x:set("flowctrl", new_section, "tr_group", tr_group_name)
		new_rule["tr_group"] = tr_group_name
		new_rule["tr_slots"] = {}
		new_rule["tr_range"] = {}
		new_rule["tr_type"] = ""
		lib_app.ref_time_config(tr_group_name)
		tr_effective=lib_app.check_policy_tr(tr_group_name)
		-- new_rule["tr_effective"] = tostring(tr_effective)
	else
		new_rule["tr_group"] = ""
		new_rule["tr_slots"] = {}
		new_rule["tr_range"] = {}
		new_rule["tr_type"] = ""
		tr_effective = 1
		-- new_rule["tr_effective"] = "1"
	end

	if (tr_effective ~= nil) then
		x:set("flowctrl", new_section, "tr_effective", tr_effective)
	else
		x:set("flowctrl", new_section, "tr_effective", 1)
	end

	--新增dscp和vlanPri
	if (input_param["dscp"] ~= nil and #input_param["dscp"] ~= 0) then
		x:set("flowctrl", new_section, "dscp", input_param["dscp"])
		new_rule["dscp"] = tostring(input_param["dscp"])
	else
		new_rule["dscp"] = ""
	end

	if (input_param["ipPri"] ~= nil and #input_param["ipPri"] ~= 0) then 
		x:set("flowctrl", new_section, "ip_pri", input_param["ipPri"])
		new_rule["ipPri"] = tostring(input_param["ipPri"])
	else
		new_rule["ipPri"] = ""
	end

	local effective=check_policy(enable_s, intf, idyc_version, app_group_name, input_param["comment"])
	x:set("flowctrl", new_section, "effective", effective) --先计算生效性，web能够提前显示
	new_rule["effective"] = tostring(effective)
end

local function update_config_policy(jsonStr, idyc_version, config_table)
	local tr_type
	--list为空以及超过1个元素
	if (#jsonStr["list"] == 0 or #jsonStr["list"] > 1) then
		module_debug.lua_debug(module_debug.ERROR, "param list is empty or too big");
		return -1
	end

	local rule_name = jsonStr["list"][1]["comment"]
	check_name_is_exist(rule_name)
	if (name_is_exist == 0) then
		module_debug.lua_debug(module_debug.ERROR, "rule is exist");
		return -1
	end

	if (update_policy_id == nil) then --旧配置可能会出现这种情况
        module_debug.lua_debug(module_debug.ERROR, "he policy have no policy id");
		return -1
	end

	--新增时间管理参数检查
    if (lib_app.fc_tmngt_grp_check(jsonStr["list"][1]) < 0) then
        module_debug.lua_debug(module_debug.ERROR, "update vpn policy[%s], tmngt is error", jsonStr["list"][1]["comment"]);
        return -1;
    end

	if (jsonStr["list"][1]["dscp"] ~= nil and #jsonStr["list"][1]["dscp"] > 0) then
		local dscp = tonumber(jsonStr["list"][1]["dscp"])
		if (dscp == nil or dscp > lib_app.max_dscp) then
			module_debug.lua_debug(module_debug.ERROR, "update vpn policy[%s] dscp[%s] is error", rule_name, jsonStr["list"][1]["dscp"]);
			return -1;
		end
	end

	if (jsonStr["list"][1]["ipPri"] ~= nil and #jsonStr["list"][1]["ipPri"] > 0) then
		local ip_pri = tonumber(jsonStr["list"][1]["ipPri"])
		if (ip_pri == nil or ip_pri > lib_app.max_ip_pri) then
			module_debug.lua_debug(module_debug.ERROR, "update vpn policy[%s] ip_pri[%s] is error", rule_name, jsonStr["list"][1]["ipPri"]);
			return -1;
		end
	end

	if (name_is_exist ~= 0) then
		--无table.update操作，只能删除旧的节点，重新添加。
		x:delete("flowctrl", old_section)
		delete_for_update_json_config_rule(rule_name, config_table)
		local uci_section = x:add("flowctrl", "vpn_policy")
		local app_group_name

		lib_app.app_idy_update_app_config(jsonStr["list"][1]["appList"], update_policy_id, update_app_grp, idyc_version)
		--兼容老本web下发无applist字段要先判断是否为nil
		if (jsonStr["list"][1]["appList"] ~= nil and #jsonStr["list"][1]["appList"] > 0) then --为all的时候直接删除当前应用组
			app_group_name = "fc_"..update_policy_id
		elseif (jsonStr["list"][1]["customApp"] ~= nil and #jsonStr["list"][1]["customApp"] > 0) then
			--应用识别的引用计数操作/2023-4-23 app_grp名用app_identify的section名代替
			lib_app_idy.custom_group_count_handle("add",jsonStr["list"][1]["customApp"],nil)
		end

		--应用识别的引用计数操作/2023-4-23 app_grp名用app_identify的section名代替
		if (update_app_grp_for_appidy ~= nil) then
			lib_app_idy.custom_group_count_handle("del",update_app_grp_for_appidy,nil)
		end
		--更新的时候要删除老的用户组再添加新的用户组
		if (user_group_flag == "1" and update_user_group ~= nil) then
			lib_user.user_mgr_del_vgrp(update_user_group)
		end

		local user_group_name
		if (user_group_flag == "1" and jsonStr["list"][1]["user_group_list"][1] ~= nil) then
			user_group_name="fc_"..update_policy_id
			user_list=jsonStr["list"][1]["user_group_list"]
			lib_user.user_mgr_add_vgrp(user_group_name, user_list)
		end

		--先解引用时间组
		if(update_tr_group ~= nil) then
			lib_app.deref_time_config(update_tr_group)
		end
		debug_init()
		--新增时间管理
        local tr_type = jsonStr["list"][1]["tr_type"]
        local tr_slots = jsonStr["list"][1]["tr_slots"]
        local tr_range = jsonStr["list"][1]["tr_range"]
        local tr_group_name = jsonStr["list"][1]["tr_group"]

		if (tr_type ~= nil and #tr_type ~= 0) then
			tr_group_name="fc_"..update_policy_id
			if (tr_type == lib_app.tr_week_type) then
				lib_app.update_time_config(tr_group_name, cjson.encode(tr_slots), "auto", lib_app.tr_week_type)
			else
				lib_app.update_time_config(tr_group_name, cjson.encode(tr_range), "auto", lib_app.tr_date_type)
			end
		end

		local new_rule = {} --有没有好的办法，直接转一手？？
		fill_new_section_and_rule(uci_section, jsonStr["list"][1], update_pri, update_policy_id, app_group_name, user_group_name, idyc_version, new_rule, tr_group_name, tr_type)
		-- 移到原始的位置
		x:reorder("flowctrl", uci_section, cfg_index) --更新后仍在原位置，所以pri不用考虑顺序问题)
		--json配置文件更新不保持原有位置
		table.insert(config_table["list"], new_rule)
		table.sort(config_table["list"],function(l,r)
			return l.pri>r.pri
		end)
		return 0
	end

	return -1
end

local moved=0
local function move_config_policy(rulename, opt, config_table)
	moved = 0
	x:foreach("flowctrl", "vpn_policy", function(s)
		if (moved ~= 0) then
			return 0
		end

		local name = s[".name"]
		local current_pri = x:get("flowctrl", name, "pri")
		local current_rule_name = x:get("flowctrl", name, "comment")
		if (current_rule_name == rulename) then
			-- !!! 注意up要把配置往下移动，down要把配置往上移动，方向是反的。
			if (opt == "up") then
				find_last_rule_index()
				if (last_index ~= 0) then
					if (last_index ~= s[".index"]) then
						--新增完成up操作的pri交换 jzh
						local swap_comment=swap_pri_up(current_rule_name, current_pri, name, s[".index"])
						if (swap_comment ~= nil) then
							swap_pri_json(current_rule_name, swap_comment, config_table)
						else
							module_debug.lua_debug(module_debug.ERROR, "swap comment is error");
							return 1
						end
						--改变策略在配置中的位置
						x:reorder("flowctrl", name, s[".index"] + 1)
						moved = 1
					end
				end
			else
				find_first_rule_index()
				if (first_index ~= 150) then
					--只有一条不移动，避免直接操作dev_config导致uci文件顺序错乱。
					--正好是第一条要上移，此时索引相等，条数大于1条，则可上移。
					if (first_index ~= s[".index"]) then
						local swap_comment=swap_pri_down(current_policy_id, current_pri, name, s[".index"])
						if (swap_comment ~= nil) then
							swap_pri_json(current_rule_name, swap_comment, config_table)
						else
							module_debug.lua_debug(module_debug.ERROR, "swap comment is error");
							return 1
						end
						--改变策略在配置中的位置
						x:reorder("flowctrl", name, s[".index"] - 1)
						moved = 1
					end
				end
			end

			--json排序
			table.sort(config_table["list"],function (l, r)
				--return只return这个funcition，按pri降序排列
				return l.pri > r.pri
			end)

			return 0
		end
    end)
	--json配置文件不移动但是交换pri，由云端按pri排序后下发
	return 0
end

local function del_config_policy(rulename, config_table)
	for i, value in pairs(rulename) do
		del_uci_config_by_rule_name(value)
		delete_json_config_rule(value, config_table)
	end
end

local function add_config_policy(jsonStr, idyc_version, config_table)
	--list为空以及超过1个元素
	if (#jsonStr["list"] == 0 or #jsonStr["list"] > 1) then
		module_debug.lua_debug(module_debug.ERROR, "param list is empty or too big");
		return -1
	end

	check_name_is_exist(jsonStr["list"][1]["comment"])
	if (name_is_exist ~= 0) then
        module_debug.lua_debug(module_debug.ERROR, "rule is exist");
		return -1
	end

	--新增时间管理参数检查
    if (lib_app.fc_tmngt_grp_check(jsonStr["list"][1]) < 0) then
        module_debug.lua_debug(module_debug.ERROR, "add vpn policy[%s], tmngt is error", jsonStr["list"][1]["comment"]);
        return -1;
    end

	if (jsonStr["list"][1]["dscp"] ~= nil and #jsonStr["list"][1]["dscp"] > 0) then
		local dscp = tonumber(jsonStr["list"][1]["dscp"])
		if (dscp == nil or dscp > lib_app.max_dscp) then
			module_debug.lua_debug(module_debug.ERROR, "add vpn policy[%s] dscp[%s] is error", jsonStr["list"][1]["comment"], jsonStr["list"][1]["dscp"]);
			return -1;
		end
	end

	if (jsonStr["list"][1]["ipPri"] ~= nil and #jsonStr["list"][1]["ipPri"] > 0) then
		local ip_pri = tonumber(jsonStr["list"][1]["ipPri"])
		if (ip_pri == nil or ip_pri > lib_app.max_ip_pri) then
			module_debug.lua_debug(module_debug.ERROR, "add vpn policy[%s] ip_pri[%s] is error", jsonStr["list"][1]["comment"], jsonStr["list"][1]["ipPri"]);
			return -1;
		end
	end

	local pri
	if (jsonStr["list"][1]["type"] == "PPTP" or jsonStr["list"][1]["type"] == "L2TP" or jsonStr["list"][1]["type"] == "OPENVPN") then
		find_first_rule_index()
		pri = default_pri + 1
	else
		find_last_rule_index()
		pri = default_pri - policy_cnt
	end

	--计算policy_id
	local policy_id = lib_app.clc_policy_id(lib_app.vpn_tag)
	local app_group_name
	--老流控web不下发appList这个字段不能判断长度，因此要先判断是否为nil
	if (jsonStr["list"][1]["appList"] ~= nil and #jsonStr["list"][1]["appList"] > 0) then
		app_group_name = "fc_"..policy_id
		lib_app.app_idy_add_app_config_policy(jsonStr["list"][1]["appList"], policy_id, idyc_version)
	elseif (jsonStr["list"][1]["customApp"] ~= nil and #jsonStr["list"][1]["customApp"] > 0) then
		--应用识别的引用计数操作/2023-4-23 app_group用section名代替
		lib_app_idy.custom_group_count_handle("add",jsonStr["list"][1]["customApp"],nil)
	end

	--新增user_group虚拟用户组
	if (user_group_flag == "1" and jsonStr["list"][1]["user_group_list"][1] ~= nil) then
		user_group_name="fc_"..policy_id
		user_list=jsonStr["list"][1]["user_group_list"]
		lib_user.user_mgr_add_vgrp(user_group_name, user_list)
	end
	debug_init()

	--新增时间管理
	local tr_type = jsonStr["list"][1]["tr_type"]
	local tr_slots = jsonStr["list"][1]["tr_slots"]
	local tr_range = jsonStr["list"][1]["tr_range"]
	local tr_group_name = jsonStr["list"][1]["tr_group"]

	if (tr_type ~= nil and #tr_type ~= 0) then
		tr_group_name="fc_"..policy_id
		if (tr_type == lib_app.tr_week_type) then
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_slots), "auto", lib_app.tr_week_type)
		else
			lib_app.update_time_config(tr_group_name, cjson.encode(tr_range), "auto", lib_app.tr_date_type)
		end
	end

	--先确定位置，再新增节点。
	local new_rule = {} --有没有好的办法，直接转一手？？
	local uci_section = x:add("flowctrl", "vpn_policy")
	fill_new_section_and_rule(uci_section, jsonStr["list"][1], pri, policy_id, app_group_name, user_group_name, idyc_version, new_rule, tr_group_name, tr_type)

	--服务器配置的策略放头部，自定义策略放位置+1
	if (first_index ~= 150) then
		x:reorder("flowctrl", uci_section, first_index)
	elseif (last_index ~= 0) then
		--150个配置项足够，能够确保在最后。
		x:reorder("flowctrl", uci_section, last_index + 1)
	else
		--150个配置项足够，能够确保在最后。
		x:reorder("flowctrl", uci_section, 150)
	end

	--json配置文件插入到末尾，不需要考虑顺序
	table.insert(config_table["list"], new_rule)
	return 0
end

local function main()
	debug_init()
	
	if (arg[1] == nil or arg[2] == nil or arg[3] == nil) then
		module_debug.lua_debug(module_debug.ERROR, "parameter is null");
		os.exit(1)
	end

	config_file = arg[3] --增量配置需要写框架配置文件
	config_table = public_module.read_file(config_file)
	if (config_table == nil) then
		module_debug.lua_debug(module_debug.ERROR, "config_table is null");
		os.exit(1)
	end

	local ret = 0
	local jsonStr = cjson.decode(arg[2]);
	policy_cnt = arg[5]
	user_group_flag = arg[4]
	local idyc_version=x:get("app_identify","signature","version")

	--开了用户组功能则加载用户库
	if (user_group_flag == "1") then
		lib_user = require "user_mgr.user_mgr_common"
	end

	if (arg[1] == "add") then
		module_debug.lua_debug(module_debug.INFO, "=======================vpnctrl_add========================");
		ret = add_config_policy(jsonStr, idyc_version, config_table)
		if (ret ~= 0) then
            module_debug.lua_debug(module_debug.ERROR, "add_config_policy fail");
			os.exit(1)
		end

	elseif (arg[1] == "del") then
		module_debug.lua_debug(module_debug.INFO, "=======================vpnctrl_del========================");
		del_app_grp["appGrp"]={}
		del_app_grp_for_appidy["grpName"]={}
		del_config_policy(jsonStr["rulename"], config_table)
		--删除app配置中对应的group
		lib_app.app_idy_del_config_app_group(del_app_grp["appGrp"], nil)
		lib_app.execute_app_count_operation("del",nil,del_app_grp_for_appidy["grpName"])
	else
		--处理更新
		if (jsonStr["opt"] == nil) then
			--更新单个规则
			module_debug.lua_debug(module_debug.INFO, "=======================vpnctrl_update========================");
			ret = update_config_policy(jsonStr, idyc_version, config_table)
			if (ret ~= 0) then
                module_debug.lua_debug(module_debug.ERROR, "update_config_policy fail");
				os.exit(1)
			end
		elseif (jsonStr["opt"] == "up" or jsonStr["opt"] == "down") then
			--处理优先级移动
			module_debug.lua_debug(module_debug.INFO, "=======================vpnctrl_opt========================");
			ret = move_config_policy(jsonStr["rulename"], jsonStr["opt"], config_table)
			if (ret ~= 0) then
                module_debug.lua_debug(module_debug.ERROR, "move_config_policy fail");
				os.exit(1)
			end
		end
	end

	x:commit("flowctrl")
	--保存dev_config的模块json配置文件
	public_module.write_file(config_table, config_file)
    module_debug.lua_debug(module_debug.INFO, "VPN policy config success");
end

main()
