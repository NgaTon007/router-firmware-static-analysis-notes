#!/bin/sh
. /usr/share/libubox/jshn.sh
. /lib/functions.sh
LOCK="/tmp/app_idy.lock"
delete_flag=0
real_class=""

add_custom_group()
{
    config_load app_identify
    config_get name_ch custom name
    config_get name_en custom_En name

    if [ "$name_ch" == "null" -o "$name_ch" == "" ]; then
        uci set app_identify.custom=Custom_Group
        uci set app_identify.custom.name=自定义
        uci add_list app_identify.custom.app=自定义应用
        uci commit app_identify
    fi

    if [ "$name_en" == "null" -o "$name_en" == "" ]; then
        uci set app_identify.custom_En=Custom_Group_En
        uci set app_identify.custom_En.name=Custom
        uci add_list app_identify.custom_En.app=Custom_App
        uci commit app_identify
    fi
}

caculate_same_class_rule_num()
{
    config_get flag $1 operation
    if [ "$flag" == "add" -o "$flag" == "modify" ]; then
        let delete_flag+=1
    fi
}

delete_custom_group()
{   
    if [ "$app_class" = "zh_app" ]; then
        config_foreach caculate_same_class_rule_num Custom_Rule
    elif [ "$app_class" = "en_app" ]; then
        config_foreach caculate_same_class_rule_num Custom_Rule_En
    else
        echo "{\"code\":\"-1\", \"msg\":\" parameter error\"}"
    fi
    if [ $delete_flag == 0 ]; then
        uci delete app_identify.custom
        uci delete app_identify.custom_En
        uci commit app_identify
    fi 
}

app_idy_set_custom_rule()
{
    exec 7>$LOCK
    flock -n 7
    # 解析web下发的配置参数
    json_load "$1"
    json_select custom_rule
    json_get_var operation operation
    json_get_var app_class class
    if [ "$operation" == "add" -o "$operation" == "modify" ]; then
        config_load app_identify
        json_get_var app_ruleid ruleId
        json_get_var app_name name
        json_get_var app_protocol protocol
        json_get_var app_type type
        json_get_var app_sip sip 
        json_get_var app_sport sport 
        json_get_var app_dip dip
        json_get_var app_dport dport 
        json_get_var app_url url
        # uci delete app_identify.custom
        # uci delete app_identify.custom_En

        uci delete app_identify.$app_ruleid
        if [ "$app_class" == "en_app" ]; then
            real_class="Custom_App"
            uci set app_identify.$app_ruleid=Custom_Rule_En
        elif [ "$app_class" == "zh_app" ]; then
            real_class="自定义应用"
            uci set app_identify.$app_ruleid=Custom_Rule
        else 
            echo "{\"code\":\"-1\", \"msg\":\" parameter error\"}"
        fi
        uci set app_identify.$app_ruleid.ruleid=$app_ruleid
        uci set app_identify.$app_ruleid.operation="$operation"
        uci set app_identify.$app_ruleid.name="$app_name"
        uci set app_identify.$app_ruleid.protocol="$app_protocol"
        uci set app_identify.$app_ruleid.type="$app_type"
        uci set app_identify.$app_ruleid.sip="$app_sip"
        uci set app_identify.$app_ruleid.sport="$app_sport"
        uci set app_identify.$app_ruleid.dip="$app_dip"
        uci set app_identify.$app_ruleid.dport="$app_dport"
        uci set app_identify.$app_ruleid.url="$app_url"
        uci set app_identify.$app_ruleid.class="$real_class"
        uci reorder app_identify.$app_ruleid=38
        uci commit app_identify 
        add_custom_group
        echo "{\"code\":\"0\", \"msg\":\"$operation success\"}"
    
    elif [ "$operation" == "delete" ]; then
        json_select ruleIdArr
        index=1
        while json_get_type status $index && [ "$status" = string ]; do
            json_get_var rule_id $index
            uci set app_identify.$rule_id.operation="$operation"
            index=$((index+1))
        done
        uci commit app_identify
        # config_load app_identify
        # delete_custom_group
        echo "{\"code\":\"0\", \"msg\":\"$operation success\"}"
    else
        echo "{\"code\":\"-1\", \"msg\":\"parameter error\"}"
    fi
    flock -u 7
}

app_idy_set_custom_rule
