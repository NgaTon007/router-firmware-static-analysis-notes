require("uci")
if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"parameter is nil\"}")
    return
end

local cjson = require "cjson"
local jsonStr = cjson.decode(arg[1]);
local tool = require "dev.tools.common"
local module_debug = require "utils.debug"
local DEBUG_LOG_DIR = "/tmp/user_group/"
local addr_id_table = {}
addr_id_table["id"] = {}

x =uci.cursor()
for i, value in pairs(jsonStr["names"])	do	
	local name = x:get("content_audit", value, "name")
    id = x:get("content_audit", value, "id")
    table.insert(addr_id_table["id"], id)
	if (name ~= nil) then
		x:delete("content_audit", value)
--		io.popen("/usr/sbin/content_audit_cmd.elf -C --usr " .. value .." --delete")
	end
end	
x:commit("content_audit")

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
module_debug.debug_init(DEBUG_LOG_DIR, "ca_del_ip_range.log", 500, module_debug.INFO, "1")
local config_tab = cjson.encode(addr_id_table)
if (config_tab ~= nil) then
    module_debug.lua_debug(module_debug.INFO, "config_tab = %s", config_tab)
end
os.execute("dev_config del -m user_group '"..config_tab.."'")

print("{\"code\":\"0\", \"msg\":\"\"}")
--统一改成配置完后重启进程，其他命令都不需要了
--io.popen("/etc/init.d/content_audit restart")
--os.execute("/etc/init.d/content_audit restart 1>/dev/null > /dev/null")
--os.execute("/etc/init.d/content_audit stop 1>/dev/null > /dev/null")
--os.execute("/etc/init.d/content_audit start 1>/dev/null > /dev/null")

