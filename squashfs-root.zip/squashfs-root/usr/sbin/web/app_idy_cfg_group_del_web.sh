. /usr/share/libubox/jshn.sh
json_init

opt=$1
rst="fail"
msg="config fail!"
opt2=$2


/usr/sbin/web/app_idy_create_cfg_file.sh
####����Key_Group
if [ $opt = "-k" ]; then
  /usr/sbin/idyc -G -k -n -a$opt2
  if [ $? = "1" ]; then
    uci del_list app_identify.@Key_Group[0].app=$opt2
    rst="succ"
    msg="config success!"
  fi
fi


####����Other_Group
if [ $opt = "-o" ]; then
  /usr/sbin/idyc -G -o -n -a$opt2
  if [ $? = "1" ]; then
    uci del_list app_identify.@Other_Group[0].app=$opt2
    rst="succ"
    msg="config success!"
  fi
fi


####����Block_Group
if [ $opt = "-b" ]; then
  /usr/sbin/idyc -G -b -n -a$opt2
  if [ $? = "1" ]; then
    uci del_list app_identify.@Block_Group[0].app=$opt2
    rst="succ"
    msg="config success!"
  fi
fi


####Inhibitive_Group
if [ $opt = "-i" ]; then
  /usr/sbin/idyc -G -i -n -a$opt2
  if [ $? = "1" ]; then
    uci del_list app_identify.@Inhibitive_Group[0].app=$opt2
    rst="succ"
    msg="config success!"
  fi
fi
  
  
if [ $opt = "-g" ]; then
  /usr/sbin/idyc -G -n -g$2
  if [ $? = "1" ]; then
    test=""
	#�ж�section ��Group_Group $2���Ƿ����
    test=$(uci get app_identify.$2)
    if [ "$test" = "Custom_Group" ]; then
      uci delete app_identify.$2
      rst="succ"
      msg="config success!"
	else
      rst="succ"
      msg="not found custom_group '$2'!"
    fi
  fi
fi 
  
if [ $opt = "-c" ]; then
  /usr/sbin/idyc -G -c$2 -a$3
  if [ $? = "1" ]; then
    test=""
	#�ж�section ��Group_Group $2���Ƿ����
    test=$(uci get app_identify.$2)
    if [ "$test" = "Custom_Group" ]; then
      uci del_list app_identify.$2.app=$3
      rst="succ"
      msg="config success!"
	else
      rst="succ"
      msg="not found custom_group '$2'!"
    fi
  fi
fi

uci commit app_identify

if [ $rst = "succ" ]; then
  json_add_string "code"  "0"
  json_add_string "msg"   "$msg"
else
  json_add_string "code"  "1"
  json_add_string "msg"   "$msg"
fi
json_dump
