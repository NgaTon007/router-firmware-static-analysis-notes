package.path = string.format("%s;%s;/www/guest_auth/?.lua", package.path, "./?.lua")
local module_debug = require "utils.debug"
local cjson = require "luci.json" 
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local x = require "luci.model.uci".cursor()
require "pub"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

local portal_0 = {
    ["name"] = "Default Portal",
    ["id"]   = "0",
    ["type"] = "local"
}

--debug初始化
local function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_get_portal_list.log", 500, module_debug.INFO, "1");
end

local function traceback(msg)
    module_debug.lua_debug(module_debug.ERROR, debug.traceback());
end

function main()
    local result = {}
    result["portalCnt"] = "1"
    result["portal"] = {}
    result["idmax"] = x:get("guest_auth", "portal_main", "idmax")
    table.insert(result["portal"], portal_0)
    module_debug.lua_debug(module_debug.DEBUG, "Start get portal_list");

    local total = x:get("guest_auth", "portal_main", "total")
    if (total == nil or total == "" or tonumber(total) == 0) then
        result["idmax"] = "1"
        print(cjson.encode(result))
        return 
    end

    result["portalCnt"] = tostring(tonumber(total) + 1)
    local portal_list = x:get_list("guest_auth", "portal_main", "portal")
    for k,v in ipairs(portal_list) do
        local portal_info = {}
        portal_info["name"] = x:get("guest_auth", v, "portalName")
        portal_info["id"] = x:get("guest_auth", v, "id")
        portal_info["type"] = x:get("guest_auth", v, "portalType")
        if (portal_info["type"] == nil) then
            portal_info["type"] = "local"
        end
        table.insert(result["portal"], portal_info)
    end

    print(cjson.encode(result))
end

debug_init()
xpcall(main, traceback)  
