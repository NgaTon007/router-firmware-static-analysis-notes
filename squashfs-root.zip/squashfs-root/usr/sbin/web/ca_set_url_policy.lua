package.path = "/usr/sbin/web/?.lua"
package.path = "/usr/lib/lua/?.lua;" .. package.path;
require "public_module"

require("uci")
x = uci.cursor()

local version = x:get("content_audit", "signature", "version")

function get_cls_name(url_policy_list)
	local cfg_name = ""

	if (version == "3") then
		if (url_policy_list["url_available"] == "1") then
			cfg_name = "ca_url_list_en"
		else
			cfg_name = "ca_url_list"
		end
	else
		if (url_policy_list["url_available"] == "1") then
			cfg_name = "ca_url_list"
		else
			cfg_name = "ca_url_list_en"
		end
	end

    url_policy_list["class_name"] = {}
	for i, v in ipairs(url_policy_list["url_class"]) do
		local name = x:get(cfg_name, v, "name")
		url_policy_list["class_name"][i] = name
	end
end

local app_comparison_table = {
	["社交软件"] = "communication",
	["视频|音乐|直播"] = "video",
	["网络购物"] = "shopping",
	["网络游戏"] = "games",
	["应用商店"] = "app_store",
	["金融软件"] = "financial"
}

if (arg[1] == nil or arg[2] == nil or arg[3] == nil) then
    print("{\"code\":\"-1\", \"msg\":\"parameter is null\"}")
    return
end

config_file = arg[3] --增量配合需要写框架配置文件
config_table = public_module.read_file(config_file)
if (config_table == nil) then
	print("{\"code\":\"-1\", \"msg\":\"config file is not exist\"}")
	return
end

local usr_grp_ab = arg[2]
local ctmngt = require("ca_time_manager")
local user_grp
if (usr_grp_ab == "1") then
	user_grp = require "user_mgr.user_mgr_common"
end
local cjson = require "cjson"  
local jsonStr = cjson.decode(arg[1]);
local json_info = {}

local operate
local rule_name
local rule_id
local old_url_obj
local old_pos
local new_rule = {}

--[如果policy为空表示新建策略--]
if (jsonStr["policy"] == "") then
    operate = "create"
    local policy_cnt = x:get("content_audit", "count", "policy")
	local increase = tonumber(policy_cnt) + 1
	local version = x:get("content_audit", "signature", "version")
	jsonStr["policy"] = "policy_" .. increase
	x:set("content_audit", "count", "policy", increase)
	x:set("content_audit", jsonStr["policy"], "policy")
	new_rule["policy"] = jsonStr["policy"]
	--[当前设置policy界面不需要输入名称,所以这个name选项可以去掉--]
--    x:set("content_audit", jsonStr["policy"], "name", jsonStr["policy"])
	--[创建对应的rule，当前是1:1关系--]
	local rule_cnt = x:get("content_audit", "count", "url_rule")
	increase = tonumber(rule_cnt) + 1
	local rule = "url_rule_" .. increase
	x:set("content_audit", "count", "url_rule", increase)
	--[记录关联的rule--]
	x:set("content_audit", jsonStr["policy"], "rule", rule)
	x:set("content_audit", rule, "url_rule")
	x:set("content_audit", rule, "policy_name", jsonStr["policy"])
	rule_id = increase
	x:set("content_audit", rule, "rule_id", increase)
	--下发时，策略默认为有效的
	x:set("content_audit", rule, "url_available", 1)
	x:set("content_audit", rule, "version", version)
	x:set("content_audit", rule, "action", jsonStr["action"])
	rule_name = rule
	x:set("content_audit", rule_name, "enable", jsonStr["enable"])
	new_rule["enable"] = jsonStr["enable"]
	if (jsonStr["comment"] ~= nil) then
		x:set("content_audit", rule_name, "comment", jsonStr["comment"])
	end
	new_rule["comment"] = jsonStr["comment"]
elseif(jsonStr["policy"] ~= nil) then
    local flag = x:get("content_audit", jsonStr["policy"])
	--[存在指定的policy，web修改必定是存在的，除非认为修改了config--]
	if (flag ~= nil) then
		--[如果policy存在且不为空表示修改策略--]
		operate = "modify"
		local content_usr = x:get("content_audit", jsonStr["policy"], "usr_name")
		local pos = string.find(content_usr, "self_usr")
		--[如果原策略关联的usr是自定义的则先删除--]
		if (pos) then
			x:delete("content_audit", content_usr)
		else
			if (usr_grp_ab == "1") then
				local content_usr = x:get("content_audit", jsonStr["policy"], "usr_group")
				local pos1 = string.find(content_usr, "ca_usr_grp")
				--[如果原策略关联的usr是用户组的则先删除--]
				if (pos1) then
					x:delete("content_audit", content_usr)
					--调用usr group接口，删除虚拟用户组
					user_grp.user_mgr_del_vgrp(content_usr)
				end
			end
		end
		local rule = x:get("content_audit", jsonStr["policy"], "rule")
		local tr = x:get("content_audit", rule, "time_range")
		--[解除时间关联--]
		ctmngt.deref_time_range(tr)
		local pos2 = string.find(tr, "self_tr")
		--[如果原策略关联的tr是自定义的则先删除--]
		if (pos2) then
--			x:delete("content_audit", tr)
            ctmngt.del_time_range(tr)
		end
		--[删除原关联的url_obj--]
		local url_obj = x:get("content_audit", rule, "url_object")
		old_url_obj = url_obj

		rule_name = rule
		rule_id = x:get("content_audit", rule, "rule_id")
		x:set("content_audit", rule_name, "enable", jsonStr["enable"])
		new_rule["policy"] = jsonStr["policy"]
		new_rule["enable"] = jsonStr["enable"]
		if (jsonStr["comment"] ~= nil) then
			x:set("content_audit", rule_name, "comment", jsonStr["comment"])
		end
		new_rule["comment"] = jsonStr["comment"]
		for k,v in pairs(config_table["list"]) do
			if (v["policy"] == jsonStr["policy"]) then
				old_pos = k
				break
			end
		end
	end
else
    return -1
end
new_rule["url_available"] = "1"
new_rule["action"] = jsonStr["action"]
new_rule["ip_name"] = ""
new_rule["time_mode"] = "calendar"

local ip_slots = {}
--[如果ip_group 和 user_group_list[]为空表示地址是自定义的--]
if (jsonStr["ip_group"] ~= "") then
	x:set("content_audit", jsonStr["policy"], "usr_name", jsonStr["ip_group"])
else
	if (jsonStr["ip_slots"][1] == "") then
		local usr_group_cnt = x:get("content_audit", "count", "usr_group")
		if (usr_group_cnt == nil) then
			usr_group_cnt = 0;
		end
		local increase = tonumber(usr_group_cnt) + 1
		local usr_grp_name = "ca_usr_grp_" .. increase
		x:set("content_audit", "count", "usr_group", increase)
		x:set("content_audit", usr_grp_name, "usr_group")
		--[自定义地址节名和name选项分配同一名称--]
		x:set("content_audit", usr_grp_name, "name", usr_grp_name)
		if (#jsonStr["user_group_list"] ~= 0) then
			x:set("content_audit", usr_grp_name, "user_list", jsonStr["user_group_list"])
		end
		x:set("content_audit", jsonStr["policy"], "usr_name", "no_address")
		x:set("content_audit", jsonStr["policy"], "usr_group", usr_grp_name)
		--调用usr group接口，增加虚拟用户组
		user_grp.user_mgr_add_vgrp(usr_grp_name,jsonStr["user_group_list"])
	else
		local self_usr_cnt = x:get("content_audit", "count", "self_usr")
		local increase = tonumber(self_usr_cnt) + 1
		local ip_grp_name = "self_usr_" .. increase
		x:set("content_audit", "count", "self_usr", increase)
		x:set("content_audit", ip_grp_name, "content_usr")
		--[自定义地址节名和name选项分配同一名称--]
		x:set("content_audit", ip_grp_name, "name", ip_grp_name)
		x:set("content_audit", ip_grp_name, "flag", "usr")
		if (#jsonStr["ip_slots"] ~= 0) then
			x:set("content_audit", ip_grp_name, "ip_range", jsonStr["ip_slots"])
		end
		x:set("content_audit", jsonStr["policy"], "usr_name", ip_grp_name)
		ip_slots = jsonStr["ip_slots"]
	end
end
new_rule["ip_group"] = jsonStr["ip_group"]
new_rule["user_group_list"] = jsonStr["user_group_list"]
new_rule["ip_slots"] = ip_slots

--[如果tr_group为空表示时间是自定义的--]
new_rule["tr_group"] = jsonStr["tr_group"]
if (jsonStr["tr_group"] == "") then
    local list_tab = {}
    local self_tr_cnt = x:get("content_audit", "count", "self_tr")
	local increase = tonumber(self_tr_cnt) + 1
	jsonStr["tr_group"] = "self_tr_" .. increase	
	x:set("content_audit", "count", "self_tr", increase)
	--[向tmngtd增加时间对象--]
	local tr_slots = cjson.encode(jsonStr["tr_slots"])
	ctmngt.add_time_range(jsonStr["tr_group"], tr_slots, "auto")
end
x:set("content_audit", rule_name, "time_range", jsonStr["tr_group"])
new_rule["tr_slots"] = jsonStr["tr_slots"]
--[向tmngtd关联时间对象，并获取当前时间对象是否生效--]
ctmngt.ref_time_range(jsonStr["tr_group"])
--local tr_eft = ctmngt.get_tr_effect(jsonStr["tr_group"])
--ctmngt.add_to_json_cfg(jsonStr["tr_group"], "0")

if (operate == "create") then  
	local url_obj_cnt = x:get("content_audit", "count", "url_obj")
	local increase = tonumber(url_obj_cnt) + 1
	jsonStr["url_obj"] = "url_obj_" .. increase 
	x:set("content_audit", "count", "url_obj", increase)
	x:set("content_audit", jsonStr["url_obj"], "url_object")
else
    jsonStr["url_obj"] = old_url_obj
end
if (#jsonStr["url_class"] ~= 0) then
	x:set("content_audit", jsonStr["url_obj"], "url_class", jsonStr["url_class"])
end
x:set("content_audit", rule_name, "url_object", jsonStr["url_obj"])
new_rule["url_class"] = jsonStr["url_class"]
-- new_rule["url_obj"] = jsonStr["url_obj"]

local enable
local policy_num
if (operate == "create") then
	local policy_total = x:get("content_audit", "count", "policy_total")
	policy_num = tonumber(policy_total) + 1
	x:set("content_audit", "count", "policy_total", policy_num)
	enable = x:get("content_audit", "content_audit", "enable")
	if (policy_num > 0 and enable == "0") then
		x:set("content_audit", "content_audit", "enable", "1")		
		os.execute("/bin/sh /usr/sbin/web/app_idy_set_module.sh content_audit on")
	end
end

x:commit("content_audit")
get_cls_name(new_rule)

-- if (operate == "create") then
--     if (policy_num > 0 and enable == "0") then
-- 		os.execute("insmod /lib/modules/$(uname -r)/content_audit.ko")
-- 	    os.execute("/etc/init.d/content_audit start 1>/dev/null > /dev/null")
-- 	end
-- end
-- 一致性后任何时候都有可能启动进程
if (ctmngt.content_audit_is_exist() == false) then
	if (ctmngt.content_audit_enable_flag() == true) then
		os.execute("/etc/init.d/content_audit start 1>/dev/null > /dev/null")
	end
end

if (operate == "create") then
	--json配置文件插入到末尾，不需要考虑顺序
	table.insert(config_table["list"], new_rule)
else
	--json配置文件插入原先位置，不需要考虑顺序
	table.remove(config_table["list"], old_pos)
	table.insert(config_table["list"], old_pos, new_rule)
end
config_table["count"] = #config_table["list"];
--保存dev_config的模块json配置文件
public_module.write_file(config_table, config_file)

print("{\"code\":\"0\", \"msg\":\"\",\"policy\":\"" .. jsonStr["policy"] .."\"}")

--统一改成配置完后重启进程，其他命令都不需要了
--io.popen("/etc/init.d/content_audit restart")
--os.execute("/etc/init.d/content_audit restart 1>/dev/null > /dev/null")
--os.execute("/etc/init.d/content_audit stop 1>/dev/null > /dev/null")
--os.execute("/etc/init.d/content_audit start 1>/dev/null > /dev/null")
