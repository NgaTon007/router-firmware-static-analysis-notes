#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local table_input_err = {rcode = "05630001", rmsg = "param error"}

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_set_authlog_reupload.log", 200, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

local function authlog_reupload_set(param_tab)
    if param_tab["reupload_enable"] == nil or param_tab["upload_now"] == nil then
        return 1
    end
    module_debug.lua_debug(module_debug.INFO, "INFO:param_tab.reupload_enable:%s, param_tab.upload_now:%s", param_tab["reupload_enable"], param_tab["upload_now"])
    uci:set("webservice", "webservice", "reupload_enable", param_tab["reupload_enable"])
    uci:commit("webservice")
        
    if param_tab["upload_now"] == "1" then
        local cmd = 'curl --connect-timeout 2 http://127.0.0.1:2060/upload_authlog 2>/dev/null > /dev/null'
        module_debug.lua_debug(module_debug.INFO, "INFO:cmd:%s", cmd)
        os.execute(cmd)
    end

    return 0
end

function main()
    if (arg[1] == nil) then
		return check_result("0001")
	end

    if (lib_param.lua_param_safety_check(arg[1]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:param is unsafe : %s", arg[1])
        return check_result("0001")
    end
    local param_tab = cjson.decode(arg[1]);

    local ret = authlog_reupload_set(param_tab)
    if (ret ~= 0) then
        return check_result("0001")
    end
    return check_result("0000")
end

function traceback(msg)
    print("{\"code\":\"-1\", \"msg\":\"", debug.traceback(), "\"}") 
end  

debug_init()
xpcall(main, traceback)  