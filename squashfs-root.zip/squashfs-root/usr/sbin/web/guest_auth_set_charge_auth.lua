#!/usr/bin/env lua
package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")

local console = require "console"
local cjson = require "cjson"
local lfs = require "lfs"
local uci = require "luci.model.uci".cursor()
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local lib_param = require("libc2lua")
local util = require "luci.util"
local DEBUG_LOG_DIR = "/tmp/guest_auth/"
local table_input_err = {rcode = "05630001", rmsg = "param error"}
local default_ad_url = "http://xxxxxxxxxxxx/auth/wifidogAuth/login/"
local default_ad_uri = "/auth/wifidogAuth/login/"
local web_default_ad_uri = "/auth/servlet/standardAuthServlet"
local web_default_sec_ad_uri = "/auth/wifidogAuth"
local def_url_ad_url = uci:get("app_auth", "def_url", "ad_url")
local def_url_service_url = uci:get("app_auth", "def_url", "service_url")
local ignore_crt = 1
local server_name = require("product").get_product("capacity.portal.server_name")

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "guest_auth_set_charge_auth.log", 200, module_debug.INFO, "1");
end

function check_result(ret)
    if ret == "0000" then
        return console.uf_lua_success()
    elseif ret == "0001" then
        return console.uf_lua_fail(table_input_err)
    end
end

--@chargeAuth_set
-- ������֤��ʽҪ�����������Ѱ�ť --- Y
-- config auth_rule
--         option name 'charge_web' 'charge_pppoe'
--         option ser_name 'charge_web' 'charge_pppoe'
--         option ad_url 'https://${ad_url}/auth/wifidogAuth/login/'
--         option rdt_style 'wifidog'
--         option enable '1'
--         option remind_enable '1'
--         option proxy_https '1'
--         list ip 'xxx.xxx.xxx.xxx-xxx.xxx.xxx.xxx'
function cloud_auth_rule_on()
    local name_list = uci:get("app_auth", "module", "name")
    if name_list == nil then
        return false
    end
    for key, v in pairs(name_list) do
        if (v == server_name or v == "remind") then
            return true
        end
    end
    return false
end

function app_idy_set_module(param)
    if (tool.file_exist("/usr/sbin/web/app_idy_set_module.sh") == false) then
       return
    end
    if (param == "up") then
        os.execute("/bin/sh /usr/sbin/web/app_idy_set_module.sh app_auth on 2>/dev/null >/dev/null")
    elseif (param == "down") then
        os.execute("/bin/sh /usr/sbin/web/app_idy_set_module.sh app_auth off 2>/dev/null >/dev/null")
    end
end

local function chargeAuthSet(param_tab, charge_type)
    local proxy_https = param_tab["proxy_https"]
    local ad_url = default_ad_url
    local auth_rule_name = "charge_" .. charge_type
    local cmd = ""
    local protocol = ""
    local pppoe_auth_enable = nil
    local cloud_auth_enable = cloud_auth_rule_on()
    
    if proxy_https == nil or proxy_https == "" then
        proxy_https = "1"
    end

    module_debug.lua_debug(module_debug.INFO, "INFO: auth_rule is %s", auth_rule_name)
    if (param_tab["auth_enable"] == nil or param_tab["remind_enable"] == nil) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR: [module_set] param_tab is nil")
        return "{\"code\":\"1\",\"msg\":\"param is nil!\"}"
    end

    uci:foreach("app_auth", "auth_rule", function(s)
        local name = s[".name"]
        local ser_name = uci:get("app_auth", name, "ser_name")
        if (ser_name == auth_rule_name) then
            if (charge_type == "pppoe") then
                pppoe_auth_enable = uci:get("app_auth", name, "enable")
            end
            if (param_tab["auth_enable"] == "1") then
                uci:delete("app_auth", name)
            else
                uci:set("app_auth", name, "enable", "0")
                uci:set("app_auth", name, "proxy_https", proxy_https)
                uci:set("app_auth", name, "remind_enable", param_tab["remind_enable"])
                uci:delete("app_auth", name, "ip")
                if auth_rule_name == "charge_web" then
                    cmd = '/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "charge_web" "off"'
                elseif auth_rule_name == "charge_pppoe" then
                    cmd = '/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "charge_pppoe" "off"'
                end
                os.execute(cmd)
                if cloud_auth_enable == false then
                    app_idy_set_module("down")
                end
            end
        end
    end
    )

    if (param_tab["auth_enable"] == "1") then
        local name =uci:add("app_auth", "auth_rule")
        local ip_list = {}
        for i,v in pairs(param_tab["auth_rule"]) do
            if (v["ip_range"] ~= nil) then
                table.insert(ip_list, v["ip_range"])
            end
        end
        
        if param_tab["remind_enable"] ~= nil and param_tab["remind_enable"] ~= "" then
            uci:set("app_auth", name, "remind_enable", param_tab["remind_enable"])
        else
            uci:set("app_auth", name, "remind_enable", "0")
        end

        if param_tab["ad_url"] ~= nil and param_tab["ad_url"] ~= "" then
            protocol = param_tab["ad_url"]:match("^(.-)://")
            if protocol == nil or protocol == "" then
                protocol = "http://"
            elseif protocol == "https" then
                protocol = ""
            elseif protocol == "http" then
                protocol = ""
            else
                protocol = "http://"
            end
            ad_url = protocol .. param_tab["ad_url"] .. default_ad_uri
        end

        if param_tab["macByPass"] ~= nil and param_tab["macByPass"] ~= "" then
            uci:set("app_auth", "app_auth", "mac_inq", param_tab["macByPass"])
        end

        if param_tab["cfgIdOpt"] ~= nil then
            if param_tab["cfgIdOpt"] == "2" then
                uci:set("app_auth", "app_auth", "cfg_id_opt", "id-mac")
            else
                uci:set("app_auth", "app_auth", "cfg_id_opt", "id-ip")
            end
        end

        uci:set("app_auth", name, "name", auth_rule_name)
        uci:set("app_auth", name, "ser_name", auth_rule_name)
        uci:set("app_auth", name, "enable", "1")
        uci:set("app_auth", name, "ad_url", ad_url)
        uci:set("app_auth", name, "rdt_style", "wifidog")
        uci:set("app_auth", name, "proxy_https", proxy_https)
        uci:set_list("app_auth", name, "ip", ip_list)
        uci:commit("app_auth")

        if (def_url_ad_url == nil or def_url_service_url == nil or def_url_ad_url ~= param_tab["ad_url"]) then
            uci:set("webservice", "webservice", "user_url", protocol .. param_tab["ad_url"] .. web_default_ad_uri)
            uci:set("webservice", "webservice", "sec_user_url", protocol .. param_tab["ad_url"] .. web_default_sec_ad_uri)
            uci:set("webservice", "webservice", "service_url", protocol .. param_tab["ad_url"] .. web_default_ad_uri)
            uci:set("webservice", "webservice", "sec_service_url", protocol .. param_tab["ad_url"] .. web_default_sec_ad_uri)
        else
            uci:set("webservice", "webservice", "user_url", def_url_ad_url .. web_default_ad_uri)
            uci:set("webservice", "webservice", "sec_user_url", def_url_ad_url .. web_default_sec_ad_uri)
            ignore_crt = 0
            uci:set("webservice", "webservice", "service_url", def_url_service_url .. web_default_ad_uri)
            uci:set("webservice", "webservice", "sec_service_url", def_url_service_url .. web_default_sec_ad_uri)
        end
        uci:set("webservice", "webservice", "ignore_crt", ignore_crt)
        if param_tab["portalCheck"] ~= nil and param_tab["portalCheck"] ~= "" then
            uci:set("webservice", "webservice", "portal_check", param_tab["portalCheck"])
        end
        if param_tab["client_sync"] ~= nil and param_tab["client_sync"] ~= "" then
            uci:set("webservice", "webservice", "client_sync", param_tab["client_sync"])
        else
            uci:set("webservice", "webservice", "client_sync", "1")
        end
        if param_tab["client_sync_interval"] ~= nil and param_tab["client_sync_interval"] ~= "" then
            uci:set("webservice", "webservice", "client_sync_interval", param_tab["client_sync_interval"])
        end
        uci:commit("webservice")
        if auth_rule_name == "charge_web" then
            cmd = '/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "charge_web" "on"'
        elseif auth_rule_name == "charge_pppoe" then
            cmd = '/usr/bin/lua /usr/sbin/web/app_auth_set_module_sw.lua "charge_pppoe" "on"'
        end
        os.execute(cmd)
        app_idy_set_module("up")
    elseif (param_tab["auth_enable"] == "0") then
        uci:commit("app_auth")
    end

    if charge_type == "pppoe" and pppoe_auth_enable ~= param_tab["auth_enable"] then
        os.execute("/usr/bin/lua /usr/sbin/web/account_mgr_update.lua &")
        module_debug.lua_debug(module_debug.INFO, "INFO:account_mgr_update")
    end

    return 0
end

function main()
    if (arg[1] == nil or arg[2] == nil) then
		return check_result("0001")
	end

    if (lib_param.lua_param_safety_check(arg[2]) ~= true) then
        module_debug.lua_debug(module_debug.ERROR, "ERROR:param is unsafe : %s", arg[2])
        return check_result("0001")
    end
    local param_tab = cjson.decode(arg[2]);

    local ret = chargeAuthSet(param_tab, arg[1])
    if (ret ~= 0) then
        return check_result("0001")
    end
    return check_result("0000")
end

debug_init()
main()