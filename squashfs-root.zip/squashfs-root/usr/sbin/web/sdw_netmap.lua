#!/usr/bin/env lua
package.path = "/usr/lib/lua/?.lua;" .. package.path;

local uci = require "luci.model.uci".cursor()
local cjson = require "cjson"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_LOG_DIR = "/tmp/sdwan/"
local SDWAN_JSON_FILE = "/etc/sd_config/single/sdwan.json"

if (tool.file_exist(DEBUG_LOG_DIR) == false) then
    local path = "mkdir -p " .. DEBUG_LOG_DIR .. " >/dev/null 2>&1"
    os.execute(path);
end

--debug初始化
function debug_init()
    module_debug.debug_init(DEBUG_LOG_DIR, "sdw_netmap.log", 500, module_debug.INFO, "1");
end

function main()
    module_debug.lua_debug(module_debug.INFO, "################################main START################################")
    if (tool.file_exist(SDWAN_JSON_FILE) == false) then
        module_debug.lua_debug(module_debug.ERROR, "%s is not exsit.", SDWAN_JSON_FILE)
        return
    end
    local sdwan_json_tab = tool.file_read(SDWAN_JSON_FILE)
    if (sdwan_json_tab == nil) then
        module_debug.lua_debug(module_debug.ERROR, "sdwan_json_tab is nil")
        return
    end
    local sdwan_postrouting_del = ('/usr/sbin/iptables -w -t nat -F sdwan_postrouting 2>/dev/null')
    local sdwan_prerouting_del = ('/usr/sbin/iptables -w -t nat -F sdwan_prerouting 2>/dev/null')
    os.execute(sdwan_postrouting_del)
    os.execute(sdwan_prerouting_del)
    os.execute('echo "'..sdwan_postrouting_del..'" >> /tmp/iptables.rules/n2n_edge_policy')
    os.execute('echo "'..sdwan_prerouting_del..'" >> /tmp/iptables.rules/n2n_edge_policy')
    local sdwan_config_tab = cjson.decode(sdwan_json_tab)
    if sdwan_config_tab.netMap ~= nil and sdwan_config_tab.netMap.map ~= nil then
        local map_entries = sdwan_config_tab.netMap.map
        local entry_count = #map_entries
        if entry_count == 0 then
            module_debug.lua_debug(module_debug.INFO, "netmap count is 0")
            return
        else 
            module_debug.lua_debug(module_debug.INFO, "netmap count is %d", entry_count)
        end
        for idx, entry in ipairs(map_entries) do
            if entry.src ~= nil and entry.src ~= "" and entry.dst ~= nil and entry.dst ~= "" then
                module_debug.lua_debug(module_debug.INFO, "Entry %d:", idx)
                module_debug.lua_debug(module_debug.INFO, "SRC:%s, DST:%s", entry.src, entry.dst)
                local netmap_out_del_cmd = ('/usr/sbin/iptables -w -t nat -D sdwan_postrouting -s '..entry.src..' -j NETMAP --to '..entry.dst..' 2>/dev/null')
                local netmap_out_cmd = ('/usr/sbin/iptables -w -t nat -A sdwan_postrouting -s '..entry.src..' -j NETMAP --to '..entry.dst..' 2>/dev/null')
                local netmap_in_del_cmd = ('/usr/sbin/iptables -w -t nat -D sdwan_prerouting -d '..entry.dst..' -j NETMAP --to '..entry.src..' 2>/dev/null')
                local netmap_in_cmd = ('/usr/sbin/iptables -w -t nat -A sdwan_prerouting -d '..entry.dst..' -j NETMAP --to '..entry.src..' 2>/dev/null')
                os.execute('echo "'..netmap_out_del_cmd..'" >> /tmp/iptables.rules/n2n_edge_policy')
                os.execute('echo "'..netmap_out_cmd..'" >> /tmp/iptables.rules/n2n_edge_policy')
                os.execute('echo "'..netmap_in_del_cmd..'" >> /tmp/iptables.rules/n2n_edge_policy')
                os.execute('echo "'..netmap_in_cmd..'" >> /tmp/iptables.rules/n2n_edge_policy')
                os.execute(netmap_out_del_cmd)
                os.execute(netmap_out_cmd)
                os.execute(netmap_in_del_cmd)
                os.execute(netmap_in_cmd)
            end
        end
    else
        module_debug.lua_debug(module_debug.INFO, "netmap is nil or netMap.map is nil")
    end
    module_debug.lua_debug(module_debug.INFO, "################################main END################################")
end

---------------------------------------------main--------------------------------------------------
debug_init()
main()
