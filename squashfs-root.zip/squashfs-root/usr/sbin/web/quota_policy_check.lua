#!/usr/bin/env lua
-- /etc/hotplug.d/intf_exist/wan-quota-simple
-- 监听 WAN 接口销毁事件，检查其是否在配额配置中
-- 特殊处理：wan0 视为与 wan 相同
-- 日志记录到 /tmp/run/quota/wan_check.log，自动轮转（10KB）

local cjson = require "luci.json"
local module_debug = require "utils.debug"
local dev_config = require "dev_config"

local LOG_DIR = "/tmp/run/quota/"
local LOG_FILE = "wan_check.log"

local function debug_init()
    os.execute("mkdir -p " .. LOG_DIR .. " >/dev/null 2>&1")
    module_debug.debug_init(LOG_DIR, LOG_FILE, 500, module_debug.INFO, "1")
end

local function traceback(msg)
    module_debug.lua_debug(module_debug.ERROR, "%s\n%s", tostring(msg), debug.traceback())
end

local function log_debug(msg)
    module_debug.lua_debug(module_debug.DEBUG, "%s", msg)
end

local function log_info(msg)
    module_debug.lua_debug(module_debug.INFO, "%s", msg)
end

local function log_error(msg)
    module_debug.lua_debug(module_debug.ERROR, "%s", msg)
end

local function normalize_name(name)
    if type(name) ~= "string" then
        return ""
    end

    name = string.lower(name)
    if name == "wan0" then
        return "wan"
    end
    return name
end

local function run_cmd(cmd)
    local handle = io.popen(cmd)
    if not handle then
        return nil
    end

    local output = handle:read("*all")
    handle:close()
    return output
end

local function get_network_info()
    local output = run_cmd("dev_config get -m network 2>/dev/null")
    if not output or output == "" then
        return nil, nil
    end

    local ok, config = pcall(cjson.decode, output)
    if not ok or type(config) ~= "table" then
        return nil, nil
    end

    local subwan_set = {}
    if type(config.wan) == "table" then
        for _, wan_item in ipairs(config.wan) do
            if type(wan_item) == "table" and type(wan_item.subwan) == "table" then
                for _, subwan_item in ipairs(wan_item.subwan) do
                    local intf_name = subwan_item and subwan_item.intfName
                    if type(intf_name) == "string" and intf_name ~= "" then
                        subwan_set[normalize_name(intf_name)] = true
                    end
                end
            end
        end
    end

    return tonumber(config.wanNum), subwan_set
end

local function get_current_wan_set()
    local output = run_cmd("dev_sta get -m port_status 2>/dev/null")
    if not output or output == "" then
        return nil, 0
    end

    local ok, config = pcall(cjson.decode, output)
    if not ok or type(config) ~= "table" or type(config.List) ~= "table" then
        return nil, 0
    end

    local wan_set = {}
    local wan_count = 0
    for _, item in ipairs(config.List) do
        local name = item and item.name
        if type(name) == "string" and string.upper(name) ~= "LAN" then
            local wan_name = normalize_name(name)
            wan_set[wan_name] = true
            wan_count = wan_count + 1
        end
    end

    return wan_set, wan_count
end

local function is_wan_name(name)
    return string.match(name, "^wan%d*$") ~= nil
        or string.match(name, "^wan%d+_.+$") ~= nil
        or string.match(name, "^wan_%d+") ~= nil
end

local function set_to_str(t)
    if type(t) ~= "table" then return "nil" end
    local keys = {}
    for k, _ in pairs(t) do
        keys[#keys + 1] = tostring(k)
    end
    table.sort(keys)
    return "{" .. table.concat(keys, ", ") .. "}"
end

local function main()
    local wan_num, subwan_set = get_network_info()
    if not wan_num then
        log_error("错误: 无法获取 network.wanNum")
        return 1
    end
    log_debug(string.format("network.wanNum=%d, subwan_set=%s", wan_num, set_to_str(subwan_set)))

    local wan_set, current_wan_count = get_current_wan_set()
    if not wan_set then
        log_error("错误: 无法获取 port_status WAN 列表")
        return 1
    end
    log_debug(string.format("port_status wan_count=%d, wan_set=%s", current_wan_count, set_to_str(wan_set)))

    if wan_num ~= current_wan_count then
        log_error(string.format("错误: network.wanNum 与 port_status WAN 列表数量不匹配,network.wanNum=%d, port_status_wan_count=%d", wan_num, current_wan_count))
        return 1
    end

    for intf_name, _ in pairs(subwan_set or {}) do
        wan_set[intf_name] = true
    end
    log_debug(string.format("合并subwan后 wan_set=%s", set_to_str(wan_set)))

    local config_json = run_cmd("dev_config get -m quotaIntf 2>/dev/null")
    if not config_json or config_json == "" then
        log_error("错误: 无法获取配额配置")
        return 1
    end

    local ok, config = pcall(cjson.decode, config_json)
    if not ok or type(config) ~= "table" or type(config.list) ~= "table" then
        log_error("错误: JSON 解析失败或配置结构无效")
        return 1
    end

    local quota_names = {}
    for _, item in ipairs(config.list) do
        if item and type(item.name) == "string" then
            quota_names[#quota_names + 1] = item.name
        end
    end
    log_debug(string.format("quotaIntf配置列表: {%s}", table.concat(quota_names, ", ")))

    local matched = false
    for _, item in ipairs(config.list) do
        local qname = item and item.name
        if type(qname) == "string" and qname ~= "" then
            local norm_qname = normalize_name(qname)
            log_debug(string.format("检查配额项: name=%s, norm=%s, is_wan=%s, in_wan_set=%s",
                qname, norm_qname, tostring(is_wan_name(norm_qname)), tostring(wan_set[norm_qname] ~= nil)))
            if is_wan_name(norm_qname) and not wan_set[norm_qname] then
                matched = true
                log_debug("检测到消失WAN并删除配额配置: " .. qname .. " (归一化后: " .. norm_qname .. ")")

                dev_config.fetch("del", "quotaIntf", cjson.encode({ name = qname }), "1")
            end
        end
    end

    if not matched then
        log_info("WAN口有变化，但未找到需要删除的quotaIntf配置")
    end
    return 0
end

debug_init()
xpcall(main, traceback)