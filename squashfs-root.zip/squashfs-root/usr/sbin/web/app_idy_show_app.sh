. /usr/share/libubox/jshn.sh
json_init
json_add_string "code"  "0"
json_add_string "msg"   "succ"
json_add_array  "app_list"

read nothing		#���˵���һ��

#read app index      #��ȡ��һ�У�any 255-4095-63-48 
json_add_object "head"
json_add_string "app_name"         "$app"
json_add_string "app_index"       "$index"
json_add_array  "app_list"

blank=4				#�ո�ĸ���������������λ���ж��Ƿ������ϵ
IFSbak=$IFS
IFS="\n"
first_flag=1
blank_4_cnt=1
blank_8_cnt=1
blank_12_cnt=1
blank_16_cnt=1
last_line_blank=0

while
  read -r line		#��ȡһ��
do
  blank_num=0
  for i in 1 2 3 4 5
  do
    #����������λ��
    tmp_num=$blank_num
    str=${line:$tmp_num:4}
	if [ ${str} = "    " ] ;
	then
      let blank_num+=4
	  continue
	else
	  break
	fi
  done
  
  sub_line=${line:$blank_num}
  app_name=$(echo $sub_line|tr " " "\n"| sed -n 1p)
  app_index=$(echo $sub_line|tr " " "\n"| sed -n 2p)
  
  #������������ĸ��ո�����
  if [ $blank_num = 4 ] ;
  then
    if [ $first_flag = 0 ];
	then
	  if [ $last_line_blank = 16 ];
	  then
		json_close_array   "app_blk_8"
		json_close_object  "blk_8"
		json_close_array   "app_blk_12"
		json_close_object  "blk_12"
		json_close_array   "app_blk_16"
		json_close_object  "blk_16"
	  fi
	  if [ $last_line_blank = 12 ];
	  then
		json_close_array   "app_blk_8"
		json_close_object  "blk_8"
		json_close_array   "app_blk_12"
		json_close_object  "blk_12"
	  fi
	  if [ $last_line_blank = 8 ];
	  then
	    json_close_array   "app_list"
		json_close_object  "blk_8"
	  fi
      json_close_object  "blk_4"
	  json_close_array   "app_list"
	fi
    json_add_object "blk_4"
    json_add_string "app_name"         "$app_name"
    json_add_string "app_index"        "$app_index"
    json_add_array  "app_list"
	first_flag=0
	first_8_blk_flag=1
  fi
  
  
  #������������˸��ո�����
  if [ $blank_num = 8 ] ;
  then
    if [ $first_8_blk_flag = 0 ];
	then
	  if [ $last_line_blank = 16 ];
	  then
		json_close_array   "app_blk_12"
		json_close_object  "blk_12"
		json_close_array   "app_blk_16"
		json_close_object  "blk_16"
	  fi
	  if [ $last_line_blank = 12 ];
	  then
		json_close_array   "app_blk_12"
		json_close_object  "blk_12"
	  fi
	  json_close_array   "app_list"
      json_close_object  "blk_8"
	fi
    json_add_object "blk_8"
    json_add_string "app_name"         "$app_name"
    json_add_string "app_index"        "$app_index"
    json_add_array  "app_list"
	first_12_blk_flag=1
	first_8_blk_flag=0
  fi
  
  #������������˸��ո�����
  if [ $blank_num = 12 ] ;
  then
    if [ $first_12_blk_flag = 0 ];
	then
	  if [ $last_line_blank = 16 ];
	  then
		json_close_array   "app_blk_16"
		json_close_object  "blk_16"
	  fi
	  json_close_array   "app_list"
      json_close_object  "blk_12"
	fi
    json_add_object "blk_12"
    json_add_string "app_name"         "$app_name"
    json_add_string "app_index"        "$app_index"
    json_add_array  "app_list"
	first_16_blk_flag=1
	first_12_blk_flag=0
  fi
  #������������˸��ո�����
  if [ $blank_num = 16 ] ;
  then
    if [ $first_16_blk_flag = 0 ];
	then
	  json_close_array   "app_list"
      json_close_object  "blk_16"
	fi
    json_add_object "blk_16"
    json_add_string "app_name"         "$app_name"
    json_add_string "app_index"        "$app_index"
    json_add_array  "app_list"
	first_16_blk_flag=0
  fi
  last_line_blank=$blank_num		#��¼��һ��������Ŀ
done
IFS=$IFSbak
if [ $last_line_blank = 16 ]; then
  json_close_array   "app_blk_8"
  json_close_object  "blk_8"
  json_close_array   "app_blk_12"
  json_close_object  "blk_12"
  json_close_array   "app_blk_16"
  json_close_object  "blk_16"
fi
if [ $last_line_blank = 12 ]; then
  json_close_array   "app_blk_8"
  json_close_object  "blk_8"
  json_close_array   "app_blk_12"
  json_close_object  "blk_12"
fi
if [ $last_line_blank = 8 ];then
  json_close_array   "app_list"
  json_close_object  "blk_8"
fi
json_close_object "blk_4"
json_close_array "app_list"
json_close_object "head"
json_close_array "app_list"
json_dump