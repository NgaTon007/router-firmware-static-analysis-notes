package.path = "/usr/lib/lua/?.lua;"
local libc2lua = require("libc2lua");

if arg[1] == nil then
    print("{\"code\":\"-1\", \"msg\":\"type parameter error\"}")
    return
end
if (libc2lua.lua_param_safety_check(arg[1]) ~= true) then
	print("{\"code\":\"-1\", \"msg\":\"[ipinfo]param is no safety\"}")
	return
end

if string.match(arg[1], "\\n") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end
if string.match(arg[1], ">") then
	print("{\"code\":\"-1\", \"msg\":\"type parameter error \"}")
    return
end

function lua_string_split_space(str)
    local sub_str_tab = {}
    for i in string.gmatch(str, "%S+") do
        table.insert(sub_str_tab, i)
    end

    return sub_str_tab
end

local in_cjson = require "cjson" 
local jsonStr = in_cjson.decode(arg[1]);
local sub_info = {}
local ip, onlineTime, session
local passUp
local passDown
local cjson = require "dkjson"
local ary_data = {}
local cnt = 1
local t
local cmd = "/usr/sbin/flow_audit_cmd.elf -S -r -s -g"

if (jsonStr["dir"] == nil or jsonStr["order"] == nil) then
	cmd = cmd
else
	if (jsonStr["order_type"] == "top") then
        cmd = cmd.." --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"].." --top "..jsonStr["top"]
    elseif (jsonStr["order_type"] == "page") then
        cmd = cmd.." --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"].." --start "..jsonStr["pos"].." --limit "..jsonStr["limit"]
	else
		cmd = cmd.." --order-by --pass".." --"..jsonStr["dir"].." --"..jsonStr["order"]
	end
end
t = io.popen(cmd)
for line in t:lines() do
	if (string.sub(line, -1) == "\r") then
		line = string.sub(line, 1, string.len(line) - 1)
	end
	table.insert(sub_info, line)
end
ary_data["list"] = {}
for i=5,#sub_info, 3 do
	local info = lua_string_split_space(sub_info[i])
	userName = info[1]
	ip = info[2]
	session = info[3]
	onlineTime = info[4]
    info = lua_string_split_space(sub_info[i+1])
    passUp = info[1]
    passDown = info[2]
	ary_data["list"][cnt] = {}
	ary_data["list"][cnt]["ip"] = ip
	ary_data["list"][cnt]["userName"] = userName
	ary_data["list"][cnt]["session"] = session
	ary_data["list"][cnt]["onlineTime"] = onlineTime
	ary_data["list"][cnt]["up"] = passUp
	ary_data["list"][cnt]["down"] = passDown
	cnt = cnt + 1
end

ary_data["count"] = cnt - 1
local jsonStr = cjson.encode(ary_data);
print(jsonStr);
