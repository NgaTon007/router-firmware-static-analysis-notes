#! /usr/bin/lua
require("uci")
x = uci.cursor()
y = uci.cursor("/rom/etc/config", nil)

-- 当客户保留配置升级时，/etc/config/app_identify配置文件的兼容性处理
-- 读取/rom/etc/config/app_identify文件的系统组，赋值给/etc/config/app_identify
-- 系统应用组，值为在配置文件中的位置，尽量不删除变动
local app_position_table = {
    ["communication"] = 7,
    ["video"] = 8,
    ["shopping"] = 9,
    ["games"] = 10,
    ["databank"] = 11,
    ["p2p_software"] = 12,
    ["app_store"] = 13,
    ["financial"] = 14,
    ["news"] = 15,
    ["service"] = 16,
    ["business"] = 17,
    ["payment"] = 18,
    ["protocol"] = 19,
    ["study"] = 20,
    ["child_social"] = 21,
    ["child_game"] = 22,
    ["child_video"] = 23,
    ["child_payment"] = 24,
    ["child_study"] = 25,
    ["child_appstore"] = 26,
    ["communication_En"] = 27,
    ["video_En"] = 28,
    ["shopping_En"] = 29,
    ["games_En"] = 30,
    ["reading_En"] = 31,
    ["databank_En"] = 32,
    ["p2p_software_En"] = 33,
    ["app_store_En"] = 34,
    ["payment_En"] = 35,
    ["service_En"] = 36,
    ["protocol_En"] = 37,
}

local function app_idy_syn_config()
    -- 国内特征库系统组
    y:foreach("app_identify", "Custom_Group", function(s)
        local section_name = s[".name"]
        local section = {}
        local option_name = y:get("app_identify", section_name, "name")
        section["app_list"] = y:get("app_identify", section_name, "app")
        local position = app_position_table[section_name]
        if (position) then
            x:delete("app_identify", section_name)
            if (position ~= -1) then
                x:set("app_identify", section_name, "Custom_Group")
                x:set("app_identify", section_name, "name", option_name)
                x:set("app_identify", section_name, "app", section["app_list"])
                x:reorder("app_identify", section_name, position)
            end
        end
    end
    )
    -- 国际特征库系统组
    y:foreach("app_identify", "Custom_Group_En", function(s)
        local section_name = s[".name"]
        local section = {}
        local option_name = y:get("app_identify", section_name, "name")
        section["app_list"] = y:get("app_identify", section_name, "app")
        local position = app_position_table[section_name]
        if (position) then
            x:delete("app_identify", section_name)
            if (position ~= -1) then
                x:set("app_identify", section_name, "Custom_Group_En")
                x:set("app_identify", section_name, "name", option_name)
                x:set("app_identify", section_name, "app", section["app_list"])
                x:reorder("app_identify", section_name, position)
            end
        end
    end
    )
    -- 中国库青少年模式系统组
    y:foreach("app_identify", "Custom_Group_Child", function(s)
        local section_name = s[".name"]
        local section = {}
        local option_name = y:get("app_identify", section_name, "name")
        section["app_list"] = y:get("app_identify", section_name, "app")
        local position = app_position_table[section_name]
        if (position) then
            x:delete("app_identify", section_name)
            if (position ~= -1) then
                x:set("app_identify", section_name, "Custom_Group_Child")
                x:set("app_identify", section_name, "name", option_name)
                x:set("app_identify", section_name, "app", section["app_list"])
                x:reorder("app_identify", section_name, position)
            end
        end
    end
    )
    x:commit("app_identify")
end

if (string.sub(arg[0], -string.len("app_idy_synchronize_config.lua")) == "app_idy_synchronize_config.lua") then
    app_idy_syn_config()
end
