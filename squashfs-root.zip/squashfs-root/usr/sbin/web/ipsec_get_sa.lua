package.path = string.format("%s;%s;", package.path, "/usr/sbin/web/?.lua")
require "ipsec_pub"
local module_debug = require "utils.debug"
local tool = require "dev.tools.common"
local DEBUG_DIR_LOGFILE = "/tmp/ipsec/log/"

if (tool.file_exist(DEBUG_DIR_LOGFILE) == false) then
    local path = "mkdir -p " .. DEBUG_DIR_LOGFILE .. " >/dev/null 2>&1"
    os.execute(path);
end

function debug_init()
    module_debug.debug_init(DEBUG_DIR_LOGFILE, "ipsec_get_sa.log", 1000, module_debug.INFO, "1");
end

local connection_list={}
function get_all_ipsec_sa()
    local cmd=string.format("ipsec stroke statusall-nb")
    local cmd_outputs =io.popen(cmd)
    local each_line
    local line_counts=0
    local flag
    local parsing_ike_sa=false
    local parsing_child_sa=false
    local ike_sa_remain_line=0
    local child_sa_remain_line=0
    local uci = require "luci.model.uci"
    local ret={}
    local total_item=0
    local lines_per_sa=0
    local name=nil
    local child_sa_name=nil
    local local_binding=nil
    local remote_peer=nil 
    local encapsule=nil 
    local spi_in=nil 
    local spi_out=nil 
    local ah_auth_alg=nil
    local esp_auth_alg=nil
    local encapsule_alg=nil
    local left_net=nil 
    local right_net=nil 
    local ikeVer=nil
    local uci_r = uci.cursor()
    ---------------------------------get all connection section -----------------------------------
    uci_r:foreach("ipsec", "connection",
        function(section)
            connection_list[#connection_list + 1] = uci_r:get_all("ipsec", section[".name"])        
                if not connection_list[#connection_list] then
                return 
            end        
        end 
    )   
    
    each_line=cmd_outputs:read("*line") 
    line_counts=0 
    flag=0
    parsing_ike_sa=false
    parsing_child_sa=false
    ike_sa_remain_line=0
    child_sa_remain_line=0  
    total_item=1
    while each_line do 
        line_counts=line_counts+1
        local i=nil
        local j=nil     
        
        --解析的思路：先解析IKE_SA,然后解析CHILD_SA,一般地,IKE_SA 和CHILD_SA是一一对应的，但是也不排斥一个IKE_SA对应多个CHILD_SA的情况，
        --因此，解析的方法是：先解析3行，解析完IKE_SA,然后再使用3行来解析出CHILD_SA,接着再使用3行来解析CHILD_SA.
        if false == parsing_ike_sa and false == parsing_child_sa then 
            --重新确定下一步是什么状态
            --ike_sa阶段,目前仅仅解析ESTABLISHED, 其它(REKEY等)
            i,j=string.find(each_line,"ESTABLISHED")
            if nil ~= i then                
                parsing_ike_sa=true         
                parsing_child_sa=false
                --正常解析完一个ike_sa，需要解析3行，也就是说，解析完一个ike_sa，刚刚好3行 
                ike_sa_remain_line=3
                --每个IKE_SA隐含包括3行IKE_SA和3行CHILD_SA,提前赋值，为了避免认为解析完IKE_SA就万事大吉了。
                child_sa_remain_line=3                  
                --ike_sa需要解析出来的三个参数
                flag=1                              
                name=nil
                local_binding=nil
                remote_peer=nil 
                
                --child_sa需要解析出来的
                encapsule=nil 
                spi_in=nil 
                spi_out=nil 
                ah_auth_alg=nil
                esp_auth_alg=nil
                encapsule_alg=nil
                left_net=nil 
                right_net=nil 
                --dbg(string.format("########%s######## ",each_line))
                --dbg(string.format("Starting a IKE_SA decode. "))
    
            end     
                
            --辨识是否是child_sa阶段
            i,j=string.find(each_line,"INSTALLED")
            if nil ~= i then 
                --CHILD_SA是否需要开始解析还取决于IKE_SA是否解析成功.
                if nil ~= name and nil ~= local_binding and nil ~=  remote_peer  then 
                    parsing_ike_sa=false            
                    parsing_child_sa=true
                    --正常解析完一个child_sa，需要解析3行，也就是说，解析完一个child_sa，刚刚好3行 
                    child_sa_remain_line=3              
                    flag=1      
                    --child_sa需要解析出来的
                    encapsule=nil               
                    spi_in=nil 
                    spi_out=nil 
                    ah_auth_alg=nil
                    esp_auth_alg=nil
                    encapsule_alg=nil
                    left_net=nil 
                    right_net=nil   
                --  dbg(string.format("########%s######## ",each_line))
                    --dbg(string.format("Starting a CHILD_SA decode. "))
                else 
                --  dbg(string.format("########%s######## ",each_line))
                    dbg(string.format("It's a wrong CHILD_SA,because No IKE_SA exist."))        
                end 
            end                 
            
        end
        
        --需要解析3行来解析ike_sa
        if true == parsing_ike_sa then 
            if 3 == ike_sa_remain_line and 1 == flag then       
                --解析第一行，此行会获取到三个参数：隧道名以及隧道起始点和终止点
                --name 
                i,j=string.find(each_line,":")
                if nil ~= i and nil ~= j then                   
                    name=string.sub(each_line,1,i-1)
                    --dbg(string.format("tunnel name: %s",name))
                else 
                    dbg("Fail to decode the output ,can not get the tunnel name .")
                    flag=0
                end 
                
                --local_binding
                i,j=string.find(each_line,"ago,")
                if nil ~= i and nil ~= j then                   
                    each_line=string.sub(each_line,j+1,string.len(each_line))
                    --dbg(string.format("line remains: %s",each_line))                  
                else 
                    dbg("Fail to decode the output ,can not get the local_binding .")
                    flag=0                   
                end                     
                if 0 ~= flag then 
                    --%是lua的转义字符
                    i,j=string.find(each_line,"%[")
                    if nil ~= i and nil ~= j then 
                        local_binding=string.sub(each_line,1,i-1)
                        --dbg(string.format("tunnel local_binding: %s",local_binding))
                        each_line=string.sub(each_line,j+1,string.len(each_line))
                        --dbg(string.format("line remains: %s",each_line))
                    else
                        flag=0
                        --dbg("Fail to decode the output ,can not get the local_binding .")
                    end 
                end 
                
                --remote peer
                i,j=string.find(each_line,"%.%.%.")
                if nil ~= i and nil ~= j then                   
                    each_line=string.sub(each_line,j+1,string.len(each_line))
                    --dbg(string.format("line remains: %s",each_line))                  
                else 
                    dbg("Fail to decode the output ,can not get the remote peer.")
                    flag=0                   
                end 
                
                if 0 ~= flag then 
                    i,j=string.find(each_line,"%[")
                    if nil ~= i and nil ~= j then 
                        remote_peer=string.sub(each_line,1,i-1)
                        --dbg(string.format("tunnel remote peer: %s",remote_peer))
                        each_line=string.sub(each_line,j+1,string.len(each_line))
                        --dbg(string.format("line remains: %s",each_line))
                    else
                        flag=0
                        dbg("Fail to decode the output ,can not get the remote_peer name .")
                    end 
                end 
                
                --sane check 
                if nil == name or nil == local_binding or nil == remote_peer then 
                    flag=0
                    dbg("Fail to decode the output ,forget it.")
                --else 
                --  dbg(string.format("decode success, name: %s local_binding: %s remote_peer: %s ",name ,local_binding,remote_peer))
                end 
                -- 没有任何信息需要从第2、1行获取的，除非以后需要获取ike_sa 第一阶段信息。             
            end 
            ike_sa_remain_line=ike_sa_remain_line-1
            if 0 == ike_sa_remain_line then 
                if 0 == flag then               
                    --dbg(string.format("decode IKS_SA success, name: %s local_binding: %s remote_peer: %s ",name ,local_binding,remote_peer))
                --else 
                    dbg(string.format("decode IKE_SA failed"))
                end
                parsing_ike_sa=false
            end
        end 
        
        --flag 用于标识是否需要解析该行，在解析过程中可以赋值为0，表示不需要解析该行，直到遇到下一个"ESTABLISHED"为止.
        if true == parsing_child_sa then    
            --dbg(string.format("child_sa_remain_line:%d ",child_sa_remain_line))
            if 3 == child_sa_remain_line and 1 == flag then
                local tailor=string.format("{%%d+}:")
                i,j=string.find(each_line,tailor)
                if nil ~= i then 
                    child_sa_name=string.sub(each_line,1,i-1)
                else 
                    child_sa_name="---"
                end 
                
                -- encapsule,spi,direction
                -- to check if it's of 'ESP' protocol , or 'AH'
                i,j=string.find(each_line,"ESP")
                if nil ~= i and nil ~= j then 
                    encapsule="ESP"
                else
                    -- it should be either 'AH' or 'ESP'
                    i,j=string.find(each_line,"AH")
                    if nil ~= i and nil ~= j then 
                        encapsule="AH"
                    else 
                        flag =0 
                    end                     
                end 
                
                if 0 ~= flag then 
                    i,j=string.find(each_line,"SPIs:")
                    if nil ~= i and nil ~= j then 
                        each_line=string.sub(each_line,j+1,string.len(each_line))                       
                    else 
                        flag=0 
                    end 
                end 
        
                if 0 ~= flag then 
                    i,j=string.find(each_line,"_i")
                    if nil ~= i and nil ~= j then 
                        spi_in=string.sub(each_line,1,i-1)
                        each_line=string.sub(each_line,j+1,string.len(each_line))                       
                    else
                        flag=0 
                    end 
                end 
        
                if 0 ~= flag then 
                    i,j=string.find(each_line,"_o")
                    if nil ~= i and nil ~= j then 
                        spi_out=string.sub(each_line,1,i-1)                     
                    else
                        flag=0 
                    end 
                end 
                --dbg(string.format("decode success, encapsule:%s spi_in:%s spi_out:%s flag=%d",encapsule,spi_in,spi_out,flag))
                
            elseif 2 == child_sa_remain_line and 1 == flag then 
                i,j=string.find(each_line,":  ")
                if nil ~= i and nil ~= j then 
                    each_line=string.sub(each_line,j+1,string.len(each_line))
                    i,j=string.find(each_line,"/")  
                    if nil ~= i and nil ~= j then 
                        -- 'ESP'情形
                        encapsule_alg=string.sub(each_line,1,j-1)
                        each_line=string.sub(each_line,j+1,string.len(each_line))
                        i,j=string.find(each_line,",")
                        if nil ~= i and nil ~= j then 
                            --'ESP'情形除了加密算法，还有验证算法.
                            esp_auth_alg=string.sub(each_line,1,j-1)                            
                            ah_auth_alg="--"
                        else
                            flag=0
                        end 
                    else
                        --'AH' 情形
                        if "AH" == encapsule then 
                            encapsule_alg="--"
                            i,j=string.find(each_line,",")
                            if nil ~= i and nil ~= j then 
                                --AH情形只有auth算法
                                ah_auth_alg=string.sub(each_line,1,j-1)                     
                                esp_auth_alg="--"
                            else
                                flag=0
                            end                             
                        else 
                            flag=0
                        end                                         
                    end
                else
                    flag=0 
                end 
                --dbg(string.format("decode success, esp_auth_alg:%s encapsule_alg:%s ",esp_auth_alg,encapsule_alg))                
            elseif 1 == child_sa_remain_line and 1 == flag then
                i,j=string.find(each_line,":  ")
                if nil ~= i and nil ~= j then 
                    each_line=string.sub(each_line,j+1,string.len(each_line))
                    i,j=string.find(each_line,"===")
                    if nil ~= i and nil ~= j then 
                        left_net=string.sub(each_line,1,i-1)
                        right_net=string.sub(each_line,j+1,string.len(each_line))
                    else
                        flag=0 
                    end 
                else 
                    flag=0 
                end
                --dbg(string.format("decode CHILD_SA,left: %s ---> right: %s  ",left_net,right_net))                    
            end             
            child_sa_remain_line=child_sa_remain_line-1
            
            --秋天，是收获的季节
            if 0 == child_sa_remain_line then 
                if 0 == flag then               
                    --dbg(string.format("decode CHILD_SA success,left: %s ---> right: %s  ",left_net,right_net))    
                --else 
                    dbg(string.format("decode CHILD_SA failed"))
                end
                parsing_child_sa=false
            end
        end 

        --所有参数解析完毕，而且都解析成功,则组装js条目返回给页面,每次解析都需要返回两个方向的条目，故有两条条目
        if 0 ~= flag and 0 == child_sa_remain_line and 0 == ike_sa_remain_line then
            
            --为了使IPSec安全联盟的显示更加直观，对算法名称进行如下的转换
            local algname_transform = { ["--"] = "--", 
                                        ["HMAC_MD5_96"] = "MD5",
                                        ["HMAC_SHA1_96"] = "SHA1", 
                                        ["AES_CBC_128"] = "AES-128",
                                        ["AES_CBC_192"] = "AES-192",
                                        ["AES_CBC_256"] = "AES-256",
                                        ["DES_CBC"] = "DES",
                                        ["3DES_CBC"] = "3DES"}  

            if nil ~= algname_transform[ah_auth_alg] then 
                ah_auth_alg = algname_transform[ah_auth_alg]
            end
            if nil ~= algname_transform[esp_auth_alg] then 
                esp_auth_alg = algname_transform[esp_auth_alg]
            end
            if nil ~= algname_transform[encapsule_alg] then 
                encapsule_alg = algname_transform[encapsule_alg]
            end

            --将SPI转化为10进制显示，与之前的产品统一            
            if nil ~= spi_in and nil ~= spi_out then 
                spi_in = "0x" .. string.gsub(spi_in,"^%s*(.-)%s*$","%1")
                spi_out = "0x" .. string.gsub(spi_out,"^%s*(.-)%s*$","%1")

                spi_in = string.format("%u",spi_in)
                spi_out = string.format("%u",spi_out)
            end

            if child_sa_name ~= nill then
                child_sa_name = string.gsub(child_sa_name,"^%s*(.-)%s*$","%1")
            end


            for k, connection in ipairs(connection_list) do
                if nil ~= connection.ipsec_name and string.find(child_sa_name, connection.ipsec_name)then
                    child_sa_name = connection.name
                    ikeVer = connection.ikeVer
                end
            end

            --"in" 方向 
            ret[2*total_item-1]={}
            ret[2*total_item-1].name=child_sa_name
            ret[2*total_item-1].spi=spi_in
            ret[2*total_item-1].direction="in"
            ret[2*total_item-1].tunnel=string.format("%s<--%s",local_binding,remote_peer)
            ret[2*total_item-1].flows=string.format("%s<--%s",left_net,right_net)
            ret[2*total_item-1].encapsule=encapsule
            ret[2*total_item-1].ah_auth_alg=ah_auth_alg
            ret[2*total_item-1].esp_auth_alg=esp_auth_alg
            ret[2*total_item-1].encapsule_alg=encapsule_alg
            ret[2*total_item-1].ikeVer=ikeVer
            ret[2*total_item-1].status = 1 
            ret[2*total_item-1].reason = ""
            --"out" 方向
            ret[2*total_item]={}
            ret[2*total_item].name=child_sa_name
            ret[2*total_item].spi=spi_out
            ret[2*total_item].direction="out"
            ret[2*total_item].tunnel=string.format("%s-->%s",local_binding,remote_peer)
            ret[2*total_item].flows=string.format("%s-->%s",left_net,right_net)
            ret[2*total_item].encapsule=encapsule
            ret[2*total_item].ah_auth_alg=ah_auth_alg
            ret[2*total_item].esp_auth_alg=esp_auth_alg
            ret[2*total_item].encapsule_alg=encapsule_alg
            ret[2*total_item].ikeVer=ikeVer   
            ret[2*total_item].status = 1  
            ret[2*total_item].reason = ""           
            total_item=total_item+1
            --成功识别出一条隧道之后，需要把标志位复原，意味着一切都需要从头开始解析，否则会出现下一个each_line
            --既不是ike_sa，也不是child_sa，但是依然加入了ret值，导致webUI中显示出重复的条目。
            flag=0
        end         
        --dbg(string.format("lines_per_sa:%d ",lines_per_sa))
        each_line=cmd_outputs:read("*line") 
        
        
    end 
    --print(string.format("total_item:%d",total_item-1))
    --[[
    ret[1]={}
    ret[1].name="policy_one"    --line 1、
    ret[1].spi="211090286/hh"   --line 4、
    ret[1].direction="in"       --line 4、
    ret[1].tunnel="192.168.1.122<->192.168.1.100"   --line 1 
    ret[1].flows="192.168.14.0/24<-192.168.13.0/24"  ---line 6
    ret[1].encapsule="ESP"      --- line 4
    ret[1].ah_auth_alg="---"    --- line 5 
    ret[1].esp_auth_alg="md5"   --- line 5
    ret[1].encapsule_alg="3des" --- line 5
    
    ret[2]={}
    ret[2].name="policy_two_llll"
    ret[2].spi="211090286"
    ret[2].direction="in"
    ret[2].tunnel="192.168.1.122<->192.168.1.100"
    ret[2].flows="192.168.14.0/24<-192.168.13.0/24"
    ret[2].encapsule="ESP"
    ret[2].ah_auth_alg="---"
    ret[2].esp_auth_alg="md5"
    ret[2].encapsule_alg="3des"
    --]]

    --dbg.dumptable(ret)
    --[[ strongSwan 5.1.1起支持AH算法，get_all_ipsec_sa实现的前提输入是ipsec statusall 的输出格式，如果有变化，则解析也需要做相关改变
    ESP输出：
  ipsecpolli[1]: ESTABLISHED 99 seconds ago, 192.168.1.1[192.168.1.1]...192.168.1.145[192.168.1.145]
  ipsecpolli[1]: IKEv1 SPIs: 4d30170c7877d6ec_i 5c5bd254ffbb6898_r*, pre-shared key reauthentication in 10 hours
  ipsecpolli[1]: IKE proposal: 3DES_CBC/HMAC_MD5_96/PRF_HMAC_MD5/MODP_1024
  ipsecpolli{1}:  INSTALLED, TUNNEL, reqid 1, ESP SPIs: c27563d3_i cbe62263_o
  ipsecpolli{1}:  3DES_CBC/HMAC_MD5_96, 0 bytes_i, 0 bytes_o, rekeying in 9 hours
  ipsecpolli{1}:   192.168.10.0/24 === 192.168.11.0/24
  
    AH输出：
  ipsecpolli[1]: ESTABLISHED 7 seconds ago, 192.168.1.1[192.168.1.1]...192.168.1.145[192.168.1.145]
  ipsecpolli[1]: IKEv1 SPIs: af0d61a74febaf6d_i 4a30cfe722d40744_r*, pre-shared key reauthentication in 10 hours
  ipsecpolli[1]: IKE proposal: 3DES_CBC/HMAC_MD5_96/PRF_HMAC_MD5/MODP_1024
  ipsecpolli{1}:  INSTALLED, TUNNEL, reqid 1, AH SPIs: cd9de932_i c6f8a2ec_o
  ipsecpolli{1}:  HMAC_MD5_96, 0 bytes_i, 0 bytes_o, rekeying in 9 hours
  ipsecpolli{1}:   192.168.10.0/24 === 192.168.11.0/24
  
  有一种特殊的输出，即：一个IKE_SA对应着多个CHILD_SA(IPSEC_SA)，如下：
     ipsec_192[1]: ESTABLISHED 5 seconds ago, 1.1.1.75[server_7520]...1.1.1.145[client_any_is_ok]
   ipsec_192[1]: IKEv1 SPIs: d35f9361494456ce_i* a6d8be4fbbdc2c32_r, pre-shared key reauthentication in 7 hours
   ipsec_192[1]: IKE proposal: 3DES_CBC/HMAC_MD5_96/PRF_HMAC_MD5/MODP_1024
   ipsec_192{1}:  INSTALLED, TUNNEL, reqid 1, ESP SPIs: c3a11b1f_i cc452bd8_o
   ipsec_192{1}:  3DES_CBC/HMAC_MD5_96, 0 bytes_i, 0 bytes_o, rekeying in 7 hours
   ipsec_192{1}:   192.168.1.0/24 === 192.168.0.192/26
    ipsec_64{2}:  INSTALLED, TUNNEL, reqid 2, ESP SPIs: c03de528_i cb987f12_o
    ipsec_64{2}:  3DES_CBC/HMAC_MD5_96, 0 bytes_i, 0 bytes_o, rekeying in 7 hours
    ipsec_64{2}:   192.168.1.0/24 === 192.168.0.64/26
 
    --]]
    --PrintTable(ret)
    return ret 
end 

local cjson = require "luci.json" 
local status = ""
local data_tab = {}
local file = io.open("/tmp/log/ipsec_status", "r+")
if io.type(file) ~= nil then
    status = file:read("*all")
    file:close()
end

if (status ~= nil and status ~= "") then
    data_tab = cjson.decode(status)
else
    data_tab.data = {}	
end

function main()
    debug_init()
    local sa = {}
    local count
    
    sa.data = get_all_ipsec_sa()
    for i=1, #connection_list do
        count = 0
        if connection_list[i].status == "enable" then
            for k=1, #sa.data do
                if (sa.data[k].name == connection_list[i].name) then
                    count = count + 1
                    sa.data[k].status = 1
                end
            end
            if type(connection_list[i].remote_network) ~= "table" then
                module_debug.lua_debug(module_debug.INFO, "remote_network is not table");
                connection_list[i].remote_network = lua_string_split(connection_list[i].remote_network, ",")
                connection_list[i].local_network = lua_string_split(connection_list[i].local_network, ",")
            end
            for j=1, #data_tab.data do
                if (data_tab.data[j].status == 0 and count < #connection_list[i].remote_network * 2 and data_tab.data[j].name == connection_list[i].name) then  
                    data_tab.data[j].spi = "---"
                    data_tab.data[j].direction = "---"
                    data_tab.data[j].tunnel = "---"
                    data_tab.data[j].flows = "---"
                    data_tab.data[j].encapsule = "---"
                    data_tab.data[j].esp_auth_alg = "---"
                    data_tab.data[j].ah_auth_alg = "---"
                    data_tab.data[j].encapsule_alg = "---"
                    data_tab.data[j].ikeVer = "---"
                    table.insert(sa.data, data_tab.data[j])
                end
            end
        end
    end
    
    local jsonStr = cjson.encode(sa)
    print(jsonStr)
end
main()
function traceback(msg)
    print("{\"code\":\"-1\", \"msg\":\"error!\"}") 
end  
  
--xpcall(main, traceback)  

