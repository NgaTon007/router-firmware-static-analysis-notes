#!/bin/sh
cap1=$(cat /tmp/sd_device/sd_device.json |jq .eweb.line_quality -r)
cap2=$(cat /tmp/sd_device/sd_device.json |jq .gateway.qualityRouting -r)
[[ $cap1 != "1" && $cap2 != "1" ]] && exit 1

if ! cat /etc/sd_config/single/qualityRouting.json | jq -e '.list[] | select(.enable == "on")' > /dev/null; then
    # 如果不存在任何一个为"on"，则退出
        exit 1
fi

process_cnt=`ps | grep /usr/sbin/qualityRouting.elf | grep -v grep | wc -l`

if [ "$process_cnt" == "0" ]; then
    /etc/init.d/qualityRouting restart
fi
