#!/bin/sh
# Copyright (C) 2019 .
# Author: wangliang
# Date: 2019-08-08

#获取当前设备某个IP的TCP状态为ASSURED且外网回来的报文数大于1个的流表以及对应的应用识别结果。
#用于应用识别诊断问题。

[ -z "$1" ] && echo "Error: please input your ip address" && exit 0

IFS_old=$IFS            #whole line
IFS=$'\n'

cat /proc/net/nf_conntrack | grep $1 | grep tcp | grep ASSURED > /tmp/tcp.txt
cat /proc/app_identify | grep $1 | grep TCP > /tmp/idy.txt

cur_line=$(cat /tmp/tcp.txt)
for line in $(cat /tmp/tcp.txt); do
        pkt=$(echo $line | awk '{ print $17 }')
        pkt_num=${pkt#*\=}
        if [ $pkt_num -gt '1' ]; then
            echo $line
			sport=$(echo $line | awk '{ print $9 }')
			port_num=${sport#*\=}
			cat /tmp/idy.txt | grep $port_num
        fi
done

IFS=$IFS_old

rm /tmp/tcp.txt
rm /tmp/idy.txt
