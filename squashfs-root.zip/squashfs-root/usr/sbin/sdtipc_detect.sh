#!/bin/sh

SGI_TEST_RST_FILE="/tmp/sdtipc_file"
str_no="No active bearers"
file_name=$0
runCount=`ps |grep $0 | grep -v grep -c`
if [ $runCount -gt 2 ]
then
    exit 1
fi

while true
do
	sleep 10
	result=$(sdtipc-config -b | grep "${str_no}")

	if [[ "$result" != "" ]]
	then
		forward=$(uci -q get sysinfo.@sysinfo[0].forwardMode)
		dev_type=$(uci -q get sysinfo.@sysinfo[0].dev_type)
		if [[ "$forward" == "ROUTER" ]]
		then
			sdtipc-config -be=sdeth:br-lan
		else
			if [[ "$dev_type" == "msw" ]]
			then
				sdtipc-config -be=sdeth:br-manager
			else
				sdtipc-config -be=sdeth:br-wan
			fi
		fi
	fi
done
