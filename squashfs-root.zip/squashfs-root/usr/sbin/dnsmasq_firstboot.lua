#! /usr/bin/env lua

package.path = "/usr/lib/lua/?.lua;" .. package.path
uci = require("luci.model.uci")
cjson_safe = require "cjson.safe"
module_debug = require "utils.debug"
DHCP_CAP = "/tmp/sd_device/dhcpcap.json"
DEV_CAP = "/tmp/sd_device/sd_device.json"
NETWORK_JSON = "/etc/sd_config/single/network.json"
bit_hl = require "bit"

flag = 0
x = uci.cursor()

module_debug.debug_init("/tmp/dhcp/", "def_dhcp.log", 100, module_debug.DEBUG, "1")

-- read the exist file
-- @path: File path
-- @return file content, if the action success; otherwise return nil.
local function file_read(file)
    local content
    local f = io.open(file,'r')

    if f then
        content = f:read("*all")
        f:close()
    end

    return content
end

-- check file exist
-- @path: File path
-- @return 0, if the file exist; otherwise return -1.
local function file_exist(path)
    local f = io.open(path, "rb");
    if (f) then
        f:close()
        return 0
    end

    return -1
end

-- read the exist file
-- @path: File path
-- @return 0,content_json if the action success; otherwise return -1.
local function read_file_for_json(path)
    local content, content_json

    if (type(path) ~= "string") then
        return -1
    end

    if (file_exist(path) == -1) then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] isn't exist.", path)
        return -1
    end

    content = file_read(path)
    if (content == nil) then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] doesn't read.", path)
        return -1
    end

    content_json = cjson_safe.decode(content)
    if (content_json == nil or type(content_json) ~= "table") then
        module_debug.lua_debug(module_debug.ERROR, "the file [%s] isn't json.", path)
        return -1
    end

    return 0, content_json
end

-- set the dhcp interface receive the dhcp message
local function uci_set_dhcp_enable(intf, start, limit, leasetime, force, ignore)
    flag = 1
    x:set("dhcp", intf, "dhcp")
    x:set("dhcp", intf, "interface", intf)
    x:set("dhcp", intf, "start", start)
    x:set("dhcp", intf, "limit", limit)
    x:set("dhcp", intf, "leasetime", leasetime)
    x:set("dhcp", intf, "ignore", ignore)
    x:set("dhcp", intf, "force", force)
end

-- set the dhcp interface reject the dhcp message
local function uci_set_dhcp_disable(intf, ignore)
    flag = 1
    x:set("dhcp", intf, "dhcp")
    x:set("dhcp", intf, "interface", intf)
    x:set("dhcp", intf, "ignore", ignore)
end

local function ip_to_int(str)
    local num = 0
    if str and type(str)=="string" then
        local o1,o2,o3,o4 = str:match("(%d+)%.(%d+)%.(%d+)%.(%d+)" )
        num = 2^24*o1 + 2^16*o2 + 2^8*o3 + o4
    end
    return num
end

local function ipstart_num_get(ip_start, lan_ip, netmask)
    if(ip_start == "" or lan_ip == "" or netmask == "") then
        return nil;
    end

    ip_start = ip_to_int(ip_start)
    lan_ip = ip_to_int(lan_ip)
    netmask = ip_to_int(netmask)

    local lan_netmask = bit_hl.band(lan_ip, netmask)
    local start_num = ip_start - lan_netmask

    return start_num
end

local function intf_dhcp_set_for_lan(node)
    local intf
    
    if (node["vlanid"] == nil or node["ignore"] == nil) then
        return
    end

    if (node["vlanid"] == "233") then
        intf = "lan"
    else
        intf = string.format("lan_%s", node["vlanid"])
    end

    leasetime = node["leasetime"]
    limit = node["limit"]
    ignore = node["ignore"]
    ipaddr = node["ipaddr"]
    netmask = node["netmask"]

    if (type(leasetime) ~= "string" or type(limit) ~= "string" or type(ignore) ~= "string" or type(ipaddr) ~= "string" or type(netmask) ~= "string") then
        uci_set_dhcp_disable(intf, "1")
    else    
        start = ipstart_num_get(node["ipstart"], node["ipaddr"], node["netmask"])
        leasetime = table.concat({node["leasetime"], "m"})
        
        uci_set_dhcp_enable(intf, start, limit, leasetime, "1", ignore)
    end
end

local function intf_dhcp_set_by_network(network)
    local intf

    if (network["lan"] ~= nil) then
        for k,v in ipairs(network["lan"]) do
            intf_dhcp_set_for_lan(v)
        end
    end
    
    i = 0
    if (network["wan"] ~= nil) then
        for k,v in ipairs(network["wan"]) do
            if (i ~= 0) then
                intf = string.format("wan%s", i)
            else
                intf = "wan"
            end
            
            uci_set_dhcp_disable(intf, "1")
            i = i + 1
        end
    end
end

-- save dnsmasq
local function dnsmasq_commit()
    if (flag == 1) then
        x:commit("dhcp")
        x:revert("dhcp")
    end
end

ret, network = read_file_for_json(NETWORK_JSON)
if (ret ~= -1) then
    intf_dhcp_set_by_network(network)
    dnsmasq_commit()
end




