module("devRemark", package.seeall)

local console = require "console"
local libdbg = require("utils.debug")

local dkjson = require "dkjson"

local dev_config = require "dev_config"

local dev_sta = require "dev_sta"

require("uci")
local cursor = uci.cursor()

libdbg.debug_init("/tmp/devRemark/", "devRemark_lua.log", 200, libdbg.DEBUG, libdbg.OPEN)

--function获取devRemark配置
function get_devRemarkData(ip)
    local tp_conf = dev_config.fetch("get", "devRemark", "", 1, ip)
    if tp_conf == nil or type(tp_conf) ~= "table" then 
        libdbg.lua_debug(libdbg.ERROR, "dev_config get -m devRemark failed")
        return -1
    end
    local tp_data = tp_conf.data
    if tp_data == nil or tp_data == "" then 
        libdbg.lua_debug(libdbg.ERROR, "devRemark_data is null")
        return -1
    end
    local obj = dkjson.decode(tp_data)
    if obj == nil or type(obj) ~= "table" then
        libdbg.lua_debug(libdbg.ERROR, "devRemark_data decode failed")
        return -1
    end
    local devRemark_data = {list = obj.list}
    return devRemark_data
end

--function获取整网能力值，返回配置是否为空 -1:为空;0:不为空
function get_enetcap()
    local result = dev_sta.fetch("get", "enetCap", '{"obj":{"modules":{"devRemark":[]}}}')
    if type(result) ~= "table" or result == nil then
        libdbg.lua_debug(libdbg.ERROR, "enetCap get devRemark failed")
        return -1
    end
    local response = result.data
    local data = dkjson.decode(response)
    if type(data) ~= "table" or data == nil then
        libdbg.lua_debug(libdbg.ERROR, "enetCap get devRemark data invailed")
        return -1
    end

    if data.data[1].modules ~= nil then 
        return 0
    end

    return -1
end

--function有配置的设备添加整网能力值标记
function add_enetCap()
    local enetcap_res = get_enetcap()
    if enetcap_res == 0 then
        libdbg.lua_debug(libdbg.DEBUG, "Don't need set enetCap")
        return 0
    end

    local devRemark_data = get_devRemarkData("")
    if devRemark_data == nil or devRemark_data == -1 then
        libdbg.lua_debug(libdbg.ERROR, "get devRemarkData failed")
        return -1
    end

    -- 有配置则设置 本机 enetCap能力值
    if #devRemark_data.list ~= 0 then
        libdbg.lua_debug(libdbg.DEBUG, "set enetCap")
        local all_content = {}
        all_content["data"] = 1
        local cmdTable = {}
        cmdTable["module"] = "devRemark"
        cmdTable["caps"] = dkjson.encode(all_content)
        local param_string = dkjson.encode(cmdTable)
        libdbg.lua_debug(libdbg.DEBUG, "param_string:%s", param_string)
        dev_sta.fetch("set", "enetCap", param_string)
    else
        libdbg.lua_debug(libdbg.DEBUG, "devRemark_data is null")
    end
    return 0
end

-- --function获取本机的IP地址
-- function get_ip_config(nic_name) 
--     local handle = io.popen("ifconfig " ..nic_name.. " | grep 'inet addr' | awk '{print $2}' | cut -d ':' -f 2") 
--     local result = handle:read("*a") 
--     handle:close() 
--     if result == nil or result == "" then
--         libdbg.lua_debug(libdbg.ERROR, "handle ipconfig result is null")
--         return -1
--     end 
--     return result:gsub("[\n\r]+", "")
-- end

--function从aplist 获取设备的IP地址 根据SN号
function get_ip_fSN(serialNumber)
    local handle = io.popen("dev_sta get -m ap_list")
    local result = handle:read("*a") 
    handle:close() 
    if result == nil or result == "" then
        libdbg.lua_debug(libdbg.ERROR, "handle show ap_list result is null")
        return -1 
    end
    local data = dkjson.decode(result)
    if data == nil or type(data) ~= "table" then
        libdbg.lua_debug(libdbg.ERROR, "ap_list result decode failed")
        return -1
    end
    local ip

    -- DONE #data.list放到循环外面
    local list_len = #data.list
    for i = 1, list_len do
        if data.list[i] ~= nil and data.list[i].serialNumber ~= nil then
            if data.list[i].serialNumber == serialNumber then 
                ip = data.list[i].ip
                if ip == nil then
                    libdbg.lua_debug(libdbg.ERROR, "data.list[i].ip is null")
                end
                break 
            end
        end
    end

    return ip
end

--function获取主设备的信息
function get_master_data()
    local handle = io.popen("dev_sta get -m master")
    local result = handle:read("*a")
    handle:close() 
    if result == nil or result == "" then
        libdbg.lua_debug(libdbg.ERROR, "handle show master result is null")
        return -1 
    end
    local data = dkjson.decode(result)
    if data == nil or type(data) ~= "table" then
        libdbg.lua_debug(libdbg.ERROR, "ap_list result decode failed")
        return -1
    end
    return data
end

--function获取拥有配置的设备的设备号
function get_serialNumber()
    local result = dev_sta.fetch("get", "enetCap", '{"sn":[],"obj":{"modules":{"devRemark":[]}}}')
    if type(result) ~= "table" or result == nil then
        libdbg.lua_debug(libdbg.ERROR, "enetCap get devRemark failed")
        return -1
    end
    local response = result.data
    local data = dkjson.decode(response)
    if type(data) ~= "table" or data == nil then
        libdbg.lua_debug(libdbg.ERROR, "enetCap get devRemark data invailed")
        return -1
    end

    local sn_array = {}
    for i = 1, #data.data do
        if next(data.data[i].modules) ~= nil then 
            table.insert(sn_array, data.data[i].sn)
        end
    end

    return sn_array
end

-- 函数功能:合并两个配置,如果出现重复的mac则master_list的name优先
function merge_list(master_list, slave_list)
    local update_list = {}
    local res_table = {}
    for _, master_obj in ipairs(master_list) do 
        local master_mac = master_obj.mac
        if master_mac == nil or master_mac == "" then
            libdbg.lua_debug(libdbg.ERROR, "master mac get failed")
        end
        res_table[master_mac] = master_obj.name
    end
    for _, slave_obj in ipairs(slave_list) do
        local slave_mac = slave_obj.mac
        if slave_mac == nil or slave_mac == "" then
            libdbg.lua_debug(libdbg.ERROR, "slave mac get failed")
        end
        if res_table[slave_mac] == nil then
            res_table[slave_mac] = slave_obj.name
        end
    end
    for mac_key, name_value in pairs(res_table) do
        local update_obj = {}
        update_obj["mac"] = mac_key
        update_obj["name"] = name_value
        table.insert(update_list, update_obj)
    end
    return update_list
end

local result = ""

result = add_enetCap()
if result ~= 0 or result == nil then
    libdbg.lua_debug(libdbg.ERROR, "add_enetCap failed")
    return
end

-- 判断是否为主设备,主设备才需要同步其他从设备的配置
local master_data = get_master_data()
if master_data == nil or master_data == -1 then
    libdbg.lua_debug(libdbg.ERROR, "master_data is null")
    return
end

local master_ip = master_data.ip
if master_ip == nil or master_ip == "" then
    libdbg.lua_debug(libdbg.ERROR, "master_ip not find")
    return
end

if master_ip ~= "127.0.0.1" then
    libdbg.lua_debug(libdbg.INFO, "device isn't master")
    return
end

--获取拥有配置的设备的sn号
local sn_array = get_serialNumber()
if type(sn_array) ~= "table" or #sn_array == 0 then
    libdbg.lua_debug(libdbg.ERROR, "sn_array not find")
    return
end

--获取主设备的sn号
local master_sn = master_data.sn
if master_sn == nil or master_sn == "" then
    libdbg.lua_debug(libdbg.ERROR, "master_sn not find")
    return
end

--获取拥有配置的从设备的IP号
local slaveIP_array = {}
local sn_arrayLen = #sn_array
for i = 1, sn_arrayLen do
    if sn_array[i] ~= master_sn then
        libdbg.lua_debug(libdbg.DEBUG, "slave_sn:%s", sn_array[i])
        local slave_ip = get_ip_fSN(sn_array[i])
        if slave_ip == -1 then
            libdbg.lua_debug(libdbg.ERROR, "slave_ip get failed sn:%s", sn_array[i])
        end
        libdbg.lua_debug(libdbg.DEBUG, "slave_ip:%s", slave_ip)
        table.insert(slaveIP_array, slave_ip)
    end
end

--如果拥有配置的从设备的sn号为空，则说明主设备不需要新增配置
if #slaveIP_array == 0 then
    libdbg.lua_debug(libdbg.INFO, "master device need't update conifg")
    return
end
-- local master_ip = get_ip_fSN(master_sn)
-- if master_ip == nil or master_ip == -1 then
--     libdbg.lua_debug(libdbg.ERROR, "master ip get failed")
--     return
-- end
for _, slave_ip in ipairs(slaveIP_array) do
    local update_data, update_list, res_table = {}, {}, {}
    local master_data = get_devRemarkData(master_ip)
    if master_data == -1 or master_data == nil then
        libdbg.lua_debug(libdbg.ERROR, "master_data get failed")
        return
    end
    local master_list = master_data.list
    libdbg.lua_debug(libdbg.DEBUG, "master_list:%s", dkjson.encode(master_list))

    local slave_data = get_devRemarkData(slave_ip)
    if slave_data == -1 or slave_data == nil then
        libdbg.lua_debug(libdbg.ERROR, "slave_data get failed")
        return
    end
    local slave_list = slave_data.list
    if slave_list == nil then
        libdbg.lua_debug(libdbg.ERROR, "slave_list is null")
        return
    end
    libdbg.lua_debug(libdbg.DEBUG, "slave_list:%s", dkjson.encode(slave_list))

    update_list = merge_list(master_list, slave_list)
    update_data = {list = update_list}
    local devRemark_str = dkjson.encode(update_data)
    libdbg.lua_debug(libdbg.DEBUG, "update_data:%s", devRemark_str)
    
    result = dev_config.fetch("update", "devRemark", devRemark_str)
    -- libdbg.lua_debug(libdbg.DEBUG, "result:%s", result.data)

    result = dev_config.fetch("del", "devRemark", '{"list":[]}', 1, slave_ip)
    -- libdbg.lua_debug(libdbg.DEBUG, "result:%s", result.data)
end

