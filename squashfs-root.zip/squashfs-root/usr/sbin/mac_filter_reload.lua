#!/usr/bin/env lua

local ubus = require("ubus");

function file_exists(path)
  local file = io.open(path, "rb")
  if file then file:close() end
  return file ~= nil
end

local function ubus_send()
    local conn = ubus.connect()

    if not conn then
        debug_print("ubus_send","ubus connect failed")
        return
    end

    conn:send("mac_filter_change", {})
    
    conn:close()
end

os.execute("/usr/sbin/mac_filter_exec.lua")

if (file_exists("/proc/shortcut_flush") == true) then
    os.execute("echo 'f' > /proc/shortcut_flush") 
end

if (file_exists("/usr/lib/lua/hnat/hwnat_clean_entry.lua") == true) then
    os.execute("/usr/bin/lua /usr/lib/lua/hnat/hwnat_clean_entry.lua");
end

ubus_send()
