#!/bin/sh

. /usr/share/libubox/jshn.sh

NFPP_CONFIG="/etc/sd_config/single/nfpp.json"
NFPP_ZONE_RULES="/tmp/iptables.rules/nfpp_zone_rule_"

nfpp_update_syn_flood_rule()
{
    local zone=$1
    local syn_flood=$2
    
    json_select "syn_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."
    
    if [ -f "/proc/nfpp/nfpp_tcp_syn_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_tcp_syn_drop_num 2>/dev/null
    fi
    
    echo "ip6tables -w -t filter -F syn_flood_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/tcp_syn_rate" -a -f "/proc/nfpp/tcp_syn_rate" ]; then
            echo 0 > /proc/nfpp/tcp_syn_rate 2>/dev/null
            echo 0 > /proc/nfpp/tcp_syn_burst 2>/dev/null
        fi
        
        return
    fi
    
    if [ "$limit_rate" -ge "5000" ]; then
        echo "ip6tables -w -t filter -A syn_flood_$zone -p tcp --syn -m limit --limit 10000/second --limit-burst 10000 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    else
        echo "ip6tables -w -t filter -A syn_flood_$zone -p tcp --syn -m limit --limit $limit_rate/second --limit-burst $((limit_rate * 2)) -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    fi
    echo "ip6tables -w -t filter -A syn_flood_$zone -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    
    if [ -n "$limit_rate" -a -f "/proc/nfpp/tcp_syn_rate" -a -f "/proc/nfpp/tcp_syn_rate" ]; then
        echo -e "$limit_rate" > /proc/nfpp/tcp_syn_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/tcp_syn_burst 2>/dev/null
    fi
}

nfpp_update_icmp_flood_rule()
{
    local zone=$1
    local icmp_flood=$2
    
    json_select "icmp_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."
    
    if [ -f "/proc/nfpp/nfpp_icmp_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_icmp_drop_num 2>/dev/null
    fi
    
    echo "ip6tables -w -t filter -F icmp_flood_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/icmp_rate" -a -f "/proc/nfpp/icmp_burst" ]; then
            echo 0 > /proc/nfpp/icmp_rate 2>/dev/null
            echo 0 > /proc/nfpp/icmp_burst  2>/dev/null
        fi
    
        return
    fi

    if [ "$limit_rate" -ge "5000" ]; then
        echo "ip6tables -w -t filter -A icmp_flood_$zone -p ipv6-icmp -m limit --limit 10000/second --limit-burst 10000 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    else
        echo "ip6tables -w -t filter -A icmp_flood_$zone -p ipv6-icmp -m limit --limit $limit_rate/second --limit-burst $((limit_rate * 2)) -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    fi

    echo "ip6tables -w -t filter -A icmp_flood_$zone -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone 

    if [ -n "$limit_rate" -a -f "/proc/nfpp/icmp_rate" -a -f "/proc/nfpp/icmp_burst" ]; then
        echo -e "$limit_rate" > /proc/nfpp/icmp_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/icmp_burst  2>/dev/null
    fi

}

nfpp_update_udp_flood_rule()
{
    local zone=$1
    local udp_flood=$2
    
    json_select "udp_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."
    
    if [ -f "/proc/nfpp/nfpp_udp_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_udp_drop_num 2>/dev/null
    fi
    
    echo "ip6tables -w -t filter -F udp_flood_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/udp_rate" -a -f "/proc/nfpp/udp_burst" ]; then
            echo 0 > /proc/nfpp/udp_rate 2>/dev/null
            echo 0 > /proc/nfpp/udp_burst  2>/dev/null
        fi
        
        return
    fi
    
    if [ "$limit_rate" -ge "5000" ]; then
            echo "ip6tables -w -t filter -A udp_flood_$zone -m limit --limit 10000/second --limit-burst 10000 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    else
        echo "ip6tables -w -t filter -A udp_flood_$zone -m limit --limit $limit_rate/second --limit-burst $((limit_rate * 2)) -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    fi

    echo "ip6tables -w -t filter -A udp_flood_$zone -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone

    if [ -n "$limit_rate" -a -f "/proc/nfpp/udp_rate" -a -f "/proc/nfpp/udp_burst" ]; then
        echo -e "$limit_rate" > /proc/nfpp/udp_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/udp_burst  2>/dev/null
    fi
}

nfpp_update_tcp_other_flood_rule()
{
    local zone=$1
    local tcp_other_flood=$2
   
    if [ -z "$tcp_other_flood" ]; then
        return
    fi
   
    json_select "tcp_other_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."
    
    if [ -f "/proc/nfpp/nfpp_tcp_other_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_tcp_other_drop_num 2>/dev/null
    fi
    
    if [ "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/tcp_other_rate" -a -f "/proc/nfpp/tcp_other_burst" ]; then
            echo 0 > /proc/nfpp/tcp_other_rate 2>/dev/null
            echo 0 > /proc/nfpp/tcp_other_burst  2>/dev/null
        fi
    
        return
    fi

    if [ -n "$limit_rate" -a -f "/proc/nfpp/tcp_other_rate" -a -f "/proc/nfpp/tcp_other_burst" ]; then
        echo -e "$limit_rate" > /proc/nfpp/tcp_other_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/tcp_other_burst  2>/dev/null
    fi
}

nfpp_update_other_flood_rule()
{
    local zone=$1
    local other_flood=$2
    
    if [ -z "$other_flood" ]; then
        return
    fi
    
    json_select "other_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."
    
    if [ -f "/proc/nfpp/nfpp_other_ip_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_other_ip_drop_num 2>/dev/null
    fi    
    
    if [  "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/other_ip_proto_rate" -a -f "/proc/nfpp/other_ip_proto_burst" ]; then
            echo 0 > /proc/nfpp/other_ip_proto_rate 2>/dev/null
            echo 0 > /proc/nfpp/other_ip_proto_burst  2>/dev/null
        fi
        
        return
    fi

    if [ -n "$limit_rate" -a -f "/proc/nfpp/other_ip_proto_rate" -a -f "/proc/nfpp/other_ip_proto_burst" ]; then
        echo -e "$limit_rate" > /proc/nfpp/other_ip_proto_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/other_ip_proto_burst 2>/dev/null
    fi
}

nfpp_update_arp_flood_rule()
{
    local zone=$1
    local arp_flood=$2
    
    if [ -z "$arp_flood" ]; then
        return
    fi
    
    json_select "arp_flood"
    json_get_var enable "enable"
    json_get_var limit_rate "limit_rate"
   
    json_select ".."


    if [ -f "/proc/nfpp/nfpp_arp_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_arp_drop_num 2>/dev/null
    fi
    
    if [  "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/arp_burst" -a -f "/proc/nfpp/arp_rate" ]; then
            uci set nfpp.nfpp_bridge.enable='0'
            uci set nfpp.nfpp_bridge.arp_burst='0'
            uci set nfpp.nfpp_bridge.arp_rate='0'
            
            echo -e "0" > /proc/nfpp/nfpp_bridge_switch 2>/dev/null
            echo -e 0 > /proc/nfpp/arp_burst 2>/dev/null
            echo -e 0 > /proc/nfpp/arp_rate  2>/dev/null
        fi
        
        return
    fi

    if [ -n "$limit_rate" -a -f "/proc/nfpp/arp_burst" -a -f "/proc/nfpp/arp_rate" ]; then
        uci set nfpp.nfpp_bridge.enable="1"
        echo -e "1" > /proc/nfpp/nfpp_bridge_switch  2>/dev/null
        
        burst_rate=$((limit_rate * 2))
        uci set nfpp.nfpp_bridge.arp_rate="$limit_rate"
        uci set nfpp.nfpp_bridge.arp_burst="$burst_rate"
        
        echo -e "$limit_rate" > /proc/nfpp/arp_rate 2>/dev/null
        echo -e $((limit_rate * 2)) > /proc/nfpp/arp_burst 2>/dev/null
    fi
}

nfpp_update_defend_ddos_rule()
{
    local zone=$1
    local defend_ddos=$2
    
    json_select "defend_ddos"
    
    json_get_var syn_flood "syn_flood"
    json_get_var arp_flood "arp_flood"
    json_get_var icmp_flood "icmp_flood"
    json_get_var udp_flood "udp_flood"
    json_get_var tcp_other_flood "tcp_other_flood"
    json_get_var other_flood "other_flood"

    nfpp_update_syn_flood_rule $zone $syn_flood
    nfpp_update_icmp_flood_rule $zone $icmp_flood
    nfpp_update_udp_flood_rule $zone $udp_flood
    nfpp_update_tcp_other_flood_rule $zone $tcp_other_flood
    nfpp_update_other_flood_rule $zone $other_flood
    nfpp_update_arp_flood_rule $zone $arp_flood

    json_select ".."
}

nfpp_update_large_ping_rule()
{
    local zone=$1
    local large_ping=$2
    
    json_select "large_ping"
    json_get_var enable "enable"
    json_get_var limit_length "limit_length"
    json_select ".."

    echo "iptables -w -t filter -F large_ping_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        return
    fi
    
    echo "iptables -w -t filter -A large_ping_$zone -p icmp -m length --length :$limit_length -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A large_ping_$zone -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix large_ping 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A large_ping_$zone -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone
}

nfpp_update_fraggle_atk_rule()
{
    local zone=$1
    local fraggle_atk=$2
    
    json_select "fraggle_atk"
    json_get_var enable "enable"
    json_select ".."

    echo "iptables -w -t filter -F fraggle_atk_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        return
    fi
    echo "iptables -w -t filter -A fraggle_atk_$zone -p udp -m multiport --dports 7,19 -m limit --limit 50/sec --limit-burst 100 -j NFLOG --nflog-group 1 --nflog-prefix fraggle_atk 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A fraggle_atk_$zone -p udp -m multiport --dports 7,19 -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone
}

nfpp_update_icmp_check_rule()
{
    local zone=$1
    local icmp_check=$2
    
    json_select "icmp_check"
    json_get_var enable "enable"
    json_select ".."

    echo "iptables -w -t filter -F icmp_check_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    if [ "$enable" == "0" ]; then
        return
    fi

    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type echo-reply -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type destination-unreachable -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type source-quench -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type redirect -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type echo-request -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone  
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type router-advertisement -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type router-solicitation -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type time-exceeded -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type parameter-problem -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type address-mask-request -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp --icmp-type address-mask-reply -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone   
    echo "iptables -w -t filter -A icmp_check_$zone -p icmp -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone       
}

nfpp_update_ip_check_rule()
{
    local zone=$1
    local ip_check=$2
    
    json_select "ip_check"
    json_get_var enable "enable"
    json_select ".."

    echo "iptables -w -t filter -F ip_check_port_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -D ip_check_$zone -d 240.0.0.0/4 -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone

    if [ "$enable" == "0" ]; then
        return
    fi

    echo "iptables -w -t filter -A ip_check_$zone -d 240.0.0.0/4 -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone

    echo "iptables -w -t filter -A ip_check_port_$zone -p 1 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 2 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 3 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 4 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 5 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 6 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 8 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 9 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 12 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 17 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 20 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 22 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 27 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 29 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 36 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 37 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 38 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 45 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 46 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 47 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
    echo "iptables -w -t filter -A ip_check_port_$zone -p 50 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 51 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 57 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 73 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 81 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 88 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 89 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 93 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 94 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 97 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 98 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 99 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 103 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 108 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 112 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 115 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 124 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 132 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone
	echo "iptables -w -t filter -A ip_check_port_$zone -p 133 -j RETURN 2>/dev/null" >> $NFPP_ZONE_RULES$zone   
	echo "iptables -w -t filter -A ip_check_port_$zone -j REJECT --reject-with icmp-proto-unreachable 2>/dev/null" >> $NFPP_ZONE_RULES$zone       
}

nfpp_update_malformed_pkt_rule()
{
    local zone=$1
    local malformed_pkt=$2
    
    json_select "malformed_pkt"
    
    json_get_var large_ping "large_ping"
    json_get_var fraggle_atk "fraggle_atk"
    json_get_var icmp_check "icmp_check"
    json_get_var ip_check "ip_check"
    
    nfpp_update_large_ping_rule $zone $large_ping
    nfpp_update_fraggle_atk_rule $zone $fraggle_atk
    nfpp_update_icmp_check_rule $zone $icmp_check
    nfpp_update_ip_check_rule $zone $ip_check
    
    json_select ".."
}

nfpp_update_session_rule()
{
    local zone=$1
    local session_safe=$2
    
    json_select "session_safe"
    json_select "rate_limit"
    json_get_var enable "enable"
    json_get_var global_rate "global_rate"
    json_get_var record_rate "record_rate"
   
    json_select ".."
    json_select ".."

    if [ -f "/proc/nfpp/nfpp_session_drop_num" ]; then
        echo 0 > /proc/nfpp/nfpp_session_drop_num 2>/dev/null
    fi   
    
    if [  "$enable" == "0" ]; then
        if [ -f "/proc/nfpp/hash_ip_burst" -a -f "/proc/nfpp/hash_ip_rate" -a -f "/proc/nfpp/ip_limit_default_burst" -a "/proc/nfpp/ip_limit_default_rate" ]; then
            uci set nfpp.nfpp_conntrack.enable="0"
            uci set nfpp.nfpp_conntrack.record_rate="0"
            uci set nfpp.nfpp_conntrack.record_burst="0"
            uci set nfpp.nfpp_conntrack.global_burst="0"
            uci set nfpp.nfpp_conntrack.global_rate="0"

            echo -e "0" > /proc/nfpp/nfpp_conntrack_switch 2>/dev/null
            echo -e 0 > /proc/nfpp/hash_ip_burst 2>/dev/null
            echo -e 0 > /proc/nfpp/hash_ip_rate 2>/dev/null
            echo -e 0 > /proc/nfpp/ip_limit_default_burst 2>/dev/null
            echo -e 0 > /proc/nfpp/ip_limit_default_rate 2>/dev/null
        fi
        
        return
    fi

    if [ -n "$global_rate" -a -n "$record_rate" -a -f "/proc/nfpp/hash_ip_burst" -a -f "/proc/nfpp/hash_ip_rate" -a -f "/proc/nfpp/ip_limit_default_burst" -a "/proc/nfpp/ip_limit_default_rate" ]; then
        uci set nfpp.nfpp_conntrack.enable="1"
        uci set nfpp.nfpp_conntrack.record_rate="$record_rate"
        uci set nfpp.nfpp_conntrack.record_burst="$record_rate"
        uci set nfpp.nfpp_conntrack.global_burst="$global_rate"
        uci set nfpp.nfpp_conntrack.global_rate="$global_rate"

        echo -e "1" > /proc/nfpp/nfpp_conntrack_switch  2>/dev/null
        echo -e "$record_rate" > /proc/nfpp/hash_ip_burst 2>/dev/null
        echo -e "$record_rate" > /proc/nfpp/hash_ip_rate 2>/dev/null
        echo -e "$global_rate" > /proc/nfpp/ip_limit_default_burst 2>/dev/null
        echo -e "$global_rate" > /proc/nfpp/ip_limit_default_rate 2>/dev/null
    fi
}

nfpp_update_icmp_forbit_rule()
{
    local zone=$1
    local icmp_forbit=$2
    
    json_select "icmp_forbit"
    json_get_var enable "enable"
    json_select "msg_type"
    
    echo "iptables -w -t filter -F icmp_forbit_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone    
    
    if [ "$enable" == "0" ]; then
        json_select ".."
        json_select ".."
        return
    fi   
    
    local index="1"
    while json_is_a ${index} object; do
        json_select "$index"
        json_get_var type "type"
        json_get_var code "code"
        json_get_var icmpenable "enable"

        if [ "$icmpenable" == "1" ]; then
            len=${#code}
            if [ $len == 0 ]; then 
                echo "iptables -w -t filter -A icmp_forbit_$zone -p icmp -m icmp --icmp-type $type -j DROP  2>/dev/null" >> $NFPP_ZONE_RULES$zone   
            else
                echo "iptables -w -t filter -A icmp_forbit_$zone -p icmp -m icmp --icmp-type $type/$code -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone   
            fi
        fi

        index=$((index+1))
        json_select ".."
    done
    
    json_select ".."
    json_select ".."
}

nfpp_update_icmpv6_forbit_rule()
{
    local zone=$1
    local icmpv6_forbit=$2
    
    json_select "icmpv6_forbit"
    json_get_var enable "enable"
    json_select "msg_type"
    
    echo "ip6tables -w -t filter -F icmpv6_forbit_$zone 2>/dev/null" >> $NFPP_ZONE_RULES$zone    
    
    if [ "$enable" == "0" ]; then
        json_select ".."
        json_select ".."
        return
    fi   
    
    local index="1"
    while json_is_a ${index} object; do
        json_select "$index"
        json_get_var type "type"
        json_get_var code "code"
        json_get_var icmpv6enable "enable"

        if [ "$icmpv6enable" == "1" ]; then
            len=${#code}
            if [ $len == 0 ]; then 
                echo "ip6tables -w -t filter -A icmpv6_forbit_$zone -p ipv6-icmp -m icmp6 --icmpv6-type $type -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone   
            else
                echo "ip6tables -w -t filter -A icmpv6_forbit_$zone -p ipv6-icmp -m icmp6 --icmpv6-type  $type/$code -j DROP 2>/dev/null" >> $NFPP_ZONE_RULES$zone   
            fi
        fi
        
        index=$((index+1))
        json_select ".."
    done
    
    json_select ".."
    json_select ".."
}

nfpp_update_local_pkt_send_rule()
{
    local zone=$1
    local local_pkt_send=$2
    
    json_select "local_pkt_send"
    
    json_get_var icmp_forbit "icmp_forbit"
    json_get_var icmpv6_forbit "icmpv6_forbit"
    
    nfpp_update_icmp_forbit_rule $zone $icmp_forbit
    nfpp_update_icmpv6_forbit_rule $zone $icmpv6_forbit
    
    json_select ".."
}

nfpp_parse() {
    if [ ! -e "$NFPP_CONFIG" ]; then
        return
    fi

    local content=$(cat $NFPP_CONFIG)
    
    json_init
    json_load "$content"
    

    json_get_type val "list"
	if [ -n "$val" ]; then
        json_select "list"
        
        local index="1"
        while json_is_a ${index} object; do
            json_select "$index"
            json_get_var zone_name "zone_name"
            json_get_var defend_ddos "defend_ddos"
            json_get_var malformed_pkt "malformed_pkt"
            json_get_var local_pkt_send "local_pkt_send"
            json_get_var session_safe "session_safe"

            echo "" > $NFPP_ZONE_RULES$zone_name

            nfpp_update_defend_ddos_rule $zone_name $defend_ddos
            echo "" >> $NFPP_ZONE_RULES$zone_name

            nfpp_update_malformed_pkt_rule $zone_name $malformed_pkt
            echo "" >> $NFPP_ZONE_RULES$zone_name
            
            nfpp_update_local_pkt_send_rule $zone_name $local_pkt_send
            echo "" >> $NFPP_ZONE_RULES$zone_name
            
            nfpp_update_session_rule $zone_name $session_safe
            
            chmod +x $NFPP_ZONE_RULES$zone_name
            $NFPP_ZONE_RULES$zone_name
            
            index=$((index+1))
            json_select ".."
        done
    fi
    
    json_select ".."
    json_cleanup
    
    uci commit nfpp
}

nfpp_parse