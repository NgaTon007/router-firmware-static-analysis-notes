#!/bin/sh

DEV=switch0
CRC=RxCRC
TMP_FILE=/tmp/.dev_crc_errs
first=1

crc_err_0=0
crc_err_1=0
crc_err_2=0
crc_err_3=0
crc_err_4=0
crc_err_5=0
crc_err_6=0

while true
do
	swconfig dev $DEV show | grep $CRC > $TMP_FILE

	i=0
	while read line
	do
		cur=`echo $line | awk '{print $3}'`
		
		if [ $first -eq 1 ]; then
			eval crc_err_${i}=${cur}
			continue
		fi
		
		eval old='$'crc_err_${i}		
		incrs=$(($cur-$old))
		if [ $incrs -gt 0 ]; then 
			logger -t user.warn "dev $DEV Port $i RxCRC: $cur, increase $incrs in 1 min"
		fi
		
		eval crc_err_${i}=${cur}
		
		i=$((i+1))
	 done < $TMP_FILE
	
	first=0
	sleep 60
	
done
