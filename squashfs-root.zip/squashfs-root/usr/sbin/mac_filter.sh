#!/bin/sh

Rules="/tmp/iptables.rules/mac_filter"
. /usr/share/libubox/jshn.sh
. /lib/functions.sh

Table="filter"
SubChain="mac_filter_chain"
ParentChain="FORWARD_sd_chain"
sets_name="mac_set"
accept_sets_name="eth_lan_iface"
dev_allow_set="dev_allow_macfilter_set"

#创建白名单放行ppp口
create_accept_set() {
    ipset destroy "$accept_sets_name" 2>/dev/null
    ipset create "$accept_sets_name" hash:net,iface maxelem 64  -exist 2>/dev/null
    ipset add "$accept_sets_name" 0.0.0.0/0,br-lan* wildcard 2>/dev/null
    #ipv6
    ipset destroy eth_lan_iface6 2>/dev/null
    ipset create eth_lan_iface6 hash:net,iface family inet6 maxelem 64  -exist 2>/dev/null
    ipset add eth_lan_iface6 ::/0,br-lan* wildcard 2>/dev/null
}

#白名单
while_list() {   
    iptables -w -t ${Table} -A "$SubChain" -m set --match-set "$dev_allow_set" src -j RETURN 2>/dev/null
    ip6tables -w -t ${Table} -A "$SubChain" -m set --match-set "$dev_allow_set" src -j RETURN 2>/dev/null
    echo "iptables -w -t ${Table} -A $SubChain -m set --match-set $dev_allow_set src -j RETURN 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -A $SubChain -m set --match-set $dev_allow_set src -j RETURN 2>/dev/null" >> "$Rules"

    iptables -w -t ${Table} -A "$SubChain" -m set ! --match-set eth_lan_iface src,src -j RETURN 2>/dev/null
    ip6tables -w -t ${Table} -A "$SubChain" -m set ! --match-set eth_lan_iface6 src,src -j RETURN 2>/dev/null
    echo "iptables -w -t ${Table} -A $SubChain -m set ! --match-set eth_lan_iface src,src -j RETURN 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -A $SubChain -m set ! --match-set eth_lan_iface6 src,src -j RETURN 2>/dev/null" >> "$Rules"

    iptables -w -t ${Table} -A "$SubChain" -m set --match-set "$sets_name" src -j RETURN 2>/dev/null
    ip6tables -w -t ${Table} -A "$SubChain" -m set --match-set "$sets_name" src -j RETURN 2>/dev/null
    echo "iptables -w -t ${Table} -A $SubChain -m set --match-set $sets_name src -j RETURN 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -A $SubChain -m set --match-set $sets_name src -j RETURN 2>/dev/null" >> "$Rules"
    
    iptables -w -t ${Table} -A "$SubChain" -j DROP 2>/dev/null
    ip6tables -w -t ${Table} -A "$SubChain" -j DROP 2>/dev/null
    echo "iptables -w -t ${Table} -A $SubChain -j DROP 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -A $SubChain -j DROP 2>/dev/null" >> "$Rules"
}

#黑名单
black_list() {
    iptables -w -t ${Table} -I "$SubChain" -m set --match-set "$sets_name" src -j DROP 2>/dev/null
    ip6tables -w -t ${Table} -I "$SubChain" -m set --match-set "$sets_name" src -j DROP 2>/dev/null
    echo "iptables -w -t ${Table} -I $SubChain -m set --match-set $sets_name src -j DROP 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -I $SubChain -m set --match-set $sets_name src -j DROP 2>/dev/null" >> "$Rules"
    
    iptables -w -t ${Table} -A "$SubChain" -j RETURN 2>/dev/null
    ip6tables -w -t ${Table} -A "$SubChain" -j RETURN 2>/dev/null
    echo "iptables -w -t ${Table} -A $SubChain -j RETURN 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -A $SubChain -j RETURN 2>/dev/null" >> "$Rules"
}

#创建自定义链
create_chain() {
    #清空原先存在自定义链
    clean_chain
    
    iptables -w -t ${Table} -N "$SubChain" 2>/dev/null
    ip6tables -w -t ${Table} -N "$SubChain" 2>/dev/null
    echo "iptables -w -t ${Table} -N $SubChain 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -N $SubChain 2>/dev/null" >> "$Rules"
    
    iptables -w -t ${Table} -D "$ParentChain" -j "$SubChain" 2>/dev/null   
    ip6tables -w -t ${Table} -D "$ParentChain" -j "$SubChain" 2>/dev/null 
    echo "iptables -w -t ${Table} -D $ParentChain -j $SubChain 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -D $ParentChain -j $SubChain 2>/dev/null" >> "$Rules"
    
    iptables -w -t ${Table} -I "$ParentChain" -j "$SubChain" 2>/dev/null
    ip6tables -w -t ${Table} -I "$ParentChain" -j "$SubChain" 2>/dev/null   
    echo "iptables -w -t ${Table} -I $ParentChain -j $SubChain 2>/dev/null" >> "$Rules"
    echo "ip6tables -w -t ${Table} -I $ParentChain -j $SubChain 2>/dev/null" >> "$Rules"
    
    ipset destroy "$sets_name" 2>/dev/null

    ipset create "$sets_name" hash:mac -exist 2>/dev/null
    
    
    # 增加组网设备放行集合
    ipset create "$dev_allow_set" hash:mac -exist 2>/dev/null
}

#清空自定义链
clean_chain() {
    iptables -w -t ${Table} -F "$SubChain" 2>/dev/null
    ip6tables -w -t ${Table} -F "$SubChain" 2>/dev/null
    ipset flush "$sets_name" 2>/dev/null
    echo "" > "$Rules"
    
    rm -rf "$Rules"_wan*
}

#主函数
main() {
    #判断是否开启mac黑白名单
    op="$1"
    case "$op" in
        "init") create_chain
        ;;
        "clean") clean_chain
        ;;
        *) echo "ERROR: Invild Parameter!"
        ;;
    esac

    #判断开启的模式为白名单/黑名单
    model="$2"
    [ -z "$model" ] && {
        return
    }
    case "$model" in
        "white") 
            create_accept_set
            while_list
            ;;
        "black") 
            black_list
            ;;
        *) echo "ERROR: Invild Parameter!"
            ;;
    esac
}

#主函数
main "$1" "$2"
