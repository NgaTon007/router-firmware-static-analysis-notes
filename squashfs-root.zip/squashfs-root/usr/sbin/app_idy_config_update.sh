#!/bin/sh

#解决app_identify新增应用分组解析问题
ret=$(cat /etc/config/app_identify | grep -E 'communication|video|shopping')
if [ -z "$ret" ]; then
    uci set app_identify.communication=Custom_Group
	uci set app_identify.communication.name="社交软件"
	uci add_list app_identify.communication.app="即时通讯软件"
	uci add_list app_identify.communication.app="即时通讯_MOBILE"
	uci add_list app_identify.communication.app="社交_MOBILE"
	uci add_list app_identify.communication.app="微博"
	uci set app_identify.video=Custom_Group
	uci set app_identify.video.name="视频|音乐|直播"
	uci add_list app_identify.video.app="HTTP视频"
	uci add_list app_identify.video.app="视频|影音_MOBILE"
	uci add_list app_identify.video.app="视频流媒体软件"
	uci add_list app_identify.video.app="视频直播类"
	uci set app_identify.shopping=Custom_Group
	uci set app_identify.shopping.name="网络购物"
	uci add_list app_identify.shopping.app="HTTP网络购物"
	uci add_list app_identify.shopping.app="网购_MOBILE"
	uci set app_identify.games=Custom_Group
	uci set app_identify.games.name="网络游戏"
	uci add_list app_identify.games.app="网络游戏软件"
	uci add_list app_identify.games.app="游戏_MOBILE"
	uci set app_identify.databank=Custom_Group
	uci set app_identify.databank.name="网络硬盘|云存储"
	uci add_list app_identify.databank.app="网络硬盘"
	uci set app_identify.p2p_software=Custom_Group
	uci set app_identify.p2p_software.name="P2P软件"
	uci add_list app_identify.p2p_software.app="P2P应用软件"
	uci set app_identify.app_store=Custom_Group
	uci set app_identify.app_store.name="应用商店"
	uci add_list app_identify.app_store.app="下载工具_MOBILE"
	uci set app_identify.financial=Custom_Group
	uci set app_identify.financial.name="金融软件"
	uci add_list app_identify.financial.app="股票软件"
	uci commit app_identify
fi
ret=$(cat /etc/config/app_identify | grep -w 'news')
if [ -z "$ret" ]; then
	uci set app_identify.news=Custom_Group
	uci set app_identify.news.name="新闻阅读"
	uci add_list app_identify.news.app="新闻资讯"
	uci add_list app_identify.news.app="新闻资讯_Mobile"
	uci commit app_identify
fi
ret=$(cat /etc/config/app_identify | grep -w '证券_MOBILE')
if [ -n "$ret" ]; then
	uci -q del_list app_identify.financial.app="证券_MOBILE"
	uci commit app_identify
fi

#English
ret=$(cat /etc/config/app_identify | grep -E 'communication_En|video_En|shopping_En')
if [ -z "$ret" ]; then
	uci set app_identify.communication_En=Custom_Group_En
	uci set app_identify.communication_En.name="Communication"
	uci add_list app_identify.communication_En.app="Social_applications"
	uci add_list app_identify.communication_En.app="Chat"
	uci add_list app_identify.communication_En.app="InstantMessaging_MOBILE"
	uci set app_identify.video_En=Custom_Group_En
	uci set app_identify.video_En.name="Video"
	uci add_list app_identify.video_En.app="Video_MOBILE"
	uci add_list app_identify.video_En.app="HTTP-VIDEO"
	uci add_list app_identify.video_En.app="STREAMING"
	uci set app_identify.shopping_En=Custom_Group_En
	uci set app_identify.shopping_En.name="Shopping"
	uci add_list app_identify.shopping_En.app="Online_Shopping"
	uci set app_identify.games_En=Custom_Group_En
	uci set app_identify.games_En.name="Play"
	uci add_list app_identify.games_En.app="Games"
	uci add_list app_identify.games_En.app="Game_MOBILE"
	uci set app_identify.databank_En=Custom_Group_En
	uci set app_identify.databank_En.name="Databank"
	uci add_list app_identify.databank_En.app="OnlineStorage"
	uci set app_identify.p2p_software_En=Custom_Group_En
	uci set app_identify.p2p_software_En.name="P2PSoftware"
	uci add_list app_identify.p2p_software_En.app="P2P"
	uci set app_identify.app_store_En=Custom_Group_En
	uci set app_identify.app_store_En.name="AppStore"
	uci add_list app_identify.app_store_En.app="DownloadTools_MOBILE"
	uci set app_identify.app_store_En=payment_En
	uci set app_identify.app_store_En.name="Payment"
	uci add_list app_identify.app_store_En.app="OnlinePayment|Bank_MOBILE"
	uci add_list app_identify.app_store_En.app="OnlineBank"
	uci commit app_identify
fi

ret=$(cat /etc/config/app_identify | grep -w 'signature')
if [ -z "$ret" ]; then
	uci set app_identify.signature=main
	uci set app_identify.signature.version="2"
	uci commit app_identify
	/etc/init.d/app_identify restart
fi

ret=`cat /etc/config/ca_url_list | grep "dz\*.com"`
if [ ! -z "$ret" ]; then
    uci -q del_list ca_url_list.news.url="dz*.com"
    uci -q del_list ca_url_list.sports.url="sports.dz*.com"
    uci commit ca_url_list
fi

