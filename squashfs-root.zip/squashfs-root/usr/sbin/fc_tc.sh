#!/bin/bash

LOCK="/tmp/flowctrl.lock"
tc_file_path="/tmp/flowctrl/flowctrl_config"
file_path="/usr/sbin/flowctrl_tc_cfg.lua"
FC_OP_LOG="/tmp/flowctrl/opteration.log"
FC_OP_LOG_SIZE=5        # 日志文件大小, 单位KB; du最小都是4k，而且是4的整数倍，故不能设置小于4k。

help()
{
cat <<EOF
Syntax: flow_start [command]

Available commands:
	start           Start creat tc chl
	stop            del tc chl
	restart         Restart creat tc chl      
EOF
}

debug_log()
{
    local cur_time=$(date "+[%Y-%m-%d %H:%M:%S]")
    local file_size
    if [ -e $FC_OP_LOG ]; then
            file_size=$(du -shk $FC_OP_LOG | awk '{print $1}' | tr -d ' \n\t')
    else
            file_size=0
    fi

    [ $file_size  -gt $FC_OP_LOG_SIZE ] && {
            mv -f $FC_OP_LOG ${FC_OP_LOG}.old
    }

    echo -e "${cur_time} ${1}" >> $FC_OP_LOG
}

#由于template_path old_cfg fc_policy_check三个脚本会同写一个配置文件，因此启机的时候不能单独分开，把他们放在一个脚本顺序启动。 仅有启机的时候调用start web只调用restart 因此lua $old_cfg不会频繁执行
start() {
    #接口上下线、流控开关和特征库切换需进行所有策略生效性检查
    debug_log "[fc_tc]:start"
    :> $tc_file_path 2>/dev/null
    lua /usr/sbin/fc_policy_check.lua
    lua /usr/sbin/fc_data_recode.lua
    #不能加&号防止策略太多时通道没创建完成又二次创建
    lua $file_path
    fc_tc_cmd.elf --start
    /usr/sbin/fc_cmd.elf -R
}

stop() {
    debug_log "[fc_tc]:stop"
    :> $tc_file_path 2>/dev/null
    :> /tmp/flowctrl/udf 2>/dev/null
    fc_tc_cmd.elf --clean
    #停止后重置策略
    /usr/sbin/fc_cmd.elf -R
}

restart() {
    debug_log "[fc_tc]:restart"
    #策略更新不需要进行所有策略检查
    #清空配置，重写文件
    :> $tc_file_path 2>/dev/null
    #重启只检查时间生效性 不检查接口生效性
    lua /usr/sbin/flowctrl_tr_check.lua
    lua /usr/sbin/fc_data_recode.lua
    lua $file_path
    fc_tc_cmd.elf --restart
    /usr/sbin/fc_cmd.elf -R
}

case "$1" in
	start|stop|restart)
		$*
	;;
	*)
		help
	;;
esac

exit 0
