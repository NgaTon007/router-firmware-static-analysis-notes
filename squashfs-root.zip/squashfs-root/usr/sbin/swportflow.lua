#!/usr/bin/env lua

module("flow_status", package.seeall);
cjson = require "cjson"
ubus = require "ubus"
tool = require "dev.tools.common"

modul = "swconfig"
flow_path = "/tmp/ap_log/all/swportflow/swportflow"

local function tbl_num_to_str(obj)
    if type(obj) == "table" then
        for k, v in pairs(obj) do
            if type(v) == "number" then
                -- 将数字转换为字符串
                obj[k] = tostring(v)
            elseif type(v) == "table" then
                -- 递归处理嵌套的表中的数值
                tbl_num_to_str(v)
            end
        end
    end
end

function file_read(conf_file)
    local file = io.open(conf_file, "r")
    local data = file:read("*a")
    file:close()
    return data
end

function file_write(conf_file, data)
    local file = io.open(conf_file,"w+")
    file:write(data)
    file:close()
end

function ubus_call(method,data)
    local conn = ubus.connect()
    if not conn then
        return
    end
    status = conn:call(modul, method, data)
    return status
end

local file = io.open(flow_path, "wr")
if (file == nil) then
    os.execute("mkdir -p /tmp/ap_log/all/swportflow");
else
    file:close()
end

ret = ubus_call("flow_status_get", {})
if (ret ~= nil) then
    tbl_num_to_str(ret)
    file_write(flow_path, cjson.encode(ret))
    return cjson.encode(ret)
end



